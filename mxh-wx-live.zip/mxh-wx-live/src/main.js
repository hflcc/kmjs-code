import Vue from 'mpvue'
import TIMApp from './App'
import TIM from 'tim-wx-sdk'
import store from './store/index'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import { isJSON } from './utils'
import wxp from 'minapp-api-promise'
import COS from 'cos-wx-sdk-v5'
import { SDKAPPID } from '../static/utils/GenerateTestUserSig'
import TYPES from './utils/types'
import fly from './utils/fly'
Vue.prototype.$http = fly
const tim = TIM.create({
  SDKAppID: SDKAPPID
})
tim.setLogLevel(0)
wx.$app = tim
wx.$app.registerPlugin({ 'cos-wx-sdk': COS })
wx.store = store
wx.TIM = TIM
wx.dayjs = dayjs
wx.$http = fly
dayjs.locale('zh-cn')

let $bus = new Vue()
Vue.prototype.TIM = TIM
Vue.prototype.$type = TYPES
Vue.prototype.$store = store
Vue.prototype.$bus = $bus
wx.$bus = $bus

tim.on(TIM.EVENT.SDK_READY, onReadyStateUpdate, this)
tim.on(TIM.EVENT.SDK_NOT_READY, onReadyStateUpdate, this)

tim.on(TIM.EVENT.KICKED_OUT, kickOut, this)
// 出错统一处理
tim.on(TIM.EVENT.ERROR, onError, this)

tim.on(TIM.EVENT.MESSAGE_RECEIVED, messageReceived, this)
tim.on(TIM.EVENT.CONVERSATION_LIST_UPDATED, convListUpdate, this)
tim.on(TIM.EVENT.GROUP_LIST_UPDATED, groupListUpdate, this)
tim.on(TIM.EVENT.BLACKLIST_UPDATED, blackListUpdate, this)
tim.on(TIM.EVENT.GROUP_SYSTEM_NOTICE_RECEIVED, groupSystemNoticeUpdate, this)
tim.on(TIM.EVENT.PROFILE_UPDATED, groupProfileUpdated, this)
tim.on(TIM.TYPES.MSG_GRP_SYS_NOTICE, msgGrpSysNotice, this)

function onReadyStateUpdate({ name }) {
  const isSDKReady = (name === TIM.EVENT.SDK_READY)
  if (isSDKReady) {
    wx.$app.getMyProfile().then(res => {
      store.commit('updateMyInfo', res.data)
    })
    wx.$app.getBlacklist().then(res => {
      store.commit('setBlacklist', res.data)
    })
  }
  store.commit('setSdkReady', isSDKReady)
}

function kickOut(event) {
  store.dispatch('resetStore')
  // wx.showToast({
  //   title: '你已被踢下线',
  //   icon: 'none',
  //   duration: 1500
  // })
  // setTimeout(() => {
  //   wx.reLaunch({
  //     url: '../login/main'
  //   })
  // }, 500)
}

function onError(event) {
  // 网络错误不弹toast && sdk未初始化完全报错
  if (event.data.message && event.data.code && event.data.code !== 2800 && event.data.code !== 2999) {
    store.commit('showToast', {
      title: event.data.message,
      duration: 2000
    })
  }
}

function messageReceived(event) {
  for (let i = 0; i < event.data.length; i++) {
    let item = event.data[i]
    if (item.type === TYPES.MSG_GRP_TIP) {
      if (item.payload.operationType) {
        $bus.$emit('groupNameUpdate', item.payload)
      }
    }
    if (item.type === TYPES.MSG_CUSTOM) {
      if (isJSON(item.payload.data)) {
        const videoCustom = JSON.parse(item.payload.data)
        if (videoCustom.version === 3) {
          switch (videoCustom.action) {
            // 对方呼叫我
            case 0:
              if (!store.getters.isCalling) {
                let url = `../call/main?args=${item.payload.data}&&from=${item.from}&&to=${item.to}`
                wx.navigateTo({ url })
              } else {
                $bus.$emit('isCalling', item)
              }
              break
              // 对方取消
            case 1:
              wx.navigateBack({
                delta: 1
              })
              break
              // 对方拒绝
            case 2:
              $bus.$emit('onRefuse')
              break
              // 对方不接1min
            case 3:
              wx.navigateBack({
                delta: 1
              })
              break
              // 对方接听
            case 4:
              $bus.$emit('onCall', videoCustom)
              break
              // 对方挂断
            case 5:
              $bus.$emit('onClose')
              break
              // 对方正在通话中
            case 6:
              $bus.$emit('onBusy')
              break
            default:
              break
          }
        }
      }
    }
  }
  store.dispatch('onMessageEvent', event)
}

function convListUpdate(event) {
  store.commit('updateAllConversation', event.data)
}

function groupListUpdate(event) {
  store.commit('updateGroupList', event.data)
}

function blackListUpdate(event) {
  store.commit('updateBlacklist', event.data)
}

function groupSystemNoticeUpdate(event) {
  if (event.data.message.payload.userDefinedField) {
    let userDefinedField = JSON.parse(event.data.message.payload.userDefinedField.replace(/\'/g, '"'))
    console.log('eventssss',userDefinedField)
    /**
	   * 关闭置顶弹幕
	   */
	  if (userDefinedField.key == 'LIVE_SIGNED_INITIATE') {
	    	store.commit('setsignedVo',userDefinedField.value);	    
	  }
    /**
	   * 关闭置顶弹幕
	   */
	  if (userDefinedField.key == 'LIVE_TOP_MESSAGE_CLOSE') {
	    store.commit('setTopmesg','')
	    
	  }
	  /**
	   * 置顶弹幕
	   */
	  if (userDefinedField.key == 'LIVE_TOP_MESSAGE') {
	    store.commit('setTopmesg',userDefinedField.value)
	    
	  }
    /**
     * 禁言单个用户
     */
    if (userDefinedField.key == 'NO_TALKING' && userDefinedField.value == wx.getStorageSync('mxhUserInfo').openid) {
      store.commit('updateGroupMemberProfile', event.data.message.to)
    }

    /**
     * 禁言全体用户
     */
    if (userDefinedField.key == 'NO_TALKING' && userDefinedField.value == '1') {
      store.commit('updateAllbannedSpeak', 1)
    }

    /**
     * 解除全体用户禁言
     */
    if (userDefinedField.key == 'NO_TALKING' && userDefinedField.value == '0') {
      store.commit('updateAllbannedSpeak', 0)
    }

    /**
     * 打开考试
     */
    if (userDefinedField.key == 'PUSH_EXAM') {
      store.commit('getIsExam', event.data.message.to)
    }

    /**
     * 停止直播
     */
    if (userDefinedField.key == 'STOP_LIVE') {
      store.commit('setColseLive', 1)
    }

    /**
     * 开始直播
     */
    if (userDefinedField.key == 'START_LIVE') {
      store.commit('setColseLive', 0)
    }

    /**
     * 解锁ppt
     */
    if(userDefinedField.key == 'RELIEVE_PPT_LOCK'){
      store.commit('unlockpptList', userDefinedField.value -1)
    }
    /**
     * 更新ppt
     */
    if(userDefinedField.key == 'UPDATE_PPT'){
      store.commit('updatePPT')
    }

    /**
     * 增加用户观看人数
     */
    if(userDefinedField.key == 'ADD_USER_LIVE'){
      store.commit('updateAddUserLive')
    }

    /**
     * 添加提问通知
     * 删除提问通知
     */
    if(userDefinedField.key == 'ADD_COMMENT' || userDefinedField.key == 'DEL_COMMENT'){
      store.commit('updateComment',true)
    }

    /**
     * 点赞通知
     */
    if(userDefinedField.key == 'ADD_LIVE_LIKE'){
      store.commit('updateAddLiveLive')
    }

    /**
     * 观众申请连麦
     */
    // if(userDefinedField.key == 'VIEWERS_APPLY_LINK'){
      
    // }

    /**
     * 主播响应观众连麦
     */
    // if(userDefinedField.key == 'LINK_VIEWERS_LIVE'){
      
    // }

    /**
     * 用户主动断开连麦
     */
    if(userDefinedField.key == 'VIEWERS_DISCONNECT_LIVE'){
      store.commit('offConnectLive',true)
    }

    /**
     * 用户同意连麦
     */
    if(userDefinedField.key == 'USER_ASSENT_LIVE'){
      store.commit('openConnectLive',true)
    }

    // /**
    //  * 用户拒绝或直播过期
    //  */
    // if(userDefinedField.key == 'USER_REFUSE_LIVE'){
      
    // }

    // /**
    //  * 主播结束直播清除所有申请
    //  */
    // if(userDefinedField.key == 'DEL_INTERACTIVE_ALL'){
      
    // }

    /**
     * 主播断开与观众的连麦
     */
    if(userDefinedField.key == 'LIVE_DISCONNECT_VIEWERS_LINK'){
      store.commit('offConnectLive',true)
    }

    /**
     * 主播之间连麦PK成功
     */
    if(userDefinedField.key == 'LIVE_LINK_PK_SUCCESS'){
      store.commit('openConnectLive',true)
    }


    /**
     * 推送上架商品列表通知
     */
    if(userDefinedField.key == 'UPDATE_LIVE_GOODS'){
      console.log(1)
      store.commit('updateLiveGoods',true)
    }

    /**
     * 推送下架商品列表通知
     */
    if(userDefinedField.key == 'DEL_LIVE_GOODS'){
      console.log(2)
      store.commit('updateLiveGoods',true)
    }

    /**
     * 直播时候提醒的商品
     */
    if(userDefinedField.key == 'LIVE_TIPS_COMMODITY'){
      store.commit('updateLiveTipsGoods',userDefinedField.value)
    }

  }
}

function groupProfileUpdated(event) {
  console.log(event)
}

function msgGrpSysNotice(event) {
  console.log(event, 8888)
}


function getCode() {
  return new Promise(function(resolve, reject) {
    wx.login({
      success: function(res) {
        if (res.code) {
          resolve(res.code)
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  })
}

async function onGotUserInfo() {
  let code = await getCode()
  let url = '/wechat/v2/getOpenId/' + code
  fly.get(url).then((res) => {
    wxp.setStorageSync('openId', res.data.openId)
  })
}

onGotUserInfo()

new Vue({
  TIMApp
}).$mount()
