const userModules = {
  state: {
    myInfo: {},
    userProfile: {},
    blacklist: [],
    isLogin: false
  },
  getters: {
    myInfo: state => state.myInfo,
    userProfile: state => state.userProfile,
    isLogin: state => state.isLogin
  },
  mutations: {
    updateMyInfo (state, myInfo) {
      state.myInfo = myInfo
    },
    updateUserProfile (state, userProfile) {
      state.userProfile = userProfile
    },
    setBlacklist (state, blacklist) {
      state.blacklist = blacklist
    },
    updateBlacklist (state, blacklist) {
      state.blacklist.push(blacklist)
    },
    setIsLogin (state, isLogin) {
      state.isLogin = isLogin
    },
    resetUser (state) {
      state.blacklist = []
      state.userProfile = {}
      state.myInfo = {}
    }
  }
}

export default userModules
