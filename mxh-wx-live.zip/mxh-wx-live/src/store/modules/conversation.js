import { formatTime } from '../../utils/index'
import { decodeElement } from '../../utils/decodeElement'
import TIM from 'tim-wx-sdk'
import fly from '../../utils/fly'
const conversationModules = {
  state: {
    allConversation: [], // 所有的conversation
    currentConversationID: '', // 当前聊天对话ID
    currentConversation: {}, // 当前聊天对话信息
    currentMessageList: [], // 当前聊天消息列表
    nextReqMessageID: '', // 下一条消息标志
    isCompleted: false, // 当前会话消息是否已经请求完毕
    isLoading: false, // 是否正在请求
    groupMemberProfile: [],
    isExam: 1, // 是否已参加 0没参加  1参加
    isOpenExam: 0, // 是否开启 0没开启  1开启
    closelive: 2, // 是否关闭直播
    updateLogin: false, //是否回调登录后回调方法
    pptList: [], // ppt 列表
    pptindex: 1,
    isLogin: false, // 是否显示登录弹窗
    isLoginCallback: false,
    updatepptlocation: false,
    updatePPTList: 0, // 是否更新ppt列表
    allbannedSpeak: false, // 是否全体禁言,
    userLiveNumber: 0, //用户观看人数
    updateComment: false, // 是否更新提问
    likeNum: 0, // 点赞数
    isOffConnectLive: false, // 关闭连麦直播
    isOpenConnectLive: false, // 关闭连麦直播
    isUpdateLiveGoodsList: false, //是否更新直播商品
    liveTipsGoods: {}, //直播推送商品
    Topmesg:'',
    signedVo:null,
  },
  getters: {
    allConversation: state => state.allConversation,
    allpptList: state => state.allpptList,
    // 当前聊天对象的ID
    toAccount: state => {
      if (state.currentConversationID.indexOf('C2C') === 0) {
        return state.currentConversationID.substring(3)
      } else if (state.currentConversationID.indexOf('GROUP') === 0) {
        return state.currentConversationID.substring(5)
      }
    },
    // 当前聊天对象的昵称
    toName: state => {
      if (state.currentConversation.type === 'C2C') {
        return state.currentConversation.userProfile.userID
      } else if (state.currentConversation.type === 'GROUP') {
        return state.currentConversation.groupProfile.name
      }
    },
    // 当前聊天对话的Type
    currentConversationType: state => {
      if (state.currentConversationID.indexOf('C2C') === 0) {
        return 'C2C'
      }
      if (state.currentConversationID.indexOf('GROUP') === 0) {
        return 'GROUP'
      }
      return ''
    },
    currentConversation: state => state.currentConversation,
    currentMessageList: state => state.currentMessageList,
    totalUnreadCount: state => {
      const result = state.allConversation.reduce((count, { unreadCount }) => count + unreadCount, 0)
      if (result === 0) {
        wx.removeTabBarBadge({ index: 0 })
      } else {
        wx.setTabBarBadge({ index: 0, text: result > 99 ? '99+' : String(result) })
      }
      return result
    }
  },
  mutations: {
  	/*签卡*/
  	setsignedVo(state,obj){
  		state.signedVo = obj;
  	},
  	/*置顶弹幕消息*/
  	setTopmesg(state,msg){
			state.Topmesg = msg
		},
    updateLiveTipsGoods(state, data) {
      state.liveTipsGoods = JSON.parse(data)
    },
    /**
     * 更新直播商品列表
     */
    updateLiveGoods(state, data) {
      state.isUpdateLiveGoodsList = data
    },
    offConnectLive(state, data) {
      state.isOffConnectLive = data
    },
    openConnectLive(state, data) {
      state.isOpenConnectLive = data
    },
    /**
     * 更新点赞数
     * @return {[type]}
     */
    updateAddLiveLive(state) {
      state.likeNum = ++state.likeNum
    },
    /**
     * 更新提问
     */
    updateComment(state, status) {
      state.updateComment = status
    },
    /**
     * 增加1个用户观看人数
     */
    updateAddUserLive(state) {
      state.userLiveNumber++
    },
    /**
     * 设置用户观看人数
     */
    setUserLive(state, number) {
      state.userLiveNumber = number
    },
    /**
     * 更新全体禁言
     */
    updateAllbannedSpeak(state, allbannedSpeak) {
      state.allbannedSpeak = allbannedSpeak
    },
    /**
     * 更新详情ppt列表
     */
    updatePPT(state) {
      state.updatePPTList = 1
      setTimeout(() => {
        state.updatePPTList = 0
      }, 1000)
    },
    setupdatepptlocation(state, status) {
      state.updatepptlocation = status
    },
    setpptList(state, list) {
      state.pptList = list
    },
    setIsLogin(state, status) {
      state.isLogin = status
    },
    setIsLoginCallback(state, status) {
      state.isLoginCallback = status
    },
    unlockpptList(state, value) {
      if (state.pptList && state.pptList.length && state.pptList[value]) {
        wx.$bus.$set(state.pptList[parseInt(value)], 'status', 1)
        state.pptindex = parseInt(value)
        state.updatepptlocation = true
      }
    },
    updatepptindex(state, index) {
      state.pptindex = index
    },
    loginCallback(state, status) {
      state.updateLogin = status
    },
    setColseLive(state, status) {
      state.closelive = status
    },
    getIsExam(state, liveId) {
      let url = '/exam/get/videoLive/' + liveId
      fly.get(url).then(res => {
        if (res.data) {
          state.isExam = res.data.isExam
          state.isOpenExam = res.data.isOpenExam
          return false
        }
      })
    },
    /**
     * 获取群成员的资料
     */
    updateGroupMemberProfile(state, liveId) {
      setTimeout(() => {
        let promise = wx.$app.getGroupMemberProfile({
          groupID: liveId,
          userIDList: [wx.getStorageSync('mxhUserInfo').openid], // 请注意：即使只拉取一个群成员的资料，也需要用数组类型，例如：userIDList: ['user1']
          memberCustomFieldFilter: ['group_member_custom'], // 筛选群成员自定义字段：group_member_custom
        });
        promise.then(function(imResponse) {
          state.groupMemberProfile = imResponse.data.memberList
        }).catch(function(imError) {
          console.warn('getGroupMemberProfile error:', imError);
        });
      }, 5000)
    },
    // 历史头插消息列表
    unshiftMessageList(state, messageList) {
      let list = [...messageList]
      for (let i = 0; i < list.length; i++) {
        let message = list[i]
        list[i].virtualDom = decodeElement(message)
        let date = new Date(message.time * 1000)
        list[i].newtime = formatTime(date)
      }
      state.currentMessageList = [...list, ...state.currentMessageList]
    },
    // 消息列表插入通知
    pushMessageList(state, messageList) {
      let list = [...messageList]
      for (let i = 0; i < list.length; i++) {
        let message = list[i]
        list[i].virtualDom = decodeElement(message)
        let date = new Date(message.time * 1000)
        list[i].newtime = formatTime(date)
      }
      state.currentMessageList = [...state.currentMessageList, ...list]
    },
    // 收到
    receiveMessage(state, messageList) {
      let list = [...messageList]
      for (let i = 0; i < list.length; i++) {
        let message = list[i]
        list[i].virtualDom = decodeElement(message)
        let date = new Date(message.time * 1000)
        list[i].newtime = formatTime(date)
      }
      state.currentMessageList = [...state.currentMessageList, ...list]
    },
    sendMessage(state, message) {
      message.virtualDom = decodeElement(message)
      let date = new Date(message.time * 1000)
      message.newtime = formatTime(date)
      state.currentMessageList.push(message)
      setTimeout(() => {
        wx.pageScrollTo({
          scrollTop: 99999
        })
      }, 800)
    },
    // 更新当前的会话
    updateCurrentConversation(state, conversation) {
      state.currentConversation = conversation
      state.currentConversationID = conversation.conversationID
    },
    // 更新当前所有会话列表
    updateAllConversation(state, list) {
      for (let i = 0; i < list.length; i++) {
        if (list[i].lastMessage && (typeof list[i].lastMessage.lastTime === 'number')) {
          let date = new Date(list[i].lastMessage.lastTime * 1000)
          list[i].lastMessage._lastTime = formatTime(date)
        }
      }
      state.allConversation = list
    },
    // 重置当前会话
    resetCurrentConversation(state) {
      state.currentConversationID = '' // 当前聊天对话ID
      state.currentConversation = {} // 当前聊天对话信息
      state.currentMessageList = [] // 当前聊天消息列表
      state.nextReqMessageID = '' // 下一条消息标志
      state.isCompleted = false // 当前会话消息是否已经请求完毕
      state.isLoading = false // 是否正在请求
    },
    resetAllConversation(state) {
      state.allConversation = []
    },
    removeMessage(state, message) {
      state.currentMessageList.splice(state.currentMessageList.findIndex(item => item.ID === message.ID), 1)
    },
    changeMessageStatus(state, index) {
      state.currentMessageList[index].status = 'fail'
    }
  },
  actions: {
    // 消息事件
    onMessageEvent(context, event) {
      if (event.name === 'onMessageReceived') {
        let id = context.state.currentConversationID
        if (!id) {
          return
        }
        let list = []
        event.data.forEach(item => {
          if (item.conversationID === id) {
            list.push(item)
          }
        })
        context.commit('receiveMessage', list)
      }
    },
    // 获取消息列表
    getMessageList(context) {
      const { currentConversationID, nextReqMessageID } = context.state
      // 判断是否拉完了
      if (!context.state.isCompleted) {
        if (!context.state.isLoading) {
          context.state.isLoading = true
          wx.$app.getMessageList({ conversationID: currentConversationID, nextReqMessageID: nextReqMessageID, count: 15 }).then(res => {
            context.state.nextReqMessageID = res.data.nextReqMessageID
            // context.commit('unshiftMessageList', res.data.messageList)
            if (res.data.isCompleted) {
              context.state.isCompleted = true
            }
            context.state.isLoading = false
          }).catch(err => {
            console.log(err)
          })
        } else {
          wx.showToast({
            title: '你拉的太快了',
            icon: 'none',
            duration: 500
          })
        }
      } else {
        wx.showToast({
          title: '没有更多啦',
          icon: 'none',
          duration: 1500
        })
      }
    },
    checkoutConversation(context, conversationID) {

      // context.commit('resetCurrentConversation')
      wx.$app.setMessageRead({ conversationID })
      return wx.$app.getConversationProfile(conversationID)
        .then(({ data: { conversation } }) => {
          context.commit('updateCurrentConversation', conversation)
          // context.dispatch('getMessageList')
          let name = ''
          switch (conversation.type) {
            case TIM.TYPES.CONV_C2C:
              name = conversation.userProfile.nick || conversation.userProfile.userID
              break
            case TIM.TYPES.CONV_GROUP:
              name = conversation.groupProfile.name || conversation.groupProfile.groupID
              break
            default:
              name = '系统通知'
          }
          // wx.navigateTo({ url: `../chat/main?toAccount=${name}&type=${conversation.type}` })
          return Promise.resolve()
        })
    },

  }
}

export default conversationModules
