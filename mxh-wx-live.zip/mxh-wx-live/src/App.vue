<script>
export default {
	onLaunch(){
    this.getUpdateManager()
	 	console.log(1)
	},
  created() {
  	console.log(1)
  },
  methods: {
    getUpdateManager(){
      const updateManager = wx.getUpdateManager()
      updateManager.onCheckForUpdate(function (res) {
        // 请求完新版本信息的回调
        console.log(res.hasUpdate,'请求完新版本信息的回调')
      })
      updateManager.onUpdateReady(function () {
        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
        updateManager.applyUpdate()
        console.log(res.hasUpdate,'新的版本已经下载好，调用 applyUpdate 应用新版本并重启')
      })
      updateManager.onUpdateFailed(function () {
        // 新的版本下载失败
        console.log(res.hasUpdate,'新的版本下载失败')
      })
    }
    
  }
}

</script>
<style lang="less">
@keyframes slideTop {
    0% {
        transform: translate3d(0, 100%, 0)
    }

    100% {
        transform: translate3d(0, 0, 0)
    }
}

@keyframes slideBottom {
    0% {
        transform: translate3d(0, 100%, 0)
    }

    100% {
        transform: translate3d(0, 0, 0)
    }
}
</style>
