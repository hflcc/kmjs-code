
//export let baseURL = 'http://120.78.185.151:8004/api'
// export let baseURL = 'http://gateway.mxh.ink/api'
// export let baseURL = 'https://gatewaymxh.kmjs999.com/api'
// export let shopH5web = 'https://h5.merrymall.com'
export let baseURL = 'https://api.mxh.ink/api'
//export let baseURL = 'http://47.115.23.38:8004/api'
