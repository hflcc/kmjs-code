var Fly = require("flyio/dist/npm/wx")
const fly = new Fly;
const newFly = new Fly;
import wxp from 'minapp-api-promise'
import {
  baseURL
} from './domain.js'
//配置请求基地址

fly.config.baseURL = baseURL
var ulrs = ''
var body = ''
// //添加请求拦截器
fly.interceptors.request.use((config) => {
  //给所有请求添加自定义header
  // wx.showLoading({
  //   title: '加载中',
  // })
  // let token = wxp.getStorageSync("token");


  // 解决重复快速点击问题
  if (ulrs.indexOf(config.url) > -1) {
    if (config.body && body.indexOf(JSON.stringify(config.body)) > -1) { // 有参数时候
      return Promise.reject('请求重复')
    }
    if (!config.body) { //没有参数时候
      return Promise.reject('请求重复')
    }
  }
  if (config.body) {
    body += JSON.stringify(config.body)
  }
  ulrs += config.url



  let token = wxp.getStorageSync("token");
  config.headers["authorization"] = token;
  config.headers["channel"] = 2;
  config.headers['Content-Type'] = 'application/json'
  return config;
})


//添加响应拦截器，响应拦截器会在then/catch处理之前执行
fly.interceptors.response.use(
  async function(response, promise) {
      return new Promise((resolve, reject) => {
        if (response.data.code == 1100 && wxp.getStorageSync("mxhUserInfo")) {
          let openid = null
          let headImgurl = null
          let nickName = null
          bindGetUserInfo()

          function bindGetUserInfo() {
            var userInfo = wxp.getStorageSync("mxhUserInfo")
            openid = userInfo.openid
            headImgurl = userInfo.headImgurl
            nickName = userInfo.nickName
            let url = '/user/weChatRegister'
            let data = {
              identityType: 2,
              openid: openid,
              headImgurl: headImgurl,
              nickName: nickName,
            }
            wx.$http.post(url, data).then((res) => {
              if (res.code == 2008) {
                login()
              } else {
                wx.setStorageSync('token', res.data.token)
                wx.setStorageSync('mxhUserInfo', res.data.mxhUserInfo)
                wx.store.commit("setIsLogin", false);
                response.headers['authorization'] = res.data.token
                wx.store.commit('loginCallback', true)
              }
            })
          }

          function login() {
            let url = '/user/weChatLogin'
            let data = {
              identityType: 0,
              openid: openid,
              headImgurl: headImgurl,
              nickName: nickName,
            }
            wx.$http.post(url, data).then((res) => {
              if (res.code == 0) {
                wx.setStorageSync('token', res.data.token)
                wx.setStorageSync('mxhUserInfo', res.data.mxhUserInfo)
                wx.store.commit("setIsLogin", false);
                response.headers['authorization'] = res.data.token
                wx.store.commit('loginCallback', true)
              }
            })
          }


        } else if (response.data.code == 1100 && !wxp.getStorageSync("userInfo")) {
          wx.store.commit("setIsLogin", true);
        }
        ulrs = ulrs.replace(response.request.url, '')
        if (response.request.body) {
          body = ulrs.replace(JSON.stringify(response.request.body), '')
        }
        resolve(response.data)
      })
    },
    (err, promise) => {
      //发生网络错误后会走到这里
      console.log(err)
    }
)

export default fly
