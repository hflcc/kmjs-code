<template>
  <section>
    <swiper class="banner" :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval" :duration="duration"
      indicator-color="rgba(255,255,255,0.5)" indicator-active-color="#d3a358" v-if="indexList.mxhBannerList && indexList.mxhBannerList.length">
      <block v-for="(item,index) in indexList.mxhBannerList" :key="index">
        <swiper-item @click="goBanner(item)" style="border-radius:12rpx;">
          <img :src="item.url">
        </swiper-item>
      </block>
    </swiper>
    <div class="channel" v-if="indexList.companyUserInfoList.length || indexList.attentionUserInfoList.length">
      <div class="nav">
        <div style="width:50%;float:left">
          <div class="item-a active" @click="clickType(1)">企业频道</div>
          <div class="more" @click="channelMore(1)" style="margin-right:10px">更多</div>
        </div>
        <div style="width:50%;float:left;padding-left:10rpx;box-sizing:border-box;">
          <div class="item-a active" @click="clickType(2)">个人频道</div>
          <div class="more" @click="channelMore(2)">更多</div>
        </div>
      </div>
      <div class="company-content2 ml30">
        <div class="company-content">
          <div class="company-item" v-for="(item,index2) in indexList.companyUserInfoList" :key="index2" @click="goEnterpriseHome(item)">
            <div class="label-live" v-if="item.liveCount != null && item.liveCount != '0' &&  item.liveCount != 0 ">·
              直播中</div>
            <div class="company-logo-content" :class="index2 == 0 ? 'item-1': index2 == 1 ? 'item-2' : 'item-3'"><img
                :src="item.headImgurl" alt="" class="company-logo"></div>
            <div style="display:inline-block;width:170rpx;vertical-align: middle;">
              <div class="company-name">{{item.nickName}}</div>
              <div class="company-text" v-html="item.profile || ''"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="company-content2">
        <div class="company-content">
          <div class="company-item" v-for="(item,index2) in indexList.attentionUserInfoList" :key="index2" @click="goPersonalHome(item)">
            <div class="label-live" v-if="item.liveCount != null && item.liveCount != '0' && item.liveCount != 0 ">·
              直播中</div>
            <div class="company-logo-content" :class="index2 == 0 ? 'item-1': index2 == 1 ? 'item-2' : 'item-3'"><img
                :src="item.headImgurl" alt="" class="company-logo"></div>
            <div style="display:inline-block;width:170rpx;vertical-align: middle;">
              <div class="company-name">{{item.nickName}}</div>
              <div class="company-text" v-html="item.profile || ''"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="banner-app" @click="download">
      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/channel%402x.png">
    </div>
    <div class="recommend-content" v-if="list && list.length">
      <div class="recommend-title">精品课程 <div class="more" @click="boutiqueMore">更多</div>
      </div>
      <div class="recommend-content2">
        <div class="item" v-for="(item,index) in list" :key="index" @click="goDetails(item,index)">
          <div class="product-img"><img :src="item.url" alt="" mode="widthFix"></div>
          <div class="product-text">{{item.title}}</div>
          <div class="product-label">{{item.corporateType == 1 ? '企业频道' : '个人频道'}}</div>
          <div class="product-info" v-html="item.text"></div>
        </div>
      </div>
    </div>

    <div class="recommend-content" v-if="topicList && topicList.length">
      <div class="recommend-title">课程推荐</div>
      <div v-for="(topicitem,topicIndex) in topicList" :key="topicIndex" @click="recommendMore(topicitem,0)">
        <div class="special">
          <div class="special-img">
            <img :src="topicitem.url">
          </div>
          <div class="special-title">{{topicitem.title}}</div>
          <div class="item-list-content-2">
            <span class="type" v-if="topicitem.mxhLiveVideoPlayType && topicitem.mxhLiveVideoPlayType.type == 1">加密</span>
            <span class="type" v-else>免费</span>
            <span class="number">· {{topicitem.viewTotal}}人</span>
            <span class="time" v-if="topicitem.type ==0 || topicitem.type ==2">{{topicitem.startTime}}</span>
            <span class="time" v-if="topicitem.type ==1">{{topicitem.label}}</span>
          </div>
        </div>

        <div class="item-list" v-for="(item,index) in topicitem.liveVideoList" :key="index" @click.stop="recommendMore(topicitem,index)">
          <div class="item-list-l-content">
            <div class="item-list-l">
              <div class="item-list-l-title">
                <span class="item-list-l-label" v-if="item.type ==0 && item.status == 0">预告</span>
                <span class="item-list-l-label" v-if="item.type ==1">录播</span>
                <span class="item-list-l-label" v-if="(item.type ==2 && item.status==0)">直播课</span>
                <span class="item-list-l-label" v-if="(item.type ==2 && item.status==1) || (item.type ==0 && item.status==1) ">直播中</span>
                <span class="item-list-l-label" v-if="(item.type ==0 && item.status == 2) || (item.type ==2 && item.status == 2) ">直播课</span>
                {{item.title}}</div>
              <div class="item-list-text" v-html="item.text"></div>
            </div>
            <div class="item-list-r">
              <img :src="item.url" mode="widthFix">
            </div>
          </div>
          <div class="item-list-content-2">
            <span class="type" v-if="item.mxhLiveVideoPlayType && item.mxhLiveVideoPlayType.type == 1">加密</span>
            <span class="type" v-else>免费</span>
            <span class="number">· {{item.viewTotal}}人</span>
            <span class="time" v-if="item.type ==0 || item.type ==2">{{item.startTime}}</span>
            <span class="time" v-if="item.type ==1">{{item.label}}</span>
          </div>
        </div>
      </div>
    </div>
    <auth type="index"></auth>
  </section>
</template>
<script>
  import auth from '@/components/auth'
  export default {
    data() {
      return {
        indexList: {
          mxhBannerList: [],
          notReadAmount: 0,
          recommendVideoList: [],
          teaserVideoList: [],
          companyUserInfoList: [],
          attentionUserInfoList: []
        },
        bannerList: [],
        indicatorDots: true,
        vertical: false,
        autoplay: false,
        interval: 2000,
        duration: 500,
        form: {
          page: 1,
          pageSize: 16,
        },
        list: [],
        isViewAll: false,
        topicList: [],
        corporateType: 1, //企业身份 1企业 2个人
      }
    },
    onLoad() {
      // this.form = {
      //   page: 1,
      //   pageSize: 4,
      // }
      // this.list = []
      // this.topicList = []
      // this.getIndex()
      // this.getliveVideolist()
      // this.getTopic()
    },
    async onShow() {
      this.form = {
        page: 1,
        pageSize: 4,
      }
      this.indexList = []
      this.list = []
      this.topicList = []
      await this.getIndex()
      await this.getliveVideolist()
      await this.getTopic()
    },
    components: {
      auth,
    },
    // 上拉加载
    onReachBottom() {
      this.form.page++
      this.getTopic()
    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function(res) {
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit("setIsLogin", true);
        return false
      }
      this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
      let arr = [
        'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_1.png',
        'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_1.png',
        'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_2.png',
        'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_3.png',
        'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_4.png',
      ]
      // 来自页面内转发按钮
      return {
        title: this.mxhUserInfo.nickName + '邀请您免费学习美学会精选好课',
        path: 'pages/home/main',
        imageUrl: arr[Math.ceil(Math.random() * 4)],
        success: function(res) {
          // 转发成功之后的回调
          if (res.errMsg == 'shareAppMessage:ok') {}
        },
        fail: function() {
          // 转发失败之后的回调
          if (res.errMsg == 'shareAppMessage:fail cancel') {
            // 用户取消转发
          } else if (res.errMsg == 'shareAppMessage:fail') {
            // 转发失败，其中 detail message 为详细失败信息
          }
        },
        complete: function() {

          // 转发结束之后的回调（转发成不成功都会执行）
        }
      }
    },
    methods: {
      channelMore(corporateType) {
        if (corporateType == 1) {
          wx.navigateTo({
            url: '/pages/subpacks/home/corporateChannelList/main'
          })
        }
        if (corporateType == 2) {
          wx.navigateTo({
            url: '/pages/subpacks/home/personalChannelList/main'
          })
        }
      },
      clickCourse(item, index) {
        wx.navigateTo({
          url: '/pages/subpacks/course/courseVideo/main?liveId=' + item.id + '&index=' + index
        })
      },
      boutiqueMore() {
        wx.navigateTo({
          url: '/pages/subpacks/home/boutiqueList/main'
        })
      },
      recommendMore(data, index) {
        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        wx.navigateTo({
          url: '/pages/subpacks/course/courseVideo/main?index=' + index + '&topicId=' + data.id
        })
      },
      clickType(type) {
        this.corporateType = type
      },
      async getTopic() {
        let url = '/home/get/topic/' + this.form.page + '/' + this.form.pageSize
        await this.$http.get(url).then(res => {
          this.topicList = this.topicList.concat(res.data)
        })
      },
      attention(item) {
        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
        let url = '/userConcern/saveMxhUserConcern'
        let data = {
          concernUserId: item.id,
        }
        this.$http.post(url, data).then(res => {
          if (item.isAttention == 1) {
            item.isAttention = 0
            let data2 = JSON.parse(JSON.stringify(this.indexList.companyUserInfoList))
            this.$set(this.indexList, 'companyUserInfoList', data2)
          } else {
            item.isAttention = 1
            let data2 = JSON.parse(JSON.stringify(this.indexList.companyUserInfoList))
            this.$set(this.indexList, 'companyUserInfoList', data2)
          }
        })
      },
      clickViewAll() {
        this.isViewAll = !this.isViewAll
      },
      goEnterpriseHome(item) {
        wx.navigateTo({
          url: '/pages/enterpriseHome/main?userId=' + item.id
        })
      },
      goPersonalHome(item) {
        wx.navigateTo({
          url: '/pages/personalHome/main?userId=' + item.id
        })
      },
      download() {
        wx.navigateTo({
          url: '/pages/subpacks/home/download/main'
        })
      },
      goBanner(item) {
        if (item.type == 0) {
          wx.setStorageSync('url', item.itemText)
          wx.navigateTo({
            url: '/pages/webView/main'
          })
        }
        if (item.type == 1) {
          item.id = item.itemText
          this.goDetails(item)
        }
        if (item.type == 2) {

        }
      },
      goDetails(item) {
        // wx.navigateTo({
        //   url: '/pages/details/main?liveId=1793'
        // })


        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        if (item.liveType == 1) {
          wx.navigateTo({
            url: '/pages/details/main?liveId=' + item.id
          })
        } else {
          wx.navigateTo({
            url: '/pages/verticalLive/main?liveId=' + item.id
          })
        }
      },
      // goDetails(item){
      //   if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
      //     this.$store.commit("setIsLogin", true);
      //     return false
      //   }
      //   wx.navigateTo({
      //       url: '/pages/details/main?liveId=' + item.id
      //   })

      // },
      /**
       * 获取首页信息
       */
      async getIndex() {
        let url = '/home/index'
        await this.$http.get(url).then(res => {
          if (res.data.teaserVideoList && res.data.teaserVideoList.length) {
            res.data.teaserVideoList.forEach((item, key) => {
              //结束时间
              var startTime = new Date(item.startTime.replace(/-/g, '/')).getTime();
              //当前时间
              var nowDate = new Date().getTime();
              //相差的总秒数
              item.broadcast = (startTime - nowDate)

              item.startTime = item.startTime.substr(0, 11)
            })
          }
          res.data.companyUserInfoList.splice(3)
          res.data.attentionUserInfoList.splice(3)
          this.$set(this, 'indexList', res.data)
          // this.indexList = res.data
        })
      },
      /**
       * 获取banner信息
       */
      async getliveVideolist() {
        let url = '/liveVideo/list/1/4'
        let data = {
          type: '-1',
          recommend: '1',
        }
        await this.$http.post(url, data).then(res => {
          this.list = this.list.concat(res.data)
        })
      },

      changeIndicatorDots() {
        this.setData({
          indicatorDots: !this.data.indicatorDots
        })
      },

      changeAutoplay() {
        this.setData({
          autoplay: !this.data.autoplay
        })
      },

      intervalChange(e) {
        this.setData({
          interval: e.detail.value
        })
      },

      durationChange(e) {
        this.setData({
          duration: e.detail.value
        })
      }
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: #f8f8f8;
    overflow: scroll;
    width: 100%;
    overflow-x: hidden;
  }

  .banner {
    height: 345px;
  }

  swiper {
    width: 690px;
    border-radius: 12px;
    margin: 0 auto;
    margin-top: 20px;
    background: #fff;

    img {
      width: 100%;
      height: 345px;
    }
  }

  .channel {
    margin-top: 60px;
    overflow: hidden;

    .nav {
      padding: 0 30px;
      padding-bottom: 25px;
      overflow: hidden;

      .item-a {
        font-size: 28px;
        font-family: PingFang SC;
        font-weight: 500;
        color: rgba(102, 102, 102, 1);
        display: inline-block;
        margin-right: 45px;
      }

      .item-a.active {
        position: relative;
        font-size: 32px;
        font-weight: bold;
        color: rgba(34, 34, 34, 1);

        &:before {
          position: absolute;
          bottom: -5px;
          left: 0;
          display: inline-block;
          width: 100%;
          height: 6px;
          background: rgba(211, 163, 88, 1);
          border-radius: 4px;
          content: '';
        }
      }

      .more {
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 10px;
      }
    }

    .ml30 {
      margin-left: 30px;
    }
  }

  .company-content2 {
    margin: 0;
    width: 360px;
    float: left;
  }

  .company-content2::-webkit-scrollbar {
    display: none;
  }

  .company-content {
    width: 330px;
    margin-top: 40px;
    display: inline-block;
    margin: 0;

    swiper-item {
      padding-top: 40px;
    }

    .company-item {
      width: 330px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      display: block;
      position: relative;
      margin-right: 30px;
      margin-bottom: 20px;
      white-space: normal;
      height: 170px;
      display: inline-block;
      position: relative;
      overflow: hidden;

      .label-live {
        text-align: center;
        position: absolute;
        right: 0;
        top: 0;
        width: 90px;
        line-height: 30px;
        font-size: 20px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        background: url(https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/label-live.png);
        background-size: 100% 100%;
      }

      .company-logo-content {
        display: inline-block;
        margin-left: 12px;
        overflow: hidden;
        vertical-align: middle;
      }

      .company-logo-content.item-1 {
        width: 107px;
        height: 104px;
        background: url(https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/crown-1.png);
        background-size: 100% 100%;
      }

      .company-logo-content.item-2 {
        width: 107px;
        height: 104px;
        background: url(https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/crown-3.png);
        background-size: 100% 100%;
      }

      .company-logo-content.item-3 {
        width: 107px;
        height: 104px;
        background: url(https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/crown-2.png);
        background-size: 100% 100%;
      }

      .company-attention {
        position: absolute;
        width: 66px;
        height: 66px;
        z-index: 10;
        left: 0;
        top: 0;

      }

      .company-logo {
        width: 80px;
        height: 80px;
        z-index: 100;
        border-radius: 50%;
        background: #fff;
        margin-top: 19px;
        margin-left: 22px;
      }

      .company-name {
        font-size: 28px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        margin-top: 5px;
        text-align: left;
        white-space: normal;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
        padding: 0 20px;
        padding-top: 30px;
      }

      .company-text {
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        line-height: 55px;
        padding-left: 20px;
        white-space: normal;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
        height: 55px;
      }

      .center {
        text-align: center;
      }

      .attention {
        width: 128px;
        line-height: 48px;
        background: rgba(255, 255, 255, 1);
        border: 1px solid rgba(242, 242, 242, 1);
        border-radius: 6px;
        text-align: center;
        font-size: 26px;
        font-weight: 500;
        color: rgba(204, 204, 204, 1);
        margin: 0 auto;
        margin-top: 20px;
        margin-bottom: 15px;
      }

      .attention2 {
        width: 128px;
        line-height: 48px;
        background: rgba(211, 163, 88, 1);
        border-radius: 6px;
        text-align: center;
        font-size: 26px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        margin: 0 auto;
        margin-top: 20px;
        margin-bottom: 15px;
      }
    }
  }


  .banner-app {
    width: 690px;
    height: 120px;
    margin: 0 auto;
    margin-top: 15px;

    img {
      width: 690px;
      height: 120px;
    }
  }


  .recommend-content {
    padding: 0 30px;
    overflow: hidden;

    .recommend-title {
      font-size: 34px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      padding: 40px 0 20px 0;

      .more {
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 10px;
      }
    }
  }

  .item:nth-child(2n-1) {
    margin-right: 20px;
  }

  .item {
    width: 335px;
    float: left;
    margin-bottom: 20px;
    padding-bottom: 20px;
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;

    .product-img {
      position: relative;
      height: 200px;
      overflow: hidden;

      img {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
      }
    }

    .product-text {
      font-size: 30px;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
      line-height: 60px;
      padding: 0 10px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      overflow: hidden;
      height: 60px;
    }

    .product-label {
      width: 90px;
      height: 30px;
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(211, 163, 88, 1);
      border-radius: 4px;
      font-size: 20px;
      font-weight: 500;
      color: rgba(211, 163, 88, 1);
      margin-left: 10px;
      margin-bottom: 10px;
      text-align: center;
    }

    .product-info {
      padding: 0 10px;
      font-size: 22px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      line-height: 30px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }


  .item-list {
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;
    padding: 0 30px;
    width: 690px;
    box-sizing: border-box;
    margin: 0 auto;
    margin-bottom: 30px;

    .item-list-l-content {
      overflow: hidden;
      border-bottom: 2px solid rgba(246, 246, 246, 1);
      padding-bottom: 40px;
      padding-top: 40px;

      .item-list-l {
        float: left;
        width: 408px;
        margin-right: 30px;
      }

      .item-list-r {
        float: left;

        img {
          width: 190px;
          height: 114px;
          border-radius: 8px;
        }
      }
    }

    .item-list-content-2 {
      padding: 20px 0 30px 0;

      .type {
        font-size: 24px;
        font-weight: 500;
        color: #D3A358;
        margin-right: 40px;
      }

      .number {
        font-size: 24px;
        font-weight: 500;
        color: rgba(51, 51, 51, 1);
      }

      .time {
        padding: 0 15px;
        line-height: 35px;
        background: rgba(243, 244, 245, 1);
        border-radius: 17px;
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 7px;
      }
    }
  }

  .special {
    background: #fff;
    margin-bottom: 20px;
    overflow: hidden;

    .special-img {
      width: 630px;
      height: 378px;
      border-radius: 8px;
      margin: 0 auto;
      margin-top: 30px;

      img {
        width: 630px;
        height: 378px;
        border-radius: 8px;
      }
    }

    .special-title {
      padding-left: 30px;
      font-size: 32px;
      font-weight: 500;
      color: rgba(34, 34, 34, 1);
      padding: 25px 30px;
    }

    .item-list-content-2 {
      padding: 25px 0 25px 30px;
      border-top: 2px solid rgba(246, 246, 246, 1);
      line-height: 30px;

      .type {
        font-size: 24px;
        font-weight: 500;
        color: #D3A358;
        margin-right: 40px;
      }

      .number {
        font-size: 24px;
        font-weight: 500;
        color: rgba(51, 51, 51, 1);
      }

      .time {
        padding: 0 15px;
        line-height: 35px;
        background: rgba(243, 244, 245, 1);
        border-radius: 17px;
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 7px;
      }
    }
  }

  // .recommend-content {
  //   padding: 0 30px;

  //   .tutor {
  //     position: relative;
  //     padding: 30px 0;
  //     padding-bottom: 0;
  //     background: #fff;
  //     width: 690px;
  //     border-radius: 10px;
  //     margin: 0;
  //     height: 270px;
  //     overflow: hidden;
  //     .figure-item-content {
  //       padding: 0 30px;

  //       .attention-head {
  //         position: relative;
  //         width: 100px;
  //         height: 100px;
  //         border-radius: 50px;
  //         display: inline-block;
  //         margin-right: 33px;
  //         margin-bottom: 30px;

  //         img {
  //           width: 100px;
  //           height: 100px;
  //           border-radius: 50px;
  //           display: block;
  //         }

  //         .attention {
  //           position: absolute;
  //           right: 0;
  //           bottom: 0;
  //           z-index: 100;
  //           width: 28px;
  //           height: 28px;
  //         }

  //       }

  //       .attention-head:nth-child(5n) {
  //         margin-right: 0;
  //       }
  //     }

  //     .viewAll {
  //       position: absolute;
  //       left: 0;
  //       bottom: 0;
  //       z-index: 100;
  //       width: 690px;
  //       height: 160px;
  //       background: linear-gradient(0deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0.5) 100%);
  //       border-radius: 0px 0px 8px 8px;
  //       text-align: center;
  //       overflow: hidden;

  //       span {
  //         position: absolute;
  //         left: 50%;
  //         bottom: 20px;
  //         z-index: 200;
  //         transform: translate(-50%, 0);
  //         font-size: 26px;
  //         font-weight: 500;
  //         color: #d3a358;
  //         opacity: 0.9;
  //       }
  //     }
  //   }

  //   .tutorAuto {
  //     height: auto !important;
  //   }

  //   .livePreview::-webkit-scrollbar {
  //     display: none;
  //   }

  //   .livePreview {
  //     height: 460px;
  //     background: #F0F2F5;
  //     margin: 0;
  //     width: 100%;
  //     overflow: hidden;
  //     overflow-x: scroll;
  //     -webkit-overflow-scrolling: touch;
  //     white-space: nowrap;
  //     padding: 0.125rem 0.1rem;
  //     transition: left 2s;
  //     -moz-transition: left 2s;
  //     -webkit-transition: left 2s;
  //     -o-transition: left 2s;

  //     .swiperItem2 {
  //       margin-right: 20px;
  //     }

  //     .swiperItem,
  //     .swiperItem2 {
  //       width: 300px;
  //       background: #fff;
  //       height: 460px;
  //       position: relative;
  //       display: inline-block;
  //       vertical-align: top;

  //       .label {
  //         position: absolute;
  //         left: 50%;
  //         top: 126px;
  //         transform: translate(-50%, 0);
  //         z-index: 10;
  //         padding: 4px 20px;
  //         line-height: 35px;
  //         background: rgba(0, 0, 0, 0.5);
  //         opacity: 0.5;
  //         border-radius: 17px;
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: rgba(255, 255, 255, 1);
  //         text-align: center;
  //         box-sizing: border-box;
  //         width: 180px;
  //       }

  //       img {
  //         width: 100%;
  //         height: 180px;
  //         background: rgba(215, 215, 215, 1);
  //         border-radius: 8px 8px 0px 0px;
  //       }

  //       .item-list-l-title {
  //         font-size: 32px;
  //         font-weight: 500;
  //         color: rgba(34, 34, 34, 1);
  //         padding: 0 10px;
  //         margin-bottom: 10px;
  //         text-align: justify;
  //         white-space: normal;
  //         text-overflow: -o-ellipsis-lastline;
  //         overflow: hidden;
  //         text-overflow: ellipsis;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 2;
  //         line-clamp: 2;
  //         -webkit-box-orient: vertical;
  //         height: 85px;
  //         line-height: 40px;
  //       }

  //       .item-list-text {
  //         padding: 0 15px;
  //         margin-bottom: 20px;
  //         text-overflow: -o-ellipsis-lastline;
  //         overflow: hidden;
  //         text-overflow: ellipsis;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 3;
  //         line-clamp: 3;
  //         -webkit-box-orient: vertical;
  //         height: 100px;
  //         line-height: 35px;
  //         width: 270px;
  //         white-space: normal;

  //       }

  //       .item-list-button {
  //         font-size: 28px;
  //         font-weight: 500;
  //         color: #d3a358;
  //         line-height: 44px;
  //         padding: 0 10px;
  //         text-align: center;
  //         margin-bottom: 20px;
  //       }

  //       .apply {
  //         font-size: 28px;
  //         font-weight: 500;
  //         color: rgba(204, 204, 204, 1);
  //       }
  //     }

  //   }

  // .item-list-l-title {
  //   font-size: 32px;
  //   font-weight: 500;
  //   color: rgba(34, 34, 34, 1);
  //   margin-bottom: 20px;
  //   text-align: justify;
  //   white-space: normal;
  //   text-overflow: -o-ellipsis-lastline;
  //   overflow: hidden;
  //   text-overflow: ellipsis;
  //   display: -webkit-box;
  //   -webkit-line-clamp: 2;
  //   line-clamp: 2;
  //   -webkit-box-orient: vertical;
  //   height: 85px;
  //   line-height: 40px;

  //   .item-list-l-label {
  //     vertical-align: middle;
  //   }

  //   span {
  //     line-height: 35px;
  //     background: rgba(255, 225, 220, 1);
  //     border-radius: 17px;
  //     font-size: 22px;
  //     font-weight: 500;
  //     color: rgba(232, 101, 81, 1);
  //     display: inline-block;
  //     padding: 0 15px 0 20px;
  //     vertical-align: middle;
  //     margin-right: 18px;
  //     margin-top: -10px;
  //   }
  // }

  // .item-list-text {
  //   font-size: 24px;
  //   font-weight: 500;
  //   color: rgba(158, 158, 158, 1);
  //   text-align: justify;
  //   text-overflow: -o-ellipsis-lastline;
  //   overflow: hidden;
  //   text-overflow: ellipsis;
  //   display: -webkit-box;
  //   -webkit-line-clamp: 3;
  //   line-clamp: 3;
  //   -webkit-box-orient: vertical;
  //   height: 100px;
  //   line-height: 35px;
  //   white-space: normal;
  // }

  // .recommend-content {
  //   padding: 0 30px;

  //   .tutor {
  //     position: relative;
  //     padding: 30px 0;
  //     padding-bottom: 0;
  //     background: #fff;
  //     width: 690px;
  //     border-radius: 10px;
  //     margin: 0;
  //     height: 270px;
  //     overflow: hidden;
  //     .figure-item-content {
  //       padding: 0 30px;

  //       .attention-head {
  //         position: relative;
  //         width: 100px;
  //         height: 100px;
  //         border-radius: 50px;
  //         display: inline-block;
  //         margin-right: 33px;
  //         margin-bottom: 30px;

  //         img {
  //           width: 100px;
  //           height: 100px;
  //           border-radius: 50px;
  //           display: block;
  //         }

  //         .attention {
  //           position: absolute;
  //           right: 0;
  //           bottom: 0;
  //           z-index: 100;
  //           width: 28px;
  //           height: 28px;
  //         }

  //       }

  //       .attention-head:nth-child(5n) {
  //         margin-right: 0;
  //       }
  //     }

  //     .viewAll {
  //       position: absolute;
  //       left: 0;
  //       bottom: 0;
  //       z-index: 100;
  //       width: 690px;
  //       height: 160px;
  //       background: linear-gradient(0deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0.5) 100%);
  //       border-radius: 0px 0px 8px 8px;
  //       text-align: center;
  //       overflow: hidden;

  //       span {
  //         position: absolute;
  //         left: 50%;
  //         bottom: 20px;
  //         z-index: 200;
  //         transform: translate(-50%, 0);
  //         font-size: 26px;
  //         font-weight: 500;
  //         color: #d3a358;
  //         opacity: 0.9;
  //       }
  //     }
  //   }

  //   .tutorAuto {
  //     height: auto !important;
  //   }

  //   .livePreview::-webkit-scrollbar {
  //     display: none;
  //   }

  //   .livePreview {
  //     height: 460px;
  //     background: #F0F2F5;
  //     margin: 0;
  //     width: 100%;
  //     overflow: hidden;
  //     overflow-x: scroll;
  //     -webkit-overflow-scrolling: touch;
  //     white-space: nowrap;
  //     padding: 0.125rem 0.1rem;
  //     transition: left 2s;
  //     -moz-transition: left 2s;
  //     -webkit-transition: left 2s;
  //     -o-transition: left 2s;

  //     .swiperItem2 {
  //       margin-right: 20px;
  //     }

  //     .swiperItem,
  //     .swiperItem2 {
  //       width: 300px;
  //       background: #fff;
  //       height: 460px;
  //       position: relative;
  //       display: inline-block;
  //       vertical-align: top;

  //       .label {
  //         position: absolute;
  //         left: 50%;
  //         top: 126px;
  //         transform: translate(-50%, 0);
  //         z-index: 10;
  //         padding: 4px 20px;
  //         line-height: 35px;
  //         background: rgba(0, 0, 0, 0.5);
  //         opacity: 0.5;
  //         border-radius: 17px;
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: rgba(255, 255, 255, 1);
  //         text-align: center;
  //         box-sizing: border-box;
  //         width: 180px;
  //       }

  //       img {
  //         width: 100%;
  //         height: 180px;
  //         background: rgba(215, 215, 215, 1);
  //         border-radius: 8px 8px 0px 0px;
  //       }

  //       .item-list-l-title {
  //         font-size: 32px;
  //         font-weight: 500;
  //         color: rgba(34, 34, 34, 1);
  //         padding: 0 10px;
  //         margin-bottom: 10px;
  //         text-align: justify;
  //         white-space: normal;
  //         text-overflow: -o-ellipsis-lastline;
  //         overflow: hidden;
  //         text-overflow: ellipsis;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 2;
  //         line-clamp: 2;
  //         -webkit-box-orient: vertical;
  //         height: 85px;
  //         line-height: 40px;
  //       }

  //       .item-list-text {
  //         padding: 0 15px;
  //         margin-bottom: 20px;
  //         text-overflow: -o-ellipsis-lastline;
  //         overflow: hidden;
  //         text-overflow: ellipsis;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 3;
  //         line-clamp: 3;
  //         -webkit-box-orient: vertical;
  //         height: 100px;
  //         line-height: 35px;
  //         width: 270px;
  //         white-space: normal;

  //       }

  //       .item-list-button {
  //         font-size: 28px;
  //         font-weight: 500;
  //         color: #d3a358;
  //         line-height: 44px;
  //         padding: 0 10px;
  //         text-align: center;
  //         margin-bottom: 20px;
  //       }

  //       .apply {
  //         font-size: 28px;
  //         font-weight: 500;
  //         color: rgba(204, 204, 204, 1);
  //       }
  //     }

  //   }

  //   .recommend-title {
  //     font-size: 34px;
  //     font-family: PingFang SC;
  //     font-weight: bold;
  //     color: rgba(34, 34, 34, 1);
  //     padding: 60px 0 30px 0;
  //   }

  //   .company-content {
  //     width: 260px;
  //     margin-top: 40px;
  //     display: inline-block;
  //     margin: 0;
  //     background: #F0F2F5;

  //     swiper-item {
  //       padding-top: 40px;
  //     }

  //     .company-item {
  //       width: 250px;
  //       background: rgba(255, 255, 255, 1);
  //       border-radius: 8px;
  //       display: block;
  //       position: relative;
  //       margin-right: 30px;
  //       padding-bottom: 10px;
  //       margin-bottom: 10px;
  //       white-space: normal;
  //       padding-top: 10px;
  //       height: 300px;

  //       .company-attention {
  //         position: absolute;
  //         width: 66px;
  //         height: 66px;
  //         z-index: 10;
  //         left: 0;
  //         top: 0;

  //       }

  //       .company-logo {
  //         width: 80px;
  //         height: 80px;
  //         z-index: 100;
  //         border-radius: 50%;
  //         background: #fff;
  //         margin: 0 auto;
  //         display: block;
  //         margin-top: 20px;
  //         margin-bottom: 5px;
  //       }

  //       .company-name {
  //         font-size: 28px;
  //         font-weight: 500;
  //         color: rgba(34, 34, 34, 1);
  //         margin-top: 5px;
  //         text-align: center;
  //         margin-bottom: 15px;
  //         white-space: normal;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 1;
  //         -webkit-box-orient: vertical;
  //         overflow: hidden;
  //         padding: 0 20px;
  //       }

  //       .company-text {
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: rgba(153, 153, 153, 1);
  //         line-height: 55px;
  //         padding: 0 10px;
  //         white-space: normal;
  //         display: -webkit-box;
  //         -webkit-line-clamp: 1;
  //         -webkit-box-orient: vertical;
  //         overflow: hidden;
  //         height: 55px;
  //       }

  //       .attention {
  //         width: 128px;
  //         line-height: 48px;
  //         background: rgba(255, 255, 255, 1);
  //         border: 1px solid rgba(242, 242, 242, 1);
  //         border-radius: 6px;
  //         text-align: center;
  //         font-size: 26px;
  //         font-weight: 500;
  //         color: rgba(204, 204, 204, 1);
  //         margin: 0 auto;
  //         margin-top: 20px;
  //         margin-bottom: 15px;
  //       }

  //       .attention2 {
  //         width: 128px;
  //         line-height: 48px;
  //         background: #d3a358;
  //         border-radius: 6px;
  //         text-align: center;
  //         font-size: 26px;
  //         font-weight: 500;
  //         color: rgba(255, 255, 255, 1);
  //         margin: 0 auto;
  //         margin-top: 20px;
  //         margin-bottom: 15px;
  //       }
  //     }
  //   }

  //   .company-content2 {
  //     margin: 0;
  //     background: #F0F2F5;
  //     width: 100%;
  //     white-space: nowrap;
  //     overflow-x: scroll;
  //   }

  //   .company-content2::-webkit-scrollbar {
  //     display: none;
  //   }

  //   .item-list {
  //     background: rgba(255, 255, 255, 1);
  //     border-radius: 8px;
  //     padding: 0 30px;
  //     width: 690px;
  //     box-sizing: border-box;
  //     margin: 0 auto;
  //     margin-bottom: 30px;

  //     .item-list-l-content {
  //       overflow: hidden;
  //       border-bottom: 2px solid rgba(246, 246, 246, 1);
  //       padding-bottom: 40px;
  //       padding-top: 40px;

  //       .item-list-l {
  //         float: left;
  //         width: 408px;
  //         margin-right: 30px;
  //       }

  //       .item-list-r {
  //         float: left;

  //         img {
  //           width: 190px;
  //           height: 114px;
  //           border-radius: 8px;
  //         }
  //       }
  //     }

  //     .item-list-content-2 {
  //       padding: 20px 0 30px 0;

  //       .type {
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: #d3a358;
  //         margin-right: 40px;
  //       }

  //       .number {
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: rgba(51, 51, 51, 1);
  //       }

  //       .time {
  //         padding: 0 15px;
  //         line-height: 35px;
  //         background: rgba(243, 244, 245, 1);
  //         border-radius: 17px;
  //         font-size: 24px;
  //         font-weight: 500;
  //         color: rgba(153, 153, 153, 1);
  //         float: right;
  //         margin-top: 7px;
  //       }
  //     }
  //   }
  // }

  // .pd-r {
  //   padding-right: 0px !important;
  // }
</style>
