<template>
  <section>
    <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/shareButton.png" class="shareButton" @click.stop="clickShareButton"
      mode="widthFix" v-if="orientation=='vertical'">
    <div :class="orientation=='horizontal' ? 'viewsNumberActive' : 'viewsNumber'" v-if="!((detailsData.mxhLiveVideo.status == 0 && detailsData.mxhLiveVideo.type == 0))"><img
        src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/number.png">{{userLiveNumber || 0}}人观看</div>
    <canvas id="shareCanvas" canvas-id="shareCanvas" style="width:650px;height:732px;background:rgba(255,255,255,1);border-radius:8px;"></canvas>
    <!-- 禁止播放 -->
    <div v-if="mxhLiveVideoPlayType && mxhLiveVideoPlayType.type == 1">
      <div class="recorded" style="padding:0">
        <div class="beforeLive">
          <img :src="detailsData.mxhLiveVideo.url" class="beforeLive-img">
        </div>
        <swiper :autoplay="false" :current="0" @change="bindchangeswiper" class="swiper-content" style="padding-top:400rpx;">
          <swiper-item style="padding:0">
            <div class="ask-content recorded-ask-content">
              <scroll-view scroll-y="true" :style="'height:'+ scrollViewHeight5" :scroll-top="0">
                <div class="item-1">
                  <div class="ask-title">{{detailsData.mxhLiveVideo.title}} </div>
                  <div class="ask-li">
                    <img :src="detailsData.mxhUserInfo.headImgurl" @click="goPersonalDetails">
                    <div class="ask-character">
                      <div class="ask-text" @click.stop="goPersonalDetails">{{detailsData.mxhUserInfo.nickName}}<img
                          src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png" v-if="detailsData.mxhUserInfo.corporateType"
                          alt="" class="logo"><span class="attention" @click.stop="attention(detailsData.mxhUserInfo)">{{!isAttention ? '+关注' : '已关注'}}</span></div>
                      <div class="ask-name" v-html="detailsData.mxhUserInfo.profile"></div>
                    </div>
                  </div>
                </div>
                <div class="item-2">
                  <div class="ask-course-content" style="margin-bottom:20px">
                    <div class="ask-course-title">课程介绍</div>
                    <text class="ask-course-text" v-html="detailsData.mxhLiveVideo.text"></text>
                  </div>
                </div>
              </scroll-view>
            </div>
          </swiper-item>
        </swiper>
      </div>
      <!-- 购买课程按钮 -->
      <div class="pay-course-button" v-if="mxhLiveVideoPlayType.type == 1">
        <div class="button" @click="clickPasswordShow">解锁课程</div>
      </div>
      <!--  密码弹窗 -->
      <div class="password" v-if="isPasswordShow" @click="clickPasswordShow">
        <div class="content" @click.stop="passwordShowContent">
          <div class="title">
            请填写信息解锁课程
          </div>
          <div class="name" v-for="(item,index) in detailsData.mxhLiveVideo.mxhLiveVideoCollectInfoList"><input type="text"
              v-model="item.value" name="" :placeholder="item.text"></div>
          <div class="input2">
            <input type="text" password v-model="password" placeholder="请输入解锁密码">
          </div>
          <div class="button">
            <span @click.stop="clickPasswordShow">取消</span>
            <span class="noBorder" @click.stop="unlock">确认</span>
          </div>
        </div>
      </div>
    </div>
    <!-- 直播 -->
    <div class="live-content" v-if="isLiveTemplate && mxhLiveVideoPlayType.type != 1">
      <div class="live-player-content" v-if="detailsData.mxhLiveVideo.status != 0">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/stop.png" :class="orientation=='horizontal' ? 'stopButtonHorizontal' : 'stopButton'"
          v-if="!isPaly && !information" mode="widthFix" @click.stop="bindPlay">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/paly.png" :class="orientation=='horizontal' ? 'playButtonHorizontal' : 'playButton'"
          v-if="isPaly && !information" mode="widthFix" @click.stop="bindPause">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/amplification.png" :class="orientation=='horizontal' ? 'shrinkButtonHorizontal' : 'shrinkButton'"
          v-if="orientation=='vertical' && !information" mode="widthFix" @click.stop="switchMode">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/shrink.png" :class="orientation=='horizontal' ? 'amplificationButtonHorizontal' : 'amplificationButton'"
          v-if="orientation=='horizontal' && !information" mode="widthFix" @click.stop="switchMode">
        <!-- 正常直播 -->
        <div v-if="!information" class="live-content">
          <live-player :src="playUrl" id="player" mode="live" autoplay class="livePlayer" :class="orientation=='horizontal' ? 'playerHorizontal' : ''"
            :orientation="orientation" @statechange="statechange" @error="error" :style="orientation == 'horizontal'? 'width:' + windowWidth + 'px;position:fixed;left:50%;top:50%;transform: translate(-50%, -50%);' : ''"
            :auto-pause-if-open-native="true" :auto-pause-if-navigate="false" >
            <cover-view v-if="showCloseFullText" class="close-full--t" @click.stop="closeFullScreen">退出全屏</cover-view>
          </live-player>
        </div>
        <!-- 主播和主播连麦 -->
        <div v-if="information && information.otherPlayUrl" class="live-content">
          <live-player :src="playUrl" id="player" mode="live" autoplay class="anchorLivePlayer" :orientation="horizontal"
            @statechange="statechange" @error="error" :auto-pause-if-open-native="true" :auto-pause-if-navigate="false"
            object-fit="fillCrop">
            <cover-view v-if="showCloseFullText" class="close-full--t" @click.stop="closeFullScreen">退出全屏</cover-view>
          </live-player>
          <live-player v-if="information.otherPlayUrl" :src="information.otherPlayUrl" object-fit="fillCrop" id="otherPlayUrl"
            mode="live" :orientation="horizontal" autoplay class="otherPlayUrl" :auto-pause-if-open-native="true"
            :auto-pause-if-navigate="false" />
        </div>
        <!-- 用户和主播连麦 -->
        <!--    <div v-if="information && information.otherPlayUrl && !information.otherUserLiveId" class="live-content">
          <live-player :src="playUrl" id="player" mode="live" autoplay class="livePlayer" :class="orientation=='horizontal' ? 'playerHorizontal' : ''" :orientation="orientation" @statechange="statechange" @error="error" :style="orientation == 'horizontal'? 'width:' + windowWidth + 'px;position:fixed;left:50%;top:50%;transform: translate(-50%, -50%);' : ''" :auto-pause-if-open-native="true" :auto-pause-if-navigate="false" />
          <live-player v-if="information.otherPlayUrl" :src="information.otherPlayUrl" id="userOtherPlayUrl" mode="live" autoplay class="userOtherPlayUrl" :auto-pause-if-open-native="true" :auto-pause-if-navigate="false" :class="orientation=='horizontal' ? 'userOtherPlayerHorizontal' : ''" />
        </div> -->
      </div>
      <div class="tab" v-if="detailsData.mxhLiveVideo.status == 0 && orientation == 'vertical'">
        <div class="li" :class="current == 0 ? 'active' : ''" @click="clickTab(0)" style="width:50%">课程</div>
        <div class="li" :class="current == 1 ? 'active' : ''" @click="clickTab(1)" style="width:50%">互动</div>
      </div>
      <div class="tab" v-else-if="orientation == 'vertical'">
        <div class="li" :class="current == 0 ? 'active' : ''" @click="clickTab(0)">同问</div>
        <div class="li" :class="current == 1 ? 'active' : ''" @click="clickTab(1)">课程</div>
        <div class="li" :class="current == 2 ? 'active' : ''" @click="clickTab(2)">互动</div>
        <div class="li" :class="current == 3 ? 'active' : ''" @click="clickTab(3)">PPT</div>
      </div>
      <div class="topMsg" v-if="Topmesg&&current == 2">
				<span class="im-name-sapn identity-1">主播 : </span>
				<span class="topmsg_text">{{Topmesg}}</span>
			</div>
      <div class="goCurrentPage" v-if="current == 3"><img src="/static/images/goCurrentPage.png" @click="goCurrentPage" /></div>
      <swiper :autoplay="autoplay" :current="current" @change="bindchangeswiper" class="swiper-content">
        <swiper-item v-if="detailsData.mxhLiveVideo.status != 0">
          <scroll-view scroll-y="true" :style="'height:'+ scrollViewHeight" @scrolltolower="bindscrolltolower">
            <div class="ask-content">
              <div class="ask-title">{{detailsData.mxhLiveVideo.title}}</div>
              <div class="ask-li">
                <img :src="detailsData.mxhUserInfo.headImgurl" @click="goPersonalDetails">
                <div class="ask-character">
                  <div class="ask-text" @click="goPersonalDetails">{{detailsData.mxhUserInfo.nickName}}<img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png"
                      alt="" v-if="detailsData.mxhUserInfo.corporateType" class="logo"><span class="attention"
                      @click.stop="attention(detailsData.mxhUserInfo)">{{!isAttention ? '+关注' : '已关注'}}</span></div>
                  <div class="ask-name" v-html="detailsData.mxhUserInfo.profile"></div>
                </div>
              </div>
            </div>
            <div class="ask-content" style="padding-bottom: 20rpx;">
              <div class="ask-li" v-for="(comment,index) in commentList" :key="index">
                <img :src="comment.userUrl">
                <div class="ask-character">
                  <div class="ask-name">{{comment.nickName}}</div>
                  <div class="ask-text">{{comment.text}}</div>
                  <div class="ask-number">
                    <span class="fl">{{comment.likeTotal}}人同问</span>
                    <span class="fr" :class="comment.isLike == 0 ? 'active' : ''" @click="commentLike(comment)">
                      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/addAsk-active.png" mode="widthFix"
                        v-if="comment.isLike == 0">
                      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/addAsk.png" mode="widthFix" v-else>
                      同问
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </scroll-view>
        </swiper-item>
        <swiper-item>
          <div class="ask-content">
            <div class="ask-title">{{detailsData.mxhLiveVideo.title}}</div>
            <div class="ask-li">
              <img :src="detailsData.mxhUserInfo.headImgurl" @click="goPersonalDetails">
              <div class="ask-character">
                <div class="ask-text" @click="goPersonalDetails">{{detailsData.mxhUserInfo.nickName}}<img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png"
                    alt="" v-if="detailsData.mxhUserInfo.corporateType" class="logo"><span class="attention"
                    @click.stop="attention(detailsData.mxhUserInfo)">{{!isAttention ? '+关注' : '已关注'}}</span></div>
                <div class="ask-name" v-html="detailsData.mxhUserInfo.profile"></div>
              </div>
            </div>
            <div class="ask-course-content">
              <div class="ask-course-title">课程介绍</div>
              <text class="ask-course-text" v-html="detailsData.mxhLiveVideo.text"></text>
            </div>
          </div>
        </swiper-item>
        <swiper-item>
          <div class="im-content">
            <scroll-view scroll-y="true" :style="{'padding-top':topMsgHeight,height:scrollViewHeight3,'box-sizing':'border-box'}" :data-height="topMsgHeight" :scroll-top="scrollTop">
              <div v-for="(item,index) in currentMessageList" :key="index">
                <div class="im-li" v-if="item.type == 'TIMTextElem'">
                  <span class="im-name">
                    <span v-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主讲人'"
                      class="im-name-sapn identity-1">主讲人 : </span>
                    <span v-else-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主持人'"
                      class="im-name-sapn identity-2">主持人 :</span>
                    <span v-else-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '助教'"
                      class="im-name-sapn identity-3">助教 : </span>
                    <span v-else class="im-name-sapn identity-4">{{item.flow == "in" ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName) }}
                      : </span>
                    <span class="im-text" v-for="(div, index2) in item.virtualDom" :key="item.ID + index2">
                      <span v-if="div.name === 'span'">{{div.text}}</span>
                      <image v-if="div.name === 'img'" :src="div.src" style="width:20px;height:20px;" />
                    </span>
                  </span>
                </div>
                <div class="im-li-2" v-if="item.type == 'enterInform'">
                  <div>【助教】</div>
                  <div>欢迎{{myInfo.nick || mxhUserInfo.nickName}}回来，您可以在同问模块发起问题，主讲人会注意大家关心的热门问题在直播中予以解答。直播间请文明发言，非常感谢。</div>
                </div>
              </div>
            </scroll-view>
          </div>
        </swiper-item>
        <swiper-item v-if="detailsData.mxhLiveVideo.status != 0">
          <scroll-view scroll-y="true" :style="'height:'+ scrollViewHeight4" :scroll-top="currentPageY" @scroll="bindscroll">
            <div class="pptimg" v-for="(item,index) in pptList" v-if="pptList.length" :index="index" :id="item.pptUrl"
              @click="previewImg(item)" :data-status="item.status">
              <div class="lock" v-if="item.status == 0"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/lock.png"></div>
              <div class="ppt-content">
                <div class="currentPage" v-if="(pptindex == index) && item.status == 1">当前</div>
                <img :src="item.pptUrl" mode="widthFix" class="img" :class="(item.status == 1 && !item[index+1]) || (item.status == 1 && item[index+1] && item[index+1].status == 0)  ? 'newCurrentPage' : '' ">
              </div>
            </div>
            <div class="pptimg" v-if="!pptList.length">
              <img :src="share.banner" mode="widthFix" class="img" />
            </div>
          </scroll-view>
        </swiper-item>
      </swiper>
      <div class="input" v-if="current == 2 || (detailsData.mxhLiveVideo.status == 0 && current == 1) && !first" :style="'bottom:' + bottom">
        <div class="signIn" v-if="signedVo&&!signedVo.signedRecord" @click="signCard">
          <!--<img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/signIn.png" mode="widthFix" v-if="!detailsData.mxhLiveVideoSignCard"
            @click="signCard">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/signed.png" mode="widthFix" v-else>
          <span v-if="!detailsData.mxhLiveVideoSignCard">签到</span>
          <span v-else class="signCard">已签到</span>-->
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/signIn.png" mode="widthFix">
          <span>签到</span>
        </div>
        <div class="banned" v-if="allbannedSpeak || bannedSpeak">禁言中</div>
        <div class="message-input" v-else>
          <input type="" name="" :adjust-position="false" v-model="messageContent" placeholder-style="color:rgba(204,204,204,1);font-size:28rpx;"
            placeholder="加入讨论中吧~" @confirm="imSendMessage" @focus="bindfocus" @blur="bindblur">
          <span @click="imSendMessage">发送</span>
        </div>
      </div>
      <div class="ask-button" v-if="current == 0 &&  detailsData.mxhLiveVideo.status != 0" @click="clickAsk">
        我也要提问
      </div>
      <div class="quiz" v-if="isQuizShow">
        <div class="return" @click="clickAsk">返回</div>
        <div class="quiz-text">
          <textarea placeholder="请输入您的问题~" v-model="mxhComment" placeholder-style="color:rgba(204,204,204,1);">
          </textarea>
        </div>
        <div class="quiz-button" @click="addComment">确认发送</div>
      </div>
      <div class="examButton" v-if="isExam == 0 && isOpenExam == 1" @click="clickExamButton">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/examButton.png">
      </div>
    </div>
    <!-- 录播 -->
    <div class="recorded" v-if="!isLiveTemplate && mxhLiveVideoPlayType.type != 1">
      <div class="examButton" v-if="isExam == 0 && isOpenExam == 1" @click="clickExamButton">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/examButton.png">
      </div>
      <div class="surface-img" v-if="isPayVideo">
        <img :src="detailsData.mxhLiveVideo.url" class="banner">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/pay.png" class="pay" @click="payVideo" v-if="viedeList[videoIndex] && viedeList[videoIndex].playUrl">
      </div>
      <div class="beforeLive" v-if="(detailsData.mxhLiveVideo.status == 0 && detailsData.mxhLiveVideo.type == 0) && state">
        <div class="beforeLive-img-content"></div>
        <img :src="detailsData.mxhLiveVideo.url" class="beforeLive-img">
        <div class="beforeLive-content">
          <div class="beforeLive-title">{{detailsData.mxhLiveVideo.title}}</div>
          <div class="beforeLive-viewsNumber"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/number.png">{{detailsData.reservationAmount || 0}}人已报名</div>
          <div class="beforeLive-des">{{detailsData.mxhLiveVideo.startTime}}开始直播</div>
          <div class="button">
            <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/pay.png" class="pay" @click="payVideo" v-if="viedeList[videoIndex] && viedeList[videoIndex].playUrl">
            <div class="beforeLive-button" @click="applyName" v-if="!detailsData.isReservation && detailsData.mxhLiveVideo.broadcast > 0 && detailsData.mxhLiveVideo.status ==0">马上报名</div>
            <div class="beforeLive-button actived" v-if="detailsData.isReservation == 1 && detailsData.mxhLiveVideo.broadcast > 0 && detailsData.mxhLiveVideo.status ==0">已报名</div>
            <div class="beforeLive-button actived" v-if="detailsData.mxhLiveVideo.broadcast < 0 || detailsData.mxhLiveVideo.status !=0">报名已结束</div>
          </div>
        </div>
      </div>
      <video :src="viedeList[videoIndex] ? viedeList[videoIndex].playUrl : ''" class="recorded-video" @ended="bindended"
        object-fit="cover" id="myVideo" @timeupdate="bindtimeupdate" :auto-pause-if-open-native="true"></video>
      <div class="tab">
        <div class="li" :class="current == 0 ? 'active' : ''" @click="clickTab(0)" style="width:50%">课程</div>
        <div class="li" :class="current == 1 ? 'active' : ''" @click="clickTab(1)" style="width:50%">PPT</div>
      </div>
      <swiper :autoplay="autoplay" :current="current" @change="bindchangeswiper" class="swiper-content" style="padding-top:44rpx">
        <swiper-item style="padding:0;padding-top:20rpx">
          <div class="ask-content recorded-ask-content">
            <scroll-view scroll-y="true" :style="'height:'+ scrollViewHeight5" :scroll-top="0" @scrolltolower="scrolltolower">
              <div class="item-1">
                <div class="ask-title">{{detailsData.mxhLiveVideo.title}}</div>
                <div class="ask-li">
                  <img :src="detailsData.mxhUserInfo.headImgurl" @click="goPersonalDetails">
                  <div class="ask-character">
                    <div class="ask-text" @click="goPersonalDetails">{{detailsData.mxhUserInfo.nickName}}<img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png"
                        alt="" v-if="detailsData.mxhUserInfo.corporateType" class="logo"> <span class="attention"
                        @click.stop="attention(detailsData.mxhUserInfo)">{{!isAttention ? '+关注' : '已关注'}}</span></div>
                    <div class="ask-name" v-html="detailsData.mxhUserInfo.profile"></div>
                  </div>
                </div>
              </div>
              <div class="item-2">
                <div class="ask-course-content" style="margin-bottom:20px">
                  <div class="ask-course-title">课程介绍</div>
                  <text class="ask-course-text" v-html="detailsData.mxhLiveVideo.text"></text>
                </div>
              </div>
              <div class="im-content item-3" v-if="detailsData.mxhLiveVideo.status != 0">
                <div class="ask-course-title">课程互动</div>
                <div v-for="(item,index) in currentMessageList" :key="index">
                  <div class="im-li" v-if="item.type == 'TIMTextElem'">
                    <span class="im-name">
                      <span v-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主讲人'"
                        class="im-name-sapn identity-1">主讲人 : </span>
                      <span v-else-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主持人'"
                        class="im-name-sapn identity-2">主持人 :</span>
                      <span v-else-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '助教'"
                        class="im-name-sapn identity-3">助教 : </span>
                      <span v-else class="im-name-sapn identity-4">{{item.flow == "in" ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName) }}
                        : </span>
                      <span class="im-text" v-for="(div, index2) in item.virtualDom" :key="item.ID + index2">
                        <span v-if="div.name === 'span'">{{div.text}}</span>
                        <image v-if="div.name === 'img'" :src="div.src" style="width:20px;height:20px;" />
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            </scroll-view>
          </div>
        </swiper-item>
        <swiper-item style="padding:0;padding-top:20rpx">
          <scroll-view scroll-y="true" :style="'height:'+ scrollViewHeight4" :scroll-top="0" @scroll="bindscroll">
            <div class="pptimg2" v-for="(item,index) in pptList" v-if="pptList.length" :index="index" :id="item.pptUrl"
              @click="previewImg(item)" :data-status="item.status">
              <div class="lock" v-if="item.status == 0"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/lock.png"></div>
              <div class="ppt-content">
                <!-- <div class="currentPage" v-if="(pptindex == index) && item.status == 1">当前</div> -->
                <img :src="item.pptUrl" mode="widthFix" class="img" :class="(item.status == 1 && !item[index+1]) || (item.status == 1 && item[index+1] && item[index+1].status == 0)  ? 'newCurrentPage' : '' ">
              </div>
            </div>
            <div class="pptimg2" v-if="!pptList.length">
              <img :src="share.banner" mode="widthFix" class="img" />
            </div>
          </scroll-view>
        </swiper-item>
      </swiper>
    </div>
    <!-- 飘浮canvas -->
    <!-- <canvas id="floatCanvas" type="2d" canvas-id="floatCanvas" style="width:100px;height:300px;position:fixed;right:0px;bottom:125rpx;z-index: 1;" @click="clickVideo"></canvas> -->

    <div class="popup-mask" v-if="isSharePopup" @click="clickShareButton">
      <div class="share-popup" @click.stop="clickShareContent">
        <div class="share-content">
          <button class="shareWeChat" open-type='share'>
            <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/shareWeChat.png" mode="widthFix">
            <span>微信分享</span>
          </button>
          <div class="sharePosters" @click.stop="savePhoto">
            <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/share%20Posters.png" mode="widthFix">
            <span>海报分享</span>
          </div>
        </div>
        <div class="cancel" @click="clickShareButton">取消</div>
      </div>
    </div>
    <div class="shareImg" v-if="isShareImg" @click="clickShareImg">
      <button open-type="openSetting" @opensetting="opensettingCallback" v-if="!isSaveImageToPhotosAlbum" @click.stop="clickstop">
        <img :src="canvasToImagePath" mode="widthFix">
      </button>
      <img :src="canvasToImagePath" mode="widthFix" @click.stop="save" v-if="isSaveImageToPhotosAlbum">
    </div>
    <auth type="details"></auth>
     <bind-mobile @close="close()" v-if="isShowPopup" @confirm='confirm()'></bind-mobile>
  </section>
</template>
<script>
import { mapState } from 'vuex'
// import { genTestUserSig } from '../../../static/utils/GenerateTestUserSig'
import { emojiName, emojiMap, emojiUrl } from '../../utils/emojiMap'
import auth from '@/components/auth'
import bindMobile from '@/components/bindMobile'
// import float from '@/utils/flutter-hearts-zmt.js'
// import screen from './child-component/screen'

export default {
  data () {
    return {
      topMsgHeight: 0,
      emojiName: emojiName,
      emojiMap: emojiMap,
      emojiUrl: emojiUrl,
      autoplay: false,
      current: 0,
      liveId: '', // 直播id
      messageContent: '', // 消息内容
      isSharePopup: false,
      form: {
        page: 1,
        size: 10
      },
      pagesLength: 1,
      isQuizShow: false,
      mxhComment: '',
      commentList: [],
      detailsData: {
        liveVideoUserVoList: [],
        mxhLiveVideoPlayList: [],
        mxhLiveVideoSignCard: null,
        mxhLiveVideo: {},
        mxhUserInfo: {},
        isReservation: 0
      },
      playUrl: '',
      timer: '',
      scrollTop: 99999,
      scrollViewHeight: 0,
      scrollViewHeight2: 0,
      scrollViewHeight3: 0,
      scrollViewHeight4: 0,
      scrollViewHeight5: 0,
      share: {
        banner:
          'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg',
        avatar:
          'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg',
        qrcode:
          'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg'
      },
      canvasToImagePath: '', // 分享图
      isShareImg: false,
      isSaveImageToPhotosAlbum: true,
      ctx: '',
      isPaly: true,
      orientation: 'vertical',
      mxhUserInfo: {},

      viedeList: [],
      videoIndex: 0,

      isLiveTemplate: true,
      userPlayLoading: true,
      isBindended: true,
      isPayVideo: true,
      state: true,
      bannedSpeak: false, // 是否禁言
      isShow: false,
      bottom: 0,
      currentPageY: 0,
      currentPagePageY: 0,
      windowWidth: 0,
      historyFrom: {
        page: 1,
        size: 100
      },
      isPasswordShow: false,
      password: '', // 解锁密码
      mxhLiveVideoPlayType: {
        type: ''
      },
      viewDuration: 0, // 直播播放时长
      isAttention: 0,

      information: null, // 连麦信息
      showCloseFullText: false // 是否展示退出全屏文案
    }
  },
  computed: {
    ...mapState({
      currentMessageList: state => {
        return state.conversation.currentMessageList
      },
      currentConversation: state => state.conversation.currentConversation,
      myInfo: state => state.user.myInfo,
      isExam: state => state.conversation.isExam, // 是否参加过考试
      isOpenExam: state => state.conversation.isOpenExam, // 是否开启
      isShowPopup: state => state.global.isShowPopup,
      groupMemberProfile: state => state.conversation.groupMemberProfile,
      first: state => state.conversation.first,
      closelive: state => state.conversation.closelive,
      updateLogin: state => state.conversation.updateLogin,
      pptList: state => state.conversation.pptList,
      updatepptlocation: state => state.conversation.updatepptlocation,
      pptindex: state => state.conversation.pptindex,
      updatePPTList: state => state.conversation.updatePPTList,
      allbannedSpeak: state => state.conversation.allbannedSpeak,
      userLiveNumber: state => state.conversation.userLiveNumber,
      updateComment: state => state.conversation.updateComment,
      isOffConnectLive: state => state.conversation.isOffConnectLive,
      isOpenConnectLive: state => state.conversation.isOpenConnectLive,
      Topmesg: state => state.conversation.Topmesg, // 被置顶的弹幕消息
      signedVo: state => state.conversation.signedVo // 是否发起签到
      // likeNum: state => state.conversation.likeNum, // 点赞数
    })
  },
  watch: {
    // likeNum: function() {
    //   this.clickFloat()
    // },
    isOffConnectLive: async function () {
      if (this.isOffConnectLive && !this.isOpenConnectLive) {
        this.information = null
        await this.getLiveStreamPull()
        this.$store.commit('offConnectLive', false)
      }
    },
    isOpenConnectLive: async function () {
      if (this.isOpenConnectLive && !this.isOffConnectLive) {
        await this.getOtherInteractive()
        await this.getStartInteractive()
        await this.getLiveStreamPull()
        this.$store.commit('openConnectLive', false)
      }
    },
    updateComment: function () {
      if (this.updateComment == true) {
        this.form.page = 1
        this.commentList = []
        this.getComment()
        this.$store.commit('updateComment', false)
      }
    },
    updatePPTList: function () {
      if (this.updatePPTList == 1) {
        this.$store.commit('setpptList', [])
        this.getPpt()
        this.$store.commit('updatepptindex', 1)
      }
    },
    updatepptlocation: function () {
      this.locationPPT()
    },
    updateLogin: async function () {
      let pages = getCurrentPages()
      let currPage = null
      if (pages.length) {
        currPage = pages[pages.length - 1]
      }
      if (currPage.route == 'pages/details/main') {
        await this.getOtherInteractive()
        await this.getStartInteractive()
        await this.getLiveVideo()
        this.$store.commit('loginCallback', false)
      }
    },
    closelive: function () {
      let that = this
      if (this.closelive == 1) {
        this.bindPause()
      }
      if (this.closelive == 0) {
        wx.showModal({
          title: '提示',
          content: '主播已开播，是否跳转直播？',
          success: async res => {
            if (res.confirm) {
              await that.getOtherInteractive()
              await that.getStartInteractive()
              await that.getLiveVideo()
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
        return false
      }
    },
    currentMessageList: function () {
      this.$nextTick(() => {
        this.$set(this, 'scrollTop', ++this.scrollTop)
      })
    },
    groupMemberProfile: function () {
      if (
        this.groupMemberProfile.length &&
        this.groupMemberProfile[0].muteUntil * 1000 > new Date().getTime()
      ) {
        this.bannedSpeak = true
      } else {
        this.bannedSpeak = false
      }
    },
    Topmesg: function () {
      if (this.Topmesg && this.current == 2) {
        let _this = this
        this.$nextTick(() => {
          wx
            .createSelectorQuery()
            .selectAll('.topMsg')
            .boundingClientRect()
            .exec(function (res) {
              _this.topMsgHeight = res[0][0].height + 'px'
            })
        })
      } else {
        this.topMsgHeight = '0px'
      }
    },
    current: function () {
      if (this.Topmesg && this.current == 2) {
        let _this = this
        this.$nextTick(() => {
          wx
            .createSelectorQuery()
            .selectAll('.topMsg')
            .boundingClientRect()
            .exec(function (res) {
              _this.topMsgHeight = res[0][0].height + 'px'
            })
        })
      } else {
        this.topMsgHeight = '0px'
      }
      if (this.current == 2) {
        this.$nextTick(() => {
          this.bindblur()
        })
      }
    }
  },
  onLoad (options) {
    if (options.scene) {
      let arr = decodeURIComponent(options.scene).split('=')
      this.liveId = arr[1]
    } else {
      this.liveId = decodeURIComponent(options.liveId)
    }
    this.pagesLength = getCurrentPages().length
    console.log('pages', this.pagesLength)
  },
  async onShow () {
    this.windowWidth = 340 * wx.getSystemInfoSync().windowHeight / 170
    if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
      this.$store.commit('setIsLogin', true)
      this.$store.commit('setIsLoginCallback', true)
      return false
    }
    await this.getOtherInteractive()
    await this.getStartInteractive()
    await this.getLiveVideo()
    if (this.Topmesg && this.current == 2) {
      let _this = this
      this.$nextTick(() => {
        wx
          .createSelectorQuery()
          .selectAll('.topMsg')
          .boundingClientRect()
          .exec(function (res) {
            _this.topMsgHeight = res[0][0].height + 'px'
          })
      })
    } else {
      this.topMsgHeight = '0px'
    }
  },
  onUnload () {
    this.$store.commit('setpptList', [])
    this.$store.commit('resetCurrentConversation')
    this.emojiName = emojiName
    this.emojiMap = emojiMap
    this.emojiUrl = emojiUrl
    this.autoplay = false
    this.current = 0
    this.liveId = '' // 直播id
    this.messageContent = '' // 消息内容
    this.isSharePopup = false
    this.information = null
    this.form = {
      page: 1,
      size: 10
    }
    this.isQuizShow = false
    this.mxhComment = ''
    this.commentList = []
    this.detailsData = {
      liveVideoUserVoList: [],
      mxhLiveVideoPlayList: [],
      mxhLiveVideoSignCard: null,
      mxhLiveVideo: {},
      mxhUserInfo: {},
      isReservation: 0,
      reservationAmount: 0
    }
    this.playUrl = ''
    this.timer = ''
    this.scrollTop = 99999
    this.scrollViewHeight = 0
    this.scrollViewHeight2 = 0
    this.historyFrom.page = 1
    this.share = {
      banner:
        'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg',
      avatar:
        'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg',
      qrcode:
        'http://oss.sanhoiedu.com/app/2c2a94f7-cff6-4a1e-b9f1-820fe75022ae.jpg'
    }
    this.canvasToImagePath = '' // 分享图
    this.isShareImg = false
    this.isSaveImageToPhotosAlbum = true
    this.ctx = ''
    this.isPaly = true
    this.orientation = 'vertical'
    this.mxhUserInfo = {}

    this.viedeList = []
    this.videoIndex = 0

    this.isLiveTemplate = true
    this.userPlayLoading = true
    this.isBindended = true
    this.isPayVideo = true
    this.state = true
    this.bannedSpeak = false

    this.isPasswordShow = false
    this.password = '' // 解锁密码
    this.mxhLiveVideoPlayType = {
      type: ''
    }
    this.viewDuration = 0
    if (this.timer) {
      clearInterval(this.timer)
    }
  },
  components: {
    auth,
    bindMobile
    // screen
  },
  methods: {
    close () {
      this.$store.commit('showToast', { title: '您不能观看当前节目' })
      setTimeout(() => {
        if (this.pagesLength == 1) {
          wx.redirectTo({
            url:
              '/pages/personalHome/main?userId=' +
              this.detailsData.mxhUserInfo.id
          })
        } else {
          wx.navigateBack({
            // 返回
            delta: 1
          })
        }
      }, 500)
    },
    confirm () {
      this.isLiveTemplate = true
    },
    isLogin () {
      let mxhUserInfo = wx.getStorageSync('mxhUserInfo')
      if (!mxhUserInfo || (mxhUserInfo && !mxhUserInfo.mobile)) {
        this.$store.commit('setShowPopup', true)
        return false
      }
      return true
    },
    scrolltolower () {
      this.historyFrom.page = this.historyFrom.page + 1
      this.getHistory()
    },
    // likeNum: function() {
    //   this.clickFloat()
    // },
    // /**
    //  * 点击浮动效果
    //  */
    // clickFloat() {
    //   if (!this.images.length) {
    //     return
    //   }
    //   var random = {
    //     uniform: function(min, max) {
    //       return min + (max - min) * Math.random();
    //     },
    //     uniformDiscrete: function(i, j) {
    //       return i + Math.floor((j - i + 1) * random.uniform(0, 1));
    //     },
    //   };
    //   this.stage.bubble(this.images[random.uniformDiscrete(0, this.images.length - 1)]);
    // },
    /**
     * 获取正在申请PK的互动连麦的信息
     */
    async getOtherInteractive () {
      if (this.liveId) {
        let url = '/liveVideo/interactive/get/other/interactive/' + this.liveId
        let data = {}
        await this.$http.post(url, data).then(res => {
          if (res.data) {
            this.information = res.data[0]
          }
        })
      }
    },
    /**
     * 获取正在互动连麦的信息
     * @return {[type]}
     */
    async getStartInteractive () {
      let url = '/liveVideo/interactive/get/start/interactive/' + this.liveId
      let data = {}
      await this.$http.post(url, data).then(res => {
        if (res.data) {
          this.information = res.data
        }
      })
    },
    /**
     * 关注
     */
    attention (param) {
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit('setIsLogin', true)
        return false
      }
      let url = '/userConcern/saveMxhUserConcern'
      let data = {
        concernUserId: param.id
      }
      this.$http.post(url, data).then(res => {
        this.$set(this, 'isAttention', !this.isAttention)
      })
    },
    // ...
    // onRoomEvent: function(e){
    //     switch(e.mp.detail.tag){
    //         case 'roomClosed': {
    //             //房间已经关闭
    //             break;
    //         }
    //         case 'error': {
    //             //发生错误
    //             var code = e.mp.detail.code;
    //             var detail = e.mp.detail.detail;
    //             break;
    //         }
    //         case 'recvTextMsg': {
    //             //收到文本消息
    //             var text = e.mp.detail.detail;
    //             break;
    //         }
    //         case 'requestJoinAnchor': {
    //             //主播收到来自观众的连麦请求
    //             var audience = e.detail;
    //             var name = audience.userName;
    //             var id = audience.userID;
    //             // 允许请求
    //             liveroom.respondJoinReq(true, audience)
    //             break;
    //         }
    //         case 'linkOn': {
    //             //连麦观众在连麦成功时会收到此通知
    //             break;
    //         }
    //         case 'linkOut': {
    //             //连麦观众退出连麦时会收到此通知
    //             break;
    //         }
    //     }
    // },
    /**
     * 定位ppt
     */
    locationPPT () {
      let _this = this
      var query = wx.createSelectorQuery()
      query.selectAll('.pptimg').boundingClientRect()
      query.selectViewport().scrollOffset()
      query.exec(function (res) {
        setTimeout(() => {
          let currentPageY = 0
          if (_this.pptindex) {
            res[0].forEach((res, key) => {
              if (key < _this.pptindex) {
                currentPageY += res.height
              }
            })
          }
          _this.currentPageY = currentPageY
          _this.currentPagePageY = currentPageY
        }, 0)
      })
      this.$store.commit('setupdatepptlocation', false)
    },

    /**
     * 切换定位到当前ppt
     */
    atLocationPPT () {
      let status = true
      this.pptList.forEach((item, index) => {
        if (item.status == 0 && status) {
          this.$store.commit('updatepptindex', index - 1)
          status = false
        }
      })
      this.locationPPT()
    },

    /**
     * 图片浏览
     */
    previewImg (item) {
      var current = item.pptUrl
      var status = item.status
      if (status == 0) {
        return false
      }
      var imgList = []
      for (let i = 0; i < this.pptList.length; i++) {
        if (this.pptList[i].status == 1) {
          imgList.push(this.pptList[i].pptUrl)
        }
      }
      wx.previewImage({
        current: current, // 当前点击的图片链接
        urls: imgList // 图片数组
      })
    },
    /**
     * 获取im历史消息
     */
    getHistory () {
      let url =
        '/liveVideo/msg/get/' +
        this.liveId +
        '/' +
        this.historyFrom.page +
        '/' +
        this.historyFrom.size
      this.$http.post(url).then(res => {
        if (res.code == 0) {
          let historyList = [
            {
              type: 'enterInform'
            }
          ]
          res.data.forEach((item, key) => {
            historyList.unshift({
              flow: this.mxhUserInfo.id == item.userId ? 'out' : 'in',
              from: item.nickName,
              nick: item.nickName,
              type: item.type,
              payload: {
                text: item.msgText
              },
              virtualDom: [
                {
                  name: item.type == 'TIMTextElem' ? 'span' : 'img',
                  text: item.msgText
                }
              ]
            })
          })
          this.$store.commit('unshiftMessageList', historyList)
        }
      })
    },
    goPersonalDetails () {
      if (this.detailsData.mxhUserInfo.corporateType == 0) {
        wx.navigateTo({
          url:
            '/pages/personalHome/main?userId=' + this.detailsData.mxhUserInfo.id
        })
      }
      if (this.detailsData.mxhUserInfo.corporateType == 1) {
        wx.navigateTo({
          url:
            '/pages/enterpriseHome/main?userId=' +
            this.detailsData.mxhUserInfo.id
        })
      }
    },
    goCurrentPage () {
      let _this = this
      var query = wx.createSelectorQuery()
      query.selectAll('.pptimg').boundingClientRect()
      query.selectViewport().scrollOffset()
      query.exec(function (res) {
        setTimeout(() => {
          let currentPageY = 0
          if (_this.pptindex) {
            res[0].forEach((res, key) => {
              if (key < _this.pptindex) {
                currentPageY += res.height
              }
            })
          }
          if (_this.currentPageY == currentPageY) {
            _this.currentPageY = currentPageY + 1
            _this.currentPagePageY = currentPageY + 1
          } else {
            _this.currentPageY = currentPageY
            _this.currentPagePageY = currentPageY
          }
        }, 0)
      })
      this.$store.commit('setupdatepptlocation', false)
    },
    bindfocus (e) {
      let that = this
      wx.getSystemInfo({
        success (res) {
          if (res.platform == 'android' || res.platform == 'ios') {
            that.scrollViewHeight3 =
              wx.getSystemInfoSync().windowHeight -
              wx.getSystemInfoSync().windowWidth /
                750 *
                (480 + 450 + e.mp.detail.height) +
              'px'
            setTimeout(() => {
              that.$set(that, 'scrollTop', ++that.scrollTop)
            }, 500)
            that.bottom = e.mp.detail.height + 'px'
          }
        }
      })
    },
    bindblur () {
      this.scrollViewHeight3 =
        wx.getSystemInfoSync().windowHeight -
        wx.getSystemInfoSync().windowWidth / 750 * (480 + 140) +
        'px'
      setTimeout(() => {
        this.$set(this, 'scrollTop', ++this.scrollTop)
      }, 500)
      this.bottom = '0px'
    },
    bindscroll (e) {
      // this.currentPageY = parseInt(e.mp.detail.scrollTop)
      // console.log(e.mp.detail.scrollTop)
    },
    bindscrolltolower () {
      this.form.page++
      this.getComment()
    },
    payVideo () {
      this.isPayVideo = false
      this.state = false
      this.videoContext.play()
    },
    clickExamButton () {
      wx.navigateTo({
        url: `/pages/subpacks/exam/home/main?examId=${this.detailsData.examId}`
      })
      // wx.navigateTo({ url: `/pages/examination/main?liveId=${this.liveId}` })
      // this.current = 2
    },
    applyName () {
      let that = this
      let str = 'jGJW2VkF2uI32aczWoI6aVyvvLzksx9tteHAkyj9yPY' // xxx是模板id
      let str2 = '7RZ8G_f8rdZ1SVFYMHDle-P1vC9DhBLf8wnvEW3rcD8' // xxx是模板id
      wx.requestSubscribeMessage({
        tmplIds: [str, str2], // 此处可填写多个模板 ID，但低版本微信不兼容只能授权一个
        success (res) {
          // 'accept'表示用户接受；'reject'表示用户拒绝；'ban'表示已被后台封禁
          if (res[str] == 'accept') {
            let url = '/liveVideo/add/user/reservation'
            let data = {
              liveVideoId: that.liveId
            }
            that.$http.post(url, data).then(res => {
              if (res.code == 0) {
                that.detailsData.isReservation = 1
                that.detailsData.reservationAmount++
                that.$store.commit('updateAddUserLive')
              }
            })
          }
        }
      })
    },
    bindchangeswiper (e) {
      this.current = e.target.current
      if (this.current == 0) {
        // this.form.page = 1
        // this.commentList = []
        // this.getComment()
      }
    },
    bindended () {
      this.isPayVideo = true
      this.state = true
      // if (!this.isBindended) {
      //   return false
      // }
      // this.isBindended = false
      // if ((this.videoIndex + 1) < this.viedeList.length) {
      //   this.videoIndex = this.videoIndex + 1
      //   setTimeout(() => {
      //     this.videoContext.play()
      //     this.isBindended = false
      //   }, 1000)
      // }
    },
    bindtimeupdate (e) {
      let ratio = 1 / this.viedeList.length
      let currentTime = parseInt(e.mp.detail.currentTime)
      let duration = parseInt(e.mp.detail.duration)
      let progressRate = parseInt(
        (currentTime / duration * ratio + this.videoIndex * ratio) * 100
      )
      if (currentTime == duration && currentTime) {
        this.userPlay(progressRate)
      }
      if (currentTime % 9 == 0 && currentTime) {
        this.userPlay(progressRate)
      }
    },
    /**
     * 录播添加播放记录
     */
    userPlay (progressRate) {
      if (!this.userPlayLoading) {
        return false
      }
      this.userPlayLoading = false
      let url = '/liveVideo/add/user/play'
      let data = {
        liveVideoId: this.liveId,
        progressRate: progressRate
      }

      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          setTimeout(() => {
            this.userPlayLoading = true
          }, 1000)
        }
      })
    },
    /**
     * 直播录播添加播放记录
     */
    liveUserPlay () {
      if (!this.userPlayLoading) {
        return false
      }
      this.userPlayLoading = false
      let url = '/liveVideo/add/user/play'
      let data = {
        liveVideoId: this.liveId,
        viewDuration: this.viewDuration,
        progressRate: 100
      }

      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.viewDuration = this.viewDuration + 10
          setTimeout(() => {
            this.userPlayLoading = true
          }, 1000)
        }
      })
    },

    clickShareImg () {
      this.isShareImg = false
    },
    clickstop () {},
    closeFullScreen () {
      wx.createLivePlayerContext('player').exitFullScreen({
        success: () => {
          this.showCloseFullText = false
        }
      })
    },
    switchMode () {
      wx.createLivePlayerContext('player').requestFullScreen({
        direction: 90,
        success: () => {
          this.showCloseFullText = true
          wx.showToast({
            icon: 'success',
            title: 'success'
          })
        },
        fail (err) {
          wx.showToast({
            icon: 'none',
            title: err.errMsg
          })
        }
      })
      // if (this.orientation == 'vertical') {
      //   this.orientation = 'horizontal'
      // } else {
      //   this.orientation = 'vertical'
      // }
    },
    statechange (e) {
      /**
       * code == 2004
       * 播放开始
       */
      if (!this.timer && e.mp.detail.code == 2004) {
        this.timer = setInterval(() => {
          this.liveUserPlay()
        }, 10000)
      }

      console.log('live-player code:', e.mp.detail.code)
    },
    error (e) {
      console.error('live-player error:', e.mp.detail.errMsg)
    },
    /**
     * 获取微信二维码
     */
    async getCode () {
      let url = '/wechat/get/v2/code'
      let data = {
        page: 'pages/details/main',
        scene: '?liveId=' + this.liveId
      }
      await this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.share.qrcode = res.data
        }
      })
    },
    bindPlay () {
      let that = this
      that.isPaly = true
      this.ctx.play({
        success: res => {
          console.log('play success')
        },
        fail: res => {
          console.log('play fail')
        }
      })
    },
    bindPause () {
      if (this.information) {
        this.$store.commit('showToast', {
          title: '当前直播间处于连麦中,请勿暂停'
        })
      } else {
        this.isPaly = false
        this.ctx.pause({
          success: res => {
            console.log('pause success')
          },
          fail: res => {
            console.log('pause fail')
          }
        })
      }
    },
    bindamplification () {},
    opensettingCallback () {
      let that = this
      wx.getSetting({
        success (res) {
          if (res.authSetting['scope.writePhotosAlbum'] === false) {
            that.isSaveImageToPhotosAlbum = false
          }
          if (res.authSetting['scope.writePhotosAlbum'] === null) {
            that.isSaveImageToPhotosAlbum = true
          }
          if (res.authSetting['scope.writePhotosAlbum'] === true) {
            that.isSaveImageToPhotosAlbum = true
          }
        }
      })
    },
    getImgInfo (url) {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: res => {
            resolve(res)
          }
        })
      })
    },
    /**
     * 生成图片核心
     */
    coreCanvas () {
      let that = this
      let ctx = wx.createCanvasContext('shareCanvas')

      Promise.all([
        this.getImgInfo(this.share.banner.replace('http:', 'https:')),
        this.getImgInfo(this.mxhUserInfo.headImgurl.replace('http:', 'https:')),
        this.getImgInfo(this.share.qrcode.replace('http:', 'https:'))
      ]).then(results => {
        let banner = results[0]
        let avatar = results[1]
        let qrcode = results[2]

        /**
         * 背景颜色
         */
        ctx.fillStyle = '#fff'
        ctx.fillRect(0, 0, 650, 732)
        ctx.save()
        ctx.beginPath() // 开始绘制

        /**
         * 标题
         */
        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#fff') // 文字颜色：黑色
        ctx.setFontSize(32) // 文字字号：22px
        ctx.fillText('法律大讲堂，智慧普法教育', 30, 340)

        /**
         * 绘制名称
         */
        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#222222') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText(this.mxhUserInfo.nickName, 132, 450)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#999999') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('邀请您免费学习', 132, 490)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#d3a358') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('美学会', 328, 490)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#999999') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('精选好课', 413, 490)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#222222') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('扫描学习新知识', 192, 615)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#222222') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('开课后免费学习', 192, 670)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#d3a358') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('美学会', 388, 670)

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#222222') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText('课程', 473, 670)

        /**
         * 右边头像
         */
        var avatarurl_width2 = 80 // 绘制的头像宽度
        var avatarurl_heigth2 = 80 // 绘制的头像高度
        var avatarurl_x2 = 30 // 绘制的头像在画布上的位置
        var avatarurl_y2 = 420 // 绘制的头像在画布上的位置
        ctx.arc(
          avatarurl_width2 / 2 + avatarurl_x2,
          avatarurl_heigth2 / 2 + avatarurl_y2,
          avatarurl_width2 / 2,
          0,
          Math.PI * 2,
          false
        )
        ctx.fill()
        ctx.clip() // 画好了圆 剪切  原始画布中剪切任意形状和尺寸。一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内 这也是我们要save上下文的原因
        ctx.drawImage(
          avatar.path,
          avatarurl_x2,
          avatarurl_y2,
          avatarurl_width2,
          avatarurl_heigth2
        )
        ctx.restore()
        ctx.setStrokeStyle('#fff')

        ctx.drawImage(qrcode.path, 30, 562, 140, 140)

        /**
         * 绘制banner
         */
        ctx.drawImage(banner.path, 0, 0, 650, 390)

        ctx.fillStyle = 'rgba(0,0,0,0.3)' // 设置fillStyle属性可以是CSS样式颜色，渐变，或是图案。fillStyle默认设置是#000000（黑色）
        ctx.fillRect(0, 310, 650, 80) // fillRect(x,y,width,height)方法定义了矩形当前的填充方式。
        // ctx.setWindowOpacity(0.5);
        ctx.save()
        ctx.beginPath() // 开始绘制

        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#fff') // 文字颜色：黑色
        ctx.setFontSize(32) // 文字字号：22px
        let text =
          this.detailsData.mxhLiveVideo.title.length > 10
            ? this.detailsData.mxhLiveVideo.title.substring(0, 10) + '...'
            : this.detailsData.mxhLiveVideo.title
        ctx.fillText(this.detailsData.mxhLiveVideo.title, 30, 363)

        ctx.moveTo(30, 530)
        ctx.lineTo(620, 530)
        ctx.lineWidth = 2
        ctx.strokeStyle = '#EAEAEA'

        ctx.stroke()
        ctx.draw()

        setTimeout(() => {
          wx.canvasToTempFilePath({
            width: 650,
            height: 732,
            canvasId: 'shareCanvas',
            success (res) {
              wx.hideLoading()
              that.canvasToImagePath = res.tempFilePath
              that.isSharePopup = false
              that.isShareImg = true
            }
          })
        }, 1000)
      })
    },
    async savePhoto () {
      wx.showLoading({
        title: '正在生成分享图片...',
        mask: true
      })
      await this.getCode()
      this.coreCanvas()
    },
    /**
     * 保存图片
     */
    save () {
      wx.saveImageToPhotosAlbum({
        filePath: this.canvasToImagePath,
        success () {
          wx.showToast({
            title: '已保存到相册'
          })
        },
        fail (res) {}
      })
    },
    clickShareButton () {
      this.isSharePopup = !this.isSharePopup
    },
    clickShareContent () {},
    addComment () {
      if (!this.isnull(this.mxhComment)) {
        if (this.comment) {
          return
        }
        this.comment = true
        let url = '/comment/add'
        let data = {
          liveVideoId: this.liveId,
          text: this.mxhComment
        }
        this.$http.post(url, data).then(res => {
          if (res.code == 0) {
            this.isQuizShow = false
            this.mxhComment = ''
            this.commentList = []
            this.form.page = 1
            setTimeout(() => {
              this.comment = false
            }, 1000)
            // this.getComment()
          }
        })
      } else {
        this.$store.commit('showToast', {
          title: '提交问题不能为空'
        })
      }
    },
    clickAsk () {
      this.isQuizShow = !this.isQuizShow
    },
    /**
     * 签到
     */
    signCard () {
      //      let url = '/signCard/add/signCard'
      let url = '/live/video/signed/add/record'
      let data = {
        liveVideoId: this.liveId
      }
      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.$set(this.detailsData, 'mxhLiveVideoSignCard', res.data)
          this.imSendMessage('签到')
          this.$store.commit('setsignedVo', null)
        }
      })
    },
    /**
     * 获取ppt
     */
    getPpt () {
      let url = '/live/ppt/get/list/' + this.liveId
      this.$http.post(url).then(res => {
        this.$store.commit('setpptList', res.data)
      })
    },
    /**
     * 获取提问列表
     */
    getComment () {
      let url = '/comment/get/list/' + this.form.page + '/' + this.form.size
      let data = {
        liveVideoId: this.liveId
      }
      this.$http.post(url, data).then(res => {
        this.commentList = this.commentList.concat(res.data.list)
      })
    },
    /**
     * 点赞同问
     */
    commentLike (comment) {
      // if (comment.isLike) {
      //   return false
      // }
      let url = '/comment/set/like'
      let data = {
        likeItemId: comment.id,
        type: 0
      }
      this.$http.post(url, data).then(res => {
        if (res.code == 0 && res.data != 0) {
          comment.isLike = 1
          comment.likeTotal = ++comment.likeTotal
        }
        if (res.code == 0 && res.data == 0) {
          comment.isLike = 0
          comment.likeTotal = --comment.likeTotal
        }
      })
    },
    /**
     * 获取课程详情
     */
    getLiveVideo () {
      let url = '/liveVideo/get/' + this.liveId
      this.$http.post(url).then(res => {
        if (res.code == 2032) {
          wx.showModal({
            title: '提示',
            content: '直播间已删除',
            showCancel: false,
            success (res) {
              if (res.confirm) {
                wx.reLaunch({
                  url: '/pages/home/main'
                })
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
          return false
        }
        if (res.data.mxhLiveVideo && res.data.mxhLiveVideo.startTime) {
          // 结束时间
          var startTime = new Date(
            res.data.mxhLiveVideo.startTime.replace(/-/g, '/')
          ).getTime()
          // 当前时间
          var nowDate = new Date().getTime()
          // 相差的总秒数
          res.data.mxhLiveVideo.broadcast = startTime - nowDate

          res.data.mxhLiveVideo.startTime =
            res.data.mxhLiveVideo.startTime.substr(5, 2) +
            '月' +
            res.data.mxhLiveVideo.startTime.substr(8, 2) +
            '日' +
            ' ' +
            res.data.mxhLiveVideo.startTime.substr(10, 6)
        }

        if (res.data.mxhLiveVideo.text) {
          res.data.mxhLiveVideo.text = res.data.mxhLiveVideo.text.replace(
            /\<img/gi,
            '<img style="max-width:100%;height:auto" '
          )
        }

        this.detailsData = {
          examId: res.data.examId,
          mxhLiveVideo: res.data.mxhLiveVideo ? res.data.mxhLiveVideo : {},
          mxhUserInfo: res.data.mxhUserInfo ? res.data.mxhUserInfo : {},
          mxhLiveVideoSignCard: res.data.mxhLiveVideoSignCard
            ? res.data.mxhLiveVideoSignCard
            : null,
          mxhLiveVideoPlayList: res.data.mxhLiveVideoPlayList
            ? res.data.mxhLiveVideoPlayList
            : [],
          liveVideoUserVoList: res.data.liveVideoUserVoList
            ? res.data.liveVideoUserVoList
            : [],
          isReservation: res.data.isReservation,
          reservationAmount: res.data.reservationAmount
        }

        /**
         * 关注字段 0 1 未关注/已关注
         */
        this.isAttention = res.data.isAttention
        // if(this.detailsData.mxhUserInfo && this.detailsData.mxhUserInfo.profile){
        //  this.detailsData.mxhUserInfo.profile = this.detailsData.mxhUserInfo.profile.replace(/↵/g,"\n");
        // }
        // if(this.detailsData.mxhLiveVideo && this.detailsData.mxhLiveVideo.text){
        //  this.detailsData.mxhLiveVideo.text = this.detailsData.mxhLiveVideo.text.replace(/\r\n/g,"<br/>");
        // }
        if (
          (res.data.mxhLiveVideo.type == 0 &&
            res.data.mxhLiveVideo.status == 1) ||
          (res.data.mxhLiveVideo.type == 2 && res.data.mxhLiveVideo.status == 1)
        ) {
          this.current = 2
        }
        if (
          res.data.mxhLiveVideo.type == 2 &&
          res.data.mxhLiveVideo.status == 0
        ) {
          this.current = 1
        }
        // this.detailsData.mxhLiveVideo.status = 0
        // 录播
        if (res.data.mxhLiveVideo.type == 1) {
          this.viedeList = res.data.mxhLiveVideoPlayList || []
          this.isLiveTemplate = false
        }

        // 预播结束
        if (
          res.data.mxhLiveVideo.type == 0 &&
          res.data.mxhLiveVideo.status == 2
        ) {
          this.viedeList = res.data.mxhLiveVideoPlayList || []
          this.isLiveTemplate = false
        }
        // 预播开始
        if (
          res.data.mxhLiveVideo.type == 0 &&
          res.data.mxhLiveVideo.status == 0
        ) {
          res.data.mxhLiveVideo.playUrl = res.data.mxhLiveVideo.replayUrl
          res.data.mxhLiveVideoPlayList = [res.data.mxhLiveVideo]
          this.viedeList = res.data.mxhLiveVideoPlayList || []
          this.isLiveTemplate = false
        }

        // 直播结束
        if (
          res.data.mxhLiveVideo.type == 2 &&
          res.data.mxhLiveVideo.status == 2
        ) {
          this.viedeList = res.data.mxhLiveVideoPlayList || []
          this.isLiveTemplate = false
        }

        this.$store.commit('setsignedVo', res.data.signedVo)
        this.$store.commit('setTopmesg', res.data.topMessage)
        this.$store.commit(
          'updateAllbannedSpeak',
          res.data.mxhLiveVideo.isForbidSendMsg
        )
        this.$store.commit('setUserLive', res.data.mxhLiveVideo.viewTotal)
        // this.allbannedSpeak = res.data.mxhLiveVideo.isForbidSendMsg

        this.share.banner = res.data.mxhLiveVideo.url

        this.$store.commit('resetCurrentConversation')
        this.ctx = wx.createLivePlayerContext('player')
        this.scrollViewHeight =
          wx.getSystemInfoSync().windowHeight -
          wx.getSystemInfoSync().windowWidth / 750 * (480 + 100) +
          'px'
        this.scrollViewHeight3 =
          wx.getSystemInfoSync().windowHeight -
          wx.getSystemInfoSync().windowWidth / 750 * (480 + 140) +
          'px'
        this.scrollViewHeight2 =
          wx.getSystemInfoSync().windowHeight -
          wx.getSystemInfoSync().windowWidth / 750 * 500 +
          'px'
        this.scrollViewHeight4 =
          wx.getSystemInfoSync().windowHeight -
          wx.getSystemInfoSync().windowWidth / 750 * 550 +
          'px'
        this.scrollViewHeight5 =
          wx.getSystemInfoSync().windowHeight -
          wx.getSystemInfoSync().windowWidth / 750 * 430 +
          'px'
        this.mxhUserInfo = wx.getStorageSync('mxhUserInfo')
          ? wx.getStorageSync('mxhUserInfo')
          : {}
        this.videoContext = wx.createVideoContext('myVideo')
        this.$store.commit('getIsExam', this.liveId)
        this.imLogin(this.mxhUserInfo.uuid || this.mxhUserInfo.openid)

        if (
          res.data.mxhLiveVideo &&
          res.data.mxhLiveVideo.mxhLiveVideoCollectInfoList
        ) {
          res.data.mxhLiveVideo.mxhLiveVideoCollectInfoList.forEach(
            (item, index) => {
              item.value = ''
            }
          )
        }

        /**
         * 播放类型 type=1 需要输入密码解锁
         * isPassword 是否已解密
         */
        if (res.data.mxhLiveVideoPlayType && res.data.isPassword == 0) {
          this.mxhLiveVideoPlayType = res.data.mxhLiveVideoPlayType
        } else {
          /**
           * 不需要解锁课程拉取其他信息
           */
          this.qtInfo()
        }
        if (res.data.mxhLiveVideo && !!res.data.mxhLiveVideo.filterWhiteList) {
          if (!this.isLogin()) {
            this.isLiveTemplate = false
            return false
          } else {
            this.colationMobile()
          }
        }
      })
    },
    colationMobile () {
      // 判断当前手机号是否为白名单用户
      let url = `/white/list/colation/mobile/${this.liveId}`
      this.$http.get(url).then(res => {
        if (!res.data.isWhiteList) {
          this.$store.commit('showToast', { title: '您不能观看当前节目' })
          setTimeout(() => {
            if (this.pagesLength == 1) {
              wx.redirectTo({
                url:
                  '/pages/personalHome/main?userId=' +
                  this.detailsData.mxhUserInfo.id
              })
            } else {
              wx.navigateBack({
                // 返回
                delta: 1
              })
            }
          }, 500)
        }
      })
    },
    /**
     * 其他不需要解锁信息
     */
    async qtInfo () {
      this.getHistory()
      this.opensettingCallback()
      await this.getOtherInteractive()
      await this.getStartInteractive()
      await this.getLiveStreamPull()
      this.getComment()
      this.getPpt()
    },
    /**
     * 切换tab
     */
    clickTab (index) {
      this.isQuizShow = false
      // if (index == 3 && this.current != 3) {
      //   this.timer = setInterval(() => {
      //     this.getPpt()
      //   }, 3000)
      // } else {
      //   clearInterval(this.timer)
      // }
      this.current = index
      if (index == 0) {
        // this.form.page = 1
        // this.commentList = []
        // console.log(22)
        // this.getComment()
      }

      if (index == 3) {
        this.atLocationPPT()
      } else {
        this.currentPageY = 0
      }
    },
    passwordShowContent () {},

    /**
     * 密码解锁课程
     */
    unlock () {
      if (this.detailsData.mxhLiveVideo.type == 1) {
        this.playListRewind()
      } else {
        this.getLivePull()
      }
    },

    /**
     * 点击关闭弹窗/开启弹窗
     */
    clickPasswordShow () {
      // if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
      //   this.$store.commit("setIsLogin", true);
      //   this.$store.commit('setIsLoginCallback', true)
      //   return false
      // }
      this.isPasswordShow = !this.isPasswordShow
    },
    /**
     * 密码获取录播视频信息
     */
    playListRewind () {
      let state = true
      this.detailsData.mxhLiveVideo.mxhLiveVideoCollectInfoList.forEach(
        item => {
          if (!item.value && state) {
            wx.showToast({
              title: '请填写' + item.text,
              icon: 'none'
            })
            state = false
            return false
          }
        }
      )
      if (state == false) {
        return false
      }
      if (!this.password) {
        this.$store.commit('showToast', {
          title: '请输入密码'
        })
        return false
      }

      let mxhLiveVideoCollectInfoList = []
      this.detailsData.mxhLiveVideo.mxhLiveVideoCollectInfoList.forEach(
        item => {
          mxhLiveVideoCollectInfoList.push({
            id: item.id,
            text: item.value
          })
        }
      )

      let url = '/liveVideo/get/play/list'
      let data = {
        liveId: this.liveId,
        mxhLiveVideoCollectInfoList: mxhLiveVideoCollectInfoList,
        password: this.password
      }
      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.viedeList = res.data
          this.mxhLiveVideoPlayType.type = ''
          this.clickPasswordShow()
          this.qtInfo()
        } else {
          this.$store.commit('showToast', {
            title: res.msg
          })
        }
      })
    },
    /**
     * 获取直播拉流信息
     */
    async getLiveStreamPull () {
      /**
       * information 连麦信息
       */
      if (this.information) {
        let id = 0
        if (
          this.information.otherUserLiveId &&
          this.information.otherUserLiveId != this.liveId
        ) {
          id = this.information.otherUserLiveId
        }
        if (
          this.information.otherUserLiveId &&
          this.information.liveId != this.liveId
        ) {
          id = this.information.liveId
        }
        if (!this.information.otherUserLiveId) {
          id = this.information.liveId + '_' + this.information.id
        }
        /**
         * 主播和主播连麦
         */
        let url = '/liveVideo/get/live/pull/' + id
        await this.$http.post(url).then(res => {
          this.$set(this.information, 'otherPlayUrl', res.data)
        })
      }

      /**
       * 普通正常直播
       */
      if (this.liveId) {
        let url = '/liveVideo/get/live/pull/' + this.liveId
        await this.$http.post(url).then(res => {
          this.playUrl = res.data
        })
      }
    },
    /**
     * 密码获取直播拉流信息
     */
    getLivePull () {
      let state = true
      this.detailsData.mxhLiveVideo.mxhLiveVideoCollectInfoList.forEach(
        item => {
          if (!item.value && state) {
            wx.showToast({
              title: '请填写' + item.text,
              icon: 'none'
            })
            state = false
            return false
          }
        }
      )
      if (state == false) {
        return false
      }

      let mxhLiveVideoCollectInfoList = []
      this.detailsData.mxhLiveVideo.mxhLiveVideoCollectInfoList.forEach(
        item => {
          mxhLiveVideoCollectInfoList.push({
            id: item.id,
            text: item.value
          })
        }
      )

      if (!this.password) {
        this.$store.commit('showToast', {
          title: '请输入密码'
        })
        return false
      }
      let url = '/liveVideo/get/live/pull/play'
      let data = {
        liveId: this.liveId,
        mxhLiveVideoCollectInfoList: mxhLiveVideoCollectInfoList,
        password: this.password
      }
      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.playUrl = res.data
          this.mxhLiveVideoPlayType.type = ''
          this.clickPasswordShow()
          this.qtInfo()
        } else {
          this.$store.commit('showToast', {
            title: res.msg
          })
        }
      })
    },
    async getUserSig (userID) {
      let url = '/im/get/userSig/' + userID
      return this.$http.post(url).then(res => {
        return res.data
      })
    },
    /**
     * 用户登录im
     */
    async imLogin (userID) {
      wx.$app
        .login({
          userID,
          userSig: await this.getUserSig(userID)
        })
        .then(() => {
          setTimeout(() => {
            this.joinGroup()
            this.imUpdateMyProfile()
          }, 1500)
        })
        .catch(() => {
          this.loading = false
        })
    },
    /**
     * im修改个人信息
     */
    imUpdateMyProfile () {
      let data = {
        nick: this.mxhUserInfo.nickName,
        avatar: this.mxhUserInfo.headImgurl
      }
      wx.$app
        .updateMyProfile(data)
        .then(res => {
          console.log('修改个人信息成功')
        })
        .catch(() => {})
    },
    /**
     * 加入聊天室
     */
    joinGroup () {
      try {
        wx.$app
          .joinGroup({
            groupID: this.liveId
          })
          .then(res => {
            this.$store.commit('updateGroupMemberProfile', this.liveId)
            this.$store.dispatch('checkoutConversation', `GROUP${this.liveId}`)
          })
          .catch(() => {})
      } catch (err) {}
    },
    /**
     * 发送im消息
     */
    imSendMessage (text) {
      if (!this.isnull(this.messageContent) || text == '签到') {
        const message = wx.$app.createTextMessage({
          to: this.liveId,
          conversationType: this.TIM.TYPES.CONV_GROUP,
          payload: {
            text: text == '签到' ? '签到' : this.messageContent
          }
        })
        let index = this.$store.state.conversation.currentMessageList.length
        this.$store.commit('sendMessage', message)
        wx.$app.sendMessage(message).catch(() => {
          this.$store.commit('changeMessageStatus', index)
        })
        this.messageContent = ''
      } else {
        this.$store.commit('showToast', {
          title: '消息不能为空'
        })
      }
    },
    isnull (content) {
      if (content === '') {
        return true
      }
      const reg = '^[ ]+$'
      const re = new RegExp(reg)
      return re.test(content)
    }
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    this.isSharePopup = false
    // 来自页面内转发按钮
    return {
      title: this.mxhUserInfo.nickName + '邀请您免费学习美学会精选好课',
      path: 'pages/details/main?liveId=' + this.liveId,
      imageUrl:
        this.share.banner +
        '?x-oss-process=image/resize,m_pad,h_400,w_500,color_FFFFFF',
      success: function (res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {
        }
      },
      fail: function () {
        // 转发失败之后的回调
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          // 用户取消转发
        } else if (res.errMsg == 'shareAppMessage:fail') {
          // 转发失败，其中 detail message 为详细失败信息
        }
      },
      complete: function () {
        // 转发结束之后的回调（转发成不成功都会执行）
      }
    }
  }
}
</script>
<style lang="less" scoped>
.close-full--t {
  position: absolute;
  left: 20px;
  top: 20px;
  z-index: 999;
  color: #fff;
}
section {
  min-height: 100vh;
  background: #f0f2f5;
}

.viewsNumber {
  padding: 0 20px;
  line-height: 48px;
  background: rgba(0, 0, 0, 1);
  opacity: 0.6;
  border-radius: 24px;
  font-size: 24px;
  font-weight: 500;
  color: rgba(255, 255, 255, 1);
  position: fixed;
  left: 30px;
  top: 30px;
  z-index: 2002;

  img {
    width: 20px;
    height: 24px;
    vertical-align: middle;
    margin-top: -3px;
    margin-right: 10px;
  }
}

.viewsNumberActive {
  transform: rotate(90deg);
  padding: 0 20px;
  line-height: 48px;
  background: rgba(0, 0, 0, 1);
  opacity: 0.6;
  border-radius: 24px;
  font-size: 24px;
  font-weight: 500;
  color: rgba(255, 255, 255, 1);
  position: fixed;
  right: 30px;
  top: 80px;
  z-index: 2002;

  img {
    width: 20px;
    height: 24px;
    vertical-align: middle;
    margin-top: -3px;
    margin-right: 10px;
  }
}

.beforeLive {
  width: 750px;
  height: 400px;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  z-index: 200;

  .beforeLive-img-content {
    position: absolute;
    left: 0;
    top: 0;
    width: 750px;
    height: 400px;
    display: block;
    z-index: 2;
    background: rgba(0, 0, 0, 0.5);
  }

  .pay {
    width: 192px;
    height: 64px;
    display: inline-block;
    vertical-align: middle;
  }

  .beforeLive-img {
    position: absolute;
    left: 0;
    top: 0;
    width: 750px;
    height: 400px;
    display: block;
    z-index: 1;
  }

  .livePlayer-content {
    position: fixed;
    z-index: 80;
    left: 0;
    top: 0;
  }

  .beforeLive-content {
    position: absolute;
    left: 50%;
    top: 80px;
    transform: translate(-50%, 0);
    z-index: 10;
    text-align: center;
    width: 90%;

    .button {
      display: inline-block;
    }

    .beforeLive-title {
      font-size: 32px;
      font-weight: bold;
      color: rgba(255, 255, 255, 1);
      text-align: center;
      margin-bottom: 10px;
    }

    .beforeLive-viewsNumber {
      padding: 0 20px;
      line-height: 48px;
      opacity: 0.6;
      border-radius: 24px;
      font-size: 24px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      margin-bottom: 10px;

      img {
        width: 20px;
        height: 24px;
        vertical-align: middle;
        margin-top: -3px;
        margin-right: 10px;
      }
    }

    .beforeLive-des {
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      margin-bottom: 40px;
    }

    .beforeLive-button {
      width: 240px;
      line-height: 68px;
      background: #d3a358;
      border-radius: 34px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      vertical-align: middle;
      margin-left: 30px;
    }

    .beforeLive-button.actived {
      background: rgba(43, 180, 233, 0.7);
    }
  }
}

.recorded {
  background: #f0f2f5;
  position: relative;

  .surface-img {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 10;
    width: 750px;
    height: 400px;

    .banner {
      width: 750px;
      height: 400px;
    }

    .pay {
      width: 192px;
      height: 64px;
      position: fixed;
      top: 300px;
      left: 30px;
      z-index: 2222;
    }
  }

  .recorded-video {
    width: 750px;
    height: 400px;
  }

  .recorded-fixed {
    position: fixed;
    left: 0;
    bottom: 0;
    padding: 0 30px;
    font-size: 28px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);
    line-height: 60px;
    background: #fff;
    width: 100%;

    span {
      color: #585858;
    }
  }

  .item-1 {
    background: #fff;
    padding: 0 30px;
    padding-top: 30px;
    margin-bottom: 20px;

    .ask-li {
      border: none;
    }
  }

  .item-2 {
    background: #fff;
    padding: 0 30px;
    padding-bottom: 1px;
    margin-bottom: 20px;
  }

  .item-3 {
    background: #fff;
    padding: 0 30px;
    padding-top: 30px;
    padding-bottom: 30px;

    .ask-course-title {
      font-size: 28px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      margin-bottom: 10px;
    }
  }
}

#shareCanvas {
  position: fixed;
  left: -10000px;
  bottom: -10000px;
}

.shareImg {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1000;
  width: 100vh;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);

  img {
    width: 650px;
    border-radius: 8px 8px 0px 0px;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 10;
  }
}

.live-content {
  width: 750px;
  min-height: 400px;
  background: #000;
  position: relative;

  .anchorLivePlayer {
    width: 375px;
    height: 224px;
    display: block;
    position: absolute;
    left: 0;
    top: 50%;
    transform: translate(0, -50%);
  }

  .otherPlayUrl {
    width: 375px !important;
    height: 224px !important;
    background: #ff0000;
    display: block;
    position: absolute;
    right: 0;
    top: 50%;
    transform: translate(0, -50%);
  }

  .userOtherPlayUrl {
    width: 160px;
    height: 240px;
    border-radius: 8px;
    display: block;
    position: absolute;
    right: 30px;
    top: 50px;
    z-index: 100;
  }

  .userOtherPlayerHorizontal {
    width: 160px;
    height: 240px;
    border-radius: 8px;
    display: block;
    position: fixed;
    z-index: 100;
    right: 130px;
    top: auto !important;
    bottom: 150px;
    transform: rotate(90deg);
  }
}

.livePlayer {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 80;
  width: 750rpx;
  height: 400rpx;
}

.live-player-content {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 100;
}

.playerHorizontal {
  width: 100vh;
  height: 100vh;
  z-index: 10;
}

.quiz {
  position: fixed;
  width: 100%;
  bottom: 0;
  left: 0;
  background: #fff;
  z-index: 600;

  .return {
    padding: 0 30px;
    line-height: 100px;
    font-size: 28px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
    border-bottom: 1px solid rgba(234, 234, 234, 1);
  }

  .quiz-text {
    padding: 0 30px;

    textarea {
      padding-top: 30px;
      height: 600px;
      font-size: 32px;
      font-weight: 500;
      line-height: 40px;
      color: #000;
    }
  }

  .quiz-button {
    width: 750px;
    line-height: 88px;
    background: #d3a358;
    font-size: 32px;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
    text-align: center;
  }
}

.examButton {
  width: 162px;
  height: 162px;
  position: fixed;
  bottom: 155px;
  right: 25px;
  z-index: 50;

  img {
    width: 162px;
    height: 162px;
    display: block;
  }
}

.goCurrentPage {
  position: absolute;
  right: 30px;
  bottom: 100px;
  width: 129px;
  height: 52px;
  z-index: 1000;

  img {
    display: block;
    width: 100%;
    height: 100%;
  }
}

.pptimg,
.pptimg2 {
  min-height: 390px;
  position: relative;
  padding-bottom: 20px;

  .ppt-content {
    position: relative;

    .currentPage {
      position: absolute;
      left: 40px;
      top: 40px;
      padding: 5px 10px 7px 10px;
      line-height: 1;
      background: #d3a358;
      border-radius: 4px;
      font-size: 24px;
      font-family: PingFang SC;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
    }
  }

  .lock {
    position: absolute;
    left: 0;
    top: 0;
    z-index: 100;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 1);

    img {
      width: 100px;
      height: 100px;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      z-index: 100;
      display: block;
    }
  }

  img {
    width: 100%;
    display: block;
  }
}

.shareButton {
  position: fixed;
  top: 30px;
  right: 30px;
  width: 45px;
  height: 45px;
  z-index: 1000;
}

section .stopButtonHorizontal {
  position: fixed;
  left: 40px;
  top: 40px;
  width: 29px;
  height: 38px;
  z-index: 1000;
  transform: rotate(90deg);
}

section .playButtonHorizontal {
  transform: rotate(90deg);

  position: fixed;
  left: 40px;
  top: 40px;
  width: 28px;
  height: 30px;
  top: none;
  z-index: 1000;
}

section .shrinkButtonHorizontal {
  position: fixed;
  right: 40px;
  top: 40px;
  z-index: 1000;
}

section .amplificationButtonHorizontal {
  position: fixed;
  left: 30px;
  bottom: 30px;
  width: 40px;
  height: 40px;
  top: none;
  z-index: 1000;
}

.stopButton {
  position: fixed;
  top: 320px;
  left: 37px;
  width: 29px;
  height: 38px;
  z-index: 100;
}

.playButton {
  position: fixed;
  top: 320px;
  left: 37px;
  width: 28px;
  height: 36px;
  z-index: 100;
  z-index: 100;
}

.amplificationButton {
  position: fixed;
  top: 320px;
  right: 37px;
  width: 40px;
  height: 40px;
  z-index: 100;
}

.shrinkButton {
  position: fixed;
  top: 320px;
  right: 37px;
  width: 40px;
  height: 40px;
  z-index: 100;
}

.popup-mask {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1000;
  width: 100vh;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
}

.share-popup {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 1000;
  width: 100%;
  background: rgba(234, 234, 234, 1);

  .share-content {
    width: 100%;
    overflow: hidden;
    background: #fff;
    padding-top: 35px;
    margin-bottom: 20px;
    padding-bottom: 25px;

    button.shareWeChat {
      display: block;
      padding-left: 0px;
      padding-right: 0px;
      line-height: 10px;
      background-color: rgba(255, 255, 255, 0);
    }

    button.shareWeChat::after {
      width: 0;
      height: 0;
      top: 0;
      left: 0;
      border: none;
    }

    .shareWeChat {
      display: block;
      float: left;
      width: 50%;

      img {
        display: block;
        width: 60px;
        margin: 0 auto;
        margin-bottom: 20px;
      }

      span {
        font-size: 24px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        line-height: 42px;
        display: block;
        text-align: center;
      }
    }

    .sharePosters {
      display: block;
      float: left;
      width: 50%;

      span {
        font-size: 24px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        line-height: 42px;
        display: block;
        text-align: center;
      }

      img {
        display: block;
        width: 60px;
        margin: 0 auto;
        margin-bottom: 20px;
      }
    }
  }

  .cancel {
    background: #fff;
    line-height: 80px;
    text-align: center;
    font-size: 30px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
  }
}

.tab {
  position: fixed;
  left: 0;
  top: 400px;
  width: 100%;
  background: #fff;
  z-index: 1;

  .li {
    width: 25%;
    text-align: center;
    font-size: 28px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
    float: left;
    line-height: 80px;
    position: relative;
  }

  .active {
    color: #d3a358;

    &:before {
      content: '';
      width: 100px;
      height: 4px;
      background: #d3a358;
      border-radius: 2px;
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translate(-50%, 0);
    }
  }
}

swiper {
  height: 100vh;
  padding-top: 480px;
  box-sizing: border-box;
  background: #fff;

  swiper-item {
    padding: 0 30px;
    box-sizing: border-box;
    padding-top: 20px;
    overflow-y: scroll;
  }
}

.im-content {
  .im-li {
    margin-bottom: 10px;
    word-wrap: break-word;
    word-break: normal;
    overflow: hidden;

    .im-name {
      font-size: 28px;
      font-weight: 500;
      color: #999;
      line-height: 42px;

      .im-name-sapn {
        vertical-align: middle;
        white-space: nowrap;
      }

      .identity-1 {
        color: #02ff83;
      }

      .identity-2 {
        color: #ff3600;
      }

      .identity-3 {
        color: #ff02a9;
      }
    }

    .im-text {
      vertical-align: middle;
      font-size: 30px;
      font-weight: 500;
      color: #585858;
      line-height: 42px;
    }
  }

  .im-li-2 {
    width: 100%;
    background: rgba(247, 249, 250, 1);
    border: 2px solid #d3a358;
    border-radius: 6px;
    font-size: 28px;
    font-weight: 500;
    color: #d3a358;
    line-height: 42px;
    padding: 20px;
    box-sizing: border-box;
  }
}

.ask-content {
  .ask-course-content {
    padding-top: 30px;

    .ask-course-title {
      font-size: 28px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      margin-bottom: 10px;
    }

    .ask-course-text {
      font-size: 26px;
      font-weight: 500;
      color: rgba(102, 102, 102, 1);
      line-height: 36px;
    }
  }

  .ask-title {
    font-size: 32px;
    font-weight: bold;
    color: rgba(34, 34, 34, 1);
    margin-bottom: 20px;
    text-align: justify;
  }

  .ask-li {
    border-bottom: 2px solid rgba(232, 232, 232, 1);
    padding-bottom: 20px;
    padding-top: 30px;

    img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      vertical-align: top;
      display: inline-block;
      margin-right: 20px;
    }

    .ask-character {
      width: 580px;
      vertical-align: top;
      display: inline-block;

      .ask-name {
        font-size: 28px;
        font-weight: 500;
        color: #666666;
        line-height: 45px;
      }

      .ask-text {
        font-size: 28px;
        font-weight: 500;
        color: #222222;
        line-height: 42px;

        .logo {
          width: 112px;
          height: 30px;
          vertical-align: middle;
          margin-top: -3px;
          border-radius: 0;
          margin-left: 10px;
        }

        span {
          float: right;
          width: 120px;
          line-height: 48px;
          background: #d3a358;
          border-radius: 0.04rem;
          text-align: center;
          color: #fff;
        }
      }

      .ask-number {
        overflow: hidden;
        width: 100%;
        margin-top: 25px;

        .fl {
          font-size: 24px;
          font-weight: 500;
          color: rgba(153, 153, 153, 1);
          line-height: 42px;
          float: left;
        }

        .fr {
          font-size: 24px;
          font-weight: 500;
          color: rgba(153, 153, 153, 1);
          line-height: 42px;
          float: right;
          margin-top: 5px;

          img {
            width: 28px;
            display: inline-block;
            vertical-align: middle;
            margin-right: 5px;
            border-radius: 0px;
            margin-top: -5px;
          }
        }

        .fr.active {
          color: #d3a358;
        }
      }
    }
  }
}

.input {
  position: fixed;
  bottom: 0px;
  left: 0;
  right: 0;
  height: 80px;
  background: rgba(234, 234, 234, 1);
  padding: 15px 12px;
  display: flex;
  z-index: 1;
  .signIn {
    width: 125px;
    margin-top: 8px;
    flex-shrink: 0;
    img {
      width: 42px;
      display: block;
      margin: 0 auto;
    }
    span {
      display: block;
      font-size: 24px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      line-height: 42px;
      text-align: center;
    }

    .signCard {
      color: #999;
    }
  }

  .message-input {
    margin-top: 8px;
    flex: 1;
    display: flex;
    input {
      /*width: 455px;*/
      height: 60px;
      border-radius: 30px;
      margin-top: 8px;
      background: #fff;
      line-height: 70px;
      border-radius: 30px;
      display: block;
      padding-left: 20px;
      box-sizing: border-box;
      display: inline-block;
      vertical-align: middle;
      margin-right: 20px;
      flex: 1;
    }
    span {
      margin-top: 8px;
      display: inline-block;
      width: 120px;
      line-height: 60px;
      background: #d3a358;
      border-radius: 30px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      text-align: center;
      vertical-align: middle;
      flex-shrink: 0;
    }
  }

  // input {
  //   margin-top: 8px;
  //   background: #fff;
  //   float: left;
  //   width: 595px;
  //   height: 60px;
  //   line-height: 70px;
  //   background: rgba(255, 255, 255, 1);
  //   border-radius: 30px;
  //   display: block;
  //   padding-left: 20px;
  //   box-sizing: border-box;
  // }

  .banned {
    flex: 1;
    /*width: 595px;*/
    height: 60px;
    line-height: 60px;
    background: rgba(248, 248, 248, 1);
    border-radius: 30px;
    font-size: 28px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);
    text-align: center;
    display: inline-block;
    margin-top: 8px;
  }
}

.ask-button {
  width: 750px;
  line-height: 88px;
  background: #d3a358;
  font-size: 32px;
  font-weight: 500;
  color: rgba(255, 255, 255, 1);
  position: fixed;
  bottom: 0;
  left: 0;
  text-align: center;
}

.pay-course-button {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  padding: 10px 0;
  background: #fff;

  .button {
    width: 690px;
    line-height: 80px;
    background: #d3a358;
    border-radius: 40px;
    font-size: 30px;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
    display: block;
    text-align: center;
    margin: 0 auto;
  }
}

.password {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 10000;
  width: 100vh;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);

  .content {
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 650px;
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;

    .title {
      font-size: 36px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      line-height: 36px;
      text-align: center;
      line-height: 120px;
    }

    .input2 {
      background: #fff;

      input {
        width: 570px;
        height: 80px;
        background: rgba(255, 255, 255, 1);
        border: 2px solid rgba(229, 229, 229, 1);
        border-radius: 40px;
        margin: 0 auto;
        padding-left: 20px;
        font-size: 30px;
      }
    }

    .button {
      border-top: 2px solid rgba(246, 246, 246, 1);
      overflow: hidden;
      margin-top: 60px;

      span {
        display: inline-block;
        width: 50%;
        float: left;
        text-align: center;
        line-height: 88px;
        border-right: 2px solid rgba(246, 246, 246, 1);
        box-sizing: border-box;
      }

      .noBorder {
        border: none;
        color: #d3a358;
      }
    }
  }
}

.button {
  overflow: hidden;

  span {
    display: inline-block;
    width: 50%;
    float: left;
    text-align: center;
    line-height: 88px;
    border-right: 2px solid rgba(246, 246, 246, 1);
    box-sizing: border-box;
  }

  .noBorder {
    border: none;
    color: #d3a358;
  }
}

.name,
.mobile,
.code {
  margin: 0 auto 40px;
  width: 570px;
  height: 80px;
  background: rgba(255, 255, 255, 1);
  border: 2px solid rgba(234, 234, 234, 1);
  border-radius: 6px;
  position: relative;
  border-radius: 40px;
  padding-left: 20px;
  span {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translate(0, -50%);
    z-index: 100;
    font-size: 28px;
    font-weight: 500;
    color: #d3a358;
    line-height: 80px;
    padding: 0 30px;
  }

  input {
    height: 80px;
    line-height: 80px;
    width: 400px;
    font-size: 30px;
  }
}
.topMsg {
  box-sizing: border-box;
  padding: 11px 92px 9px 46px;
  max-height: 120px;
  position: fixed;
  left: 0;
  right: 0;
  top: 480px;
  z-index: 1;
  background: url('https://resource.amez999.com/releasingGrass/1470436/2021/01/21/16570685686672937.png');
  background-size: 100% 100%;
  overflow-y: scroll;
  font-size: 24px;
  color: #9e6400;
  line-height: 35px;
  word-break: break-all;
  .topmsg_text {
    color: #fff;
  }
}
</style>
