<template>
  <section>
    <div class="text">
      <textarea name="" id="" cols="30" rows="10" class="textarea" placeholder="请输入你要举报的信息..." v-model="form.content"></textarea>
    </div>
    <div class="addImg">
      <div class="title">添加照片（最多3张图片）</div>
      <div class="addCard" v-for="(item,index) in form.complainantUrl" :key="index">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/del.png" alt="" class="del" @click="del(index)">
        <img :src="item" alt="" class="addCard">
      </div>
      <div class="addCard" @click="chooseImage(item)" v-if="form.complainantUrl.length < 3">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/addImage.png" alt="" class="addCard">
      </div>
    </div>
    <div class="button" @click="saveComplainant">提交</div>
  </section>
</template>
<script>
  import {
    baseURL
  } from '@/utils/domain.js'
  export default {
    data() {
      return {
        form: {
          complainantUrl: [],
          content: '',
        },
        oss: {},
        type: 0,
      }
    },
    onLoad(options) {
      this.liveId = options.liveId
      this.type = options.type ? options.type : 0
      this.getOssSts()
    },
    onUnload() {
      this.form = {
        complainantUrl: [],
        content: ''
      }
      this.oss = {}
    },
    methods: {
      del(index) {
        this.form.complainantUrl.splice(index, 1)
        let data2 = JSON.parse(JSON.stringify(this.form.complainantUrl))
        this.$set(this.form, 'complainantUrl', data2)
      },
      /**
       * 上传图片
       */
      chooseImage(url) {

        let token = wx.getStorageSync("token");
        var that = this;
        wx.chooseImage({
          count: 1,
          sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
          sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
          success: function(res) {
            let tempFilePaths = res.tempFilePaths[0]
            wx.uploadFile({
              url: baseURL + '/aliyun/oss/add/file', //上传到OSS
              filePath: tempFilePaths,
              name: 'file',
              header: {
                'authorization': token,
                'channel': 2,
              },
              success(res) {
                let data = JSON.parse(res.data)
                that.form.complainantUrl.push(data.data)
                let data2 = JSON.parse(JSON.stringify(that.form.complainantUrl))
                that.$set(that.form, 'complainantUrl', data2)
              },
            })
          }
        })


      },
      /**
       * 获取oss信息
       */
      async getOssSts() {
        let url = '/aliyun/oss/get/sts'
        await this.$http.get(url).then((res) => {
          if (res.code == 0) {
            this.oss = res.data
          }
        })
      },
      /**
       * 保存举报成功
       */
      async saveComplainant() {
        if (!this.form.content) {
          this.$store.commit('showToast', {
            title: '请填写举报信息'
          })
          return false
        }
        if (!this.form.complainantUrl.length) {
          this.$store.commit('showToast', {
            title: '请添加图片'
          })
          return false
        }
        let url = '/feedBack/saveFeedBack'
        let data = {
          imgUrlList: this.form.complainantUrl,
          content: this.form.content,
          type: this.type,
          itemId:this.liveId
        }

        // if (this.type == 0) {
        //   data['liveId'] = this.liveId
        // }
        // if (this.type == 1) {
        //   data['itemId'] = this.liveId
        // }

        await this.$http.post(url, data).then((res) => {
          if (res.code == 0) {
            this.$store.commit('showToast', {
              title: '保存举报成功'
            })
            setTimeout(() => {
              wx.navigateBack({
                delta: 1
              })
            }, 1000)
          }
        })
      }
    }
  }
</script>
<style scoped lang="less">
  section {
    background: #f0f2f5;
    min-height: 100vh;
  }

  .text {
    width: 750px;
    background: rgba(255, 255, 255, 1);
    border-top: 20px solid #f0f2f5;
    border-bottom: 20px solid #f0f2f5;
    padding: 20px;
    box-sizing: border-box;

    .textarea {
      width: 750px;
      height: 300px;
      line-height: 30px;
      background: rgba(255, 255, 255, 1);
    }
  }

  .addImg {
    background: #fff;
    padding-left: 20px;
    padding-bottom: 30px;

    .title {
      font-size: 28px;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
      line-height: 88px;
    }

    .addCard {
      width: 120px;
      height: 120px;
      display: inline-block;
      margin-right: 10px;
      margin-bottom: 10px;
      position: relative;

      .del {
        position: absolute;
        right: -15px;
        top: -15px;
        width: 40px;
        height: 40px;
        display: block;
        z-index: 10;
      }
    }
  }

  .button {
    width: 670px;
    line-height: 80px;
    background: #d3a358;
    border-radius: 40px;
    font-size: 32px;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
    text-align: center;
    margin: 0 auto;
    margin-top: 120px;
  }
</style>
