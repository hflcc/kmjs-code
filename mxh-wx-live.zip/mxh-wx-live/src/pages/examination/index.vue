<template>
  <section>
    <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/examination.png" class="examination">
    <div class="table">
      <div class="table-header">资料填写</div>
      <div class="name" v-for="(item,index) in videoData.mxhExamTextList"><input type="text" v-model="item.text" name=""
          :placeholder="item.examText" @input="getInputValue"></div>
      <div class="name"><input type="text" v-model="name" name="" placeholder="请填写您的姓名" @input="getInputValue"></div>

      <div class="mobile" v-if="!bingMobile"><input type="number" v-model="mobile" name="" placeholder="请填写您的手机号"
          @input="getInputValue">
        <span v-if="!isCodeDisabled" @click="getCode">获取验证码</span>
        <span v-if="isCodeDisabled">{{codeText}}</span>
      </div>
      <div class="name" v-if="bingMobile" style="background:#EAEAEA"><input type="text" name="" :placeholder="bingMobile"
          @input="getInputValue"></div>


      <!--       <div class="name"><input type="text" v-model="name" name="" placeholder="您的岗位名称" @input="getInputValue"></div> -->

      <div class="code" v-if="!bingMobile"><input type="number" v-model="code" name="" placeholder="请输入验证码" @input="getInputValue"></div>
      <button class="button" @click="bondUserInfoWithMobile" :class="isDisabled?'isDisabled':''" :disabled='isDisabled'
        v-if="!bingMobile">开始考试</button>
      <button class="button" @click="gotoAnswer" :class="isDisabled?'isDisabled':''" :disabled='isDisabled' v-if="bingMobile">
        开始考试</button>
    </div>
  </section>
</template>
<script>
  import {
    checkPhone
  } from './../../utils/index.js'
  export default {
    data() {
      return {
        name: '',
        mobile: wx.getStorageSync('mxhUserInfo').mobile,
        code: '',
        isDisabled: true,
        isFinish: false,
        liveId: '',
        loading: false,
        codeText: '',
        isCodeDisabled: false,
        bingMobile: wx.getStorageSync('mxhUserInfo').mobile,
        videoData: {
          mxhExamTextList: []
        }
      }
    },
    onLoad(options) {


      this.name = ''
      this.mobile = wx.getStorageSync('mxhUserInfo').mobile
      this.isDisabled = true
      this.isFinish = false
      this.code = ''
      this.bingMobile = wx.getStorageSync('mxhUserInfo').mobile
      this.liveId = options.liveId
      this.getVideoLive()
    },
    onUnload() {
      // this.isQuestion =true
      // this.page =null
      // this.currentTab =0
      // this.activeIdx =null

      this.goType = ''
    },
    methods: {
      // getUserInfoByToken(){
      //   let url = '/user/getUserInfoByToken'
      //   this.$http.get(url).then(res => {

      //   })
      // },
      bondUserInfoWithMobile() {
        if (!this.name) {
          wx.showToast({
            title: '请填写您的姓名',
            icon: 'none'
          })
          return false
        }
        if (this.mobile.length != 11) {
          wx.showToast({
            title: '请输入正确手机号码',
            icon: 'none'
          })
          return false
        }
        if (!this.code) {
          wx.showToast({
            title: '请输入验证码',
            icon: 'none'
          })
          return false
        }
        let url = '/user/bondUserInfoWithMobile'
        let data = {
          openid: wx.getStorageSync('openId'),
          mobile: this.mobile,
          verifyCode: this.code,
        }
        this.$http.post(url, data).then(res => {
          if (res.code == 0) {
            let mxhUserInfo = wx.getStorageSync('mxhUserInfo')
            mxhUserInfo.mobile = this.mobile
            wx.setStorageSync('mxhUserInfo', mxhUserInfo)
            this.gotoAnswer()

          }
        })
      },
      /**
       * 获取考试信息
       */
      getVideoLive() {
        let url = '/exam/get/videoLive/' + this.liveId
        this.$http.get(url).then(res => {
          if (res.code == 0) {
            res.data.mxhExamTextList.forEach((item) => {
              item.text = ''
            })
            this.videoData = res.data
          }
        })
      },
      // 开始考试
      gotoAnswer() {
        let state = true
        this.videoData.mxhExamTextList.forEach((item) => {
          if (!item.text && state) {
            wx.showToast({
              title: '请填写' + item.examText,
              icon: 'none'
            })
            state = false
            return false
          }
        })
        if (state == false) {
          return false
        }
        if (!this.name) {
          wx.showToast({
            title: '请填写您的姓名',
            icon: 'none'
          })
          return false
        }
        if (this.loading) {
          return false
        }
        this.loading = true

        let url = '/exam/get/videoLive/' + this.liveId
        this.$http.get(url).then(res => {
          this.loading = false
          if (res.code == 0 && res.data == 'ERROR') {
            wx.showToast({
              title: res.msg,
              icon: 'none'
            })
            return false
          }
          if (res.data.isExam == 1) {
            wx.showToast({
              title: '本场考试已作答',
              icon: 'none'
            })
            return false
          } else {
            wx.setStorageSync('name', this.name)
            wx.setStorageSync('mxhExamTextList', this.videoData.mxhExamTextList)
            wx.setStorageSync('mobile', this.mobile)
            wx.setStorageSync('startExamTime', new Date().getTime())
            wx.navigateTo({
              url: '/pages/answer/main?liveId=' + this.liveId
            })
            return true
          }
        })
      },
      /**
       * 发送验证码
       */
      async getCode() {
        if (this.mobile.length != 11) {
          wx.showToast({
            title: '请输入手机号码',
            icon: 'none'
          })
          // this.$toast.text('请输入手机号码')
          return
        }
        this.isCodeDisabled = true
        let res = await this.$http.post(`/user/verifyCode/${this.mobile}`)
        if (res.code == '0') {
          let timer = 60
          this.codeText = --timer + 's后重新发送'
          let timerId = setInterval(() => {
            if (timer <= 0) {
              timer = 60
              this.codeText = '重新发送'
              this.isCodeDisabled = false
              clearTimeout(timerId)
              timer = null
            } else {
              --timer
              this.codeText = timer + 's后重新发送'
            }
          }, 1000)
          wx.showToast({
            title: '成功',
            icon: 'none'
          })
          return false
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      },
      // 监听input值
      getInputValue() {
        let state = true
        this.videoData.mxhExamTextList.forEach((item) => {
          if (!item.text) {
            state = false
          }
        })

        if (checkPhone(this.mobile) && state) {
          this.isDisabled = false
        } else {
          this.isDisabled = true
        }
      }
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: #f5f5f5;
    height: 100vh;
  }

  .examination {
    width: 100%;
    height: 140px;
  }

  .table {
    width: 690px;
    padding-bottom: 100px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 4px 10px 0px rgba(218, 218, 218, 0.6);
    border-radius: 8px;
    margin: -20px auto 0;

    .table-header {
      font-size: 30px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      border-bottom: 2px solid #f6f6f6;
      height: 80px;
      line-height: 80px;
      padding-left: 20px;
      margin-bottom: 20px;

      &::before {
        content: "|";
        width: 6px;
        height: 32px;
        display: inline-block;
        color: #d3a358;
        margin-right: 10px;
      }
    }

    .name,
    .mobile,
    .code {
      margin: 40px auto 0;
      width: 624px;
      height: 80px;
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(234, 234, 234, 1);
      border-radius: 6px;
      position: relative;

      span {
        position: absolute;
        right: 20px;
        top: 50%;
        transform: translate(0, -50%);
        z-index: 100;
        font-size: 28px;
        font-weight: 500;
        color: #d3a358;
        line-height: 80px;
        padding: 0 30px;
      }

      input {
        height: 80px;
        line-height: 80px;
        padding-left: 30px;
        width: 400px;
      }
    }

    .button {
      width: 624px;
      height: 80px;
      line-height: 80px;
      border-radius: 40px;
      text-align: center;
      font-size: 28px;
      margin: 100px auto 0;
      background: #d3a358;
      color: #ffffff;
    }

    .isDisabled {
      color: #999999;
      background: rgba(234, 234, 234, 1);
    }
  }
</style>
