<template>
  <section class="content">
    <i-avideo-swiper :video-list="videos" :initial-index="initialIndex" @change="onChange" :duration="duration" :play="onPlay"
      :forward="onPanelForward">
      <course-video-content :liveCourseId="liveId" v-if="liveId"></course-video-content>
    </i-avideo-swiper>
    <div class="shade" v-if="isGuide">
      <div class="content">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/guide_button_1.png" class="guide_button_1">
        <div class="text">上下滑动可以切换视频噢~</div>
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/guide_button_2.png" class="guide_button_2" @click="clickGuide">
      </div>
    </div>
  </section>
</template>
<script>
  import courseVideoContent from './components/course-video-content'
  export default {
    data() {
      return {
        videos: [],
        videoIndex: 0,
        initialIndex: 0,
        duration: 500,
        form: {
          page: 1,
          size: 20
        },
        liveId: '',
        topicId: '',
        isGuide: false,
      }
    },
    components: {
      courseVideoContent
    },
    async onLoad(options) {
      this.topicId = options.topicId
      this.initialIndex = options.index
      this.form.size = 10
      this.form.page = 1
      this.videos = await this.getVideoList()
      if (!wx.getStorageSync('isGuide')) {
        wx.setStorageSync('isGuide', true)
        this.isGuide = wx.getStorageSync('isGuide')
        // setTimeout(()=>{this.isGuide=false},3000)
      } else {
        wx.setStorageSync('isGuide', true)
      }
    },
    onUnload() {
      this.topicId = ''
      this.initialIndex = 0
    },
    methods: {
      clickGuide() {
        this.isGuide = false
      },
      async getVideoList() {
        let url = '/liveVideo/get/topic/' + this.topicId + '/' + this.form.page + '/' + this.form.size
        return await this.$http.get(url).then(res => {
          const videos = [];
          if (res.data && res.data.length && !this.liveId) {
            this.liveId = res.data[0].id
          }
          res.data.forEach((item, index) => {
            if (item.mxhLiveVideoPlayList.length) {
              videos.push({
                // poster: item.backgroundUrl,
                src: item.mxhLiveVideoPlayList[0].playUrl,
                data: item,
              })
            }
          })
          this.form.size = 10
          return videos
        })
      },
      async onChange(e) {
        this.liveId = e.mp.detail.video.data.id + ''
        if ((this.videos.length - e.mp.detail.dataIdx) < 5) {
          this.form.page++
          let list = await this.getVideoList()
          this.videos = this.videos.concat(list)
        }
        wx.setStorageSync('videoIndex', e.mp.detail.dataIdx);
      },
      onPlay(e) {
        console.log('play', e.detail.video);
      },
      onPanelForward(e) {
        wx.showToast({
          title: 'panel事件：' + e.detail.video.title,
          icon: 'none'
        });
      },
    }
  }
</script>
<style scoped lang="less">
  section {
    height: 100vh;
    width: 100vh;
    overflow: hidden;
    background: #000;
  }

  live-player {
    height: 100%;
    width: 100%;
    display: block;
    background: red;
  }

  .liveEnd {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vh;
    height: 100vh;
    z-index: 1;

    .shade {
      position: fixed;
      left: 0;
      top: 0;
      z-index: 1;
      background: rgba(0, 0, 0, 1);
      opacity: 0.6;
      width: 100%;
      height: 100%;
    }

    .liveEndImg {
      position: fixed;
      left: 0;
      top: 0;
      width: 100%;
      z-index: 1;
    }

    span {
      position: fixed;
      z-index: 10;
      left: 50%;
      top: 400px;
      width: 100%;
      transform: translate(-50%, 0);
      text-align: center;
      color: #fff;
      font-size: 36px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
    }
  }

  #shareCanvas {
    position: fixed;
    left: -10000px;
    bottom: -10000px;
  }

  #floatCanvas {}

  #myVideo {
    height: 100vh;
    width: 100%;
    display: block;
  }

  .live-apply {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100vh;
    z-index: 200;

    .cover {
      position: fixed;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 100%;
    }

    .appply-conent {
      position: fixed;
      left: 0;
      top: 0;
      width: 100%;
      height: 100vh;
      z-index: 222;
      background: rgba(0, 0, 0, 0.6);
      text-align: center;

      .pay {
        width: 210px;
        display: inline-block;
        vertical-align: middle;
        margin-right: 20px;
      }

      .title {
        font-size: 32px;
        font-weight: bold;
        color: rgba(255, 255, 255, 1);
        padding-top: 280px;
      }

      .time {
        font-size: 28px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        line-height: 42px;
        padding-top: 50px;
      }

      .appply {
        width: 240px;
        line-height: 68px;
        background: #d3a358;
        border-radius: 34px;
        font-size: 28px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        text-align: center;
        margin-top: 70px;
        display: inline-block;
      }
    }

    .live-introduce {
      position: fixed;
      left: 50%;
      bottom: 0;
      transform: translate(-50%, 0);
      width: 690px;
      height: 538px;
      padding: 20px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 8px;
      z-index: 250;
      box-sizing: border-box;
      overflow-y: auto;

      .live-title {
        font-size: 32px;
        font-weight: bold;
        color: rgba(34, 34, 34, 1);
        margin-bottom: 35px;
        padding-top: 20px;
      }

      .live-des-title {
        font-size: 28px;
        font-weight: 500;
        color: #d3a358;
        margin-bottom: 25px;

        img {
          width: 32px;
          height: 32px;
          vertical-align: middle;
          margin-right: 20px;
          margin-top: -5px;
        }
      }

      .live-des-content {}
    }
  }

  .nav-fixed {
    position: fixed;
    top: 35px;
    left: 0;
    width: 100%;
    z-index: 10000;

    .goBack {
      width: 65px;
      height: 65px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 30px;
      margin-right: 20px;
    }

    .info {
      display: inline-block;
      vertical-align: middle;
      background: rgba(0, 0, 0, 0.3);
      border-radius: 32px;

      .head {
        width: 65px;
        height: 65px;
        border-radius: 100%;
        vertical-align: middle;
        display: inline-block;
        margin-right: 10px;
      }

      .content-head {
        width: 165px;
        display: inline-block;
        vertical-align: middle;
        margin-right: 10px;

        .name {
          font-size: 24px;
          font-weight: 500;
          color: rgba(255, 255, 255, 1);
          overflow: hidden;
          /*超出部分隐藏*/
          white-space: nowrap;
          /*不换行*/
          text-overflow: ellipsis;
          /*超出部分文字以...显示*/
        }

        .number {
          font-size: 20px;
          font-weight: 500;
          color: rgba(255, 255, 255, 1);
        }
      }

      .attention-button {
        margin-right: 10px;
        width: 78px;
        line-height: 52px;
        background: rgba(255, 255, 255, 1);
        border-radius: 26px;
        font-size: 24px;
        font-weight: 500;
        color: #d3a358;
        text-align: center;
        display: inline-block;
        vertical-align: middle;
      }
    }
  }

  .poster {
    position: fixed;
    left: 0;
    top: 10;
    height: 100vh;
    width: 100%;
    background: rgba(0, 0, 0, 0.6);
    z-index: 100;

    .poster-content {
      position: fixed;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);

      img {
        width: 650px;
        height: 620px;
        background: rgba(255, 255, 255, 1);
        border-radius: 8px;
        margin-bottom: 80px;
      }

      .poster-button {
        width: 650px;
        line-height: 80px;
        background: #d3a358;
        border-radius: 40px;
        text-align: center;
        font-size: 28px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
      }
    }
  }

  .comment-box {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 750px;
    height: 100px;
    background: rgba(255, 255, 255, 1);
    z-index: 300;
    animation: slideTop 0.2s;

    .comment-content {
      position: relative;
      height: 100px;
    }

    input {
      height: 100px;
      line-height: 100px;
      margin-left: 30px;
      width: 530px;
    }

    .send {
      position: absolute;
      right: 20px;
      top: 50%;
      transform: translate(0, -50%);
      width: 120px;
      line-height: 60px;
      background: #d3a358;
      border-radius: 30px;
      text-align: center;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
    }
  }

  .integralList {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    z-index: 100;
    animation: slideTop 0.2s;

    .integral-list-title {
      position: relative;
      background: rgba(255, 255, 255, 1);
      border-radius: 20px 20px 0px 0px;
      font-size: 32px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      line-height: 88px;

      span {
        display: block;
        margin: 0 30px;
        line-height: 88px;
        border-bottom: 2px solid rgba(234, 234, 234, 1);
      }

      .my-integral-number {
        position: absolute;
        right: 30px;
        top: 50%;
        transform: translate(0, -50%);
        font-size: 24px;
        font-weight: 500;
        color: #222;

        font {
          color: #d3a358;
        }
      }
    }

    .integral-li {
      background: #fff;
      height: 510px;

      .li {
        position: relative;
        overflow: hidden;
        margin: 0 30px;
        padding: 30px 0;
        border-bottom: 1px solid rgba(234, 234, 234, 1);

        .integral-img {
          width: 64px;
          height: 64px;
          border-radius: 10px;
          vertical-align: middle;
          display: inline-block;
        }

        .attention {
          position: absolute;
          top: 50%;
          right: 30px;
          transform: translate(0, -50%);
          width: 100px;
          line-height: 48px;
          background: #d3a358;
          border-radius: 24px;
          font-size: 24px;
          font-weight: 500;
          color: rgba(255, 255, 255, 1);
          text-align: center;
        }

        .attention.active {
          background: #666;
        }

        .li-content {
          margin-left: 20px;
          vertical-align: middle;
          display: inline-block;
          width: 500px;

          .li-title {
            font-size: 28px;
            font-weight: 500;
            color: rgba(34, 34, 34, 1);
            line-height: 40px;
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;

          }

          .li-des {
            font-size: 24px;
            font-weight: 500;
            color: rgba(153, 153, 153, 1);
            line-height: 70px;
          }

        }
      }

      .li:last-child {
        border-bottom: none;
      }
    }

  }

  .goodsList {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    z-index: 100;
    animation: slideTop 0.2s;

    .goods-list-title {
      background: rgba(255, 255, 255, 1);
      border-radius: 20px 20px 0px 0px;
      font-size: 32px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      line-height: 88px;

      span {
        display: block;
        margin: 0 30px;
        line-height: 88px;
        border-bottom: 2px solid rgba(234, 234, 234, 1);
      }
    }

    .goods-li {
      background: #fff;
      height: 710px;
      position: relative;

      .li {
        overflow: hidden;
        margin: 0 30px;
        padding: 30px 0;
        border-bottom: 1px solid rgba(234, 234, 234, 1);

        .number {
          display: block;
          position: absolute;
          width: 40px;
          line-height: 28px;
          background: rgba(0, 0, 0, 1);
          opacity: 0.4;
          border-radius: 8px 0px 8px 0px;
          z-index: 1;
          color: #fff;
          text-align: center;
          font-size: 20px;
        }

        .goods-img {
          width: 168px;
          height: 168px;
          border-radius: 10px;
          float: left;
        }

        .li-content {
          margin-left: 20px;
          float: left;
          width: 500px;

          .li-title {
            font-size: 28px;
            font-weight: 500;
            color: rgba(34, 34, 34, 1);
            line-height: 40px;
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
            height: 84px;
          }

          .li-lables {
            margin: 10px 0;

            .li-lable {
              padding: 0 10px;
              line-height: 35px;
              background: rgba(255, 255, 255, 1);
              border: 2px solid #d3a358;
              border-radius: 4px;
              font-size: 22px;
              font-weight: 500;
              color: #d3a358;
              display: inline-block;
            }
          }

          .li-operation {
            .li-price {
              font-size: 32px;
              font-weight: bold;
              color: rgba(232, 101, 81, 1);
              margin-right: 10px;
            }

            .li-button {
              width: 120px;
              line-height: 48px;
              background: rgba(232, 101, 81, 1);
              border-radius: 24px;
              font-size: 24px;
              font-weight: 500;
              color: rgba(255, 255, 255, 1);
              float: right;
              text-align: center;
              margin-top: -7px;
            }
          }

        }
      }

      .li:last-child {
        border-bottom: none;
      }
    }

  }

  .chat-content {
    position: fixed;
    left: 20px;
    bottom: 250px;
    height: 430px;
    z-index: 5;
    width: 540px;

    .chat-list {
      max-width: 540px;
      border-radius: 20px;
      color: #fff;
      font-size: 28px;
      max-width: 540px;
      border-radius: 20px;
      background: rgba(0, 0, 0, 0.2);
      padding: 10px 20px;
      box-sizing: border-box;
      margin-bottom: 15px;
      display: inline-block;

      .msgImg {
        width: 20px;
        height: 20px;
      }

      span {
        color: #d3a358;
        font-size: 28px;
      }

      .identity-1 {
        color: #02FF83;
      }

      .identity-2 {
        color: #FF3600;
      }

      .identity-3 {
        color: #FF02A9;
      }
    }
  }

  .button {
    position: fixed;
    bottom: 100px;
    left: 0;
    width: 100%;
    z-index: 10;

    .material {
      width: 110px;
      height: 110px;
      display: inline-block;
      vertical-align: bottom;
      margin: 0 25px;
      margin-top: 5px;
      position: relative;

      .goods {
        position: absolute;
        top: -240px;
        background: #fff;
        width: 580px;
        padding: 20px;
        box-sizing: border-box;
        border-radius: 10px;

        &:before {
          position: absolute;
          left: 24px;
          bottom: -16px;
          width: 0;
          height: 0;
          content: '';
          display: block;
          border-left: 16px solid transparent;
          border-top: 24px solid #fff;
          border-right: 16px solid transparent;
        }

        img {
          width: 176px;
          height: 176px;
          border-radius: 10px;
          display: inline-block;
          vertical-align: middle;
          margin-right: 10px;
        }

        .content {
          display: inline-block;
          width: 350px;
          vertical-align: middle;

          .title {
            font-size: 28px;
            font-weight: 500;
            color: rgba(51, 51, 51, 1);
            line-height: 38px;
            margin-bottom: 40px;
          }

          .price {
            font-size: 32px;
            font-weight: bold;
            color: rgba(255, 43, 93, 1);

            span {
              width: 120px;
              line-height: 48px;
              background: rgba(232, 101, 81, 1);
              border-radius: 24px;
              font-size: 24px;
              font-weight: 500;
              color: rgba(255, 255, 255, 1);
              display: inline-block;
              float: right;
              text-align: center;
            }

            img {
              width: 52px;
              height: 52px;
              float: right;
            }
          }
        }
      }

      img {
        width: 110px;
        height: 110px;
      }
    }

    .what {
      font-size: 28px;
      font-weight: 500;
      color: #fff;
      border-bottom: 2px solid rgba(255, 255, 255, 0.4);
      display: inline-block;
      vertical-align: middle;
      padding: 0 10px;
      padding-bottom: 15px;
    }

    .moreClose {
      width: 46px;
      height: 76px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 80px;
      margin-right: 20px;
      position: relative;

      img {
        display: block;
        width: 46px;
        height: 46px;
        margin-top: 15px;
      }

      .more-list {
        position: absolute;
        bottom: 0px;
        left: 50%;
        transform: translate(-50%, -120%);

        span {
          width: 80px;
          height: 80px;
          border-radius: 100%;
          background: #000;
          text-align: center;
          display: inline-block;
          line-height: 80px;
          color: #fff;
          font-size: 28px;
        }
      }
    }

    .more {
      width: 116px;
      height: 76px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 30px;

      img {
        display: block;
        width: 100%;
        height: 100%;
      }
    }

    .integral {
      width: 60px;
      height: 60px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 15px;

      img {
        display: block;
        width: 100%;
        height: 100%;
      }
    }

    .share {
      width: 56px;
      height: 56px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 35px;

      img {
        display: block;
        width: 100%;
        height: 100%;
      }
    }

    .like {
      width: 60px;
      height: 60px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 35px;

      img {
        display: block;
        width: 100%;
        height: 100%;
      }
    }
  }

  .button.liveAcitve {
    bottom: 20px !important;
  }



  .shrinkButton {
    position: fixed;
    top: 320px;
    right: 37px;
    width: 40px;
    height: 40px;
    z-index: 100;
  }

  .popup-mask {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
  }

  .share-popup {
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 1000;
    width: 100%;
    animation: slideTop 0.2s;

    .share-content {
      width: 100%;
      overflow: hidden;
      padding-top: 65px;
      padding-bottom: 60px;
      background: rgba(255, 255, 255, 1);
      border-radius: 20px 20px 0px 0px;
      border-bottom: 20px solid rgba(246, 246, 246, 1);

      button.shareWeChat {
        display: block;
        padding-left: 0px;
        padding-right: 0px;
        line-height: 10px;
        background-color: rgba(255, 255, 255, 0);
      }

      button.shareWeChat::after {
        width: 0;
        height: 0;
        top: 0;
        left: 0;
        border: none;
      }

      .shareWeChat {
        display: block;
        float: left;
        width: 50%;

        img {
          display: block;
          width: 60px;
          margin: 0 auto;
          margin-bottom: 20px;
        }

        span {
          font-size: 24px;
          font-weight: 500;
          color: rgba(34, 34, 34, 1);
          line-height: 42px;
          display: block;
          text-align: center;
        }
      }

      .sharePosters {
        display: block;
        float: left;
        width: 50%;

        span {
          font-size: 24px;
          font-weight: 500;
          color: rgba(34, 34, 34, 1);
          line-height: 42px;
          display: block;
          text-align: center;

        }

        img {
          display: block;
          width: 60px;
          margin: 0 auto;
          margin-bottom: 20px;
        }
      }
    }

    .cancel {
      background: #fff;
      line-height: 80px;
      text-align: center;
      font-size: 30px;
      font-weight: 500;
      color: rgba(34, 34, 34, 1);
    }
  }

  .live-content {
    background: #000;
    position: relative;
    width: 100%;
    height: 100%;
  }

  .bg {
    background: linear-gradient(0deg, rgba(41, 41, 55, 1) 0%, rgba(28, 31, 41, 1) 100%);
  }

  .userOtherPlayUrl {
    width: 160px;
    height: 240px;
    border-radius: 8px;
    display: block;
    position: absolute;
    right: 30px;
    top: 200px;
    z-index: 100;
  }

  .anchorLivePlayer {
    width: 375px;
    height: 620px;
    display: block;
    position: absolute;
    left: 0;
    top: 200px;
  }

  .otherPlayUrl {
    width: 375px;
    height: 620px;
    display: block;
    position: absolute;
    right: 0;
    top: 50%;
    transform: translate(0, -50%);
  }

  .ellipsis2 {
    text-overflow: -o-ellipsis-lastline;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .node-data {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    img {
      width: 247px;
      height: 221px;
      margin-bottom: 15px;
    }

    .text {
      font-size: 28px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      text-align: center;
    }
  }


  .shade {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 10000;
    background: rgba(0, 0, 0, 0.6);
    width: 100%;
    height: 100%;

    .content {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      z-index: 1000;

      .text {
        font-size: 36px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        line-height: 52px;
        padding-top: 40px;
        padding-bottom: 80px;
      }

      .guide_button_1 {
        width: 200px;
        height: 230px;
        display: inline-block;
      }

      .guide_button_2 {
        width: 289px;
        height: 121px;
        display: inline-block;
      }
    }
  }
</style>
