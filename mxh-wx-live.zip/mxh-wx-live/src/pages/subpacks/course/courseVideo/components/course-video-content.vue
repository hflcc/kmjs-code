<template>
  <section class="content">
    <div class="nav-fixed" :style="'top:' + (6 + statusBarHeight) + 'px'">
      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/goBack.png" alt="" class="goBack" @click="goBack">
      <div class="info">
        <img :src="detailsData.mxhUserInfo.headImgurl" alt="" class="head" @click="goEnterpriseHome(detailsData.mxhUserInfo)">
        <div class="content-head" @click="goEnterpriseHome(detailsData.mxhUserInfo)">
          <div class="name">{{detailsData.mxhUserInfo.nickName}}</div>
          <div class="number">{{userLiveNumber || 0}}观看</div>
        </div>
        <div class="attention-button" @click="saveMxhUserConcern" v-if="detailsData.isAttention == 0">关注</div>
        <!--             <div class="attention-button" @click="saveMxhUserConcern" v-if="detailsData.isAttention == 1">已关注</div> -->
      </div>
    </div>
<!--     <video v-if="!isLiveIng" :src="viedeList[videoIndex] ? viedeList[videoIndex].playUrl : ''" @ended="bindended" object-fit="cover" id="myVideo" @timeupdate="bindtimeupdate" autoplay="autoplay"></video> -->
    <!--  聊天 -->
    <scroll-view scroll-y="true" class="chat-content" :scroll-top="scrollTop">
      <div v-for="(item,index) in currentMessageList" :key="index" v-if="item.type == 'TIMTextElem'">
        <div class="chat-list">
          <div>
            <span v-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主讲人'" class="identity-1">主讲人：</span>
            <span v-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '主持人'" class="identity-2">主持人：</span>
            <span v-if="(item.flow == 'in' ? (item.nick || item.from) : (myInfo.nick || mxhUserInfo.nickName)) == '助教'" class="identity-3">助教：</span>
            <span v-else>{{item.flow == "in" ? item.nick : mxhUserInfo.nickName }} : </span>
            <font v-for="(div, index2) in item.virtualDom" :key="index2">
              <font v-if="div.name === 'span'">{{div.text}}</font>
              <image v-if="div.name === 'img'" :src="div.src" class="msgImg" />
            </font>
          </div>
        </div>
      </div>
    </scroll-view>
    <!-- 按钮 -->
    <div class="button" v-if="!isSendMsgIng" :class="isLiveIng ? 'liveAcitve' : ''">
      <div class="material" @click="clickMaterial">
        <div class="goods" v-if="liveGoods && liveGoods.id" @click.stop="goBuyGoods(liveGoods)">
          <img :src="liveGoods.goodsUrl" class="goodsImg">
          <div class="content">
            <div class="title ellipsis2">{{liveGoods.goodsName}}</div>
            <div class="price">￥{{liveGoods.goodsMoney}}<span>去看看</span></div>
          </div>
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/close.png" class="close" @click.stop="closeGoods">
        </div>
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/integral-material.png">
      </div>
      <div class="what" @click="clickSendMsg">{{ (allbannedSpeak || bannedSpeak ) ? '禁言中' : '说点什么吧' }}</div>
      <div class="more" v-if="!isMore" @click="clickMore"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/more.png"></div>
      <div class="moreClose" v-if="isMore">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/moreClose.png" @click="clickMore">
        <div class="more-list">
          <span @click="clickReport">举报</span>
        </div>
      </div>
      <div class="integral" @click="clickIntegral"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/verticalLive-integral.png"></div>
      <div class="share" @click="clickShare"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/verticalLive-share.png"></div>
      <div open-type="getPhoneNumber" class="like" @click="setLike" v-if="questionCount.likeCount == 0"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/verticalLive-like.png"></div>
      <div open-type="getPhoneNumber" class="like" @click="setLike" v-else><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/verticalLive-like-active.png"></div>
    </div>
    <!-- 发送消息 -->
    <div class="comment-box" v-if="isSendMsgIng" :style="'position:fixed;width:100%;bottom:' + bottom + 'px'">
      <div class="shade" @click="clickVideo"></div>
      <div class="comment-content">
        <input type="text" :adjust-position="isShowPopup" :hold-keyboard="true" placeholder="和老师说点什么..." v-model="messageContent" @confirm="imSendMessage" @focus="bindfocus" @blur="bindblur" :focus="isSendMsgIng" />
        <span class="send" @click="imSendMessage">发送</span>
      </div>
    </div>
    <!-- 学习积分 -->
    <div class="integralList" v-if="isIntegral">
      <div class="shade" @click="clickVideo"></div>
      <div class="integral-list-title">
        <span>学习积分</span>
        <div class="my-integral-number">我有：<font>{{userIntegral}} 积分</font>
        </div>
      </div>
      <scroll-view scroll-y="true" class="integral-li">
        <div class="li">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/study-attention.png" alt="" class="integral-img">
          <div class="li-content">
            <div class="li-title">关注老师</div>
            <div class="li-des">关注老师的美学课堂赠送<span>{{mxhLiveTask[0].taskScore}}</span>积分</div>
          </div>
          <div class="attention" @click.stop="saveMxhUserConcern" v-if="detailsData.isAttention==0">关注</div>
          <div class="attention" :class="detailsData.isAttention==1 ? 'active': ''" @click.stop="saveMxhUserConcern" v-if="detailsData.isAttention==1">已关注</div>
        </div>
        <div class="li">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/study-give.png" alt="" class="integral-img">
          <div class="li-content">
            <div class="li-title">为老师点赞 | 每点{{mxhLiveTask[1].scoreCount}}赞 +{{mxhLiveTask[1].taskScore}}积分</div>
            <div class="li-des">每场点赞上限<span>{{questionCount.likeCount}}</span>/{{mxhLiveTask[1].taskCount}}次</div>
          </div>
          <div class="attention" @click="setLike">点赞</div>
        </div>
        <div class="li">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/study-quiz.png" alt="" class="integral-img">
          <div class="li-content">
            <div class="li-title">向老师提问 | 每次提问 +{{mxhLiveTask[2].taskScore}}积分</div>
            <div class="li-des">每场提问上限<span>{{questionCount.questionCount}}</span>/10次</div>
          </div>
          <div class="attention" :class="(allbannedSpeak || bannedSpeak) ? 'active': ''" @click="goComment">{{(allbannedSpeak || bannedSpeak ) ? '禁言中' : '去提问'}}</div>
        </div>
      </scroll-view>
    </div>
    <!-- 商品推荐 -->
    <div class="goodsList" v-if="isMaterial">
      <div class="shade" @click="clickVideo"></div>
      <div class="goods-list-title"><span>相关资料 <font v-if="detailsData.mxhLiveVideoGoodsList && detailsData.mxhLiveVideoGoodsList.length">{{detailsData.mxhLiveVideoGoodsList.length}}</font></span></div>
      <scroll-view scroll-y="true" class="goods-li">
        <div class="li" v-for="(item,index) in detailsData.mxhLiveVideoGoodsList" :key="index" @click="goBuyGoods(item)">
          <div class="number">{{index+1}}</div>
          <img :src="item.goodsUrl" alt="" class="goods-img">
          <div class="li-content">
            <div class="li-title">{{item.goodsName}}</div>
            <div class="li-lables">
              <div class="li-lable" v-for="(actTag,i) in item.goodsLabel" :key="i">{{actTag}}</div>
            </div>
            <div class="li-operation">
              <span class="li-price">￥{{item.goodsMoney}}</span>
              <div class="li-button">去看看</div>
            </div>
          </div>
        </div>
        <div class="node-data" v-if="!detailsData.mxhLiveVideoGoodsList || !detailsData.mxhLiveVideoGoodsList.length">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/tz_icon%402x.png">
          <div class="text">暂无相关资料</div>
        </div>
      </scroll-view>
    </div>
    <!-- 分享按钮 -->
    <div class="share-popup" v-if="isShare">
      <div class="shade" @click="clickVideo"></div>
      <div class="share-content">
        <button class="shareWeChat" open-type='share'>
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/shareWeChat.png" mode="widthFix">
          <span>微信好友</span>
        </button>
        <div class="sharePosters" @click.stop="savePhoto">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/share%20Posters.png" mode="widthFix">
          <span>海报分享</span>
        </div>
      </div>
      <div class="cancel" @click="clickShare">取消</div>
    </div>
    <!--  海报 -->
    <div class="poster" v-if="isPoster">
      <div class="shade" @click="clickVideo"></div>
      <div class="poster-content">
        <img :src="canvasToImagePath" mode="widthFix">
        <div class="poster-button" @click="savePoster">保存海报</div>
      </div>
    </div>
    <!-- 飘浮canvas -->
    <canvas id="floatCanvas" type="2d" canvas-id="floatCanvas" style="width:100px;height:300px;position:fixed;right:0px;bottom:125rpx;z-index: 1;"></canvas>
    <!-- 分享图canvas -->
    <canvas id="shareCanvas" canvas-id="shareCanvas" style="width:650px;height:620px;background:rgba(255,255,255,1);border-radius:8px;"></canvas>
    <auth type="verticalLive"></auth>
    <bind-mobile v-if="isShowPopup"></bind-mobile>
  </section>
</template>
<script>
import { mapState } from 'vuex'
import { shopH5web } from '@/utils/domain.js'
import float from '@/utils/flutter-hearts-zmt.js'
import auth from '@/components/auth'
import bindMobile from '@/components/bindMobile'
export default {
  props: ['liveCourseId'],
  data() {
    return {
      videos: [],
      videoIndex: 0,
      duration: 500,
      form: {
        page: 1,
        size: 20
      },


      liveId: '', //直播id
      playUrl: '', //直播播放地址
      mxhUserInfo: {}, //用户信息
      userIntegral: 0, //用户积分数
      isMore: false,
      isSendMsgIng: false,
      isIntegral: false,
      isMaterial: false,
      isShare: false,
      isPoster: false,
      isAddPlayRecord: false,
      isLiveIng: true, // 是否直播
      isPayVideo: false, // 是否播放
      detailsData: { // 课程详情
        isAttention: 0,
        liveVideoUserVoList: [],
        mxhLiveVideoPlayList: [],
        mxhLiveVideoGoodsList: [],
        mxhLiveVideoSignCard: null,
        mxhLiveVideo: {},
        mxhUserInfo: {},
        isReservation: 0
      },
      messageContent: '', // 输入框消息
      share: { // 分享信息
        banner: '',
        avatar: '',
        qrcode: ''
      },
      canvasToImagePath: '', //分享图
      ctx: '',
      viedeList: [], //录播列表
      videoIndex: 0, //录播播放下标
      scrollTop: 9999,
      historyFrom: {
        page: 1,
        size: 100,
      },
      questionCount: {},
      images: [],
      bottom: 0,
      statusBarHeight: 0,
      bannedSpeak: false, // 是否禁言
      mxhLiveTask: [{}, {}, {}],
      information: null, //连麦信息
      liveGoodsTime: null,
    }
  },
  computed: {
    ...mapState({
      currentMessageList: state => { // im消息列表
        return state.conversation.currentMessageList
      },
      likeNum: state => state.conversation.likeNum, // 点赞数
      myInfo: state => state.user.myInfo, // im用户消息
      userLiveNumber: state => state.conversation.userLiveNumber, //直播观看人数
      updateLogin: state => state.conversation.updateLogin,
      liveGoods: state => state.conversation.liveTipsGoods,
      isShowPopup: state => state.global.isShowPopup,
    })
  },
  components: {
    auth,
    bindMobile
  },
  watch: {
    liveCourseId: async function() {
      this.liveId = this.liveCourseId
      this.$store.commit('setColseLive', 2)
      this.loginCallbackFn()
      this.videos = await this.getVideoList()
    },
    currentMessageList: function() {
      this.$set(this, 'scrollTop', ++this.scrollTop)
    },
    likeNum: function() {
      this.clickFloat()
    },
    updateLogin: function() {
      let pages = getCurrentPages();
      let currPage = null;
      if (pages.length) {
        currPage = pages[pages.length - 1];
      }
      if (currPage.route == 'pages/verticalLive/main') {
        this.loginCallbackFn()
      }
    },
  },
  async created(options) {
    this.statusBarHeight = wx.getSystemInfoSync()['statusBarHeight']
    this.liveId = this.liveCourseId + ''
    this.$store.commit('setColseLive', 2)
    this.loginCallbackFn()
    this.videos = await this.getVideoList()
  },
  methods: {
    /**
     * 登录回调初始化内容
     */
    async loginCallbackFn() {
      this.ctx = wx.createLivePlayerContext('player')
      this.videoContext = wx.createVideoContext('myVideo')
      this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
      await this.getOtherInteractive()
      await this.getStartInteractive()
      this.clickPlayer()
      this.getHistory()
      this.getLiveStreamPull()
      this.getLiveVideo()
      this.findMxhPointNotParam()
      this.findLikeAndQuestionCount()
      this.getFloatImg()
      this.getMxhLiveTaskList()
      this.$store.commit('updateGroupMemberProfile', this.liveId)
      this.$store.commit('loginCallback', false)
    },
    /**
     * 获取直播商品列表
     */
    getLiveGoodsList() {
      let url = '/liveVideo/get/' + this.liveId
      let data = {}
      this.$http.post(url).then((res) => {
        res.data.mxhLiveVideoGoodsList.forEach((item) => {
          if (item.goodsLabel) {
            item.goodsLabel = item.goodsLabel.split(',')
          } else {
            item.goodsLabel = []
          }
        })
        let mxhLiveVideoGoodsList = res.data.mxhLiveVideoGoodsList ? res.data.mxhLiveVideoGoodsList : []
        this.$set(this.detailsData, 'mxhLiveVideoGoodsList', mxhLiveVideoGoodsList)
        this.$set(this.detailsData, 'mxhLiveVideoGoodsList', mxhLiveVideoGoodsList)
      })
    },
    /**
     * 获取正在申请PK的互动连麦的信息
     */
    async getOtherInteractive() {
      if (this.liveId) {
        let url = '/liveVideo/interactive/get/other/interactive/' + this.liveId
        let data = {}
        await this.$http.post(url, data).then((res) => {
          if (res.data) {
            this.information = res.data[0]
          }
        })
      }
    },
    /**
     * 获取正在互动连麦的信息
     * @return {[type]}
     */
    async getStartInteractive() {
      let url = '/liveVideo/interactive/get/start/interactive/' + this.liveId
      let data = {}
      await this.$http.post(url, data).then((res) => {
        if (res.data) {
          this.information = res.data
        }
      })
    },

    goEnterpriseHome(item) {
      if (item.corporateType == 1) {
        wx.navigateTo({
          url: '/pages/enterpriseHome/main?userId=' + item.id
        })
      } else {
        wx.navigateTo({
          url: '/pages/personalHome/main?userId=' + item.id
        })
      }
    },
    payVideo() {
      this.isPayVideo = true
      this.videoContext.play()
    },
    /**
     * 马上报名
     */
    applyName() {
      let that = this
      let str = 'jGJW2VkF2uI32aczWoI6aVyvvLzksx9tteHAkyj9yPY' //xxx是模板id
      wx.requestSubscribeMessage({
        tmplIds: [str], // 此处可填写多个模板 ID，但低版本微信不兼容只能授权一个
        success(res) {
          //'accept'表示用户接受；'reject'表示用户拒绝；'ban'表示已被后台封禁
          if (res[str] == 'accept') {
            let url = '/liveVideo/add/user/reservation'
            let data = {
              liveVideoId: that.liveId,
            }
            that.$http.post(url, data).then((res) => {
              if (res.code == 0) {
                that.detailsData.isReservation = 1
                that.$store.commit('updateAddUserLive')
              }
            })
          }
        },
      })
    },
    /**
     * 保存海报
     */
    savePoster() {
      wx.saveImageToPhotosAlbum({
        filePath: this.canvasToImagePath,
        success() {
          wx.showToast({
            title: '已保存到相册',
          })
        },
        fail(res) {

        }
      })
    },
    /**
     * 点击浮动效果
     */
    clickFloat() {
      if (!this.images.length) {
        return
      }
      var random = {
        uniform: function(min, max) {
          return min + (max - min) * Math.random();
        },
        uniformDiscrete: function(i, j) {
          return i + Math.floor((j - i + 1) * random.uniform(0, 1));
        },
      };
      this.stage.bubble(this.images[random.uniformDiscrete(0, this.images.length - 1)]);
    },
    getFloatImg() {
      let that = this
      const query = wx.createSelectorQuery()
      query.select('#floatCanvas')
        .fields({ node: true, size: true })
        .exec((res) => {
          const width = res[0].width
          const height = res[0].height
          var canvas = res[0].node
          var context = canvas.getContext("2d")
          wx.appCanvas = res[0].node
          const dpr = wx.getSystemInfoSync().pixelRatio
          canvas.width = width * dpr
          canvas.height = height * dpr
          context.scale(dpr, dpr)
          var assets = [
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-1.png',
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-2.png',
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-3.png',
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-4.png',
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-5.png',
            'https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/float-6.png',
          ];
          that.stage = new float.BubbleHearts();
          assets.forEach(function(src, index) {
            assets[index] = new Promise(function(resolve) {
              const img = canvas.createImage()
              img.src = src
              img.onload = resolve.bind(null, img);
            });
          });
          Promise.all(assets).then(function(images) {
            that.images = images
          })
        })
    },
    /**
     * 返回
     */
    goBack() {
      let pages = getCurrentPages()
      if (pages.length >= 2) {
        wx.navigateBack({
          delta: 1
        })
      } else {
        wx.reLaunch({
          url: '/pages/home/main'
        })
      }
    },
    isLogin() {
      let mxhUserInfo = wx.getStorageSync("mxhUserInfo")
      if (!mxhUserInfo || (mxhUserInfo && !mxhUserInfo.id)) {
        this.$store.commit("setIsLogin", false);
        this.clickPlayer()
        return false
      }
      if (!mxhUserInfo || (mxhUserInfo && !mxhUserInfo.mobile)) {
        this.$store.commit('setShowPopup', true)
        this.clickPlayer()
        return false
      }
      return true
    },
    /**
     * 去提问
     */
    goComment() {
      if (!this.isLogin()) {
        return false
      }
      this.isIntegral = false
      this.clickSendMsg()
    },
    /**
     * 获取积分列表弹窗详情数据
     */
    async findLikeAndQuestionCount() {
      let url = 'liveLike/findLikeAndQuestionCount/' + this.liveId
      await this.$http.get(url).then((res) => {
        if (res.code == 0) {
          this.$set(this, 'questionCount', res.data)
          // this.questionCount = res.data
        }
      })
    },
    /**
     * 点赞
     */
    async setLike() {

      if (!this.isLogin()) {
        return false
      }

      let url = '/comment/set/like'
      let data = {
        likeItemId: this.liveId,
        id: this.liveId,
        type: 1,
      }
      await this.$http.post(url, data).then((res) => {
        if (res.code == 0) {
          if (this.questionCount.likeCount < this.mxhLiveTask[1].taskCount) {
            // this.$set(this,'userIntegral',(this.userIntegral + 1))
            this.$set(this.questionCount, 'likeCount', ++this.questionCount.likeCount)
            // this.findLikeAndQuestionCount()
            this.findMxhPointNotParam()
          }
        }
      })
    },
    /**
     * 关注主播
     */
    async saveMxhUserConcern() {

      if (!this.isLogin()) {
        return false
      }

      let url = '/userConcern/saveMxhUserConcern'
      let data = {
        liveVideoId: this.liveId,
        concernUserName: this.detailsData.mxhUserInfo.nickName,
        concernUserId: this.detailsData.mxhUserInfo.id,
      }
      await this.$http.post(url, data).then((res) => {
        if (res.code == 0) {
          this.detailsData.isAttention = (this.detailsData.isAttention == 0 ? 1 : 0)
          this.findMxhPointNotParam()
        }
      })
    },

    /**
     * 积分详情
     */
    async getMxhLiveTaskList() {
      let url = '/mxhLiveTask/getMxhLiveTaskList/' + this.liveId
      await this.$http.get(url).then((res) => {
        if (res.code == 0 && res.data && res.data.length) {
          this.mxhLiveTask = res.data
        }
      })
    },
    /**
     * 获取用户积分
     */
    async findMxhPointNotParam() {
      let url = '/point/findMxhPointNotParam'
      await this.$http.get(url).then((res) => {
        if (res.code == 0) {
          this.userIntegral = res.data ? res.data.usableCredit : 0
        }
      })
    },
    /**
     * 去看看
     */
    goBuyGoods(item) {
      if (item.path) {
        wx.setStorageSync('url', item.path)
        wx.navigateTo({
          url: '/pages/webView/main'
        })
      }
    },
    /**
     * 点击生成海报图
     */
    async savePhoto() {
      wx.showLoading({
        title: '正在生成分享图片...',
        mask: true
      })
      await this.getCode()
      this.coreCanvas()
    },
    /**
     * 获取微信二维码
     */
    async getCode() {
      let url = '/wechat/get/code'
      let data = {
        path: 'pages/verticalLive/main?liveId=' + this.liveId,
        width: 140,
      }
      await this.$http.post(url, data).then((res) => {
        if (res.code == 0) {
          this.share.qrcode = res.data
        }
      })
    },
    getImgInfo(url) {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            resolve(res)
          }
        });
      })
    },
    /**
     * 生成图片核心
     */
    coreCanvas() {
      let that = this
      let ctx = wx.createCanvasContext('shareCanvas')
      Promise.all([
        this.getImgInfo(this.share.banner.replace('http:', 'https:')),
        this.getImgInfo(this.mxhUserInfo.headImgurl.replace('http:', 'https:')),
        this.getImgInfo(this.share.qrcode.replace('http:', 'https:')),
      ]).then(results => {

        let banner = results[0]
        let avatar = results[1]
        let qrcode = results[2]

        /**
         * 背景颜色
         */
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, 650, 620);
        ctx.save();
        ctx.beginPath(); //开始绘制


        /**
         * 标题
         */
        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#fff') // 文字颜色：黑色
        // ctx.setFontSize(32) // 文字字号：22px
        // ctx.fillText("法律大讲堂，智慧普法教育", 30, 340)

        /**
         * 绘制名称
         */
        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#222222') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText(this.mxhUserInfo.nickName, 132, 450)


        this.detailsData.mxhLiveVideo.text.length > 10 ? this.detailsData.mxhLiveVideo.text = this.detailsData.mxhLiveVideo.text.substr(0, 9) + '...' : ''
        ctx.setTextAlign('left') // 文字居中
        ctx.setFillStyle('#999999') // 文字颜色：黑色
        ctx.setFontSize(28) // 文字字号：22px
        ctx.fillText(this.detailsData.mxhLiveVideo.text, 132, 490)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#d3a358') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("美学会", 328, 490)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#999999') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("精选好课", 413, 490)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#222222') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("扫描学习新知识", 192, 615)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#222222') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("开课后免费学习", 192, 670)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#d3a358') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("美学会", 388, 670)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#222222') // 文字颜色：黑色
        // ctx.setFontSize(28) // 文字字号：22px
        // ctx.fillText("课程", 473, 670)



        /**
         * 右边头像
         */
        var avatarurl_width2 = 80; //绘制的头像宽度
        var avatarurl_heigth2 = 80; //绘制的头像高度
        var avatarurl_x2 = 30; //绘制的头像在画布上的位置
        var avatarurl_y2 = 420; //绘制的头像在画布上的位置
        ctx.arc(avatarurl_width2 / 2 + avatarurl_x2, avatarurl_heigth2 / 2 + avatarurl_y2, avatarurl_width2 / 2, 0, Math.PI * 2, false);
        ctx.fill()
        ctx.clip(); //画好了圆 剪切  原始画布中剪切任意形状和尺寸。一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内 这也是我们要save上下文的原因
        ctx.drawImage(avatar.path, avatarurl_x2, avatarurl_y2, avatarurl_width2, avatarurl_heigth2)
        ctx.restore();
        ctx.setStrokeStyle('#fff')


        ctx.drawImage(qrcode.path, 470, 417, 160, 160)

        /**
         * 绘制banner
         */
        ctx.drawImage(banner.path, 0, 0, 650, 390)

        // ctx.setTextAlign('left') // 文字居中
        // ctx.setFillStyle('#fff') // 文字颜色：黑色
        // ctx.setFontSize(32) // 文字字号：22px
        // let text = this.detailsData.mxhLiveVideo.title.length > 10 ? this.detailsData.mxhLiveVideo.title.substring(0, 10) + '...' : this.detailsData.mxhLiveVideo.title
        // ctx.fillText(this.detailsData.mxhLiveVideo.title, 30, 363)

        // ctx.moveTo(30, 530);
        // ctx.lineTo(620, 530);
        // ctx.lineWidth = 2;
        // ctx.strokeStyle = "#EAEAEA";


        ctx.stroke()
        ctx.draw()

        setTimeout(() => {
          wx.canvasToTempFilePath({
            width: 650,
            height: 620,
            canvasId: 'shareCanvas',
            success(res) {
              wx.hideLoading()
              that.canvasToImagePath = res.tempFilePath
              that.isPoster = true
              that.isShare = false

            }
          })
        }, 1000)

      })
    },
    bindfocus(e) {
      this.bottom = e.mp.detail.height
    },
    bindblur() {
      this.bottom = 0
    },
    /** 
     * 发送im消息
     */
    imSendMessage(text) {
      if (!this.isLogin()) {
        return false
      }
      if (!this.isnull(this.messageContent) || text == '签到') {
        const message = wx.$app.createTextMessage({
          to: this.liveId,
          conversationType: this.TIM.TYPES.CONV_GROUP,
          payload: { text: text == '签到' ? '签到' : this.messageContent }
        })
        let index = this.$store.state.conversation.currentMessageList.length
        this.$store.commit('sendMessage', message)
        wx.$app.sendMessage(message).catch(() => {
          this.$store.commit('changeMessageStatus', index)
        })
        this.messageContent = ''
        if (this.questionCount.questionCount < 10) {
          this.findMxhPointNotParam()
          this.$set(this.questionCount, 'questionCount', ++this.questionCount.questionCount)
        }
        this.isSendMsgIng = false
      } else {
        this.$store.commit('showToast', { title: '消息不能为空' })
      }
    },
    isnull(content) {
      if (content === '') {
        return true
      }
      const reg = '^[ ]+$'
      const re = new RegExp(reg)
      return re.test(content)
    },
    /**
     * 获取直播拉流信息
     */
    getLiveStreamPull() {
      /**
       * information 连麦信息
       */
      if (this.information) {
        let id = 0
        if (this.information.otherUserLiveId && this.information.otherUserLiveId != this.liveId) {
          id = this.information.otherUserLiveId
        }
        if (this.information.otherUserLiveId && this.information.liveId != this.liveId) {
          id = this.information.liveId
        }
        if (!this.information.otherUserLiveId) {
          id = this.information.liveId + '_' + this.information.id
        }
        /**
         * 主播和主播连麦
         */
        if (id) {
          let url = '/liveVideo/get/live/pull/' + id
          this.$http.post(url).then((res) => {
            console.log(res.data, 2222)
            this.$set(this.information, 'otherPlayUrl', res.data)
          })
        }

      }

      if (this.liveId) {
        let url = '/liveVideo/get/live/pull/' + this.liveId
        this.$http.post(url).then((res) => {
          this.playUrl = res.data
          this.imLogin()
        })
      }

    },
    /**
     * 用户登录im
     */
    async imLogin() {
      if (this.mxhUserInfo && (this.mxhUserInfo.uuid || this.mxhUserInfo.openid)) {
        let userID = (this.mxhUserInfo.uuid || this.mxhUserInfo.openid)
        wx.$app.login({
          userID,
          userSig: await this.getUserSig(userID)
        }).then(() => {
          this.joinGroup()
          this.imUpdateMyProfile()
        }).catch(() => {
          this.loading = false
        })
      }
    },
    /**
     * 获取登录userSig
     */
    async getUserSig(userID) {
      let url = '/im/get/userSig/' + userID
      return this.$http.post(url).then((res) => {
        return res.data
      })
    },
    /**
     * 加入聊天室
     */
    joinGroup() {
      try {
        wx.$app.joinGroup({ groupID: this.liveId })
          .then((res) => {
            this.$store.commit('updateGroupMemberProfile', this.liveId)
            this.$store.dispatch('checkoutConversation', `GROUP${this.liveId}`)
          }).catch((res) => {
            console.log(5555555555555)
            this.$store.commit('updateGroupMemberProfile', this.liveId)
            this.$store.dispatch('checkoutConversation', `GROUP${this.liveId}`)
          })
      } catch (err) {

      }
    },
    /**
     * im修改个人信息
     */
    imUpdateMyProfile() {
      if (this.mxhUserInfo.nickName && this.mxhUserInfo.nickName.indexOf('1') == 0 && this.mxhUserInfo.nickName.length == 11) {
        this.mxhUserInfo.nickName = (this.mxhUserInfo.nickName.substr(0, 3) + "****" + this.mxhUserInfo.nickName.substr(7))
      }
      let data = {
        nick: this.mxhUserInfo.nickName,
        avatar: this.mxhUserInfo.headImgurl,
      }
      wx.$app.updateMyProfile(data)
        .then((res) => {
          console.log('修改个人信息成功')
        }).catch(() => {})
    },
    /**
     * 点击推荐商品
     */
    clickMaterial() {
      this.isMaterial = !this.isMaterial
    },
    /**
     * 点击更多
     */
    clickMore() {
      this.isMore = !this.isMore
    },
    /**
     * 点击举报
     */
    clickReport() {
      wx.navigateTo({
        url: '/pages/report/main?type=0&liveId=' + this.liveId
      })
    },
    /**
     * 点击积分
     */
    clickIntegral() {
      this.isIntegral = !this.isIntegral
    },
    /**
     * 点击分享
     */
    clickShare() {
      this.isShare = !this.isShare
    },
    /**
     * 点击发消息
     */
    clickSendMsg() {
      if (!(this.allbannedSpeak || this.bannedSpeak)) {
        this.isSendMsgIng = !this.isSendMsgIng
      }
    },
    /**
     * 获取im历史消息
     */
    getHistory() {
      let url = '/liveVideo/msg/get/' + this.liveId + '/' + this.historyFrom.page + '/' + this.historyFrom.size
      this.$http.post(url).then((res) => {
        if (res.code == 0) {
          let historyList = [{
            "type": "enterInform"
          }]
          res.data.forEach((item, key) => {
            historyList.unshift({
              "flow": this.mxhUserInfo.id == item.userId ? 'out' : 'in',
              "from": item.nickName,
              "nick": item.nickName,
              "type": item.type,
              "payload": {
                "text": item.msgText
              },
              "virtualDom": [{
                "name": item.type == 'TIMTextElem' ? "span" : "img",
                "text": item.msgText
              }]
            })
          })
          this.$store.commit('resetCurrentConversation')
          this.$store.commit('unshiftMessageList', historyList)
        }
      })
    },
    /**
     * 获取课程详情
     */
    getLiveVideo() {
      let url = '/liveVideo/get/' + this.liveId
      this.$http.post(url).then((res) => {
        if (res.data.mxhLiveVideo && res.data.mxhLiveVideo.startTime) {

          //结束时间
          var startTime = new Date(res.data.mxhLiveVideo.startTime.replace(/-/g, '/')).getTime();
          //当前时间
          var nowDate = new Date().getTime();
          //相差的总秒数
          res.data.mxhLiveVideo.broadcast = (startTime - nowDate)

          res.data.mxhLiveVideo.startTime = res.data.mxhLiveVideo.startTime.substr(5, 2) + '月' + res.data.mxhLiveVideo.startTime.substr(8, 2) + '日' + ' ' + res.data.mxhLiveVideo.startTime.substr(10, 6)
        }

        if (res.data.mxhLiveVideo.text) {
          res.data.mxhLiveVideo.text = res.data.mxhLiveVideo.text.replace(/\<img/gi, '<img style="max-width:100%;height:auto" ')
        }

        this.detailsData = {
          mxhLiveVideo: res.data.mxhLiveVideo ? res.data.mxhLiveVideo : {},
          mxhUserInfo: res.data.mxhUserInfo ? res.data.mxhUserInfo : {},
          mxhLiveVideoSignCard: res.data.mxhLiveVideoSignCard ? res.data.mxhLiveVideoSignCard : null,
          mxhLiveVideoPlayList: res.data.mxhLiveVideoPlayList ? res.data.mxhLiveVideoPlayList : [],
          liveVideoUserVoList: res.data.liveVideoUserVoList ? res.data.liveVideoUserVoList : [],
          isReservation: res.data.isReservation,
          isAttention: res.data.isAttention,
          reservationAmount: res.data.reservationAmount
        }

        if ((res.data.mxhLiveVideo.type == 0 && res.data.mxhLiveVideo.status == 1) || (res.data.mxhLiveVideo.type == 2 && res.data.mxhLiveVideo.status == 1)) {
          this.current = 2
        }
        if ((res.data.mxhLiveVideo.type == 0 && res.data.mxhLiveVideo.status == 0) || (res.data.mxhLiveVideo.type == 2 && res.data.mxhLiveVideo.status == 0)) {
          this.current = 1
        }
        // this.detailsData.mxhLiveVideo.status = 0
        // 录播
        if (res.data.mxhLiveVideo.type == 1) {
          this.viedeList = res.data.mxhLiveVideoPlayList
          this.isLiveIng = false
        }


        // 预播结束
        if ((res.data.mxhLiveVideo.type == 0 && res.data.mxhLiveVideo.status == 2)) {
          this.viedeList = res.data.mxhLiveVideoPlayList
          this.isLiveIng = false
        }
        //预播开始
        if (res.data.mxhLiveVideo.type == 0 && res.data.mxhLiveVideo.status == 0) {
          res.data.mxhLiveVideo.playUrl = res.data.mxhLiveVideo.replayUrl
          res.data.mxhLiveVideoPlayList = [res.data.mxhLiveVideo]
          this.viedeList = res.data.mxhLiveVideoPlayList
          this.isLiveIng = false
        }

        // 直播结束
        if (res.data.mxhLiveVideo.type == 2 && res.data.mxhLiveVideo.status == 2) {
          this.viedeList = res.data.mxhLiveVideoPlayList
          this.isLiveIng = false
        }

        if (res.data.mxhLiveVideoGoodsList && res.data.mxhLiveVideoGoodsList.length) {
          res.data.mxhLiveVideoGoodsList.forEach((item) => {
            if (item.goodsLabel) {
              item.goodsLabel = item.goodsLabel.split(',')
            } else {
              item.goodsLabel = []
            }
          })
          this.detailsData.mxhLiveVideoGoodsList = res.data.mxhLiveVideoGoodsList ? res.data.mxhLiveVideoGoodsList : []
        }


        this.$store.commit('updateAllbannedSpeak', res.data.mxhLiveVideo.isForbidSendMsg)
        this.$store.commit('setUserLive', res.data.mxhLiveVideo.viewTotal)

        this.share.banner = res.data.mxhLiveVideo.url
      })
    },
    clickPlayer() {
      this.isMore = false
      this.isSendMsgIng = false
      this.isIntegral = false
      this.isMaterial = false
      this.isShare = false
      this.isPoster = false
      this.isAddPlayRecord = false
      this.bottom = 0
    },
    clickVideo() {
      this.isMore = false
      this.isSendMsgIng = false
      this.isIntegral = false
      this.isMaterial = false
      this.isShare = false
      this.isPoster = false
      this.isAddPlayRecord = false
      this.bottom = 0
    },
    /**
     * 直播错误回调
     */
    error() {

    },
    /**
     * 播放状态变化事件
     */
    statechange() {

    },
    /**
     * 播放录播结束回调
     */
    bindended() {

    },
    /**
     * 监听录播播放回调
     */
    bindtimeupdate(e) {
      let ratio = 1 / this.viedeList.length
      let currentTime = parseInt(e.mp.detail.currentTime)
      let duration = parseInt(e.mp.detail.duration)
      let progressRate = parseInt((currentTime / duration * ratio + this.videoIndex * ratio) * 100)
      if (currentTime == duration && currentTime) {
        this.userPlay(progressRate)
      }
      if (currentTime % 9 == 0 && currentTime) {
        this.userPlay(progressRate)
      }
    },
    /**
     * 添加录播播放记录
     */
    userPlay(progressRate) {
      if (this.isAddPlayRecord) {
        return false
      }
      this.isAddPlayRecord = true
      let url = '/liveVideo/add/user/play'
      let data = {
        "liveVideoId": this.liveId,
        "progressRate": progressRate,
      }

      this.$http.post(url, data).then((res) => {
        if (res.code == 0) {
          setTimeout(() => {
            this.isAddPlayRecord = false
          }, 1000)
        }
      })
    },
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(res) {
    this.isSharePopup = false
    // 来自页面内转发按钮
    return {
      title: this.mxhUserInfo.nickName + '邀请您免费学习美学会精选好课',
      path: 'pages/verticalLive/main?liveId=' + this.liveId,
      imageUrl: this.share.banner,
      success: function(res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {}
      },
      fail: function() {
        // 转发失败之后的回调
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          // 用户取消转发
        } else if (res.errMsg == 'shareAppMessage:fail') {
          // 转发失败，其中 detail message 为详细失败信息
        }
      },
      complete: function() {

        // 转发结束之后的回调（转发成不成功都会执行）
      }
    }
  },
}

</script>
<style scoped lang="less">
section {
  height: 100vh;
  width: 100vh;
  overflow: hidden;
  background: #000;
}

live-player {
  height: 100%;
  width: 100%;
  display: block;
  background: red;
}

.liveEnd {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vh;
  height: 100vh;
  z-index: 1;

  .shade {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1;
    background: rgba(0, 0, 0, 1);
    opacity: 0.6;
    width: 100%;
    height: 100%;
  }

  .liveEndImg {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    z-index: 1;
  }

  span {
    position: fixed;
    z-index: 10;
    left: 50%;
    top: 400px;
    width: 100%;
    transform: translate(-50%, 0);
    text-align: center;
    color: #fff;
    font-size: 36px;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
  }
}

#shareCanvas {
  position: fixed;
  left: -10000px;
  bottom: -10000px;
}

#floatCanvas {}

#myVideo {
  height: 100vh;
  width: 100%;
  display: block;
}

.live-apply {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100vh;
  z-index: 200;

  .cover {
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
  }

  .appply-conent {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100vh;
    z-index: 222;
    background: rgba(0, 0, 0, 0.6);
    text-align: center;

    .pay {
      width: 210px;
      display: inline-block;
      vertical-align: middle;
      margin-right: 20px;
    }

    .title {
      font-size: 32px;
      font-weight: bold;
      color: rgba(255, 255, 255, 1);
      padding-top: 280px;
    }

    .time {
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      line-height: 42px;
      padding-top: 50px;
    }

    .appply {
      width: 240px;
      line-height: 68px;
      background: #d3a358;
      border-radius: 34px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      text-align: center;
      margin-top: 70px;
      display: inline-block;
    }
  }

  .live-introduce {
    position: fixed;
    left: 50%;
    bottom: 0;
    transform: translate(-50%, 0);
    width: 690px;
    height: 538px;
    padding: 20px;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 8px;
    z-index: 250;
    box-sizing: border-box;
    overflow-y: auto;

    .live-title {
      font-size: 32px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      margin-bottom: 35px;
      padding-top: 20px;
    }

    .live-des-title {
      font-size: 28px;
      font-weight: 500;
      color: #d3a358;
      margin-bottom: 25px;

      img {
        width: 32px;
        height: 32px;
        vertical-align: middle;
        margin-right: 20px;
        margin-top: -5px;
      }
    }

    .live-des-content {}
  }
}

.nav-fixed {
  position: fixed;
  top: 35px;
  left: 0;
  width: 100%;
  z-index: 10000;

  .goBack {
    width: 65px;
    height: 65px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 30px;
    margin-right: 20px;
  }

  .info {
    display: inline-block;
    vertical-align: middle;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 32px;
    .head {
      width: 65px;
      height: 65px;
      border-radius: 100%;
      vertical-align: middle;
      display: inline-block;
      margin-right: 10px;
    }

    .content-head {
      width: 165px;
      display: inline-block;
      vertical-align: middle;
      margin-right: 10px;

      .name {
        font-size: 24px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        overflow: hidden;
        /*超出部分隐藏*/
        white-space: nowrap;
        /*不换行*/
        text-overflow: ellipsis;
        /*超出部分文字以...显示*/
      }

      .number {
        font-size: 20px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
      }
    }

    .attention-button {
      margin-right: 10px;
      width: 78px;
      line-height: 52px;
      background: rgba(255, 255, 255, 1);
      border-radius: 26px;
      font-size: 24px;
      font-weight: 500;
      color: #d3a358;
      text-align: center;
      display: inline-block;
      vertical-align: middle;
    }
  }
}

.poster {
  position: fixed;
  left: 0;
  top: 10;
  height: 100vh;
  width: 100%;
  background: rgba(0, 0, 0, 0.6);
  z-index: 100;

  .poster-content {
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);

    img {
      width: 650px;
      height: 620px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      margin-bottom: 80px;
    }

    .poster-button {
      width: 650px;
      line-height: 80px;
      background: #d3a358;
      border-radius: 40px;
      text-align: center;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
    }
  }
}

.comment-box {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 750px;
  height: 100px;
  background: rgba(255, 255, 255, 1);
  z-index: 300;
  animation: slideTop 0.2s;

  .comment-content {
    position: relative;
    height: 100px;
    z-index: 1;
    background:#fff;
  }

  input {
    height: 100px;
    line-height: 100px;
    margin-left: 30px;
    width: 530px;
  }

  .send {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translate(0, -50%);
    width: 120px;
    line-height: 60px;
    background: #d3a358;
    border-radius: 30px;
    text-align: center;
    font-size: 28px;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
  }
}

.integralList {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  z-index: 100;
  animation: slideTop 0.2s;

  .integral-list-title {
    position: relative;
    background: rgba(255, 255, 255, 1);
    border-radius: 20px 20px 0px 0px;
    font-size: 32px;
    font-weight: bold;
    color: rgba(34, 34, 34, 1);
    line-height: 88px;

    span {
      display: block;
      margin: 0 30px;
      line-height: 88px;
      border-bottom: 2px solid rgba(234, 234, 234, 1);
    }

    .my-integral-number {
      position: absolute;
      right: 30px;
      top: 50%;
      transform: translate(0, -50%);
      font-size: 24px;
      font-weight: 500;
      color: #222;

      font {
        color: #d3a358;
      }
    }
  }

  .integral-li {
    background: #fff;
    height: 510px;

    .li {
      position: relative;
      overflow: hidden;
      margin: 0 30px;
      padding: 30px 0;
      border-bottom: 1px solid rgba(234, 234, 234, 1);

      .integral-img {
        width: 64px;
        height: 64px;
        border-radius: 10px;
        vertical-align: middle;
        display: inline-block;
      }

      .attention {
        position: absolute;
        top: 50%;
        right: 30px;
        transform: translate(0, -50%);
        width: 100px;
        line-height: 48px;
        background: #d3a358;
        border-radius: 24px;
        font-size: 24px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        text-align: center;
      }

      .attention.active {
        background: #666;
      }

      .li-content {
        margin-left: 20px;
        vertical-align: middle;
        display: inline-block;
        width: 500px;

        .li-title {
          font-size: 28px;
          font-weight: 500;
          color: rgba(34, 34, 34, 1);
          line-height: 40px;
          text-overflow: -o-ellipsis-lastline;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          line-clamp: 2;
          -webkit-box-orient: vertical;

        }

        .li-des {
          font-size: 24px;
          font-weight: 500;
          color: rgba(153, 153, 153, 1);
          line-height: 70px;
        }

      }
    }

    .li:last-child {
      border-bottom: none;
    }
  }

}

.goodsList {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  z-index: 100;
  animation: slideTop 0.2s;

  .goods-list-title {
    background: rgba(255, 255, 255, 1);
    border-radius: 20px 20px 0px 0px;
    font-size: 32px;
    font-weight: bold;
    color: rgba(34, 34, 34, 1);
    line-height: 88px;

    span {
      display: block;
      margin: 0 30px;
      line-height: 88px;
      border-bottom: 2px solid rgba(234, 234, 234, 1);
    }
  }

  .goods-li {
    background: #fff;
    height: 710px;
    position: relative;

    .li {
      overflow: hidden;
      margin: 0 30px;
      padding: 30px 0;
      border-bottom: 1px solid rgba(234, 234, 234, 1);

      .number {
        display: block;
        position: absolute;
        width: 40px;
        line-height: 28px;
        background: rgba(0, 0, 0, 1);
        opacity: 0.4;
        border-radius: 8px 0px 8px 0px;
        z-index: 1;
        color: #fff;
        text-align: center;
        font-size: 20px;
      }

      .goods-img {
        width: 168px;
        height: 168px;
        border-radius: 10px;
        float: left;
      }

      .li-content {
        margin-left: 20px;
        float: left;
        width: 500px;

        .li-title {
          font-size: 28px;
          font-weight: 500;
          color: rgba(34, 34, 34, 1);
          line-height: 40px;
          text-overflow: -o-ellipsis-lastline;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          line-clamp: 2;
          -webkit-box-orient: vertical;
          height: 84px;
        }

        .li-lables {
          margin: 10px 0;

          .li-lable {
            padding: 0 10px;
            line-height: 35px;
            background: rgba(255, 255, 255, 1);
            border: 2px solid #d3a358;
            border-radius: 4px;
            font-size: 22px;
            font-weight: 500;
            color: #d3a358;
            display: inline-block;
          }
        }

        .li-operation {
          .li-price {
            font-size: 32px;
            font-weight: bold;
            color: rgba(232, 101, 81, 1);
            margin-right: 10px;
          }

          .li-button {
            width: 120px;
            line-height: 48px;
            background: rgba(232, 101, 81, 1);
            border-radius: 24px;
            font-size: 24px;
            font-weight: 500;
            color: rgba(255, 255, 255, 1);
            float: right;
            text-align: center;
            margin-top: -7px;
          }
        }

      }
    }

    .li:last-child {
      border-bottom: none;
    }
  }

}

.chat-content {
  position: fixed;
  left: 20px;
  bottom: 250px;
  height: 430px;
  z-index: 5;
  width: 540px;

  .chat-list {
    max-width: 540px;
    border-radius: 20px;
    color: #fff;
    font-size: 28px;
    max-width: 540px;
    border-radius: 20px;
    background: rgba(0, 0, 0, 0.2);
    padding: 10px 20px;
    box-sizing: border-box;
    margin-bottom: 15px;
    display: inline-block;

    .msgImg {
      width: 20px;
      height: 20px;
    }

    span {
      color: #d3a358;
      font-size: 28px;
    }

    .identity-1 {
      color: #02FF83;
    }

    .identity-2 {
      color: #FF3600;
    }

    .identity-3 {
      color: #FF02A9;
    }
  }
}

.button {
  position: fixed;
  bottom: 100px;
  left: 0;
  width: 100%;
  z-index: 10;

  .material {
    width: 110px;
    height: 110px;
    display: inline-block;
    vertical-align: bottom;
    margin: 0 25px;
    margin-top: 5px;
    position: relative;

    .goods {
      position: absolute;
      top: -240px;
      background: #fff;
      width: 580px;
      padding: 20px;
      box-sizing: border-box;
      border-radius: 10px;

      &:before {
        position: absolute;
        left: 24px;
        bottom: -16px;
        width: 0;
        height: 0;
        content: '';
        display: block;
        border-left: 16px solid transparent;
        border-top: 24px solid #fff;
        border-right: 16px solid transparent;
      }

      img.goodsImg {
        width: 176px;
        height: 176px;
        border-radius: 10px;
        display: inline-block;
        vertical-align: middle;
        margin-right: 10px;
      }
      img.close{
        position:absolute;
        right: 20px;
        top: 0px;
        width:30px;
        height: 30px;
      }

      .content {
        display: inline-block;
        width: 350px;
        vertical-align: middle;

        .title {
          font-size: 28px;
          font-weight: 500;
          color: rgba(51, 51, 51, 1);
          line-height: 38px;
          margin-bottom: 40px;
        }

        .price {
          font-size: 32px;
          font-weight: bold;
          color: rgba(255, 43, 93, 1);

          span {
            width: 120px;
            line-height: 48px;
            background: rgba(232, 101, 81, 1);
            border-radius: 24px;
            font-size: 24px;
            font-weight: 500;
            color: rgba(255, 255, 255, 1);
            display: inline-block;
            float: right;
            text-align: center;
          }

          img {
            width: 52px;
            height: 52px;
            float: right;
          }
        }
      }
    }

    img {
      width: 110px;
      height: 110px;
      margin-top: 15px;
    }
  }

  .what {
    font-size: 28px;
    font-weight: 500;
    color: #fff;
    border-bottom: 2px solid rgba(255, 255, 255, 0.4);
    display: inline-block;
    vertical-align: middle;
    padding: 0 10px;
    padding-bottom: 15px;
  }

  .moreClose {
    width: 46px;
    height: 76px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 80px;
    margin-right: 20px;
    position: relative;

    img {
      display: block;
      width: 46px;
      height: 46px;
      margin-top: 15px;
    }

    .more-list {
      position: absolute;
      bottom: 0px;
      left: 50%;
      transform: translate(-50%, -120%);

      span {
        width: 80px;
        height: 80px;
        border-radius: 100%;
        background: #000;
        text-align: center;
        display: inline-block;
        line-height: 80px;
        color: #fff;
        font-size: 28px;
      }
    }
  }

  .more {
    width: 116px;
    height: 76px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 30px;

    img {
      display: block;
      width: 100%;
      height: 100%;
    }
  }

  .integral {
    width: 60px;
    height: 60px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 15px;

    img {
      display: block;
      width: 100%;
      height: 100%;
    }
  }

  .share {
    width: 56px;
    height: 56px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 35px;

    img {
      display: block;
      width: 100%;
      height: 100%;
    }
  }

  .like {
    width: 60px;
    height: 60px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 35px;

    img {
      display: block;
      width: 100%;
      height: 100%;
    }
  }
}

.button.liveAcitve {
  bottom: 20px !important;
}



.shrinkButton {
  position: fixed;
  top: 320px;
  right: 37px;
  width: 40px;
  height: 40px;
  z-index: 100;
}

.popup-mask {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1000;
  width: 100%;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
}

.share-popup {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 1000;
  width: 100%;
  animation: slideTop 0.2s;

  .share-content {
    width: 100%;
    overflow: hidden;
    padding-top: 65px;
    padding-bottom: 60px;
    background: rgba(255, 255, 255, 1);
    border-radius: 20px 20px 0px 0px;
    border-bottom: 20px solid rgba(246, 246, 246, 1);

    button.shareWeChat {
      display: block;
      padding-left: 0px;
      padding-right: 0px;
      line-height: 10px;
      background-color: rgba(255, 255, 255, 0);
    }

    button.shareWeChat::after {
      width: 0;
      height: 0;
      top: 0;
      left: 0;
      border: none;
    }

    .shareWeChat {
      display: block;
      float: left;
      width: 50%;

      img {
        display: block;
        width: 60px;
        margin: 0 auto;
        margin-bottom: 20px;
      }

      span {
        font-size: 24px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        line-height: 42px;
        display: block;
        text-align: center;
      }
    }

    .sharePosters {
      display: block;
      float: left;
      width: 50%;

      span {
        font-size: 24px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        line-height: 42px;
        display: block;
        text-align: center;

      }

      img {
        display: block;
        width: 60px;
        margin: 0 auto;
        margin-bottom: 20px;
      }
    }
  }

  .cancel {
    background: #fff;
    line-height: 80px;
    text-align: center;
    font-size: 30px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
  }
}

.live-content {
  background: #000;
  position: relative;
  width: 100%;
  height: 100%;
}

.bg {
  background: linear-gradient(0deg, rgba(41, 41, 55, 1) 0%, rgba(28, 31, 41, 1) 100%);
}

.userOtherPlayUrl {
  width: 160px;
  height: 240px;
  border-radius: 8px;
  display: block;
  position: absolute;
  right: 30px;
  top: 200px;
  z-index: 100;
}

.anchorLivePlayer {
  width: 375px;
  height: 620px;
  display: block;
  position: absolute;
  left: 0;
  top: 200px;
}

.otherPlayUrl {
  width: 375px;
  height: 620px;
  display: block;
  position: absolute;
  right: 0;
  top: 50%;
  transform: translate(0, -50%);
}

.ellipsis2 {
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
}

.node-data {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);

  img {
    width: 247px;
    height: 221px;
    margin-bottom: 15px;
  }

  .text {
    font-size: 28px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);
    text-align: center;
  }
}
.shade{
  position:fixed;
  left:0;
  top: 0;
  width: 100vh;
  height: 100vh;
  z-index: -1;
  background: rgba(0,0,0,0.3)
}
</style>
