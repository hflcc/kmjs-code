<template>
  <view class="subject">
    <swiper :current="currentTab" duration="300" class='asw-box' @change="swiperTab">
      <swiper-item v-for="(item,index) in examQuestionVoList" :key="index">
        <div class="swiper-item">
          <!-- 填空 -->
          <!--    <div class="content-fill" v-if="item.type==2">
            <div class="title">
              <span class="type">填空</span>
              {{item.title}}
              <input maxlength="1" class="input" type="text">
              <input maxlength="1" class="input" type="text">
              物管理单位应当主动接受居民委员会的监督。
            </div>
          </div> -->
          <!-- 选择 -->
          <div class="content-chose" v-if="item.type==0">
            <div class="title">
              <span class="type">单选</span>
              {{item.title}}
            </div>
            <div class="option">
              <div class="option__item" v-for="(its,idx) in item.mxhExamAnswerList" :key="index" @click="radioChange(item,idx)">
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 0">{{its.status == 2 ? 'A' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 1">{{its.status == 2 ? 'B' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 2">{{its.status == 2 ? 'C' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 3">{{its.status == 2 ? 'D' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 4">{{its.status == 2 ? 'E' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 5">{{its.status == 2 ? 'F' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 6">{{its.status == 2 ? 'G' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 7">{{its.status == 2 ? 'H' : ''}}</div>
                <div class="option__item__desc" :class="its.status == 3 ? 'red' : '' ">{{its.text}}</div>
              </div>
            </div>
          </div>
          <!-- 选择 -->
          <div class="content-chose" v-if="item.type==1">
            <div class="title">
              <span class="type">多选</span>
              {{item.title}}
            </div>
            <div class="option">
              <div class="option__item" v-for="(its,idx) in item.mxhExamAnswerList" :key="index" @click="multipleChange(item,idx)">

                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 0">{{its.status == 2 ? 'A' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 1">{{its.status == 2 ? 'B' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 2">{{its.status == 2 ? 'C' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 3">{{its.status == 2 ? 'D' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 4">{{its.status == 2 ? 'E' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 5">{{its.status == 2 ? 'F' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 6">{{its.status == 2 ? 'G' : ''}}</div>
                <div :class="its.status == 1 ? 'option__item__chosed': (its.status == 3 ? 'option__item__error' : 'option__item__btn')"
                  v-if="idx == 7">{{its.status == 2 ? 'H' : ''}}</div>
                <div class="option__item__desc" :class="its.status == 3 ? 'red' : '' ">{{its.text}}</div>
              </div>
            </div>
          </div>
          <!-- 简答 -->
          <div class="content-answer" v-if="item.type==2">
            <div class="title">
              <span class="type">简答</span>
              {{item.title}}
            </div>
            <textarea class="answer" placeholder="请输入您的答案" v-model="item.value" :disabled="isEnd" @input="textChange(item)" />
            </div>
            <!-- 答案 -->
            <div class="result" v-if="isEnd">答案：{{item.answerText}}</div>
            <!-- 解析 -->
            <div class="analysis" v-if="isEnd">
              <div class="title">
                <div class="line"></div>
                本题解析
              </div>
              <div class="desc">{{item.remarks || '无'}}</div>
            </div>
        </div>
      </swiper-item>
    </swiper>
    <test-info :status="2" v-if="isShow" @onshowhide="onshowhide" :questions="examQuestionVoList" :totalData="totalData"></test-info>
    <selection :isEnd="isEnd" :number="currentTab" :questions="examQuestionVoList" :totalData="totalData" :succeedNumber="succeedNumber" :errorNumber="errorNumber" @goSwiper="goSwiper" @onshowhide="onshowhide"></selection>
  </view>
</template>

<script>
import Selection from '../components/selection.vue'
import TestInfo from '../components/testInfo.vue'
export default {
  name: 'subject',
  data() {
    return {
      currentTab:0, // 当前题数
      isEnd: false, // 考试是否结束
      examQuestionVoList: [], // 考试试题
      totalData: {},
      errorNumber: 0,
      succeedNumber:0,
      isShow: false
    }
  },
  components: {
    Selection,
    TestInfo
  },
  onLoad (options) {
    this.examId = options.examId
    this.initData()
  },
  onUnload(){
    this.isShow = false
    this.currentTab = 0
  },
  methods: {

    bindtextarea(item){
      if(item.value){
        item.status = 1
      }else{
        item.status = 0
      }
    },
    onshowhide(status){
      this.isShow = status
    },
    /**
     * 获取考试信息
     */
    getVideoLive(){
      let url = '/exam/get/exam/statistics/' + this.examId
      this.$http.get(url).then(res => {
        if(res.code == 0){
         this.examQuestionVoList.forEach((item,index)=>{
            //单选
            if(item.type == 0){
              let i = 0
              if(res.data.mxhExamUserAnswerList[index].text == 'A'){
                i = 0
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'B'){
                i = 1
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'C'){
                i = 2
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'D'){
                i = 3
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'E'){
                i = 4
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'F'){
                i = 5
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'G'){
                i = 6
              }
              if(res.data.mxhExamUserAnswerList[index].text == 'H'){
                i = 7
              }
              if(res.data.mxhExamUserAnswerList[index].text == item.answerText){
                item.mxhExamAnswerList[i].status = 1
              }else{
                item.mxhExamAnswerList[i].status = 3
              }
            }

            //双选
            if(item.type == 1){
              // if(res.data.mxhExamUserAnswerList[index].text.length < item.answerText.length){
                res.data.mxhExamUserAnswerList[index].text.split(',').forEach((item2)=>{
                  let i = 0
                  if(item2 == 'A'){
                    i = 0
                  }
                  if(item2 == 'B'){
                    i = 1
                  }
                  if(item2 == 'C'){
                    i = 2
                  }
                  if(item2 == 'D'){
                    i = 3
                  }
                  if(item2 == 'E'){
                    i = 4
                  }
                  if(item2 == 'F'){
                    i = 5
                  }
                  if(item2 == 'G'){
                    i = 6
                  }
                  if(item2 == 'H'){
                    i = 7
                  }
                  if(item.answerText.indexOf(item2) > -1){
                    item.mxhExamAnswerList[i].status = 1
                  }else{
                    item.mxhExamAnswerList[i].status = 3
                  }
                })
            }

            if(item.type == 2){
              item.value = res.data.mxhExamUserAnswerList[index].text
            }

            if(res.data.mxhExamUserAnswerList[index].text == item.answerText){
              item.status = 1
            }else{
              item.status = 3

            }

         })
         this.mxhExamUserAnswerList = res.data.mxhExamUserAnswerList
         this.errorNumber = res.data.mxhExamUserAnswerList.length - res.data.mxhExamUserScore.correctQuestionNumber
         this.succeedNumber = res.data.mxhExamUserScore.correctQuestionNumber
        }
      })
    },
    // 初始化
    initData () {
      let url = '/exam/get/exam/' + this.examId
      this.$http.get(url).then(res => {
        let number = 0
        res.data.examQuestionVoList.forEach((item,index)=>{
          item.number = ++number
          item.status = 2
          if(item.type == 0 || item.type == 1){
            item.mxhExamAnswerList.forEach((item,index)=>{
              item.status = 2
            })
          }
          if(item.type == 2){
            item.value = ''
          }

        })
        this.totalData = res.data
        this.examQuestionVoList = res.data.examQuestionVoList
        wx.setStorageSync('examQuestionVoList',res.data.examQuestionVoList)
        this.isEnd = false
        if(this.totalData.isExam == 1){
          this.isEnd = true
          this.getVideoLive()
        }
      })
    },
    // 单选
    radioChange (item, i) {
      if(this.totalData.isExam == 0){
        item.mxhExamAnswerList.forEach((res)=>{
          res.status = 2
        })
        if(item.mxhExamAnswerList[i].status == 1){
          item.status = 2
          this.$set(item.mxhExamAnswerList[i],'status',2)
          return false
        }
        if(item.mxhExamAnswerList[i].status == 2){
          item.status = 1
          this.$set(item.mxhExamAnswerList[i],'status',1)
          return false
        }
      }
    },
    // 双选
    multipleChange(item,i){
      if(this.totalData.isExam == 0){
        if(item.mxhExamAnswerList[i].status == 1){
          this.$set(item.mxhExamAnswerList[i],'status',2)
          let status = false
          item.mxhExamAnswerList.forEach((item,index)=>{
             if(item.status == 1){
               status = true
             }
          })
          status ? item.status = 1 :  item.status = 2
          return false
        }
        if(item.mxhExamAnswerList[i].status == 2){
          item.status = 1
          this.$set(item.mxhExamAnswerList[i],'status',1)
          return false
        }
      }
    },
    textChange(item){
      if(item.value){
        item.status = 1
      }else{
        item.status = 1
      }
    },
    goSwiper(index){
      this.currentTab = index
    },
    swiperTab(e){
      this.currentTab = e.mp.detail.current
    }
  }
}
</script>

<style lang="less" scoped>
  .asw-box{
    min-height:100vh;
  }
  .subject {
    padding-bottom: 150rpx;
    box-sizing: border-box;
    height:100vh;
    position:relative;
  }
  .content-fill,
  .content-chose,
  .content-answer {
    padding: 40rpx 30rpx 0;
    box-sizing: border-box;
    position: relative;
    overflow: scroll;
    .title {
      font-size: 36rpx;
      line-height: 52rpx;
      letter-spacing: 5rpx;
      .type {
        position: relative;
        top: -6rpx;
        margin-right: 10rpx;
        letter-spacing: 0;
        display: inline-block;
        font-size: 22rpx;
        color: #fff;
        width: 76rpx;
        line-height: 36rpx;
        height: 36rpx;
        background: rgba(43,180,233,1);
        border-radius: 18rpx 18rpx 0px 18rpx;
        text-align: center;
      }
      .input {
        font-size: 36rpx;
        text-align: center;
        padding: 0 10rpx;
        box-sizing: border-box;
        position: relative;
        display: inline-block;
        background-color: #F2F3F4;
        width: 56rpx;
        height: 56rpx;
        margin-right: 16rpx;
        overflow: inherit;
        outline: none;
      }
    }
  }
  .content-chose {
    padding-bottom: 60px;
    height:100vh;
    .option {
      margin-top: 61rpx;
      .option__item {
        display: flex;
        align-items: center;
        margin-bottom: 60rpx;
        &__btn {
          margin-right: 30rpx;
          text-align: center;
          line-height: 52rpx;
          font-size: 32rpx;
          width: 52rpx;
          color: #030303;
          height: 52rpx;
          background: rgba(255,255,255,1);
          box-shadow: 0 2rpx 6rpx 0 rgba(127,127,127,0.3);
          border-radius: 50%;
        }
        &__chosed {
          margin-right: 30rpx;
          background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/chosed.png') no-repeat;
          background-size: 100% 100%;
          width: 60rpx;
          height: 60rpx;
        }
        &__error {
          margin-right: 30rpx;
          background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-error.png') no-repeat;
          background-size: 100% 100%;
          width: 52rpx;
          height: 52rpx;
        }
        &__desc {
          flex: 1;
          font-size: 36rpx;
        }
      }
    }
  }
  .content-answer {
    .answer {
      margin-top: 59rpx;
      border-radius: 8rpx;
      padding: 30rpx 20rpx;
      box-sizing: border-box;
      width: 690rpx;
      height: 400rpx;
      background-color: #FAFAFA;
    }
  }
  .result {
    margin: 52rpx 30rpx 62rpx;
    background: rgba(245,248,250,1);
    border-radius: 8px;
    padding: 30rpx 20rpx;
    box-sizing: border-box;
    color: #030303;
    font-size: 32rpx;
    font-weight: bold;
  }
  .analysis {
    margin: 0 30rpx;
    .title {
      display: flex;
      align-items: center;
      font-size: 28rpx;
      color: #030303;
      font-weight: bold;
      .line {
        width: 6rpx;
        height: 28rpx;
        background: rgba(43,180,233,1);
        margin-right: 13rpx;
      }
    }
    .desc {
      font-size: 30rpx;
      line-height: 52rpx;
      margin-top: 20rpx;
      letter-spacing: 5rpx;
    }
  }
.option__item__desc.red{
  color:red;
}
</style>
