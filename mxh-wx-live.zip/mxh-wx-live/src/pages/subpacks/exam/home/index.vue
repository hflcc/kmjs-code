<template>
  <view class="mian">
    <div class="content">
      <img class="avtor" :src="mxhUserInfo.headImgurl" alt="">
      <div class="name">{{mxhUserInfo.nickName}}</div>
      <div class="item">
        <span class="item__title">考试名称：</span>
        <span class="item__desc">{{examData.mxhExam.title}}</span>
      </div>
      <div class="item">
        <span class="item__title">通过标准：</span>
        <span class="item__desc">{{examData.examQuestionVoList.length}}题，{{examData.mxhExam.correctRate}}分通过（满分100分）</span>
      </div>
      <div class="item">
        <span class="item__title">出题单位：</span>
        <span class="item__desc">{{examData.userName || ''}}</span>
      </div>
      <div class="tips">温馨提醒：左右滑动切换上一题、下一题。做完可修改答案，右下角可快速寻找考题。</div>
    </div>
    <div class="btn-1" @click="begain" v-if="examData.isExam == 0">开始考试</div>
    <div class="btn-1" @click="result" v-if="examData.isExam == 1">查看考试结果</div>
    <div class="btn-2" @click="checkGrade" v-if="examData.isExam == 1">查看题目</div>
    <test-info v-if="isShowPopup" :status="1" :examData="examData" @cancel="cancelShowPopup"></test-info>
    <auth type="examHome"></auth>
  </view>
</template>

<script>
  import TestInfo from '../components/testInfo.vue'
  import auth from '../../../../components/auth'
  import {
    mapState
  } from 'vuex'
  export default {
    name: 'home',
    data() {
      return {
        isShowPopup: false,
        examData: {
          mxhExam: {},
          mxhExamTextList: [],
          examQuestionVoList: [],
        },
        mxhUserInfo: {},
        mxhExamTextList: wx.getStorageSync('mxhExamTextList')
      }
    },
    components: {
      TestInfo,
      auth
    },
    computed: {
      ...mapState({
        updateLogin: state => state.conversation.updateLogin,
      })
    },
    watch: {
      updateLogin: async function() {
        let pages = getCurrentPages();
        let currPage = null;
        if (pages.length) {
          currPage = pages[pages.length - 1];
        }
        if (currPage.route == 'pages/subpacks/exam/home/main') {
          this.mxhUserInfo = wx.getStorageSync('mxhUserInfo')
          this.getVideoLive()
          this.$store.commit('loginCallback', false)
        }
      },
    },
    onLoad(options) {
      // this.examId = 111
      if (options.scene) {
        let arr = decodeURIComponent(options.scene).split('=')
        this.examId = arr[1]
      } else {
        this.examId = decodeURIComponent(options.examId)
      }



    },
    onShow() {
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit("setIsLogin", true);
        this.$store.commit('setIsLoginCallback', true)
        return false
      }

      this.mxhUserInfo = wx.getStorageSync('mxhUserInfo')
      this.getVideoLive()
    },
    methods: {
      /**
       * 获取考试信息
       */
      getVideoLive() {
        let url = '/exam/get/exam/' + this.examId
        this.$http.get(url).then(res => {
          if (res.code == 0) {
            res.data.mxhExamTextList.forEach((item) => {
              item.text = ''
            })
            this.examData = res.data
          }
        })
      },
      cancelShowPopup() {
        this.isShowPopup = false
      },
      begain() {
        this.isShowPopup = true
        // wx.navigateTo({
        //   url: '/pages/subpacks/exam/subject/main?examId=' + this.examId
        // })
      },
      result() {
        wx.navigateTo({
          url: '/pages/subpacks/exam/grade/main?examId=' + this.examId
        })
      },
      checkGrade() {
        wx.navigateTo({
          url: '/pages/subpacks/exam/subject/main?examId=' + this.examId
        })
      }
    }
  }
</script>

<style lang="less" scoped>
  .mian {
    background-color: #E8F5FA;
    padding: 80rpx 30rpx;
    box-sizing: border-box;
    height: 100vh;

    .content {
      padding: 76rpx 20rpx 60rpx;
      box-sizing: border-box;
      text-align: center;
      position: relative;
      background-color: #fff;
      border-radius: 16rpx;
      color: #000000;

      .avtor {
        background-color: pink;
        position: absolute;
        display: block;
        width: 100rpx;
        height: 100rpx;
        border-radius: 50%;
        top: -50rpx;
        left: 50%;
        transform: translateX(-50%);
      }

      .name {
        font-size: 28rpx;
        font-weight: bold;
        margin-bottom: 78rpx;
      }

      .item {
        margin-bottom: 42rpx;
        display: flex;
        font-size: 30rpx;

        &__title {
          color: #666666;
        }

        &__desc {
          font-weight: 500;
          text-align: left;
          flex: 1;
        }
      }

      .tips {
        text-align: left;
        color: #999999;
        font-size: 24rpx;
      }
    }

    .btn-1 {
      width: 690rpx;
      height: 88rpx;
      background: rgba(43, 180, 233, 1);
      border-radius: 44rpx;
      color: #FFFFFF;
      font-size: 30rpx;
      text-align: center;
      line-height: 88rpx;
      margin: 80rpx auto 0;
    }

    .btn-2 {
      width: 690rpx;
      height: 88rpx;
      border: 2rpx solid rgba(51, 51, 51, 1);
      border-radius: 44rpx;
      font-size: 30rpx;
      text-align: center;
      line-height: 84rpx;
      margin: 40rpx auto 0;
    }
  }
</style>
