<template>
  <view class="info">
    <div v-if="status === 1" class="content-test">
      <div class="title">请填写信息开始考试</div>
      <div class="item" v-for="(item,index) in examData.mxhExamTextList" :key="index">
        <input class="item__input" v-model="item.text" type="text" :placeholder="'请输入您的' + item.examText">
      </div>
      <div class="item">
        <input class="item__input" type="text" v-model="name" placeholder="请填写您的姓名">
      </div>
      <div class="item" v-if="bingMobile">
        <input class="item__input" type="text" :placeholder="mobile" disabled />
      </div>
      <div class="item" v-if="!bingMobile">
        <input class="item__input" v-model="mobile" type="text" placeholder="请输入您的手机号" />
      </div>
      <div class="item" v-if="!bingMobile">
        <input class="item__input" type="text" v-model="code" placeholder="请输入验证码" />
        <div class="item__code" v-if="codeText == '获取验证码'" @click="getCode">{{codeText}}</div>
        <div class="item__code" v-else @click="getCode">{{codeText}}</div>
      </div>
      <div class="btn">
        <div class="btn__cancel" @click="cancel">取消</div>
        <div class="btn__confirm" @click="save">确认</div>
      </div>
    </div>
    <div v-else class="content-tips">
      <div class="title">温馨提示</div>
      <div class="desc">您确定要提交试卷吗？</div>
      <div class="btn">
        <div class="btn__cancel" @click="onhide">取消</div>
        <div class="btn__confirm" @click="confirm">确认</div>
      </div>
    </div>
  </view>
</template>
<script>
export default {
  name: 'testInfo',
  props: {
    totalData: {
      type: Object,
      defalut: {}
    },
    questions:{
      type: Array,
      defalut: []
    },
    status: {
      type: Number,
      defalut: 1
    },
    examData: {
      type: Object,
      defalut: {}
    }
  },
  created() {
  },
  data() {
    return {
      mxhExamTextList: wx.getStorageSync('mxhExamTextList'),
      bingMobile: wx.getStorageSync('mxhUserInfo').mobile,
      name: '',
      code: '',
      loading: false,
      mobile: wx.getStorageSync('mxhUserInfo').mobile,
      codeText: '获取验证码',
      resultObj:{}
    }
  },
  methods: {
    onhide(){
      this.$emit('onshowhide', false)
    },
    confirm(){
      if(this.loading){
        return false
      }
      this.loading = true
      let url = '/exam/send/submitExamResults'
      let mxhExamTextList = []
      this.mxhExamTextList.forEach((item) => {
        mxhExamTextList.push({
          id: item.id,
          examText:item.text || item.value,
        })
      })
      this.resultObj.time = new Date().getTime() - wx.getStorageSync('startExamTime')
      let data = {
        examId: this.totalData.mxhExam.id,
        liveVideoId: this.totalData.mxhExam.liveVideoId,
        mobile: wx.getStorageSync('mobile'),
        title: this.totalData.mxhExam.title,
        userName: wx.getStorageSync('name'),
        examUserAnswerVoList: [],
        mxhExamTextList:  mxhExamTextList,
        duration: parseInt(this.resultObj.time / 1000),
      }
      this.questions.forEach((res)=>{
        this.loading = false
        if(res.type == 0){
          res.mxhExamAnswerList.forEach((res2)=>{
            if(res2.status == 1){
              var resultStr=res2.serialNumber.replace(/\ +/g,"").replace(/[ ]/g,"").replace(/[\r\n]/g,"");//去掉空格
              data.examUserAnswerVoList.push({
                examQuestionId: res.id,
                text: resultStr
              })
            }
          })
        }
        if(res.type == 1){
          let arr = []
          res.mxhExamAnswerList.forEach((res2)=>{
            if(res2.status == 1){
              arr.push(res2.serialNumber)
            }
          })
          data.examUserAnswerVoList.push({
            examQuestionId: res.id,
            text: arr.join(",")
          })
        }
        if(res.type == 2 || res.type==3){
          data.examUserAnswerVoList.push({
            examQuestionId: res.id,
            text: res.value
          })
        }
      })
      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.resultObj = res.data
          let accuracy = this.resultObj.correctQuestionNumber / this.resultObj.questionNumber * 100
          if (accuracy > 0) {
            this.resultObj.accuracy = accuracy.toFixed(2)
          } else {
            this.resultObj.accuracy = 0
          }
          wx.setStorageSync('resultObj', this.resultObj)
          wx.redirectTo({
            url: '/pages/subpacks/exam/grade/main?examId=' + this.totalData.mxhExam.id,
          })
        }
      })


      // wx.navigateTo({
      //   url: '/pages/subpacks/exam/subject/main?examId=' + this.examData.mxhExam.id
      // })
    },
    cancel(){
      this.$emit('cancel')
    },
    // 开始考试
    save() {

      let state = true
      this.examData.mxhExamTextList.forEach((item) => {
        if (!item.text && state) {
          wx.showToast({
            title: '请填写' + item.examText,
            icon: 'none'
          })
          state = false
          return false
        }
      })
      if (state == false) {
        return false
      }


      if (!this.name) {
        wx.showToast({
          title: '请填写您的姓名',
          icon: 'none'
        })
        return false
      }

      // this.$emit('onshowhide', true)

      if (this.loading) {
        return false
      }
      this.loading = true

      let url = '/exam/get/exam/' + this.examData.mxhExam.id
      this.$http.get(url).then(res => {
        this.loading = false
        if (res.code == 0 && res.data == 'ERROR') {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
          return false
        }
        if (res.data.isExam == 1) {
          wx.showToast({
            title: '本场考试已作答',
            icon: 'none'
          })
          return false
        } else {
          wx.setStorageSync('name', this.name)
          wx.setStorageSync('mxhExamTextList', this.examData.mxhExamTextList)
          wx.setStorageSync('mobile', this.mobile)
          wx.setStorageSync('startExamTime', new Date().getTime())
          this.$emit('cancel')
          wx.navigateTo({
            url: '/pages/subpacks/exam/subject/main?examId=' + this.examData.mxhExam.id
          })
          return true
        }
      })
    },
    /**
     * 发送验证码
     */
    async getCode() {
      if (this.mobile.length != 11) {
        wx.showToast({
          title: '请输入手机号码',
          icon: 'none'
        })
        return
      }
      let res = await this.$http.post(`/user/verifyCode/${this.mobile}`)
      if (res.code == '0') {
        this.countDown(60)
        wx.showToast({
          title: res.data,
          icon: 'none'
        })
        return false
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'none'
        })
      }
    },
    countDown(time) {
      if (time === 0) {
        time = 60
        this.codeText = "获取验证码"
        return
      } else {
        this.codeText = `${time}s后重新发送`
        time--
      }
      setTimeout(() => {
        this.countDown(time)
      }, 1000)
    },
  }
}

</script>
<style lang="less" scoped>
.info {
  background: rgba(0, 0, 0, .6);
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 0 50rpx 0;
  box-sizing: border-box;
  z-index: 1000;
  .content-test {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding-top: 40rpx;
    box-sizing: border-box;
    position: relative;
    z-index: 5;
    background-color: #fff;
    border-radius: 8rpx;
    bottom: 0;

    .title {
      color: #222;
      font-size: 36rpx;
      font-weight: bold;
      text-align: center;
      margin-bottom: 40rpx;
    }

    .item {
      margin-left: 30rpx;
      margin-bottom: 30rpx;
      width: 590rpx;
      height: 80rpx;
      background: rgba(255, 255, 255, 1);
      border: 1rpx solid rgba(229, 229, 229, 1);
      border-radius: 8rpx;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20rpx;
      box-sizing: border-box;
      font-size: 32rpx;

      &__input {
        color: #333333;
      }

      .input-placeholder {
        color: #CCCCCC;
      }

      &__code {
        color: #d3a358;
      }
    }

    .btn {
      border-top: 1rpx solid rgba(246, 246, 246, 1);
      display: flex;
      text-align: center;
      height: 88rpx;
      line-height: 88rpx;
      font-size: 32rpx;

      &__cancel {
        width: 50%;
        border-right: 1rpx solid rgba(246, 246, 246, 1);
      }

      &__confirm {
        width: 50%;
        color: #d3a358;
      }
    }
  }

  .content-tips {
    background-color: #fff;
    z-index: 5;
    width: 580rpx;
    height: 374rpx;
    margin: 0 auto;
    border-radius: 8rpx;
    padding-top: 39rpx;
    box-sizing: border-box;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .title {
      color: #222;
      font-size: 36rpx;
      font-weight: bold;
      text-align: center;
      margin-bottom: 56rpx;
    }

    .desc {
      font-size: 28rpx;
      text-align: center;
    }

    .btn {
      margin: 80rpx 25rpx 0;
      display: flex;
      font-size: 32rpx;
      justify-content: space-between;

      &__cancel {
        color: #fff;
        width: 250rpx;
        height: 80rpx;
        background: #d3a358;
        border-radius: 40rpx;
        line-height: 80rpx;
        text-align: center;
      }

      &__confirm {
        width: 250rpx;
        height: 80rpx;
        background: rgba(255, 255, 255, 1);
        border: 2rpx solid rgba(234, 234, 234, 1);
        border-radius: 40rpx;
        line-height: 78rpx;
        text-align: center;
      }
    }
  }
}

</style>
