<template>
  <view class="score-progress">
    <canvas class="progress_bg" :canvas-id="canvasID" type="2d" id="myCanvas"></canvas>
    <div class="score">
      <div class="num">{{step}}</div>
      <div class="desc">考试分数</div>
    </div>
  </view>
</template>

<script>
  // 开始的弧度
  const startAngle = 0.75
  // 结束的弧度
  const endAngle = 0.25

  export default {
    name: 'score-progress',
    props: {
      step: {
        type: Number | String,
        default: 0
      }
    },
    data() {
      return {
        canvasID: new Date().getTime()
      }
    },
    watch: {
      "step": function() {
        setTimeout(() => {
          this.drawProgressbg(this.step)
        }, 600)
      }
    },
    mounted() {
      setTimeout(() => {
        this.drawProgressbg(this.step)
      }, 600)

    },
    methods: {
      drawProgressbg(step) {

        const query = wx.createSelectorQuery()
        query.select('#myCanvas')
          .fields({
            node: true,
            size: true
          })
          .exec((res) => {
            const canvas = res[0].node
            const context = canvas.getContext('2d')
            // const context = wx.createCanvasContext(this.canvasID, this)
            context.clearRect(0, 0, 306, 306)
            context.lineCap = 'round'
            // 外圆环
            context.beginPath()
            context.strokeStyle = "rgba(1,1,1,0.12)"
            context.lineWidth = 7
            context.arc(150, 95, 70, Math.PI * startAngle, Math.PI * endAngle, false)
            context.stroke()
            context.closePath()
            // 进度圆环
            step = 0.015 * step + 0.75;
            if (step >= 2) {
              step = step % 2;
            }
            context.beginPath()
            context.strokeStyle = '#FFF'
            context.arc(150, 95, 70, Math.PI * startAngle, Math.PI * step, false)
            context.stroke()
            context.closePath()
            // context.draw()
          })


      }
    }
  }
</script>

<style lang="less" scoped>
  .progress_bg {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    // width: 400rpx;
    height: 300rpx;
    margin-bottom: 40rpx;
  }

  .score {
    padding-top: 25rpx;
    box-sizing: border-box;
    color: #fff;
    text-align: center;
    position: absolute;
    top: 95rpx;
    left: 50%;
    transform: translateX(-50%);
    width: 210rpx;
    height: 210rpx;
    border-radius: 50%;
    background: linear-gradient(180deg, rgba(245, 245, 245, 0.12), rgba(245, 245, 245, 0.25));

    .num {
      font-size: 88rpx;
      font-weight: bold;
    }

    .desc {
      font-size: 24rpx;
      opacity: 0.6;
    }
  }
</style>
