<template>
  <view class="selection">
    <div class="mask" v-if="!isShowList" @click="close" @touchmove.stop.prevent></div>
    <div :class="['content', isShowList ? 'content_top' : 'content']">
      <div class="content__header">
        <div class="left" v-if="!isEnd" @click="onSubmit"><span class="left__icon"></span>交卷</div>

        <div class="middle" v-if="!isEnd">
          <div class="done"><span class="done__icon"></span>{{haveAnswerNumber}}</div>
          <div class="not-done"><span :class="['not-done__icon', {'error': isEnd}]"></span>{{notAnswerNumber}}</div>
        </div>
        <div class="middle" v-if="isEnd">
          <div class="done"><span class="done__icon"></span>{{succeedNumber}}</div>
          <div class="not-done"><span :class="['not-done__icon', {'error': isEnd}]"></span>{{errorNumber}}</div>
        </div>

        <div class="right" @click="switchOver"><span class="right__icon"></span><span class="right__name">{{number + 1}}</span>/{{questions.length}}</div>
      </div>
      <div v-if="!isShowList" class="content__list">
        <div @click="goSwiper(index)" :class="['content__list__item', {'correct' : item.status == 1, 'not-chosed': item.status == 2, 'error' : item.status == 3}]" v-for="(item, index) in questions" :key="index">{{(item.number)}}</div>
      </div>

    </div>
  </view>
</template>

<script>
export default {
  name: 'selection',
  props: {
    totalData: {
      type: Object,
      defalut: {}
    },
    questions:{
      type: Array,
      defalut: []
    },
    isEnd: {
      type: Boolean,
      defalut: false
    },
    number:{
      type: Number,
      defalut: 0
    },
    succeedNumber:{
      type: Number,
      defalut: 0
    },
    errorNumber:{
      type: Number,
      defalut: 0
    },

  },
  computed: {
    haveAnswerNumber:function(){
      let number = 0
      this.questions.forEach((item)=>{
        if(item.type == 0 || item.type == 1){
          let status = true
          item.mxhExamAnswerList.forEach((item)=>{
            if(item.status == 1 && status){
              number++
              status = false
            }
          })
        }
        if(item.type == 2){
          if(item.value){
             number++
          }
        }
      })
      return number
    },
    notAnswerNumber:function(){
      return (this.questions.length - this.haveAnswerNumber)
    },
  },
  data() {
    return {
      mxhExamTextList: wx.getStorageSync('mxhExamTextList'),
      loading: false,
      isShowList: true,
      resultObj:{},
      arr: [
        {
          status: 0,
          num: 1
        },
        {
          status: 1,
          num: 2
        },
        {
          status: 2,
          num: 3
        },
        {
          status: 3,
          num: 4
        },
        {
          status: 0,
          num: 5
        },
        {
          status: 0,
          num: 6
        },
         {
          status: 0,
          num: 7
        },
         {
          status: 0,
          num: 8
        },
         {
          status: 0,
          num: 9
        },
         {
          status: 0,
          num: 10
        },
         {
          status: 0,
          num: 11
        },
         {
          status: 0,
          num: 12
        },
         {
          status: 0,
          num: 13
        }
      ]
    }
  },
  methods: {
    
    onSubmit(){

      /**
       *判断是否填写完试题
       */
      let isFinish = true
      this.questions.forEach((item)=>{
        if(item.type == 0 || item.type == 1){
          if(item.status == 2){
            isFinish = false
          }
        }
        if(item.type == 2){
          if(!item.value){
            isFinish = false
          }
        }
      })
      console.log(isFinish)
      if(!isFinish){
        this.$store.commit('showToast', { title: '请填写完试题' })
        return false
      }


      this.$emit('onshowhide', true)
      
    },
    goSwiper(index){
      this.$emit('goSwiper',index)
    },
    close() {
      this.isShowList = true
    },
    switchOver() {
      this.isShowList = !this.isShowList
    }
  }
}
</script>

<style lang="less" scoped>
.selection {
  position: fixed;
  left: 0;
  bottom: 0;
  right: 0;
  height: 100rpx;
}
.mask {
  z-index: 10;
  position: absolute;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
}
.content {
  z-index: 10;
  position: absolute;
  background-color: #fff;
  width: 100%;
  height: 620rpx;
  bottom: 0;
  display: flex;
  flex-direction: column;
  &.content_top {
    transform: translateY(520rpx);
  }
  &__header {
    border-top: 1rpx solid #f4f4f4;
    padding: 0 30rpx;
    box-sizing: border-box;
    height: 100rpx;
    width: 100%;
    display: flex;
    justify-content: space-between;
  }
  &__list {
    border-top: 1rpx solid #f4f4f4;
    padding: 0 0 30rpx 30rpx;
    box-sizing: border-box;
    overflow: scroll;
    display: flex;
    flex-wrap: wrap;
    &__item {
      margin-top: 30rpx;
      margin-right: 42rpx;
      color: #999999;
      font-size: 36rpx;
      width: 76rpx;
      height: 76rpx;
      border: 2rpx solid #969FA3;
      border-radius: 50%;
      text-align: center;
      line-height: 76rpx;
      &.correct {
        background: rgba(224,246,255,1);
        color: #d3a358;
        border: none;
        width: 80rpx;
        height: 80rpx;
      }
      &.not-chosed {
        border: 2rpx solid rgba(43,180,233,1);
        color: #d3a358;
      }
      &.error {
        background:rgba(255,227,227,1);
        color: #FA5E5E;
        border: none;
        width: 80rpx;
        height: 80rpx;
      }
      &:nth-child(6n) {
        margin-right: 0;
      }
    }
  }
}
.left {
  display: flex;
  align-items: center;
  color: #d3a358;
  font-size: 28rpx;
  &__icon {
    margin-right: 12rpx;
    display: block;
    background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-hand.png') no-repeat;
    background-size: 100% 100%;
    width: 32rpx;
    height: 32rpx;
  }
}
.middle {
  display: flex;
}
.done {
  margin-right: 50rpx;
  display: flex;
  align-items: center;
  font-size: 28rpx;
  &__icon {
    margin-right: 12rpx;
    display: block;
    background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/chosed.png') no-repeat;
    background-size: 100% 100%;
    width: 28rpx;
    height: 28rpx;
  }
}
.not-done {
  // margin: 0 80rpx 0 50rpx;
  display: flex;
  align-items: center;
  font-size: 28rpx;
  &__icon {
    margin-right: 12rpx;
    display: block;
    background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-gray.png') no-repeat;
    background-size: 100% 100%;
    width: 28rpx;
    height: 28rpx;
     &.error {
      display: block;
      background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-error.png') no-repeat;
      background-size: 100% 100%;
      width: 28rpx;
      height: 28rpx;
    }
  }
}
.right {
  display: flex;
  align-items: center;
  font-size: 28rpx;
  color: #999999;
  &__icon {
    margin-right: 12rpx;
    display: block;
    background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-rectangle.png') no-repeat;
    background-size: 100% 100%;
    width: 30rpx;
    height: 30rpx;
  }
  &__name {
    color: #222222;
    font-weight: bold;
  }
}
.bottom_to_top {
  animation: bottom_to_top 0.5s  forwards;
}
.top_to_bottom {
  animation: top_to_bottom 0.5s  forwards;
}
@keyframes bottom_to_top {
  from {
    bottom: -500rpx; /* 370/100 */;
  }
  to {
    bottom: 0;
  }
}
@keyframes top_to_bottom {
  from {
    bottom: 0;
  }
  to {
    bottom: 500rpx; /* 370/100 */;
  }
}
</style>