<template>
  <view class="grade">
    <div class="top">
      <score-progress :step="mxhExam.mxhExamUserScore.score" v-if="isShow"></score-progress>
      <div class="test-detail">

        <div class="item">
          <div class="name">{{mxhExam.duration || 0}}</div>
          <div class="desc">考试时长</div>
        </div>
        <div class="item">
          <div class="name">{{mxhExam.userRank || 0}}名</div>
          <div class="desc">分数排名</div>
        </div>
        <div class="item">
          <div class="name">{{mxhExam.mxhExamUserScore.questionNumber || 0}}题</div>
          <div class="desc">考试题数</div>
        </div>
      </div>
    </div>
    <!-- 历史成绩 -->
    <div class="history">
      <div class="title">
        <div class="icon"></div>
        历史考试成绩
      </div>
      <div class="list">
        <div class="content" v-for="(item,index) in list" :key="index">
          <div class="score">{{item.score}}分</div>
          <div class="num">{{item.questionNumber}}题</div>
          <div class="date">{{item.createTime}}</div>
          <div :class="['result', {'error': item.status === 2}]">{{item.lable}}</div>
        </div>
      </div>
    </div>
  </view>
</template>
<script>
  import ScoreProgress from '../components/score-progress.vue'
  export default {
    name: 'grade',
    data() {
      return {
        form: {
          size: 10,
          page: 1,
        },
        list: [],
        examId: '',
        mxhExam: {
          mxhExamUserScore: {
            score: 0,
          }
        },
        isShow: false
      }
    },
    onLoad(option) {

      this.examId = option.examId
      this.getVideoLive()
      this.getList()

    },
    onUnload() {
      this.form = {
        size: 10,
        page: 1,
      }
      this.list = []
      this.examId = ''
      this.mxhExam = {
        mxhExamUserScore: {
          score: 0,
        }
      }
      this.isShow = false
    },
    components: {
      ScoreProgress
    },
    methods: {
      /**
       * 获取考试信息
       */
      getVideoLive() {
        let url = '/exam/get/exam/statistics/' + this.examId
        this.$http.get(url).then(res => {
          if (res.code == 0) {
            res.data.duration = this.toHHmmss(res.data.duration * 1000)
            this.mxhExam = res.data
            // this.mxhExam.mxhExamUserScore.score = new Date().getTime()
            this.isShow = true
          }
        })
      },
      toHHmmss(data) {
        var time = '';
        var hours = parseInt((data % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = parseInt((data % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = parseInt((data % (1000 * 60)) / 1000);
        if (hours) {
          time += (hours < 10 ? ('0' + hours) : hours) + '时'
        }
        if (minutes) {
          time += (minutes < 10 ? ('0' + minutes) : minutes) + '分'
        }
        if (seconds) {
          time += (seconds < 10 ? ('0' + seconds) : seconds) + '秒'
        }
        return time;
      },
      getList() {
        let url = '/exam/get/user/' + this.form.page + '/' + this.form.size
        this.$http.get(url).then(res => {
          res.data.forEach((item, index) => {
            if (item.score >= 80) {
              item.status = 1
              item.lable = "您真棒！"
            }
            if (item.score >= 60 && item.score < 80) {
              item.status = 1
              item.lable = "考试通过"
            }
            if (item.score < 60) {
              item.status = 2
              item.lable = "考试不合格"
            }
          })
          this.list = this.list.concat(res.data)
        })
      }
    },
    // 上拉加载
    onReachBottom() {
      this.form.page++
      this.getList()
    },
  }
</script>
<style lang="less" scoped>
  .top {
    background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/bg.png') no-repeat;
    background-size: 100% 100%;
    background-position-y: -138rpx;
    width: 100%;
    height: 640rpx;
  }

  .history {
    margin-top: -130rpx;
  }

  .title {
    padding: 0 0 20rpx 30rpx;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    border-bottom: 1rpx solid #f4f4f4;
    font-size: 28rpx;
    font-weight: bold;

    .icon {
      background: url('https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/exam/icon-clock.png') no-repeat;
      background-size: 100% 100%;
      width: 32rpx;
      height: 32rpx;
      margin-right: 21rpx;
    }
  }

  .test-detail {
    display: flex;
    justify-content: space-around;

    .item {
      color: #fff;
      text-align: center;

      .name {
        font-weight: bold;
        font-size: 30rpx;
      }

      .desc {
        font-size: 24rpx;
        opacity: 0.6;
      }
    }
  }

  .list {
    padding: 0 30rpx;
    box-sizing: border-box;
  }

  .content {
    padding: 48rpx 0;
    display: flex;
    border-bottom: 1rpx solid #f4f4f4;
    justify-content: space-between;
    font-size: 28rpx;
    color: #999999;

    .score {
      width: 25%;
      font-size: 32rpx;
      color: #FA6565;
      font-weight: bold;
    }

    .num {
      width: 25%;
    }

    .date {
      width: 25%;
    }

    .result {
      text-align: right;
      width: 25%;
      color: #d3a358;
      font-weight: bold;

      &.error {
        color: #FA6565;
      }
    }
  }
</style>
