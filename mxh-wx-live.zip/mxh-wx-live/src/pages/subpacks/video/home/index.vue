<template>
  <section>
    <div class="nav-fixed" :style="'top:' + (6 + statusBarHeight) + 'px'">
      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/goBack.png" alt="" class="goBack" @click="back">
    </div>
    <!--   <custom-nav-bar
        :fixed="true"
        :placeholder="false"
        :transparent="navBarIsTransparent"
        :title="navBarIsTransparent ? '' : ''"
      >
      </custom-nav-bar> -->
    <i-avideo-swiper :video-list="videos" :initial-index="0" @change="onChange" :duration="duration" :play="onPlay"
      :forward="onPanelForward"></i-avideo-swiper>
  </section>
</template>

<script>
  export default {
    data() {
      return {
        videos: [],
        videoIndex: 0,
        duration: 500,
        form: {
          page: 1,
          size: 20
        },
        statusBarHeight: 0,
        navBarIsTransparent: true
      }
    },
    async onLoad(options) {
      this.statusBarHeight = wx.getSystemInfoSync()['statusBarHeight']
      if (wx.getStorageSync('videoIndex')) {
        this.form.size = wx.getStorageSync('videoIndex') + 20
        this.videoIndex = wx.getStorageSync('videoIndex')
      }
      this.videos = await this.getVideoList()
    },
    methods: {
      back() {
        wx.navigateBackMiniProgram({
          success(res) {}
        })
      },
      async getVideoList() {
        let that = this
        let data = {
          size: this.form.size,
          page: this.form.page
        }
        return await new Promise((resolve, reject) => {
          wx.request({
            url: 'https://gateway.mr8.net/video/page',
            data: data,
            method: 'POST',
            success(res) {
              const videos = [];
              res.data.data.records.forEach((item, index) => {
                videos.push({
                  src: item.url,
                  des: item.title,
                  nickname: item.nickname,
                })
              })
              that.form.size = 20
              resolve(videos);
            }
          })
        });
      },
      async onChange(e) {
        if ((this.videos.length - e.detail.dataIdx) < 5) {
          this.form.page++
          let list = await this.getVideoList()
          this.videos = this.videos.concat(list)
        }
        wx.setStorageSync('videoIndex', e.detail.dataIdx);
      },
      onPlay(e) {
        console.log('play', e.detail.video);
      },
      onPanelForward(e) {
        console.log('panel event: forward', e.detail.video);
        wx.showToast({
          title: 'panel事件：' + e.detail.video.title,
          icon: 'none'
        });
      }
    }
  }
</script>

<style lang="less" scoped>
  section {
    background-color: #000;
    overflow: hidden;
    height: 100vh;
    width: 100%;
  }

  .my-input {
    position: fixed;
    bottom: 100px;
    left: 20px;
    height: 30px;
    width: 100px;
    background-color: red;
  }

  .nav-fixed {
    position: fixed;
    top: 35px;
    left: 0;
    width: 100%;
    z-index: 10000;

    .goBack {
      width: 65px;
      height: 65px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 30px;
      margin-right: 20px;
    }
  }
</style>
