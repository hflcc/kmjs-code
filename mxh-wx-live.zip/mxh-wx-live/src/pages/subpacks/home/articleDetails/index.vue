<template>
  <section>
    <div class="ask-content recorded-ask-content">
      <div class="item-1">
        <div class="ask-title">{{article.articleTitle}} </div>
        <div class="ask-li">
          <img :src="article.mxhUserInfo.headImgurl" @click="goPersonalHome(article.mxhUserInfo)">
          <div class="ask-character">
            <div class="ask-text" @click.stop="goPersonalHome(article.mxhUserInfo)">{{article.mxhUserInfo.nickName}}<img
                src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png" alt="" class="logo" v-if="article.mxhUserInfo.corporateType == 2"><span
                class="attention" @click.stop="attention">{{!article.isAttention ? '+关注' : '已关注'}}</span></div>
            <div class="ask-name">{{article.createTime}}</div>
          </div>
        </div>
      </div>
      <div v-html="article.articleComment" class="article-comment"></div>
      <div class="label">
        <span v-if="article.isLive" class="active" @click="commentLike"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give-active.png"
            class="give"><label>{{article.likeTotal}}</label></span>
        <span v-if="!article.isLive" @click="commentLike"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give.png"
            class="give"><label>{{article.likeTotal}}</label></span>
        <button open-type="share" class="shareWeChat"><span><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/weChat.png"
              class="weChat"><label>微信</label></span></button>
      </div>
      <div class="comment">
        <div class="comment-title"><span>评论</span>{{commentListTotal}}</div>
        <div class="comment-content" v-for="(item,index) in commentList" :key="index">
          <div class="comment-item">
            <div class="headimg"><img :src="item.userUrl" class="head"></div>
            <div class="comment-li">
              <div class="comment-li-title">
                {{item.nickName}}
                <span v-if="item.isLike" class="active" @click="replyCommentLike(item)">{{item.likeTotal}} <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give-active.png"></span>
                <span v-else @click="replyCommentLike(item)">{{item.likeTotal}} <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give.png"></span>
              </div>
              <div class="comment-li-des">{{item.text}}</div>
              <div class="comment-li-time">{{item.createTime}}<span @click="clickShow(2,item.id,index)">· 回复</span></div>
            </div>
          </div>

          <div class="comment-content" v-for="(mxhCommentReplyItem,mxhCommentReplyIndex) in item.mxhCommentReplyList"
            :key="mxhCommentReplyIndex">
            <div class="comment-item" v-if="mxhCommentReplyIndex < 1  || item.allView">
              <div class="headimg"><img :src="mxhCommentReplyItem.userUrl" class="head"></div>
              <div class="comment-li">
                <div class="comment-li-title">{{mxhCommentReplyItem.nickName}}</div>
                <div class="comment-li-des">{{mxhCommentReplyItem.text}}</div>
                <div class="comment-li-time">{{mxhCommentReplyItem.createTime}}</div>
              </div>
            </div>
          </div>
          <div class="allView" @click="clickAllView(item)" v-if="!item.allView && item.mxhCommentReplyList.length > 1">查看全部{{item.mxhCommentReplyList.length}}条回复</div>
        </div>
      </div>
      <div class="fixed">
        <div class="input" @click="clickShow(1,articleId)"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/eitd.png"><span>说几句...</span></div>
        <div class="fixed-content">
          <span class="zhengwen" @click="goTop"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/article_report.png"></span>
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give.png" class="like" v-if="!article.isLive"
            @click="commentLike">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/give-active.png" class="like acitve" v-else
            @click="commentLike">
          <button open-type="share" class="shareWeChat"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/transpond.png"
              class="transpond"></button>
        </div>
      </div>
      <div class="inContent" v-if="isShow" @click="clickShow">
        <div class="inContent-content" @click.stop="clickContent">
          <textarea placeholder="期待您的优质评论" v-model="mxhComment" fixed :cursor-spacing="90"></textarea>
          <div class="send" @click="clickSend()">发送</div>
        </div>
      </div>
    </div>

    <div class=""></div>
  </section>
</template>
<script>
  export default {
    data() {
      return {
        commentList: [],
        commentListTotal: 0,
        form: {
          page: 1,
          size: 10,
        },
        article: {
          isLive: 0,
          likeTotal: 0,
          mxhUserInfo: {}
        },
        articleId: '',
        isShow: false,
        mxhComment: '',
        commentIng: false,
        commentItemId: 0,
        commentItemType: 1,
        commentItemIndex: 0,
      }
    },
    onLoad(options) {
      this.articleId = options.articleId
      this.getArticle()
      this.getComment()
    },
    methods: {
      goPersonalHome(item) {
        if (item.corporateType == 1) {
          wx.navigateTo({
            url: '/pages/enterpriseHome/main?userId=' + item.id
          })
        }
        if (item.corporateType == 2) {
          wx.navigateTo({
            url: '/pages/personalHome/main?userId=' + item.id
          })
        }
      },
      clickAllView(item) {
        this.$set(item, 'allView', !item.allView)
      },
      clickShow(commentItemType, commentItemId, index) {
        this.commentItemId = commentItemId
        this.commentItemType = commentItemType
        this.commentItemIndex = index
        this.isShow = !this.isShow
      },
      clickContent() {

      },
      goTop() {
        wx.navigateTo({
          url: '/pages/report/main?type=1&liveId=' + this.articleId
        })
        // wx.pageScrollTo({
        //   scrollTop: 0
        // })
      },
      // type 1 回复文章  type 2  回复人
      clickSend() {
        if (!this.isnull(this.mxhComment)) {
          if (this.commentIng) {
            return
          }
          this.commentIng = true
          let url = '/comment/add'
          let data = {
            type: this.commentItemType,
            commentItemId: this.commentItemId,
            text: this.mxhComment
          }
          this.$http.post(url, data).then((res) => {
            if (res.code == 0) {
              if (this.commentItemType == 1) {
                this.commentList = []
                this.form.page = 1
                this.getComment()
              }
              if (this.commentItemType == 2) {
                this.commentList[this.commentItemIndex].mxhCommentReplyList.push(res.data)
                this.form.page = 1
              }
              this.mxhComment = ''
              this.clickShow()
              setTimeout(() => {
                this.commentIng = false
              }, 1000)
            }
          })
        } else {
          this.$store.commit('showToast', {
            title: '内容不能为空'
          })
        }
      },
      /**
       * 点赞同问
       */
      replyCommentLike(item) {
        let url = '/comment/set/like'
        let data = {
          type: 0,
          likeItemId: item.id,
        }
        this.$http.post(url, data).then((res) => {
          if (res.code == 0 && item.isLike == 0) {
            this.$set(item, 'isLike', 1)
            this.$set(item, 'likeTotal', ++item.likeTotal)
            console.log(1)
            return false
          }
          if (res.code == 0 && item.isLike == 1) {
            this.$set(item, 'isLike', 0)
            this.$set(item, 'likeTotal', --item.likeTotal)
            console.log(2)
            return false
          }
        })
      },
      isnull(content) {
        if (content === '') {
          return true
        }
        const reg = '^[ ]+$'
        const re = new RegExp(reg)
        return re.test(content)
      },
      /**
       * 获取评论列表
       */
      getComment() {
        let url = '/comment/get/list/' + this.form.page + '/' + this.form.size
        let data = {
          type: 1,
          commentItemId: this.articleId,
        }
        this.$http.post(url, data).then((res) => {
          this.commentList = this.commentList.concat(res.data.list)
          this.commentListTotal = res.data.total
        })
      },
      /**
       * 点赞
       */
      commentLike() {
        let url = '/comment/set/like'
        let data = {
          likeItemId: this.articleId,
          type: 2,
        }
        this.$http.post(url, data).then((res) => {
          if (res.code == 0 && this.article.isLive == 0) {
            this.$set(this.article, 'isLive', 1)
            this.$set(this.article, 'likeTotal', ++this.article.likeTotal)
            return false
          }
          if (res.code == 0 && this.article.isLive == 1) {
            this.$set(this.article, 'isLive', 0)
            this.$set(this.article, 'likeTotal', --this.article.likeTotal)
            return false
          }
        })
      },
      /**
       * 关注
       */
      attention() {
        let url = '/userConcern/saveMxhUserConcern'
        let data = {
          concernUserId: this.article.userId,
        }
        this.$http.post(url, data).then(res => {
          this.$set(this.article, 'isAttention', !this.article.isAttention)
        })
      },
      getArticle() {
        let url = '/article/get/' + this.articleId
        this.$http.post(url).then(res => {
          this.article = res.data
        })
      }
    },
    // 上拉加载
    onReachBottom() {
      this.form.page++
      this.getComment()
    },
    onShareTimeline() {
      // 来自页面内转发按钮
      return {
        title: this.article.articleTitle,
        path: 'pages/subpacks/home/articleDetails/main',
        imageUrl: this.article.articleImgUrl,
        success: function(res) {
          // 转发成功之后的回调
          if (res.errMsg == 'shareAppMessage:ok') {}
        },
        fail: function() {
          // 转发失败之后的回调
          if (res.errMsg == 'shareAppMessage:fail cancel') {
            // 用户取消转发
          } else if (res.errMsg == 'shareAppMessage:fail') {
            // 转发失败，其中 detail message 为详细失败信息
          }
        },
        complete: function() {

          // 转发结束之后的回调（转发成不成功都会执行）
        }
      }
    },
    onShareAppMessage(res) {
      // 来自页面内转发按钮
      return {
        title: this.article.articleTitle,
        path: 'pages/subpacks/home/articleDetails/main?articleId=' + this.articleId,
        imageUrl: this.article.articleImgUrl,
        success: function(res) {
          // 转发成功之后的回调
          if (res.errMsg == 'shareAppMessage:ok') {}
        },
        fail: function() {
          // 转发失败之后的回调
          if (res.errMsg == 'shareAppMessage:fail cancel') {
            // 用户取消转发
          } else if (res.errMsg == 'shareAppMessage:fail') {
            // 转发失败，其中 detail message 为详细失败信息
          }
        },
        complete: function() {

          // 转发结束之后的回调（转发成不成功都会执行）
        }
      }
    },
  }
</script>
<style lang='less' scoped>
  section {
    overflow: scroll;
    width: 100%;
    overflow-x: hidden;
    min-height: 100vh;
    position: relative;
    padding-bottom: 120px;
  }

  .ask-content {
    padding: 30px;

    .ask-course-content {
      .ask-course-title {
        font-size: 28px;
        font-weight: bold;
        color: rgba(34, 34, 34, 1);
        margin-bottom: 10px;
      }

      .ask-course-text {
        font-size: 26px;
        font-weight: 500;
        color: rgba(102, 102, 102, 1);
        line-height: 36px;
      }
    }

    .ask-title {
      font-size: 32px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      margin-bottom: 20px;
      text-align: justify;
    }

    .ask-li {
      padding-bottom: 20px;
      padding-top: 30px;

      img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        vertical-align: top;
        display: inline-block;
        margin-right: 20px;
      }

      .ask-character {
        width: 593px;
        vertical-align: top;
        display: inline-block;

        .ask-name {
          font-size: 24px;
          font-weight: 500;
          color: rgba(153, 153, 153, 1);
          line-height: 50px;
        }

        .ask-text {
          font-size: 28px;
          font-weight: 500;
          color: #222222;
          line-height: 42px;

          .logo {
            width: 112px;
            height: 30px;
            vertical-align: middle;
            margin-top: -3px;
            border-radius: 0;
            margin-left: 10px;
          }

          span {
            float: right;
            width: 120px;
            line-height: 48px;
            background: rgba(211, 163, 88, 1);
            border-radius: 8px;
            text-align: center;
            color: #fff;
          }
        }

        .ask-number {
          overflow: hidden;
          width: 100%;
          margin-top: 25px;

          .fl {
            font-size: 24px;
            font-weight: 500;
            color: rgba(153, 153, 153, 1);
            line-height: 42px;
            float: left;
          }

          .fr {
            font-size: 24px;
            font-weight: 500;
            color: rgba(153, 153, 153, 1);
            line-height: 42px;
            float: right;
            margin-top: 5px;

            img {
              width: 28px;
              display: inline-block;
              vertical-align: middle;
              margin-right: 5px;
              border-radius: 0px;
              margin-top: -5px;
            }
          }

          .fr.active {
            color: #d3a358;
          }
        }
      }
    }
  }

  .article-comment {
    font-size: 32px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
    line-height: 60px;
  }

  .label {
    padding-top: 90px;
    text-align: center;

    span {
      width: 200px;
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(234, 234, 234, 1);
      border-radius: 36px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
      line-height: 72px;
      text-align: center;
      display: inline-block;
      margin-right: 25px;

      img {
        width: 34px;
        height: 34px;
        display: inline-block;
        vertical-align: middle;
        margin-top: -3px;
        margin-right: 10px;
      }

      label {
        display: inline-block;
        vertical-align: middle;
      }
    }

    span:last-child {
      margin-right: 0;
    }

    span.active {
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(211, 163, 88, 1);
      border-radius: 36px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(211, 163, 88, 1);
    }
  }

  button.shareWeChat {
    display: inline-block;
    vertical-align: middle;
    padding-left: 0px;
    padding-right: 0px;
    line-height: 10px;
    background-color: rgba(255, 255, 255, 0);
  }

  button.shareWeChat::after {
    width: 0;
    height: 0;
    top: 0;
    left: 0;
    border: none;
  }

  .fixed {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    z-index: 100;
    background: #fff;
    border-top: 2px solid rgba(234, 234, 234, 1);
    box-sizing: border-box;
    padding: 15px 30px;

    .input {
      font-size: 28px;
      font-weight: 500;
      color: rgba(52, 52, 52, 1);
      line-height: 64px;
      background: rgba(246, 246, 246, 1);
      display: inline-block;
      padding: 6px 30px;
      border-radius: 32px;
      padding-right: 210px;

      img {
        width: 32px;
        height: 32px;
        display: inline-block;
        margin-right: 13px;
        vertical-align: middle;
        margin-top: -5px;
      }

      span {
        vertical-align: middle;
      }
    }

    .fixed-content {
      display: inline-block;
      vertical-align: middle;

      .zhengwen {
        font-size: 28px;
        font-weight: 500;
        color: rgba(52, 52, 52, 1);
        margin-left: 55px;

        img {
          width: 38px;
          height: 38px;
          margin-top: -3px;
          vertical-align: middle;
          margin-right: 10px;
        }

        span {
          vertical-align: middle;
        }
      }

      .like {
        display: inline-block;
        width: 38px;
        height: 38px;
        margin-left: 55px;
        vertical-align: middle;
      }

      .transpond {
        display: inline-block;
        width: 42px;
        height: 38px;
        margin-left: 55px;
        vertical-align: middle;
      }

    }
  }

  .comment {
    .comment-title {
      font-size: 28px;
      font-weight: bold;
      color: rgba(51, 51, 51, 1);
      line-height: 50px;

      span {
        position: relative;

        &:before {
          position: absolute;
          left: 50%;
          bottom: -10px;
          transform: translate(-50%, 0);
          content: '';
          display: block;
          width: 60px;
          height: 6px;
          background: rgba(211, 163, 88, 1);
          border-radius: 3px;
        }
      }
    }

    >.comment-content {
      .allView {
        font-size: 26px;
        font-weight: 500;
        color: rgba(211, 163, 88, 1);
        line-height: 50px;
        padding-left: 136px;
        margin-bottom: 30px;
      }

      &:after {
        content: '';
        display: block;
        height: 2px;
        background: rgba(234, 234, 234, 1);
        margin-left: 72px;
      }

      .comment-item {
        padding-top: 20px;

        .allView {
          font-size: 26px;
          font-weight: 500;
          color: rgba(211, 163, 88, 1);
          line-height: 50px;
        }

        .headimg {
          display: inline-block;
          vertical-align: top;
          margin-top: 15px;

          img {
            width: 72px;
            height: 72px;
            display: inline-block;
            border-radius: 50%;
          }
        }

        .comment-li {
          width: 600px;
          display: inline-block;
          vertical-align: top;
          padding-left: 20px;
          padding-bottom: 20px;

          .comment-li-title {
            font-size: 28px;
            font-weight: bold;
            color: rgba(51, 51, 51, 1);
            line-height: 50px;

            span {
              font-size: 28px;
              font-weight: 500;
              color: rgba(102, 102, 102, 1);
              line-height: 50px;
              float: right;

              img {
                width: 34px;
                height: 34px;
                display: inline-block;
              }
            }

            .active {
              font-size: 28px;
              font-weight: 500;
              color: rgba(211, 163, 88, 1);
            }
          }

          .comment-li-des {
            font-size: 32px;
            font-weight: 500;
            color: rgba(51, 51, 51, 1);
            line-height: 50px;
          }

          .comment-li-time {
            font-size: 24px;
            font-weight: 500;
            color: rgba(204, 204, 204, 1);
            line-height: 50px;

            span {
              font-size: 24px;
              font-weight: 500;
              color: rgba(51, 51, 51, 1);
              line-height: 50px;
              margin-left: 30px;
            }
          }
        }
      }

      .comment-content {
        padding-left: 72px;

        .comment-item {
          border-bottom: none;

          .headimg {
            margin-top: 0;

            img {
              width: 48px;
              height: 48px;
              border-radius: 50%;

            }
          }

          .comment-li {
            width: 528px;
          }
        }
      }
    }
  }

  .inContent {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.4);
    z-index: 100;
  }

  .inContent-content {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    z-index: 100;
    background: #fff;
    z-index: 100;
    overflow: hidden;
    padding: 30px;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;

    textarea {
      width: 690px;
      height: 140px;
      background: rgba(246, 246, 246, 1);
      border-radius: 8px;
      margin-bottom: 20px;
      line-height: 30px;
      padding: 15px 20px;
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
    }

    .send {
      width: 132px;
      line-height: 60px;
      background: rgba(211, 163, 88, 1);
      border-radius: 30px;
      text-align: center;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      float: right;
    }
  }
</style>
