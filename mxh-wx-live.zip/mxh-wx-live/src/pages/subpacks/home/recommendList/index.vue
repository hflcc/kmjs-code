<template>
  <section>
    <div class="recommend-content">
      <div class="item-list" v-for="(item,index) in list" :key="index" @click="goDetails(item)">
        <div class="item-list-l-content">
          <div class="item-list-l">
            <div class="item-list-l-title">
              <span class="item-list-l-label" v-if="item.type ==0 && item.status == 0">预告</span>
              <span class="item-list-l-label" v-if="item.type ==1">录播</span>
              <span class="item-list-l-label" v-if="(item.type ==2 && item.status==0)">直播课</span>
              <span class="item-list-l-label" v-if="(item.type ==2 && item.status==1) || (item.type ==0 && item.status==1) ">直播中</span>
              <span class="item-list-l-label" v-if="(item.type ==0 && item.status == 2) || (item.type ==2 && item.status == 2) ">直播课</span>
              {{item.title}}</div>
            <div class="item-list-text" v-html="item.text"></div>
          </div>
          <div class="item-list-r">
            <img :src="item.url" mode="widthFix">
          </div>
        </div>
        <div class="item-list-content-2">
          <span class="type" v-if="item.mxhLiveVideoPlayType && item.mxhLiveVideoPlayType.type == 1">加密</span>
          <span class="type" v-else>免费</span>
          <span class="number">· {{item.viewTotal}}人</span>
          <span class="time" v-if="item.type ==0 || item.type ==2">{{item.startTime}}</span>
          <span class="time" v-if="item.type ==1">{{item.label}}</span>
        </div>
      </div>
    </div>
    <auth></auth>
  </section>
</template>
<script>
  import auth from '@/components/auth'
  export default {
    data() {
      return {
        form: {
          page: 1,
          pageSize: 10,
        },
        list: [],
        topicId: '',
      }
    },
    components: {
      auth,
    },
    onLoad(options) {
      this.form = {
        page: 1,
        pageSize: 10,
      }
      this.list = []
      this.topicId = options.topicId
      this.getList()
    },
    methods: {
      getList() {
        let url = '/liveVideo/get/topic/' + this.topicId + '/' + this.form.page + '/' + this.form.pageSize
        this.$http.get(url).then(res => {
          this.list = this.list.concat(res.data)
        })
      },
      goDetails(item) {
        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        if (item.liveType == 1) {
          wx.navigateTo({
            url: '/pages/details/main?liveId=' + item.id
          })
        } else {
          wx.navigateTo({
            url: '/pages/verticalLive/main?liveId=' + item.id
          })
        }
      }
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: #f8f8f8;
    overflow: scroll;
    width: 100%;
    overflow-x: hidden;
    min-height: 100vh;
  }


  .recommend-content {
    padding: 30px;
    overflow: hidden;

    .recommend-title {
      font-size: 34px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      padding: 40px 0 20px 0;

      .more {
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 10px;
      }
    }
  }

  .item-list {
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;
    padding: 0 30px;
    width: 690px;
    box-sizing: border-box;
    margin: 0 auto;
    margin-bottom: 30px;

    .item-list-l-content {
      overflow: hidden;
      border-bottom: 2px solid rgba(246, 246, 246, 1);
      padding-bottom: 40px;
      padding-top: 40px;

      .item-list-l {
        float: left;
        width: 408px;
        margin-right: 30px;
      }

      .item-list-r {
        float: left;

        img {
          width: 190px;
          height: 114px;
          border-radius: 8px;
        }
      }
    }

    .item-list-content-2 {
      padding: 20px 0 30px 0;

      .type {
        font-size: 24px;
        font-weight: 500;
        color: #D3A358;
        margin-right: 40px;
      }

      .number {
        font-size: 24px;
        font-weight: 500;
        color: rgba(51, 51, 51, 1);
      }

      .time {
        padding: 0 15px;
        line-height: 35px;
        background: rgba(243, 244, 245, 1);
        border-radius: 17px;
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        float: right;
        margin-top: 7px;
      }
    }
  }
</style>
