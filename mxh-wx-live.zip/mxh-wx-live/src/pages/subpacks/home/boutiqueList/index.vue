<template>
  <section>
    <div class="recommend-content2">
      <div class="item" v-for="(item,index) in list" :key="index" @click="goDetails(item,index)">
        <div class="product-img"><img :src="item.url" alt="" mode="widthFix"></div>
        <div class="product-text">{{item.title}}</div>
        <div class="product-label">{{item.corporateType == 1 ? '企业频道' : '个人频道'}}</div>
        <div class="product-info" v-html="item.text"></div>
      </div>
    </div>
    <auth></auth>
  </section>
</template>
<script>
  import auth from '@/components/auth'
  export default {
    data() {
      return {
        form: {
          page: 1,
          pageSize: 10,
        },
        list: []
      }
    },
    components: {
      auth,
    },
    onLoad() {
      this.form = {
        page: 1,
        pageSize: 10,
      }
      this.list = []
      this.getList()
    },
    // 上拉加载
    onReachBottom() {
      this.form.page++
      this.getList()
    },
    methods: {
      getList() {
        let url = '/liveVideo/list/' + this.form.page + '/' + this.form.pageSize
        let data = {
          type: '-1',
          recommend: '1',
        }
        this.$http.post(url, data).then(res => {
          this.list = this.list.concat(res.data)
        })
      },
      goDetails(item) {
        // wx.navigateTo({
        //   url: '/pages/details/main?liveId=1793'
        // })


        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        if (item.liveType == 1) {
          wx.navigateTo({
            url: '/pages/details/main?liveId=' + item.id
          })
        } else {
          wx.navigateTo({
            url: '/pages/verticalLive/main?liveId=' + item.id
          })
        }
      },
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: #f8f8f8;
    overflow: scroll;
    width: 100%;
    overflow-x: hidden;
    min-height: 100vh;
  }

  .item:nth-child(2n-1) {
    margin-right: 20px;
  }

  .recommend-content2 {
    padding: 30px;
  }

  .item {
    width: 335px;
    float: left;
    margin-bottom: 20px;
    padding-bottom: 20px;
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;

    .product-img {
      position: relative;
      height: 200px;
      overflow: hidden;

      img {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
      }
    }

    .product-text {
      font-size: 30px;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
      line-height: 60px;
      padding: 0 10px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      overflow: hidden;
      height: 60px;
    }

    .product-label {
      width: 90px;
      height: 30px;
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(211, 163, 88, 1);
      border-radius: 4px;
      font-size: 20px;
      font-weight: 500;
      color: rgba(211, 163, 88, 1);
      margin-left: 10px;
      margin-bottom: 10px;
      text-align: center;
    }

    .product-info {
      padding: 0 10px;
      font-size: 22px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      line-height: 30px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  }
</style>
