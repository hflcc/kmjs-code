<template>
  <section>
    <div class="item" v-for="(item,index) in list" :key="index" @click="goEnterpriseHome(item)">
      <img :src="item.headImgurl" class="img">
      <div class="content">
        <div class="name">{{item.nickName}}</div>
        <div class="des" v-html="item.profile || ''"></div>
        <div class="attention" v-if="item.isAttention == 1" @click.stop="attention(item)">已关注</div>
        <div class="attentioned" v-else @click.stop="attention(item)">关注</div>
      </div>
    </div>
    <auth></auth>
  </section>
</template>
<script>
  import auth from '@/components/auth'
  export default {
    data() {
      return {
        form: {
          page: 1,
          pageSize: 10,
        },
        list: []
      }
    },
    components: {
      auth,
    },
    onShow() {
      this.form = {
        page: 1,
        pageSize: 10,
      }
      this.list = []
      this.getList()
    },
    // 上拉加载
    onReachBottom() {
      this.form.page++
      this.getList()
    },
    methods: {
      getList() {
        let url = '/home/get/recommendAttention/' + this.form.page + '/' + this.form.pageSize
        this.$http.get(url).then(res => {
          this.list = this.list.concat(res.data)
        })
      },
      goEnterpriseHome(item) {
        wx.navigateTo({
          url: '/pages/personalHome/main?userId=' + item.id
        })
      },
      attention(item) {
        if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
          this.$store.commit("setIsLogin", true);
          return false
        }
        this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
        let url = '/userConcern/saveMxhUserConcern'
        let data = {
          concernUserId: item.id,
        }
        this.$http.post(url, data).then(res => {
          if (item.isAttention == 1) {
            item.isAttention = 0
          } else {
            item.isAttention = 1
          }
        })
      },
    }
  }
</script>
<style lang='less' scoped>
  .item {
    padding: 20px 30px;
    overflow: hidden;

    .img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      display: inline-block;
      float: left;
      padding: 8px;
      border: 2px solid rgba(234, 234, 234, 1);
    }

    .content {
      position: relative;
      display: inline-block;
      width: 535px;
      float: left;
      padding-left: 20px;

      .name {
        font-size: 32px;
        font-weight: bold;
        color: rgba(33, 33, 33, 1);
        width: 380px;
        margin: 10px 0;
      }

      .des {
        font-size: 24px;
        font-weight: 500;
        color: rgba(101, 101, 101, 1);
        line-height: 36px;
        width: 380px;
        white-space: normal;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      .attention {
        position: absolute;
        top: 50%;
        right: 0px;
        transform: translate(0, -50%);
        border: 2px solid rgba(233, 233, 233, 1);
        width: 128px;
        height: 56px;
        background: rgba(255, 255, 255, 1);
        border-radius: 8px;
        font-size: 28px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        line-height: 56px;
        text-align: center;
      }

      .attentioned {
        position: absolute;
        top: 50%;
        right: 0px;
        transform: translate(0, -50%);
        border: 2px solid rgba(211, 163, 87, 1);
        width: 128px;
        height: 56px;
        background: rgba(211, 163, 87, 1);
        border-radius: 8px;
        font-size: 28px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        line-height: 56px;
        text-align: center;
      }
    }
  }
</style>
