<template>
  <section @longtap="downloadImg">
    <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/android_bg_code.png">
  </section>
</template>
<script>
  export default {
    data() {
      return {}
    },
    onLoad() {},
    methods: {
      downloadImg() { //下载文件资源到本地，客户端直接发起一个 HTTP GET 请求，返回文件的本地临时路径
        var _this = this
        let url = "https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/android_mxh.png"
        wx.downloadFile({
          url: url,
          success(res) {
            wx.saveImageToPhotosAlbum({ // 下载成功后再保存到本地
              filePath: res.tempFilePath, //返回的临时文件路径，下载后的文件会存储到一个临时文件
              success() {
                _this.sharePop = !_this.sharePop
                wx.showToast({
                  title: '图片保存成功',
                  icon: 'none',
                  duration: 2000
                })
              }
            })
          }
        })
      },
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: url(https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/home/android_bg.png);
    background-size: 100% 100%;
    overflow: scroll;
    width: 100%;
    overflow-x: hidden;
    min-height: 100vh;
    position: relative;
  }

  img {
    width: 464px;
    height: 833px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
</style>
