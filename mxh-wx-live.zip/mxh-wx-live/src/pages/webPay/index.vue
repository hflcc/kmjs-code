<template>
  <view class="content" v-if="url">

  </view>
</template>
<script>
  import {
    shopH5web
  } from '@/utils/domain.js'
  export default {
    data() {
      return {
        url: '',
        form: {
          money: '',
          orderNumber: '',
          payOrderNo: ''
        }
      }
    },
    onLoad(options) {
      this.form.money = options.money
      this.form.orderNumber = options.goodsOrderNumber
      this.form.payOrderNo = options.payOrderNo
      this.pay()
      // if(options.url){
      //     if(options.url.indexOf('@') > -1){
      //         wx.setStorageSync('url',options.url.replace('@','?'))
      //     }
      // }
      // this.url =  wx.getStorageSync('url')
    },
    methods: {
      /**
       * 获取积分列表弹窗详情数据
       */
      async pay() {
        let that = this
        let url = '/wechat/pay'
        let data = {
          money: 0.01,
          orderNumber: this.form.orderNumber,
          payOrderNo: this.form.payOrderNo
        }
        await this.$http.post(url, data).then((res) => {
          if (res.code == 0) {
            console.log(res.data)
            wx.requestPayment({
              timeStamp: res.data.timeStamp,
              nonceStr: res.data.nonceStr,
              package: res.data.package,
              signType: 'MD5',
              paySign: res.data.paySign,
              success(res) {
                wx.setStorageSync('url', shopH5web + '/orderPaySuccess/' + that.form.orderNumber)
                wx.navigateTo({
                  url: '/pages/webView/main'
                })
              },
              fail(res) {
                that.$store.commit('showToast', {
                  title: res
                })
                wx.navigateBack({
                  delta: 1
                })
              }
            })
          }
        })
      },
    }
  }
</script>
<style scoped>
</style>
