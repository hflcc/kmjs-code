<template>
  <view class='exasw-com'>
    <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/examination.png" class="examination">
    <!-- <swiper :current="currentTab" duration="300" class='asw-box' bindchange="swiperTab" style="min-height:700px" v-if="isQuestion"> -->
    <view class='asw-box' v-if="isQuestion">
      <block v-for="(item,index) in subAswData" :key="index" v-if="index == currentTab">
        <view class="answer-content">
          <view class="content">
            <view class="cont-tit">
              <view class="L a-tit">
                <label v-if="item.type==0" class="gap"> 单项题 </label>
                <label v-else-if="item.type==1" class="gap"> 多项题 </label>
                <label v-else-if="item.type==2" class="gap"> 填空题 </label>
                <label v-else-if="item.type==3" class="gap">简答题</label>
              </view>
              <view class="R aswNum"><text>{{currentTab+1}}</text>/{{subAswData&&subAswData.length}}</view>
            </view>
          </view>
          <view class='exam-com'>
            <view class='exam-title'>{{item.title}}<text> {{item.aswType}}</text></view>
            <block v-if="item.type==0">
              <radio-group class="radio-group">
                <label class="radio change-item" :class="its.selected ? 'radioActive':''" v-for="(its,idx) in item.mxhExamAnswerList"
                  :key="idx" @click="radioChange(item.mxhExamAnswerList,idx)">
                  <view class="ra-text">
                    <span v-if="idx == 0">A、</span>
                    <span v-if="idx == 1">B、</span>
                    <span v-if="idx == 2">C、</span>
                    <span v-if="idx == 3">D、</span>
                    <span v-if="idx == 4">E、</span>
                    <span v-if="idx == 5">F、</span>
                    <span v-if="idx == 6">G、</span>
                    {{its.text}}</view>
                </label>
              </radio-group>
            </block>
            <block v-if="item.type==1">
              <checkbox-group class="checkbox-group">
                <radio-group class="radio-group">
                  <label class="radio change-item" :class="its.selected ?'radioActive':''" v-for="(its,idx) in item.mxhExamAnswerList"
                    :key="idx" @click="multipleChange(item.mxhExamAnswerList,idx)">
                    <view class="ra-text">
                      <view class="select active" v-if="its.selected"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/active.png"></view>
                      <view class="select" v-else></view>
                      <span v-if="idx == 0">A、</span>
                      <span v-if="idx == 1">B、</span>
                      <span v-if="idx == 2">C、</span>
                      <span v-if="idx == 3">D、</span>
                      <span v-if="idx == 4">E、</span>
                      <span v-if="idx == 5">F、</span>
                      <span v-if="idx == 6">G、</span>
                      {{its.text}}
                    </view>
                  </label>
                </radio-group>
              </checkbox-group>
            </block>
            <block v-if="item.type==2 || item.type==3">
              <textarea class='aswTarea' maxlength="-1" v-model="item.value" auto-height placeholder="填写你的答案"
                style-placeholder="color:#ccc" />
              </block>
            <button class="exam-footer " :class="showActive?'btnActive':''" :disabled='showActive' @click="nextQuestion">确定</button>
          </view>
        </view>
      </block>
    </view>
    <!-- </swiper> -->
   <!--  <view v-else-if="!isQuestion" class="answer_success"> -->
     <view v-else-if="!isQuestion" class="answer_success">
        <view class="correctQuestionNumber">
          <view class="title">本次答对题目数</view>
          <view class="number">{{resultObj.correctQuestionNumber}}</view>
        </view>
        <img src="../../../static/images/answer_bg.png" class="answer_bg">
        <view class="answer_content">
            <view class="left">
                 <view >正确率：{{resultObj.accuracy}}%</view>
                 <view >用时：{{time}}</view>
            </view>
            <view class="right">
                 <view >答题数：{{resultObj.questionNumber}}</view>
                 <view >错题数：{{resultObj.questionNumber-resultObj.correctQuestionNumber}}</view>
            </view>
             <button @click="goBack">返回</button>
        </view>
    </view>
  </view>
</template>
<script>
export default {
  data () {
    return {
      isQuestion: true,
      page: null,
      currentTab: 0,
      activeIdx: null,
      subAswData: [],
      liveVideoId: '',
      title: '',
      examId: '',
      resultObj: {}, // 考试结果
      time:'',
      loading: false,
      mxhExamTextList:wx.getStorageSync('mxhExamTextList')
    }
  },
  onLoad (options) {
    this.mxhExamTextList = wx.getStorageSync('mxhExamTextList')
    console.log(this.mxhExamTextList)
    this.liveId = options.liveId
    this.initData()
  },
  onUnload() {
    this.isQuestion =true
    this.page =null
    this.currentTab =0
    this.activeIdx =null
    this.subAswData =[]
    this.liveVideoId =''
    this.title =''
    this.examId =''
    this.resultObj ={} // 考试结果
  },
  methods:{
    // 单选
    radioChange (item, i) {
      item.forEach((res)=>{
        res.selected = false
      })
      this.$set(item[i],'selected',!item[i].selected)
    },
    multipleChange(item,i){
      this.$set(item[i],'selected',!item[i].selected)
    },
    // 下一题
    nextQuestion () {
      if(this.subAswData[this.currentTab].type == 0){
        var state = false
        this.subAswData[this.currentTab].mxhExamAnswerList.forEach((res)=>{
          if(res.selected){
            state = true
          } 
        })
        if(!state){
          this.$store.commit('showToast', { title: '请选择' })
          return false
        }
      }
      if(this.subAswData[this.currentTab].type == 1){
        var state = false
        this.subAswData[this.currentTab].mxhExamAnswerList.forEach((res)=>{
          if(res.selected){
            state = true
          } 
        })
        if(!state){
          this.$store.commit('showToast', { title: '请选择' })
          return false
        }
      }
      if(this.subAswData[this.currentTab].type == 2){
        if(!this.subAswData[this.currentTab].value){
          this.$store.commit('showToast', { title: '请输入' })
          return false
        }
      }

      if (this.subAswData.length > this.currentTab + 1) {
        this.currentTab += 1
      } else if (this.subAswData.length == this.currentTab + 1) {
        this.submitExamResults()
      }
    },
    // 初始化
    initData () {
      let url = '/exam/get/videoLive/' + this.liveId
      this.$http.get(url).then(res => {
        if (res.data.isExam == 1) {
          this.isQuestion = false
        }else{
          this.isQuestion = true
        }
        res.data.examQuestionVoList.forEach((res)=>{
          if(res.type == 0 || res.type == 1){
            res.mxhExamAnswerList.forEach((res)=>{
              res.selected = false
            })
          }
          if(res.type ==3){
            res.value = ''
          }
        })
        this.subAswData = res.data.examQuestionVoList
        this.examId = res.data.mxhExam.id
        this.liveVideoId = res.data.mxhExam.liveVideoId
        this.title = res.data.mxhExam.title
      })
    },
    // 考试结果
    submitExamResults () {
      if(this.loading){
        return false
      }
      this.loading = true
      let url = '/exam/send/submitExamResults'
      let mxhExamTextList = []
      this.mxhExamTextList.forEach((item) => {
        mxhExamTextList.push({
          id: item.id,
          examText:item.text,
        })
      })
      let data = {
        examId: this.examId,
        liveVideoId: this.liveVideoId,
        mobile: wx.getStorageSync('mobile'),
        title: this.title,
        userName: wx.getStorageSync('name'),
        examUserAnswerVoList: [],
        mxhExamTextList:  mxhExamTextList
      }
      this.subAswData.forEach((res)=>{
        this.loading = false
        if(res.type == 0){
          res.mxhExamAnswerList.forEach((res2)=>{
            if(res2.selected){
              var resultStr=res2.serialNumber.replace(/\ +/g,"").replace(/[ ]/g,"").replace(/[\r\n]/g,"");//去掉空格
              data.examUserAnswerVoList.push({
                examQuestionId: res.id,
                text: resultStr
              })
            }
          })
        }
        if(res.type == 1){
          let arr = []
          res.mxhExamAnswerList.forEach((res2)=>{
            if(res2.selected){
              arr.push(res2.serialNumber)
            }
          })
          data.examUserAnswerVoList.push({
            examQuestionId: res.id,
            text: arr.join(",")
          })
        }
        if(res.type == 2 || res.type==3){
          data.examUserAnswerVoList.push({
            examQuestionId: res.id,
            text: res.value
          })
        }
      })
      this.$http.post(url, data).then(res => {
        if (res.code == 0) {
          this.isQuestion = false
          this.resultObj = res.data
          let accuracy = this.resultObj.correctQuestionNumber / this.resultObj.questionNumber * 100
          if (accuracy > 0) {
            this.resultObj.accuracy = accuracy.toFixed(2)
          } else {
            this.resultObj.accuracy = 0
          }
          this.time = this.toHHmmss(new Date().getTime() - wx.getStorageSync('startExamTime'))
          
        }
      })
    },
    toHHmmss (data) {
       var time;
       var hours = parseInt((data % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
       var minutes = parseInt((data % (1000 * 60 * 60)) / (1000 * 60));
       var seconds =  parseInt((data % (1000 * 60)) / 1000);
       time = (hours < 10 ? ('0' + hours) : hours) + ':' + (minutes < 10 ? ('0' + minutes) : minutes) + ':' + (seconds < 10 ? ('0' + seconds) : seconds);
       return time;
    },
    // 返回
    goBack () {
      this.currentTab = 0
      wx.navigateBack({delta: 2})
      // wx.navigateTo({ url: '/pages/details/main?liveId=' +  this.liveId })
    }
  }
}
</script>
<style lang='less' scoped>
.exasw-com {
  background: #f5f5f5;
  min-height: 100vh;
  .examination {
    width: 100%;
    height: 140px;
  }
  .asw-box {
    width: 690px;
    margin: 0 auto ;
    background: #fff;
    box-shadow: 0px 4px 10px 0px rgba(218, 218, 218, 0.6);
    border-radius: 8px;
    padding-bottom: 80px;
  }
  .answer-content{
    overflow-y: scroll;
    height: 100%;
  }
  .content {
    .cont-tit {
      display: flex;
      justify-content: space-between;
      border-bottom: 2px solid #f6f6f6;
      height: 80px;
      line-height: 80px;
      padding-right: 30px;
      .a-tit {
        font-size: 30px;
        font-weight: bold;
        color: rgba(34, 34, 34, 1);

        padding-left: 20px;
        margin-bottom: 20px;
        &::before {
          content: "|";
          width: 6px;
          height: 32px;
          display: inline-block;
          color: #d3a358;
          margin-right: 10px;
        }
        .single{
          color:#d3a358;
        }
        .multiple{
          color: red;
        }
        .simpleness{
          color: #b457ff
        }
        .gap{
          color: #222222
        }
      }
      .aswNum {
        color: #999;
        font-size: 24px;
        text {
          color: #222222;
          font-size: 48px;
          font-weight: bold;
        }
      }
    }
  }
  .exam-com {
    padding: 0 30px;
    .exam-title {
      padding-top: 20px;
      font-size: 28px;
      font-family: PingFang SC;
      font-weight: 500;
      color: rgba(34, 34, 34, 1);
      line-height: 48px;
    }
    .radio-group {
      padding-top: 50px;
      .change-item {
        box-sizing: border-box;
        display: inline-block;
        width: 630px;
        background: rgba(248, 248, 248, 1);
        border: 2px solid rgba(234, 234, 234, 1);
        border-radius: 6px;
        margin: 30px auto 0;

        .ra-text {
          padding: 24px 30px;
          color: #222222;
          font-size: 24px;
          .select.active{
            width: 40px;
            height: 40px;
            border-radius: 100%;
            overflow: hidden;
            vertical-align: middle;
            display: inline-block;
            margin-top: -4px;
            margin-right: 20px;
            img{
              width: 40px;
              height: 40px;
            }
          }
          .select{
            width:40px;
            height:40px;
            background:rgba(255,255,255,1);
            border:2px solid rgba(234,234,234,1);
            border-radius:50%;
            overflow: hidden;
            vertical-align: middle;
            display: inline-block;
            margin-top: -4px;
            margin-right: 20px;
          }
          .show{
            display: block;
          }
          .hide{
            display: none;
          }
        }
      }
      .radioActive {
        border: 2px solid #d3a358;
      }
    }
    .aswTarea {
      margin-top: 80px;
      width: 630px;
      height: 400px !important;
      background: rgba(248, 248, 248, 1);
      border: 1px solid rgba(234, 234, 234, 1);
      border-radius: 6px;
      padding: 30px;
      box-sizing: border-box;
    }
  }
  .exam-footer {
    width: 400px;
    height: 80px;
    line-height: 80px;
    background: #d3a358;
    border-radius: 40px;
    margin: 120px auto 0;
    text-align: center;
    font-size: 28px;
    font-family: PingFang SC;
    font-weight: 500;
    color: rgba(255, 255, 255, 1);
  }
  .btnActive {
    background: rgba(234, 234, 234, 1);
    color: #999999;
  }
  .answer_success {
    margin: 0 auto;
    width: 690px;
    position: relative;
    .correctQuestionNumber{
      position: absolute;
      z-index: 100;
      .title{
        font-size: 32px;
        font-weight:500;
        color:rgba(255,255,255,1);
        margin-bottom: 30px;
        padding-left:20px;
        line-height: 50px;
        padding-top: 30px;
      }
      .number{
        font-size:72px;
        font-weight:500;
        color:rgba(255,255,255,1);
        line-height:38px;
        padding-left:30px;
      }
    }
    .answer_bg {
      width: 690px;
      height: 240px;
      vertical-align: bottom;
    }
    .answer_content {
      background: rgba(255, 255, 255, 1);
      box-shadow: 0px 4px 10px 0px rgba(218, 218, 218, 0.6);
      border-bottom-right-radius: 8px;
      border-bottom-left-radius: 8px;
      height: 500px;
      padding: 0 59px;
      .left {
        padding-top: 59px;
        display: flex;
        justify-content: space-between;
        view {
          flex: 1;
          text-align: left;
        }
      }
      .right {
        padding-top: 70px;
        display: flex;
        justify-content: space-between;
        view {
          flex: 1;
          text-align: left;
        }
      }
      button {
        width: 400px;
        height: 80px;
        line-height: 80px;
        background: #d3a358;
        border-radius: 40px;
        margin: 120px auto 0;
        color: #fff;
      }
    }
  }
}
</style>
