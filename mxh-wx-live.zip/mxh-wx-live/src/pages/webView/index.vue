<template>
  <view class="content" v-if="url">
    <web-view :src="url"></web-view>
  </view>
</template>
<script>
  export default {
    data() {
      return {
        url: ''
      }
    },
    onLoad(options) {
      if (options.url) {
        if (options.url.indexOf('@') > -1) {
          wx.setStorageSync('url', options.url.replace('@', '?'))
        }
      }
      this.url = wx.getStorageSync('url')
    },
    methods: {}
  }
</script>
<style scoped>
</style>
