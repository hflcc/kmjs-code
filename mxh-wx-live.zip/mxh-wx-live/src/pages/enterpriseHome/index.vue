<template>
  <section class="content">
    <div class="bg">
      <img :src="userinfo.backgroundUrl" alt="">
    </div>
    <div class="info">
      <img :src="userinfo.headImgUrl" alt="" class="head">
      <div class="head-content">
        <div class="text">
          <span>{{userinfo.fansAmount}}<font>粉丝</font></span>
          <span>{{userinfo.attentionAmount}}<font>关注</font></span>
        </div>
        <div class="attention" @click="attention" v-if="userinfo.isAttention == 1">取消关注</div>
        <div class="attention" @click="attention" v-if="userinfo.isAttention == 0">关注</div>
      </div>
      <div class="name">{{userinfo.nickName}} <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/enterprise.png" alt="" class="logo"></div>
      <div class="des-content" :class="!more ? 'active' : ''">
        <div class="des" v-html="userinfo.profile">
         <!--  {{userinfo.profile || ''}} -->
          
        </div>
      </div>
      <span @click="clickMore" v-if="!more" class="more">更多</span>
      <span @click="clickMore" v-if="more" class="more">收起</span>
    </div>
    <div class="tab">
      <div class="li" :class="current == 0 ? 'active' : ''" @click="clickTab(0)" style="width:25%">直播</div>
      <div class="li" :class="current == 1 ? 'active' : ''" @click="clickTab(1)" style="width:25%">视频</div>
      <div class="li" :class="current == 2 ? 'active' : ''" @click="clickTab(2)" style="width:25%">文章</div>
      <div class="li" :class="current == 3 ? 'active' : ''" @click="clickTab(3)" style="width:25%">测试</div>
    </div>
    <div :autoplay="autoplay" :current="current" @change="bindchangeswiper" class="swiper-content">
      <div v-if="current == 0" style="overflow:hidden">
       <!--  <scroll-view class="item-content" scroll-y="true" @scrolltolower="bindscrolltolower"> -->
          <div v-if="list.length && !loading">
            <div class="item-list" v-for="(item,index) in list" :key="index" @click="goDetails(item)">
              <div class="item-list-l-content">
                <div class="item-list-l">
                  <div class="item-list-l-title">
                    <span class="item-list-l-label" v-if="item.type ==0 && item.status == 0">预告</span>
                    <span class="item-list-l-label" v-if="item.type ==1">录播</span>
                    <span class="item-list-l-label" v-if="(item.type ==2 && item.status==0)">直播课</span>
                    <span class="item-list-l-label" v-if="(item.type ==2 && item.status==1) || (item.type ==0 && item.status==1) ">直播中</span>
                    <span class="item-list-l-label" v-if="(item.type ==0 && item.status == 2) || (item.type ==2 && item.status == 2) ">直播课</span>
                    {{item.title}}</div>
                  <div class="item-list-text" v-html="item.text"></div>
                </div>
                <div class="item-list-r">
                  <img :src="item.url" mode="widthFix">
                </div>
              </div>
              <div class="item-list-content-2">
                <span class="type" v-if="item.mxhLiveVideoPlayType && item.mxhLiveVideoPlayType.type == 1">加密</span>
                <span class="type"  v-else>免费</span>
                <span class="number">· {{item.viewTotal}}人</span>
                <span class="time" v-if="item.type ==0 || item.type ==2">{{item.startTime}}</span>
                <span class="time" v-if="item.type ==1">{{item.label}}</span>
              </div>
            </div>
          </div>
          <div class="nodeData" v-if="!list.length && !loading">
            <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/kong.png" alt="">
            <div>当前暂无内容哦~</div>
          </div>
       <!--  </scroll-view> -->
      </div>
      <div v-if="current == 1">
        <!-- <scroll-view class="item-content" scroll-y="true" @scrolltolower="bindscrolltolower"> -->
          <!--             <div class="item-content"> -->
          <div v-if="list.length && !loading">
            <div class="item" v-for="(item,index) in list" :key="index" @click="goDetails(item)">
              <div class="product-img"><img :src="item.url" alt="" mode="widthFix"></div>
              <div class="product-text">{{item.title}}</div>
              <div class="product-info">
                <font class="free" v-if="item.mxhLiveVideoPlayType && item.mxhLiveVideoPlayType.type == 1">加密</font>
                <font class="free" v-else>免费</font>
                <!--               <font class="price">￥154.00</font> -->
                <span class="number">{{item.viewTotal}}人学习</span>
              </div>
            </div>
          </div>
          <div class="nodeData"v-if="!list.length && !loading">
            <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/kong.png" alt="">
            <div>当前暂无内容哦~</div>
          </div>
          <!-- </div> -->
        <!-- </scroll-view> -->
      </div>
      <div v-if="current == 2">
        <div v-if="list.length">
          <div class="article-item"  v-for="(item,index) in list" :key="index" @click="goArticle(item)">
            <div class="article-content">
              <div class="article-title">{{item.articleTitle}}</div>
              <div class="article-des" v-html="item.articleComment"></div>
              <div class="article-label"><span>{{item.userName}}</span><!-- <span>568评</span> --><span>{{item.createTime}}</span></div>
            </div>
            <div class="article-img"><img :src="item.articleImgUrl"></div>
          </div>
        </div>
        <div class="nodeData" v-else>
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/kong.png" alt="">
          <div>当前暂无内容哦~</div>
        </div>
      </div>
      <div v-if="current == 3">
        <div class="nodeData">
          <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/kong.png" alt="">
          <div>当前暂无内容哦~</div>
        </div>
      </div>
    </div>
    <auth></auth>
  </section>
</template>
<script>
import auth from '@/components/auth'
export default {
  data() {
    return {
      current: 0,
      autoplay: false,
      userId: '',
      userinfo: {},
      type: 0,
      form: {
        page: 1,
        sizePage: 16,
      },
      list: [],
      mxhUserInfo: {},
      loading: false,
      loadListing: false,
      more: false,

    }
  },
  onLoad(options) {
    this.userId = options.userId
  },
  onShow(){

    this.current = 0
    this.autoplay = false
    this.userinfo = {}
    this.type = 0
    this.form = {
      page:1,
      sizePage:16,
    }
    this.list = []
    this.mxhUserInfo = {}
    this.loading = false
    this.loadListing = false
    this.more= false

    this.getInfo()
    this.getList()
  },
  onUnload() {
    
  },
  components: {
    auth,
  },
  onReachBottom() {
      this.form.page++
      this.getList()
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(res) {
    if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
      this.$store.commit("setIsLogin", true);
      return false
    }
    this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
    let arr = [
      'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_1.png',
      'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_1.png',
      'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_2.png',
      'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_3.png',
      'https://kmjs-mxh.oss-cn-shenzhen.aliyuncs.com/share_4.png',
    ]
  // 来自页面内转发按钮
    return {
      title: '邀请您关注' + this.userinfo.nickName + '线上直播频道',
      path: 'pages/enterpriseHome/main?userId=' + this.userId,
      imageUrl: arr[Math.ceil(Math.random()*4)],
      success: function(res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {}
      },
      fail: function() {
        // 转发失败之后的回调
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          // 用户取消转发
        } else if (res.errMsg == 'shareAppMessage:fail') {
          // 转发失败，其中 detail message 为详细失败信息
        }
      },
      complete: function() {

        // 转发结束之后的回调（转发成不成功都会执行）
      }
    }
  },
  methods: {
    clickMore(){
      this.more = !this.more
    },
    attention() {
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit("setIsLogin", true);
        return false
      }
      this.mxhUserInfo = wx.getStorageSync('mxhUserInfo') ? wx.getStorageSync('mxhUserInfo') : {}
      let url = '/userConcern/saveMxhUserConcern'
      let data = {
        concernUserId: this.userId,
      }
      this.$http.post(url, data).then(res => {
        this.$set(this.userinfo, 'isAttention', !this.userinfo.isAttention)
        if(this.userinfo.isAttention == 1){
          this.userinfo.fansAmount++
        }else{
          this.userinfo.fansAmount--
        }
      })
    },
    bindscrolltolower() {
      // this.list = []
      this.form.page++
      this.getList()
    },
    /**
     * 获取个人信息
     */
    getInfo() {
      let url = '/liveVideo/get/live/user/info/' + this.userId
      this.$http.post(url).then(res => {
        this.userinfo = res.data
      })
    },
    getList() {

      if(this.current == 0 || this.current == 1){
        var url = '/liveVideo/get/user/list/' + this.userId + '/' + this.type + '/' + this.form.page + '/' + this.form.sizePage
      }
      if(this.current == 2){
        var url = '/article/getMxhArticleList/' + this.form.page + '/' + this.form.sizePage
      }
      if(this.current == 3){
        return false
      }
      let data = {
        userId: this.userId
      }
      this.loadListing = true
      this.$http.post(url,data).then(res => {
        this.loading = false
        this.loadListing = false
        this.list = this.list.concat(res.data)
      })
    },
    goDetails(item) {
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit("setIsLogin", true);
        return false
      }
      if(item.liveType == 1){
        wx.navigateTo({
            url: '/pages/details/main?liveId=' + item.id
        })
      }else{
        wx.navigateTo({
            url: '/pages/verticalLive/main?liveId=' + item.id
        })
      }

    },

    goArticle(data){
      if (!wx.getStorageSync('token') || !wx.getStorageSync('mxhUserInfo')) {
        this.$store.commit("setIsLogin", true);
        return false
      }
      wx.navigateTo({
        url:'/pages/subpacks/home/articleDetails/main?articleId=' + data.id
      })
    },

    bindchangeswiper(e) {
      this.list = []
      this.form.page = 1
      this.type = e.target.current
      this.current = e.target.current
      this.getList()
    },
    /**
     * 切换tab
     */
    clickTab(index) {
      if (!this.loadListing) {
        this.list = []
        this.form.page = 1
        this.type = index
        this.current = index
        this.getList()
      }
    },
  }
}

</script>
<style lang="less" scoped>
swiper {
  height: 100vh;
  padding-top: 550px;
  box-sizing: border-box;
}

.item-content {
  height: 100%;
  overflow-y: scroll;
}

.content {
  position: relative;
  background: #fff;
  height: 100vh;
  .bg {
    // position: absolute;
    // left: 0;
    // top: 0;
    // z-index: 1;
    width: 100%;

    img {
      width: 750px;
      height: 300px;
    }
  }

  .info {
    width: 100%;
    background: rgba(255, 255, 255, 1);
    margin: 0 auto;
    position: relative;
    left: 0px;
    top: -100px;
    z-index: 100;
    border-bottom: 2px solid rgba(246, 246, 246, 1);
    padding-bottom: 10px;

    .head {
      width: 112px;
      height: 112px;
      border-radius: 56px;
      display: inline-block;
      vertical-align: middle;
      margin: 30px;
      margin-bottom: 15px;
      margin-top: -80px;
      background:#fff;
    }

    .attention {
      width: 488px;
      height: 60px;
      background: #d3a358;
      border-radius: 30px;
      font-size: 28px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      line-height: 60px;
      text-align: center;
      margin-top: 20px;
    }

    .des-content{
      padding:0 30px;
      padding-left: 20px;
      margin-bottom: 40px;
      position:relative;
    }
    span.more {
        position:absolute;
        right: 30px;
        bottom: 10px;
        color: #d3a358;
        font-size: 30px;
        margin-right: 30px;

        font {
          color: #999999;
          font-size: 24px;
          margin-left: 20px;
        }
      }
    .des-content.active{
      text-overflow: -o-ellipsis-lastline;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      line-clamp: 2;
      -webkit-box-orient: vertical;
    }

    .name {
      font-size: 34px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      padding-left: 30px;
      margin-bottom: 20px;
      margin-top: 10px;

      .logo {
        width: 112px;
        height: 30px;
        vertical-align: middle;
        margin-top: -3px;
      }
    }

    .head-content {
      width: 450px;
      display: inline-block;
      vertical-align: middle;
      padding-top: 20px;


      .text {
        span {
          font-size: 32px;
          font-weight: bold;
          color: rgba(34, 34, 34, 1);
          margin-right: 60px;

          font {
            color: #666;
            font-size: 24px;
            margin-left: 20px;
          }
        }
      }
    }

    .des {
      padding: 0 30px;
      font-size: 26px;
      font-family: PingFang SC;
      font-weight: 500;
      color: rgba(102, 102, 102, 1);
      line-height: 36px;
      padding:0;
      margin: 0;
      
      // text-align: justify;
      // word-break: break-all;
      // text-overflow: ellipsis;
      // display: -webkit-box;
      // -webkit-line-clamp: 2;
      // -webkit-box-orient: vertical;
      // overflow: hidden;
      

      span {
        font-size: 26px;
        font-family: PingFang SC;
        font-weight: 500;
        color: #d3a358;
      }
    }
  }
}

.item {
  width: 330px;
  margin-left: 32px;
  float: left;
  box-shadow: 2px 2px 20px 2px rgba(0, 0, 0, 0.1);
  margin-bottom: 30px;
  padding-bottom: 20px;
  background: #fff;

  .product-img {
    position: relative;
    height: 200px;
    overflow: hidden;

    img {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 100%;
    }
  }

  .product-text {
    font-size: 30px;
    font-weight: 500;
    color: rgba(51, 51, 51, 1);
    line-height: 60px;
    padding: 0 10px;
    text-align: justify;
    word-break: break-all;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    overflow: hidden;
    height: 60px;
  }

  .product-info {
    overflow: hidden;
    padding: 0 10px;

    .free {
      font-size: 30px;
      font-weight: bold;
      color: #d3a358;
      float: left;
    }

    .price {
      font-size: 30px;
      font-weight: bold;
      color: rgba(232, 101, 81, 1);
      float: left;
    }

    .number {
      font-size: 28px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      float: right;
    }
  }
}

.tab {
  // position: fixed;
  // left: 0;
  // top: 450px;
  width: 100%;
  z-index: 1;
  overflow: hidden;
  margin-top: -80px;
  margin-bottom: 20px;

  .li {
    width: 25%;
    text-align: center;
    font-size: 28px;
    font-weight: 500;
    color: rgba(34, 34, 34, 1);
    float: left;
    line-height: 80px;
    position: relative;
  }

  .active {
    color: #d3a358;

    &:before {
      content: '';
      width: 100px;
      height: 4px;
      background: #d3a358;
      border-radius: 2px;
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translate(-50%, 0);
    }
  }
}


.item-list {
  background: rgba(255, 255, 255, 1);
  border-radius: 8px;
  padding: 0 30px;
  width: 690px;
  box-sizing: border-box;
  margin: 0 auto;
  margin-bottom: 30px;
  background: #fff;
  box-shadow: 2px 2px 20px 2px rgba(0, 0, 0, 0.1);
  margin-top: 2px;

  .item-list-l-content {
    overflow: hidden;
    border-bottom: 2px solid rgba(246, 246, 246, 1);
    padding-bottom: 40px;
    padding-top: 40px;

    .item-list-l {
      float: left;
      width: 408px;
      margin-right: 30px;
    }

    .item-list-r {
      float: left;

      img {
        width: 190px;
        height: 114px;
        border-radius: 8px;
      }
    }
  }

  .item-list-content-2 {
    padding: 20px 0 30px 0;

    .type {
      font-size: 24px;
      font-weight: 500;
      color: #d3a358;
      margin-right: 40px;
    }

    .number {
      font-size: 24px;
      font-weight: 500;
      color: rgba(51, 51, 51, 1);
    }

    .time {
      padding: 0 15px;
      line-height: 35px;
      background: rgba(243, 244, 245, 1);
      border-radius: 17px;
      font-size: 24px;
      font-weight: 500;
      color: rgba(153, 153, 153, 1);
      float: right;
      margin-top: 7px;
    }
  }
}

.nodeData {
  // position: absolute;
  // left: 50%;
  // top: 50%;
  // transform: translate(-50%, -50%);
  margin: 0 auto;
  margin-top:100px;
  margin-bottom: 100px;
  text-align: center;
  img {
    width: 202px;
    height: 160px;
    margin-bottom: 20px;
  }

  div {
    font-size: 28px;
    font-weight: 500;
    color: rgba(153, 153, 153, 1);
    line-height: 40px;
    text-align: center;
  }
}
.item-list-l-title {
  font-size: 32px;
  font-weight: 500;
  color: rgba(34, 34, 34, 1);
  margin-bottom: 20px;
  text-align: justify;
  word-break: break-all;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 85px;
  line-height: 40px;
  .item-list-l-label{
    vertical-align: middle;
  }
  span {
    line-height: 35px;
    background: rgba(255, 225, 220, 1);
    border-radius: 17px;
    font-size: 22px;
    font-weight: 500;
    color: rgba(232, 101, 81, 1);
    display: inline-block;
    padding: 0 15px 0 20px;
    vertical-align: middle;
    margin-right: 18px;
    margin-top: -10px;
  }
}

.article-item{
  display:fiex;
  display: -webkit-flex;
  flex-direction:row;
  margin: 0 30px;
  border-bottom: 2px solid rgba(234,234,234,1);
  padding: 20px 0;
  .article-content{
    
    width: 450px;
    .article-title{
      font-size:28px;
      font-weight:500;
      color:rgba(34,34,34,1);
      line-height:40px;
      margin-bottom: 15px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .article-des{
      font-size:24px;
      font-weight:500;
      color:rgba(153,153,153,1);
      line-height:36px;
      margin-bottom: 10px;
      text-align: justify;
      word-break: break-all;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .article-label{
      margin-bottom: 10px;
      span{
        font-size:22px;
        font-weight:500;
        color:rgba(153,153,153,1);
        line-height:42px;
        margin-right: 30px;
      }
    }
  }
  .article-img{
    width:226px;
    height:150px;
    border-radius:4px;
    margin-left: 20px;
    img{
      width:226px;
      height:150px;
      border-radius:4px;
    }
  }
}

</style>
