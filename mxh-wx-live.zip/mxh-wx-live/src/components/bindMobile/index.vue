<template>

  <section @click="close">
    <div class="content" @click.stop="content">
      <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/bind-close.png" alt="" @click="close" class="bind-close">
      <div class="title">绑定手机</div>
      <div class="mobile"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/bind-mobile.png" alt=""><input
          type="number" v-model="mobile" placeholder="请填写您的手机号码" @input="getInputValue" maxlength="11"></div>
      <div class="code"><img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/bind-note.png" alt="">
        <input type="text" placeholder="请输入验证码" v-model="code" maxlength="6">
        <span v-if="!isCodeDisabled" class="code-button" @click="getCode">获取验证码</span>
        <span v-if="isCodeDisabled" class="code-button active">{{codeText}}</span>
      </div>
      <button class="button"  @click="bondUserInfoWithMobile">确定</button>
    </div>
  </section>



  <!--  <section @click="close">
    <div class="content" @click.stop="content">
      <div class="table">
        <div class="table-header">绑定手机</div>
        <div class="mobile"><input type="number" v-model="mobile" name="" placeholder="请填写您的手机号" @input="getInputValue">
          <span v-if="!isCodeDisabled" @click="getCode">获取验证码</span>
          <span v-if="isCodeDisabled">{{codeText}}</span>
        </div>
        <div class="code"><input type="number" v-model="code" name="" placeholder="请输入验证码" @input="getInputValue"></div>
        <button class="button" @click="bondUserInfoWithMobile" :class="isDisabled?'isDisabled':''" :disabled='isDisabled'> 绑定手机</button>
      </div>
    </div>
  </section> -->
</template>
<script>
  import {
    checkPhone
  } from './../../utils/index.js'
  export default {
    data() {
      return {
        name: '',
        mobile: wx.getStorageSync('mxhUserInfo').mobile,
        code: '',
        isDisabled: true,
        isFinish: false,
        liveId: '',
        loading: false,
        codeText: '',
        isCodeDisabled: false,
        bingMobile: wx.getStorageSync('mxhUserInfo').mobile,
        goType: ''
      }
    },
    onLoad(options) {

      this.goType = options.goType
      this.name = ''
      this.mobile = wx.getStorageSync('mxhUserInfo').mobile
      this.isDisabled = true
      this.isFinish = false
      this.code = ''
      this.bingMobile = wx.getStorageSync('mxhUserInfo').mobile
      this.liveId = options.liveId
      // this.getUserInfoByToken()
    },
    onUnload() {
      // this.isQuestion =true
      // this.page =null
      // this.currentTab =0
      // this.activeIdx =null

      this.goType = ''
    },
    methods: {
      close() {
        this.$store.commit('setShowPopup', false)
        this.$emit('close')
      },
      content() {

      },
      // getUserInfoByToken(){
      //   let url = '/user/getUserInfoByToken'
      //   this.$http.get(url).then(res => {

      //   })
      // },
      bondUserInfoWithMobile() {
        // if(!this.name){
        //   wx.showToast({
        //     title: '请填写您的姓名',
        //     icon: 'none'
        //   })
        //   return false
        // }
        if (this.mobile&&this.mobile.length != 11) {
          wx.showToast({
            title: '请输入正确手机号码',
            icon: 'none'
          })
          return false
        }
        if (!this.code) {
          wx.showToast({
            title: '请输入验证码',
            icon: 'none'
          })
          return false
        }
        let url = '/user/bondUserInfoWithMobile'
        let data = {
          openid: wx.getStorageSync('openId'),
          mobile: this.mobile,
          verifyCode: this.code,
        }
        this.$http.post(url, data).then(res => {
          if (res.code == 0) {
            let mxhUserInfo = wx.getStorageSync('mxhUserInfo')
            mxhUserInfo.mobile = this.mobile
            wx.setStorageSync('mxhUserInfo', mxhUserInfo)
            wx.showToast({
              title: '绑定号码成功~',
              icon: 'none'
            })
            setTimeout(() => {
              this.$store.commit('setShowPopup', false)
              this.$emit('confirm')
            }, 1000)

          }else{
          	wx.showToast({
              title: res.msg,
              icon: 'none'
            })
          }
        })
      },
      // 开始考试
      gotoAnswer() {
        if (!this.name) {
          wx.showToast({
            title: '请填写您的姓名',
            icon: 'none'
          })
          return false
        }
        if (this.loading) {
          return false
        }
        this.loading = true

        let url = '/exam/get/videoLive/' + this.liveId
        this.$http.get(url).then(res => {
          this.loading = false
          if (res.code == 0 && res.data == 'ERROR') {
            wx.showToast({
              title: res.msg,
              icon: 'none'
            })
            return false
          }
          if (res.data.isExam == 1) {
            wx.showToast({
              title: '本场考试已作答',
              icon: 'none'
            })
            return false
          } else {
            wx.setStorageSync('name', this.name)
            wx.setStorageSync('mobile', this.mobile)
            wx.setStorageSync('startExamTime', new Date().getTime())
            wx.navigateTo({
              url: '/pages/answer/main?liveId=' + this.liveId
            })
            return true
          }
        })
      },
      /**
       * 发送验证码
       */
      async getCode() {
        if (this.mobile&&this.mobile.length != 11) {
          wx.showToast({
            title: '请输入手机号码',
            icon: 'none'
          })
          // this.$toast.text('请输入手机号码')
          return
        }
        this.isCodeDisabled = true
        let res = await this.$http.post(`/user/verifyCode/${this.mobile}`)
        if (res.code == '0') {
          let timer = 60
          this.codeText = --timer + 's后重新发送'
          let timerId = setInterval(() => {
            if (timer <= 0) {
              timer = 60
              this.codeText = '重新发送'
              this.isCodeDisabled = false
              clearTimeout(timerId)
              timer = null
            } else {
              --timer
              this.codeText = timer + 's后重新发送'
            }
          }, 1000)
          wx.showToast({
            title: '验证码已发送',
            icon: 'none'
          })
          return false
        } else {
          wx.showToast({
            title: res.msg,
            icon: 'none'
          })
        }
      },
      // 监听input值
      getInputValue() {
        if (checkPhone(this.mobile)) {
          this.isDisabled = false
        } else {
          this.isDisabled = true
        }
      }
    }
  }
</script>
<style lang='less' scoped>
  section {
    background: rgba(0, 0, 0, 0.4);
    height: 100vh;
    width: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
  }

  .content {
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: 100;
    background: #fff;
    width: 600px;
    height: 522px;
    background: rgba(255, 255, 255, 1);
    border-radius: 8px;

    .title {
      font-size: 36px;
      font-weight: bold;
      color: rgba(51, 51, 51, 1);
      line-height: 25px;
      text-align: center;
      line-height: 120px;
    }

    .bind-close {
      width: 44px;
      height: 44px;
      display: block;
      position: absolute;
      right: 30px;
      top: 30px;
      z-index: 100;
    }

    .mobile {
      margin: 0 50px;
      border-bottom: 2px solid rgba(217, 217, 217, 1);

      img {
        width: 34px;
        height: 44px;
        display: inline-block;
        vertical-align: middle;
        margin-right: 20px;
      }

      input {
        width: 400px;
        line-height: 100px;
        height: 100px;
        display: inline-block;
        vertical-align: middle;
      }
    }

    .code {
      position: relative;
      margin: 0 50px;

      img {
        width: 34px;
        height: 44px;
        display: inline-block;
        vertical-align: middle;
        margin-right: 20px;
      }

      input {
        width: 200px;
        line-height: 100px;
        height: 100px;
        display: inline-block;
        vertical-align: middle;
      }

      .code-button {
        position: absolute;
        right: 0px;
        top: 50%;
        transform: translate(0, -50%);
        width: 200px;
        height: 68px;
        line-height: 68px;
        background: rgba(255, 255, 255, 1);
        border: 2px solid rgba(43, 180, 233, 1);
        border-radius: 34px;
        text-align: center;
        font-size: 26px;
        font-weight: 500;
        color: rgba(43, 180, 233, 1);
      }

      .active {
        width: 200px;
        line-height: 68px;
        background: rgba(246, 246, 246, 1);
        border-radius: 34px;
        font-size: 24px;
        font-weight: 500;
        color: rgba(204, 204, 204, 1);
        border: 2px solid rgba(246, 246, 246, 1);
      }
    }

    .button {
      width: 500px;
      height: 80px;
      line-height: 80px;
      background: rgba(43, 180, 233, 1);
      border-radius: 40px;
      font-size: 30px;
      font-weight: 500;
      color: rgba(255, 255, 255, 1);
      margin-top: 60px;
    }
  }

  .examination {
    width: 100%;
    height: 140px;
  }

  .table {
    width: 690px;
    padding-bottom: 40px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 4px 10px 0px rgba(218, 218, 218, 0.6);
    border-radius: 8px;

    .table-header {
      font-size: 30px;
      font-weight: bold;
      color: rgba(34, 34, 34, 1);
      border-bottom: 2px solid #f6f6f6;
      height: 80px;
      line-height: 80px;
      padding-left: 20px;
      margin-bottom: 20px;

      &::before {
        content: "|";
        width: 6px;
        height: 32px;
        display: inline-block;
        color: #d3a358;
        margin-right: 10px;
      }
    }

    .name,
    .mobile,
    .code {
      margin: 40px auto 0;
      width: 624px;
      height: 80px;
      background: rgba(255, 255, 255, 1);
      border: 2px solid rgba(234, 234, 234, 1);
      border-radius: 6px;
      position: relative;

      span {
        position: absolute;
        right: 20px;
        top: 50%;
        transform: translate(0, -50%);
        z-index: 100;
        font-size: 28px;
        font-weight: 500;
        color: #d3a358;
        line-height: 80px;
        padding: 0 30px;
      }

      input {
        height: 80px;
        line-height: 80px;
        padding-left: 30px;
        width: 400px;
      }
    }

    .button {
      width: 624px;
      height: 80px;
      line-height: 80px;
      border-radius: 40px;
      text-align: center;
      font-size: 28px;
      margin: 0 auto;
      margin-top: 40px;
      background: #d3a358;
      color: #ffffff;
    }

    .isDisabled {
      color: #999999;
      background: rgba(234, 234, 234, 1);
    }
  }
</style>
