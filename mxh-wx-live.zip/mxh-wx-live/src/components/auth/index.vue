<template>
  <section>
    <div class="login" v-if="isLogin">
      <div class="login-content">
        <img src="https://merrymall.oss-cn-shenzhen.aliyuncs.com/myh/logo.png" class="login-logo">
        <div class="login-title">您还未登录呦~ 请先登录吧！</div>
        <div class="login-des">登录可免费观看课程和各种提问服务呦~</div>
        <button class="login-button" open-type="getUserInfo" @getuserinfo="bindGetUserInfo" v-if="step == 1">
          授权登录
        </button>
        <button class="login-button cancel" @click="clickCancel">
          取消
        </button>
      </div>
    </div>
  </section>
</template>
<script>
  import {
    mapGetters,
    mapState
  } from 'vuex'

  export default {
    data() {
      return {
        step: 1,
        form: {
          "encryptedData": "string",
          "headImgurl": "string",
          "identityType": 2,
          "iv": "string",
          "mobile": "string",
          "nickName": "string",
          "openid": "string",
          "profile": "string"
        }
      }
    },
    onLoad() {
      this.getCode()
    },
    props: {
      type: ''
    },
    computed: {
      ...mapGetters(['isLogin']),
    },
    methods: {
      clickLogin() {
        this.isLogin = false
      },
      clickCancel() {
        this.$store.commit("setIsLogin", false);
      },
      /**
       * 获取用户code
       */
      getCode() {
        return new Promise(function(resolve, reject) {
          wx.login({
            success: function(res) {
              if (res.code) {
                console.log(res.code)
                resolve(res.code);
              } else {
                console.log('登录失败！' + res.errMsg)
              }
            }
          });
        });
      },
      async getOpenId() {
        let that = this
        let code = await this.getCode()
        return new Promise(function(resolve, reject) {
          let url = '/wechat/getOpenId/' + code
          that.$http.get(url).then((res) => {
            resolve(res.data);
          })
        });
      },
      /**
       * 绑定手机号
       */
      async getphonenumber(e) {
        if (e.mp.detail.errMsg == 'getPhoneNumber:ok') {
          let getOpenId = await this.getOpenId()
          let url = '/wechat/get/phone'
          let data = {
            iv: e.mp.detail.iv,
            encryptedData: e.mp.detail.encryptedData,
            sessionKey: getOpenId.session_key,
          }
          this.$http.post(url, data).then(res => {
            if (res.code == 0) {
              this.step = 2
            }
          })
        } else {
          this.$store.commit('showToast', {
            title: '获取手机号失败'
          })
        }
      },
      async bindGetUserInfo(e) {
        if (e.target.errMsg != 'getUserInfo:ok') {
          return false
        }
        let openData = await this.getOpenId()
        this.form.openid = openData
        this.form.headImgurl = e.target.userInfo.avatarUrl
        this.form.nickName = e.target.userInfo.nickName
        this.form.encryptedData = e.target.encryptedData
        this.form.iv = e.target.iv
        let url = '/user/weChatRegister'
        let data = {
          identityType: 2,
          openid: this.form.openid,
          headImgurl: this.form.headImgurl,
          nickName: this.form.nickName,
          // iv: this.form.iv,
          // encryptedData:this.form.encryptedData
        }
        this.$http.post(url, data).then((res) => {
          if (res.code == 2008) {
            this.login()
          } else {
            wx.setStorageSync('token', res.data.token)
            wx.setStorageSync('mxhUserInfo', res.data.mxhUserInfo)
            this.$store.commit("setIsLogin", false);
            this.$store.commit("loginCallback", this.type);
          }
        })
      },

      login() {
        let url = '/user/weChatLogin'
        let data = {
          identityType: 0,
          openid: this.form.openid,
          headImgurl: this.form.headImgurl,
          nickName: this.form.nickName,
        }
        this.$http.post(url, data).then((res) => {
          if (res.code == 0) {
            wx.setStorageSync('token', res.data.token)
            wx.setStorageSync('mxhUserInfo', res.data.mxhUserInfo)
            this.$store.commit("setIsLogin", false);
            this.$store.commit("loginCallback", this.type);
          }
        })
      }
    }
  }
</script>
<style lang='less' scoped>
  .login {
    position: fixed;
    z-index: 100;
    left: 0;
    top: 0;
    width: 100vh;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);

    .login-content {
      position: fixed;
      z-index: 10;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 610px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      text-align: center;

      .login-logo {
        width: 168px;
        height: 168px;
        margin-bottom: 50px;
        margin-top: -64px;
        border-radius: 50%;
      }

      .login-title {
        font-size: 32px;
        font-weight: 500;
        color: rgba(34, 34, 34, 1);
        line-height: 36px;
        margin-bottom: 30px;
      }

      .login-des {
        font-size: 24px;
        font-weight: 500;
        color: rgba(153, 153, 153, 1);
        line-height: 36px;
        margin-bottom: 50px;
      }

      .login-button {
        width: 530px;
        line-height: 80px;
        background: #d3a358;
        border-radius: 40px;
        font-size: 32px;
        font-weight: 500;
        color: rgba(255, 255, 255, 1);
        display: block;
        margin: 0 auto;
        margin-bottom: 30px;
      }

      .cancel {
        background: #eaeaea;
      }

      .cancel:after {
        border: none;
      }

      .login-close {
        width: 30px;
        height: 30px;
        display: block;
        margin: 0 auto;
        margin-bottom: 30px;
      }
    }
  }
</style>
