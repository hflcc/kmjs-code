<template>
<uni-shadow-root class="iview-avideo-swiper-component-share-panel-index"><view class="panel">
  <button class="forward-btn" plain="true" @click.stop.prevent="onForwardTap">
    <image class="forward-btn-img" src="../../image/forward.png"></image>
  </button>
</view></uni-shadow-root>
</template>

<script>

global['__wxVueOptions'] = {components:{}}

global['__wxRoute'] = 'iview/avideo-swiper/component/share-panel/index'
Component({
	properties: {
		video: {
			type: Object,
			value: null
		}
	},

	data: {
		videoData: {}
	},

	observers: {
		video(video) {
			if (typeof video === 'object') {
				this.setData({
					videoData: video
				});
			}
		}
	},
	methods: {
		onForwardTap() {
			this.triggerEvent('forward', { video: this.data.videoData }, { bubbles: true, composed: true });
		}
	}
});
export default global['__wxComponents']['iview/avideo-swiper/component/share-panel/index']
</script>
<style platform="mp-weixin">
.panel {
	width: 100%;
	height: 100%;
	position: relative;
	left: 0;
	top: 0;
}

.title {
	display: block;
	color: red;
	width: 250px;
	height: 30px;
	position: absolute;
	left: 16px;
	top: 58px;
}

.panel .forward-btn {
	position: absolute;
	bottom: 110px;
	bottom: calc(env(safe-area-inset-bottom, 0px) + 110px);
	right: 12rpx;
	border: 0;
	margin: 0;
	padding: 0;
	width: auto;
}

.forward-btn-img {
	display: block;
	width: 68rpx;
	height: 68rpx;
}
</style>