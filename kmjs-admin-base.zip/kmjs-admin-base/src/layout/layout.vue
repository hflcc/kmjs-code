<template>
  <router-view v-slot="{ Component }">
    <keep-alive :include="keepAlive">
      <component :is="Component"></component>
    </keep-alive>
  </router-view>
</template>
<script lang="ts">
  import { defineComponent, onActivated, onMounted, computed } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'layoutView',
    setup() {
      const store = useStore();
      const keepAlive = computed(() => store.getters['menu/keepAlive']);
      onMounted(() => {
        console.log('layout mounted');
      });
      onActivated(() => {
        console.log('layout activated');
      });
      return {
        keepAlive
      };
    }
  });
</script>
