<template>
  <div class="login page center_box">
    <div class="box_main">
      <el-form label-position="right" ref="form" :model="loginForm" :rules="loginRules">
        <el-form-item label="账户" prop="account" label-width="80px">
          <el-input placeholder="请输入账号" v-model="loginForm.account"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password" label-width="80px">
          <el-input placeholder="请输入密码" v-model="loginForm.password" show-password></el-input>
        </el-form-item>
        <el-form-item>
          <el-button style="width: 100%" type="primary" block @click="login">登陆</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, reactive, ref } from 'vue';
  import { validAccount, validPassword } from '@/utils/valid';
  import { useStore } from 'vuex';
  import { useRouter } from 'vue-router';
  import { ElForm } from 'element-plus';

  export default defineComponent({
    name: 'login',
    setup() {
      const router = useRouter();
      const store = useStore();
      // form 实例
      const form = ref<InstanceType<typeof ElForm>>();
      // 登录表单
      const loginForm = reactive({
        account: 'ces',
        password: 'ceshi'
      });

      // 登录方法
      function login() {
        form.value?.validate().then((result: boolean) => {
          if (result) {
            // console.log('调用登录');
            store
              .dispatch('user/login', {
                username: loginForm.account,
                pwd: loginForm.password
              })
              .then((res) => {
                if (res) {
                  router.push({ path: '/' });
                }
              });
          }
        });
      }

      // 验证账号
      const validateAccount = (rule: unknown, value: string, callback: (value?: Error) => void) => {
        const result = validAccount(value);
        if (result === true) {
          callback();
        } else {
          callback(new Error(result));
        }
      };
      // 验证密码
      const validatePassword = (
        rule: unknown,
        value: string,
        callback: (value?: Error) => void
      ) => {
        const result = validPassword(value);
        if (result === true) {
          callback();
        } else {
          callback(new Error(result));
        }
      };
      // 表单验证规则
      const loginRules = {
        account: [{ required: true, trigger: 'blur', validator: validateAccount }],
        password: [{ required: true, trigger: 'blur', validator: validatePassword }]
      };
      return {
        // form 实例
        form,
        // 登录表单
        loginForm,
        // 登录方法
        login,
        // 表单验证规则
        loginRules
      };
    }
  });
</script>

<style lang="less">
  .login {
    .box_main {
      width: 500px;
    }
  }
</style>
