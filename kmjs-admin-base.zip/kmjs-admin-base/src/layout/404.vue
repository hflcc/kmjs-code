<template>
  <div class="page404">page404</div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
    name: 'page404',
    components: {},
    setup() {
      return {};
    }
  });
</script>

<style lang="less" scoped>
  .page404 {
  }
</style>
