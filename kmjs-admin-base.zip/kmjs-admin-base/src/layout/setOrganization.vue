<template>
  <div class="set_organization">set_organization</div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
    name: 'set_organization',
    components: {},
    setup() {
      return {};
    }
  });
</script>

<style lang="less" scoped>
  .set_organization {
  }
</style>
