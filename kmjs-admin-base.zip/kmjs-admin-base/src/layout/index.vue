<template>
  <div class="page index">
    <div class="sidebar">
      <kmjs-sidebar />
    </div>
    <div class="container">
      <div class="header">
        <kmjs-header />
      </div>
      <kmjsTabMenu />
      <div class="main">
        <router-view v-slot="{ Component }">
          <keep-alive :include="keepAlive">
            <component :is="Component" />
          </keep-alive>
        </router-view>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import kmjsHeader from '@/components/header/index.vue';
  import kmjsSidebar from '@/components/sidebar/index.vue';
  import kmjsTabMenu from '@/components/tabsMenu/index.tsx';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'index',
    components: {
      kmjsHeader,
      kmjsSidebar,
      kmjsTabMenu
    },
    setup() {
      const store = useStore();
      const keepAlive = computed(() => {
        return store.getters['menu/keepAlive'];
      });
      return {
        keepAlive
      };
    }
  });
</script>

<style lang="less" scoped>
  .index {
    display: flex;

    .sidebar {
      //width: 256px;
      height: 100%;
      overflow: hidden;
    }

    .container {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;

      .header {
        overflow: hidden;
      }

      .main {
        flex: 1;
        overflow: hidden;
      }
    }
  }
</style>
