import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';
import test from './modules/test';

// 全屏页面的路由
const commonRouter: RouteRecordRaw[] = [
  {
    path: '/',
    component: () => import(/* webpackChunkName: "index" */ '@/layout/index.vue'),
    redirect: '/home',
    name: 'rootRoute',
    children: [
      {
        path: 'home',
        meta: {
          title: '首页'
        },
        name: 'home',
        component: () => import(/* webpackChunkName: "home" */ '@/pages/home.vue')
      },
      ...test
    ]
  },
  {
    path: '/:catchAll(.*)',
    name: '404',
    component: () => import(/* webpackChunkName: "404" */ '@/layout/404.vue')
  },
  {
    path: '/login',
    name: 'login',
    meta: {
      title: '登陆'
    },
    component: () => import(/* webpackChunkName: "login" */ '@/layout/login.vue')
  },
  {
    path: '/setOrganization',
    name: 'setOrganization',
    component: () =>
      import(/* webpackChunkName: "setOrganization" */ '@/layout/setOrganization.vue')
  }
];
const router = createRouter({
  history: createWebHashHistory(),
  routes: [...commonRouter]
});

export default router;
