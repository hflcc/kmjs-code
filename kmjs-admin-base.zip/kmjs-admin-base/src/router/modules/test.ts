import { RouteRecordRaw } from 'vue-router';

const commonRouter: RouteRecordRaw[] = [
  {
    path: '/menu01',
    meta: {
      title: 'menu01',
      icon: 'office-building',
      breadcrumb: true
    },
    name: 'menu01',
    component: () => import(/* webpackChunkName: "menu01" */ '@/layout/layout.vue'),
    children: [
      {
        path: 'menu0101',
        name: 'menu0101',
        meta: {
          // 组件的名称，方便后续的keep-alive
          keepName: 'menu01-01',
          title: 'menu0101',
          icon: 'office-building',
          breadcrumb: true
        },
        component: () =>
          import(/* webpackChunkName: "menu01-01" */ '@/pages/menu01/01/menu01-01.vue')
      },
      {
        path: 'menu0102',
        name: 'menu0102',
        meta: {
          keepName: 'menu01-02',
          title: 'menu0102',
          icon: 'phone',
          breadcrumb: true
        },
        component: () =>
          import(/* webpackChunkName: "menu01-02" */ '@/pages/menu01/02/menu01-02.vue')
      },
      {
        path: 'menu0103',
        name: 'menu0103',
        meta: {
          title: 'menu0103',
          icon: 'goods',
          breadcrumb: false
        },
        component: () => import(/* webpackChunkName: "menu01" */ '@/layout/layout.vue'),
        children: [
          {
            path: 'menu010301',
            name: 'menu010301',
            meta: {
              keepName: 'menu01-03-01',
              title: 'menu010301',
              icon: 's-release',
              breadcrumb: true
            },
            component: () =>
              import(/* webpackChunkName: "menu01-03-01" */ '@/pages/menu01/03/01/menu01-03-01.vue')
          },
          {
            path: 'menu010302',
            name: 'menu010302',
            meta: {
              keepName: 'menu01-03-02',
              title: 'menu010302',
              icon: 'printer',
              breadcrumb: true
            },
            component: () =>
              import(/* webpackChunkName: "menu01-03-02" */ '@/pages/menu01/03/02/menu01-03-02.vue')
          },
          {
            path: 'menu010303',
            name: 'menu010303',
            meta: {
              keepName: 'menu01-03-03',
              title: 'menu010303',
              icon: 'office-building',
              breadcrumb: true
            },
            component: () => import(/* webpackChunkName: "menu01" */ '@/layout/layout.vue'),
            children: [
              {
                path: 'menu01030301',
                name: 'menu01030301',
                meta: {
                  keepName: 'menu01-03-03-01',
                  title: 'menu01030301',
                  icon: 'box',
                  breadcrumb: true
                },
                component: () =>
                  import(
                    /* webpackChunkName: "menu01-03-03-01" */ '@/pages/menu01/03/03/menu01-03-03-01.vue'
                  )
              },
              {
                path: 'menu01030302',
                name: 'menu01030302',
                meta: {
                  keepName: 'menu01-03-03-02',
                  title: 'menu01030302',
                  icon: 'time',
                  breadcrumb: true
                },
                component: () =>
                  import(
                    /* webpackChunkName: "menu01-03-03-02" */ '@/pages/menu01/03/03/menu01-03-03-02.vue'
                  )
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/menu02',
    meta: {
      title: 'menu02',
      icon: 'office-building',
      breadcrumb: true,
      keepName: 'menu02'
    },
    name: 'menu02',
    component: () => import('@/pages/menu02.vue')
  }
];

export default commonRouter;
