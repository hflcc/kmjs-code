import router from '@/router/index';
import store from '@/store';
import type { RouteRecordRaw } from 'vue-router';
// import store from '@/store';
// // 登录白名单
const loginWhiteList = ['/login'];
// // 机构白名单
const organizationWhiteList = ['/login', '/setOrganization'];

router.beforeEach(async (to, form, next) => {
  // // 登录信息
  const token = store.getters['user/token'];
  // // 机构信息
  const organization = store.getters['user/organization'];
  const { path } = to;
  // 没登录,不在白名单;
  if (!token && !loginWhiteList.includes(path)) {
    return next({
      name: 'login'
    });
    // 没机构,不在白名单;
  }
  // else if (!organization && !organizationWhiteList.includes(path)) {
  //   return next({
  //     name: 'setOrganization'
  //   });
  // }
  next();
});
/**
 * ======================== 动态计算路由 =======================
 * 先获取routet/modules下的所有文件
 * 进行比对后，route.addRoute 加入已实例后的全局路由中
 */
const localRoute: RouteRecordRaw[] = [];
const req = require.context('@/router/modules', false, /\.ts$/);
req.keys().forEach((item) => {
  return localRoute.push(...req(item).default);
});

/**
 * 根据路由name对总体的路由进行合并比较
 * @param serverRouterData 服务器的路由数据
 * @param localRoute 当前本地已经配置好的路由
 * @return 本层次对比后的结果
 * */
const marge = (
  serverRouterData: ServerRouterData[],
  localRoute: RouteRecordRaw[]
): RouteRecordRaw[] => {
  const data: RouteRecordRaw[] = [];
  const Slength = serverRouterData.length;
  for (let i = 0; i < Slength; i++) {
    const item = serverRouterData[i];
    const localData = localRoute.find((s) => s.name === item.name) || undefined;
    if (localData) {
      let margeChild: RouteRecordRaw[] = [];
      // 先排除children，如果有必要对比children在对比加入
      const children = localData.children;
      delete localData.children;
      if (children?.length && item.children?.length) {
        margeChild = marge(item.children, children);
      }
      if (margeChild.length) {
        localData.children = margeChild;
      }
      data.push(localData);
    }
  }
  return data;
};
/**
 * 根据后台返回的路由name对总体的路由进行合并比较
 * @param serverRouterData 当前路由名称的name
 * @return 对比后的所有结果
 * */
export const computed = (serverRouterData: ServerRouterData[]): RouteRecordRaw[] => {
  const data = marge(serverRouterData, localRoute);
  data.forEach((v) => router.addRoute('rootRoute', v));
  return data;
};
