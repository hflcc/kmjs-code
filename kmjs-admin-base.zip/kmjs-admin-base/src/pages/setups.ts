import { ref } from 'vue';

export default () => {
  const num = ref(0);
  const updateNum = () => {
    num.value += 2;
  };
  return {
    num,
    updateNum
  };
};
