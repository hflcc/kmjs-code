<template>
  <div class="menu01-02">
    menu0222
    <p>{{ num }}</p>
    <button @click="updateNum">change</button>
  </div>
</template>

<script lang="tsx">
  import { defineComponent, onMounted, onActivated } from 'vue';
  import setups from '@/pages/setups';

  export default defineComponent({
    name: 'menu02',
    setup() {
      onMounted(() => {
        console.log('mounted menu02');
      });
      onActivated(() => {
        console.log('onActivated menu02');
      });
      return {
        ...setups()
      };
    }
  });
</script>

<style lang="less" scoped>
  .menu01-01 {
  }
</style>
