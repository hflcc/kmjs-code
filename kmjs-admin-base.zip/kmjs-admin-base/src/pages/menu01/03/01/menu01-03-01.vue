<template>
  <div class="menu01-03-01">
    menu01-03-01
    <p>{{ num }}</p>
    <button @click="updateNum">change</button>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onActivated, onMounted } from 'vue';
  import setups from '@/pages/setups';

  export default defineComponent({
    name: 'menu01-03-01',
    components: {},
    setup() {
      onMounted(() => {
        console.log('mounted menu01-03-01');
      });
      onActivated(() => {
        console.log('onActivated menu01-03-01');
      });
      return {
        ...setups()
      };
    }
  });
</script>

<style lang="less" scoped>
  .menu01-03-01 {
  }
</style>
