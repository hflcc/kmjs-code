import axios from '@/utils/axios';

export interface TestApiRequest {
  name: string;
  age: number;
}

export interface TestApiResponse {
  name: string;
  id: string;
  top: number;
}

export function testApi(data: TestApiRequest): Promise<TestApiResponse> {
  return axios.post<TestApiRequest, TestApiResponse>('/api/test', data);
}
