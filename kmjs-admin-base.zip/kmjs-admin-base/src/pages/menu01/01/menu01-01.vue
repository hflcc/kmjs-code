<template>
  <div class="page menu01-01">
    <kmjs-table :data="data" />
    <p>{{ num }}</p>
    <button @click="updateNum">change</button>
  </div>
</template>

<script lang="tsx">
  import { defineComponent, reactive, onMounted, onActivated } from 'vue';
  import kmjsTable from '@/components/table/index.vue';
  import { TestApiRequest, testApi, TestApiResponse } from '@/pages/menu01/api';
  import { TableComponent } from '@/components/table/table';
  import setups from '@/pages/setups';
  export default defineComponent({
    name: 'menu01-01',
    components: {
      kmjsTable
    },
    setup() {
      onMounted(() => {
        console.log('mounted menu01-01');
      });
      onActivated(() => {
        console.log('onActivated menu01-01');
      });
      const data = reactive<TableComponent<TestApiRequest, TestApiResponse>>({
        beforeRequest(data: TestApiRequest) {
          return new Promise<TestApiRequest>((resolve) => {
            resolve(data);
          });
        },
        url: testApi,
        search: {
          defaultSuggest: '默认联想',
          filters: [
            {
              label: '年月日选择器',
              key: 'key01',
              type: 'datePickerDate',
              defaultValue: ''
            },
            {
              label: '年月日选择器(带区间)',
              key: 'key02',
              type: 'datePickerDateRange',
              defaultValue: []
            },
            {
              label: '时分秒选择器',
              key: 'key03',
              type: 'datePickerTime',
              defaultValue: ''
            },
            {
              label: '时分秒选择器(带区间)',
              key: 'key04',
              type: 'datePickerTimeRange',
              defaultValue: []
            },
            {
              label: '数字输入框',
              key: 'key05',
              type: 'inputNumber',
              defaultValue: ''
            },
            {
              label: '文本输入款',
              key: 'key06',
              type: 'inputText',
              defaultValue: ''
            },
            {
              label: '自带数据选择器',
              key: 'key07',
              type: 'select',
              value: [
                { label: 'label1', value: '1' },
                { label: 'label2', value: '2' }
              ],
              defaultValue: ''
            },
            {
              label: '字典表选择器',
              key: 'key08',
              type: 'selectDict',
              value: 'dictKeyWord',
              defaultValue: ''
            },
            {
              label: '字典表选择器(多选)',
              key: 'key09',
              type: 'selectDictMultiple',
              value: 'dictKeyWordMultiple',
              defaultValue: []
            },
            {
              label: '自带数据选择器(多选)',
              key: 'key10',
              type: 'selectMultiple',
              value: [
                { label: 'label1', value: '1' },
                { label: 'label2', value: '2' }
              ],
              defaultValue: []
            },
            {
              label: '建议项',
              key: 'key11',
              type: 'suggest',
              value: 'suggestKey',
              defaultValue: ''
            }
          ]
        },
        handleButton: [
          {
            label: '新增',
            key: 'add',
            cb: () => {
              console.log('点击新增');
            }
          },
          {
            label: '编辑',
            key: 'edit',
            cb: () => {
              console.log('点击编辑');
            }
          }
        ],
        table: {
          columns: [
            {
              prop: 'key01',
              label: '表头01'
            },
            {
              prop: 'key02',
              label: '表头02'
            },
            {
              prop: 'key03',
              label: '表头03'
            },
            {
              prop: 'key04',
              label: '表头04',
              sort: true,
              width: 300,
              // 加过滤;可变列宽;checkbox;
              // formatter(row) {
              //   return "我是格式化后的数据";
              // },
              render: () => {
                return <el-button>1</el-button>;
              }
            },
            {
              prop: 'key05',
              label: '表头05'
            },
            {
              prop: 'key06',
              label: '表头06'
            },
            {
              prop: 'key07',
              label: '表头07'
            },
            {
              prop: 'key08',
              label: '表头08'
            },
            {
              prop: 'key09',
              label: '表头09'
            },
            {
              prop: 'key10',
              label: '表头10'
            },
            {
              prop: 'key11',
              label: '表头11'
            }
          ],
          buttons: [
            {
              label: () => '删除',
              attributes() {
                return {
                  disabled: false
                };
              },
              key: 'handle',
              cb: () => {
                console.log('点击删除');
              }
            }
          ]
        }
      });
      return {
        data,
        ...setups()
      };
    }
  });
</script>

<style lang="less" scoped>
  .menu01-01 {
  }
</style>
