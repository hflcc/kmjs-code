import { ActionContext, Module } from 'vuex';
import { computed } from '@/router/permission';
import testRouter from '@/router/modules/test';
import { RouteRecordRaw } from 'vue-router';
import { login, logout } from '@/utils/commApi';

const user: Module<UserInfo, RootState> = {
  namespaced: true,
  state: {
    // 用户菜单权限
    menus: testRouter,
    // 登录态
    token: '',
    // 用户机构信息
    organization: '',
    // 用户名
    userName: '',
    // 权限
    permissions: ['aaaaaaaas', 'ssss', 'dddd']
  },
  mutations: {
    UPDATE_MENU(state: UserInfo, data: RouteRecordRaw[]) {
      state.menus = [...data];
    },
    LOGIN(state: UserInfo, options: { username: string; token: string }) {
      state.userName = options.username;
      state.token = options.token;
    },
    LOGOUT(state: UserInfo) {
      state.userName = '';
      state.token = '';
    }
  },
  getters: {
    // 获取全部菜单
    menus: (state: UserInfo) => {
      return state.menus;
    },
    // 获取 token
    token: (state: UserInfo) => {
      return state.token;
    },
    // 获取 organization
    organization: (state: UserInfo) => {
      return state.organization;
    },
    userMsg(state: UserInfo): { username: string } {
      return {
        username: state.userName
      };
    },
    permissions(state: UserInfo): string[] {
      return state.permissions;
    }
  },
  actions: {
    getUserMenu(
      { commit }: ActionContext<UserInfo, RootState>,
      serverRouterData: ServerRouterData[]
    ): void {
      const computedMenu = computed(serverRouterData);
      commit('UPDATE_MENU', computedMenu);
    },
    async login(
      { commit, dispatch }: ActionContext<UserInfo, RootState>,
      data: { username: string; pwd: string }
    ): Promise<boolean> {
      const res = await login(data.username, data.pwd);
      console.log(res);
      if (res && res.code === 0) {
        commit('LOGIN', { username: res.data.username, token: 'sss' });
        await dispatch('getUserMenu', res.data.menuList);
        return true;
      }
      return false;
    },
    async logOut({ commit }: ActionContext<UserInfo, RootState>) {
      const res = await logout();
      if (res && res.code === 0) {
        commit('LOGOUT');
        return true;
      }
      return false;
    }
  }
};
export default user;
