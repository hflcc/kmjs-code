import { Module } from 'vuex';

const menuModule: Module<MenuInfo, RootState> = {
  namespaced: true,
  state: {
    // 菜单是不是只显示为ICON
    iconMenu: false,
    // 需要被keep-alive缓存的页面组件
    keepAlive: ['home', 'layoutView'],
    // tabs菜单
    activeRoute: 'home',
    // 被加入tabs中的菜单项
    tabMenus: [
      {
        title: 'home',
        name: 'home',
        path: '/home',
        keepName: 'home'
      }
    ]
  },
  mutations: {
    UPDATE_ICON_MENU(state: MenuInfo, data: boolean) {
      state.iconMenu = data;
    },
    CHANGE_KEEP_ALIVE(state: MenuInfo, keepAlive: string[]) {
      state.keepAlive = [...keepAlive];
    },
    CHANGE_ACTIVE_MENU(state: MenuInfo, name: string) {
      state.activeRoute = name;
    },
    ADD_TAB_MENUS(state: MenuInfo, data: TabMenuItem) {
      state.tabMenus.push(data);
    },
    DEL_TAB_MENUS(state: MenuInfo, data: TabMenuItem) {
      const index = state.tabMenus.indexOf(data);
      if (index > -1) {
        state.tabMenus.splice(index, 1);
      }
    }
  },
  getters: {
    iconMenu(state: MenuInfo): boolean {
      return state.iconMenu;
    },
    keepAlive(state: MenuInfo): string[] {
      return [...state.keepAlive];
    },
    tabMenus(state: MenuInfo): TabMenuItem[] {
      return [...state.tabMenus];
    },
    activeRoute(state: MenuInfo): string {
      return state.activeRoute;
    }
  }
};

export default menuModule;
