import { createStore } from 'vuex';
import createPersistedState from 'vuex-persistedstate';
import user from './modules/user';
import menu from './modules/menu';

const store = createStore<RootState>({
  modules: {
    user,
    menu
  },
  plugins: [
    createPersistedState({
      key: 'vuex',
      storage: window.localStorage,
      // 缓存哪些字段
      paths: ['user.token', 'user.userName', 'menu']
    })
  ]
});
export default store;
