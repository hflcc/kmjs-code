// 账号验证
export function validAccount(value: string): true | string {
  value = value.trim();
  if (value.length < 5) {
    return '账号长度需要大于五位';
  }
  return true;
}
// 密码验证
export function validPassword(value: string): true | string {
  value = value.trim();
  if (value.length < 5) {
    return '密码长度需要大于五位';
  }
  return true;
}
