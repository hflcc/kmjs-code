import store from '@/store';

/**
 * 校验当前用户的权限是否符合某个元素所需要的权限
 * @param permission 当前元素需要的权限
 * @return boolean 校验的结果，符合返回true 不符合返回false
 * */
export const checkPermission: (permission: string | string[]) => boolean = (permission) => {
  const permissions = store.getters['user/permissions'];
  if (Array.isArray(permission)) {
    return !!permission.find((s) => permissions.indexOf(s) > -1);
  } else {
    return permissions.indexOf(permission) === -1;
  }
};
