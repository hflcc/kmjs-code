import ajax from '@/utils/axios';
import { AxiosRequestConfig } from 'axios';

export interface Res<T> {
  code: number;
  msg: string;
  data: T;
}

interface LoginData {
  username: string;
  menuList: ServerRouterData[];
}

export const login = (username: string, pwd: string): Promise<Res<LoginData>> => {
  return ajax.post<
    {
      username: string;
      pwd: string;
    },
    Res<LoginData>
  >('/api/login', {
    username,
    pwd
  });
};
export const logout = (): Promise<Res<string>> => {
  return ajax.post<null, Res<string>>('/api/logout');
};
