import moment from 'moment';
export function formatterTimer(value: Date, formatType?: string): string {
  formatType = formatType || 'YYYY-MM-DD';
  return moment(value).format(formatType);
}
