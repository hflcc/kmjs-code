import { getCurrentInstance } from 'vue';
// tsx暴露实例方法, https://github.com/youzan/vant/blob/dev/src/composables/use-expose.ts#L5
export function useExpose(apis: Record<string, unknown>): void {
  const instance = getCurrentInstance();
  if (instance) {
    Object.assign(instance.proxy, apis);
  }
}
