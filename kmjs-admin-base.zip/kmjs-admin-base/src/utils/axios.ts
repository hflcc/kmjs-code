import axios from 'axios';
import store from '@/store';
import { ElNotification } from 'element-plus';
import { Res } from '@/utils/commApi';

const noTokenUrl: string[] = [];
// 创建axios实例
const serveice = axios.create({
  baseURL: process.env.VUE_APP_AXIOS_BASE_URL,
  timeout: 60 * 1000
});

// 请求拦截
serveice.interceptors.request.use(
  (config) => {
    if (noTokenUrl.indexOf(config.url as string) === -1) {
      config.headers['token'] = store.getters['user/token'];
    }
    return config;
  },
  (err) => {
    console.log(err);
  }
);

// 响应拦截
serveice.interceptors.response.use(
  (response) => {
    const data = response.data;
    if (data.code !== 0) {
      ElNotification({
        type: 'error',
        title: '请求错误 code: < ' + data.code + ' >',
        message: data.msg || '请求错误， 请稍后在试',
        duration: 4000
      });
      return Promise.resolve(false);
    }
    return data;
  },
  (error) => {
    console.log(error);
    return Promise.resolve(false);
  }
);

export default serveice;
