<template>
  <div class="breadcrumb-wrap">
    <div class="menu-icon-trigger" @click="triggerMenu">
      <i class="el-icon-s-fold"></i>
    </div>
    <el-breadcrumb>
      <transition-group name="breadcrumb">
        <!-- :to="{ path: item.path }" -->
        <el-breadcrumb-item v-for="item in breadcrumbData" :key="item.name"
          >{{ item.name }}
        </el-breadcrumb-item>
      </transition-group>
    </el-breadcrumb>
  </div>
</template>

<script lang="ts">
  import { useRoute } from 'vue-router';
  import { useStore } from 'vuex';
  import { defineComponent, computed } from 'vue';

  export default defineComponent({
    name: 'breadcrumb',
    setup() {
      const store = useStore();
      const route = useRoute();
      const breadcrumbData = computed(() => {
        let matched = route.matched.filter((item) => item.meta && item.meta.title);

        return matched.filter((item) => {
          if (item.name !== 'rootRoute')
            return item.meta && item.meta.title && item.meta.breadcrumb !== false;
        });
      });
      const triggerMenu = () => {
        store.commit('menu/UPDATE_ICON_MENU', !store.getters['menu/iconMenu']);
      };
      return {
        breadcrumbData,
        triggerMenu
      };
    }
  });
</script>

<style lang="less">
  /* breadcrumb transition */
  .breadcrumb-enter-active,
  .breadcrumb-leave-active {
    transition: all 0.5s;
  }

  .breadcrumb-enter,
  .breadcrumb-leave-active {
    opacity: 0;
    transform: translateX(20px);
  }

  .breadcrumb-move {
    transition: all 0.5s;
  }

  .breadcrumb-leave-active {
    position: absolute;
  }
</style>
