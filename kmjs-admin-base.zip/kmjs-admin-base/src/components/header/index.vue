<template>
  <header class="header-wrap">
    <Breadcrumb />
    <UserMessage />
  </header>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import Breadcrumb from '@/components/header/breadcrumb.vue';
  import UserMessage from '@/components/header/userMessage.vue';

  export default defineComponent({
    name: 'xHeader',
    components: {
      Breadcrumb,
      UserMessage
    },
    setup() {
      return {};
    }
  });
</script>

<style lang="less">
  @import './header.less';
</style>
