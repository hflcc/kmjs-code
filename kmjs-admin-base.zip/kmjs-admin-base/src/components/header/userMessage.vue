<template>
  <div class="user-wrap">
    <div class="name-area">
      欢迎您，
      <el-dropdown
        ><span class="user-name">{{ userMsg.username }}</span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item>黄金糕</el-dropdown-item>
            <el-dropdown-item>狮子头</el-dropdown-item>
            <el-dropdown-item @click="logout">登出</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script lang="ts">
  import { useStore } from 'vuex';
  import { useRouter } from 'vue-router';
  import { defineComponent, computed } from 'vue';

  export default defineComponent({
    name: 'userMsg',
    setup() {
      const store = useStore();
      const router = useRouter();
      const userMsg = computed(() => store.getters['user/userMsg']);
      const logout = () => {
        store.dispatch('user/logOut').then((res) => {
          if (res) {
            router.push({ path: '/login' });
          }
        });
      };
      return {
        userMsg,
        logout
      };
    }
  });
</script>
