import { defineComponent, watch, computed, nextTick } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useStore } from 'vuex';

import './style.less';

export default defineComponent({
  name: 'tabs-menu',
  setup() {
    const store = useStore();
    const route = useRoute();
    const router = useRouter();
    const routes = computed(() => store.getters['menu/tabMenus']);
    const activeRoute = computed(() => store.getters['menu/activeRoute']);

    const changeTab = (item: TabMenuItem) => {
      if (item.name === activeRoute.value) return;
      store.commit('menu/CHANGE_ACTIVE_MENU', item.name);
      router.push({ path: item.path });
    };

    const deleteTab = (item: TabMenuItem) => {
      const keepAlive: string[] = store.getters['menu/keepAlive'];
      const index = keepAlive.findIndex((v) => v === item.keepName);
      const routeIndex = routes.value.indexOf(item);
      if (routeIndex > -1) {
        if (activeRoute.value === item.name) {
          changeTab(routes.value[routeIndex - 1]);
          nextTick(() => {
            store.commit('menu/DEL_TAB_MENUS', item);
          });
        } else {
          store.commit('menu/DEL_TAB_MENUS', item);
        }
      }
      if (index > -1) {
        keepAlive.splice(index, 1);
        store.commit('menu/CHANGE_KEEP_ALIVE', keepAlive);
      }
    };

    watch(route, (to) => {
      const item = routes.value.find((v: TabMenuItem) => v.path === to.path) || null;
      const keepAlive: string[] = store.getters['menu/keepAlive'];
      if (!item) {
        store.commit('menu/ADD_TAB_MENUS', {
          title: to.meta.title as string,
          name: to.name as string,
          path: to.path,
          keepName: to.meta.keepName as string
        });
        if (to.meta.keepName) {
          keepAlive.push(to.meta.keepName as string);
          store.commit('menu/CHANGE_KEEP_ALIVE', keepAlive);
        }
      }
      store.commit('menu/CHANGE_ACTIVE_MENU', to.name as string);
    });
    return {
      activeRoute,
      routes,
      changeTab,
      deleteTab
    };
  },
  render() {
    const { activeRoute, routes, changeTab, deleteTab } = this;
    const items = routes.map((v: TabMenuItem) => {
      return (
        <div
          onClick={() => changeTab(v)}
          class={['tab-item', v.name === activeRoute ? 'active' : ''].join(' ')}
        >
          {v.title}
          {v.name === 'home' ? null : (
            <i
              class="close-icon el-icon-close"
              onClick={(e) => {
                e.stopPropagation();
                deleteTab(v);
              }}
            />
          )}
        </div>
      );
    });
    return (
      <div class="tab-menu-wrap">
        <div class="scroll-bar">{items}</div>
      </div>
    );
  }
});
