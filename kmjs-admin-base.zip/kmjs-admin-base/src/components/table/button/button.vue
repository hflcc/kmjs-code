<template>
  <div class="kmjs_table_button">kmjs_table_button</div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
    name: 'kmjs_table_button',
    components: {},
    setup() {
      return {};
    }
  });
</script>

<style lang="less">
  .kmjs_table_button {
  }
</style>
