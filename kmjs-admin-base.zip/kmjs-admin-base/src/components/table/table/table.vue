<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableTable } from '../table';
  export default defineComponent({
    name: 'kmjs_table_table',
    props: {
      tableData: {
        type: Array,
        required: true
      },
      data: {
        type: Object as PropType<TableTable>,
        required: true
      }
    },
    setup(props) {
      return () => {
        return (
          <div class="kmjs_table_table">
            <el-table data={props.tableData} border style="width: 100%" height="100%">
              {props.data.columns.map((item) => {
                return (
                  <el-table-column
                    width="300"
                    prop={item.prop}
                    label={item.label}
                  ></el-table-column>
                );
              })}
            </el-table>
          </div>
        );
      };
    }
  });
</script>

<style lang="less">
  .kmjs_table_table {
    flex: 1;
  }
</style>
