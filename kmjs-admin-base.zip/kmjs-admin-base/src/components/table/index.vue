<template>
  <div class="kmjs_table">
    <kmjs-search :data="data.search" @search="searchAndFormatter" />
    <kmjs-button />
    <kmjs-table :tableData="tableData" :data="data.table" />
    <kmjs-paging />
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, PropType, reactive } from 'vue';
  import kmjsSearch from './search/search.vue';
  import kmjsButton from './button/button.vue';
  import kmjsTable from './table/table.vue';
  import kmjsPaging from './paging/paging.vue';
  import { SearchDataType, TableComponent } from '@/components/table/table';
  import { Res } from '@/utils/commApi';
  export default defineComponent({
    name: 'kmjs_table',
    props: {
      data: {
        type: Object as PropType<TableComponent<SearchDataType, Res<any>>>,
        required: true
      }
    },
    components: {
      kmjsSearch,
      kmjsButton,
      kmjsTable,
      kmjsPaging
    },
    setup(props) {
      // 获取数据
      function getData(data: SearchDataType) {
        props.data.url(data).then((res) => {
          tableData.push(...res.data);
        });
      }
      // 列表数据
      const tableData = reactive<SearchDataType[]>([]);
      // 触发搜索以及格式化数据
      async function searchAndFormatter(data: SearchDataType) {
        if (props.data.beforeRequest) {
          data = await props.data.beforeRequest(data);
        }
        getData(data);
      }
      // 初始化拉去数据
      onMounted(() => {
        getData({});
      });
      return {
        // 获取数据
        getData,
        // 格式化 -> 搜索
        searchAndFormatter,
        // 列表数据
        tableData
      };
    }
  });
</script>

<style lang="less">
  .kmjs_table {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    padding: 20px;
    box-sizing: border-box;
  }
</style>
