<script lang="tsx">
  import {
    SearchDataType,
    SelectType,
    TableSearch,
    TableSearchComponent,
    TableSearchComponentRange,
    TableSearchComponentSelect,
    TableSearchComponentSelectDict,
    TableSearchComponentSelectDictMultiple,
    TableSearchComponentSelectMultiple,
    TableSearchComponentSuggest
  } from '@/components/table/table';
  import { defineComponent, PropType, reactive, ref } from 'vue';
  import { mixins, renderComponent } from './components/renderHelper';
  import { useExpose } from '@/utils/setup';
  export default defineComponent({
    name: 'kmjs_table_search_single',
    mixins: [mixins],
    props: {
      data: {
        type: Object as PropType<TableSearch>,
        required: true
      }
    },
    setup(props) {
      // 选择器选项
      const options: Array<SelectType> = props.data.filters.map((item) => {
        return {
          label: item.label,
          value: item.key
        };
      });
      // 联想的搜索字段
      const searchValue = ref('');
      // 表单数据
      const formData = reactive<SearchDataType>({});
      // form类型数据
      let formType = reactive<
        | TableSearchComponent
        | TableSearchComponentRange
        | TableSearchComponentSelect
        | TableSearchComponentSelectDict
        | TableSearchComponentSelectMultiple
        | TableSearchComponentSelectDictMultiple
        | TableSearchComponentSuggest
      >({
        label: '',
        key: '',
        type: 'suggest',
        value: props.data.defaultSuggest
      });
      // 获取搜索数据
      function getFormData() {
        return formData;
      }
      // 暴露出实例方法
      useExpose({
        getFormData
      });
      return () => {
        return (
          <div class="kmjs_table_search_single">
            <el-form model={formData} size="mini" label-width="auto">
              <el-form-item
                v-slots={{
                  label: () => {
                    return (
                      <el-select
                        modelValue={searchValue.value}
                        {...{
                          'onUpdate:modelValue': (value: string) => {
                            searchValue.value = value;
                          },
                          onChange: (value: string) => {
                            // 清空历史数据
                            if (formType.key) {
                              formData[formType.key] = '';
                            }
                            props.data.filters.forEach((item) => {
                              if (item.key === value) {
                                Object.assign(formType, item);
                              }
                            });
                          }
                        }}
                      >
                        {options.map((item) => {
                          return (
                            <el-option
                              key={item.value}
                              label={item.label}
                              value={item.value}
                            ></el-option>
                          );
                        })}
                      </el-select>
                    );
                  }
                }}
              >
                {renderComponent(formData, formType)}
              </el-form-item>
            </el-form>
          </div>
        );
      };
    }
  });
</script>
