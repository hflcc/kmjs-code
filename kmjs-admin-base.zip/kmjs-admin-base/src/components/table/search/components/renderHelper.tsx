import {
  TableSearchComponent,
  TableSearchComponentRange,
  TableSearchComponentSelect,
  TableSearchComponentSelectDict,
  TableSearchComponentSelectDictMultiple,
  TableSearchComponentSelectMultiple,
  TableSearchComponentSuggest
} from '../../table';
import inputText from '@/components/table/search/components/inputText.vue';
import inputNumber from '@/components/table/search/components/inputNumber.vue';
import datePickerDate from '@/components/table/search/components/datePickerDate.vue';
import datePickerDateRange from '@/components/table/search/components/datePickerDateRange.vue';
import datePickerTime from '@/components/table/search/components/datePickerTime.vue';
import datePickerTimeRange from '@/components/table/search/components/datePickerTimeRange.vue';
import kmjsSelect from '@/components/table/search/components/select.vue';
import selectDict from '@/components/table/search/components/selectDict.vue';
import selectMultiple from '@/components/table/search/components/selectMultiple.vue';
import selectDictMultiple from '@/components/table/search/components/selectDictMultiple.vue';
import suggest from '@/components/table/search/components/suggest.vue';

export function renderComponent(
  formData: { [key: string]: string | number | Array<string | number> },
  item:
    | TableSearchComponent
    | TableSearchComponentRange
    | TableSearchComponentSelect
    | TableSearchComponentSelectDict
    | TableSearchComponentSelectMultiple
    | TableSearchComponentSelectDictMultiple
    | TableSearchComponentSuggest
): JSX.Element {
  if (item.type === 'inputNumber') {
    return <inputNumber v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'datePickerDate') {
    return <datePickerDate v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'datePickerDateRange') {
    return <datePickerDateRange v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'datePickerTime') {
    return <datePickerTime v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'datePickerTimeRange') {
    return <datePickerTimeRange v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'select') {
    return <kmjs-select v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'selectDict') {
    return <selectDict v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'selectMultiple') {
    return <selectMultiple v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'selectDictMultiple') {
    return <selectDictMultiple v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'suggest') {
    return <suggest v-model={formData[item.key]} data={item} />;
  } else if (item.type === 'inputText') {
    return <inputText v-model={formData[item.key]} data={item} />;
  }
  return <div></div>;
}

export const mixins = {
  components: {
    inputText,
    inputNumber,
    datePickerDate,
    datePickerDateRange,
    datePickerTime,
    datePickerTimeRange,
    kmjsSelect,
    selectDict,
    selectMultiple,
    selectDictMultiple,
    suggest
  }
};
