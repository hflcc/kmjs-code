<script lang="tsx">
  import { defineComponent, PropType, reactive } from 'vue';
  import { TableSearchComponentSelectDictMultiple, SelectType } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: Array,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponentSelectDictMultiple>,
        required: true
      }
    },
    setup(props, { emit }) {
      const options = reactive<Array<SelectType>>([]);
      function sleep() {
        return new Promise<string>((resolve) => {
          setTimeout(() => {
            resolve('1');
          }, 1000);
        });
      }
      sleep().then(() => {
        options.push({
          label: props.data.value,
          value: props.data.value
        });
      });
      return () => {
        return (
          <el-select
            class="full_label"
            multiple
            modelValue={props.modelValue}
            placeholder={'请选择' + props.data.label}
            {...{
              'onUpdate:modelValue': (value: Array<string | number>) => {
                emit('update:modelValue', value);
              }
            }}
          >
            {options.map((item) => {
              return <el-option key={item.value} label={item.label} value={item.value}></el-option>;
            })}
          </el-select>
        );
      };
    }
  });
</script>
