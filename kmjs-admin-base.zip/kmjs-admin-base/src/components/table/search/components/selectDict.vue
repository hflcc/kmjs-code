<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponentSelectDict } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: String,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponentSelectDict>,
        required: true
      }
    },
    setup(props, { emit }) {
      console.log(props.data.value);
      return () => {
        return (
          <el-select
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请选择' + props.data.label}
            {...{
              'onUpdate:modelValue': (value: string) => {
                emit('update:modelValue', value);
              }
            }}
          ></el-select>
        );
      };
    }
  });
</script>
