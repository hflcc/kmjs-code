<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponentSelect } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: String,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponentSelect>,
        required: true
      }
    },
    setup(props, { emit }) {
      return () => {
        return (
          <el-select
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请选择' + props.data.label}
            {...{
              'onUpdate:modelValue': (value: string) => {
                emit('update:modelValue', value);
              }
            }}
          >
            {props.data.value.map((item) => {
              return <el-option key={item.value} label={item.label} value={item.value}></el-option>;
            })}
          </el-select>
        );
      };
    }
  });
</script>
