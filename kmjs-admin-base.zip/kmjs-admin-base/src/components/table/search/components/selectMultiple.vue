<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponentSelectMultiple } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: Array,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponentSelectMultiple>,
        required: true
      }
    },
    setup(props, { emit }) {
      return () => {
        return (
          <el-select
            multiple
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请选择' + props.data.label}
            {...{
              'onUpdate:modelValue': (value: Array<string | number>) => {
                emit('update:modelValue', value);
              }
            }}
          >
            {props.data.value.map((item) => {
              return <el-option key={item.value} label={item.label} value={item.value}></el-option>;
            })}
          </el-select>
        );
      };
    }
  });
</script>
