<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { SelectType, TableSearchComponentSelect } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: String,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponentSelect>,
        required: true
      }
    },
    setup(props, { emit }) {
      // 联想事件
      function getSuggestions(inputValue: string, cb: (data: SelectType[]) => void) {
        cb([{ label: 'label' + inputValue, value: inputValue }]);
      }
      return () => {
        return (
          <el-autocomplete
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请输入' + props.data.label}
            value-key="label"
            fetch-suggestions={getSuggestions}
            trigger-on-focus={false}
            {...{
              'onUpdate:modelValue': (value: string) => {
                emit('update:modelValue', value);
              },
              onSelect: (item: SelectType) => {
                console.log(item);
              }
            }}
          />
        );
      };
    }
  });
</script>
