<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponent } from '@/components/table/table';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: String,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponent>,
        required: true
      }
    },
    setup(props, { emit }) {
      return () => {
        return (
          <el-input
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请输入' + props.data.label}
            {...{
              'onUpdate:modelValue': (value: string) => {
                console.log(value);
                emit('update:modelValue', value);
              }
            }}
          />
        );
      };
    }
  });
</script>
