<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponent } from '@/components/table/table';
  import { formatterTimer } from '@/utils/index';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: String,
        value: ''
      },
      data: {
        type: Object as PropType<TableSearchComponent>,
        required: true
      }
    },
    setup(props, { emit }) {
      return () => {
        return (
          <el-date-picker
            class="full_label"
            modelValue={props.modelValue}
            placeholder={'请输入' + props.data.label}
            type="datetime"
            {...{
              'onUpdate:modelValue': (value: Date) => {
                emit('update:modelValue', formatterTimer(value, 'YYYY-MM-DD HH:mm:ss'));
              }
            }}
          />
        );
      };
    }
  });
</script>
