<script lang="tsx">
  import { defineComponent, PropType } from 'vue';
  import { TableSearchComponentRange } from '@/components/table/table';
  import { formatterTimer } from '@/utils/index';
  export default defineComponent({
    components: {},
    props: {
      modelValue: {
        type: Array,
        value: []
      },
      data: {
        type: Object as PropType<TableSearchComponentRange>,
        required: true
      }
    },
    setup(props, { emit }) {
      return () => {
        return (
          <el-date-picker
            class="full_label"
            modelValue={props.modelValue}
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            {...{
              'onUpdate:modelValue': (value: Array<Date>) => {
                const result = value.map((item) => {
                  return formatterTimer(item);
                });
                emit('update:modelValue', result);
              }
            }}
          />
        );
      };
    }
  });
</script>
