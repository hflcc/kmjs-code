<template>
  <div class="kmjs_table_search">
    <div class="kmjs_table_search_single_box">
      <div class="left">
        <single ref="singleSearch" :data="data" />
      </div>
      <div class="middle">
        <el-button size="mini" @click="singleSearach"> 查询 </el-button>
      </div>
      <div class="right">
        <el-button type="primary" @click="changeSearchAll" size="mini">
          {{ showSearchAll ? '普通搜索' : '高级搜索' }}
        </el-button>
      </div>
    </div>
    <transition name="el-zoom-in-center">
      <all v-show="showSearchAll" @allSearch="allSearch" :data="data" />
    </transition>
  </div>
</template>

<script lang="ts">
  import { SearchDataType, TableSearch } from '@/components/table/table';
  import { defineComponent, PropType, ref } from 'vue';
  import all from './all.vue';
  import single from './single.vue';
  export default defineComponent({
    name: 'kmjs_table_search',
    components: {
      all,
      single
    },
    props: {
      data: {
        type: Object as PropType<TableSearch>,
        required: true
      }
    },
    emits: ['search'],
    setup(props, { emit }) {
      const singleSearch = ref();
      // 展示是否搜索全部
      const showSearchAll = ref(true);
      // 切换是否搜索全部
      function changeSearchAll() {
        showSearchAll.value = !showSearchAll.value;
      }
      // 单一搜索按钮查询
      function singleSearach() {
        emit('search', singleSearch.value.getFormData());
      }
      // 多个搜索条件
      function allSearch(data: SearchDataType) {
        emit('search', data);
      }
      // 表单数据
      return {
        // 是否高级搜索
        showSearchAll,
        // 切换高级搜索
        changeSearchAll,
        // 单一搜索的ref
        singleSearch,
        // 搜索方法
        singleSearach,
        // 多个搜索条件
        allSearch
      };
    }
  });
</script>

<style lang="less">
  .kmjs_table_search {
    .kmjs_table_search_single,
    .kmjs_table_search_all {
      .el-form-item {
        margin-bottom: 10px;
      }
      .full_label {
        width: 100%;
      }
    }
    .kmjs_table_search_single_box {
      display: flex;
      .left {
        width: 50%;
      }
      .middle {
        padding: 0 12px;
      }
      .right {
        flex: 1;
        text-align: right;
      }
    }
  }
</style>
