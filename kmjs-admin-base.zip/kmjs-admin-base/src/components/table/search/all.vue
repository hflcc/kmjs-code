<script lang="tsx">
  import { defineComponent, PropType, reactive, ref } from 'vue';
  import { SearchDataType, TableSearch } from '@/components/table/table';
  import { mixins, renderComponent } from './components/renderHelper';
  import { ElForm } from 'element-plus';
  export default defineComponent({
    name: 'kmjs_table_search_all',
    mixins: [mixins],
    props: {
      data: {
        type: Object as PropType<TableSearch>,
        required: true
      }
    },
    emits: ['allSearch'],
    setup(props, { emit }) {
      // 表单数据
      const formData = reactive<SearchDataType>({});
      // form 实例
      const form = ref<InstanceType<typeof ElForm>>();
      // 搜索按钮点击
      function search() {
        emit('allSearch', formData);
      }
      // 重置按钮点击
      function reset() {
        form.value?.resetFields();
      }
      return () => {
        return (
          <div class="kmjs_table_search_all">
            <el-form ref={form} label-width="auto" model={formData} size="mini">
              <el-row>
                {props.data.filters.map((item) => {
                  {
                    return (
                      <el-col xl={8} md={12} sm={24} xs={24}>
                        <el-form-item label={item.label} prop={item.key}>
                          {renderComponent(formData, item)}
                        </el-form-item>
                      </el-col>
                    );
                  }
                })}
                <el-col xl={8} md={12} sm={24} xs={24}>
                  <el-form-item>
                    <el-button size="mini" onClick={search}>
                      查询
                    </el-button>
                    <el-button size="mini" onClick={reset}>
                      重置
                    </el-button>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        );
      };
    }
  });
</script>
