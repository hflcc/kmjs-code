<template>
  <div class="kmjs_table_paging">kmjs_table_paging</div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
    name: 'kmjs_table_paging',
    components: {},
    setup() {
      return {};
    }
  });
</script>

<style lang="less">
  .kmjs_table_paging {
  }
</style>
