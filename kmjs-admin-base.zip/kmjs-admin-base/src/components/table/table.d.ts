// 搜索模块
export interface SearchDataType {
  [key: string]: string | number | Array<string | number>;
}
// 选择器数据类型
export interface SelectType {
  label: string;
  value: string | number;
}
// 接口继承接口 -> extends
export interface TableSearchBasic {
  label: string;
  key: string;
}
// 基本表单
export interface TableSearchComponent extends TableSearchBasic {
  type: 'datePickerDate' | 'datePickerTime' | 'inputNumber' | 'inputText';
  defaultValue?: string | number;
}
// 建议项
export interface TableSearchComponentSuggest extends TableSearchBasic {
  type: 'suggest';
  value: string;
  defaultValue?: string | number;
}
// 'datePickerDateRange' | 'datePickerTimeRange' 区间表单
export interface TableSearchComponentRange extends TableSearchBasic {
  type: 'datePickerDateRange' | 'datePickerTimeRange';
  defaultValue?: string[];
}
// 'select' 选择器
export interface TableSearchComponentSelect extends TableSearchBasic {
  type: 'select';
  value: SelectType[];
  defaultValue?: string | number;
}
// 'selectMultiple' 多选的选择器
export interface TableSearchComponentSelectMultiple extends TableSearchBasic {
  type: 'selectMultiple';
  value: SelectType[];
  defaultValue?: Array<number | string>;
}
// 'selectDict' 字典选择器
export interface TableSearchComponentSelectDict extends TableSearchBasic {
  type: 'selectDict';
  value: string;
  defaultValue?: string | number;
}
// 'selectDictMultiple' 多选的字典选择器
export interface TableSearchComponentSelectDictMultiple extends TableSearchBasic {
  type: 'selectDictMultiple';
  value: string;
  defaultValue?: Array<number | string>;
}

// button模块
export interface TableButtonDesc {
  label: string;
  key: string;
  cb: () => void;
}

// 列表表单
export interface TableTable {
  columns: Array<TableTableColumn>;
  buttons: Array<TableTableCrossWise>;
}
// 列表每一列
export interface TableTableColumn {
  prop: string;
  label: string;
  sort?: boolean;
  width?: number;
  render?: (data: any) => JSX.Element;
}
// 列表每一行的按钮
export interface TableTableCrossWise {
  label: string | (() => string);
  key: string;
  attributes: () => any;
  cb: () => void;
}

export interface TableSearch {
  defaultSuggest: string;
  filters: Array<
    | TableSearchComponent
    | TableSearchComponentSuggest
    | TableSearchComponentRange
    | TableSearchComponentSelect
    | TableSearchComponentSelectDict
    | TableSearchComponentSelectMultiple
    | TableSearchComponentSelectDictMultiple
    | TableSearchComponentUnknow
  >;
}
export interface TableComponent<REQ, RES> {
  beforeRequest?: (data: REQ) => Promise<REQ>;
  url: (data: REQ) => Promise<RES>;
  search: TableSearch;
  handleButton: TableButtonDesc[];
  table: TableTable;
}
