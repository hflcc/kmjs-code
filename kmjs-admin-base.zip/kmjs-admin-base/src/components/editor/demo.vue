<!-- 文本编辑器demo 请勿修改 -->
<template>
  <div class="home">
    <button @click="disabledChange">disable</button>
    <kmjsEditor :controller="editCtl" />
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import kmjsEditor, { useEdit } from '@/components/editor';

  export default defineComponent({
    name: 'demo-edit',
    components: {
      kmjsEditor
    },
    setup() {
      const disabled = ref(false);
      // { clear: editClear, getData: editGetData }
      const [editCtl, { setData: editSetData, setDisabled: editSetDisabled }] = useEdit({
        onfocus(html) {
          console.log('focus use', html);
        },
        onblur(html) {
          console.log('onblur use', html);
        },
        onchange(html) {
          console.log('onchange use', html);
        },
        autoFocus: true,
        showFullScreen: true
      });
      editSetData('<p>我是大帅哥</p>');
      editSetDisabled(true);
      return {
        editCtl,
        disabled,
        disabledChange: () => {
          editSetDisabled(true);
        }
      };
    }
  });
</script>

<style lang="less" scoped>
  .home {
  }
</style>
