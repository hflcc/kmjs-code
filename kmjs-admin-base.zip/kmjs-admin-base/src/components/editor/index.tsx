import { defineComponent, onMounted, watch, ref, PropType, h } from 'vue';
import { ElMessageBox } from 'element-plus';
import E from 'wangeditor';
import { Options, EditVnode } from './useEdit';
import xss from 'xss';

/**
 * 初始化编辑器
 * @param options {Options} 配置项
 * @return E 实例化后的编辑器实例
 * */
const initEditor = (options: Required<Options>) => {
  const editor = new E('#editorWrap');
  editor.config.focus = options.autoFocus;
  editor.config.onblur = options.onblur;
  editor.config.onfocus = options.onfocus;
  editor.config.onchange = options.onchange;
  editor.config.menus = options.menus;
  // 是否显示全屏
  editor.config.showFullScreen = options.showFullScreen;
  // 隐藏插入网络图片的功能
  editor.config.showLinkImg = false;
  // 隐藏插入网络视频的功能
  editor.config.showLinkVideo = false;
  // editor.config.fontSizes = {
  //   'x-small': { name: '10px', value: '1' },
  //   'small': { name: '13px', value: '2' },
  //   'normal': { name: '16px', value: '3' },
  //   'large': { name: '18px', value: '4' },
  //   'x-large': { name: '24px', value: '5' },
  //   'xx-large': { name: '32px', value: '6' },
  //   'xxx-large': { name: '48px', value: '7' },
  // }
  editor.config.customAlert = function (s: string, t: string) {
    switch (t) {
      case 'success':
        ElMessageBox.alert(s, {
          type: 'success'
        });
        break;
      case 'info':
        ElMessageBox.alert(s, {
          type: 'info'
        });
        break;
      case 'warning':
        ElMessageBox.alert(s, {
          type: 'warning'
        });
        break;
      case 'error':
        ElMessageBox.alert(s, {
          type: 'error'
        });
        break;
      default:
        ElMessageBox.alert(s, {
          type: 'info'
        });
        break;
    }
  };
  editor.create();
  return editor;
};
export { useEdit } from './useEdit';
export default defineComponent({
  name: 'kmjs-editor',
  props: {
    controller: {
      type: Function as PropType<(obj: { setOptions: (op: Options) => EditVnode }) => void>,
      default: () => {
        return null;
      }
    }
  },
  setup(props) {
    let editor: E;
    // 记录下是否被禁用
    let disable = false;
    let options: Options = {
      autoFocus: false,
      menus: [
        'head',
        'bold',
        'fontSize',
        'fontName',
        'italic',
        'underline',
        'strikeThrough',
        'indent',
        'lineHeight',
        'foreColor',
        'backColor',
        'link',
        'list',
        'todo',
        'justify',
        'quote',
        'emoticon',
        'image',
        'table',
        'code',
        'splitLine',
        'undo',
        'redo'
      ],
      showFullScreen: false
    };
    const clearContent = () => {
      editor?.txt.clear();
    };
    const setDisabled = (flag: boolean) => {
      disable = flag;
      if (flag) {
        editor?.disable();
      } else {
        editor?.enable();
      }
    };
    const change = (html: string, fun?: (html: string) => void) => {
      if (disable) return;
      fun?.(xss(html));
    };
    onMounted(() => {
      props.controller({
        setOptions(op: Options) {
          options = Object.assign({}, options, op, {
            onblur: (html: string) => {
              change(html, op.onblur);
            },
            onfocus: (html: string) => {
              change(html, op.onfocus);
            },
            onchange: (html: string) => {
              change(html, op.onchange);
            }
          });
          editor = initEditor(options as Required<Options>);
          return {
            getData(): string {
              return editor?.txt.html() || '';
            },
            clear: clearContent,
            setDisabled,
            setData(data: string) {
              editor?.txt.html(data);
            }
          };
        }
      });
    });
  },
  render() {
    return <div class="editor-wrap" id="editorWrap"></div>;
  }
});
