<template>
  <div class="sidebar">
    <el-menu
      :default-active="activeMenu"
      class="menu"
      @select="selectMenu"
      :collapse="iconMenu"
      background-color="#304156"
      text-color="#bfcbd9"
      active-text-color="#409EFF"
    >
      <kmjs-sidebar-item v-for="(item, index) in menu" :data="item" :key="index" />
    </el-menu>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import kmjsSidebarItem from '@/components/sidebar/item.vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'sidebar',
    components: {
      kmjsSidebarItem
    },
    setup() {
      const store = useStore();
      const route = useRoute();
      const router = useRouter();
      const selectMenu = (data: string, data1: string[]) => {
        // console.log(data, data1, data2);
        router.push({ path: data1.join('/') });
      };
      const iconMenu = computed(() => store.getters['menu/iconMenu']);
      const menu = computed(() => store.getters['user/menus']);
      const activeMenu = computed(() => {
        const paths = route.path.split('/');
        return (paths.length > 2 ? '' : '/') + paths.slice(paths.length - 1)[0];
      });
      return {
        menu,
        selectMenu,
        iconMenu,
        activeMenu
      };
    }
  });
</script>

<style lang="less">
  .sidebar {
    .menu {
      height: 100%;

      &:not(.el-menu--collapse) {
        width: 256px;
      }
    }

    .el-menu--collapse .title {
      display: none;
    }
  }
</style>
