<template>
  <el-submenu
    class="sidebar_item"
    v-if="data.children && data.children.length > 0"
    :index="data.path"
  >
    <template #title>
      <i class="icon" v-if="data.meta && data.meta.icon" :class="['el-icon-' + data.meta.icon]"></i>
      <span class="title">{{ data.name }}</span>
    </template>
    <sidebar-item v-for="(item, index) in data.children" :data="item" :key="index" />
  </el-submenu>
  <el-menu-item v-else :index="data.path">
    <i v-if="data.meta && data.meta.icon" class="icon" :class="['el-icon-' + data.meta.icon]"></i>
    <span class="title">{{ data.name }}</span>
  </el-menu-item>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { RouteRecordRaw } from 'vue-router';

  export default defineComponent({
    name: 'sidebar-item',
    props: {
      data: {
        type: Object as PropType<RouteRecordRaw>,
        required: true
      }
    },
    setup() {
      return {};
    }
  });
</script>

<style lang="less">
  .sidebar_item {
    .icon {
      font-size: 24px;
    }
  }
</style>
