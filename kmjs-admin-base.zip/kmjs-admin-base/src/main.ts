import { createApp } from 'vue';
// store
import store from './store';
// router
import router from './router';
// 初始化实例
import App from './App.vue';
// 初始化样式
import 'normalize.css';
// element-ui-plus
import 'element-plus/lib/theme-chalk/index.css';
import ElementPlus from 'element-plus';
// 全局样式
import './style/global.less';
import '@/router/permission';

import locale from 'element-plus/lib/locale/lang/zh-cn';
const app = createApp(App);

app.use(ElementPlus, { locale });
app.use(store);
app.use(router);
app.mount('#app');
// 权限控制
import installDirectives from '@/directives';

installDirectives(app);
