import { App } from '@vue/runtime-core';
import permissions from './permissions';

export default (app: App) => {
  app.directive('permissions', permissions);
};
