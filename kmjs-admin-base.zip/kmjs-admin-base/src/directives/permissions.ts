import { VNode } from 'vue';
import { checkPermission } from '@/utils/permission';

export default {
  mounted(el: VNode, binding: { value: string }) {
    // 判断是否是HTML的原生DOM
    const element = el.el || el;
    if (!checkPermission(binding.value)) {
      element.parentElement.removeChild(element);
    }
  }
};
