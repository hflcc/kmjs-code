interface ServerRouterData {
  name: string;
  children?: ServerRouterData[];
}
