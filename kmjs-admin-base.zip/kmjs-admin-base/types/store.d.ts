interface TabMenuItem {
  // 路由标题
  title: string;
  // 路由名称
  name: string;
  // 路由地址
  path: string;
  // 被缓存的组件名称
  keepName: string;
}

interface MenuInfo {
  // 菜单是不是只显示为ICON
  iconMenu: boolean;
  // 需要被keep-alive缓存的页面组件
  keepAlive: string[];
  // 当前被激活的tabs菜单项
  activeRoute: string;
  // 被加入tabs中的菜单项
  tabMenus: TabMenuItem[];
}

interface UserInfo {
  // 用户菜单
  menus: RouteRecordRaw[];
  // 用户登录态
  token: string;
  // 用户机构信息
  organization: string;
  // 用户名
  userName: string;
  // 权限字符串
  permissions: string[];
}

interface RootState {
  user: UserInfo;
  menu: MenuInfo;
}
