const path = require('path');
const express = require('express');
const compression = require('compression');
const history = require('connect-history-api-fallback');
const bodyParser = require('body-parser');

const session = require('./session');
const passport = require('./passport');
const proxy = require('./proxy');
const logger = require('./logger');

// 获取绝对路径,根据service文件夹来
function resolve(_path) {
  _path = _path[0] === '/' ? _path.slice(1) : _path;
  return path.join(__dirname, '../../', _path);
}

// 初始化app
function initApp(app) {
  // 初始化日志系统
  global.info = logger.info.bind(logger);
  global.warn = logger.warn.bind(logger);
  global.error = logger.error.bind(logger);
  // 心跳检查
  app.get('/health', (request, response) => {
    response.send({ status: 'UP' });
  });
  // gzip
  app.use(compression());
  // vue-router history mode
  app.use(history());
  // 静态文件配置
  app.use(express.static(resolve('/public')));
  // // body 解析
  // app.use(bodyParser.json());
  // app.use(bodyParser.urlencoded({ extended: false }));
  // 初始化session
  session(app);
  // 初始化passport
  passport(app);
  // 最后设置代理
  proxy(app);
}

exports.resolve = resolve;
exports.initApp = initApp;
