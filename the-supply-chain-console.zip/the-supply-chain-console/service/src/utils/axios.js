const axios = require('axios');
const env = JSON.parse(process.env.NODE_ENV);
const baseURL = env.api.url;

const service = axios.create({
  baseURL,
  timeout: 60 * 1000
});

service.interceptors.request.use(
  (config) => {
    global.info(
      `request => url: ${config.url};headers: ${JSON.stringify(
        config.headers
      )};params: ${JSON.stringify(config.params)};data: ${JSON.stringify(config.data)}`
    );
    return config;
  },
  (err) => {
    global.error('发送请求错误');
    global.error(err && err.message);
    return Promise.reject(err);
  }
);

service.interceptors.response.use(
  (response) => {
    const { config, data } = response;
    global.info(`response => url: ${config.url};data: ${JSON.stringify(data)}`);
    return response;
  },
  (err) => {
    global.error(
      '返回请求错误',
      err.request && err.request.url,
      err.response && err.response.status
    );
    global.error('message =>', err && err.message);
    const data = (err.response && err.response.data) || {};
    global.error('response => ', JSON.stringify(data));
    return Promise.reject(err);
  }
);

module.exports = service;
