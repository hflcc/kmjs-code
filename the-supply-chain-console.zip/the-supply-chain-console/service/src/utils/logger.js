const log4js = require('log4js');
const path = require('path');

log4js.configure({
  appenders: {
    log: {
      type: 'console',
      // filename: path.join(__dirname, '../../logs/log'),
      // pattern: 'yyyy-MM-dd.log',
      // alwaysIncludePattern: true
    }
  },
  categories: {
    default: { appenders: ['log'], level: 'all' }
  }
});
module.exports = log4js.getLogger();
