// 设置环境变量
function setEnv() {
  const setEnv = process.argv.slice(2);
  const allEnv = getAllEnv();
  let currentEnv = 'development';
  if (setEnv.length > 0) {
    for (let i = 0; i < setEnv.length; i++) {
      const [key, value] = setEnv[i].split('=');
      if (key === 'env') {
        currentEnv = value;
        break;
      }
    }
  }
  if (allEnv[currentEnv]) {
    process.env.NODE_ENV = JSON.stringify(allEnv[currentEnv]);
  } else {
    throw new Error('初始化环境有误');
  }
}
const serverConfig = {
  port: 16001,
  // clientID
  clientID: '67B723CABE49_2',
  // clientSecret
  clientSecret: '28C6E098E9174444BC9F401DB7F9DC',
};

// 导出环境
function getAllEnv() {
  return {
    // 本地开发环境
    development: {
      ...serverConfig,
      // clientID:clientSecret 的 base64
      iDSecretBase64: new Buffer.from(`${serverConfig.clientID}:${serverConfig.clientSecret}`).toString(
          "base64"
      ),
      // api 相关
      api: {
        // 请求的地址
        url: 'https://api-dev.kmyun.cn'
      },
      // redis相关
      redis: {
        // redis 地址
        host: '127.0.0.1',
        // redis 端口
        port: 6379,
        // redis 端口
        db: 10,
        // 密码
        auth_pass: '',
        // 存储前缀
        prefix: 'dev_ms_admin_'
      },
      // session相关
      session: {
        // cookie 过期时间
        maxAge: 1000 * 60 * 60 * 24 * 15,
        // 加密cookie的秘钥,一个随机字符串
        secret: 'Gi6zDvtS5!AC4hV13Wv@H9kl5^@ItBl0',
        /**
         * 这个字段是否强制保留 但是没有测试出来证实用图;
         * 官方推荐置为false
         */
        resave: false,
        /**
         * 是否保存未验证的信息
         * 默认true
         * 官方推荐设置为false
         */
        saveUninitialized: false
      }
    },
    // 测试环境
    test: {
      ...serverConfig,
      // clientID:clientSecret 的 base64
      iDSecretBase64: new Buffer.from(`${serverConfig.clientID}:${serverConfig.clientSecret}`).toString(
          "base64"
      ),
      // api 相关
      api: {
        // 请求的地址
        url: 'http://api-dev.kmyun.cn'
      },
      // redis相关
      redis: {
        // redis 地址
        host: 'r-wz9kvkxb4hnlut0ecr.redis.rds.aliyuncs.com',
        // redis 端口
        port: 6379,
        // redis 端口
        db: 1,
        // 密码
        auth_pass: 'Redis@kmjs',
        // 存储前缀
        prefix: 'dev_ms_admin_'
      },
      // session相关
      session: {
        // cookie 过期时间
        maxAge: 1000 * 60 * 60 * 24 * 15,
        // 加密cookie的秘钥,一个随机字符串
        secret: 'Gi6zDvtS5!AC4hV13Wv@H9kl5^@ItBl0',
        /**
         * 这个字段是否强制保留 但是没有测试出来证实用图;
         * 官方推荐置为false
         */
        resave: false,
        /**
         * 是否保存未验证的信息
         * 默认true
         * 官方推荐设置为false
         */
        saveUninitialized: false
      }
    },
    // 生产环境
    prod: {
      ...serverConfig,
      // clientID:clientSecret 的 base64
      iDSecretBase64: new Buffer.from(`${serverConfig.clientID}:${serverConfig.clientSecret}`).toString(
          "base64"
      ),
      // api 相关
      api: {
        // 请求的地址
        url: 'http://api.kmyun.cn'
      },
      // redis相关
      redis: {
        // redis 地址
        host: 'r-wz9k8g6o5dxy6gxw7s.redis.rds.aliyuncs.com',
        // redis 端口
        port: 6379,
        // redis 端口
        db: 1,
        // 密码
        auth_pass: 'Redis@Mxhcom',
        // 存储前缀
        prefix: 'dev_ms_admin_'
      },
      // session相关
      session: {
        // cookie 过期时间
        maxAge: 1000 * 60 * 60 * 24 * 15,
        // 加密cookie的秘钥,一个随机字符串
        secret: 'Gi6zDvtS5!AC4hV13Wv@H9kl5^@ItBl0',
        /**
         * 这个字段是否强制保留 但是没有测试出来证实用图;
         * 官方推荐置为false
         */
        resave: false,
        /**
         * 是否保存未验证的信息
         * 默认true
         * 官方推荐设置为false
         */
        saveUninitialized: false
      }
    }
  };
}

module.exports = setEnv;
