const Redis = require('redis');
const ExpressSession = require('express-session');
const ConnectRedisStore = require('connect-redis');
const RedisStore = ConnectRedisStore(ExpressSession);
module.exports = (app) => {
  const env = JSON.parse(process.env.NODE_ENV);
  global.info('redis', JSON.stringify(env.redis));
  const { clientID } = env;
  const { host, db, port, prefix, auth_pass } = env.redis;
  const { secret, resave, saveUninitialized, maxAge } = env.session;
  app.use(
    ExpressSession({
      secret,
      resave,
      saveUninitialized,
      store: new RedisStore({
        client: Redis.createClient(port, host, {
          db,
          prefix: prefix + clientID + '_',
          password: auth_pass || ''
        })
      }),
      cookie: {
        maxAge
      }
    })
  );
};
