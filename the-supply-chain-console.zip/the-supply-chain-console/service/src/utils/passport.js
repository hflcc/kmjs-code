const passport = require('passport');
const loginByPassword = require('../handler/login-password');
const loginBySmscCode = require('../handler/login-smscode');
const logout = require('../handler/logout');

module.exports = (app) => {
  app.use(passport.initialize());
  app.use(passport.session());
  passport.serializeUser((user, done) => {
    done(null, user);
  });
  passport.deserializeUser((user, done) => {
    done(null, user);
  });
  // 账号登录的拦截
  loginByPassword(app);
  // 验证码登录的拦截
  loginBySmscCode(app);
  // 验证码登录的拦截
  logout(app);
};
