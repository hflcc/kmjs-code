const express = require('express');
const router = express.Router();
const { createProxyMiddleware } = require('http-proxy-middleware');
const ensureLogin = require('../middleware/ensure-login');

module.exports = (app) => {
  const env = JSON.parse(process.env.NODE_ENV);
  // 登录状态验证
  router.use('/auth', ensureLogin());
  // 转发带登录态的
  router.use(
    '/auth',
    createProxyMiddleware({
      target: env.api.url,
      changeOrigin: true,
      pathRewrite: {
        '^/auth': ''
      },
      logLevel: 'debug',
      logProvider: () => {
        return {
          log: global.info,
          debug: global.info,
          info: global.info,
          warn: global.warn,
          error: global.error
        };
      },
      onProxyReq(proxyReq, req) {
        proxyReq.setHeader('AppId', req && req.headers && req.headers.Appid || env.clientID);
        proxyReq.setHeader(
          'Authorization',
          `Bearer ${(req && req.user && req.user.access_token) || ''}`
        );
      }
    })
  );
  // 转发不带登录态的
  router.use(
    '/api',
    createProxyMiddleware({
      target: env.api.url,
      changeOrigin: true,
      pathRewrite: {
        '^/api': ''
      },
      logLevel: 'debug',
      logProvider: () => {
        return {
          log: global.info,
          debug: global.info,
          info: global.info,
          warn: global.warn,
          error: global.error
        };
      },
      onProxyReq(proxyReq) {
        proxyReq.setHeader('AppId', env.clientID);
      }
    })
  );
  // 本地mock版本
  router.use(
    '/mock',
    createProxyMiddleware({
      target: 'http://localhost:8889',
      changeOrigin: true,
      pathRewrite: {
        '^/mock': ''
      },
      logLevel: 'debug',
      logProvider: () => {
        return {
          log: global.info,
          debug: global.info,
          info: global.info,
          warn: global.warn,
          error: global.error
        };
      }
    })
  );
  app.use(router);
};
