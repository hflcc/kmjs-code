const passport = require('passport');
const passportLocal = require('passport-local');
const axios = require('../utils/axios');

const LocalStategy = passportLocal.Strategy;

module.exports = (app) => {
  const env = JSON.parse(process.env.NODE_ENV);
  passport.use(
    'accountLogin',
    new LocalStategy(
      {
        usernameField: 'username',
        passwordField: 'password'
      },
      async (username, password, done) => {
        try {
          const result = await axios.get('/oauth2/oauth/token', {
            params: {
              username,
              password,
              grant_type: 'password',
              scope: 'all'
            },
            headers: {
              Authorization: 'Basic ' + env.iDSecretBase64
            }
          });
          // 真正登录
          return done(null, { ...result.data, username, password });
        } catch (e) {
          done(e);
        }
      }
    )
  );
  app.all('/login/by/password', passport.authenticate('accountLogin'), (req, res) => {
    res.end();
  });
};
