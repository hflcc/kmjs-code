const passport = require('passport');
const passportLocal = require('passport-local');
const axios = require('../utils/axios');

const LocalStategy = passportLocal.Strategy;

module.exports = (app) => {
  const env = JSON.parse(process.env.NODE_ENV);
  passport.use(
    'loginBySmsCode',
    new LocalStategy(
      {
        usernameField: 'phonenum',
        passwordField: 'smscode'
      },
      async (phonenum, smscode, done) => {
        try {
          const result = await axios.get('/oauth2/oauth/token', {
            params: {
              phonenum,
              smscode,
              grant_type: 'sms_code',
              scope: 'all'
            },
            headers: {
              Authorization: 'Basic ' + env.iDSecretBase64
            }
          });
          // 真正登录
          return done(null, { ...result.data, phonenum, smscode });
        } catch (e) {
          done(e);
        }
      }
    )
  );
  app.all('/login/by/smsCode', passport.authenticate('loginBySmsCode'), (req, res) => {
    res.end();
  });
};
