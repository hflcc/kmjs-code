module.exports = (app) => {
  app.all('/logout', (req, res) => {
    req.sessionStore.destroy(req.sessionID, (err) => {
      res.send({
        message: '登出成功'
      });
    });
  });
};
