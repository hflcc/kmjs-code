// 设置环境变量
const setEnv = require('./utils/env');
setEnv();
const env = JSON.parse(process.env.NODE_ENV);
const express = require('express');
const { initApp } = require('./utils/utils');

const app = express();

// 初始化app
initApp(app);
app.use((err, req, res, next) => {
  return res.json({
    nodeCode: err.response && err.response.status,
    nodeInfo: err.response && err.response.data
  });
});
app.listen(env.port, () => {
  global.info('service listeren in ' + env.port);
});
