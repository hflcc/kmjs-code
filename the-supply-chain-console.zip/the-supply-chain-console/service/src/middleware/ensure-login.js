// 确定是否已经登录中间件
module.exports = () => {
  return function (req, res, next) {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      const error = new Error('请先先登录系统!');
      error.status = 401;
      // 兼容全局统一报错
      error.response = {
        status: 401,
        data: '请登录'
      };
      return next(error);
    }
    next();
  };
};
