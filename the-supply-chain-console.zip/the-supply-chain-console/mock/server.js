var http = require("http");
var url = require("url");
var qs = require('querystring');
var log = require('./logs').logs;

var start = function (routerplay) {
  http.createServer(function (request, response) {
    var lu = url.parse(request.url).pathname;
    routerplay(lu, request, response, qs);
  }).listen(8889);
  log.info("服务器已启动,监听8889端口");
  log.info("        使用讲解      ");
  log.info("**************************************");
  log.info("接口地址:")
  log.info("读取文件 get/post => http://localhost:8889/文件夹名字/文件的名字?timeout=如有需要设置延迟的时间(单位: 秒)");
  log.info("DEMO get/post => http://localhost:8889/api/login?timeout=如有需要设置延迟的时间(单位: 秒)");
};

exports.start = start;
