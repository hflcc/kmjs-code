var server = require('./server');
var routerplay = require('./routerplay');
server.start(routerplay.routerplay);
