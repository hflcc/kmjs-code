# mock 使用

首先它是一个node服务，需要在终端中启动它，`npm run mock`;

它的原理是读取 `mock/file`下的文件中的内容并返回

比如登陆接口是`/api/login`，它就是去读取`mock/file/api/login.json`中的数据，并返回

因此，你需要新增接口，只需要增加对于的文件即可
