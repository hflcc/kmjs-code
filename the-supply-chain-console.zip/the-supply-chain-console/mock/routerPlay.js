var log = require('./logs').logs;
const play = require('./play').play;

function routerplay(pathname, request, response, query) {
  log.info(request.method + '请求', pathname);
  if (request.method === 'OPTIONS') {
    response.writeHead(200, {
      'Content-Type': 'text/html',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers':
        'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
    });
    response.write(JSON.stringify({ code: 0, msg: 'ok' }));
    response.end();
    log.info('OPTIONS 请求响应成功');
    return;
  }
  play(pathname, request, response, query);
}

exports.routerplay = routerplay;
