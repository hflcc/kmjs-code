var log = require('./logs').logs;
const fs = require('fs');
const path = require('path');

/**
 * 确认文件是否存在
 * @param urlPath {string} 请求上的文件地址
 * @return {fullPath: string, state: boolean} state true 存在 false 不存在
 * */
function findFile(urlPath) {
  const filePath = urlPath.split('/').slice(1);
  const fullPath = path.resolve(__dirname, './file', filePath.join('/') + '.json');
  let flag = false;
  try {
    flag = fs.statSync(fullPath).isFile();
  } catch (e) {
    flag = false;
  }
  return {
    fullPath,
    state: flag
  };
}

/**
 * 路由总处理函数， 首先先判断文件是否存在，不存在返回404
 * 在尝试去读取数据，如果读取失败，返回500
 * 读取成功后，在按照是否需要延时返回，来觉得返回的时机
 * @param pathName {string} url地址
 * @param request {Request}
 * @param response {Response}
 * @param query 格式化入参的方法
 * */
function play(pathName, request, response, query) {
  if (pathName === '/post') {
    return postData(request, response, query);
  }
  const fileState = findFile(pathName);
  if (fileState.state) {
    try {
      fs.readFile(fileState.fullPath, { encoding: 'utf8' }, function (err, data) {
        if (err) {
          throw err;
        }
        response.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET',
          'Access-Control-Allow-Headers':
            'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
        });
        response.write(data);
        response.end();
      });
    } catch (e) {
      log.info('读取文件错误 ' + pathName);
      response.writeHead(500, {
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET',
        'Access-Control-Allow-Headers':
          'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
      });
      response.write('500 Server error');
      response.end();
    }
  } else {
    log.info('没有找到网页 => ' + pathName);
    response.writeHead(404, {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers':
        'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
    });
    response.write('404 Not found');
    response.end();
  }
}

/**
 * 异步等待接受post入参
 * @param request {Request} 请求
 * @param query 格式化入参的方法
 * @return {Promise<any>}
 * */
function formatJSONData(request, query) {
  return new Promise((s, f) => {
    let postData = '';
    let JSONData = {};
    request.addListener('data', function (pos) {
      postData += pos;
    });
    request.addListener('end', function () {
      log.info('数据接受完成');
      JSONData = query.parse(postData);
      JSONData = JSON.parse(postData);
      s(JSONData);
    });
  });
}

/**
 * 将指定的数据写入指定的文件
 * @param request {Request}
 * @param response {Response}
 * @param query 格式化入参的方法
 * */
async function postData(request, response, query) {
  const reqBody = await formatJSONData(request, query);
  if (!reqBody.fileName || !reqBody.data || typeof reqBody !== 'object') {
    log.info('参数错误');
    response.writeHead(404, {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers':
        'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
    });
    response.write(
      JSON.stringify({
        code: 1000,
        msg: '参数有误差'
      })
    );
    response.end();
    return;
  }
  const pathName = `/${reqBody.filePath || 'api'}/${reqBody.fileName}`;
  const fileState = findFile(pathName);
  if (fileState.state) {
    try {
      fs.writeFileSync(
        fileState.fullPath,
        JSON.stringify({
          code: 0,
          msg: '',
          data: reqBody.data
        })
      );
      response.writeHead(200, {
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET',
        'Access-Control-Allow-Headers':
            'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
      });
      response.write(
          JSON.stringify({
            code: 0,
            msg: 'suc'
          })
      );
      response.end();
    } catch (e) {
      log.info('读取文件错误 ' + pathName);
      response.writeHead(500, {
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET',
        'Access-Control-Allow-Headers':
          'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
      });
      response.write(
        JSON.stringify({
          code: 1000,
          msg: '服务器错误'
        })
      );
      response.end();
    }
  } else {
    log.info('没有找到网页' + pathName);
    response.writeHead(404, {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers':
        'x-requested-with,content-type,token,deviceid,apptype,devicetype,appversion'
    });
    response.write(
      JSON.stringify({
        code: 1000,
        msg: '没有找到文件 》' + pathName
      })
    );
    response.end();
  }
}

module.exports = {
  play
};
