interface ServerRouterData {
  sn: string;
  title: string;
  value: string;
  ico: string;
  propertyList: {
    [l: string]: string;
  };
  childrenList?: ServerRouterData[];
}
