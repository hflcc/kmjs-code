// 获取客服中心定义列表响应
interface GetMkCscDefListRes {
  // 客服中心sn
  sn: string;
  // 客服中心名称
  name: string;
  // 客服中心未读消息
  count: number;
}

// 获取客服群组列表响应
interface GetMkCscInstanceDialogServiceList {
  // 群组头像
  avatar: string;
  // 群组禁言人数
  banSpeak: number;
  // 群组sn
  dialogSn: string;
  // 群组名称
  groupName: string;
  // 最后一条消息
  message?: ImSendMessage;
  // 消息时间
  messageAt: number;
  // 消息发送者--custom是顾客， attendor是客服
  messageBy: 'custom' | 'attendor';
  // 群组未读数
  msgCount: number;
  // 对应的腾讯的ID
  groupSn: string;
  // 群组状态
  state: 'process' | 'finished';
  // 是否置顶
  top?: boolean;
  from: 'minapp' | 'app' | 'pc' | 'wechat';
}
