//#region 基础方法
interface TIMBasic {
  // 用户ID(userID) 和 签名串(userSig) 登录即时通信 IM，登录流程有若干个异步执行的步骤，使用返回的 Promise 对象处理登录成功或失败。
  login: (option: { userID: string; userSig: string }) => Promise<unknown>;

  // 登出即时通信 IM，通常在切换帐号的时候调用，清除登录态以及内存中的所有数据。
  logout: () => Promise<unknown>;

  // 销毁 SDK 实例。SDK 会先 logout，然后断开 WebSocket 长连接，并释放资源
  destroy: () => Promise<unknown>;

  /*
   * eventName: 事件名称
   * handler: 处理事件的方法，当事件触发时，会调用此handler进行处理
   * context: 期望 handler 执行时的上下文
   * */
  on: (eventName: string, handler: (e: TIMCallbackEvent) => void, context?: unknown) => void;

  /*
   * eventName: 事件名称
   * handler: 处理事件的方法，当事件触发时，会调用此handler进行处理
   * context: 期望 handler 执行时的上下文
   * once: 是否只解绑一次
   * */
  off: (eventName: string, handler: () => void, context?: unknown, once: boolean) => void;

  // 插件是一种遵循一定规范的应用程序接口编写出来的程序，即时通信 IM SDK 发送图片、语音、视频、文件等消息需要使用上传插件，将文件上传到腾讯云对象存储。
  registerPlugin: (option: { [name: string]: unknown }) => void;

  // 设置日志级别，低于 level 的日志将不会输出。
  setLogLevel: (level: 0 | 1 | 2 | 3 | 4) => void;
}
//#endregion

//#region 消息常量
interface TIMMessageConst {
  // 当被人加好友时：允许任何人添加自己为好友
  ALLOW_TYPE_ALLOW_ANY: 'AllowType_Type_AllowAny';
  // 当被人加好友时：不允许任何人添加自己为好友
  ALLOW_TYPE_DENY_ANY: 'AllowType_Type_DenyAny';
  // 当被人加好友时：需要经过自己确认才能添加自己为好友
  ALLOW_TYPE_NEED_CONFIRM: 'AllowType_Type_NeedConfirm';
  CONV_AT_ALL: 2;
  CONV_AT_ALL_AT_ME: 3;
  CONV_AT_ME: 1;
  // 会话类型：C2C(Client to Client, 端到端) 会话
  CONV_C2C: 'C2C';
  // 会话类型：GROUP(群组) 会话
  CONV_GROUP: 'GROUP';
  // 会话类型：SYSTEM(系统) 会话
  CONV_SYSTEM: '@TIM#SYSTEM';
  // 管理员禁止加好友标识：默认值，允许加好友
  FORBID_TYPE_NONE: 'AdminForbid_Type_None';
  // 管理员禁止加好友标识：禁止该用户发起加好友请求
  FORBID_TYPE_SEND_OUT: 'AdminForbid_Type_SendOut';
  // 性别：女性
  GENDER_FEMALE: 'Gender_Type_Female';
  // 性别：男性
  GENDER_MALE: 'Gender_Type_Male';
  // 性别：未设置性别
  GENDER_UNKNOWN: 'Gender_Type_Unknown';
  // 群组类型：直播群
  GRP_AVCHATROOM: 'AVChatRoom';
  // 群组类型：聊天室;v2.7.1起弃用，请使用 GRP_MEETING。
  GRP_CHATROOM: 'ChatRoom';
  // 群成员角色：管理员
  GRP_MBR_ROLE_ADMIN: 'Admin';
  // 群成员角色：普通群成员
  GRP_MBR_ROLE_MEMBER: 'Member';
  // 群成员角色：群主
  GRP_MBR_ROLE_OWNER: 'Owner';
  // 群组类型：临时会议群
  GRP_MEETING: 'ChatRoom';
  // 群组类型：私有群;v2.7.1起弃用，请使用 GRP_WORK。
  GRP_PRIVATE: 'Private';
  // 群资料：群创建时间
  GRP_PROFILE_CREATE_TIME: 'createTime';
  // 群资料：群介绍
  GRP_PROFILE_INTRODUCTION: 'introduction';
  // 群资料：申请加群选项
  GRP_PROFILE_JOIN_OPTION: 'joinOption';
  // 群资料：最后一次群资料变更时间
  GRP_PROFILE_LAST_INFO_TIME: 'lastInfoTime';
  // 群资料：当前群组的最大群成员数量
  GRP_PROFILE_MAX_MEMBER_NUM: 'maxMemberNum';
  // 群资料：当前群组的群成员数量
  GRP_PROFILE_MEMBER_NUM: 'memberNum';
  // 群资料：全体禁言设置。v2.6.2 起支持。
  GRP_PROFILE_MUTE_ALL_MBRS: 'muteAllMembers';
  // 群资料：群公告
  GRP_PROFILE_NOTIFICATION: 'notification';
  // 群资料：群主 ID
  GRP_PROFILE_OWNER_ID: 'ownerID';
  // 群组类型：陌生人社交群
  GRP_PUBLIC: 'Public';
  // 群提示：群组资料变更
  GRP_TIP_GRP_PROFILE_UPDATED: 6;
  // 群提示：有群成员被撤销管理员
  GRP_TIP_MBR_CANCELED_ADMIN: 5;
  // 群提示：有成员加群
  GRP_TIP_MBR_JOIN: 1;
  // 群提示：有群成员被踢出群
  GRP_TIP_MBR_KICKED_OUT: 3;
  // 群提示：群成员资料变更
  GRP_TIP_MBR_PROFILE_UPDATED: 7;
  // 群提示：有群成员退群
  GRP_TIP_MBR_QUIT: 2;
  // 群提示：有群成员被设为管理员
  GRP_TIP_MBR_SET_ADMIN: 4;
  // 群组类型：好友工作群
  GRP_WORK: 'Private';
  // 加群选项：不允许加群
  JOIN_OPTIONS_DISABLE_APPLY: 'DisableApply';
  // 加群选项：自由加入
  JOIN_OPTIONS_FREE_ACCESS: 'FreeAccess';
  // 加群选项：需要管理员同意
  JOIN_OPTIONS_NEED_PERMISSION: 'NeedPermission';
  // 加群申请状态：已在群中
  JOIN_STATUS_ALREADY_IN_GROUP: 'AlreadyInGroup';
  // 加群申请状态：加群成功
  JOIN_STATUS_SUCCESS: 'JoinedSuccess';
  // 加群申请状态：等待管理员同意
  JOIN_STATUS_WAIT_APPROVAL: 'WaitAdminApproval';
  // 被踢类型：多账号登录被踢
  KICKED_OUT_MULT_ACCOUNT: 'multipleAccount';
  // 被踢类型：多终端登录被踢
  KICKED_OUT_MULT_DEVICE: 'multipleDevice';
  // 被踢类型：签名过期
  KICKED_OUT_USERSIG_EXPIRED: 'userSigExpired';
  // 群聊时 @ 所有人。v2.9.0 起支持
  MSG_AT_ALL: '__kImSDK_MesssageAtALL__';
  // 消息类型：音频消息
  MSG_AUDIO: 'TIMSoundElem';
  // 消息类型：自定义消息
  MSG_CUSTOM: 'TIMCustomElem';
  // 消息类型：表情消息
  MSG_FACE: 'TIMFaceElem';
  // 消息类型：文件消息
  MSG_FILE: 'TIMFileElem';
  // 消息类型：位置消息
  MSG_GEO: 'TIMLocationElem';
  // 消息类型：群系统通知消息
  MSG_GRP_SYS_NOTICE: 'TIMGroupSystemNoticeElem';
  // 消息类型：群提示消息
  MSG_GRP_TIP: 'TIMGroupTipElem';
  // 消息类型：图片消息
  MSG_IMAGE: 'TIMImageElem';
  // 消息类型：合并消息。v2.10.1 起支持。
  MSG_MERGER: 'TIMRelayElem';
  // 群消息高优先级。建议选择该优先级的消息类型：红包消息和礼物消息
  MSG_PRIORITY_HIGH: 'High';
  // 群消息低优先级。建议选择该优先级的消息类型：点赞消息
  MSG_PRIORITY_LOW: 'Low';
  // 群消息最低优先级。建议选择该优先级的消息类型：最不重要的消息
  MSG_PRIORITY_LOWEST: 'Lowest';
  // 群消息普通优先级。建议选择该优先级的消息类型：普通文本消息
  MSG_PRIORITY_NORMAL: 'Normal';
  // 群消息提示类型：SDK 接收消息并通知接入侧，接入侧做提示
  MSG_REMIND_ACPT_AND_NOTE: 'AcceptAndNotify';
  // 群消息提示类型：SDK 接收消息并通知接入侧，接入侧不做提示
  MSG_REMIND_ACPT_NOT_NOTE: 'AcceptNotNotify';
  // 群消息提示类型：SDK 拒收消息
  MSG_REMIND_DISCARD: 'Discard';
  // 消息类型：音频消息; 注意：已废弃，请使用 MSG_AUDIO
  MSG_SOUND: 'TIMSoundElem';
  // 消息类型：文本消息
  MSG_TEXT: 'TIMTextElem';
  // 消息类型：视频消息
  MSG_VIDEO: 'TIMVideoFileElem';
  // 网络状态：已接入网络。v2.5.0 起支持。
  NET_STATE_CONNECTED: 'connected';
  // 网络状态：连接中。v2.5.0 起支持。
  NET_STATE_CONNECTING: 'connecting';
  // 网络状态：未接入网络。v2.5.0 起支持。
  NET_STATE_DISCONNECTED: 'disconnected';
  // 加好友方式：表示双向加好友
  SNS_ADD_TYPE_BOTH: 'Add_Type_Both';
  // 加好友方式：表示单向加好友
  SNS_ADD_TYPE_SINGLE: 'Add_Type_Single';
  // 同意好友申请方式：同意添加单向好友
  SNS_APPLICATION_AGREE: 'Response_Action_Agree';
  // 同意好友申请方式：同意并添加为双向好友
  SNS_APPLICATION_AGREE_AND_ADD: 'Response_Action_AgreeAndAdd';
  // 拉取好友申请：我发给别人的加好友请求
  SNS_APPLICATION_SENT_BY_ME: 'Pendency_Type_SendOut';
  // 拉取好友申请：别人发给我的加好友请求
  SNS_APPLICATION_SENT_TO_ME: 'Pendency_Type_ComeIn';
  // 拉取好友申请：别人发给我的和我发给别人的加好友请求
  SNS_APPLICATION_TYPE_BOTH: 'Pendency_Type_Both';
  // 校验好友：双向校验好友
  SNS_CHECK_TYPE_BOTH: 'CheckResult_Type_Both';
  // 校验好友：单向校验好友
  SNS_CHECK_TYPE_SINGLE: 'CheckResult_Type_Single';
  // 删除好友方式：表示双向删除好友
  SNS_DELETE_TYPE_BOTH: 'Delete_Type_Both';
  // 删除好友方式：表示单向删除好友
  SNS_DELETE_TYPE_SINGLE: 'Delete_Type_Single';
  // 好友关系：A 的好友表中有 B，但 B 的好友表中没有 A
  SNS_TYPE_A_WITH_B: 'CheckResult_Type_AWithB';
  // 好友关系：A 的好友表中有 B，B 的好友表中也有 A
  SNS_TYPE_BOTH_WAY: 'CheckResult_Type_BothWay';
  // 好友关系：A 的好友表中没有 B，但 B 的好友表中有 A
  SNS_TYPE_B_WITH_A: 'CheckResult_Type_BWithA';
  // 好友关系：A 的好友表中没有 B，B 的好友表中也没有 A
  SNS_TYPE_NO_RELATION: 'CheckResult_Type_NoRelation';
}
//#endregion

//#region 回调事件名称|回调事件使用到的常量
interface TIMEventOrConst {
  // SDK 黑名单列表更新时触发
  BLACKLIST_UPDATED: 'blacklistUpdated';
  // 会话列表更新，event.data 是包含 Conversation 对象的数组
  CONVERSATION_LIST_UPDATED: 'onConversationListUpdated';
  // SDK 遇到错误时触发
  ERROR: 'error';
  // SDK 好友申请列表更新时触发
  FRIEND_APPLICATION_LIST_UPDATED: 'onFriendApplicationListUpdated';
  // 好友分组列表更新时触发
  FRIEND_GROUP_LIST_UPDATED: 'onFriendGroupListUpdated';
  // 好友列表更新时触发
  FRIEND_LIST_UPDATED: 'onFriendListUpdated';
  // SDK 群组列表更新时触发，可通过遍历 event.data 获取群组列表数据并渲染到页面
  GROUP_LIST_UPDATED: 'onGroupListUpdated';
  // 用户被踢下线时触发
  KICKED_OUT: 'kickedOut';
  // SDK 收到消息被第三方回调修改的通知，消息发送方可通过遍历 event.data 获取消息列表数据并更新页面上同 ID 消息的内容。
  MESSAGE_MODIFIED: 'onMessageModified';
  // SDK 收到对端已读消息的通知，即已读回执。可通过遍历 event.data 获取对端已读的消息列表数据并渲染到页面，如单聊会话内可将己方发送的消息由“未读”状态改为“已读”。
  MESSAGE_READ_BY_PEER: 'onMessageReadByPeer';
  // SDK 收到推送的单聊、群聊、群提示、群系统通知的新消息，可通过遍历 event.data 获取消息列表数据并渲染到页面
  MESSAGE_RECEIVED: 'onMessageReceived';
  // SDK 收到消息被撤回的通知，可通过遍历 event.data 获取被撤回的消息列表数据并渲染到页面，如单聊会话内可展示为 "对方撤回了一条消息"；群聊会话内可展示为 "XXX撤回了一条消息"。
  MESSAGE_REVOKED: 'onMessageRevoked';
  // 网络状态发生改变
  NET_STATE_CHANGE: 'netStateChange';
  // 自己或好友的资料发生变更时触发，event.data 是包含 Profile 对象的数组
  PROFILE_UPDATED: 'onProfileUpdated';
  // SDK 进入 not ready 状态时触发，此时接入侧将无法使用 SDK 发送消息等功能。如果想恢复使用，接入侧需调用 login 接口，驱动 SDK 进入 ready 状态
  SDK_NOT_READY: 'sdkStateNotReady';
  // SDK 进入 ready 状态时触发，接入侧监听此事件，然后可调用 SDK 发送消息等API，使用 SDK 的各项功能
  SDK_READY: 'sdkStateReady';
  // 长时间断网后重新接入网络或者小程序长时间切后台又切回前台，SDK 为了和 IM 服务器进行状态及消息同步，需要重载，此时 SDK 会自动登录。如果重载前加入了直播群（AVChatRoom），重载成功后 SDK 会重新加入直播群。
  SDK_RELOAD: 'sdkReload';
  // 以下未找到文档
  SDK_DESTROY: 'sdkDestroy';
  GROUP_SYSTEM_NOTICE_RECEIVED: 'receiveGroupSystemNotice';
}
//#endregion

//#region 模块合并
interface TIMCreateOption {
  SDKAppID: number;
  oversea?: boolean;
}

type TIMInstance = TIMBasic & CreateTIMMessage & HandleMessage;

interface TIM {
  // 创建TIM实例
  create(option: TIMCreateOption): TIMInstance;
  // 回调事件名称|回调事件使用到的常量
  EVENT: TIMEventOrConst;
  // 消息常量
  TYPES: TIMMessageConst;
  // 版本
  VERSION: string;
}

declare const TIMObject: TIM;

declare module 'tim-js-sdk' {
  export = TIMObject;
}

declare module 'tim-upload-plugin' {
  export = any;
}
//#endregion

//#region 消息相关
// 创建发送的信息
interface CreateTIMMessage {
  // 创建文本消息
  createTextMessage: (option: CreateSendMessage<TIMSendPayloadText>) => TIMReceptionMessageType;

  // 创建带@的文本消息
  createTextAtMessage: (option: CreateSendMessage<TIMSendPayloadAtText>) => TIMReceptionMessageType;

  // 创建图片消息的接口，此接口返回一个消息实例，可以在需要发送图片消息时调用 发送消息 接口发送消息。
  createImageMessage: (option: CreateSendMessage<TIMSendPayloadFile>) => TIMReceptionMessageType;

  // 创建音频消息实例的接口，此接口返回一个消息实例，可以在需要发送音频消息时调用 发送消息 接口发送消息。 目前 createAudioMessage 只支持在微信小程序环境使用。
  createAudioMessage: (option: CreateSendMessage<TIMSendPayloadFile>) => TIMReceptionMessageType;

  // 创建视频消息实例的接口，此接口返回一个消息实例，可以在需要发送视频消息时调用 发送消息 接口发送消息。
  createVideoMessage: (option: CreateSendMessage<TIMSendPayloadFile>) => TIMReceptionMessageType;

  // 创建自定义消息实例的接口，此接口返回一个消息实例，可以在需要发送自定义消息时调用 发送消息 接口发送消息。 当 SDK 提供的能力不能满足您的需求时，可以使用自定义消息进行个性化定制，例如投骰子功能。
  createCustomMessage: (option: CreateSendMessage<TIMSendPayloadCustom>) => TIMReceptionMessageType;

  // 创建表情消息实例的接口，此接口返回一个消息实例，可以在需要发送表情消息时调用 发送消息 接口发送消息。
  createFaceMessage: (option: CreateSendMessage<TIMSendPayloadFace>) => TIMReceptionMessageType;

  // 创建文件消息的接口，此接口返回一个消息实例，可以在需要发送文件消息时调用 发送消息 接口发送消息。
  createFileMessage: (option: CreateSendMessage<TIMSendPayloadFile>) => TIMReceptionMessageType;

  // 创建合并消息的接口，此接口返回一个消息实例，可以在需要发送合并消息时调用 发送消息 接口发送消息。
  createMergerMessage: (option: CreateSendMessage<TIMSendPayloadMerger>) => TIMReceptionMessageType;

  // 下载合并消息的接口。如果发送方发送的合并消息较大，SDK 会将此消息存储到云端，消息接收方查看消息时，需要先把消息从云端下载到本地。
  downloadMergerMessage: (option: TIMReceptionMessageType) => Promise<undefined>;

  // 创建转发消息的接口，此接口返回一个消息实例，可以在需要发送转发消息时调用 发送消息 接口发送消息。
  createForwardMessage: (option: CreateMessage<TIMReceptionMessageType>) => TIMReceptionMessageType;
}

// 处理信息
interface HandleMessage {
  // 发送消息的接口，需先调用下列的创建消息实例的接口获取消息实例后，再调用该接口发送消息实例。
  sendMessage: (message: TIMReceptionMessageType, options?: SendMessageOptions) => Promise<unknown>;

  // 撤回单聊消息或者群聊消息。撤回成功后，消息对象的 isRevoked 属性值为 true。
  revokeMessage: (message: TIMReceptionMessageType) => Promise<unknown>;

  // 重发消息的接口，当消息发送失败时，可调用该接口进行重发。
  resendMessage: (message: TIMReceptionMessageType) => Promise<unknown>;

  // 删除消息的接口。删除成功后，被删除消息的 isDeleted 属性值为 true。
  deleteMessage: (message: Array<TIMReceptionMessageType>) => Promise<unknown>;

  setMessageRead: ({ conversationID: string }) => Promise<unknown>;
}

//#region 发送的消息数据类型
// 文本消息的payload
interface TIMSendPayloadText {
  // 消息文本
  text: string;
}

// @消息的payload
interface TIMSendPayloadAtText {
  // 消息文本
  text: string;
  // 需要 @ 的用户列表,数组字符串
  atUserList: Array<string>;
}

// 文件消息的payload
interface TIMSendPayloadFile {
  // File
  file: File;
}

// 自定义消息的payload
interface TIMSendPayloadCustom {
  // 自定义消息的数据字段
  data: string;
  // 自定义消息的说明字段
  description: string;
  // 自定义消息的扩展字段
  extension: string;
}

// 表情消息的payload
interface TIMSendPayloadFace {
  // 表情索引，用户自定义
  index: number;
  //额外数据
  data: string;
}

// 合并消息的payload
interface TIMSendPayloadMerger {
  // 合并的消息列表
  messageList: Array<SendMessage>;
  // 合并的标题，比如："大湾区前端人才中心的聊天记录"
  title: string;
  // 摘要列表，不同的消息类型可以设置不同的摘要信息，比如：文本消息可以设置为：sender: text，图片消息可以设置为：sender: [图片]，文件消息可以设置为：sender: [文件]
  abstractList: string;
  // 兼容文本，低版本 SDK 如果不支持合并消息，默认会收到一条文本消息，文本消息的内容为 ${compatibleText}，必填。
  compatibleText: string;
}

// 创建基本消息
interface CreateSendMessage<PAYLOAD> {
  // 消息接收方的 userID 或 groupID
  to: string;
  // 会话类型
  conversationType: string;
  // 消息优先级
  priority?: string;
  // 消息负载
  payload: PAYLOAD;
  // 获取上传进度的回调函数;只有图片,文件,视频才有;
  onProgress?: (event) => void;
}

// 发送消息的配置项
interface SendMessageOptions {
  // v2.6.4起支持。消息是否仅发送给在线用户的标识，默认值为 false；设置为 true，则消息既不存漫游，也不会计入未读，也不会离线推送给接收方。适合用于发送广播通知等不重要的提示消息场景。在 AVChatRoom 发送消息不支持此选项。
  onlineUserOnly: boolean;
  // v2.6.4起支持。离线推送配置。
  offlinePushInfo: {
    // true 关闭离线推送；false 开启离线推送（默认）
    disablePush: boolean;
    // 离线推送标题。该字段为 iOS 和 Android 共用
    title: string;
    // 离线推送内容。该字段会覆盖消息实例的离线推送展示文本。若发送的是自定义消息，该 description 字段会覆盖 message.payload.description。如果 description 和 message.payload.description 字段都不填，接收方将收不到该自定义消息的离线推送
    description: string;
    // 离线推送透传内容
    extension: string;
    // 离线推送忽略 badge 计数（仅对 iOS 生效），如果设置为 true，在 iOS 接收端，这条消息不会使 APP 的应用图标未读计数增加
    ignoreIOSBadge: string;
    // 离线推送设置 OPPO 手机 8.0 系统及以上的渠道 ID
    androidOPPOChannelID: string;
  };
}

//#endregion

//#region 接受到的消息数据类型
// 文本消息的payload
interface TIMReceptionPayloadText {
  // 消息文本
  text: string;
}

// @消息的payload
interface TIMReceptionPayloadAtText {
  // 消息文本
  text: string;
  // 需要 @ 的用户列表,数组字符串
  atUserList: Array<string>;
}

// 图片消息的payload
interface TIMReceptionPayloadImage {
  // 图片唯一标识
  uuid: string;
  // 图片格式类型，JPG/JPEG = 1，GIF = 2，PNG = 3，BMP = 4，其他 = 255
  imageFormat: number;
  // 图片信息
  imageInfoArray: Array<{
    // 宽度
    width: number;
    // 高度
    height: number;
    // 图片地址，可用于渲染
    url: string;
    // 图片大小，单位：Byte
    size: number;
    // 0	原图 1	198p压缩图 2	720p压缩图
    type: number;
  }>;
}

// 音频消息的payload
interface TIMReceptionPayloadAudio {
  // 图片唯一标识
  uuid: string;
  // 音频地址，可用于播放
  url: number;
  // 文件大小，单位：Byte
  size: number;
  // 音频时长，单位：秒
  second: number;
}

// 视频消息的payload
interface TIMReceptionPayloadVideo {
  // 视频文件的格式
  videoFormat: string;
  // 视频文件的时长，单位秒，整型
  videoSecond: number;
  // 视频文件大小，单位：Byte
  videoSize: number;
  // 视频文件的地址，可用于播放
  videoUrl: string;
  // video 唯一标识
  videoUUID: string;
  // thumb 唯一标识
  thumbUUID: string;
  // 缩略图大小，单位：Byte
  thumbSize: number;
  // 缩略图宽度
  thumbWidth: number;
  // 缩略图高度
  thumbHeight: number;
  // 缩略图地址，可用于渲染
  thumbUrl: string;
}

// 文件消息的payload
interface TIMReceptionPayloadFile {
  // 唯一标识
  uuid: string;
  // 文件名
  fileName: string;
  // 文件地址
  fileUrl: string;
  // 文件大小，单位：Byte
  fileSize: number;
}

// 自定义消息的payload
interface TIMReceptionPayloadCustom {
  // 自定义消息的 data 字段
  data: string;
  // 自定义消息的 description 字段
  description: string;
  // 自定义消息的 extension 字段
  extension: string;
}

// 合并消息的payload
interface TIMReceptionPayloadMerger {
  // 下载合并消息的 key, 如果合并消息的体积较大，SDK 会将消息存储在云端，此 key 作为消息的唯一标识
  downloadKey: string;
  // 合并的消息列表
  messageList: Array<unknown>;
  // 合并的标题，比如："大湾区前端人才中心的聊天记录"
  title: string;
  // 摘要列表，不同的消息类型可以设置不同的摘要信息，比如：文本消息可以设置为：sender: text，图片消息可以设置为：sender: [图片]，文件消息可以设置为：sender: [文件]
  abstractList: string;
  // 兼容文本，低版本 SDK 如果不支持合并消息，默认会收到一条文本消息，文本消息的内容为 ${compatibleText}
  compatibleText: string;
  // 合并消息嵌套层级是否超过限制。true，则消息被截断；默认值为 false
  layersOverLimit: boolean;
}

// 位置消息的payload
interface TIMReceptionPayloadGeo {
  // 相关描述信息
  description: string;
  // 纬度
  latitude: number;
  // 经度
  longitude: number;
}

// 群提示消息的payload
interface TIMReceptionPayloadGroupTip {
  // 相关描述信息
  // 0	默认值，表示该行为不是加群操作
  // 1	申请加群
  // 2	邀请加群
  groupJoinType: number;
  // 执行该操作的用户 ID
  operatorID: string;
  /*
   * 操作类型，具体如下
   * TIM.TYPES.GRP_TIP_MBR_JOIN	1	有成员加群
   * TIM.TYPES.GRP_TIP_MBR_QUIT	2	有群成员退群
   * TIM.TYPES.GRP_TIP_MBR_KICKED_OUT	3	有群成员被踢出群
   * TIM.TYPES.GRP_TIP_MBR_SET_ADMIN	4	有群成员被设为管理员
   * TIM.TYPES.GRP_TIP_MBR_CANCELED_ADMIN	5	有群成员被撤销管理员
   * TIM.TYPES.GRP_TIP_GRP_PROFILE_UPDATED	6	群组资料变更
   * TIM.TYPES.GRP_TIP_MBR_PROFILE_UPDATED	7	群成员资料变更，例如：群成员被禁言
   * */
  operationType: number;
  // 相关的 userID 列表
  userIDList: Array<string>;
  // 若是群资料变更，该字段存放变更的群资料
  newGroupProfile: { groupCustomField: Array<unknown> };
  // 当群成员被禁言时，可在该字段中拿到相关信息
  memberList: Array<{ userID: string; muteTime: number }>;
}

// 群系统通知消息的payload
interface TIMReceptionPayloadGroupSystem {
  // 执行该操作的用户 ID
  operatorID: string;
  /*
   * 操作类型，具体如下
   * 1	有用户申请加群	群管理员/群主接收
   * 2	申请加群被同意	申请加群的用户接收
   * 3	申请加群被拒绝	申请加群的用户接收
   * 4	被踢出群组	被踢出的用户接收
   * 5	群组被解散	全体群成员接收
   * 6	创建群组	创建者接收
   * 7	邀请加群	被邀请者接收
   * 8	退群	退群者接收
   * 9	设置管理员	被设置方接收
   * 10	取消管理员	被取消方接收
   * 11	群已被回收	全员接收，不展示
   * 12	收到加群邀请，被邀请者需要同意或者拒绝	被邀请者接收
   * 13	邀请他人加群，被他人同意	邀请发起者接收
   * 14	邀请他人加群，被他人拒绝	邀请发起者接收
   * 15	已读上报多终端同步通知	只有上报人自己收到
   * 255	用户自定义通知	默认全员接收
   * */
  operationType: number;
  // 相关的群组资料
  groupProfile: unknown;
  // 用户自定义字段。使用 RestAPI 发送自定义通知时，可在该属性值中拿到自定义通知的内容。
  userDefinedField: string;
  // 处理的附言
  handleMessage: unknown;
}

// 消息公用属性的合并
interface TIMReceptionMessage<PAYLOAD> {
  // 消息 ID
  ID: string;
  // 消息载体
  payload: PAYLOAD;
  // 消息所属的会话 ID
  conversationID: string;
  // 消息所属会话的类型，具体如下:
  // TIM.TYPES.CONV_C2C	C2C(Client to Client, 端到端) 会话
  // TIM.TYPES.CONV_GROUP	GROUP(群组) 会话
  // TIM.TYPES.CONV_SYSTEM	SYSTEM(系统) 会话
  conversationType: string;
  // 接收方的 userID
  to: string;
  // 发送方的 userID，在消息发送时，会默认设置为当前登录的用户
  from: string;
  // 消息的流向;in 为收到的消息,out 为发出的消息
  flow: string;
  // 消息时间戳。单位：秒
  time: number;
  // 消息状态;unSend(未发送),success(发送成功),fail(发送失败)
  status: string;
  // 是否被撤回
  isRevoked: boolean;
  // 消息优先级
  priority: string;
  // 发送者昵称
  nick: string;
  // 消息发送者的头像地址
  avatar: string;
  // 是否已读
  isPeerRead: boolean;
  // 消息发送者的群名片
  nameCard: string;
  // 群聊时此字段存储被 at 的群成员的 userID
  atUserList: Array<string>;
  // 消息自定义数据
  cloudCustomData: string;
  // 是否删除信息
  isDeleted: boolean;
  // 是否被第三方修改
  isModified: boolean;
  // 消息类型
  type: string;
  // 消息key
  sequence: number;
}

// 消息类型
type TIMReceptionMessageType =
  | TIMReceptionMessage<TIMReceptionPayloadText>
  | TIMReceptionMessage<TIMReceptionPayloadAtText>
  | TIMReceptionMessage<TIMReceptionPayloadImage>
  | TIMReceptionMessage<TIMReceptionPayloadAudio>
  | TIMReceptionMessage<TIMReceptionPayloadVideo>
  | TIMReceptionMessage<TIMReceptionPayloadFile>
  | TIMReceptionMessage<TIMReceptionPayloadCustom>
  | TIMReceptionMessage<TIMReceptionPayloadMerger>
  | TIMReceptionMessage<TIMReceptionPayloadGeo>
  | TIMReceptionMessage<TIMReceptionPayloadGroupTip>
  | TIMReceptionMessage<TIMReceptionPayloadGroupSystem>;

// 消息类型回调
interface TIMCallbackEvent {
  name: string;
  data: Array<TIMReceptionMessageType>;
}
//#endregion
//#endregion
