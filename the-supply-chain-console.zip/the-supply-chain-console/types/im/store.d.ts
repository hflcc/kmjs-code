interface ImCscService {
  sn: string;
  // 用户昵称
  nickname: string;
  // 用户头像
  avatar: string;
  // 客服ID
  attendorSn: string;
}

// 客服分组信息
interface ImServiceInfo {
  // 客服分组sn
  sn: string;
  // 客服分组名称
  name: string;
  // 客服分组未读数量
  count: number;
  // 客服列表
  serviceMap: { [attendorSn: string]: ImCscService };
}

// 备注信息描述
interface ImRemarkMessage {
  sn: string;
  // 备注客户的姓名
  title: string;
  // 备注的时间
  createdAt: number;
  // 备注联系的客服
  attendorName: string;
  // 备注信息的备注
  content: string;
  // 备注的标签
  tags: string;
}

// 联系计划描述
interface ImContactPlan {
  sn: string;
  // 实际联系时间
  actualContactTime: number;
  // 计划联系时间
  planContactTime: number;
  // 联系内容
  contactContent: string;
  // 联系客服
  serviceName: string;
  // 联系状态
  contactState: string;
  // 联系备注
  remark: string;
  // 客服sn
  attendorSn: string;
}

// 访问信息描述
interface ImVisitMessage {
  // 来源
  source: string;
  // 浏览器
  browser: string;
  // 操作系统
  system: string;
  // 地域
  location: string;
  // ip地址
  ipAddress: string;
}

// 群组信息
interface ImGroupInfo {
  // 群组头像
  avatar: string;
  // 群组禁言人数
  banSpeak: number;
  // 群组状态
  groupState: 'process' | 'finished';
  // 群组sn
  sn: string;
  // 群组姓名
  name: string;
  // 群组对应的客服中心sn
  serviceSn: string;
  bpmSn?: string;
  // 是否在前台显示中
  isShow?: boolean;
  // 腾讯那边的id
  groupSn: string;
  // 最后一条聊天记录内容
  message?: ImSendMessage;
  // 最后一条消息时间
  messageAt: number;
  // 最后一条消息来源
  messageState: 'custom' | 'attendor';
  // 消息
  msgCount: number;
  // 备注信息
  remarkMessage: Array<ImRemarkMessage>;
  // 联系计划
  contactPlan: Array<ImContactPlan>;
  // 访问信息
  visitMessage?: ImVisitMessage;
  // 是否置顶
  top: boolean;
  // 是否获取过额外信息 // 是否需要更新数据
  isExtend: boolean;
  // 来源
  from: 'minapp' | 'app' | 'pc' | 'wechat';
}

// Im系统用户信息
interface ImUserInfo {
  sn: string;
  // im系统的唯一标识
  accountSn: string;
  // im用户签名
  accountSign: string;
  // 用户昵称
  nickname: string;
  // 用户头像
  avatar: string;
  // 在线状态
  state: string;
  // 在线状态
  online: string;
  exist: boolean;
  type: 'custom' | 'attendor';
  // 重连次数
  reconnectionTimes: 0;
  // BPM中是否可以删除
  allowDelete?: boolean;
  instUserSn?: string;
  // 手机号码
  mobile?: string;
}

// 文本消息
interface ImFormatRecordText {
  // 消息文本
  text: string;
  // 被at的成员
  atUserList?: Array<string>;
}

// 自定义消息
interface ImFormatRecordCustom {
  // 自定义消息类型
  desc: SendCustomMessageDesc;
  // 自定义消息数据
  data: string;
}

// 图片消息
interface ImFormatRecordImage {
  // 图片地址
  url: string;
}

// 文件消息
interface ImFormatRecordFile {
  // 文件名称
  fileName: string;
  // 文件地址
  fileUrl: string;
  // 文件大小
  fileSize: number;
}

// 文件消息
interface ImFormatRecordVideo {
  // 视频地址
  videoUrl: string;
  // 视频长度
  videoSecond: number;
  // 文件大小
  videoSize: number;
  // 视频的第一帧
  thumbUrl: string;
}

// Im消息体
type ImFormatRecord =
  | ImFormatRecordText
  | ImFormatRecordCustom
  | ImFormatRecordImage
  | ImFormatRecordFile
  | ImFormatRecordVideo;

// 获取群组时,最后
interface ImGroupLastMessage {
  // 消息类型
  messageType: string;
  // 消息体
  messageBody: ImFormatRecord;
}

// 聊天记录描述
interface ImChattingRecord {
  // 消息sn
  sn: string;
  // 消息的流向;in 为收到的消息,out 为发出的消息
  flow: string;
  // 消息类型
  messageType: string;
  // 消息体
  messageBody: ImFormatRecord;
  // 消息KEY
  messageKey: string;
  // 消息发送者
  from: ImUserInfo;
  // 消息状态
  status: string;
  // 是否撤回
  isRevoked: boolean;
  // 是否已读
  isPeerRead: boolean;
  // 发送时间
  time: number;
  // 是否是第一条
  isFirst?: boolean;
}

// 客服中心数据对象
interface ImServiceDataMap {
  [serviceSn: string]: ImServiceInfo;
}

interface ImInfo {
  // sdk是否初始化加载完毕
  imSdkIsReady: boolean;
  // im信息初始化
  imInfoIsReady: boolean;
  // IM是否在线
  isImOnline: boolean;
  // 当前选中客户中心sn
  currentServiceSn: string;
  // 当前选中的群组sn
  currentGroupSn: string;
  // 查看选中的群组状态
  currentGroupState: string;
  // 客服中心数据对象
  serviceDataMap: ImServiceDataMap;
  // 群组列表
  groupList: { [serviceSn: string]: Array<ImGroupInfo> };
  // 群组的finished列表是否已加载
  groupFinishedState: { [accountSn: string]: boolean };
  // 聊天记录
  chattingRecordMap: { [groupSn: string]: Array<ImChattingRecord> };
  // 群组成员
  groupMemberMap: { [groupSn: string]: { [accountSn: string]: ImUserInfo } };
  // 当前客服用户信息
  userInfo: ImUserInfo;
  // 腾讯的群组sn跟对话框sn的映射
  groupMappingDialog: { [groupSn: string]: string };
  // 是否展示通知
  isNotification: boolean;
  // // 是否需要已读
  // isNeedRead: boolean;
  // im的群组列表
  imGroupMap: { [groupSn: string]: ImGroupInfo };
}

// 客户信息
interface CustomerInfo {
  clientTime: number;
  ip: string;
  location: string;
  ua: string;
  os: string;
}

interface CommonOssCommonListSeqs {
  [s: string]: {
    bucketName: string;
    id: number;
    seq: string;
    url: string;
    name: string;
    objectName: string;
    remark: string;
    storeType: string;
  };
}
