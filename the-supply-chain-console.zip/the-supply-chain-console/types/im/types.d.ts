//#region 基础消息

// 文本消息
interface SendTextMessage {
  messageBody: {
    // 消息内容
    Text: string;
  };
  messageType: TIM.TYPES.MSG_TEXT;
}

// @文本消息
interface SendAtTextMessage {
  messageBody: {
    // 消息内容
    Text: string;
  };
  messageType: TIM.TYPES.MSG_TEXT;
  atAccounts: Array<{
    atAllFlag: number;
    atAccount: string;
  }>;
}

/*
 * 自定义消息的类型
 * ORDER 订单
 * SHOP 商品类型
 * FINISH 会话结束
 * SWITCH 会话切换
 * READ 通知已读
 * */
type SendCustomMessageDesc = 'ORDER' | 'SHOP' | 'FINISH' | 'SWITCH' | 'READ';

// 自定义消息
interface SendCustomMessage {
  messageBody: {
    // 自定义消息数据
    Data: string;
    // 自定义消息描述信息;订单/会话结束
    Desc: SendCustomMessageDesc;
  };
  messageType: TIM.TYPES.MSG_CUSTOM;
}

// 图像消息
interface SendImageMessage {
  messageBody: {
    // 图片序列号
    UUID: string;
    // 图片格式; JPG = 1,GIF = 2,PNG = 3,BMP = 4,其他 = 255.
    ImageFormat: 1 | 2 | 3 | 4 | 255;
    // 原图,缩略图,大图下载信息
    ImageInfoArray: Array<{
      // 图片类型;1-原图，2-大图，3-缩略图
      Type: 1 | 2 | 3;
      // 图片数据大小
      Size: number;
      // 图片宽度
      Width: number;
      // 图片高度
      Height: number;
      // 图片下载地址;ossId
      URL: string;
    }>;
  };
  messageType: TIM.TYPES.MSG_IMAGE;
}

// 文件消息
interface SendFileMessage {
  messageBody: {
    // 文件ossId
    Url: string;
    // 文件数据大小
    FileSize: number;
    // 文件名称
    FileName: string;
  };
  messageType: TIM.TYPES.MSG_FILE;
}

interface SendVideoMessage {
  messageBody: {
    // 文件ossId
    VideoUrl: string;
    // 文件数据大小
    VideoSize: number;
    // 文件名称
    VideoSecond: number;

    ThumbUrl: string;
  };
  messageType: TIM.TYPES.MSG_VIDEO;
}

// 发送的信息
type ImSendMessage =
  | SendTextMessage
  | SendAtTextMessage
  | SendCustomMessage
  | SendImageMessage
  | SendFileMessage
  | SendVideoMessage;

// 发送消息的结果
interface SendResultData {
  // 是否成功
  success: boolean;
  // 提示文字
  hint: string;
}

// 创建消息的响应
interface CreateMessageResultSuccess {
  // 成功
  success: true;
  // 具体消息内容
  data: ImSendMessage;
}

interface CreateMessageResultFail {
  // 失败
  success: false;
  // 具体消息内容
  data: string;
}

type CreateMessageResult = CreateMessageResultSuccess | CreateMessageResultFail;

//#endregion

//#region 服务端的消息
// 服务端聊天-基本
interface ServiceRecordBasic {
  sn: string;
  // 发送者账户sn
  from: string;
  messageKey: string;
  // 信息状态
  status: string;
  withdraw: number;
  withdrawExpiredAt: number;
  revoked: boolean; // 撤回
  peerRead: boolean; // 已读
  createdAt: number; // 创建时间
}

// 服务端聊天记录-文本
interface ServiceRecordText extends ServiceRecordBasic, SendTextMessage {}

// 服务端聊天记录-自定义
interface ServiceRecordCustom extends ServiceRecordBasic, SendCustomMessage {}

// 服务端聊天记录-图片
interface ServiceRecordImage extends ServiceRecordBasic, SendImageMessage {}

// 服务端聊天记录-文件
interface ServiceRecordFile extends ServiceRecordBasic, SendFileMessage {}

interface ServiceRecordVideo extends ServiceRecordBasic, SendVideoMessage {}

// 服务端聊天记录
type ServiceRecordRes =
  | ServiceRecordText
  | ServiceRecordCustom
  | ServiceRecordImage
  | ServiceRecordFile
  | ServiceRecordVideo;
//#endregion

//#region 格式化之后的消息
// 格式化后-基本
interface FormatRecordBasic {
  sn: string; // 消息记录唯一ID
  // 来自谁?
  from: ImUserInfo;
  //发送者
  fromAccountSn: string;
  // 消息流向
  flow: string;
  // 状态?unSend(未发送),success(发送成功),fail(发送失败)
  status: string;
  // 是否已读
  isPeerRead: boolean;
  // 发送时间
  time: number;
  // 是否被撤回
  isRevoked: boolean;
  // 昵称
  nick: string;
  // 消息发送者的头像地址
  avatar: string;
  // 消息类型
  messageType: string;
}

// 格式化后-文本
interface FormatRecordText extends FormatRecordBasic {
  // 消息文本
  text: string;
  // 被at的成员
  atUserList: Array<string>;
}

// 格式化后-自定义
interface FormatRecordCustom extends FormatRecordBasic {
  // 自定义消息类型
  desc: SendCustomMessageDesc;
  // 消息数据
  data: string;
}

// 格式化后-图片
interface FormatRecordImage extends FormatRecordBasic {
  // 图片地址
  url: string;
}

// 格式化后-文件
interface FormatRecordFile extends FormatRecordBasic {
  // 文件地址
  fileName: string;
  // 文件地址
  fileUrl: string;
  // 文件大小
  fileSize: number;
}

// 服务端聊天记录
type FormatRecord = FormatRecordText | FormatRecordCustom | FormatRecordImage | FormatRecordFile;
//#endregion

//#region 群组和T数据的类型
// 聊天记录
interface GroupSnAndDataList<T> {
  sn: string;
  from: 'TIM' | 'SERVICE';
  lists: Array<T>;
}

// 群组成员记录
interface GroupSnAndDataMap<T> {
  sn: string;
  data: { [key: string]: T };
}

//#endregion
