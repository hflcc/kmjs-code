interface SubmitResultData {
  title: string;
  subTitle?: string;
  data?: {
    label: string;
    value: string;
  }[];
  action?: SubmitResultAction[];
}

interface SubmitResultAction {
  type: 'close' | 'bpm' | 'detail' | 'bpmPopup';
  name: string;
  businessSn?: string;
  formDefSn?: string;
  bpmDefSn?: string;
  bpmType?: string;
}
