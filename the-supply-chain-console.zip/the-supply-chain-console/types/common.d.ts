// 分页数据
interface Paging<T> {
  // 总页数
  totalPages: number;
  // 是否最后一页
  last: boolean;
  // 是否为空
  empty: boolean;
  // 列表数组
  content: Array<T>;
  // 总条数
  totalElements: number;
}

// 分页模块
interface PagingQuery {
  // 页数
  page: number;
  // 尺寸
  size: number;
}
