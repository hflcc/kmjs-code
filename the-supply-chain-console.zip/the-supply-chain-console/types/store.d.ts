interface UserMsg {
  // 用户id
  userId: number;
  sn: string;
  // 用户名
  name: string;
  // 状态
  state: string;
  // 签名
  signature: string;
  // 身份证类型
  idCard: string;
  // 手机号
  phoneNum: string;
  // 头像url
  headImgUrl: string;
  // 身份证件号码
  idCardNum: string;
  // 出生日期
  birthday: number;
  email: string;
  // 账号完整性
  account: boolean;
  // 密码完整性
  password: boolean;
  // 微信绑定状态
  wx: boolean;
}

interface TabMenuItem {
  // 路由标题
  title: string;
  // 路由名称
  name: string;
  // 路由地址
  path: string;
  // 被缓存的组件名称
  keepName: string;
  // 搜索入参数
  query: Record<string, any>;
  // 参数
  params: Record<string, any>;
  // 全部数据
  fullPath: string;
  beforeClose?: (next: (flag: boolean) => void) => void;
  type: '' | 'create' | 'detail' | 'edit';
  isNewTap: boolean;
}

interface MenuInfo {
  // 菜单是不是只显示为ICON
  iconMenu: boolean;
  // 需要被keep-alive缓存的页面组件
  keepAlive: string[];
  // 当前被激活的tabs菜单项
  activeRoute: string;
  // 被加入tabs中的菜单项
  tabMenus: TabMenuItem[];
}

interface UserInfo {
  // 显示设置密码弹窗， 只在用户没有设置密码时弹出
  showSetPwd: boolean;
  // 用户菜单
  menus: RouteRecordRaw[];
  // 用户名
  userName: string;
  // 用户信息
  userMsg: UserMsg | null;
  // 权限字符串
  permissions: string[];
  // 机构数据
  insts: InstItem[];
}

interface AreaItem {
  sn: string;
  name: string;
  item: AreaItem[];
}

interface DictionariesStore {
  dictionaries: { [l: string]: any };
  businessData: Record<string, Record<string, any>[]>;
}

interface SourceStore {
  ossUrl: CommonOssCommonListSeqs;
  addressData: AreaItem[] | null;
}

interface CommonOssCommonListSeqs {
  [s: string]: {
    bucketName: string;
    id: number;
    seq: string;
    url: string;
    name: string;
    objectName: string;
    remark: string;
    storeType: string;
  };
}

interface InstItemRoles {
  id: number;
  name: string;
  sn: string;
  sort: number;
}

// 机构数据
interface InstItem {
  localId: string;
  id: number;
  sn: string;
  name: string;
  simpleName: string;
  roleId: number;
  operation: boolean;
  roles: InstItemRoles[];
}

// 渠道数据
interface ChannelItem {
  instName: string;
  instSn: string;
  name: string;
  sn: string;
  type: string;
}

interface OrganizationItem {
  id?: string;
  sn: string;
  name: string;
}

interface OrganizationStore {
  // 机构
  organ: InstItem[];
  activeOrganSn: string;
  activeOrgan: InstItem | null;
  // 渠道
  showChannel: boolean;
  channel: ChannelItem[];
  filterChannel: ChannelItem[];
  activeChannelSn: string;
  activeChannel: ChannelItem | null;
  // 组织
  organization: OrganizationItem[];
  activeOrganizationSn: string;
  activeOrganization: OrganizationItem | null;
  status: string;
  organRoles: InstItemRoles[];
  // 记录菜单对应选中的渠道和组织SN
  menuActiveSn: Record<string, [string, string]>;
}

interface DictionariesItem {
  sn: string;
  type: string;
  code: string;
  name: string;
  value?: any;
  sort: number;
}

interface SystemStore {
  navMenu: string;
  asideMenu: string;
  sysName: string;
  sysLogo: string;
  loginBanner: string[];
  theme: string;
  loginDescr: string;
}

// 列表页和详情页数据交互
interface ListToDetailStore {
  data: {
    [key: string]: any;
  };
}

// 列表页和详情页数据交互
interface GoodsStore {
  specs: SpecsStore[];
  tiered: StepPricesStore[];
  isSpecsIndex: number;
}

interface SpecsStore {
  // 规格索引，请求方自行维护，不可重复，用于识别规格与SKU的关联关系，建议每新增一个规格自增一次即可
  index: number;
  // 规格名
  name: string;
  // 选择的数据
  select?: [];
  // 规格值
  children?: SpecsChilden[];
}
interface SpecsChilden {
  index: number;
  // 规格名
  name: string;
  // sn
  sn?: string;
  // 是否删除
  isDelete?: boolean;
  // 规格值
  children?: SpecsChilden[];
}
interface StepPricesStore {
  // 起始量
  min: string;
  // 结束量
  max: string;
  sn?: string;
}
interface StepList {
  name: string;
  model: string;
  retailPrice: string;
  price: string;
  weight: string;
  volume: string;
  icon: string;
  stepPrices: StepPricesList[];
  specIndexes: string;
}
interface StepPricesList {
  // 起始量
  min: string;
  // 结束量
  max: string;
  // 售价（元）
  price?: string;
  sn?: string;
}

interface RootState {
  im: ImInfo;
  user: UserInfo;
  menu: MenuInfo;
  dictionaries: DictionariesStore;
  organization: OrganizationStore;
  systemInfo: SystemStore;
  listToDetail: ListToDetailStore;
  source: SourceStore;
  goods: GoodsStore;
}
