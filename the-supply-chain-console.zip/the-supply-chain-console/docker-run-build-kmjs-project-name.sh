#!/bin/bash
docker rm -f `docker ps -a | grep -w kmjs-the-supply-chain-console | awk '{print $1}'`;
docker rmi --force `docker images | grep -w 172.18.88.211:7080/library/kmjs-the-supply-chain-console | awk '{print $3}'`;
docker build -t 172.18.88.211:7080/library/kmjs-the-supply-chain-console:latest .
docker login --username=admin --password=kmjs@2020 172.18.88.211:7080
docker push 172.18.88.211:7080/library/kmjs-the-supply-chain-console:latest
