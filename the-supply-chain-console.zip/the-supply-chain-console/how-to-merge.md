git remote -v
git remote add upstream ssh://git@172.18.88.211:8022/xhs/kmjs-admin-base.git
git fetch upstream
git merge upstream/master --allow-unrelated-histories
git push 

