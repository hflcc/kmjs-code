# 开发须知
hahaha
> 需要本地使用docker跑一个redis 供中间件链接

## node中间件配置

> 由于用户的token，系统的AppId 和密钥，属于较为机密的数据。因此使用node中间价来进行数据的保存。所有的接口都经过中件间  
> 同时后续的部署采用docker进行部署，因此node中间件也会承担web服务器的作用读取和发送静态文件

* 文件夹 `/service/src/utils/env.js` 环境的配置文件中，这里需要修改
  * clientId 每个系统对于的ID
  * clientSecret 每个系统对于的密钥

## 部署修改

将以下三个文件

docker-run-build-kmjs-<span style="color: red">project-name</span>.sh  
docker-run-prod-kmjs-<span style="color: red">project-name</span>.sh  
docker-run-test-kmjs-<span style="color: red">project-name</span>.sh

中标红的文字修改成项目名称

## 菜单配置

本地模式可以打开 文件`/src/router/permission.ts` 中113行代码让本地菜单都生效


# 编码规范

## 注释

```javascript

/**
 * 函数干啥的
 * @param 参数名 这个参数干啥的
 * @return 返回的东西是啥
 * */

```

## css

* 不使用`scoped`, 在组件的根元素上的css名来约束
* 格式为 `name-name2` 不使用驼峰

## 使用composition-API

bad:

```javascript
defineComponent({
  setup() {
    const pageNo = ref(0);
    const pageSize = ref(10);
    const tableData = ref('xxx');


    const changePage = () => {
      pageNo.value++
      pageSize.value++
    }

    const getTableData = () => {
      tableData.value = 'dsdvsv'
    }

    const search = () => {
      searchData.value = 'dsdvsv'
    }
    return {
      ...
    }
  }
})

```

good:

```javascript
const useSearch = () => {
  const searchData = ref('sss');
  const search = () => {
    searchData.value = 'dsdvsv'
  }
  return {
    searchData,
    search
  }
}

const usePage = () => {
  const pageNo = ref(0);
  const pageSize = ref(10);
  const changePage = () => {
    pageNo.value++
    pageSize.value++
  }
  return {
    pageNo,
    pageSize,
    changePage
  }
}

const useTable = () => {
  const tableData = ref('xxx');
  const getTableData = () => {
    tableData.value = 'dsdvsv'
  }
  return {
    tableData,
    getTableData
  }
}

defineComponent({
  setup() {
    const {
      searchData,
      search
    } = useSearch()
    const {
      pageNo,
      pageSize,
      changePage
    } = usePage()
    const {
      tableData,
      getTableData
    } = useTable()

    return {
      searchData,
      search,
      pageNo,
      pageSize,
      changePage,
      tableData,
      getTableData
    }
  }
})
```

# 代码更新远程架子的代码步骤

1. 新增 upstream 远端 `git remote add upstream ssh://git@172.18.88.211:8022/xhs/kmjs-admin-base.git`
2. 获取远程的数据 `git fetch update upstream`
3. 后续直接从远程进行合并即可
