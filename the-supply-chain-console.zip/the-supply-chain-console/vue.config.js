const path = require('path');
module.exports = {
  // publicPath
  publicPath: '/',

  // 输入目录
  outputDir: 'dist',

  // 放置生成的静态资源
  assetsDir: 'static',

  // 指定生成的 index.html 的输出路径,相对于outputDir
  indexPath: 'index.html',

  // 输出资源是否打入hash,控制缓存
  filenameHashing: true,

  // 是否保存自动运行 eslint --fix
  lintOnSave: false,

  // 使用的vue是否带 compiler 版本
  runtimeCompiler: false,

  // 编译node_modules包的时候使用
  transpileDependencies: [],

  // 生产环境是否打出sourceMap
  productionSourceMap: false,

  // 如果这个值是一个对象,则会通过 webpack-merge 合并到最终的配置中;
  // 如果这个值是一个函数,则会接收被解析的配置作为参数;并返回配置
  // configureWebpack: () => {},
  // 链式调用操作webpack配置
  chainWebpack: (config) => {
    config.resolve.alias.set('types', './types');
    if (process.env.buildBundle) {
      config
        .plugin('webpack-bundle-analyzer')
        .use(require('webpack-bundle-analyzer').BundleAnalyzerPlugin);
    }
    config.optimization.minimizer('terser').tap((args) => {
      args[0].terserOptions.compress.drop_console = true;
      return args;
    });
    // config.resolve.alias.set('@', './src')
  },

  // 样式相关
  css: {
    // css是否抽离,默认生产是抽离,开发不抽离.
    extract: true,
    // 是否构建css的sourceMap
    sourceMap: false,
    // 像CSSloader传递选项
    loaderOptions: {
      css: {},
      less: {}
    }
  },

  // 所有 webpack-dev-server 的选项
  devServer: {
    // 端口
    port: 8888,
    // 主机服务器
    host: '0.0.0.0',
    // 代理
    proxy: {
      '^/mock': {
        target: 'http://localhost:8889/',
        pathRewrite: {
          '^/mock': ''
        },
        changeOrigin: true
      },
      '^/test': {
        target: 'http://localhost:16001',
        pathRewrite: {
          '^/test': ''
        },
        changeOrigin: true
      },
      '^/pokemon': {
        target: 'http://172.16.31.222:8085/pokemon',
        pathRewrite: {
          '^/pokemon': ''
        },
        changeOrigin: true
      }
    }
  },

  // 是否多核构建
  parallel: true,

  pluginOptions: {
    'style-resources-loader': {
      preProcessor: 'less',
      patterns: [path.resolve(__dirname, './src/style/variableLess/*.less')]
    }
  }
};
