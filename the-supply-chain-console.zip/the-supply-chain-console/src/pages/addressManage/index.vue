<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delAddressBySn, delBatchAddressBySn } from '@/pages/addressManage/api';
  import { getAreaMessage } from '@/components/form/items/areaChoose/api';

  interface Methods {
    [propName: string]: () => void;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    address: string;
    areaSn: string;
    contactName: string;
    contactPhone: string;
    createName: string;
    createdAt: string;
    sn: string;
    type: string;
    [propName: string]: unknown;
  }

  export default defineComponent({
    name: 'addressManageIndex',
    components: {
      kmjsModule
    },
    setup() {
      const [moduleCtl, methods] = useModule({
        /*config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '地址管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增地址',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '70a3c22df30d4aa9a1d8574c94e40811'
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/address/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '联系人',
                          key: 'contactName'
                        },
                        {
                          label: '手机号',
                          key: 'contactPhone'
                        },
                        {
                          label: '所在地区',
                          key: 'areaSn',
                          type: 'area',
                          hideAuto: true
                        },
                        {
                          label: '详细地址',
                          key: 'address'
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        },
                        {
                          label: '类型',
                          key: 'type',
                          type: 'select',
                          options: [
                            {
                              label: '发货地址',
                              value: 'send'
                            },
                            {
                              label: '售后地址',
                              value: 'saled'
                            }
                          ]
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '联系人',
                          key: 'contactName'
                        },
                        {
                          label: '手机号',
                          key: 'contactPhone'
                        },
                        {
                          label: '所在地区',
                          type: 'area',
                          key: 'areaSn'
                        },
                        {
                          label: '详细地址',
                          key: 'address',
                          width: 300
                        },
                        {
                          label: '类型',
                          key: 'type',
                          type: 'mapText',
                          params: {
                            type: 'local',
                            localData: {
                              send: '发货地址',
                              saled: '售后地址'
                            }
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'remark',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'addressEdit',
                              params: {
                                // defSn: '3a46a69a280011eca2b50c42a1da1656',
                                defSn: '6f7bb9c4c25e4aba9a54b2c26ce47a13',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'addressDetail',
                              params: {
                                defSn: 'ff53f0166ab249229c1deafae5c51a12',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'addressDelete',
                              show: 'always'
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          type: 'danger',
                          emit: 'addressBatchDelete'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],*/
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          handlers[name] && handlers[name](data, methods);
        }
      });

      const handlers: Handlers = {
        // 删除地址
        tableAddressDelete: async (list) => {
          const { row } = list[0] || {};
          const address = await _getDetailAddress(row.areaSn, row.address);
          const message = `确定要删除 【${address}】 地址吗？`;
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delAddressBySn(row.sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        },
        tableAddressBatchDelete: async (list) => {
          const selectedData: TableRow[] = list[0] || [];
          if (!selectedData.length) {
            ElMessage.error('请选择需要批量删除的地址');
            return;
          }
          const addressSns = selectedData.map((item) => item.sn);
          const message = '确定要删除已选中地址吗？';
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delBatchAddressBySn(addressSns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };

      function _getDetailAddress(areaSn: string, address: string) {
        return new Promise((resolve) => {
          getAreaMessage(areaSn).then((res) => {
            resolve(
              `${res.province?.name || ''}${res.city?.name || ''}${res.area?.name || ''}${address}`
            );
          });
        });
      }

      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less"></style>
