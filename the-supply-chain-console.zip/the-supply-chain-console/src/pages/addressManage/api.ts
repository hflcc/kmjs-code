import ajax from '@/utils/axios';

interface AddressRes {
  sn: string;
  contactName: string;
  contactPhone: string;
  areaSn: string;
  address: string;
  type: string;
  createdAt: number;
  createName: string;
}

/**
 * 地址列表
 * @param type send-发货地址，saled-售后地址
 * @returns {Promise<Paging<AddressRes>>} 地址列表
 */
export function getAddressList(type: string): Promise<Paging<AddressRes>> {
  return ajax.get<{ type: string }, Paging<AddressRes>>('/auth/md/address/page', {
    params: {
      $InstId: true,
      type
    }
  });
}

/**
 * 删除地址
 */
export function delAddressBySn(addressSn: string): Promise<{ success: boolean }> {
  return ajax.delete<{ addressSn: string }, { success: boolean }>(`/auth/md/address/${addressSn}`, {
    params: {
      $InstId: true,
      addressSn
    }
  });
}
/**
 * 批量删除地址
 */
export function delBatchAddressBySn(addressSns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ addressSns: string[] }, { success: boolean }>(
    `/auth/md/address/sns?addressSns=${addressSns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
}
