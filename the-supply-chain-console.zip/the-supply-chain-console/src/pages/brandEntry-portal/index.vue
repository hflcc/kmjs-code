<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delData } from '@/pages/brandEntry-portal/api';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sn: string;
    brandEnterNo: string;
    brandNames: string[];
    bizMdPlatformInstName: string;
    bizMdSupplierName: string;
    bizMdContractName: string;
    enterType: string;
    paymentType: string;
    auditState: string;
    reason: string;
    payState: string;
    payableAmount: number;
    payExpirationTime: number;
    createdAt: number;
    createdName: string;
    remark: string;
    [propName: string]: unknown;
  }
  export default defineComponent({
    name: 'brandEntryPortal',
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        // 批量删除
        tableDeleteData: async (arr, methods) => {
          let [list] = arr;
          if (list instanceof Array) {
            if (!list.length) {
              ElMessage.error('请选择需要删除的数据');
              return;
            }
          } else {
            list = [list.row ? list.row : {}];
          }
          // 判断是否可以删除
          const isDelete =
            list.filter(
              (item: { auditState: string }) =>
                item.auditState !== 'none' && item.auditState !== 'reject'
            ).length === 0;
          if (!isDelete) {
            ElMessage.error('选中的数据中含有不可删除的数据');
            return;
          }
          // 获取选中数据的单号
          const codes = list.map((item: { brandEnterNo: string }) => item.brandEnterNo).join('、');
          ElMessageBox.confirm(`确认删除品牌入驻单【${codes}】吗？`)
            .then(async () => {
              const sns = list.map((item: TableRow) => item.sn).join(',');
              const res = await delData(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '品牌入驻-门户',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '45610ad53bcb4b21ad3a671421dfef24'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/brand/enter/page/portal',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '单号',
                          key: 'brandEnterNo',
                          type: 'text'
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          type: 'select',
                          dictionaryName: 'brand_pay_state'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'select',
                          dictionaryName: 'brand_audit_state'
                        },
                        // {
                        //   label: '销售方式',
                        //   key: 'enterType',
                        //   type: 'select',
                        //   dictionaryName: 'brand_sale_type'
                        // },
                        {
                          label: '付款方式',
                          key: 'paymentType',
                          type: 'select',
                          dictionaryName: 'brand_payment_type'
                        },
                        {
                          label: '创建人',
                          key: 'createdName',
                          type: 'text'
                        },

                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdStart',
                            endKey: 'createdEnd'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '单号',
                          key: 'brandEnterNo'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandNames',
                          type: 'listView',
                          params: {
                            valueKey: 'name'
                          }
                        },
                        {
                          label: '平台',
                          key: 'bizMdPlatformInstName'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierName'
                        },
                        {
                          label: '合同',
                          key: 'bizMdContractName'
                        },
                        {
                          label: '销售方式',
                          key: 'enterType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_sale_type'
                          }
                        },
                        {
                          label: '付款方式',
                          key: 'payType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'contract_pay_type'
                          }
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_audit_state',
                            showDiaLogIcon: true
                          }
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_pay_state'
                          }
                        },
                        {
                          label: '费用金额（元）',
                          key: 'payableAmount'
                        },
                        {
                          label: '支付剩余时间',
                          key: 'payExpirationTime',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'remark',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'brandEntryPortalDetail',
                              params: {
                                defSn: '8f79bd9aaf9a44d5ac62704ff713d6ad',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'brandEntryPortalEdit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'none|reject' //满足的值
                                }
                              ],
                              params: {
                                defSn: 'd7a89246fb7e4150a8c050b59ef6020b',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'deleteData',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'none|reject' //满足的值
                                  // columnValue: 'none|pass|reject|expired|cancel' //满足的值
                                }
                              ]
                            },
                            {
                              type: 'tableBpmStatic',
                              label: '送审',
                              emit: 'submitAudit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'none|reject' //满足的值
                                }
                              ],
                              params: {
                                defSn: '6d32a9716d0e11ec8d3eb8599f52bbe4',
                                alertMsg: '确认将入驻单（{brandEnterNo}）提交至康美集势审核吗？',
                                successMsg: '【入驻单（{brandEnterNo}）】已提交至【康美集势】审核'
                              }
                            }
                            // {
                            //   label: '去支付',
                            //   emit: 'goPay',
                            //   show: 'rule',
                            //   rules: [
                            //     {
                            //       columnKey: 'showSubmitAudit', //key
                            //       columnValue: 'true' //满足的值
                            //     }
                            //   ]
                            // },
                            // {
                            //   label: '继续支付',
                            //   emit: 'goOnPay'
                            // }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          emit: 'deleteData'
                        }
                      ]
                    }
                  ]
                },
                slotParam: []
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            dataFormatter: (tableData: TableRow[]): TableRow[] => {
              if (tableData.length) {
                let mergeData = tableData.map((item) => {
                  //支付方式==预付 && 单据状态==已通过
                  if (item.paymentType == 'prepay' && item.auditState == 'pass') {
                    item.showSubmitAudit = 'true';
                  } else {
                    item.showSubmitAudit = 'false';
                  }
                  return item;
                });
                return mergeData;
              } else {
                return tableData;
              }
            }
          }
        },
        handler: (moduleName, name, data) => {
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
