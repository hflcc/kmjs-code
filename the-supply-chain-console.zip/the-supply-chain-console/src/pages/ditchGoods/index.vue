<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>
<script lang="ts">
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { defineComponent } from 'vue';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { stateOff, stateRelease, stateOffAll, stateReleaseAll } from '@/pages/ditchGoods/api';
  export default defineComponent({
    name: 'ditchGoodsIndex',
    components: {
      kmjsModule
    },
    setup() {
      // 上架，下架
      const operating = (list: any, type: number, text: string) => {
        let sn: any = [];
        if (list instanceof Array) {
          if (!list[0].length) {
            if (!list[0].row) {
              ElMessage.error(`请选择需要${text}的数据`);
              return;
            }
          }
        }
        ElMessageBox.confirm(`确认${text}吗？`)
          .then(async () => {
            if (list[0].length) {
              list[0].map((i: any) => {
                sn.push(i.sn);
              });
            } else {
              sn.push(list[0].row.sn);
            }
            // 上架
            if (type == 1) {
              await stateRelease(sn).then((res) => {
                if (res.success) {
                  ElMessage.success('上架成功');
                  methods['/title/title-table/refreshAll']();
                } else {
                  ElMessage.error('上架失败');
                }
              });
            } else {
              // 下架
              await stateOff(sn).then((res) => {
                if (res.success) {
                  ElMessage.success('下架成功');
                  methods['/title/title-table/refreshAll']();
                } else {
                  ElMessage.error('下架失败');
                }
              });
            }
          })
          .catch((err) => {
            console.log(err);
          });
      };
      const allOperating = (type: number, text: string) => {
        ElMessageBox.confirm(`确认全部${text}吗？`)
          .then(async () => {
            if (type == 1) {
              await stateReleaseAll().then((res) => {
                if (res.success) {
                  ElMessage.success('全部上架成功');
                  methods['/title/title-table/refreshAll']();
                } else {
                  ElMessage.error('全部上架失败');
                }
              });
            } else {
              await stateOffAll().then((res) => {
                if (res.success) {
                  ElMessage.success('全部下架成功');
                  methods['/title/title-table/refreshAll']();
                } else {
                  ElMessage.error('全部下架失败');
                }
              });
            }
          })
          .catch((err) => {
            console.log(err);
          });
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '渠道商品列表',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  type: 'location',
                  label: '定位',
                  emit: 'location'
                },
                {
                  label: '全部上架',
                  emit: 'allPutaway'
                },
                {
                  label: '全部下架',
                  emit: 'allSoldOut'
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/inst/goods/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '商品名称',
                          key: 'name',
                          type: 'text'
                        },
                        {
                          label: '品牌名称',
                          key: 'brand',
                          type: 'text'
                        },
                        {
                          label: '供应商',
                          key: 'supplierName',
                          type: 'text'
                        },
                        {
                          label: '渠道名称',
                          key: 'channelName',
                          type: 'text'
                        },
                        {
                          label: '创建人',
                          key: 'createNameBy',
                          type: 'text'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        },
                        {
                          label: '商品类目',
                          type: 'platformCategory',
                          key: 'categorySn',
                          hideAuto: true
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'code'
                        },
                        {
                          label: '商品状态',
                          key: 'state',
                          width: 200,
                          type: 'mapText',
                          params: {
                            type: 'local',
                            localData: {
                              release: '正常',
                              off: '已下架'
                            }
                          }
                        },
                        {
                          label: '商品名称',
                          key: 'name'
                        },
                        {
                          label: '商品类型',
                          key: 'goodsType',
                          width: 200,
                          type: 'mapText',
                          params: {
                            type: 'local',
                            localData: {
                              brand: '品牌产品',
                              oem: 'OEM产品'
                            }
                          }
                        },
                        {
                          label: '品牌名称',
                          key: 'brand'
                        },
                        {
                          label: '供应商名称',
                          key: 'bizMdSupplierName'
                        },
                        {
                          label: '渠道名称',
                          key: 'channelName'
                        },
                        {
                          label: '类目',
                          key: 'category'
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'desc',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'channelDetail',
                              params: {
                                defSn: '1436985c3d12493291ab9afbb9fe33ca',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'channelEdit',
                              params: {
                                defSn: 'd554d89b00a144a6bca0a751e4dcd157',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '上架',
                              emit: 'putaway',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'state',
                                  columnValue: 'off'
                                }
                              ]
                            },
                            {
                              label: '下架',
                              emit: 'soldOut',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'state',
                                  columnValue: 'release'
                                }
                              ]
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '批量上架',
                          emit: 'putaway'
                        },
                        {
                          label: '批量下架',
                          emit: 'soldOut'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        handler: (moduleName, name, data) => {
          switch (moduleName + '_' + name) {
            // 定位
            case '/title_orientation':
              break;
            // 全部上架
            case '/title_allPutaway':
              allOperating(1, '上架');
              break;
            // 全部下架
            case '/title_allSoldOut':
              allOperating(0, '下架');
              break;
            // 下架
            case '/title/title-table_tableSoldOut':
              operating(data, 0, '下架');
              break;
            case '/title/title-table_tablePutaway':
              operating(data, 1, '上架');
              break;
          }
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
