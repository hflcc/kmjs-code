import ajax from '@/utils/axios';

export interface BaseResp {
  success: boolean;
  message: string;
}
// 下架
export const stateOff = (sns: string[]): Promise<BaseResp> => {
  return ajax.put(`/auth/md/inst/goods/${sns}/state/off`, undefined, {
    params: {
      $InstId: true
    }
  });
};
// 上架
export const stateRelease = (sns: string[]): Promise<BaseResp> => {
  return ajax.put(`/auth/md/inst/goods/${sns}/state/release`, undefined, {
    params: {
      $InstId: true
    }
  });
};
// 全部下架
export const stateOffAll = (): Promise<BaseResp> => {
  return ajax.put('/auth/md/inst/goods/state/off/all', undefined, {
    params: {
      $InstId: true
    }
  });
};
// 全部上架
export const stateReleaseAll = (): Promise<BaseResp> => {
  return ajax.put('/auth/md/inst/goods/state/release/all', undefined, {
    params: {
      $InstId: true
    }
  });
};
