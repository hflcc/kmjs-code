import ajax from '@/utils/axios';
interface IDelSupplierData {
  message: string;
  success: boolean;
  [propName: string]: unknown;
}
interface IAssociateInstId {
  bizMdInstName: string;
  typeInstName: string;
  typeInstSn: string;
  type: string;
  state: string;
}
/*
 *当前机构绑定的平台机构列表
 */
export const associateInstId = (): Promise<IAssociateInstId[]> => {
  return ajax.get('/auth/md/inst/associate/inst_id/list', {
    params: {
      $InstId: true
    }
  });
};
/* 删除供应商列表数据 */
export const delSupplierData = (sn: string): Promise<IDelSupplierData> => {
  return ajax.put(
    `/auth/md/supplier/instance/rejectToDelete/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
