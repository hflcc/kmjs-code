<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref, nextTick } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { useRouter } from 'vue-router';
  import { associateInstId, delSupplierData } from '@/pages/supplierManage/api';
  import useOrganization from '@/store/commModules/organization/useOrganization';
  import { ElMessage, ElMessageBox } from 'element-plus';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: TableRow, methods: Methods) => void;
  }
  interface TableRow {
    sn: string;
    bizMdTypeInstSn: string;
    bizMdInstOrgTreeSn: string;
    bizMdInstOrgTreeName: string;
    bizMdTypeInstName: string;
    bizMdSupplierDefSn: string;
    type: string;
    saleType: string;
    name: string;
    serialCode: string;
    level: string;
    state: string;
    auditState: string;
    companyType: string;
    companyAreaSn: string;
    companyAddress: string;
    companyLegalName: string;
    companyLegalPhone: string;
    companyLegalEmail: string;
    companyRegisteredCapital: string;
    companyTeamSize: number;
    companyIncorporatedAt: number;
    saleAmount: string;
    industrialPark: string;
    factory: string;
    developTeam: string;
    otherIndustrialChain: string;
    serviceChannel: string;
    description: string;
    supplierInstanceQualifications: string;
    supplierInstanceBankResponses: string;
    supplierInstancePersonResponses: string;
    createdByName: string;
    createdAt: number;
    [propName: string]: unknown;
  }
  export default defineComponent({
    name: 'supplierManageIndex',
    components: {
      kmjsModule
    },
    setup() {
      const router = useRouter();
      const { activeOrganization } = useOrganization();
      const handlers: Handlers = {
        //删除
        tableDeleData: async (list, methods) => {
          const { sn } = list;
          ElMessageBox.confirm('确认删除吗？')
            .then(async () => {
              const res = await delSupplierData(sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        // config: [
        //   {
        //     type: 'wrap-module',
        //     name: 'title',
        //     params: {
        //       hideBack: true,
        //       title: '供应商管理',
        //       actions: [
        //         {
        //           type: 'refresh',
        //           emit: 'refresh'
        //         },
        //         {
        //           type: 'location',
        //           label: '定位',
        //           emit: 'location'
        //         },
        //         // {
        //         //   type: 'createForm',
        //         //   label: '供应商入驻',
        //         //   emit: 'supplierJoin',
        //         //   params: {
        //         //     defSn: '5dd2689d200e11eca2b50c42a1da1656'
        //         //   }
        //         // },
        //         {
        //           label: '新增',
        //           type: 'createBpm',
        //           emit: 'supplierJoin',
        //           params: {
        //             bpmType: 'supplier_apply'
        //           }
        //         }
        //       ]
        //     },
        //     permissions: [],
        //     children: [
        //       {
        //         type: 'table',
        //         name: 'title-table',
        //         permissions: [],
        //         params: {
        //           tableDataUrl: '/auth/md/supplier/instance/page',
        //           items: [
        //             {
        //               type: 'search',
        //               inputs: [
        //                 {
        //                   label: '编号',
        //                   key: 'serialCode',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '供应商名称',
        //                   key: 'name',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '审核状态',
        //                   key: 'auditState',
        //                   type: 'select',
        //                   dictionaryName: 'supplier_audit_state'
        //                 },
        //                 {
        //                   label: '状态',
        //                   key: 'state',
        //                   type: 'select',
        //                   dictionaryName: 'supplier_state'
        //                 },
        //                 {
        //                   label: '销售方式',
        //                   key: 'saleType',
        //                   type: 'select',
        //                   dictionaryName: 'sale_type'
        //                 },
        //                 {
        //                   label: '创建人',
        //                   key: 'createdByName',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'daterange',
        //                   type: 'daterange',
        //                   dateConfig: {
        //                     startKey: 'startAt',
        //                     endKey: 'endAt'
        //                   }
        //                 }
        //               ]
        //             },
        //             {
        //               type: 'table',
        //               tableHead: [
        //                 {
        //                   label: '编号',
        //                   key: 'serialCode'
        //                 },
        //                 {
        //                   label: '供应商名称',
        //                   key: 'name'
        //                 },
        //                 {
        //                   label: '审核状态',
        //                   key: 'auditState',
        //                   type: 'mapText',
        //                   params: {
        //                     type: 'dictionary',
        //                     dictionaryName: 'supplier_audit_state',
        //                     showDiaLogIcon: true
        //                   }
        //                 },
        //                 {
        //                   label: '状态',
        //                   key: 'state',
        //                   type: 'mapText',
        //                   width: 100,
        //                   params: {
        //                     type: 'dictionary',
        //                     dictionaryName: 'supplier_state'
        //                   }
        //                 },
        //                 {
        //                   label: '销售方式',
        //                   key: 'saleType',
        //                   type: 'mapText',
        //                   width: 100,
        //                   params: {
        //                     type: 'dictionary',
        //                     dictionaryName: 'sale_type'
        //                   }
        //                 },
        //                 {
        //                   label: '供应商类型',
        //                   key: 'type',
        //                   type: 'mapText',
        //                   width: 100,
        //                   params: {
        //                     type: 'dictionary',
        //                     dictionaryName: 'supplier_type'
        //                   }
        //                 },
        //                 {
        //                   label: '公司名称',
        //                   key: 'companyName',
        //                   width: 100
        //                 },
        //                 {
        //                   label: '级别',
        //                   key: 'level',
        //                   width: 80
        //                 },
        //                 {
        //                   label: '法定代表人/负责人',
        //                   key: 'companyLegalName'
        //                 },
        //                 {
        //                   label: '法人联系电话',
        //                   key: 'companyLegalPhone'
        //                 },
        //                 {
        //                   label: '营业期限',
        //                   key: 'companyExpiredType',
        //                   type: 'expiredDate',
        //                   width: 200,
        //                   params: {
        //                     startKey: 'companyExpiredStartAt',
        //                     endKey: 'companyExpiredEndAt'
        //                   }
        //                 },
        //                 {
        //                   label: '平台',
        //                   key: 'bizMdTypeInstName',
        //                   width: 100
        //                 },
        //                 {
        //                   label: '创建人',
        //                   key: 'createdByName'
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'createdAt',
        //                   formatter: 'dateTime',
        //                   width: 180,
        //                   params: {
        //                     dataTimeType: 'YYYY-MM-DD HH:mm:ss'
        //                   }
        //                 },
        //                 {
        //                   label: '备注',
        //                   key: 'description',
        //                   width: 300
        //                 },
        //                 {
        //                   type: 'handle',
        //                   label: '操作',
        //                   actions: [
        //                     {
        //                       type: 'tableBpm',
        //                       label: '编辑',
        //                       emit: 'supplierEdit',
        //                       show: 'rule',
        //                       params: {
        //                         defSn: '62fa3ae4485211eca2b50c42a1da1656',
        //                         beforeCallCheck: [
        //                           {
        //                             type: 'bpm',
        //                             queryKey: 'sn',
        //                             defSn: '62fa3ae4485211eca2b50c42a1da1656'
        //                           }
        //                         ]
        //                       },
        //                       rules: [
        //                         {
        //                           columnKey: 'switchEdit',
        //                           columnValue: 'accept'
        //                         }
        //                       ]
        //                     },
        //                     {
        //                       type: 'tableBpm',
        //                       label: '编辑',
        //                       emit: 'supplierEdit',
        //                       params: {
        //                         defSn: 'f59028fa484711eca2b50c42a1da1656',
        //                         beforeCallCheck: [
        //                           {
        //                             type: 'bpm',
        //                             queryKey: 'sn',
        //                             defSn: 'f59028fa484711eca2b50c42a1da1656'
        //                           }
        //                         ]
        //                       },
        //                       show: 'rule',
        //                       rules: [
        //                         {
        //                           columnKey: 'switchEdit',
        //                           columnValue: 'reject|wait'
        //                         }
        //                       ]
        //                     },
        //                     {
        //                       type: 'tableDetail',
        //                       label: '详情',
        //                       emit: 'supplierDetail',
        //                       params: {
        //                         defSn: '7c3eee30c5924bdea983ae484839dacd',
        //                         dataSnKey: 'sn'
        //                       }
        //                     },
        //                     {
        //                       label: '删除',
        //                       emit: 'deleData',
        //                       show: 'rule',
        //                       rules: [
        //                         {
        //                           columnKey: 'auditState',
        //                           columnValue: 'reject'
        //                         }
        //                       ]
        //                     }
        //                   ]
        //                 }
        //               ]
        //             }
        //           ]
        //         },
        //         slotParam: []
        //       }
        //     ]
        //   }
        // ],
        params: {
          '/title/title-table': {
            beforeRequest: (obj: { url: string }) => {
              obj.url = `${obj.url}?orgTreeSn=${activeOrganization.value?.sn}`;
              return Promise.resolve(activeOrganization.value?.sn ? obj : null);
            },
            dataFormatter: (tableData: TableRow[]): TableRow[] => {
              if (tableData.length) {
                let newData = tableData.map((item) => {
                  // 状态==已禁用（stop）只显示详情按钮
                  /* item.switchEdit
                   *none 不显示
                   *accept 已通过
                   *reject 已驳回
                   *wait 待审核
                   */
                  if (item.state == 'stop') {
                    item.switchEdit = 'none';
                  } else {
                    item.switchEdit = item.auditState;
                  }
                  return item;
                });
                return newData;
              } else {
                return tableData;
              }
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          const { row = {} } = data[0] || {};
          const obj = row as TableRow;
          handlers[name] && handlers[name](obj, methods);
          if (name === '$ready') {
            associateInstId().then((res) => {
              if (!res) return;
              let params = res.map((item) => {
                return {
                  label: item.typeInstName,
                  value: item.typeInstSn
                };
              });
              methods['/title/title-table/setSearchOptions']('bizMdTypeInstSn', params);
            });
          }
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less"></style>
