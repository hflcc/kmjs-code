//#region 合同管理
// /
import ajax from '@/utils/axios';

export const getContractList = (): Promise<undefined> => {
  return ajax.get<null, undefined>('/auth/md/contract/instance/page', {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

// 合同实例-状态 正常-》中止
export const normalToPassOff = (sn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/md/contract/instance/state/normalToPassOff/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 合同实例-状态 中止》正常
export const passOffToNormal = (sn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/md/contract/instance/state/passOffToNormal/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 合同实例-状态 正常》解约
export const normalToStop = (sn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/md/contract/instance/state/normalToStop/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
//#endregion
