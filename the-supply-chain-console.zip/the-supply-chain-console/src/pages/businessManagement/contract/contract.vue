<template>
  <div class="page contract-page">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { normalToPassOff, normalToStop, passOffToNormal } from './api';

  export default defineComponent({
    name: 'contract',
    components: {
      kmjsModule
    },
    setup() {
      console.log('contract setup');
      const [moduleCtl, methods] = useModule({
        // config: require('./contract').default, // config详情
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          switch (moduleName + '_' + name) {
            // 删除
            case '/title/title-table_tableNormalToPassOff':
              ElMessageBox.confirm('确定要中止合同吗？', '提示').then((res) => {
                if (res) {
                  normalToPassOff(data[0].row.sn).then((r) => {
                    if (r.success) {
                      ElMessage.success('中止成功');
                      methods['/title/title-table/refresh']();
                    }
                  });
                }
                //
              });
              break;
            case '/title/title-table_tablePassOffToNormal':
              ElMessageBox.confirm('确定要恢复合同吗？', '提示').then((res) => {
                if (res) {
                  passOffToNormal(data[0].row.sn).then((r) => {
                    if (r.success) {
                      ElMessage.success('恢复成功');
                      methods['/title/title-table/refresh']();
                    }
                  });
                }
                //
              });
              break;
            case '/title/title-table_tableNormalToStop':
              ElMessageBox.confirm('确定要解约合同吗？', '提示').then((res) => {
                if (res) {
                  normalToStop(data[0].row.sn).then((r) => {
                    if (r.success) {
                      ElMessage.success('解约成功');
                      methods['/title/title-table/refresh']();
                    }
                  });
                }
                //
              });
              break;
          }
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less">
  .contract-page .el-table td div {
    white-space: pre-line;
  }
</style>
