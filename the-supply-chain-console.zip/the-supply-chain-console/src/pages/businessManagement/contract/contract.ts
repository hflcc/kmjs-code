import { ModuleItem } from '@/components/utils/commonType';

// 四大系统
const sysDic = {
  op: Symbol('平台'), // 平台
  scm: Symbol('供应商'), // 供应商
  ag: Symbol('代理商'), // 代理商
  ma: Symbol('总代理') // 总代理
};
// 定义是哪个系统的
const sys = sysDic.op;

const config: ModuleItem[] = [
  {
    type: 'wrap-module',
    name: 'title',
    params: {},
    children: [
      {
        type: 'table',
        name: 'title-table',
        params: {
          tableDataUrl: '/auth/md/contract/instance/page',
          items: [
            {
              type: 'search',
              inputs: [
                {
                  label: '合同编号',
                  key: 'serialCode',
                  type: 'text'
                },
                {
                  label: '合同名称',
                  key: 'name',
                  type: 'text'
                },
                {
                  label: '审核状态',
                  key: 'auditState',
                  type: 'select',
                  options: [
                    {
                      label: '全部',
                      value: ''
                    },
                    {
                      label: '待审核',
                      value: 'wait'
                    },
                    {
                      label: '审核中',
                      value: 'in_progress'
                    },
                    {
                      label: '已通过',
                      value: 'accept'
                    },
                    {
                      label: '已驳回',
                      value: 'reject'
                    }
                  ]
                },
                {
                  label: '合同状态',
                  key: 'state',
                  type: 'select',
                  options: [
                    {
                      label: '全部',
                      value: ''
                    },
                    {
                      label: '待生效',
                      value: 'executor'
                    },
                    {
                      label: '签订中',
                      value: 'in_progress'
                    },
                    {
                      label: '正常',
                      value: 'normal'
                    },
                    {
                      label: '已过期',
                      value: 'expired'
                    },
                    {
                      label: '已解约',
                      value: 'stop'
                    },
                    {
                      label: '已中止',
                      value: 'pass_off'
                    }
                  ]
                },
                {
                  label: '参与方',
                  key: 'partnerName',
                  type: 'text'
                },
                {
                  label: '合同类型',
                  key: 'type',
                  type: 'select',
                  options: [
                    {
                      label: '全部',
                      value: ''
                    },
                    {
                      label: '供应商',
                      value: 'supplier'
                    },
                    {
                      label: '代理商',
                      value: 'agent'
                    },
                    {
                      label: '总代理',
                      value: 'general_agent'
                    },
                    {
                      label: '门店',
                      value: 'shop'
                    },
                    {
                      label: '平台',
                      value: 'platform'
                    }
                  ]
                },
                {
                  label: '创建人',
                  key: 'createdByName'
                },
                {
                  label: '创建时间',
                  key: 'daterange',
                  type: 'daterange',
                  dateConfig: {
                    startKey: 'startAt',
                    endKey: 'endAt'
                  }
                }
              ]
            },
            {
              type: 'table',
              tableHead: [
                {
                  label: '合同编号',
                  key: 'serialCode',
                  width: 150
                },
                {
                  label: '合同名称',
                  key: 'name',
                  width: 150
                },
                {
                  label: '审核状态',
                  key: 'auditState',
                  type: 'mapText',
                  params: {
                    type: 'local',
                    localData: {
                      wait: '待审核',
                      in_progress: '审核中',
                      accept: '已通过',
                      reject: '已驳回'
                    },
                    showDiaLogIcon: true
                  }
                },
                {
                  label: '合同状态',
                  key: 'state',
                  type: 'mapText',
                  params: {
                    type: 'local',
                    localData: {
                      in_progress: '签订中',
                      executor: '待生效',
                      normal: '正常',
                      expired: '已过期',
                      stop: '已解约',
                      pass_off: '已中止'
                    }
                  }
                },
                {
                  label: '参与方',
                  key: 'contractPartnerNames',
                  width: 200
                },
                {
                  label: '合同类型',
                  type: 'mapText',
                  key: 'type',
                  params: {
                    type: 'local',
                    localData: {
                      supplier: '供应商',
                      agent: '代理商',
                      general_agent: '总代理',
                      shop: '门店',
                      platform: '平台'
                    }
                  }
                },

                {
                  label: '平台',
                  key: 'bizMdTypeInstName'
                },
                {
                  label: '时间',
                  key: 'startAt',
                  type: 'expiredDate',
                  width: 200,
                  params: {
                    startKey: 'startAt',
                    endKey: 'endAt'
                  }
                },
                {
                  label: '创建人',
                  key: 'createdByName'
                },
                {
                  type: 'formatter',
                  label: '创建时间',
                  key: 'createdAt',
                  params: {
                    formatter: 'dateTime',
                    formatterType: 'YYYY-MM-DD HH:mm:ss'
                  }
                }
              ]
            }
          ]
        }
      }
    ]
  }
];

switch (sys) {
  case sysDic.ag:
  case sysDic.scm:
    config[0].params = {
      hideBack: true,
      title: '合同管理',
      actions: [
        {
          type: 'refresh',
          emit: 'refresh'
        }
      ]
    };
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    config[0].children[0].params.items[1].tableHead.push({
      type: 'handle',
      label: '操作',
      actions: [
        {
          type: 'tableDetail',
          label: '详情',
          emit: 'detail',
          params: {
            defSn: '4d78fe83624a459da98f451dfc0050a9',
            dataSnKey: 'sn'
          }
        }
      ]
    });
    break;
  case sysDic.op:
  case sysDic.ma:
    config[0].params = {
      hideBack: true,
      title: '合同管理',
      actions: [
        {
          type: 'refresh',
          emit: 'refresh'
        },
        {
          type: 'createBpm',
          label: '发起合同',
          emit: 'initiateContract',
          params: {
            bpmType: 'supplier_contract_apply'
          }
        }
      ]
    };
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    config[0].children[0].params.items[1].tableHead.push({
      type: 'handle',
      label: '操作',
      actions: [
        {
          type: 'tableDetail',
          label: '详情',
          emit: 'detail',
          params: {
            defSn: '4d78fe83624a459da98f451dfc0050a9',
            dataSnKey: 'sn'
          }
        },
        {
          label: '中止',
          emit: 'normalToPassOff',
          show: 'rule',
          rules: [
            {
              columnKey: 'state',
              columnValue: 'executor|normal'
            }
          ]
        },
        {
          label: '解约',
          emit: 'normalToStop',
          show: 'rule',
          rules: [
            {
              columnKey: 'state',
              columnValue: 'executor|normal'
            }
          ]
        },
        {
          label: '恢复',
          emit: 'passOffToNormal',
          show: 'rule',
          rules: [
            {
              columnKey: 'state',
              columnValue: 'pass_off'
            }
          ]
        },
        {
          label: '续约',
          emit: 'renewal',
          show: 'rule',
          type: 'tableBpm',
          ruleType: 'and',
          rules: [
            {
              columnKey: 'state',
              columnValue: 'stop|expired'
            },
            {
              columnKey: 'saleType',
              columnValue: 'set_for'
            }
          ],
          params: {
            defSn: 'd1773c5b589b11ec8d3eb8599f52bbe4',
            dataSnKey: 'sn'
          }
        },
        {
          label: '续约',
          emit: 'renewal',
          show: 'rule',
          type: 'tableBpm',
          ruleType: 'and',
          rules: [
            {
              columnKey: 'state',
              columnValue: 'stop|expired'
            },
            {
              columnKey: 'saleType',
              columnValue: 'portal'
            }
          ],
          params: {
            defSn: '988205dd641611ec8d3eb8599f52bbe4',
            dataSnKey: 'sn'
          }
        }
      ]
    });
    break;
}

// 供应商的链接 跟其它不一样
if (sys === sysDic.scm) {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  config[0].children[0].params.tableDataUrl = '/auth/md/contract/instance/page?queryCurrInst=true';
}
console.log(`<-----${sys.description}配置----->`);
console.log(JSON.stringify(config));
export default config;
