<template>
  <div class="page home-page">
    <h1>welcome {{ renderMsg.sysName }}</h1>
  </div>
</template>

<script lang="tsx">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'home',
    components: {},
    setup() {
      const store = useStore();
      const renderMsg = computed(() => store.getters['systemInfo/loginData']);
      return { renderMsg };
    }
  });
</script>

<style lang="less" scoped>
  .home-page {
    h1 {
      padding-top: 20px;
      text-align: center;
      font-weight: bolder;
    }
  }
</style>
