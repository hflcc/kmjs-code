<template>
  <div class="order-step-box">
    <el-steps :active="stateActiveIndex" align-center>
      <el-step title="创建订单">
        <template v-slot:icon>
          <div class="l-step-icon">
            <div class="ellipsis" v-if="stateActiveIndex >= 1">{{ orderDatas.buyerName }}</div>
          </div>
        </template>
        <template v-slot:description>
          <div v-if="stateActiveIndex >= 1">
            <div>{{ orderDatas.buyerName || '-' }} (发起人)</div>
            <div>{{ orderCreatedTime }}</div>
          </div>
        </template>
      </el-step>
      <el-step title="订单付款">
        <template v-slot:icon>
          <div class="l-step-icon">
            <div class="ellipsis" v-if="stateActiveIndex >= 2">{{ orderDatas.buyerName }}</div>
          </div>
        </template>
        <template v-slot:description>
          <div v-if="stateActiveIndex >= 2">
            <div>
              {{ orderDatas.buyerName || '-' }} ({{
                closeDesc && stateActiveIndex === 2 ? '订单关闭' : '付款人'
              }})
            </div>
            <div>
              {{ closeDesc && stateActiveIndex === 2 ? closeDesc.time : payTypeInfo.payTimes }}
            </div>
          </div>
        </template>
      </el-step>
      <el-step title="订单发货">
        <template v-slot:icon>
          <div class="l-step-icon">
            <div class="ellipsis" v-if="stateActiveIndex >= 3">{{ deliverInfo.sendName }}</div>
          </div>
        </template>
        <template v-slot:description>
          <div v-if="stateActiveIndex >= 3">
            <div>
              {{
                closeDesc && stateActiveIndex === 3 ? orderDatas.buyerName : deliverInfo.sendName
              }}
              ({{ closeDesc && stateActiveIndex === 3 ? '订单关闭' : '发货人' }})
            </div>
            <div>{{ closeDesc && stateActiveIndex === 3 ? closeDesc.time : orderSendTime }}</div>
          </div>
        </template>
      </el-step>
      <el-step title="订单完成">
        <template v-slot:icon>
          <div class="l-step-icon">
            <div class="ellipsis" v-if="stateActiveIndex >= 4">{{ orderDatas.buyerName }}</div>
          </div>
        </template>
        <template v-slot:description>
          <div v-if="stateActiveIndex >= 4">
            <div>{{ orderDatas.buyerName || '-' }} (确认人)</div>
            <div>{{ orderCompleteTime }}</div>
          </div>
        </template>
      </el-step>
    </el-steps>
  </div>
</template>

<script lang="ts">
  import { defineComponent, computed } from 'vue';
  import { formatterTime } from '@/utils';

  export default defineComponent({
    name: '',
    props: {
      orderState: {
        type: String,
        default: ''
      },
      orderDatas: {
        type: Object,
        default: () => ({})
      },
      orderCreatedTime: {
        type: String,
        default: ''
      },
      closeDesc: {
        type: [Object, String],
        default: ''
      },
      deliverInfo: {
        type: Object,
        default: () => ({})
      },
      payTypeInfo: {
        type: Object,
        default: () => ({})
      }
    },
    setup(props) {
      /*
       * 订单发货时间
       * */
      const orderSendTime = computed(() => {
        const t = props.orderDatas.deliverAt;
        if (!t) return '-';
        return formatterTime(new Date(t * 1000));
      });
      /*
       * 订单完成时间
       * */
      const orderCompleteTime = computed(() => {
        const t = props.orderDatas.completeAt;
        if (!t) return '-';
        return formatterTime(new Date(t * 1000));
      });
      /*
       * 流程状态高亮的下标 (饿了么组件高亮从1开始)
       * @return number 1创建订单 2订单付款 3订单发货 4订单完成
       * */
      const stateActiveIndex = computed(() => {
        const s = props.orderState;
        const closeType = props.orderDatas?.closeType;
        // 如果订单是关闭cancel状态, 且closeType有值, 就根据closeType的值来决定流程高亮的下标
        if (s === 'cancel' && closeType) {
          const closeMap = new Map([
            ['none_pay_Close', 2], // 30分钟订单未支付，关闭订单
            ['active_cancel_pay', 2], // 主动取消订单
            ['compose_full_close', 2], // 拼团满人，取消订单
            ['deliver_refund', 3], // 待发货退款关闭订单
            ['compose_instance_expired_close', 3] // 超时未成团，取消订单
          ]);
          return closeMap.get(closeType);
        }
        const step = [
          ['none', 'draft'],
          ['pay', 'deliver'],
          ['receiving'],
          ['complete', 'comment']
        ];
        return step.findIndex((item) => item.includes(s)) + 1;
      });
      return {
        orderSendTime,
        orderCompleteTime,
        stateActiveIndex
      };
    }
  });
</script>

<style lang="less">
  .order-step-box {
    @mainColor: #0063c8;
    .el-steps {
      .el-step__head {
        .el-step__line {
          height: 0;
          &:before {
            position: absolute;
            content: '';
            width: 100%;
            border-top: 1px dashed #c0c4cc;
            left: 0;
            right: 0;
          }
        }
        &.is-finish .el-step__line {
          background: @mainColor;
          &:before {
            border-top: 1px solid @mainColor;
          }
        }
      }
      .el-step__title {
        &.is-finish,
        &.is-wait {
          color: #333;
        }
        &.is-process {
          font-weight: initial;
        }
      }
      .el-step__description {
        color: #666 !important;
      }
      .ellipsis {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        white-space: pre-wrap;
        word-break: break-all;
      }
      .l-step(@bg: @mainColor) {
        background: @bg;
        color: #fff;
        position: absolute;
        height: 42px;
        width: 42px;
        font-size: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 5px;
      }
      .is-finish {
        .l-step-icon {
          .l-step();
        }
      }
      .is-process,
      .is-wait {
        .l-step-icon {
          .l-step(#ccc);
        }
      }
    }
  }
</style>
