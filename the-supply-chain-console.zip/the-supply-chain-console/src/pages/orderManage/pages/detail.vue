<template>
  <div class="order-mg-detail" style="padding-top: 20px">
    <div class="kmjs-wrap">
      <div class="back flex-b">
        <div style="cursor: pointer; font-size: 16px" @click="handleBack">
          <el-icon class="el-icon-arrow-left"></el-icon>
          <span>订单详情</span>
        </div>
        <div class="right flex-e">
          <el-button v-if="orderState === 'deliver'" type="primary" @click="goSendGoodsPage"
            >立即发货</el-button
          >
        </div>
      </div>
      <div class="main mt-15px">
        <!--        订单信息-->
        <div class="bar-module">
          <div class="bar-module--t">订单信息</div>
          <div class="bar-module--c">
            <div class="grid-box">
              <div class="grid-box--item">
                <span>订单状态: {{ orderStateName }}</span>
                <div class="ml-15px" v-if="closeDesc">
                  <el-popover placement="top" trigger="hover" width="300">
                    <template #reference>
                      <el-icon class="el-icon-warning" color="red" :size="18"></el-icon>
                    </template>
                    <div>
                      <p>关闭原因: {{ closeDesc.text }}</p>
                    </div>
                  </el-popover>
                </div>
              </div>
              <div class="grid-box--item">创建时间: {{ orderCreatedTime }}</div>
              <div class="grid-box--item">买家名称: {{ orderDatas.buyerName }}</div>
              <div class="grid-box--item">联系方式: {{ orderDatas.buyerPhone || '-' }}</div>
              <div class="grid-box--item">订单编号: {{ orderDatas.sn }}</div>
            </div>
          </div>
        </div>
        <!--        流程-->
        <div class="bar-module mt-15px">
          <div class="bar-module--t">流程</div>
          <div class="bar-module--c">
            <order-step
              :orderState="orderState"
              :orderDatas="orderDatas"
              :orderCreatedTime="orderCreatedTime"
              :closeDesc="closeDesc"
              :deliverInfo="deliverInfo"
              :payTypeInfo="payTypeInfo"
            ></order-step>
          </div>
        </div>
        <!--        tab栏-->
        <el-tabs class="mt-15px" v-model="activeTab">
          <el-tab-pane label="订单信息" name="orderInfo">
            <dl>
              <dt>订单编号</dt>
              :
              <dd>{{ orderDatas.sn }}</dd>
            </dl>
            <dl>
              <dt>店铺名称</dt>
              :
              <dd>{{ orderDatas.bizEcShopName }}</dd>
            </dl>
            <template v-if="showPayInfo">
              <dl>
                <dt>支付金额</dt>
                :
                <dd>{{ orderDatas.payableAmount }}</dd>
              </dl>
              <dl>
                <dt>支付方式</dt>
                :
                <dd>{{ payTypeInfo.payTypeName }}</dd>
              </dl>
              <dl>
                <dt>支付时间</dt>
                :
                <dd>{{ payTypeInfo.payTimes }}</dd>
              </dl>
            </template>
            <template v-if="orderDatas.address">
              <dl>
                <dt>收货人</dt>
                :
                <dd>{{ orderDatas.address.name }}</dd>
              </dl>
              <dl>
                <dt>联系方式</dt>
                :
                <dd>{{ orderDatas.address.mobile }}</dd>
              </dl>
              <dl>
                <dt>收货地址</dt>
                :
                <dd>{{ receieAddress }}</dd>
              </dl>
            </template>
            <dl>
              <dt>订单备注</dt>
              :
              <dd>{{ orderDatas.message || '-' }}</dd>
            </dl>
          </el-tab-pane>
          <el-tab-pane v-if="showTransTab" label="物流信息" name="transInfo">
            <dl>
              <dt>货运方式</dt>
              :
              <dd>快递</dd>
            </dl>
            <dl>
              <dt>货运公司</dt>
              :
              <dd>{{ deliverInfo.typeName }}</dd>
            </dl>
            <dl>
              <dt>货运单号</dt>
              :
              <dd>{{ deliverInfo.billSn || '-' }}</dd>
            </dl>
            <div class="trans-detail mt-15px">
              <el-timeline>
                <el-timeline-item
                  v-for="(item, index) in transTimeLine"
                  :key="index"
                  :timestamp="item.time"
                >
                  {{ item.status }}
                </el-timeline-item>
              </el-timeline>
            </div>
          </el-tab-pane>
        </el-tabs>
        <!--        表格-->
        <div class="foot-box">
          <div class="table-box">
            <kmjsTable :tableData="tableData" :columns="tableColumn"></kmjsTable>
          </div>
          <div class="flex-e mt-15px">
            <div style="width: 220px; padding-bottom: 100px">
              <dl>
                <dt>商品总额</dt>
                :
                <dd class="flex-e">¥ {{ orderDatas.goodsAmount }}</dd>
              </dl>
              <dl>
                <dt>运费</dt>
                :
                <dd class="flex-e">¥ {{ orderDatas.deliverAmount }}</dd>
              </dl>
              <dl>
                <dt>优惠</dt>
                :
                <dd class="flex-e">¥ {{ orderDatas.ticketAmount }}</dd>
              </dl>
              <dl v-for="item in orderDatas.ticketTitles" :key="item">
                <dd class="flex-e">({{ item }})</dd>
              </dl>
              <dl style="color: red">
                <dt>实付款</dt>
                :
                <dd style="font-size: 16px" class="flex-e">¥ {{ orderDatas.payableAmount }}</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, onMounted, reactive, toRefs } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { getTransInfoAPI, orderDetailAPI, getAreaWithSn } from '@/api/orderManage';
  import kmjsTable from '@/components/table/table';
  import orderStep from '../components/orderStep.vue';
  import { formatterTime } from '@/utils';
  import { useStore } from 'vuex';

  interface Obj {
    [propName: string]: any;
  }
  interface State {
    orderState: string;
    activeTab: string;
    orderDatas: Obj;
    tableColumn: Obj[];
    tableData: Obj[];
    transTimeLine: Obj[];
    receieAddress: string;
  }
  interface PayItem {
    payType: string;
    transAt: number;
    [propName: string]: any;
  }

  const useLocalMap = () => {
    const payTypeObj: { [index: string]: string } = {
      pay_jsapi_wx: '微信支付',
      pay_app_wx: '微信支付',
      pay_app_ali: '支付宝支付',
      pay_app_qr_wx: '微信二维码支付',
      pay_app_qr_ali: '支付宝二维码支付',
      online_pay: '在线支付',
      free_pay: '免额支付'
    };
    const saledStateObj: { [index: string]: string } = {
      none: '--',
      process: '售后中',
      complete: '售后完成'
    };
    return {
      payTypeObj,
      saledStateObj
    };
  };

  export default defineComponent({
    name: 'orderManageDetail',
    components: {
      kmjsTable,
      orderStep
    },
    setup() {
      const router = useRouter();
      const { query } = useRoute();
      const store = useStore();
      const handleBack = () => router.back();
      const orderSn = query.orderSn as string;
      const { payTypeObj, saledStateObj } = useLocalMap();
      const state = reactive<State>({
        // 订单状态
        orderState: '',
        // tab栏 orderInfo订单信息 transInfo物流信息
        activeTab: 'orderInfo',
        // 请求回来的详情数据
        orderDatas: {},
        // 表格头
        tableColumn: [
          {
            type: 'text',
            label: '商品信息',
            key: 'bizEcGoodsName',
            width: 300
          },
          {
            type: 'text',
            label: 'SKU',
            key: 'bizEcGoodsSpecsName'
          },
          {
            type: 'text',
            label: '单价',
            key: 'price'
          },
          {
            type: 'text',
            label: '数量',
            key: 'quantity'
          },
          {
            type: 'text',
            label: '商品总价',
            key: 'goodsAmount'
          },
          {
            type: 'text',
            label: '实收金额',
            key: 'payAmount'
          },
          {
            type: 'text',
            label: '售后状态',
            key: 'saledStateName'
          }
        ],
        // 表格数据
        tableData: [],
        // 物流信息时间线
        transTimeLine: [],
        // 收货地址
        receieAddress: ''
      });
      /*
       * 订单状态名称
       * */
      const orderStateName = computed(() => {
        const obj = store.getters['dictionaries/getDataToJson']('ec_order_state');
        // 目前没有评论功能, 待评论和已完成统一显示为订单完成
        return obj[state.orderState];
      });
      /*
       * 是否展示物流信息tab栏
       * */
      const showTransTab = computed(() => {
        // receiving待收货 comment待评论 complete已完成
        const arr = ['receiving', 'comment', 'complete'];
        return arr.includes(state.orderState);
      });
      /*
       * 订单关闭原因描述
       * @return {Object | Boolean} 返回object说明订单是关闭状态, 且后台数据返回有关闭类型, 否则返回false供页面判断展不展示
       * */
      const closeDesc = computed(() => {
        const { closeType, closeReason, closedAt } = state.orderDatas;
        if (state.orderState === 'cancel' && closeType) {
          return {
            text: closeReason,
            time: formatterTime(new Date(closedAt * 1000))
          };
        }
        return false;
      });
      /*
       * 订单发货信息
       * */
      const deliverInfo = computed(() => {
        return state.orderDatas?.deliver || {};
      });
      /*
       * 订单创建时间
       * @return {string} '2021/01/01 12:00:00'
       * */
      const orderCreatedTime = computed(() => {
        const t = state.orderDatas?.createAt;
        if (!t) return '-';
        return formatterTime(new Date(t * 1000));
      });
      /*
       * 订单信息中是否展示支付信息
       * */
      const showPayInfo = computed(() => {
        const s = state.orderState;
        const arr = ['deliver', 'receiving', 'comment', 'complete'];
        return arr.includes(s);
      });
      /*
       * 支付信息
       * @return {object} { 支付方式, 支付时间 }
       * */
      const payTypeInfo = computed(() => {
        const pays: PayItem[] = state.orderDatas?.pays || [];
        return {
          payTypeName: pays.map((item) => payTypeObj[item.payType]).join(','),
          payTimes: pays.map((item) => formatterTime(new Date(item.transAt * 1000))).join(',')
        };
      });
      /*
       * 请求订单详情数据
       * */
      const getDetailData = async () => {
        const res = await orderDetailAPI(orderSn);
        if (res) {
          state.orderDatas = res;
          state.orderState = state.orderDatas?.state || '';
          // 将一个商品下的多种规格扁平化, 变成多条数据展示
          const list = state.orderDatas?.orderItems || [];
          state.tableData = list.reduce((total: Obj[], item: Obj) => {
            item.itemDetailResponses.forEach((record: Obj) => {
              total.push({
                saledStateName: saledStateObj[record.saledState],
                ...item,
                ...record
              });
            });
            return total;
          }, []);
          // 请求订单详情成功后, 判断有无billSn, 有值再请求获取物流信息
          deliverInfo.value.billSn && getTransInfo();
          // 根据地址areaSn请求地址详细信息
          const areaSn = state.orderDatas?.address?.areaSn;
          areaSn && getAddressWithAreasn(areaSn);
        }
      };

      /*
       * 根据后台返回的areaSn拼接省市区详细地址
       * */
      const getAddressWithAreasn = async (areaSn: string) => {
        const res: Obj = await getAreaWithSn(areaSn);
        const { province, city, area } = res || {};
        state.receieAddress = `${province?.name}${city?.name}${area?.name}${state.orderDatas?.address?.address}`;
      };

      /*
       * 请求物流信息
       * */
      const getTransInfo = async () => {
        const res: Obj = await getTransInfoAPI(orderSn);
        if (res.success) {
          state.transTimeLine = res?.statusList || [];
        }
      };

      /*
       * 跳转发货页面
       * */
      const goSendGoodsPage = () => {
        router.push({
          path: '/orderManageDelivery',
          query: {
            orderSn
          }
        });
      };

      onMounted(() => {
        getDetailData();
      });
      return {
        ...toRefs(state),
        orderCreatedTime,
        orderStateName,
        showTransTab,
        closeDesc,
        deliverInfo,
        showPayInfo,
        payTypeInfo,
        handleBack,
        goSendGoodsPage
      };
    }
  });
</script>
<style lang="less">
  .order-mg-detail {
    dl {
      margin-top: 10px;
      display: flex;
      justify-content: left;
      dt {
        flex-shrink: 0;
        width: 60px;
        text-align-last: justify;
      }
      dd {
        margin-left: 15px;
        width: 100%;
        word-break: break-all;
        padding-right: 10px;
      }
    }
    .back {
      padding-top: 0;
    }
    .flex-b {
      display: flex;
      align-items: center;
    }
    .flex-e {
      display: flex;
      align-items: center;
      justify-content: flex-end;
    }
    .mt-15px {
      margin-top: 15px;
    }
    .ml-15px {
      margin-left: 15px;
    }
    .kmjs-wrap {
      .bar-module {
        background: #eee;
        padding: 20px;
        &--t {
          padding-bottom: 15px;
          font-size: 14px;
          font-weight: bold;
        }
        .grid-box {
          display: grid;
          grid-template-columns: repeat(auto-fit, 280px);
          grid-gap: 15px;
          white-space: nowrap;
          &--item {
            display: flex;
            align-items: center;
            justify-content: flex-start;
          }
        }
      }
      .foot-box {
        .table-box {
          margin-top: 30px;
          height: 400px;
        }
        .flex-e {
          display: flex;
          justify-content: flex-end;
        }
      }
    }
    .kmjs-table-table-wrap {
      height: 100%;
    }
  }
</style>
