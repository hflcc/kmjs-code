<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage } from 'element-plus';
  import { useRoute, useRouter } from 'vue-router';
  import { orderDeliveryAPI } from '@/api/orderManage';

  interface FormData {
    deliverType: string;
    billSn: string;
  }

  export default defineComponent({
    name: 'orderManageDelivery',
    components: {
      kmjsModule
    },
    setup() {
      const { query } = useRoute();
      const router = useRouter();
      const orderSn = query.orderSn as string;
      /*
       * 确认发货
       * */
      const sureDelivery = async (formData: FormData) => {
        const res = await orderDeliveryAPI(orderSn, formData);
        if (res) {
          ElMessage.success('确认发货成功');
          sessionStorage.setItem('ordMgTransStateChange', 'y');
          setTimeout(() => {
            router.back();
          }, 1000);
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: false,
              title: '订单发货',
              actions: []
            },
            children: [
              {
                type: 'form',
                name: 'title-form',
                params: {
                  parentConfig: {
                    labelWidth: '100px',
                    labelPosition: 'left',
                    dictionary: ['deliver_type'],
                    submitText: '确认发货'
                  },
                  itemData: [
                    {
                      label: '货运公司',
                      type: 'select',
                      key: 'deliverType',
                      dictionaryName: 'deliver_type',
                      defaultValue: '',
                      validNames: ['required']
                    },
                    {
                      label: '货运单号',
                      type: 'text',
                      key: 'billSn',
                      validNames: ['required'],
                      validFlexible: [
                        {
                          valid: '^[0-9A-Za-z]{5,20}$',
                          message: '请输入正确的货运单号',
                          trigger: 'blur'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          const formData = data[0] as FormData;
          if (name === 'submit') {
            sureDelivery(formData);
          }
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
