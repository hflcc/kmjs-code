<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl">
      <template #slotGoodsInfo="{ row }">
        <dl>
          <dd v-for="(item, i) in row.items" :key="i">
            <template v-if="row.showMore || i < 3">
              <div>{{ item.bizEcGoodsName }}</div>
              <div style="color: #999999; font-size: 10px">
                <div v-for="(record, j) in item.itemDetailResponses" :key="j">
                  {{ record.bizEcGoodsSpecsName }} x{{ record.quantity }}
                </div>
              </div>
            </template>
          </dd>
          <el-button
            type="text"
            v-if="row.items && row.items.length > 3"
            @click="row.showMore = !row.showMore"
          >
            <span>{{ row.showMore ? '收起' : '查看更多' }}</span>
            <i
              :class="['el-icon--right', row.showMore ? 'el-icon-arrow-up' : 'el-icon-arrow-down']"
            ></i>
          </el-button>
        </dl>
      </template>
    </kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onActivated, onUnmounted } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage } from 'element-plus';
  import { useRouter } from 'vue-router';
  import { orderExportAPI } from '@/api/orderManage';
  import { downloadBufferFile, File } from '@/utils/tools';
  import useOrganization from '@/store/commModules/organization/useOrganization';

  interface Methods {
    [propName: string]: () => any;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface Obj {
    [propName: string]: any;
  }
  interface Deliver {
    failType: string;
  }
  interface TableRow {
    appName: string;
    bizEcShopName: string;
    bizEcShopSn: string;
    bizKey: string;
    bizSource: string;
    buyerName: string;
    buyerPhone: string;
    composes: string;
    createdAt: number;
    deliverAmount: number;
    expireAt: number;
    expireSecs: number;
    goodsAmount: number;
    id: number;
    message: string;
    originalAmount: number;
    payInstanceSn: string;
    payableAmount: number;
    paymentType: string;
    saledState: string;
    sn: string;
    species: number;
    state: string;
    ticketAmount: number;
    totalQuantity: number;
    deliver: Deliver;
    deliverFailType: string;
    sendOutType: string;
  }
  export default defineComponent({
    name: 'orderManageIndex',
    components: {
      kmjsModule
    },
    setup() {
      const router = useRouter();
      const { activeOrganization } = useOrganization();

      const handlers: Handlers = {
        // 点击全部导出
        exportAll: async (list, methods) => {
          if (!activeOrganization.value?.sn) {
            ElMessage.error('请先选择组织');
            return;
          }
          let searchData = await methods['/title/title-table/getSearchData']();
          const searchStr = Object.keys(searchData?.params ?? {})
            .map((key) => `${key}=${searchData.params[key]}`)
            .join('&');
          const res = await orderExportAPI(searchStr, activeOrganization.value?.sn);
          res && downloadBufferFile(res as File);
        },
        // 批量导出
        tableBatchExport: async (arr) => {
          const [list] = arr;
          if (!list.length) {
            ElMessage.error('请选择需要批量导出数据');
            return;
          }
          const query = `orderSns=${list.map((item: Obj) => item.sn).join(',')}`;
          const res = await orderExportAPI(query, activeOrganization.value?.sn);
          res && downloadBufferFile(res as File);
        },
        // 跳订单详情页面
        tableGoDetailPage: (list) => {
          const { row = {} } = list[0] || {};
          router.push({
            path: '/orderManageDetail',
            query: {
              orderSn: row.sn
            }
          });
        },
        // 点击发货, 跳转发货页面
        tableSendGoods: (list) => {
          const { row = {} } = list[0] || {};
          router.push({
            path: '/orderManageDelivery',
            query: {
              orderSn: row.sn
            }
          });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '订单管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '全部导出',
                  emit: 'exportAll'
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/ec/platform/order/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '商品名称',
                          key: 'goodsName',
                          type: 'text'
                        },
                        {
                          label: '订单编号',
                          key: 'orderSn',
                          type: 'text'
                        },
                        {
                          label: '下单时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        },
                        {
                          label: '买家名称',
                          key: 'buyerName',
                          type: 'text'
                        },
                        {
                          label: '收件人姓名',
                          key: 'receiveName',
                          type: 'text'
                        },
                        {
                          label: '收件人联系方式',
                          key: 'receivePhone',
                          type: 'text'
                        },
                        {
                          label: '订单状态',
                          key: 'orderState',
                          type: 'select',
                          // dictionaryName: 'ec_order_state',
                          options: [
                            {
                              label: '全部',
                              value: ''
                            },
                            {
                              label: '待支付',
                              value: 'none'
                            },
                            {
                              label: '待发货',
                              value: 'deliver'
                            },
                            {
                              label: '发货中',
                              value: 'delivering'
                            },
                            {
                              label: '待收货',
                              value: 'receiving'
                            },
                            {
                              label: '订单完成',
                              value: 'complete'
                            },
                            {
                              label: '订单关闭',
                              value: 'cancel'
                            }
                          ]
                        },
                        {
                          label: '物流状态',
                          key: 'deliverFailType',
                          type: 'select',
                          dictionaryName: 'deliver_fail_type'
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '订单编号',
                          key: 'sn',
                          width: 210
                        },
                        {
                          label: '订单状态',
                          key: 'state',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'ec_order_state'
                          }
                        },
                        {
                          label: '售后状态',
                          key: 'saledState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'order_saled_state'
                          }
                        },
                        {
                          label: '物流状态',
                          key: 'deliverFailType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'deliver_fail_type'
                          }
                        },
                        {
                          label: '商品信息',
                          type: 'slot',
                          key: 'slotGoodsInfo',
                          width: 300
                        },
                        {
                          label: '店铺名称',
                          key: 'bizEcShopName'
                        },
                        {
                          label: '商品总价',
                          key: 'goodsAmount',
                          align: 'right',
                          formatter: 'price'
                        },
                        {
                          label: '实收金额',
                          key: 'payableAmount',
                          align: 'right',
                          formatter: 'price'
                        },
                        {
                          label: '下单时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '买家',
                          key: 'buyerName'
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              label: '详情',
                              emit: 'goDetailPage',
                              show: 'always'
                            },
                            {
                              label: '发货',
                              emit: 'sendGoods',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'sendOutType',
                                  columnValue: 'deliver'
                                }
                              ]
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '批量导出',
                          emit: 'batchExport'
                        }
                      ]
                    }
                  ]
                },
                slotParam: [
                  {
                    name: 'slotIndex',
                    slotName: 'slotIndex'
                  },
                  {
                    name: 'slotGoodsInfo',
                    slotName: 'slotGoodsInfo'
                  }
                ]
              }
            ]
          }
        ],

        params: {
          '/title/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              obj.url = `${obj.url}/${activeOrganization.value?.sn}`;
              return Promise.resolve(activeOrganization.value?.sn ? obj : null);
            },
            dataFormatter: (data: TableRow[]) => {
              return data.map((item: TableRow) => {
                item.deliverFailType = item.deliver ? item.deliver.failType : '';
                if (
                  (item.state == 'deliver' ||
                    (item.state == 'delivering' && item.deliverFailType == 'fail')) &&
                  item.saledState == 'none'
                ) {
                  item.sendOutType = 'deliver';
                } else {
                  item.sendOutType = 'none';
                }
                return item;
              });
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          handlers[name] && handlers[name](data, methods);
        }
      });

      onActivated(() => {
        // 判断页面有无ordMgTransStateChange, 由订单发货页面delivery写入, 订单发货状态更新后, 需要刷新表格
        if (sessionStorage.getItem('ordMgTransStateChange') === 'y') {
          methods['/title/title-table/refresh']();
          sessionStorage.removeItem('ordMgTransStateChange');
        }
      });
      onUnmounted(() => {
        sessionStorage.removeItem('ordMgTransStateChange');
      });

      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
