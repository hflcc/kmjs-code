import ajax from '@/utils/axios';

/*
 * 删除证件认证api
 * */
export const delCerCertificationOfSingle = (sn: string) => {
  return ajax.delete(`/auth/md/certifyOrder/rejectToDelete/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 批量删除证件认证
 */
export function delBatchCertificationOfSingle(sns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ sns: string[] }, { success: boolean }>(
    `/auth/md/certifyOrder/batch/${sns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
}
