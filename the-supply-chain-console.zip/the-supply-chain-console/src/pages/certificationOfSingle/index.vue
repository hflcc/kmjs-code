<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delCerCertificationOfSingle, delBatchCertificationOfSingle } from './api/index';
  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sns: string;
    sn: string;
    serialCode: string;
  }
  export default defineComponent({
    name: 'certificationOfSingle',
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        tableCertificationOfSingleDele: async (list, methods) => {
          let sn = list[0].row.sn;
          const serialCode = list[0].row.serialCode;
          const message = `确认要删除【${serialCode}】证件认证单吗？`;
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delCerCertificationOfSingle(sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        },
        tableBankCertificationOfSingleDelete: async (list) => {
          const selectedData: TableRow[] = list[0] || [];
          if (!selectedData.length) {
            ElMessage.error('请选择需要批量删除的证件认证单');
            return;
          }
          const sns = selectedData.map((item) => item.sn);
          const message = '确定要删除已选中证件认证单吗？';
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delBatchCertificationOfSingle(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '证件认证单',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  type: 'createForm',
                  emit: 'createForm',
                  params: {
                    // 配置项
                    defSn: 'a90fbd49796e448289a4745a2f5558ef'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/certifyOrder/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '单号',
                          key: 'serialCode',
                          type: 'text'
                        },
                        {
                          label: '认证证件',
                          key: 'brandType',
                          type: 'select',
                          dictionaryName: 'qualification_def_name'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'select',
                          dictionaryName: 'certify_order_audit_state'
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          type: 'select',
                          dictionaryName: 'certify_order_pay_state'
                        },
                        {
                          label: '创建人',
                          key: 'createdByName',
                          type: 'text'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '单号',
                          key: 'serialCode'
                        },
                        {
                          label: '认证证件',
                          key: 'qualificationDefContext'
                        },
                        {
                          label: '认证机构',
                          key: 'bizMdPlatformInstName'
                        },
                        {
                          label: '付款方式',
                          key: 'payType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'certify_order_pay_type'
                          }
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'mapText',
                          params: {
                            showDiaLogIcon: true,
                            type: 'dictionary',
                            dictionaryName: 'certify_order_audit_state'
                          }
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'certify_order_pay_state'
                          }
                        },
                        {
                          label: '费用金额（元）',
                          key: 'deductTotalAmount'
                        },
                        {
                          label: '支付截止时间',
                          key: 'expiredAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdByName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'description',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'certificationOfSingleDetail',
                              params: {
                                defSn: 'e596b09dd6be4baab997f06b1b5f6d1c',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'certificationOfSingleEdit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait|reject'
                                },
                                {
                                  columnKey: 'payState',
                                  columnValue: 'expired'
                                }
                              ],
                              params: {
                                defSn: '6ae8319b6a844fa58be8cf2164a338b2',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'certificationOfSingleDele',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait|reject'
                                },
                                {
                                  columnKey: 'payState',
                                  columnValue: 'expired'
                                }
                              ]
                            },
                            {
                              type: 'tableBpm',
                              label: '送审',
                              emit: 'submitAudit',
                              show: 'rule',
                              params: {
                                dataSnKey: 'sn',
                                bpmType: 'qualification_certify_apply',
                                noForm: true
                              },
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait'
                                }
                              ]
                            }
                            /*  {
                              label: '去支付',
                              emit: 'deleData',
                              show: 'rule',
                              rules: [
                                // {
                                //   columnKey: 'auditState',
                                //   columnValue: 'accept'
                                // },
                                {
                                  columnKey: 'payState',
                                  columnValue: 'pending'
                                }
                              ]
                            },
                            {
                              label: '继续支付',
                              emit: 'deleData',
                              show: 'rule',
                              rules: [
                                // {
                                //   columnKey: 'auditState',
                                //   columnValue: 'accept'
                                // },
                                {
                                  columnKey: 'payState',
                                  columnValue: 'paying'
                                }
                              ]
                            } */
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          type: 'danger',
                          emit: 'bankCertificationOfSingleDelete'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              obj.url = `${obj.url}`;
              return Promise.resolve(obj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
