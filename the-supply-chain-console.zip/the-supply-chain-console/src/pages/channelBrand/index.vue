<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sn: string;
    brandNo: string;
    brandName: string;
    state: string;
    brandType: string;
    brandIoc: string;
    bizMdPlatformInstName: string;
    bizMdSupplierName: string;
    bizMdContractName: string;
    effectiveTimeStart: number;
    effectiveTimeEnd: number;
    bizMdContractCategoryName: string;
    createdAt: number;
    remark: string;
    createdName: string;
    [propName: string]: unknown;
  }
  export default defineComponent({
    name: 'channelBrand',
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {};
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '渠道品牌',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  type: 'location',
                  label: '定位',
                  emit: 'location'
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/brand/platform/supplier/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '编号',
                          key: 'brandNo',
                          type: 'text'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName',
                          type: 'text'
                        },
                        {
                          label: '状态',
                          key: 'state',
                          type: 'select',
                          dictionaryName: 'brand_platform_supplier_state'
                        },
                        {
                          label: '品牌类型',
                          key: 'brandType',
                          type: 'select',
                          dictionaryName: 'brand_type'
                        },
                        {
                          label: '合同名称',
                          key: 'bizMdContractName',
                          type: 'text'
                        },
                        {
                          label: '有效时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'effectiveTimeStart',
                            endKey: 'effectiveTimeEnd'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdName',
                          type: 'text'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange1',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'brandNo'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName'
                        },
                        {
                          label: '状态',
                          key: 'state',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_platform_supplier_state'
                          }
                        },
                        {
                          label: '品牌类型',
                          key: 'brandType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_type'
                          }
                        },
                        {
                          type: 'image',
                          label: '品牌商标',
                          key: 'brandIoc',
                          params: {
                            width: '80px'
                          }
                        },
                        {
                          label: '平台',
                          key: 'bizMdPlatformInstName'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierName'
                        },
                        {
                          label: '合同',
                          key: 'bizMdContractName'
                        },
                        {
                          label: '类目',
                          key: 'bizMdContractCategoryName'
                        },
                        {
                          label: '有效时间',
                          key: 'expiredType',
                          type: 'expiredDate',
                          width: 200,
                          params: {
                            startKey: 'expiredStartAt',
                            endKey: 'expiredEndAt'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'remark',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'channelBrandDetail',
                              params: {
                                defSn: '6275acb2ce5d4c15b7f6051b69d6833a',
                                dataSnKey: 'sn'
                              }
                            },
                            // 先不显示
                            {
                              type: 'tableBpm',
                              label: '变更',
                              emit: 'channelBrandChange',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'state', //key
                                  columnValue: 'expired|normal' //满足的值
                                }
                              ],
                              params: {
                                defSn: 'e7771d9d987111ec8d3eb8599f52bbe4',
                                dataSnKey: 'sn'
                              }
                            }
                          ]
                        }
                      ],
                      actions: []
                    }
                  ]
                },
                slotParam: []
              }
            ]
          }
        ],
        handler: (moduleName, name, data) => {
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
