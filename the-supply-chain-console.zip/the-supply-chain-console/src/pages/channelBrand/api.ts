import ajax from '@/utils/axios';
interface IDelSupplierData {
  message: string;
  success: boolean;
  [propName: string]: unknown;
}
/* 删除品牌库列表数据 */
export const delSupplierData = (sn: string): Promise<IDelSupplierData> => {
  return ajax.put(
    `/auth/md/supplier/instance/rejectToDelete/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
