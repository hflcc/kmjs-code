import ajax from '@/utils/axios';

export interface CscItem {
  sn: string;
  count: number;
  name: string;
}

export interface CscService {
  // 机构用户sn
  bizMdInstUserSn: string;
  // 客服昵称
  nickname: string;
  // 名称
  name: string;
  // 最大接待数
  maxProcess: number;
  // 头像
  avatar: string;
}

export interface CscCenter {
  sn: string;
  relationSn: string;
  attendorSn: string;
  name: string;
  strategy: string;
}

export interface BaseResp {
  success: boolean;
  message: string;
}

export interface CscDetail {
  avatar: string;
  lastServiceAt: number;
  maxProcess: number;
  name: string;
  nickname: string;
  number: string;
  sn: string;
  state: string;
}

export interface CscDetailList {
  content: Csclist[];
}
// 方案规则绩效相关
interface Csclist {
  avatar: string;
  name: string;
  nickname: string;
  number: string;
  sn: string;
  state: string;
}

// // 客服信息
// export

// 客服中心列表
export const cscList = (): Promise<CscItem[]> => {
  return ajax.get<null, CscItem[]>('/auth/mk/csc/def/list', {
    params: {
      $InstId: true
    }
  });
};

// 后台客服中心列表
export const cscBackList = (): Promise<Paging<CscItem>> => {
  return ajax.get<null, Paging<CscItem>>('/auth/mk/csc/def/backstage/page', {
    params: {
      $InstId: true
    }
  });
};

// 查询客服中心列表
export const cscServiceLists = (): Promise<CscCenter[]> => {
  return ajax.get<null, CscCenter[]>('/auth/mk/csc/def/backstage/list', {
    params: {
      $InstId: true
    }
  });
};

// 添加客服中心定义
export const addCsc = (data: CscCenter): Promise<BaseResp> => {
  return ajax.post<null, BaseResp>('/auth/mk/csc/def/backstage', data, {
    params: {
      $InstId: true
    }
  });
};

// 修改客服中心
export const updateCsc = (data: CscCenter): Promise<BaseResp> => {
  return ajax.put<null, BaseResp>(`/auth/mk/csc/def/backstage/${data.sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

// 删除客服中心
export const deleteCsc = (sns: string[]): Promise<BaseResp> => {
  return ajax.delete<null, BaseResp>('/auth/mk/csc/def/backstage', {
    params: {
      $InstId: true,
      sns: sns.join(',')
    }
  });
};

// 查询客服中心
export const queryCscBySn = (sn: string): Promise<CscCenter> => {
  return ajax.get<null, CscCenter>(`/auth/mk/csc/def/backstage/${sn}`, {
    params: {
      $InstId: true
    }
  });
};

// （后台）根据客服中心sn添加客服
export const cscAddAttendor = (cscDefSn: string, attendorSns: string[]): Promise<CscCenter> => {
  return ajax.post<null, CscCenter>(
    `/auth/mk/csc/attendor/relation/backstage/${cscDefSn}`,
    { attendorSns },
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 添加一个客服
export const addAttendor = (data: CscService): Promise<BaseResp> => {
  return ajax.post<null, BaseResp>('/auth/mk/csc/attendor/backstage', data, {
    params: {
      $InstId: true
    }
  });
};
// 修改客服
export const amendAttendor = (attendorSn: string, data: CscService): Promise<BaseResp> => {
  return ajax.put<null, BaseResp>(`/auth/mk/csc/attendor/backstage/${attendorSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

// （后台）分页查询客服列表
export const queryAttendorPage = (): Promise<CscDetailList> => {
  return ajax.get<null, CscDetailList>('/auth/mk/csc/attendor/relation/page', {
    params: {
      $InstId: true
    }
  });
};

// 根据客服sn查询客服
export const queryAttendorCscBySn = (attendorSn: string): Promise<CscDetail> => {
  return ajax.get<null, CscDetail>(`/auth/mk/csc/attendor/backstage/${attendorSn}`, {
    params: {
      $InstId: true
    }
  });
};

// （后台）批量删除客服
export const deleteCscBySn = (sns: string[]): Promise<BaseResp> => {
  return ajax.delete<null, BaseResp>('/auth/mk/csc/attendor/backstage', {
    params: {
      $InstId: true,
      attendorSns: sns.join(',')
    }
  });
};

// （后台）根据客服sn查询--查详情
export const attendorForSn = (sn: string): Promise<BaseResp> => {
  return ajax.get<null, BaseResp>(`/auth/mk/csc/attendor/backstage/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
// 客服中心客服中心（根据客服中心sn添加客服）
export const addManage = (cscDefSn: string, data: { attendorSns: [] }): Promise<BaseResp> => {
  return ajax.post<null, BaseResp>(`/auth/mk/csc/attendor/relation/backstage/${cscDefSn}`, data, {
    params: {
      $InstId: true
    }
  });
};
// 客服中心客服中心（删除）
export const deleteManage = (sn: string[]): Promise<BaseResp> => {
  return ajax.delete<null, BaseResp>(`/auth/mk/csc/attendor/relation/backstage/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
