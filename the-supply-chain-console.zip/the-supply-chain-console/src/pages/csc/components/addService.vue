<template>
  <el-dialog v-model="showDialog" title="添加客服" @close="closeWindow" width="60%" height="70%">
    <div>
      <kmjsModule style="height: 50vh" :ctl="moduleCtl"></kmjsModule>

      <div class="select-box">
        <div class="btn">
          <el-button size="small" @click="closeWindow">取消</el-button>
          <el-button type="primary" size="small" @click="confirm">确认</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>
<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { useDialog } from '@/utils/hooks';
  import { addManage } from '@/pages/csc/api';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'addService',
    components: {
      kmjsModule
    },
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      cscDefSn: {
        type: String,
        default: ''
      }
    },
    setup(props, { emit }) {
      const { showDialog, closeWindow } = useDialog(props, emit);

      // 确认添加
      const confirm = () => {
        const data = methods['/title/title-table/getCheckData']?.();
        if (data) {
          if (data.length) {
            const r = data.map((i: any) => {
              return (i.attendorSns = i.sn);
            });
            // 新增客服
            addManage(props.cscDefSn, { attendorSns: r }).then((res) => {
              if (res.success) {
                ElMessage.success('新增成功');
                // emit("update:modelValue", false);
                emit('on-confirm', false);
              }
            });
          }
        }
      };

      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                params: {
                  tableDataUrl: '/auth/mk/csc/attendor/page',
                  items: [
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '头像',
                          type: 'image',
                          key: 'avatar',
                          width: 60
                        },
                        {
                          label: '客服昵称',
                          key: 'nickname'
                        },
                        {
                          label: '用户名',
                          key: 'name'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ]
      });

      return {
        moduleCtl,
        showDialog,
        closeWindow,
        confirm
      };
    }
  });
</script>
<style lang="less">
  .select-box {
    margin-bottom: 20px;
    .select-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 700;
    }
  }
  .btn {
    padding-bottom: 20px;
    float: right;
  }
</style>
