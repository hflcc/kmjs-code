import { defineComponent, PropType, ref, watch } from 'vue';
import './style.less';
import { useValid } from '@/components/form';

export default defineComponent({
  name: 'form-select-button',
  props: {
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    config: {
      type: Object as PropType<Record<string, any>>
    },
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    }
  },
  emits: ['selectUser'],
  setup(props, { emit }) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange } = useValid();
    // 这里可以设置一个校验函数，在校验时会触发校验
    // if (typeof setValidRule === 'function') {
    //   setValidRule(props.config?.key, (rule, value, callback) => {
    //     if (!value) {
    //       return callback(new Error('请选择人员'));
    //     }
    //     return callback();
    //   });
    // }

    const inputValue = ref('');
    watch(
      () => props.modelValue,
      (val) => {
        inputValue.value = val;
        props.change(inputValue.value);
        validChange(inputValue.value);
      }
    );
    return {
      inputValue,
      emit
    };
  },
  render() {
    const { inputValue } = this;
    return (
      <el-space>
        {inputValue ? (
          <div
            class="input-class"
            onClick={() => {
              this.emit('selectUser');
            }}
          >
            {inputValue}
          </div>
        ) : (
          <div
            class="input-class placeholder"
            onClick={() => {
              this.emit('selectUser');
            }}
          >
            点击选择人员
          </div>
        )}
      </el-space>
    );
  }
});
