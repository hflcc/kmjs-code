<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
    <addService
      v-model="showChooseOrganization"
      :cscDefSn="cscDefSn"
      @on-confirm="getChooseOrg"
    ></addService>
  </div>
</template>

<script lang="ts">
  import { defineComponent, inject, onUnmounted, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { useRoute } from 'vue-router';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { CscCenter, deleteManage } from '@/pages/csc/api';
  import addService from '@/pages/csc/components/addService.vue';
  import { Emitter } from 'emitt';
  export default defineComponent({
    name: 'cscServiceCenterManage',
    components: {
      kmjsModule,
      addService
    },
    setup() {
      const { query } = useRoute();
      const showChooseOrganization = ref(false);
      const cscDefSn = query.sn;
      const deleteAll = (data: CscCenter[]) => {
        if (data.length === 0) {
          ElMessage.error('请至少选择一个');
          return;
        }

        const msg = data.length === 1 ? `确定要删除客服${data[0].name}吗？` : '确定要删除吗？';
        ElMessageBox.alert(msg, '提示', {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          showCancelButton: true,
          callback: (action: string) => {
            if (action === 'confirm') {
              deleteManage(data.map((i) => i.sn)).then((res) => {
                if (res.success) {
                  ElMessage.success('删除成功');
                  methods['/title/title-table/refreshAll']();
                }
              });
            }
          }
        });
      };
      const getChooseOrg = () => {
        showChooseOrganization.value = false;
        methods['/title/title-table/refreshAll']();
      };
      const [moduleCtl, methods] = useModule({
        // config: [
        //   {
        //     type: 'wrap-module',
        //     name: 'title',
        //     params: {
        //       hideBack: false,
        //       title: '客服管理',
        //       actions: [
        //         {
        //           type: 'refresh',
        //           emit: 'refresh'
        //         },
        //         {
        //           label: '添加',
        //           emit: 'addSubmit'
        //         }
        //       ]
        //     },
        //     children: [
        //       {
        //         type: 'table',
        //         name: 'title-table',
        //         params: {
        //           // tableDataUrl: `/auth/mk/csc/attendor/relation/page?cscDefSn=${query.sn}`,
        //           tableDataUrl: '/auth/mk/csc/attendor/relation/page',
        //           items: [
        //             {
        //               type: 'search',
        //               inputs: [
        //                 {
        //                   label: '客服名称',
        //                   key: 'name',
        //                   type: 'text'
        //                 }
        //               ]
        //             },
        //             {
        //               type: 'table',
        //               tableHead: [
        //                 {
        //                   label: '头像',
        //                   type: 'image',
        //                   key: 'avatar',
        //                   width: 60
        //                 },
        //                 {
        //                   label: '姓名',
        //                   key: 'name'
        //                 },
        //                 {
        //                   label: '客服昵称',
        //                   key: 'nickname'
        //                 },
        //                 {
        //                   type: 'handle',
        //                   label: '操作',
        //                   actions: [
        //                     {
        //                       label: '删除',
        //                       emit: 'delete',
        //                       show: 'always'
        //                     }
        //                   ]
        //                 }
        //               ],
        //               actions: [
        //                 {
        //                   label: '删除',
        //                   emit: 'deleteAll'
        //                 }
        //               ]
        //             }
        //           ]
        //         }
        //       }
        //     ]
        //   }
        // ],
        params: {
          '/title/title-table': {
            reqBody: {
              cscDefSn: cscDefSn
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          switch (moduleName + '_' + name) {
            case '/title_addSubmit':
              showChooseOrganization.value = true;
              break;
            case '/title/title-table_tableDelete':
              deleteAll([data[0].row]);
              break;
            case '/title/title-table_tableDeleteAll':
              deleteAll(data[0]);
              break;
          }
        }
      });
      // onUnmounted(() => {
      //   document.dispatchEvent(new CustomEvent('cscRefreshAll', {}));
      // });
      const eventEmit = inject<Emitter['emit']>('eventEmit');
      onUnmounted(() => {
        if (eventEmit) {
          eventEmit('cscRefreshAll', '');
        }
      });
      return {
        moduleCtl,
        showChooseOrganization,
        cscDefSn,
        getChooseOrg
      };
    }
  });
</script>
<style lang="less"></style>
