<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, inject, onMounted, onUnmounted } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { useRouter } from 'vue-router';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { CscCenter, deleteCsc } from '@/pages/csc/api';
  import { useStore } from 'vuex';
  import { Emitter } from 'emitt';

  export default defineComponent({
    name: 'cscServiceCenter',
    components: {
      kmjsModule
    },
    setup() {
      const router = useRouter();
      // store
      const store = useStore<RootState>();
      if (!store.state.im.imInfoIsReady) {
        store.dispatch('im/initSdk');
      }
      // 删除多个
      const deleteAll = (data: CscCenter[]) => {
        if (data.length === 0) {
          ElMessage.error('请至少选择一个');
          return;
        }
        const msg = data.length === 1 ? `确定要删除客服中心${data[0].name}吗？` : '确定要删除吗？';
        ElMessageBox.alert(msg, '提示', {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          showCancelButton: true,
          callback: (action: string) => {
            if (action === 'confirm') {
              deleteCsc(data.map((i) => i.sn)).then((res) => {
                if (res.success) {
                  ElMessage.success('删除成功');
                  methods['/title/title-table/refreshAll']();
                }
              });
            }
          }
        });
      };
      // const onRefresh = () => {
      //   methods['/title/title-table/refreshAll']();
      //   console.log('啊啊啊啊');
      // };
      // // 通过事件监听，刷新列表
      // onMounted(() => {
      //   document.addEventListener('cscRefreshAll', onRefresh);
      // });
      //
      // onUnmounted(() => {
      //   document.removeEventListener('cscRefreshAll', onRefresh);
      // });
      //#region 需要触发钩子进行刷新数据
      const onEvent = inject<Emitter['on']>('eventOn');
      const offEvent = inject<Emitter['off']>('eventOff');
      // 重新触发渲染
      function reRender() {
        methods?.['/title/title-table/refreshAll']();
      }
      onMounted(() => {
        if (onEvent) {
          onEvent('cscRefreshAll', reRender);
        }
      });

      onUnmounted(() => {
        if (offEvent) {
          offEvent('cscRefreshAll', reRender);
        }
      });
      //#endregion

      const [moduleCtl, methods] = useModule({
        // config: [
        //   {
        //     type: 'wrap-module',
        //     name: 'title',
        //     params: {
        //       hideBack: true,
        //       title: '客服中心',
        //       actions: [
        //         {
        //           type: 'refresh',
        //           emit: 'refresh'
        //         },
        //         {
        //           type: 'createForm',
        //           label: '新增',
        //           emit: 'serviceCenterAdd',
        //           params: {
        //             defSn: '02ad575d28e111eca2b50c42a1da1656'
        //           }
        //         }
        //       ]
        //     },
        //     children: [
        //       {
        //         type: 'table',
        //         name: 'title-table',
        //         params: {
        //           tableDataUrl: '/auth/mk/csc/def/backstage/page',
        //           items: [
        //             {
        //               type: 'search',
        //               inputs: [
        //                 {
        //                   label: '客服中心',
        //                   key: 'name',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'daterange',
        //                   type: 'daterange',
        //                   dateConfig: {
        //                     startKey: 'startTime',
        //                     endKey: 'endTime'
        //                   }
        //                 }
        //               ]
        //             },
        //             {
        //               type: 'table',
        //               tableHead: [
        //                 {
        //                   label: 'ID',
        //                   key: 'number'
        //                 },
        //                 {
        //                   label: '头像',
        //                   type: 'image',
        //                   key: 'ossId',
        //                   width: 60
        //                 },
        //                 {
        //                   label: '客服中心',
        //                   key: 'name'
        //                 },
        //                 {
        //                   label: '客服数',
        //                   key: 'serviceCount'
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'createdAt',
        //                   formatter: 'dateTime',
        //                   params: {
        //                     dataTimeType: 'YYYY-MM-DD HH:mm:ss'
        //                   }
        //                 },
        //                 {
        //                   type: 'handle',
        //                   label: '操作',
        //                   actions: [
        //                     {
        //                       type: 'tableEdit',
        //                       label: '编辑',
        //                       emit: 'serviceCenterEdit',
        //                       params: {
        //                         defSn: 'b50655f02a7411eca2b50c42a1da1656',
        //                         dataSnKey: 'sn'
        //                       }
        //                     },
        //                     {
        //                       label: '客服管理',
        //                       emit: 'serviceCenterManager',
        //                       show: 'always'
        //                     },
        //                     {
        //                       label: '删除',
        //                       emit: 'serviceCenterDelete',
        //                       show: 'always'
        //                     }
        //                   ]
        //                 }
        //               ],
        //               actions: [
        //                 {
        //                   label: '删除',
        //                   emit: 'serviceCenterDeleteAll'
        //                 }
        //               ]
        //             }
        //           ]
        //         }
        //       }
        //     ]
        //   }
        // ],
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          switch (moduleName + '_' + name) {
            case '/title/title-table_tableServiceCenterManager':
              router.push({
                name: 'cscServiceCenterManage',
                query: { sn: data[0].row.sn }
              });
              break;
            case '/title/title-table_tableServiceCenterDelete':
              deleteAll([data[0].row]);
              break;
            case '/title/title-table_tableServiceCenterDeleteAll':
              deleteAll(data[0]);
              break;
          }
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
