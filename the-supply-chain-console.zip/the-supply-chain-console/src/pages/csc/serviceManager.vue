<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onActivated } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { CscCenter, cscServiceLists, deleteCscBySn } from '@/pages/csc/api';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'cscServiceManager',
    components: {
      kmjsModule
    },
    setup() {
      // const router = useRouter();
      // store
      const store = useStore<RootState>();
      if (!store.state.im.imInfoIsReady) {
        store.dispatch('im/initSdk');
      }
      let lists = [
        {
          label: '选择所属中心查询',
          value: ''
        }
      ];
      // 获取客服中心下拉框数据
      cscServiceLists().then((res) => {
        if (res.length !== 0) {
          res.map((i) => {
            lists.push({
              label: i.name,
              value: i.sn
            });
          });
        } else {
          lists = [];
        }
      });
      // 删除提示
      const deleteTip = (data: CscCenter[]) => {
        if (data.length === 0) {
          ElMessage.error('请至少选择一个');
          return;
        }
        ElMessageBox.alert('删除后所在客服中心也将删除该客服，确定要删除吗?', '提示', {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          showCancelButton: true,
          callback: (action: string) => {
            if (action === 'confirm') {
              deleteCscBySn(data.map((i) => i.attendorSn)).then((res) => {
                if (res.success) {
                  ElMessage.success('删除成功');
                  methods['/title/title-table/refreshAll']();
                }
              });
            }
          }
        });
      };

      const [moduleCtl, methods] = useModule({
        // config: [
        //   {
        //     type: 'wrap-module',
        //     name: 'title',
        //     params: {
        //       hideBack: true,
        //       title: '客服管理',
        //       actions: [
        //         {
        //           type: 'refresh',
        //           emit: 'refresh'
        //         },
        //         {
        //           type: 'createForm',
        //           label: '新增',
        //           emit: 'serviceManagerAdd',
        //           params: {
        //             defSn: '246d77282ccf11eca2b50c42a1da1656'
        //           }
        //         }
        //       ]
        //     },
        //     children: [
        //       {
        //         type: 'table',
        //         name: 'title-table',
        //         params: {
        //           tableDataUrl: '/auth/mk/csc/attendor/page/relation',
        //           items: [
        //             {
        //               type: 'search',
        //               inputs: [
        //                 {
        //                   label: '姓名',
        //                   key: 'name',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '客服昵称',
        //                   key: 'nickname',
        //                   type: 'text'
        //                 },
        //                 {
        //                   label: '客服中心',
        //                   key: 'cscDefSn',
        //                   type: 'select',
        //                   defaultValue: ''
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'daterange',
        //                   type: 'daterange',
        //                   dateConfig: {
        //                     startKey: 'startTime',
        //                     endKey: 'endTime'
        //                   }
        //                 },
        //                 {
        //                   label: '是否已分配',
        //                   key: 'allocationState',
        //                   type: 'select',
        //                   options: [
        //                     {
        //                       label: '全部',
        //                       value: 'all'
        //                     },
        //                     {
        //                       label: '已分配',
        //                       value: 'already'
        //                     },
        //                     {
        //                       label: '未分配',
        //                       value: 'not_yet'
        //                     }
        //                   ]
        //                 }
        //               ]
        //             },
        //             {
        //               type: 'table',
        //               tableHead: [
        //                 {
        //                   label: 'ID',
        //                   key: 'number',
        //                   width: 150
        //                 },
        //                 {
        //                   label: '状态',
        //                   type: 'stateType',
        //                   key: 'state',
        //                   width: 150,
        //                   params: {
        //                     ON: {
        //                       name: '在线',
        //                       color: '#56bd3b'
        //                     },
        //                     BUSY: {
        //                       name: '繁忙',
        //                       color: '#fda07e'
        //                     },
        //                     OFF: {
        //                       name: '离线',
        //                       color: '#cacaca'
        //                     }
        //                   }
        //                 },
        //                 {
        //                   label: '头像',
        //                   type: 'image',
        //                   key: 'avatar',
        //                   width: 60
        //                 },
        //                 {
        //                   label: '姓名',
        //                   key: 'name',
        //                   width: 150
        //                 },
        //                 {
        //                   label: '客服昵称',
        //                   key: 'nickname'
        //                 },
        //                 {
        //                   label: '客服中心',
        //                   key: 'customerCentreName'
        //                 },
        //                 {
        //                   label: '创建时间',
        //                   key: 'createdAt',
        //                   formatter: 'dateTime',
        //                   params: {
        //                     dataTimeType: 'YYYY-MM-DD HH:mm:ss'
        //                   }
        //                 },
        //                 {
        //                   type: 'handle',
        //                   label: '操作',
        //                   actions: [
        //                     {
        //                       type: 'tableDetail',
        //                       label: '详情',
        //                       emit: 'serviceManagerDetail',
        //                       params: {
        //                         defSn: '8e8bab492cd811eca2b50c42a1da1656',
        //                         dataSnKey: 'attendorSn'
        //                       }
        //                     },
        //                     {
        //                       type: 'tableEdit',
        //                       label: '编辑',
        //                       emit: 'serviceManagerEdit',
        //                       params: {
        //                         defSn: '9227ce0f2cd711eca2b50c42a1da1656',
        //                         dataSnKey: 'attendorSn'
        //                       }
        //                     },
        //                     {
        //                       label: '删除',
        //                       emit: 'serviceManagerDelete',
        //                       show: 'always'
        //                     }
        //                   ]
        //                 }
        //               ]
        //             }
        //           ]
        //         }
        //       }
        //     ]
        //   }
        // ],
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          if (name === '$ready') {
            methods['/title/title-table/setSearchOptions']('cscDefSn', lists);
            return;
          }
          switch (moduleName + '_' + name) {
            // 删除
            case '/title/title-table_tableServiceManagerDelete':
              deleteTip([data[0].row]);
              break;
          }
        }
      });

      onActivated(() => {
        // 刷新页面
        methods && methods['/title/title-table/refresh']?.();
      });

      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
