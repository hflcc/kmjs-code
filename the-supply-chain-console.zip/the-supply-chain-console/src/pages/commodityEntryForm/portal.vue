<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { delData } from './api';
  import { ElMessage, ElMessageBox } from 'element-plus';

  interface TableRow {
    sn: string;
    payment: string;
    payState: string;
    state: string;
    [propName: string]: unknown;
  }
  export default defineComponent({
    name: 'commodityEntryPortal',
    components: {
      kmjsModule
    },
    setup() {
      // 删除数据
      const deleteData = async (arr: any) => {
        let [list] = arr;
        if (list instanceof Array) {
          if (!list.length) {
            ElMessage.error('请选择需要删除的数据');
            return;
          }
        } else {
          list = [list.row ? list.row : {}];
        }
        // 判断是否可以删除
        const isDelete =
          list.filter(
            (item: { auditState: string }) =>
              item.auditState !== 'none' && item.auditState !== 'reject'
          ).length === 0;
        if (!isDelete) {
          ElMessage.error('选中的数据中含有不可删除的数据');
          return;
        }
        // 获取选中数据的单号
        const codes = list.map((item: { brandEnterNo: string }) => item.brandEnterNo).join('、');
        ElMessageBox.confirm(`确认删除商品入驻单【${codes}】吗？`)
          .then(async () => {
            const sns = list.map((item: TableRow) => item.sn).join(',');
            const res = await delData(sns);
            if (res) {
              methods['/title/title-table/refresh']();
              ElMessage.success('删除成功');
            }
          })
          .catch((err) => {
            console.log(err);
          });
      };

      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '商品入驻单-门户',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新建',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: 'cbdac4cc72a8466ead77608034644b80'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/inst/goods/apply/order/page?salesType=portal',
                  items: [
                    {
                      type: 'search',
                      isslot: true,
                      inputs: [
                        {
                          label: '单号',
                          key: 'applyNo',
                          type: 'text'
                        },
                        {
                          label: '平台名称',
                          key: 'platformBizMdInstName',
                          type: 'text'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierInstanceName',
                          type: 'text'
                        },
                        {
                          label: '合同',
                          key: 'bizMdContractInstanceName',
                          type: 'text'
                        },
                        {
                          label: '销售方式',
                          key: 'salesType',
                          type: 'select',
                          dictionaryName: 'inst_goods_sales_type'
                        },
                        {
                          label: '付款方式',
                          key: 'payType',
                          type: 'select',
                          dictionaryName: 'inst_goods_pay_type'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'select',
                          dictionaryName: 'inst_goods_audit_state'
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          type: 'select',
                          dictionaryName: 'inst_goods_pay_state'
                        },
                        {
                          type: 'text',
                          key: 'createdNameBy',
                          label: '创建人'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        },
                        {
                          label: '费用金额',
                          key: 'feeRange',
                          hideAuto: true,
                          type: 'sliderNumber'
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '单号',
                          key: 'applyNo',
                          width: 200
                        },
                        {
                          label: '平台',
                          key: 'platformBizMdInstName'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierInstanceName'
                        },
                        {
                          label: '合同',
                          key: 'bizMdContractInstanceName'
                        },
                        {
                          label: '销售方式',
                          key: 'salesType',
                          type: 'mapText',
                          width: 80,
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'inst_goods_sales_type'
                          }
                        },
                        {
                          label: '付款方式',
                          key: 'payType',
                          type: 'mapText',
                          width: 80,
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'inst_goods_pay_type'
                          }
                        },
                        {
                          label: '审核状态',
                          width: 80,
                          key: 'auditState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'inst_goods_audit_state',
                            showDiaLogIcon: true
                          }
                        },
                        {
                          label: '支付状态',
                          key: 'payState',
                          width: 80,
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'inst_goods_pay_state'
                          }
                        },
                        {
                          label: '费用金额(元)',
                          key: 'applyFee',
                          align: 'right',
                          width: 100,
                          formatter: 'price'
                        },
                        {
                          label: '支付剩余时间',
                          key: 'payExpiredAt',
                          formatter: 'dateTime',
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '创建时间',
                          key: 'createAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdNameBy'
                        },
                        {
                          label: '备注',
                          key: 'description'
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              emit: 'purchaseOrderDetail',
                              label: '详情',
                              params: {
                                defSn: 'bdd21b6f21ca4a99b1d833d348bfc6f3',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              emit: 'purchaseOrderEdit',
                              label: '编辑',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'pending|rejected' //满足的值
                                }
                              ],
                              params: {
                                defSn: 'bea3744595f34ea791854cc7275afaf5',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableBpmStatic',
                              label: '送审',
                              emit: 'submitAudit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'pending' //满足的值
                                }
                              ],
                              params: {
                                defSn: '3101b2b7ae6c11ec8d3eb8599f52bbe4',
                                alertMsg: '确认将商品入驻单（{orderNo}）提交至康美集势审核吗？',
                                successMsg: '【商品入驻单（{orderNo}）】已提交至【康美集势】审核'
                              }
                            },
                            //支付流程未确定
                            {
                              label: '去支付',
                              emit: 'submitAudit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'showSubmitAudit', //key
                                  columnValue: 'true' //满足的值
                                }
                              ]
                            },
                            {
                              label: '删除',
                              emit: 'delData',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState', //key
                                  columnValue: 'pending|rejected' //满足的值
                                }
                              ]
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          emit: 'deleteData'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            dataFormatter: (tableData: TableRow[]): TableRow[] => {
              if (tableData.length) {
                return tableData.map((item) => {
                  //支付方式==预付 && 单据状态==已通过
                  if (item.payment == 'prepay' && item.state == 'pass') {
                    item.showSubmitAudit = 'true';
                  } else {
                    item.showSubmitAudit = 'false';
                  }
                  return item;
                });
              } else {
                return tableData;
              }
            }
          }
        },
        handler: (moduleName, name, data) => {
          if (name === 'tableDelData' || name === 'tableDeleteData') {
            deleteData(data);
          }
          // console.log(moduleName, name, data);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less" scoped>
  /deep/ .el-table .cell {
    padding: 0 14px;
  }
</style>
