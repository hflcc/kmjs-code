import ajax from '@/utils/axios';
/*
 *提审
 */
// export const submitAudit = (sn: string) => {
//   return ajax.put(`/auth/agent/purchase/order/submit/${sn} `, undefined, {
//     params: {
//       $InstId: true
//     }
//   });
// };
/*
 *删除
 */
export const delData = (sns: string) => {
  return ajax.delete(`/auth/md/inst/goods/apply/order/${sns}`, {
    params: {
      $InstId: true
    }
  });
};
