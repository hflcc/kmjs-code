<template>
  <div class="page classify-page" style="padding-top: 20px">
    <h3 class="page-title">
      店铺装修<span class="small">商品分类</span>
      <div class="button-wrapper">
        <el-button size="mini" type="default" @click="handlePreview">预览</el-button>
        <el-button size="mini" type="primary" @click="handleSave">保存</el-button>
      </div>
    </h3>
    <Classify ref="classify" />

    <PreviewCategory v-model="showPreview" :defSn="defSn" />
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import Classify from '@/components/classify/index.vue';
  import { ElMessage } from 'element-plus';
  import { useRoute } from 'vue-router';
  import { postCategory } from '@/pages/shopManage/api';
  import PreviewCategory from '@/pages/shopManage/components/previewCategory.vue';

  export default defineComponent({
    name: 'commodityClassify',
    components: {
      Classify,
      PreviewCategory
    },
    setup() {
      const route = useRoute();
      const shopSn = ref(route.query.shopSn as string);
      const defSn = ref(route.query.defSn as string);

      // 预览
      const showPreview = ref<boolean>(false);

      const classify = ref<InstanceType<typeof Classify> | null>(null);
      function handlePreview() {
        if (check()) {
          showPreview.value = true;
        }
      }

      function handleSave() {
        if (check()) {
          const data = classify.value?.allCategory ?? [];
          postCategory(shopSn.value, defSn.value, data).then((res) => {
            if (res) {
              ElMessage.success('添加成功！');
            }
          });
        }
      }

      function check() {
        const hasError = classify.value?.checkData();
        if (hasError) {
          ElMessage.error('请先完成表单必填项');
          return false;
        }
        return true;
      }

      return {
        showPreview,
        classify,
        close,
        handlePreview,
        handleSave,
        defSn
      };
    }
  });
</script>

<style lang="less">
  .classify-page {
    .page-title {
      display: flex;
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 20px;
      .small {
        font-weight: normal;
        font-size: 16px;
        color: #666;
        margin-left: 20px;
        margin-top: 5px;
      }
    }

    .el-button--mini {
      padding: 7px 15px;
    }

    .button-wrapper {
      flex: 1;
      display: flex;
      justify-content: flex-end;
    }
  }
</style>
