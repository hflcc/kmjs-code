<!-- 店铺装修-页面选择 -->
<template>
  <div class="page" style="padding-top: 20px">
    <h3 class="page-title">店铺装修</h3>
    <el-tabs v-model="activeName" @tab-click="handleClick($event, true)">
      <el-tab-pane
        v-for="item in tabs"
        :key="item.sn"
        :label="item.name"
        :data-type="item.type"
        :name="item.sn"
      />
      <!-- <el-tab-pane label="其他" name="other" data-type="INFO_FLOW" /> -->
    </el-tabs>
    <el-tabs v-model="childrenActive" @tab-click="handleClick($event, false)">
      <el-tab-pane label="过审页面" name="accept" />
      <el-tab-pane label="草稿页面" name="wait,in_progress,reject" />
    </el-tabs>

    <div class="create-button">
      <el-button type="primary" size="mini" @click="showCreateDialog">新增页面</el-button>
    </div>

    <!-- INFO_FLOW 和 OTHER 都是信息流页面， GOODS_CATEGORY 表示商品分类 -->
    <kmjsModule v-if="showPage && showInfoFlow" :ctl="moduleCtl" />
    <kmjsModule v-if="showPage && currentType === 'GOODS_CATEGORY'" :ctl="categoryCtl" />

    <el-dialog
      v-model="showDialog"
      @close="closeDialog"
      title="提示"
      width="30%"
      top="20vh"
      custom-class="custom-class"
    >
      <el-form ref="addFormEl" :model="addForm" label-width="80px">
        <el-form-item label="页面名称" prop="name">
          <el-input
            class="custom-input"
            v-model="addForm.name"
            placeholder="请输入页面名称，长度不超过25个字符"
            :maxlength="25"
            show-word-limit
          />
        </el-form-item>
        <el-form-item label="页面备注" prop="description">
          <el-input
            v-model="addForm.description"
            placeholder="页面备注"
            type="textarea"
            :maxlength="255"
            show-word-limit
            rows="6"
            :input-style="{ marginBottom: '20px' }"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="closeDialog">取 消</el-button>
          <el-button type="primary" @click="dialogConfirm">确 定</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 预览分类 -->
    <PreviewCategory v-model="showPreview" :defSn="defSn" />
  </div>
</template>

<script lang="ts">
  import {
    ComponentInternalInstance,
    computed,
    defineComponent,
    onMounted,
    reactive,
    ref,
    UnwrapRef
  } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import {
    addShopPage,
    copyShopPage,
    DefPage,
    deleteShopPage,
    getPageInfo,
    getShopPageTab,
    goRenovation,
    updateShopPage,
    updateShopPageStatus
  } from '@/pages/shopManage/api';
  import { useRoute, useRouter } from 'vue-router';
  import { ElForm, ElMessage, ElMessageBox } from 'element-plus';
  import PreviewCategory from '@/pages/shopManage/components/previewCategory.vue';

  interface TableRow {
    auditState: 'wait' | 'in_progress' | 'accept' | 'reject';
    state: 'on' | 'off';
    description: string;
    contractNo: string;
    name: string;
    sn: string;
    updatedAt: string;
    value: string;
    appId: string;
    instId: number;
    [propName: string]: unknown;
  }

  export default defineComponent({
    name: 'shopPageSelection',
    components: {
      kmjsModule,
      PreviewCategory
    },
    setup() {
      const route = useRoute();
      const router = useRouter();
      const shopSn = route.query.shopSn as string;
      const showPage = ref<boolean>(false);

      const showPreview = ref<boolean>(false);
      const defSn = ref<string>('');

      // 展示信息流的列表
      const showInfoFlow = computed<boolean>(
        () => currentType.value === 'INFO_FLOW' || currentType.value === 'OTHER'
      );

      // dialog
      const addFormEl = ref<null | InstanceType<typeof ElForm>>(null);
      const addForm = reactive({
        name: '',
        description: ''
      });
      const showDialog = ref<boolean>(false);
      // 是否是编辑模式
      const isUpdatePage = ref<boolean>(false);
      const isCopy = ref<boolean>(false);
      function closeDialog() {
        showDialog.value = false;
        addForm.name = '';
        addForm.description = '';
      }
      function dialogConfirm() {
        // 新增页面
        if (!isUpdatePage.value && !isCopy.value) {
          // const defPageSn = activeName.value === 'other' ? '' : activeName.value;
          const defPageSn = activeName.value;
          addShopPage(shopSn, defPageSn, addForm).then((res) => {
            if (res) {
              // ElMessage.success('操作成功');
              handleClick();
              getPageInfo(res.sn as string).then((res) => {
                if (res.type === 'INFO_FLOW' || res.type === 'OTHER') {
                  jumpRenovation(res.value, res.instId, res.appId);
                } else if (res.type === 'GOODS_CATEGORY') {
                  router.push({
                    path: 'commodityClassify',
                    query: { defSn: res.value, shopSn: res.shopSn }
                  });
                }
              });
            }
          });
        } else if (isCopy.value) {
          // 复制页面
          copyShopPage(currentSn.value, addForm).then((res) => {
            if (res) {
              handleClick();
              ElMessage.success('操作成功');
            }
          });
        } else {
          // 修改页面
          updateShopPage(currentSn.value, addForm).then((res) => {
            if (res) {
              handleClick();
              ElMessage.success('操作成功');
            }
          });
        }
        closeDialog();
      }
      function showCreateDialog() {
        isUpdatePage.value = false;
        showDialog.value = true;
      }

      // 获取一级tab列表
      const tabs = ref<DefPage[]>([]);
      function _getShopPageTab() {
        getShopPageTab(shopSn).then((res) => {
          if (res && res.length) {
            // activeName.value = res[0].sn || 'other';
            activeName.value = res[0].sn;
            currentType.value = res[0].type || 'INFO_FLOW';
            tabs.value = res;
          } else {
            activeName.value = '';
            currentType.value = 'INFO_FLOW';
          }
          showPage.value = true;
        });
      }

      const activeName = ref<string>('');
      const childrenActive = ref<string>('accept');
      const currentType = ref<string>(''); // 当前类型标识，区分信息流还是分类
      function handleClick(
        tab?: UnwrapRef<{ instance: ComponentInternalInstance }>,
        flag?: boolean
      ) {
        if (flag) {
          currentType.value = (tab?.instance.attrs['data-type'] as string) || '';
        }
        showInfoFlow.value
          ? methods['/table1/refresh']()
          : draftMethods['/table2/refresh'] && draftMethods['/table2/refresh']();
      }

      const [moduleCtl, methods] = useModule({
        config: [
          {
            name: 'table1',
            type: 'table',
            params: {
              tableDataUrl: '/auth/md/shop/page/page',
              items: [
                {
                  type: 'table',
                  tableHead: [
                    {
                      type: 'text',
                      label: '页面名称',
                      key: 'name'
                    },
                    {
                      label: '页面状态',
                      key: 'status',
                      type: 'mapText',
                      params: {
                        type: 'local',
                        localData: {
                          on: '已发布',
                          off: '未发布',
                          wait: '待审核',
                          in_progress: '审核中',
                          accept: '已通过',
                          reject: '已驳回'
                        }
                      }
                    },
                    {
                      label: '更新时间',
                      key: 'updatedAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                      }
                    },
                    {
                      label: '备注',
                      key: 'description'
                    },
                    {
                      type: 'handle',
                      label: '操作',
                      fixed: 'right',
                      actions: [
                        {
                          label: '装修',
                          emit: 'pageRenovation',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'wait|reject'
                            }
                          ]
                        },
                        {
                          type: 'tableBpmStatic',
                          label: '送审',
                          emit: 'toSubmit',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'wait|reject'
                            }
                          ],
                          params: {
                            defSn: 'd6e83f97684c11ec8d3eb8599f52bbe4',
                            alertMsg: '是否将（{name}）提交至康美集势平台审核？',
                            successMsg: '已提交至【康美集势】审核'
                          }
                        },
                        {
                          label: '发布',
                          emit: 'release',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off'
                            }
                          ]
                        },
                        {
                          label: '预览',
                          emit: 'pagePreview',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off|wait|in_progress|reject'
                            }
                          ]
                        },
                        {
                          label: '编辑',
                          emit: 'edit',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off|wait|reject'
                            }
                          ]
                        },
                        {
                          label: '复制页面',
                          emit: 'copy',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'on|off|in_progress'
                            }
                          ]
                        },
                        {
                          label: '删除',
                          emit: 'delete',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off|wait|reject'
                            }
                          ]
                        },
                        {
                          label: '下架',
                          emit: 'disabled',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'on'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ],
        params: {
          '/table1': {
            beforeRequest: (obj: { [index: string]: unknown }) => {
              obj.url = `${obj.url}?shopSn=${shopSn}&auditState=${childrenActive.value}&shopDefSn=${activeName.value}`;
              return Promise.resolve(obj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          const { row = {} } = data[0] || {};
          const obj = row as TableRow;
          handleMethods(name, obj);
          // handlers[name] && handlers[name](obj, methods);
        }
      });

      const [categoryCtl, draftMethods] = useModule({
        config: [
          {
            name: 'table2',
            type: 'table',
            params: {
              tableDataUrl: '/auth/md/shop/page/page',
              items: [
                {
                  type: 'table',
                  tableHead: [
                    {
                      type: 'text',
                      label: '页面名称',
                      key: 'name'
                    },
                    {
                      label: '页面状态',
                      key: 'status',
                      type: 'mapText',
                      params: {
                        type: 'local',
                        localData: {
                          on: '已发布',
                          off: '未发布',
                          wait: '待审核',
                          in_progress: '审核中',
                          accept: '已通过',
                          reject: '已驳回'
                        }
                      }
                    },
                    {
                      label: '更新时间',
                      key: 'updatedAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                      }
                    },
                    {
                      label: '备注',
                      key: 'description'
                    },
                    {
                      type: 'handle',
                      label: '操作',
                      fixed: 'right',
                      actions: [
                        {
                          label: '装修',
                          emit: 'renovation',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'wait|reject'
                            }
                          ]
                        },
                        {
                          type: 'tableBpmStatic',
                          label: '送审',
                          emit: 'toSubmit',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'wait|reject'
                            }
                          ],
                          params: {
                            defSn: 'd6e83f97684c11ec8d3eb8599f52bbe4',
                            alertMsg: '是否将（{name}）提交至康美集势平台审核？',
                            successMsg: '已提交至【康美集势】审核'
                          }
                        },
                        {
                          label: '复制页面',
                          emit: 'copy',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'on|off|in_progress'
                            }
                          ]
                        },
                        {
                          label: '预览',
                          emit: 'preview'
                        },
                        {
                          label: '编辑',
                          emit: 'edit',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off|wait|reject'
                            }
                          ]
                        },
                        {
                          label: '删除',
                          emit: 'delete',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off|wait|reject'
                            }
                          ]
                        },
                        {
                          label: '发布',
                          emit: 'release',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'off'
                            }
                          ]
                        },
                        {
                          label: '下架',
                          emit: 'disabled',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'status',
                              columnValue: 'on'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ],
        params: {
          '/table2': {
            beforeRequest: (obj: { [index: string]: unknown }) => {
              obj.url = `${obj.url}?shopSn=${shopSn}&auditState=${childrenActive.value}&shopDefSn=${activeName.value}`;
              return Promise.resolve(obj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          const { row = {} } = data[0] || {};
          const obj = row as TableRow;
          handleMethods(name, obj);
        }
      });

      function handleMethods(name: string, row: TableRow) {
        switch (name) {
          case 'tableEdit':
            editPage(row);
            break;
          case 'tableDelete':
            deletePage(row);
            break;
          case 'tableRelease':
          case 'tableDisabled':
            updatePageStatus(row);
            break;
          case 'tableCopy':
            copyPage(row);
            break;
          case 'tableRenovation': // 分类装修
            router.push({
              path: 'commodityClassify',
              query: { defSn: row.value, shopSn: shopSn }
            });
            break;
          case 'tablePreview':
            defSn.value = row.value;
            showPreview.value = true;
            break;
          case 'tablePageRenovation': // 页面装修跳转信息流页面
            row.value && jumpRenovation(row.value, row.instId, row.appId);
            break;
          case 'tablePagePreview': // 页面装修预览
            row.value && window.open(`https://info-flow-dev.kmyun.cn/?infoFlowSn=${row.value}`);
            break;
          default:
            break;
        }
      }

      // 跳转信息流页面
      function jumpRenovation(value: string, instId: number, appId: string) {
        goRenovation({
          decorateSn: shopSn,
          decorateInfoFlowSn: value,
          instId: instId, // 机构id
          appId: appId,
          path: '/infoflow/index',
          decorateType: 'shop_home',
          relationType: 'shop',
          relationValue: shopSn
        }).then((res) => {
          if (res) {
            window.open(res.url);
          }
        });
      }

      // 编辑页面
      const currentSn = ref<string>('');
      async function editPage(row: TableRow, copy = false) {
        isUpdatePage.value = copy ? false : true;
        isCopy.value = copy;
        const { sn, name, description } = await getPageInfo(row.sn);
        currentSn.value = sn;
        addForm.name = name;
        addForm.description = description;
        showDialog.value = true;
      }

      // 删除页面
      function deletePage(row: TableRow) {
        ElMessageBox.confirm(`确定要将【${row.name}】页面从平台删除吗？`)
          .then(async () => {
            const res = await deleteShopPage(row.sn);
            if (res) {
              handleClick();
              ElMessage.success('操作成功');
            }
          })
          .catch((err) => {
            console.log(err);
          });
      }

      // 页面上下架
      function updatePageStatus(row: TableRow) {
        const state = row.state === 'off' ? 'on' : 'off';
        const message =
          row.state === 'off'
            ? `确定要将【${row.name}】页面发布吗？`
            : `确定要将【${row.name}】页面下架吗`;
        ElMessageBox.confirm(message)
          .then(async () => {
            const res = await updateShopPageStatus(row.sn, state);
            if (res) {
              handleClick();
              ElMessage.success('操作成功');
            }
          })
          .catch((err) => {
            console.log(err);
          });
      }

      // 复制页面
      function copyPage(row: TableRow) {
        editPage(row, true);
      }

      onMounted(() => {
        _getShopPageTab();
      });

      return {
        moduleCtl,
        categoryCtl,
        handleClick,
        childrenActive,
        addFormEl,
        tabs,
        activeName,
        showDialog,
        addForm,
        showPage,
        currentType,
        closeDialog,
        dialogConfirm,
        showCreateDialog,
        showPreview,
        defSn,
        showInfoFlow
      };
    }
  });
</script>

<style lang="less">
  .page-title {
    font-size: 20px;
    font-weight: bolder;
    cursor: pointer;
  }
  .create-button {
    margin-bottom: 20px;
    margin-right: 20px;
    text-align: right;
  }

  .custom-class {
    .el-dialog__body {
      padding-right: 30px;
    }
  }
  .custom-input {
    .el-input__suffix {
      top: 28px;
    }
  }
</style>
