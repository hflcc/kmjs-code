<!-- 店铺设置-商品列表 -->
<template>
  <div class="page commodity" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl">
      <!-- 售价 -->
      <template #priceRangeValue="{ row }">
        <span>{{ formatterPrice(row.minPrice) }}-{{ formatterPrice(row.maxPrice) }}</span>
      </template>
    </kmjsModule>

    <EditPrice
      v-model="showPrice"
      :shopName="currentShopName"
      :shopGoodsState="shopGoodsState"
      :skuSn="currentSkuSn"
    />
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import EditPrice from '@/pages/shopManage/components/editPrice.vue';
  import { useRoute } from 'vue-router';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { updateGoodsStatus, deleteGoods, TableRow } from '@/pages/shopManage/api';
  import { formatterPrice, isEmpty, useDEToLRefresh } from '@/utils';
  import store from '@/store';
  import { goToFormCreate } from '@/pages/commonPage';

  export default defineComponent({
    name: 'shopCommodity',
    components: {
      kmjsModule,
      EditPrice
    },
    setup() {
      const route = useRoute();
      const shopSn = route.query.shopSn as string;
      const { setCallBack } = useDEToLRefresh();
      const showPrice = ref<boolean>(false);
      const currentShopName = ref<string>('');
      const shopGoodsState = ref<string>('');
      const currentSkuSn = ref<string>('');

      const flag = ref<boolean>(false);

      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '管理店铺商品',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'addShop',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '21a58d6bfc3542e596178ce174faa757'
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/shop/goods/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '商品名称',
                          key: 'name',
                          type: 'text'
                        },
                        {
                          label: '品牌',
                          key: 'brand',
                          type: 'text'
                        },
                        {
                          label: '状态',
                          key: 'shopGoodsState',
                          type: 'select',
                          options: [
                            {
                              label: '已上架',
                              value: 'on'
                            },
                            {
                              label: '待上架',
                              value: 'off'
                            }
                          ]
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableConfig: {
                        // 是否启用扩展展示
                        isExpand: true,
                        // 扩展展示的组件
                        templateName: 'goodsSku'
                      },
                      tableHead: [
                        {
                          label: '商品名称',
                          key: 'name'
                        },
                        {
                          label: '品牌',
                          key: 'brand'
                        },
                        {
                          label: '类目',
                          key: 'category'
                        },
                        {
                          type: 'image',
                          label: '图片',
                          key: 'ossId',
                          params: {
                            width: '40px'
                          }
                        },
                        {
                          label: '所属店铺',
                          key: 'shopName'
                        },
                        {
                          label: '状态',
                          width: 80,
                          key: 'shopGoodsState',
                          type: 'mapText',
                          params: {
                            type: 'local',
                            localData: {
                              on: '已上架',
                              off: '待上架'
                            }
                          }
                        },
                        {
                          label: '库存',
                          key: 'saledCount'
                        },
                        {
                          type: 'slot',
                          label: '售价',
                          key: 'priceRange'
                        },
                        {
                          label: '操作时间',
                          key: 'updatedAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '操作人',
                          key: 'createName'
                        },
                        {
                          label: '备注',
                          key: 'remark'
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              label: '编辑',
                              emit: 'goEditPage',
                              show: 'always'
                            },
                            {
                              label: '上架',
                              emit: 'changeState',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'shopGoodsState',
                                  columnValue: 'off'
                                }
                              ]
                            },
                            {
                              label: '下架',
                              emit: 'changeState',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'shopGoodsState',
                                  columnValue: 'on'
                                }
                              ]
                            },
                            {
                              label: '移除',
                              emit: 'deleteGoods',
                              show: 'always'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                slotParam: [
                  {
                    name: 'priceRange',
                    slotName: 'priceRangeValue'
                  }
                ]
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            beforeRequest: (obj: { [index: string]: unknown }) => {
              (obj.params as { [key: string]: string }).shopSn = shopSn;
              return Promise.resolve(obj);
            },
            dataFormatter: (data: TableRow[]) => {
              return data.map((s) => {
                s.skus &&
                  s.skus.map((item) => {
                    item.checked = false;
                    if (item.icon && item.icon.includes('http')) {
                      item.image = item.icon;
                    } else if (item.icon && !isEmpty(item.icon)) {
                      store.dispatch('source/getOssUrl', [item.icon]).then((res) => {
                        if (res) {
                          item.image = res[item.icon].url;
                          item.checked = false;
                        }
                      });
                    }
                  });
                return s;
              });
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);

          let rowData = {} as TableRow;
          let isChecked = false;
          if (name.includes('Sku')) {
            currentShopName.value = data.length && data[0].shopName;
            shopGoodsState.value = data.length && data[0].shopGoodsState;

            // data是sku复选框的选择结果
            rowData = (data.length && data[0].sku) || (data.length && data[0].data) || {};
          } else {
            // data是外层table复选框的选择结果
            rowData = (data.length && data[0].row) || (data.length && data[0].data) || {};
            isChecked = (data.length && data[0].checked) || false;
          }

          let allData: Array<{ data: TableRow; checked: boolean }> = [];
          if (name === 'tableTriggerCheckAll') {
            allData = data[0];
          }

          currentSkuSn.value = rowData.sn;

          const type = rowData.shopGoodsState === 'off' ? 'on' : 'off';
          const message =
            rowData.shopGoodsState === 'off'
              ? `确定要将【${rowData.name}】页面上架吗？`
              : `确定要将【${rowData.name}】页面下架吗`;

          let url = '';

          switch (name) {
            case 'tableSkuAdjust': // 商品sku调价
              showPrice.value = true;
              break;
            case 'tableChangeState': // 商品上下架
              ElMessageBox.confirm(message)
                .then(async () => {
                  const res = await updateGoodsStatus(shopSn, rowData.sn, type);
                  if (res) {
                    methods['/title/title-table/refresh']();
                    ElMessage.success('操作成功');
                  }
                })
                .catch((err) => {
                  console.log(err);
                });
              break;
            case 'tableDeleteGoods': // 删除商品
              url = `/md/shop/goods/goods/${shopSn}/${rowData.sn}`;
              handleDelete(url, rowData.name);
              break;
            case 'tableSkuDelete': // 删除商品sku
              url = `/md/shop/goods/sku/${shopSn}/${rowData.sn}`;
              handleDelete(url, rowData.name);
              break;
            case 'tableSkuChange': // sku 复选框选择
              flag.value = true;
              methods['/title/title-table/setCheckDisabled']?.(
                rowData.index,
                undefined,
                rowData.checked
              );
              flag.value = false;
              break;
            case 'tableCheckboxChange': // 表格数据复选框选择
              if (!flag.value) {
                rowData.skus &&
                  rowData.skus.forEach((item) => {
                    // 外层数据是否全选
                    if (isChecked) {
                      item.checked = true;
                    } else {
                      item.checked = false;
                    }
                  });
              }
              break;
            case 'tableTriggerCheckAll': // 表格全选
              allData.length &&
                allData.forEach((item) => {
                  item.data.skus &&
                    item.data.skus.forEach((element) => {
                      element.checked = item.checked;
                    });
                });
              console.log(allData);
              break;
            case 'addShop':
              goToFormCreate('21a58d6bfc3542e596178ce174faa757', {
                ...setCallBack(() => {
                  methods['/title/title-table/refresh']();
                }),
                sn: shopSn
              });
              break;
            default:
              break;
          }
        }
      });

      function handleDelete(url: string, name: string) {
        ElMessageBox.confirm(`确认要将【${name}】删除吗？`)
          .then(async () => {
            const res = await deleteGoods(url);
            if (res) {
              methods['/title/title-table/refresh']();
              ElMessage.success('操作成功');
            }
          })
          .catch((err) => {
            console.log(err);
          });
      }

      return {
        moduleCtl,
        showPrice,
        currentShopName,
        shopGoodsState,
        currentSkuSn,
        formatterPrice
      };
    }
  });
</script>

<style lang="less">
  .commodity {
    .el-table__expanded-cell[class*='cell'] {
      padding: 6px 0;
    }
  }
</style>
