<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>

    <el-dialog v-model="showSettingDialog" title="请选择" width="400px" top="20vh">
      <div class="setting-container">
        <div class="button-wrapper">
          <el-button type="primary" plain size="mini" @click="informationChange">
            信息变更
          </el-button>
          <el-button type="primary" plain size="mini" @click="freightSetting">运费设置</el-button>
        </div>
        <div class="button-wrapper">
          <el-button type="primary" plain size="mini" @click="commodityManage">商品管理</el-button>
          <el-button type="primary" plain size="mini" @click="serviceSettings">客服设置</el-button>
        </div>
        <div class="button-wrapper">
          <el-button type="primary" plain size="mini" @click="pageSelect">店铺装修</el-button>
          <el-button type="primary" plain size="mini" @click="changeShopState">打烊/经营</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { associateInstId, changeShopState } from '@/pages/shopManage/api';
  import { onBeforeRouteLeave, useRouter } from 'vue-router';
  import { goToCreateBpmByBusiness, goToFormEdit } from '@/pages/commonPage';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: TableRow, methods: Methods) => void;
  }
  interface TableRow {
    auditState: 'wait' | 'in_progress' | 'accept' | 'reject';
    contractName: string;
    contractNo: string;
    createName: string;
    createdAt: string;
    instName: string;
    operateState: 'on' | 'off';
    remark: string;
    shopDefName: string;
    shopName: string;
    shopNo: string;
    shopSn: string;
    supplierName: string;
    [propName: string]: unknown;
  }

  // 店铺打烊/经营
  const _changeShopState = (
    shopSn: TableRow['shopSn'],
    state: TableRow['operateState'],
    cb?: Fn
  ): void => {
    const allow = ['on', 'off'];
    if (!allow.includes(state)) return;
    let sureText = '';
    let fixState = '';
    switch (state) {
      case 'on': // 营业中
        sureText = '确认要打烊该店铺吗？';
        fixState = 'off';
        break;
      case 'off': // 打烊
        sureText = '确认要开始经营该店铺吗？';
        fixState = 'on';
        break;
      default:
        break;
    }
    ElMessageBox.confirm(sureText)
      .then(async () => {
        const res = await changeShopState(shopSn, fixState);
        if (res) {
          cb && cb();
          ElMessage.success('操作成功');
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  export default defineComponent({
    name: 'shopManageIndex',
    components: {
      kmjsModule
    },
    setup() {
      const currentShopSn = ref<string>('');
      const operateState = ref<'on' | 'off'>('off');
      const handlers: Handlers = {
        // 走流程，不直接走接口
        // // 店铺审核
        // tableShopToAudit: (row) => {
        //   const message = `是否将${row.shopName}提交至康美集势平台审核？`;
        //   ElMessageBox.confirm(message)
        //     .then(async () => {
        //       const res = await changeShopState(row.shopSn, 'apply');
        //       if (res) {
        //         methods['/title/title-table/refresh']();
        //         ElMessage.success('操作成功');
        //       }
        //     })
        //     .catch((err) => {
        //       console.log(err);
        //     });
        // },
        // 设置店铺
        tableSetting: (row) => {
          if (row.auditState !== 'accept') {
            return false;
          }
          currentShopSn.value = row.shopSn;
          operateState.value = row.operateState;
          showSettingDialog.value = true;
        }
      };

      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '店铺管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '70a3c22df30d4aa9a1d8574c94e40856'
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/shop/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '编号',
                          key: 'shopNo',
                          type: 'text'
                        },
                        {
                          label: '名称',
                          key: 'shopName',
                          type: 'text'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'select',
                          options: [
                            {
                              label: '待审核',
                              value: 'wait'
                            },
                            {
                              label: '审核中',
                              value: 'in_progress'
                            },
                            {
                              label: '已通过',
                              value: 'accept'
                            },
                            {
                              label: '已驳回',
                              value: 'reject'
                            }
                          ]
                        },
                        {
                          label: '经营状态',
                          key: 'operateState',
                          type: 'select',
                          options: [
                            {
                              label: '经营',
                              value: 'on'
                            },
                            {
                              label: '打烊',
                              value: 'off'
                            }
                          ]
                        },
                        {
                          label: '类型',
                          key: 'shopDefSn',
                          type: 'select',
                          options: []
                        },
                        {
                          label: '创建人',
                          key: 'createName',
                          type: 'text'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'shopNo'
                        },
                        {
                          label: '名称',
                          key: 'shopName'
                        },
                        {
                          label: '平台',
                          key: 'instName'
                        },
                        {
                          label: '供应商',
                          key: 'supplierName'
                        },
                        {
                          label: '合同',
                          key: 'contractName'
                        },
                        {
                          label: '类型',
                          key: 'shopDefName'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'shop_audit_state',
                            showDiaLogIcon: true
                          }
                        },
                        {
                          label: '经营状态',
                          type: 'mapText',
                          key: 'operateState',
                          params: {
                            type: 'local',
                            localData: {
                              on: '经营',
                              off: '打烊'
                            }
                          }
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '备注',
                          key: 'remark',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              show: 'always',
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'goDetailPage',
                              params: {
                                defSn: 'ff53f0166ab249229c1deafae5c51aa6',
                                dataSnKey: 'shopSn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'goEditPage',
                              params: {
                                defSn: '6f7bb9c4c25e4aba9a54b2c26ce47a1d',
                                dataSnKey: 'shopSn'
                              },
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait|reject'
                                }
                              ]
                            },
                            {
                              type: 'tableBpmStatic',
                              label: '送审',
                              emit: 'shopToAudit',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait|reject'
                                }
                              ],
                              params: {
                                defSn: 'e9c773035be911ec8d3eb8599f52bbe4',
                                dataSnKey: 'shopSn',
                                alertMsg: '是否将（{shopName}）提交至康美集势平台审核？',
                                successMsg: '已提交至【康美集势】审核'
                              }
                            },
                            {
                              type: 'unclickable',
                              label: '设置',
                              emit: 'setting',
                              params: {
                                tip: '店铺需要审核通过后，才可以编辑'
                              },
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'accept'
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          const { row = {} } = data[0] || {};
          const obj = row as TableRow;
          handlers[name] && handlers[name](obj, methods);

          // 设置搜索选项的值
          if (name === '$ready') {
            associateInstId().then((res) => {
              if (!res) return;
              res = res.map((item) => {
                return {
                  label: item.name,
                  value: item.sn
                };
              });
              methods['/title/title-table/setSearchOptions']('shopDefSn', res);
            });
          }
        }
      });

      // 店铺设置
      const router = useRouter();
      const showSettingDialog = ref<boolean>(false);

      // 客服设置
      function serviceSettings() {
        goToFormEdit('4d773bb3b5b4469981f0f599b56dd131', currentShopSn.value, {
          b: 'shopManageIndex'
        });
      }
      // 信息变更流程
      function informationChange() {
        goToCreateBpmByBusiness('6227cd005bea11ec8d3eb8599f52bbe4', currentShopSn.value);
      }
      // 运费设置
      function freightSetting() {
        goToFormEdit('50d6f865713345bca05fedadbf67ccbf', currentShopSn.value);
      }
      // 更改店铺状态
      function changeShopState() {
        showSettingDialog.value = false;
        _changeShopState(
          currentShopSn.value,
          operateState.value,
          methods['/title/title-table/refresh']
        );
      }
      // 跳转店铺商品列表
      function commodityManage() {
        router.push({
          path: 'shopCommodity',
          query: { shopSn: currentShopSn.value }
        });
      }
      // 跳转店铺装修-页面选择列表
      function pageSelect() {
        router.push({
          path: 'shopPageSelection',
          query: { shopSn: currentShopSn.value }
        });
      }

      onBeforeRouteLeave(() => {
        showSettingDialog.value = false;
      });

      return {
        showSettingDialog,
        moduleCtl,
        serviceSettings,
        informationChange,
        freightSetting,
        changeShopState,
        commodityManage,
        pageSelect
      };
    }
  });
</script>
<style lang="less">
  .setting-container {
    .button-wrapper {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
      button {
        margin: 0 20px;
      }
    }
  }
</style>
