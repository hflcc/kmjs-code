import { CategoryInfo } from '@/components/classify/api';
import ajax from '@/utils/axios';

export interface DefPage {
  descr: string;
  icon: string;
  name: string;
  sn: string;
  sort: string;
  type: string;
}

export interface SkuInfo {
  brandName: string;
  categoryName: string;
  goodsName: string;
  icon: string;
  name: string;
  price: number;
  remark: string;
  retailPrice: number;
  saledCount: number;
  stockCount: number;
  stepPrices?: { min: string; max: string; price: string }[];
}

export interface TableRow {
  bizMdGoodsSn: string;
  bizMdInstSn: string;
  brand: string;
  category: string;
  categorySn: string;
  createBy: number;
  createName: string;
  deliverFeeType: string;
  deliverFeeValue: string;
  deliverPaymentType: string;
  goodsType: string;
  id: number;
  imported: boolean;
  name: string;
  ossId: string;
  releasedAt: number;
  remark: string;
  shippingAddress: string;
  shopGoodsState: string;
  shopName: string;
  shopSn: string;
  skus: GoodsSkus[];
  sn: string;
  sort: number;
  state: string;
  unit: string;
  updatedAt: number;
  checked: boolean;
  saledCount: number;
  minPrice: number;
  maxPrice: number;
  index: number;
}

export interface GoodsSkus {
  checked: boolean;
  brandName: string;
  brandSn: string;
  categoryName: string;
  categorySn: string;
  goodsName: string;
  goodsSn: string;
  icon: string;
  id: number;
  model: string;
  volume: number;
  weight: number;
  name: string;
  price: number;
  retailPrice: number;
  sn: string;
  specSns: string;
  stockCount: number;
  image: string;
  isDelete: boolean;
  stepPrices: {
    calculation: string;
    goodsId: number;
    max: number;
    min: number;
    price: number;
    skuId: number;
    sn: string;
  }[];
}

interface result {
  message: string;
  sn: string | null;
  success: boolean;
}

export interface SkuPrice {
  price: string | number;
  retailPrice: string | number;
  remark: string;
  stepPriceItems: { min: string; max: string; price: string }[];
}
interface RenovationData {
  decorateSn: string;
  decorateInfoFlowSn: string;
  instId: number | string;
  appId: string;
  path: string;
  decorateType: string;
  relationType: string;
  relationValue: string;
}
interface RenovationResData {
  token: string; // 临时token
  appId: string; // 当前平台id
  targetAppId: string; // 目标平台id
  state: string; // 状态：未使用，已使用，已过期
  expireAt: number; // 过期时间(秒)
  url: string; // url
  data: string; // 额外参数
}

/*
 *当前机构绑定的平台机构列表
 */
export const associateInstId = (): Promise<
  { description?: string; name?: string; sn?: string; label?: string; value?: string }[]
> => {
  return ajax.get('/auth/md/shop/def/list', {
    params: {
      $InstId: true
    }
  });
};

/**
 * 店铺状态修改：经营 打烊 送审
 * type：on 经营，off 打样，apply 送审
 */
export const changeShopState = (shopSn: string, type: string): Promise<result> => {
  return ajax.put(`/auth/md/shop/${shopSn}/${type}`, undefined, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 获取店铺页面选择一级tab信息
 */
export const getShopPageTab = (shopSn: string): Promise<DefPage[]> => {
  return ajax.get(`/auth/md/shop/def/page/list/${shopSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 页面选择-新建页面
 * @param shopSn 店铺sn
 * @param defPageSn tab 对应的sn值
 * @param data 表单数据
 */
export const addShopPage = (
  shopSn: string,
  defPageSn: string,
  data: { name: string; description: string }
): Promise<result> => {
  return ajax.post(`/auth/md/shop/page/${shopSn}?defPageSn=${defPageSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 页面选择-查详情
 */
export const getPageInfo = (
  sn: string
): Promise<{
  auditState: string;
  description: string;
  name: string;
  sn: string;
  state: string;
  updatedAt: number;
  shopSn: string;
  appId: string;
  instId: number;
  status: string;
  type: string;
  value: string;
}> => {
  return ajax.get(`/auth/md/shop/page/${sn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 页面选择-修改页面
 * @param shopSn 店铺sn
 * @param defPageSn tab 对应的sn值
 * @param data 表单数据
 */
export const updateShopPage = (
  sn: string,
  data: { name: string; description: string }
): Promise<result> => {
  return ajax.put(`/auth/md/shop/page/${sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 页面选择-删除页面
 */
export const deleteShopPage = (sn: string): Promise<result> => {
  return ajax.delete(`/auth/md/shop/page/${sn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 页面选择-上下架
 * 操作类型 apply("送审") on("上架") off("下架")
 */
export const updateShopPageStatus = (sn: string, type: string): Promise<result> => {
  return ajax.put(
    `/auth/md/shop/page/operate/${sn}/${type}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

/**
 * 页面选择-复制页面
 */
export const copyShopPage = (
  sn: string,
  data: { name: string; description: string }
): Promise<result> => {
  return ajax.post(`/auth/md/shop/page/copy/${sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 跳转店铺装修系统
 * @param jumpDefSn 暂时固定 `c27af9ee321311eca2b50c42a1da1656`
 * @param data RenovationData
 */
export const goRenovation = (
  data: RenovationData,
  jumpDefSn = 'c27af9ee321311eca2b50c42a1da1656'
): Promise<RenovationResData> => {
  return ajax.post(`/auth/sys/auth/app/jump/instance/${jumpDefSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 添加分类
 */
export const postCategory = (
  shopSn: string,
  defSn: string,
  data: CategoryInfo[]
): Promise<result> => {
  return ajax.post(`/auth/md/shop/category/batch/${shopSn}/${defSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 预览分类
 */
export const previewCategory = (defSn: string): Promise<CategoryInfo[]> => {
  return ajax.get(`/auth/md/common/shop/category/preview/${defSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 商品管理-上下架
 * type: on、off 上架、下架
 * sku: PUT /md/shop/goods/sku/{shopSn}/{skuSn}/{type}
 */
export const updateGoodsStatus = (
  shopSn: string,
  goodsSn: string,
  type: string
): Promise<result> => {
  return ajax.put(
    `/auth/md/shop/goods/goods/${shopSn}/${goodsSn}/${type}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

/**
 * 商品管理-删除商品
 */
export const deleteGoods = (url: string): Promise<result> => {
  return ajax.delete(`/auth/${url}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 查询sku信息
 */
export const getSkuInfo = (skuSn: string): Promise<SkuInfo> => {
  return ajax.get(`/auth/md/shop/goods/sku/${skuSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 修改sku信息
 */
export const updateGoodsSku = (skuSn: string, data: SkuPrice): Promise<result> => {
  return ajax.put(`/auth/md/shop/goods/sku/${skuSn}`, data, {
    params: {
      $InstId: true
    }
  });
};
