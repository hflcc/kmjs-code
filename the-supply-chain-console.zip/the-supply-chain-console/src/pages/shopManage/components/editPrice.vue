<template>
  <el-dialog v-model="showDialog" title="编辑" @close="closeWindow" width="50%" top="6vh">
    <div class="editprice">
      <el-form :model="priceFrom" :rules="priceInfoFormRule" ref="editForm" label-width="140px">
        <p class="text">
          <span class="title">品牌：</span>
          <span>{{ skuInfo.brandName }}</span>
        </p>
        <p class="text">
          <span class="title">名称：</span>
          <span>{{ skuInfo.goodsName }}</span>
        </p>
        <p class="text">
          <span class="title">规格：</span>
          <span>{{ skuInfo.name }}</span>
        </p>
        <p class="text">
          <span class="title">图片：</span>
          <img class="img" :src="skuInfo.icon" />
        </p>
        <p class="text">
          <span class="title">所属店铺：</span>
          <span>{{ shopName }}</span>
        </p>
        <p class="text">
          <span class="title">状态：</span>
          <span>{{ shopGoodsState === 'on' ? '上架' : '待上架' }}</span>
        </p>
        <el-form-item label="零售价(元)：" prop="price">
          <el-input v-model.number="priceFrom.price" type="number" placeholder="请输入零售价" />
        </el-form-item>
        <el-form-item label="建议零售价(元)：" prop="retailPrice">
          <el-input
            v-model.number="priceFrom.retailPrice"
            type="number"
            placeholder="请输入建议零售价"
          />
        </el-form-item>
        <el-form-item label="阶梯价：" required>
          <div
            class="tiered-pricing"
            v-for="(item, index) in priceFrom.stepPriceItems"
            :key="index"
          >
            <el-form-item
              label="起始量"
              label-width="70px"
              :prop="`stepPriceItems.${index}.min`"
              :rules="priceInfoFormRule.min"
            >
              <el-input
                class="input"
                v-model.number="item.min"
                type="number"
                size="small"
                placeholder="起始量"
              />
            </el-form-item>
            <el-form-item
              label="结束量"
              label-width="70px"
              :prop="`stepPriceItems.${index}.max`"
              :rules="priceInfoFormRule.max"
            >
              <el-input
                class="input"
                v-model.number="item.max"
                type="number"
                size="small"
                placeholder="结束量"
              />
            </el-form-item>
            <el-form-item
              label="售价"
              label-width="70px"
              :prop="`stepPriceItems.${index}.price`"
              :rules="[{ required: true, message: '请输入售价', trigger: 'blur' }]"
            >
              <el-input
                class="input"
                v-model.number="item.price"
                type="number"
                size="small"
                placeholder="售价"
              />
            </el-form-item>
            <el-icon
              v-show="index !== 0"
              class="el-icon-delete delete-icon"
              :size="20"
              @click="deletePrice(index)"
            ></el-icon>
          </div>
          <el-button type="primary" size="small" @click="addPrice">添加阶梯价</el-button>
        </el-form-item>
        <p class="text">
          <span class="title">销量：</span>
          <span>{{ skuInfo.saledCount || 0 }}</span>
        </p>
        <p class="text">
          <span class="title">库存：</span>
          <span>{{ skuInfo.stockCount || 0 }}</span>
        </p>
        <el-form-item label="备注" prop="remark">
          <el-input type="textarea" :rows="5" v-model="priceFrom.remark" placeholder="备注" />
        </el-form-item>
      </el-form>

      <div class="select-box">
        <el-button size="small" @click="closeWindow">取消</el-button>
        <el-button type="primary" size="small" @click="confirm">确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script lang="ts">
  import { defineComponent, nextTick, PropType, reactive, ref } from 'vue';
  import { useDialog } from '@/utils/hooks';
  import { ElForm, ElMessage } from 'element-plus';
  import store from '@/store';
  import { getSkuInfo, SkuInfo, SkuPrice, updateGoodsSku } from '@/pages/shopManage/api';

  export default defineComponent({
    name: 'commodityEditPrice',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      skuSn: {
        type: String as PropType<string>,
        default: ''
      },
      shopName: {
        type: String as PropType<string>,
        default: ''
      },
      shopGoodsState: {
        type: String as PropType<string>,
        default: ''
      }
    },
    setup(props, { emit }) {
      const editForm = ref<InstanceType<typeof ElForm> | null>(null);

      const skuInfo = ref<SkuInfo>({
        brandName: '',
        categoryName: '',
        goodsName: '',
        icon: '',
        name: '',
        price: 0,
        remark: '',
        retailPrice: 0,
        saledCount: 0,
        stockCount: 0
      });
      const priceFrom = reactive<SkuPrice>({
        price: '',
        retailPrice: '',
        remark: '',
        stepPriceItems: []
      });

      const priceInfoFormRule = {
        price: [{ required: true, message: '请输入零售价', trigger: 'blur' }],
        retailPrice: [{ required: true, message: '请输入建议零售价', trigger: 'blur' }],
        min: [{ required: true, message: '请输入起始量', trigger: 'blur' }],
        max: [{ required: true, message: '请输入结束量', trigger: 'blur' }]
      };

      function addPrice() {
        priceFrom.stepPriceItems.push({
          min: '',
          max: '',
          price: ''
        });
      }

      function deletePrice(index: number) {
        priceFrom.stepPriceItems.splice(index, 1);
      }

      function confirm() {
        editForm.value?.validate((valid?: boolean) => {
          if (valid) {
            const error = priceFrom.stepPriceItems.some((item) => item.min === item.max);
            if (error) {
              ElMessage.error('起始量和结束量不能一样');
              return false;
            }
            updateGoodsSku(props.skuSn, priceFrom).then((res) => {
              if (res) {
                ElMessage.success('修改成功');
                closeWindow();
              }
            });
          } else {
            return false;
          }
        });
      }

      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        nextTick(() => {
          if (!v) {
            editForm.value?.resetFields();
          } else {
            _getSkuInfo();
          }
        });
      });

      function _getSkuInfo() {
        const _default = [{ min: '', max: '', price: '' }];
        getSkuInfo(props.skuSn).then((res) => {
          if (res) {
            skuInfo.value = res;

            store.dispatch('source/getOssUrl', [res.icon]).then((oss) => {
              if (res) {
                skuInfo.value.icon = oss[res.icon].url;
              }
            });
            priceFrom.price = res.price;
            priceFrom.retailPrice = res.retailPrice;
            priceFrom.remark = res.remark;
            priceFrom.stepPriceItems = !res.stepPrices
              ? _default
              : res.stepPrices && !res.stepPrices.length
              ? _default
              : res.stepPrices;
          }
        });
      }

      return {
        skuInfo,
        showDialog,
        priceFrom,
        priceInfoFormRule,
        closeWindow,
        confirm,
        editForm,
        addPrice,
        deletePrice
      };
    }
  });
</script>
<style lang="less">
  .editprice {
    .text {
      margin-bottom: 10px;
      .title {
        display: inline-block;
        width: 140px;
        text-align: right;
        padding: 0 12px 0 0;
        box-sizing: border-box;
      }
      .img {
        width: 50px;
        height: 50px;
        vertical-align: text-top;
      }
    }
    .select-box {
      padding-bottom: 20px;
      text-align: right;
    }
    .tiered-pricing {
      display: flex;
      align-items: center;
      padding: 4px;
      margin-bottom: 10px;
      .input {
        width: 120px;
      }
      .delete-icon {
        cursor: pointer;
        margin-left: 20px;
      }
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none !important;
    }
    input[type='number'] {
      -moz-appearance: textfield;
    }
  }
</style>
