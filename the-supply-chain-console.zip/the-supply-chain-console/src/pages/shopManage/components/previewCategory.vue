<template>
  <div class="preview-category">
    <el-drawer
      v-model="showDialog"
      title="分类预览"
      direction="rtl"
      size="500px"
      @close="closeWindow"
    >
      <div class="category-preview">
        <h3 class="category-preview--title">商品分类</h3>
        <div class="category-preview--wrapper">
          <div class="category-preview--wrapper__left" :style="{ height: clientHeight + 'px' }">
            <div
              v-for="(left, index) in previewData"
              :class="['name', activeIndex === index ? 'active' : '']"
              :key="left.sn"
              @click="changeCategory(index)"
            >
              {{ left.name }}
            </div>
          </div>
          <div class="category-preview--wrapper__right" :style="{ height: clientHeight + 'px' }">
            <div class="detail" v-for="right in rightData" :key="right.sn">
              <div class="detail__title">{{ right.name }}</div>
              <template v-for="item in right.items" :key="item.sn">
                <div class="detail__item">
                  <img class="detail__item--img" :src="item.image" />
                  <p class="detail__item--name">{{ item.name }}</p>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script lang="ts">
  import { defineComponent, nextTick, onMounted, PropType, ref } from 'vue';
  import { getFileUrlBySeq } from '@/utils/commApi';
  import { previewCategory } from '@/pages/shopManage/api';
  import { CategoryInfo, CategoryItem } from '@/components/classify/api';
  import { useDialog } from '@/utils/hooks';

  export default defineComponent({
    name: 'previewCategory',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        required: true
      },
      defSn: {
        type: String as PropType<string>,
        required: true,
        default: ''
      }
    },
    emits: ['hide'],
    setup(props, { emit }) {
      // 预览
      const clientHeight = ref<number>(0);
      const activeIndex = ref<number>(0);
      const previewData = ref<CategoryInfo[]>([]);

      const rightData = ref<CategoryItem[]>([]);
      function changeCategory(index: number) {
        activeIndex.value = index;
        const currentData = previewData.value[index].items;
        currentData.map((item) => {
          item.items.map(async (item) => {
            const oss = item.ossId && (await getFileUrlBySeq(item.ossId));
            item.image = (oss && oss[item.ossId].url) || '';
          });
        });

        rightData.value = currentData;
      }

      function getPreviewData() {
        previewCategory(props.defSn).then((res) => {
          if (res) {
            previewData.value = res;
            rightData.value = previewData.value[0].items;
            rightData.value.map((item) => {
              item.items.map(async (item) => {
                const oss = await getFileUrlBySeq(item.ossId);
                item.image = oss[item.ossId].url;
              });
            });
          }
        });
      }

      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        nextTick(() => {
          if (!v) {
            activeIndex.value = 0;
            emit('hide');
          } else {
            getPreviewData();
          }
        });
      });

      onMounted(() => {
        nextTick(() => {
          clientHeight.value = document.documentElement.clientHeight - 100;
        });
      });

      return {
        clientHeight,
        activeIndex,
        previewData,
        rightData,
        changeCategory,
        closeWindow,
        showDialog
      };
    }
  });
</script>

<style lang="less">
  .category-preview {
    height: 100%;
    &--title {
      text-align: center;
      margin-top: -20px;
      margin-bottom: 20px;
    }
    &--wrapper {
      height: 100%;
      display: flex;
      &__left {
        overflow-y: auto;
        width: 110px;
        background-color: #ddd;
        box-sizing: border-box;
        .name {
          cursor: pointer;
          padding: 10px 0;
          text-indent: 10px;
          width: 99%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          &.active {
            border-left: 2px solid #db3d38;
            background-color: #f5f5f5;
          }
          &:hover {
            background-color: #f5f5f5;
          }
        }
      }
      &__right {
        overflow-y: auto;
        flex: 1;

        .detail {
          &__title {
            font-size: 14px;
            line-height: 24px;
            margin-bottom: 10px;
            margin-left: 10px;
            font-weight: 700;
          }

          &__wrapper {
            display: flex;
          }
          &__item {
            display: inline-block;
            width: 33%;
            margin-bottom: 20px;
            text-align: center;
            &--img {
              display: inline-block;
              width: 80px;
              height: 80px;
            }
            &--name {
              padding: 5px 0;
              width: 99%;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            }
          }
        }
      }
    }
  }
</style>
