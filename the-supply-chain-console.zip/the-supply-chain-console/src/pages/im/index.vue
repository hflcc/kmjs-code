<template>
  <div class="page csc-page" style="padding-top: 20px">
    <im-user-info v-if="isReady && serviceCenter.length > 0"></im-user-info>
    <!--    中心客服分组-->
    <customer-group v-if="isReady && serviceCenter.length > 0"></customer-group>

    <div v-if="currentServiceSn">
      <div class="container" v-show="!overviewShow">
        <customer-panel class="left"></customer-panel>
        <dialogue class="dialogue"></dialogue>
        <other-panel @overview="overviewShow = true"></other-panel>
        <div class="no-select" v-if="!currentGroupSn">暂无数据</div>
      </div>

      <overview class="overview" v-if="overviewShow" @goBack="hideOverview"></overview>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, onActivated, ref } from 'vue';
  import CustomerGroup from '@/pages/im/components/customerGroup.vue';
  import dialogue from '@/pages/im/components/msg/dialogue.vue';
  import OtherPanel from '@/pages/im/components/right/otherPanel.vue';
  import CustomerPanel from '@/pages/im/components/left/customerPanel.vue';
  import Overview from '@/pages/im/components/overview.vue';
  import { useStore } from 'vuex';
  import { getMkCscServiceList } from '@/utils/im/api';
  import ImUserInfo from '@/pages/im/components/imUserInfo.vue';

  export default defineComponent({
    name: 'cscIndex',
    components: { ImUserInfo, Overview, CustomerPanel, OtherPanel, CustomerGroup, dialogue },
    setup() {
      // store
      const store = useStore<RootState>();
      const isReady = computed(() => {
        return store.state.im.imInfoIsReady;
      });

      // 客服信息
      // eslint-disable-next-line no-undef
      const csInfo = computed<ImUserInfo>(() => {
        return store.state.im.userInfo;
      });

      onActivated(() => {
        // 缓存时，会重新初始化。需要判断是否已经初始化过了
        if (!isReady.value) {
          store.dispatch('im/initSdk').then((r) => {
            if (csInfo.value.exist) {
              // 初始化IM
              store.dispatch('im/initIm');
            }
          });
        } else {
          store.dispatch('im/initIm');
          // 切换回页面时刷新客服列表
          if (currentServiceSn.value) {
            getMkCscServiceList(currentServiceSn.value).then((res) => {
              store.commit('im/SET_SERVICE_DATA_MAP_CUSTOMER', {
                sn: currentServiceSn.value,
                list: res.content
              });
            });
          }
        }
      });
      // 当前选中的群组
      const currentGroupSn = computed(() => {
        return store.state.im.currentGroupSn;
      });

      const overviewShow = ref(false);

      const hideOverview = () => {
        overviewShow.value = false;
      };
      const currentServiceSn = computed(() => {
        return store.state.im.currentServiceSn;
      });
      // 客服中心
      // eslint-disable-next-line no-undef
      const serviceCenter = computed<Array<ImServiceInfo>>(() => {
        return store.getters['im/getServiceList'];
      });

      window.onblur = function (e: Event) {
        // console.log('未激活状态！');
        store.commit('im/UPDATE_NOTIFICATION', true);
      };
      window.onfocus = function (e: Event) {
        // console.log('激活状态！');
        store.commit('im/UPDATE_NOTIFICATION', false);
      };

      // 5分钟检测，如果5分钟内没有键盘事件，发送个校验的接口
      // const onCheck = _.debounce(() => {
      //   checkOnLine().then();
      // }, 5000 * 60);
      //
      // const keydown = () => {
      //   onCheck();
      // };
      // onMounted(() => {
      //   document.addEventListener('keydown', keydown);
      // });
      // onUnmounted(() => {
      //   document.removeEventListener('keydown', keydown);
      // });
      return {
        overviewShow,
        hideOverview,
        currentServiceSn,
        isReady,
        currentGroupSn,
        serviceCenter
      };
    }
  });
</script>
<style lang="less">
  .csc-page {
    min-width: 1200px;
    .container {
      height: calc(100vh - 230px);
      display: flex;
      border: 1px solid #dcdfe6;
      position: relative;
      .left {
        width: 280px;
      }

      .dialogue {
        flex: 1;
      }

      .right {
        width: 280px;
      }

      .no-select {
        position: absolute;
        left: 310px;
        right: 0;
        top: 0;
        text-align: center;
        bottom: 0;
        z-index: 12;
        padding-top: 260px;
        padding-right: 280px;
        color: #909399;
        background: rgba(0, 0, 0, 0.08);
      }
    }
  }
</style>
