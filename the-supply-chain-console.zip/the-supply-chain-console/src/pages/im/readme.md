### IM相关文件
* src/pages/im 主文件目录
  * taking 模拟的客户端
  * ts 一些工具类
  * components 组件
* types/im 类相关
* src/utils/tim.ts 初始化的代码
