<template>
  <!--    中心客服分组-->
  <div style="margin-bottom: 10px">
    <el-scrollbar>
      <div class="group">
        <div
          class="group-item"
          :class="{ active: item.sn === currentServiceSn }"
          v-for="item in groupList"
          :key="item.sn"
          @click="selectGroup(item.sn)"
        >
          {{ item.name }}
          <div class="group-item-dot" v-show="item.count > 0">
            {{ item.count > 99 ? '99+' : item.count }}
          </div>
        </div>
      </div>
    </el-scrollbar>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'customerGroup',
    components: {},
    methods: {},
    setup() {
      const store = useStore<RootState>();
      const currentServiceSn = computed(() => {
        return store.state.im.currentServiceSn;
      });

      // 客服中心
      // eslint-disable-next-line no-undef
      const serviceCenter = computed<Array<ImServiceInfo>>(() => {
        return store.getters['im/getServiceList'];
      });
      const selectGroup = (sn: string) => {
        store.dispatch('im/changeCurrentServiceSn', sn);
      };
      if (serviceCenter.value.length > 0 && !currentServiceSn.value) {
        selectGroup(serviceCenter.value[0].sn);
      }

      return {
        currentServiceSn,
        selectGroup,
        groupList: serviceCenter
      };
    }
  });
</script>
<style lang="less">
  .group {
    color: #909399;
    display: flex;
    align-items: center;

    &-item {
      flex-shrink: 0;
      padding: 0 30px;
      position: relative;
      height: 32px;
      line-height: 32px;
      cursor: pointer;
      display: inline-block;
      background: #fcfdff;
      border: 1px solid #ebeef5;
      border-radius: 0 0 8px 8px;

      &-dot {
        background: #ff3a30;
        color: white;
        position: absolute;
        top: 4px;
        right: 20px;
        border-radius: 8px;
        height: 16px;
        line-height: 16px;
        padding: 0 5px;
        min-width: 16px;
        text-align: center;
        font-size: 12px;
      }
    }

    .active {
      color: #409eff;
      font-weight: bold;
      border-top: 1px solid !important;
      border-left: none;
      border-right: none;
      border-bottom: none;
      background: #f4f7ff;
    }
  }
</style>
