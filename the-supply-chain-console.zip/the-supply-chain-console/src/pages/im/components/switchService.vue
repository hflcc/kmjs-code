<template>
  <div class="switch-service-page" v-if="modelValue" @click="onClose">
    <div class="switch-service" @click.stop="void 0">
      <div class="title">转接客服</div>
      <i class="icon el-icon-close" @click="onClose"></i>
      <el-form :model="form" label-width="80px" style="margin: 16px">
        <el-form-item label="选择客服">
          <el-select v-model="form.sn" placeholder="请选择客服" style="width: 290px">
            <el-option
              v-for="item in serviceList"
              :key="item.sn"
              :label="item.nickname"
              :value="item.attendorSn"
            >
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item>
          <div class="fe">
            <el-button @click="onClose">取消</el-button>
            <el-button type="primary" @click="onSubmit" :disabled="!form.sn">确认</el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, PropType, reactive, watch } from 'vue';
  import { getMkCscServiceList, putMkTransferDialog } from '@/utils/im/api';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'switchService',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      }
    },
    setup(props, { emit }) {
      const form = reactive({ sn: '' });
      const store = useStore<RootState>();
      // 客服列表
      // eslint-disable-next-line no-undef
      const serviceList = computed<ImCscService[]>(() => {
        // eslint-disable-next-line no-undef
        return store.getters['im/getServiceCsList'].filter((item: ImCscService) => {
          return item.attendorSn !== store.state.im.userInfo.sn;
        });
      });

      // 打开时  重新加载客服中心列表
      watch(
        () => props.modelValue,
        (val) => {
          if (val) {
            // 获取客服中心列表
            getMkCscServiceList(store.state.im.currentServiceSn).then((res) => {
              store.commit('im/SET_SERVICE_DATA_MAP_CUSTOMER', {
                sn: store.state.im.currentServiceSn,
                list: res.content
              });
            });
          }
        }
      );

      // 获取当前选中的群
      // eslint-disable-next-line no-undef
      const currentGroup = computed<ImGroupInfo>(() => {
        return store.getters['im/getCurrentGroupInfo'];
      });
      // 提交,切换客服
      const onSubmit = () => {
        putMkTransferDialog(store.state.im.currentGroupSn, form.sn).then((res) => {
          if (res.success) {
            onClose(); // 当前选中的置空
            // 当前服务。是否加载过finished列表，如果加载过，转为finish,如果没有，可以直接删掉
            if (store.state.im.groupFinishedState[store.state.im.currentServiceSn]) {
              currentGroup.value.groupState = 'finished';
            } else {
              const list = store.getters['im/getGroupList'];
              const idx = list.findIndex(
                // eslint-disable-next-line no-undef
                (item: ImGroupInfo) => item.sn === currentGroup.value.sn
              );
              if (idx !== -1) list.splice(idx, 1);
            }
            store.commit('im/SET_CURRENT_GROUP_SN', '');
          }
        });
      };
      const onClose = () => {
        form.sn = '';
        emit('update:modelValue', false);
      };
      return { form, onSubmit, onClose, serviceList };
    }
  });
</script>

<style lang="less" scoped>
  .switch-service-page {
    width: 100%;
    height: 100%;
    position: fixed;
    background: rgba(0, 0, 0, 0.1);
    left: 0;
    top: 0;
    z-index: 999;
  }

  .switch-service {
    width: 406px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    box-shadow: 0 3px 6px rgba(144, 147, 153, 0.29);
    opacity: 1;
    border-radius: 4px;
    position: fixed;
    top: 215px;
    right: 250px;

    .el-icon-close {
      position: absolute;
      right: 16px;
      top: 16px;
      font-size: 14px;
      cursor: pointer;
    }

    .title {
      border-bottom: 1px solid #ebeef5;
      font-size: 16px;
      font-weight: bold;
      height: 46px;
      line-height: 46px;
      color: #000000;
      text-align: center;
    }

    .fe {
      display: flex;
      justify-content: flex-end;
      margin-top: 16px;
    }
  }
</style>
