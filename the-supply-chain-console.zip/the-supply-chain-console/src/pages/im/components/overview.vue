<template>
  <div class="overview">
    <div class="overview-title">
      <img src="../../../assets/back.png" alt="" @click="goBack" />
      总览
    </div>
    <div class="overview-search">
      <el-input
        v-model="searchText"
        placeholder="输入客户名称/内容"
        :input-style="{ height: '32px' }"
        @keyup.enter="loadData"
      >
        <template #suffix>
          <div class="suffix">
            |
            <img src="../../../assets/search.png" alt="" @click="loadData" />
          </div>
        </template>
      </el-input>
    </div>
    <el-table :data="tableData" style="width: 100%" :border="false" height="600px">
      <el-table-column type="index" width="50" label="序号" align="center"></el-table-column>
      <el-table-column prop="clientName" label="客户名称"></el-table-column>
      <el-table-column prop="clientServiceName" label="客服中心"></el-table-column>
      <el-table-column
        prop="planContactTime"
        label="计划联系时间"
        :formatter="formatTime"
      ></el-table-column>
      <el-table-column
        prop="actualContactTime"
        label="实际联系时间"
        :formatter="formatTime"
      ></el-table-column>
      <el-table-column prop="contactContent" label="联系内容"></el-table-column>
      <el-table-column prop="serviceName" label="执行客服"></el-table-column>
      <el-table-column prop="remark" label="备注"></el-table-column>
      <el-table-column prop="contactState" label="状态" width="100">
        <template #default="scope">
          <!--          <div style="text-align: center">-->
          <div v-if="scope.row.contactState === 'waiting'">待联系</div>
          <div v-else-if="scope.row.contactState === 'cancel'">已取消</div>
          <div v-else>已联系</div>
          <!--          </div>-->
        </template>
      </el-table-column>
      <el-table-column prop="address" label="操作" width="120">
        <template #default="scope">
          <el-button
            type="text"
            style="color: #409eff"
            size="small"
            v-if="scope.row.contactState === 'waiting'"
            @click="cancelWait(scope.row.sn)"
            >取消</el-button
          >
          <el-button
            type="text"
            style="color: #409eff"
            size="small"
            v-if="scope.row.contactState === 'waiting'"
            @click="finishWait(scope.row.sn)"
            >完成</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      layout="total, sizes, prev, pager, next"
      :total="pagination.total"
      style="text-align: right; margin-top: 12px"
      v-model:current-page="pagination.page"
      @current-change="loadData"
      @size-change="handleSizeChange"
    >
    </el-pagination>
  </div>
  <finish-dialog v-model="dialogVisible" @onSave="saveFinish"></finish-dialog>
</template>

<script lang="ts">
  import { computed, defineComponent, ref, watch } from 'vue';
  import FinishDialog from '@/pages/im/components/finishDialog.vue';
  import { cancelMkPlan, finishedMkPlan, getMkPlanList } from '@/utils/im/api';
  import { useStore } from 'vuex';
  import dayjs from 'dayjs';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'overview',
    components: { FinishDialog },
    setup(prop, { emit }) {
      const store = useStore<RootState>();
      // eslint-disable-next-line no-undef
      const tableData = ref<ImContactPlan[]>([]);
      const searchText = ref('');

      const cscDefSn = computed(() => {
        return store.state.im.currentServiceSn;
      });

      watch(
        () => cscDefSn.value,
        () => {
          pagination.value.page = 1;
          loadData();
        }
      );

      const loadData = () => {
        getMkPlanList({
          cscDefSn: cscDefSn.value,
          customName: searchText.value,
          page: pagination.value.page - 1,
          size: pagination.value.size
        }).then((res) => {
          tableData.value = res.content;
          pagination.value.total = res.totalElements;
        });
      };

      const pagination = ref({
        total: 0,
        page: 1,
        size: 10
      });

      loadData();
      // const sortChange = ({ order, prop }: Sort) => {
      //   console.info('排序', order, prop);
      // };=

      const goBack = () => {
        emit('goBack');
      };

      // 格式化时间
      const formatTime = (
        // eslint-disable-next-line no-undef
        row: ImContactPlan,
        column: { property: 'actualContactTime' | 'planContactTime' }
      ) => {
        const time = row[column.property] as number;
        if (!time) {
          return '-';
        }
        return dayjs(time * 1000).format('YYYY-MM-DD HH:mm');
      };
      // 取消联系
      const cancelWait = (sn: string) => {
        cancelMkPlan(sn).then((res) => {
          if (res.success) {
            ElMessage.success('操作成功');
            dialogVisible.value = false;
            loadData();
            updateSelectGroup();
          }
        });
      };
      // 完成对话框
      const dialogVisible = ref<boolean>(false);
      let waitSn = '';
      // 弹出完成
      const finishWait = (sn: string) => {
        dialogVisible.value = true;
        waitSn = sn;
      };
      // 保存确认完成
      const saveFinish = (remark: string) => {
        finishedMkPlan(waitSn, {
          remark
        }).then((res) => {
          if (res.success) {
            ElMessage.success('保存成功');
            dialogVisible.value = false;
            loadData();
            updateSelectGroup();
          }
        });
      };

      // 更新当前选中的联系计划
      const updateSelectGroup = () => {
        // 获取联系计划
        if (store.state.im.currentGroupSn) {
          const groupInfo = store.getters['im/getCurrentGroupInfo'];
          getMkPlanList({
            dialogSn: store.state.im.currentGroupSn,
            page: 0,
            size: 50
          }).then((res) => {
            groupInfo.contactPlan = res.content || [];
          });
        }
      };

      // 更新页码
      const handleSizeChange = (val: number) => {
        pagination.value.size = val;
        loadData();
      };

      return {
        dialogVisible,
        tableData,
        pagination,
        // sortChange,
        searchText,
        goBack,
        formatTime,
        cancelWait,
        finishWait,
        saveFinish,
        handleSizeChange,
        loadData
      };
    }
  });
</script>

<style lang="less" scoped>
  /deep/ .el-table thead th {
    background: #f4f4f5;
    color: #303133;
  }
  .overview {
    &-title {
      font-size: 20px;
      color: #303133;
      display: flex;
      align-items: center;
      margin: 15px 0;
      img {
        width: 24px;
        height: 24px;
        margin-right: 6px;
        cursor: pointer;
      }
    }

    &-search {
      color: #bbbbbb;
      border-radius: 3px;
      height: 32px;
      display: flex;
      align-items: center;
      width: 300px;
      margin-bottom: 16px;

      .suffix {
        display: flex;
        align-items: center;

        img {
          margin: 0 6px;
        }
      }
    }
  }
</style>
