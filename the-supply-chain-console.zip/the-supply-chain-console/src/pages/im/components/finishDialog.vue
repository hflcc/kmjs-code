<template>
  <el-dialog title="确认完成" v-model="showDialog" @close="closeWindow" width="30%">
    <div>
      <el-form label-position="right" ref="form" :model="remarkForm" :rules="remarkRules">
        <el-form-item label="备注" required>
          <el-input
            type="textarea"
            :rows="10"
            v-model="remarkForm.remark"
            placeholder="输入备注信息"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <div class="btns">
            <div class="btn btn-cancel" @click="showDialog = false">取消</div>
            <div class="btn btn-finish" @click="onSave">完成</div>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, PropType, reactive, watch } from 'vue';
  import { useDialog, useForm } from '@/utils/hooks';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'finishDialog',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      }
    },
    setup(props, { emit }) {
      const { showDialog, closeWindow } = useDialog(props, emit);
      const { formElem } = useForm();
      const remarkForm = reactive({ remark: '' });
      // 表单验证规则
      const remarkRules = {
        remark: [{ required: true, trigger: 'blur' }]
      };

      // 清空赋值
      watch(
        () => props.modelValue,
        (val) => {
          if (val) {
            remarkForm.remark = '';
          }
        }
      );
      const onSave = () => {
        if (!remarkForm.remark) {
          ElMessage.warning('请输入备注');
          return;
        }
        // console.info('保存');
        showDialog.value = false;
        emit('on-save', remarkForm.remark);
      };
      return {
        formElem,
        showDialog,
        remarkForm,
        remarkRules,
        closeWindow,
        onSave
      };
    }
  });
</script>

<style lang="less" scoped>
  /deep/ .el-dialog__header {
    background: #8c939d;
  }
  .btns {
    display: flex;
    justify-content: flex-end;
    .btn-cancel {
      border: 1px solid;
      color: #c0c4cc;
      background: white;
      margin-right: 10px;
    }
    .btn-finish {
      background: #409eff;
      color: white;
    }
  }
  .btn {
    width: 96px;
    height: 40px;
    background: #409eff;
    opacity: 1;
    border-radius: 4px;
    color: white;
    line-height: 40px;
    text-align: center;
    margin-top: 32px;
    cursor: pointer;
  }
</style>
