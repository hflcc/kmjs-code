<template>
  <div class="customer-header">
    <img :src="csInfo.avatar" alt="" />
    <div class="service-info">
      <div class="service-name">{{ csInfo.nickname }}</div>
      <el-dropdown trigger="click" v-if="isImOnline">
        <div class="status">
          <img src="~@/assets/online.png" alt="" v-if="csInfo.state === 'ON'" />
          <img src="~@/assets/icon_busy.svg" alt="" v-if="csInfo.state === 'BUSY'" />
          {{ csInfo.state === 'ON' ? '在线' : csInfo.state === 'BUSY' ? '繁忙' : '离线' }}
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item>
              <div class="status" @click="changeCsState('ON')">
                <img src="~@/assets/online.png" alt="" />
                在线
              </div>
            </el-dropdown-item>
            <el-dropdown-item>
              <div class="status" @click="changeCsState('BUSY')">
                <img src="~@/assets/icon_busy.svg" alt="" />繁忙
              </div>
            </el-dropdown-item>
            <!--              <el-dropdown-item>-->
            <!--                <div class="status-offline" @click="changeCsState('OFF')">离线</div>-->
            <!--              </el-dropdown-item>-->
          </el-dropdown-menu>
        </template>
      </el-dropdown>
      <div class="status" v-else>
        <img src="~@/assets/icon_offline.svg" alt="" />
        离线<span v-if="!isImOnline" class="connect">
          您已在其他地方登录，请<span @click="reConnect">重新连接</span>
        </span>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'imUserInfo',
    setup() {
      // store
      const store = useStore<RootState>();
      // 客服信息
      // eslint-disable-next-line no-undef
      const csInfo = computed<ImUserInfo>(() => {
        return store.state.im.userInfo;
      });
      // 切换客服状态
      const changeCsState = (state: string) => {
        store.dispatch('im/changeImUserState', state);
      };
      const isImOnline = computed(() => {
        return store.state.im.isImOnline;
      });
      // 重新链接
      const reConnect = () => {
        store.dispatch('im/reConnect');
      };
      return {
        csInfo,
        changeCsState,
        reConnect,
        isImOnline
      };
    }
  });
</script>

<style lang="less">
  .customer-header {
    display: flex;
    border: 1px solid #dcdfe6;
    padding: 6px 24px;

    img {
      width: 46px;
      height: 46px;
      border-radius: 8px;
    }

    .service-info {
      display: flex;
      flex-direction: column;
      justify-content: center;
      margin-left: 15px;
      color: #000000;

      .service-name {
        color: #303133;
        font-weight: bold;
        font-size: 14px;
      }
    }

    .connect {
      align-self: flex-end;
      margin-left: 16px;
      span {
        color: #2d8cf0;
        cursor: pointer;
      }
    }
  }

  /deep/ .el-dropdown-menu__item {
    line-height: 22px;
  }

  .status {
    font-size: 12px;
    position: relative;
    margin-top: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    img {
      width: 14px;
      height: 14px;
      margin-right: 8px;
    }
  }
</style>
