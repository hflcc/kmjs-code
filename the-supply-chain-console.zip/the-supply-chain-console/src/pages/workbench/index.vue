<script lang="tsx">
  import { defineComponent, onMounted, ref } from 'vue';
  import { getBrowseList, getMenusBySn, TData } from './api';
  import { isEmpty } from '@/utils/valid';
  import useMenuChild from './dataHook';
  import QuickContent from '@/components/quickContent/index.vue';
  import ShortcutFunc from './components/shortcutFunc.vue';
  import { useRouter } from 'vue-router';
  import { goToCreateBpm } from '@/pages/commonPage';

  export default defineComponent({
    name: 'workbenchPage',
    components: {
      ShortcutFunc,
      QuickContent
    },
    setup() {
      console.log('workbenchPage setup');
      const router = useRouter();
      // 常用事项
      const commonMatters = ref<Array<TData>>([]);

      // 快捷功能
      const quickFunction = ref<Array<TData>>([]);

      const { theTitle, menuChild, getImagesUrl } = useMenuChild();

      async function initData() {
        // 获取工作台常用事项
        const _commonMatters = await getBrowseList();
        commonMatters.value = await getFuncData(_commonMatters);

        // 获取工作台快捷功能
        if (menuChild) {
          const _quickFunction = await getMenusBySn(menuChild);
          quickFunction.value = await getFuncData(_quickFunction);
        }
      }

      /**
       * 处理快捷功能Icon图标，seq 拉取图片地址
       */
      async function getFuncData(list: Array<TData>) {
        if (list && list.length) {
          // 过滤空数据，后台可能会出现null的脏数据
          const _list = list.filter((item) => item);
          // 预处理icon
          const _iconList = _list.map((item) => item.ico || '');
          const _ossObj = await getImagesUrl(_iconList.join(','));
          _list.forEach((item) => {
            return (item.ico = (!isEmpty(_ossObj) && _ossObj[item.ico].url) || '');
          });
          return _list;
        } else {
          return [];
        }
      }

      /**
       * 跳转对应的快捷功能页面
       */
      function handleClick(value: string) {
        router.push({ name: value });
      }

      /**
       * 流程回调，直接进入流程发起页面
       * */
      function bpmClick(sn: string) {
        goToCreateBpm(sn);
      }

      onMounted(async () => {
        await initData();
      });

      return () => (
        <div class="workbench-container">
          <shortcut-func title={'常用事项'} data={commonMatters.value} onItemClick={handleClick} />
          <quick-content title={'快捷流程'} border onItemClick={bpmClick} />
          <shortcut-func
            title={theTitle || '快捷功能'}
            data={quickFunction.value}
            onItemClick={handleClick}
          />
        </div>
      );
    }
  });
</script>

<style lang="less">
  .workbench-container {
    padding-top: 20px;
  }
</style>
