import ajax from '@/utils/axios';

export type TChildrenList = {
  childrenList: Array<TData>;
};
export interface TData {
  id?: number;
  action: string;
  descr: string;
  ico: string;
  parentId: number;
  sn: string;
  title: string;
  value: string;
  childrenList: Array<TChildrenList>;
  propertyList: {
    menu_record: string;
    menu_child: string;
    [key: string]: string;
  };
}

/**
 * 查询用户菜单浏览记录
 */
export const getBrowseList = () => {
  return ajax.get<null, Array<TData>>('/auth/md/inst/menu/browse/createBy', {
    params: {
      $InstId: true
    }
  });
};

/**
 * 根据sn批量查询菜单快捷功能
 */
export const getMenusBySn = (menuSns: string) => {
  return ajax.get<{ menuSns: string }, Array<TData>>('/auth/md/inst/menu/instance/sns', {
    params: {
      $InstId: true,
      menuSns
    }
  });
};
