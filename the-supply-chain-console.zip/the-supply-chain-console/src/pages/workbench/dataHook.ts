import { getFileUrlBySeq } from '@/utils/commApi';
import { useRouter } from 'vue-router';
import type { TChildrenList } from './api';

interface TUseMenuChild {
  theTitle: string;
  menuChild: string;
  getImagesUrl: (seqs: string) => Promise<CommonOssCommonListSeqs>;
}

export default function useMenuChild(): TUseMenuChild {
  const router = useRouter();
  const matched = router.currentRoute.value.matched;
  const currentRouteMeta = matched.filter((item) => item.name === 'workbench')[0].meta;

  let theTitle = '';
  let menuChild = '';

  try {
    const {
      title,
      propertyList: { menu_child }
    } = (currentRouteMeta as TChildrenList).childrenList?.[0] || {};
    theTitle = title;
    menuChild = menu_child;
  } catch (error) {
    theTitle = '';
    menuChild = '';
  }

  /**
   * 通过图片sn批量拉取图片地址
   * @param seqs 通过图片sn
   */
  async function getImagesUrl(seqs: string) {
    const imgs = await getFileUrlBySeq(seqs);
    return imgs || '';
  }

  return {
    theTitle,
    menuChild,
    getImagesUrl
  };
}
