<template>
  <div class="quick">
    <h3 class="quick__title">{{ title }}</h3>
    <el-descriptions :column="column">
      <el-descriptions-item v-for="(item, index) in data" :key="index">
        <div class="quick__content" @click="itemClick(item.value)">
          <img class="quick__icon" :src="item.ico" />
          <span class="quick__text">{{ item.title }}</span>
        </div>
      </el-descriptions-item>
    </el-descriptions>

    <el-empty v-show="!hasData" :image-size="100" :description="description" />
  </div>
</template>

<script lang="ts">
  import { defineComponent, computed, PropType } from 'vue';
  import { TData } from '../api';

  export default defineComponent({
    name: 'shortcutFunc',
    props: {
      title: {
        type: String as PropType<string>,
        default: ''
      },
      column: {
        type: Number as PropType<number>,
        default: 4
      },
      hasTab: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      data: {
        type: Array as PropType<TData[]>,
        default: () => []
      }
    },
    emits: ['item-click'],
    setup(props, { emit }) {
      const hasData = computed(() => props.data.length !== 0);
      const description = computed(() => (!hasData.value ? `暂无${props.title}` : ''));

      // 点击某一项快捷方式
      function itemClick(value: string) {
        emit('item-click', value);
      }

      return {
        itemClick,
        hasData,
        description
      };
    }
  });
</script>

<style lang="less">
  .quick {
    padding: 20px;
    margin-bottom: 30px;
    border: 1px solid #ddd;
    &__title {
      font-weight: 700;
      margin-bottom: 20px;
    }
    &__content {
      padding-bottom: 10px;
      display: inline-block;
      cursor: pointer;
    }
    &__icon {
      display: inline-block;
      vertical-align: middle;
      width: 30px;
    }
    &__text {
      margin-left: 12px;
      display: inline-block;
      vertical-align: middle;
    }
  }
</style>
