import ajax from '@/utils/axios';

/*
 * 删除银行卡api
 * */
export const delCerBankAccount = (sn: string) => {
  return ajax.delete(`/auth/md/bank/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 批量删除银行卡
 */
export function delBatchBankAccountSn(sns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ sns: string[] }, { success: boolean }>(`/auth/md/bank/batch/${sns}`, {
    params: {
      $InstId: true
    }
  });
}
