<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl">
      <template #from-data>
        <p>{{ formData }}</p>
      </template>
    </kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'demo-module',
    components: {
      kmjsModule
    },
    setup() {
      const formData = ref({});
      const store = useStore();
      onMounted(() => {
        console.log(store.state.demoModule.demo);
      });
      const form: { [l: string]: (data: any[]) => void } = {
        submit: (data: any[]) => {
          formData.value = data[0];
        }
      };
      const [moduleCtl, methods] = useModule({
        params: {
          '/title/tab-menu/value/title-table': {
            reqBody: {
              a: 1
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          switch (moduleName) {
            case '/title/tab-menu/value2/title-form':
              form[name](data);
          }
        }
      });
      return {
        moduleCtl,
        formData
      };
    }
  });
</script>
<style lang="less"></style>
