<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl">
      <template #from-data>
        <p>{{ formData }}</p>
      </template>
      <template #valueTableSearch>
        <p>高级搜索</p>
      </template>
      <template #valueTableDDD="{ row }">
        <i>slot {{ row['name'] }}</i>
      </template>
      <template #formItemAAA="{ modelValue, config, change }">
        <formSlotDemo :model-value="modelValue" :config="config" :change="change"></formSlotDemo>
      </template>
    </kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, nextTick, onMounted, PropType, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { useStore } from 'vuex';
  import formSlotDemo from '@/pages/demo/components/formSlotDemo';

  export default defineComponent({
    name: 'demo-module-code',
    components: {
      kmjsModule,
      formSlotDemo
    },
    setup() {
      const text = ref('');
      const formData = ref({});
      const store = useStore();
      onMounted(() => {
        console.log(store.state.demoModule.demo);
      });
      const form: { [l: string]: (data: any[]) => void } = {
        submit: (data: any[]) => {
          formData.value = data[0];
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '测试模块1',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  type: 'location',
                  label: '定位',
                  emit: 'location'
                },
                {
                  label: '点击',
                  emit: 'click'
                },
                {
                  label: 'reset',
                  emit: 'reset'
                },
                {
                  label: 'setData',
                  emit: 'setData'
                },
                {
                  label: '新建流程',
                  type: 'createBpm'
                },
                {
                  label: '业务新建',
                  type: 'createForm',
                  params: {
                    defSn: '44a120222bf211eca2b50c42a1da1656'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'tab-module',
                name: 'tab-menu',
                permissions: [],
                params: {
                  defaultActive: 'one'
                },
                children: [
                  {
                    type: 'tab-module-item',
                    name: 'value',
                    permissions: [],
                    params: {
                      title: '类目1',
                      value: 'one',
                      isBadge: true
                    },
                    children: [
                      {
                        type: 'table',
                        name: 'title-table',
                        permissions: [],
                        params: {
                          tableDataUrl: '/auth/md/contract/instance/page',
                          items: [
                            {
                              type: 'search',
                              isSlot: true,
                              inputs: [
                                {
                                  label: '方案名称',
                                  key: 'name',
                                  type: 'area',
                                  hideAuto: true
                                },
                                {
                                  label: '方案状态',
                                  key: 'state',
                                  type: 'select',
                                  options: [
                                    {
                                      label: '全部',
                                      value: ''
                                    },
                                    {
                                      label: '待上架',
                                      value: 'none'
                                    },
                                    {
                                      label: '已上架',
                                      value: 'release'
                                    },
                                    {
                                      label: '已下架',
                                      value: 'cancel'
                                    }
                                  ]
                                },
                                {
                                  label: '加入时间',
                                  key: 'daterange',
                                  type: 'daterange',
                                  dateConfig: {
                                    startKey: 'startAt',
                                    endKey: 'endAt'
                                  }
                                }
                              ]
                            },
                            {
                              type: 'table',
                              tableHead: [
                                {
                                  type: 'slot',
                                  label: 'aa',
                                  key: 'ddd'
                                },
                                {
                                  label: '名称',
                                  key: 'qualificationDefName'
                                },
                                {
                                  type: 'image',
                                  label: '方案主图',
                                  key: 'mainImage',
                                  params: {
                                    width: '100px'
                                  }
                                },
                                {
                                  label: '时间格式化',
                                  key: 'actualContactTime',
                                  formatter: 'dateTime'
                                },
                                {
                                  type: 'mapText',
                                  label: '状态',
                                  key: 'state',
                                  params: {
                                    type: 'local',
                                    localData: {
                                      none: '待上架',
                                      release: '已上架',
                                      cancel: '已下架'
                                    }
                                  }
                                },
                                {
                                  type: 'stepInput',
                                  label: '数字',
                                  key: 'number',
                                  params: {
                                    min: 0,
                                    max: 100000,
                                    step: 1
                                  }
                                },
                                {
                                  type: 'mapText',
                                  label: '字典转换',
                                  key: 'dictionary',
                                  params: {
                                    type: 'dictionary',
                                    dictionaryName: 'company_qualification'
                                  }
                                },
                                {
                                  label: '周期',
                                  key: 'time',
                                  type: 'rangeText',
                                  params: {
                                    startKey: 'startAt',
                                    endKey: 'endAt',
                                    formatter: 'dateTime'
                                  }
                                },
                                {
                                  label: '弹框icon',
                                  key: 'qualificationDefName',
                                  params: {
                                    showDiaLogIcon: true,
                                    dialogName: 'dialogType1', // 默认auditRecord组件
                                    dialogTrigger: 'hover', // 与element-ui popover组件 trigger类型一致，默认hover
                                    dialogIconName: 'l-icon-document-checked' //element icon name 默认l-icon-document-checked
                                  }
                                },
                                {
                                  type: 'handle',
                                  label: '操作',
                                  width: 200,
                                  actions: [
                                    {
                                      label: '上架',
                                      emit: 'putaway',
                                      show: 'rule',
                                      rules: [
                                        {
                                          columnKey: 'state',
                                          columnValue: 'none|cancel'
                                        }
                                      ]
                                    },
                                    {
                                      label: '下架',
                                      emit: 'soldOut',
                                      show: 'rule',
                                      rules: [
                                        {
                                          columnKey: 'state',
                                          columnValue: 'release'
                                        }
                                      ]
                                    },
                                    {
                                      type: 'tableEdit',
                                      label: '编辑',
                                      params: {
                                        defSn: '3a46a69a280011eca2b50c42a1da1656',
                                        dataSnKey: 'sn'
                                      }
                                    },
                                    {
                                      type: 'tableDetail',
                                      label: '详情',
                                      params: {
                                        defSn: 'e12c154a1ffd11eca2b50c42a1da1656',
                                        dataSnKey: 'sn'
                                      }
                                    },
                                    {
                                      type: 'tableBpm',
                                      label: '认证',
                                      params: {
                                        dataSnKey: 'sn'
                                      }
                                    }
                                  ]
                                }
                              ],
                              actions: [
                                {
                                  label: '上架',
                                  emit: 'createNew'
                                }
                              ]
                            }
                          ]
                        },
                        slotParam: [
                          {
                            name: 'ddd',
                            slotName: 'valueTableDDD'
                          }
                        ]
                      }
                    ]
                  },
                  {
                    type: 'tab-module-item',
                    name: 'value2',
                    permissions: [],
                    params: {
                      title: '类目2',
                      value: 'two',
                      isBadge: true
                    },
                    children: [
                      {
                        type: 'form',
                        name: 'title-form',
                        permissions: [],
                        params: {
                          parentConfig: {
                            labelWidth: '80px',
                            labelPosition: 'left',
                            dictionary: ['company_qualification'],
                            showBtn: false
                          },
                          itemData: [
                            {
                              label: '供应商',
                              type: 'supplierSelector',
                              key: 'supplier',
                              defaultValue: '',
                              renderConfig: {
                                title: '选择供应商'
                              }
                            },
                            {
                              label: '品牌',
                              type: 'brandCategoryPriceSelector',
                              key: 'brand',
                              defaultValue: '',
                              renderConfig: {
                                title: '选择供应商'
                              }
                            },
                            {
                              label: 'text',
                              type: 'text',
                              disabled: false,
                              key: 'text1',
                              defaultValue: '',
                              validNames: ['required']
                            },
                            {
                              label: 'upload',
                              type: 'uploadImg',
                              key: 'uploadImg',
                              defaultValue: '',
                              validNames: ['required'],
                              uploadConfig: {
                                limit: 2,
                                size: 1
                              }
                            },
                            {
                              label: 'switch',
                              type: 'switch',
                              key: 'switch',
                              defaultValue: false
                            },
                            {
                              label: 'select',
                              type: 'select',
                              key: 'select',
                              defaultValue: 'value2',
                              options: [
                                {
                                  label: 'lable1',
                                  value: 'value1'
                                },
                                {
                                  label: 'lable3',
                                  value: 'value3'
                                },
                                {
                                  label: 'lable2',
                                  value: 'value2'
                                }
                              ]
                            },
                            {
                              label: 'textarea',
                              type: 'expiredDate',
                              key: 'textarea',
                              defaultValue: ''
                            },
                            {
                              label: 'date',
                              type: 'qualificationSelector',
                              key: 'date',
                              defaultValue: ''
                            },
                            {
                              label: 'slot',
                              type: 'slot',
                              key: 'AAA',
                              slotName: 'AAA',
                              defaultValue: '',
                              validNames: ['required']
                            },
                            {
                              label: 'daterange',
                              type: 'daterange',
                              key: 'daterange',
                              defaultValue: '',
                              dateConfig: {
                                startKey: 'startKey',
                                endKey: 'endKey'
                              }
                            },
                            {
                              label: '字典',
                              type: 'select',
                              key: 'dictionary',
                              dictionaryName: 'company_qualification',
                              defaultValue: ''
                            },
                            {
                              label: 'radio',
                              type: 'radio',
                              key: 'dictionaryRadio',
                              dictionaryName: 'company_qualification',
                              defaultValue: ''
                            },
                            {
                              label: 'checkbox',
                              type: 'checkbox',
                              key: 'dictionaryCheckBox',
                              dictionaryName: 'company_qualification',
                              defaultValue: []
                            },
                            {
                              label: '省市区',
                              type: 'area',
                              key: 'area',
                              validNames: ['required']
                            },
                            {
                              label: '定价',
                              type: 'priceInput',
                              key: 'priceInput',
                              validNames: ['required'], // 校验配置
                              disabled: false
                            },
                            {
                              label: '费用',
                              type: 'costTable',
                              key: 'table',
                              defaultValue: '',
                              disabled: false
                            },
                            {
                              label: '类目',
                              type: 'category',
                              key: 'category',
                              disabled: true,
                              validNames: ['required'], // 校验配置
                              params: {
                                sn: 'dsaf1ds56a1f56dsa15dsaqf1dsa32f1dasf54wegsajag',
                                orgSn: '52ecfff5355911eca2b50c42a1da1656'
                              },
                              linkageConfig: {
                                play: {
                                  // 表单系统内使用时，存在tab的概念，使用这个记录
                                  value2: [
                                    {
                                      sourceFormKey: 'priceInput',
                                      businessFormKey: ''
                                    },
                                    {
                                      sourceFormKey: 'table',
                                      businessFormKey: ''
                                    }
                                  ]
                                }
                              }
                            }
                          ]
                        },
                        slotParam: [
                          {
                            name: 'AAA',
                            slotName: 'formItemAAA'
                          }
                        ]
                      },
                      {
                        type: 'slot',
                        name: 'title-form-data',
                        slotName: 'from-data'
                      }
                    ]
                  },
                  {
                    type: 'tab-module-item',
                    name: 'value4',
                    permissions: [],
                    params: {
                      title: '类目3️',
                      value: 'fout'
                    },
                    children: [
                      {
                        type: 'slot',
                        name: 'slotData',
                        slotName: 'slotData',
                        children: [
                          {
                            type: 'slot',
                            name: 'slotData1',
                            slotName: 'slotData1'
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ],
        params: {
          '/title/tab-menu/value/title-table': {
            reqBody: {
              cscDefSn: '5aa6758f70cd4723bd8177a91c6ce304'
            }
          },
          '/title/tab-menu/value2/title-form': {
            valid: {
              text1: [
                {
                  trigger: 'change',
                  validator: (rule: any, value: any, callback: (err?: Error) => void) => {
                    if (value !== '123') {
                      return callback(new Error('请输入123'));
                    }
                    return callback();
                  }
                }
              ]
            },
            inputParams: {
              text1: {
                placeholder: '我是自定义的attr'
              }
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          switch (moduleName + '_' + name) {
            case '/title/tab-menu/value/title-table_tableCheckboxChange':
              data[0].data.name = 'ssss';
              break;
            case '/title/tab-menu/value2/title-form_submit':
              form[name](data);
              break;
            case '/title_click':
              methods['/title/tab-menu/value2/title-form/getData']().then(
                (res: { [l: string]: any }) => {
                  formData.value = res;
                }
              );
              break;
            case '/title_reset':
              formData.value = methods['/title/tab-menu/value2/title-form/getNoVerifyData']();
              console.log(methods['/title/tab-menu/value/title-table/getResponse']());
              break;
            case '/title_setData':
              methods['/title/tab-menu/value2/title-form/setData']({
                uploadImg: 'b11a736b984842bbbe99fffddcd01413'
              });
              break;
          }
        }
      });
      nextTick(() => {
        methods['/title/tab-menu/value/title-table/setSearchOptions']('state', [
          {
            label: 'ss',
            value: '111'
          },
          {
            label: 'ssaa',
            value: '222'
          },
          {
            label: 'adasd',
            value: '333'
          }
        ]);
      });
      return {
        moduleCtl,
        formData,
        text
      };
    }
  });
</script>

<style lang="less"></style>
