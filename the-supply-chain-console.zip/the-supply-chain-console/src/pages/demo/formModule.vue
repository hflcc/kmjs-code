<template>
  <div class="page home-page">
    <FromModule :ctl="ctl">
      <template #slotA>
        <p>aaaaa</p>
      </template>
    </FromModule>
  </div>
</template>

<script lang="tsx">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';
  import FromModule, { useModule } from '@/formModule';

  export default defineComponent({
    name: 'from-module-demo',
    components: {
      FromModule
    },
    setup() {
      const store = useStore();
      const renderMsg = computed(() => store.getters['systemInfo/loginData']);
      const [ctl, methods] = useModule({
        params: {
          defSn: 'dc09635f48de4782ab9e1dc5b1f1f010',
          type: 'create'
        },
        handler: (moduleName, name) => {
          if (name === 'ready') {
            methods.setData({
              supplier_base_info: {
                key1: '1',
                key2: '1',
                key3: '{"areaSn":"433442a4b84d11eba2b50c42a1da1656","address":"1111"}',
                key4: '11',
                key5: '18576680815',
                key6: '111',
                key7: '11',
                key8: '1632758400',
                key9: '1'
              }
            });
          }
        }
      });
      return { renderMsg, ctl };
    }
  });
</script>

<style lang="less" scoped>
  .home-page {
    h1 {
      padding-top: 20px;
      text-align: center;
      font-weight: bolder;
    }
  }
</style>
