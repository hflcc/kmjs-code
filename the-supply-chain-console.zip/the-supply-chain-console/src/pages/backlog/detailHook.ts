import { Ref, ref, UnwrapRef } from 'vue';
import { BacklogDef, togetherHavePot, turnPot } from './api';
import { ElMessage } from 'element-plus';

/**
 * 处理消息/转办/抄送区域的逻辑
 * */
export const useMessageArea = (sn: string, infoData: Ref<UnwrapRef<BacklogDef | null>>) => {
  // 区分是抄送还是转办
  let commandType = '';
  // 显示转办/抄送后的选择机构的弹窗
  const showChooseOrganization = ref(false);

  // 显示确定/驳回的富文本原因输入框
  // const showConfirmMark = ref(false);
  // 编辑确认框弹窗信息
  const confirmInfo = ref({
    show: false,
    result: '',
    require: false,
    title: '',
    cb: (data: string, closeFun: () => void) => {
      return;
    }
  });

  const showMessage = ref(false);
  /**
   * 显示消息
   * */
  const downMenuClick = (e: any) => {
    if (!infoData.value?.imAllowUse) {
      return;
    }
    // console.log(e);
    showMessage.value = !showMessage.value;
  };
  /**
   * 显示转办/抄送
   * */
  const downMenuCommand = (e: string) => {
    if (e !== 'none') {
      commandType = e;
      showChooseOrganization.value = true;
    }
  };
  const showConfirmMarkFun = (params: {
    title: string;
    require: boolean;
    result: string;
    cb: (data: string, closeFun: () => void) => void;
  }) => {
    confirmInfo.value = {
      ...params,
      show: true
    };
  };
  const requestId = new Date().getTime().toString(16);
  /**
   * 获取用户选中的机构组织，进行后续的转办/抄送
   * */
  let selectData: any[] = [];
  const getChooseOrg = async (data: any[]) => {
    if (!commandType) return;
    selectData = data;
    if (commandType === 'zb') {
      showConfirmMarkFun({
        title: '转办',
        result: '',
        require: false,
        cb: handledTask
      });
    } else {
      showConfirmMarkFun({
        title: '抄送',
        result: '',
        require: false,
        cb: handledTask
      });
    }
  };

  // 处理抄送 待办
  const handledTask = async (data: string, closeFun: () => void) => {
    if (commandType === 'zb') {
      const result = await turnPot(infoData.value?.currentNodeList[0]?.sn || '', requestId, {
        requests: selectData.map((v) => {
          return {
            actorType: v.isHuman ? 'inst_user' : 'inst_org_tree',
            actorValue: v.scopeSn,
            actorValueName: v.scopeName || v.name
          };
        }),
        describe: data
      });
      if (!result) return;
    } else {
      const result = await togetherHavePot(sn, {
        requests: selectData.map((v) => {
          return {
            actorType: v.isHuman ? 'inst_user' : 'inst_org_tree',
            actorValue: v.scopeSn,
            actorValueName: v.scopeName || v.name
          };
        }),
        describe: data
      });
      if (!result) return;
    }
    ElMessage.success('操作成功');
    closeFun();
    showChooseOrganization.value = false;
    commandType = '';
  };
  return {
    showChooseOrganization,
    downMenuClick,
    downMenuCommand,
    showConfirmMarkFun,
    getChooseOrg,
    confirmInfo,
    showMessage
  };
};
