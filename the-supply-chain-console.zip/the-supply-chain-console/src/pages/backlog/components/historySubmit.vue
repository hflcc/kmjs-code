<template>
  <div class="history-box">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, watch } from 'vue';
  import { useRouter } from 'vue-router';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { useListToDetail } from '@/utils';

  type Obj = { [i: string]: any };

  export default defineComponent({
    components: {
      kmjsModule
    },
    props: {
      infoData: {
        type: Object,
        default: () => ({})
      }
    },
    setup(props) {
      const router = useRouter();
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'table',
            name: 'title-table',
            permissions: [],
            params: {
              tableDataUrl: '/auth/bpm/instance/page/history',
              items: [
                {
                  type: 'table',
                  tableHead: [
                    {
                      label: '事项',
                      key: 'title',
                      width: 300
                    },
                    {
                      label: '状态',
                      key: 'stateDesc'
                    },
                    {
                      label: '发起人',
                      key: 'createdNameBy'
                    },
                    {
                      label: '发起人部门',
                      key: 'initiatorOrgTreeName'
                    },
                    {
                      label: '审核人',
                      key: 'completeNameBy',
                      width: 200
                    },
                    {
                      label: '审核时间',
                      key: 'completeAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                      }
                    },
                    {
                      label: '审核建议',
                      key: 'completeDesc',
                      width: 200,
                      type: 'richText'
                    },
                    {
                      label: '创建时间',
                      key: 'startAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD hh:mm:ss'
                      }
                    },

                    {
                      label: '操作',
                      type: 'handle',
                      actions: [
                        {
                          label: '详情',
                          emit: 'goDetailPage'
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ],
        params: {
          '/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              const { defSn, bizType, bizSn } = props.infoData || {};
              // obj.url = bizSn
              //   ? `${obj.url}/${defSn}/${bizType}/${bizSn}`
              //   : `${obj.url}/${defSn}/${bizType}`;
              obj.url = bizSn ? `${obj.url}/${bizSn}` : `${obj.url}/${defSn}/${bizType}`;
              return Promise.resolve(props.infoData ? obj : null);
            }
          }
        },
        handler: (moduleName, name, data) => {
          const { row = {} } = data[0] || {};
          switch (name) {
            case 'tableGoDetailPage':
              goDetailPage(row);
              break;
            default:
              break;
          }
        }
      });
      const { setData } = useListToDetail('historySubmitList');

      const goDetailPage = (row: Obj) => {
        const tableData = methods && methods['/title-table/getTableData']();
        setData(tableData.map((item: { instanceSn: string }) => item.instanceSn));
        router.push({
          name: 'subHistoryDetail',
          query: {
            sn: row.instanceSn
          }
        });
      };
      watch(
        () => props.infoData,
        () => {
          methods && methods['/title-table/refresh']();
        }
      );
      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less">
  .history-box {
    height: 500px;

    .kmjs-table-wrap {
      height: 100%;
    }
  }
</style>
