<template>
  <div class="kmjs-card backlog-step-wrap">
    <div class="title">流程</div>
    <div class="content">
      <div class="step-wrap" v-if="stepNodeData.length">
        <div
          class="step-item-wrap"
          v-for="item in stepNodeData"
          :key="item.id"
          :class="['is-' + item.state]"
        >
          <div class="step-line"></div>
          <div
            class="step-item-area"
            :class="{ 'is-border': item.data.length > 1 }"
            :style="{ marginTop: item.data.length === 1 ? '20px' : 'auto' }"
          >
            <div class="step-item" v-for="s in item.data" :key="s.sn" :class="['is-' + s.state]">
              <div class="step-content">
                <div class="step-content-item">
                  <div class="step-icon">
                    <div class="take-bt-content">{{ s.title }}</div>
                  </div>
                  <div
                    class="step-info"
                    :style="{ height: item.data.length === 1 ? '41px' : 'auto' }"
                  >
                    <p class="info">
                      {{ s.takeNameBy }}
                      {{ s.nodeType }}
                      <!--                <span class="chat">-->
                      <!--                  <i class="icon el-icon-chat-dot-round"></i>-->
                      <!--                  <i class="chat-number">12</i>-->
                      <!--                </span>-->
                    </p>
                    <p class="info">{{ s.takeAt }} {{ s.takeTime }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, PropType, ref } from 'vue';
  import { getBacklogDef, StepNodeItem } from '../api';
  import { formatterTime, relativeTimeStr } from '@/utils/formatter';

  export default defineComponent({
    name: 'backlog-step',
    props: {
      sn: {
        type: String as PropType<string>,
        default: ''
      },
      stepData: {
        type: Array as PropType<StepNodeItem[][]>,
        default: () => []
      }
    },
    setup(props) {
      const stepNodeData = ref<{ id: number; state: string; data: StepNodeItem[] }[]>([]);
      onMounted(async () => {
        const data = await getBacklogDef(props.sn);
        if (!data) return;
        const arrData: { id: number; state: string; data: StepNodeItem[] }[] = [];
        let id = 0;
        // 将有状态的节点 和 全部节点进行匹配合并
        // 通过sn去进行匹配
        data.nodeList.forEach((v) => {
          // 记录最终的匹配值
          const nodeList: StepNodeItem[] = [];
          // 多个节点时，判断当前这个总节点的完成状态
          let state: string[] = [];
          // sync 异步 即一个节点完成即算完成
          // osync 同步， 必须两个节点都完成才算完成
          let stateType: 'sync' | 'osync' = 'sync';
          v.forEach((s) => {
            const instance: StepNodeItem[] | undefined = props.stepData.find((k) => {
              return k.find((d) => {
                return d.itemNodeSn === s.sn;
              });
            });
            const item = Object.assign({}, s) as StepNodeItem;
            if (instance && instance.length > 0) {
              Object.assign(item, instance[0]) as StepNodeItem;
            }
            item.takeNameBy = item.completeByName || item.takeNameBy || '';
            // none 未领取 reply 转办中
            if (item.state === 'none' || item.state === 'reply') {
              item.state = 'process';
            }
            // 没有状态时说明离这个节点还很远
            if (!item.state) item.state = 'default';
            if (item.state !== 'none' && item.takeAt) {
              item.takeTime =
                '（用时： ' +
                relativeTimeStr((item.takeAt as number) * 1000, new Date().getTime()) +
                '）';
              item.takeAt = formatterTime(new Date((item.takeAt as number) * 1000));
            } else {
              item.takeTime = '';
              item.takeAt = '';
            }
            switch (item.nodeType) {
              case 'start':
                item.nodeType = '（发起人）';
                item.takeTime = '';
                item.takeNameBy = item.createdNameBy || '';
                break;
              case 'end':
                item.nodeType = '';
                item.takeTime = '';
                item.takeNameBy = '完成';
                break;
              case 'auto':
                item.nodeType = '（自动处理）';
                break;
              default:
                item.nodeType = item.state === 'process' ? '（处理中）' : '';
                break;
            }
            state.push(item.state);
            stateType = item.executeType;
            nodeList.push(item);
          });
          // 同步时，有一个完成即为完成
          if (stateType === 'sync') {
            state = state.includes('complete') ? ['complete'] : ['process'];
          } else {
            // 异步时，状态不同为进行中， 状态相同，显示相同的
            state = new Set(state).size === 1 ? [state[0]] : ['process'];
          }
          arrData.push({
            id: id++,
            state: state.length === 1 ? state[0] : 'process',
            data: nodeList
          });
        });
        stepNodeData.value = arrData;
      });
      return {
        stepNodeData
      };
    }
  });
</script>
<style lang="less">
  .backlog-step-wrap {
    .content {
      padding-top: 10px;
      padding-bottom: 10px;
      overflow-x: auto;
      overflow-y: hidden;

      .step-wrap {
        display: flex;
        align-items: center;

        .step-item-wrap {
          flex: 1;
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          min-width: 250px;

          & + .step-item-wrap {
            .step-line {
              display: block;
            }
          }

          .step-line {
            display: none;
            position: absolute;
            top: calc(50% - 15px);
            right: 50%;
            width: 100%;
            height: 0;
            border-top: 2px dotted @noneStatus;
            z-index: 1;
            background: @noneStatus;
          }

          .step-item-area {
            width: 200px;
            position: relative;
            z-index: 2;

            &.is-border {
              border: 2px solid #000;
              border-radius: 2px;
              background: #fff;
            }

            .step-item {
              display: flex;
              justify-content: center;
              flex: 1;

              & + .step-item {
                .step-line {
                  display: block;
                }
              }

              .step-content {
                position: relative;
                z-index: 10;
                //background: #fff;
                .step-content-item {
                  display: block;

                  .step-icon {
                    font-family: element-icons !important;
                    position: relative;
                    width: 48px;
                    height: 48px;
                    background: @noneStatus;
                    border-radius: 8px;
                    padding: 4px;
                    color: #fff;
                    text-align: center;
                    font-size: 12px;
                    margin: 0 auto 10px;
                    border: 4px solid #fff;
                    box-sizing: content-box;

                    .take-bt-content {
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      width: 100%;
                      height: 100%;
                    }

                    &:before {
                      width: 15px;
                      height: 15px;
                      content: '';
                      color: #fff;
                      text-align: center;
                      line-height: 15px;
                      border-radius: 50%;
                      position: absolute;
                      bottom: -6px;
                      right: -6px;
                      background: @primary;
                      border: 2px solid #fff;
                    }
                  }

                  .step-title {
                    color: @fontColor;
                    font-size: 14px;
                    text-align: center;
                    font-weight: 500;
                  }

                  .step-info {
                    color: @secondFontColor;
                    font-size: 12px;
                    text-align: center;

                    .chat {
                      cursor: pointer;

                      .icon {
                        font-size: 18px;
                        color: @primary;
                      }

                      .chat-number {
                        border-radius: 10px;
                        display: inline-block;
                        color: #fff;
                        font-size: 12px;
                        height: 18px;
                        line-height: 18px;
                        padding: 0 6px;
                        text-align: center;
                        white-space: nowrap;
                        border: 1px solid #fff;
                        background: @primary;
                        font-weight: 500;
                      }
                    }
                  }
                }
              }

              &.is-process {
                .step-content {
                  .step-content-item {
                    .step-icon {
                      background: @primary;

                      &:before {
                        background: @primary;
                        content: '';
                        font-size: 15px;
                      }
                    }
                  }
                }
              }

              &.is-complete {
                .step-content {
                  .step-content-item {
                    .step-icon {
                      background: @success;

                      &:before {
                        background: @success;
                        content: '';
                      }
                    }
                  }
                }
              }

              &.is-default {
                .step-content {
                  .step-content-item {
                    .step-icon {
                      background: @noneStatus;
                      color: #303133;

                      &:before {
                        display: none;
                      }
                    }
                  }
                }
              }
            }
          }

          &.is-process {
            .step-line {
              border-top: 2px solid @primary;
            }

            .is-border {
              border-color: @primary;
            }
          }

          &.is-complete {
            .step-line {
              border-top: 2px solid @success;
            }

            .is-border {
              border-color: @success;
            }
          }

          &.is-default {
            .step-line {
              border-top: 2px dotted #707070;
            }

            .is-border {
              border-color: #707070;
            }
          }
        }
      }
    }
  }
</style>
