<!--审核记录-->
<template>
  <div class="audit-box">
    <template v-if="dataList.length">
      <el-timeline style="margin: 8px">
        <el-timeline-item
          v-for="(item, index) in dataList"
          :key="index"
          hide-timestamp
          placement="top"
          icon="el-icon-success"
          size="large"
        >
          <el-card class="audit-card" :body-style="{ padding: '12px 16px' }">
            <div v-if="index === 0">
              <h4>{{ item.title }}</h4>
              <p>发起人：{{ item.createdNameBy }}</p>
              <p>发起时间：{{ item.takeStr }}</p>
            </div>
            <div v-else>
              <h4>
                {{ item.title }} <span class="take-time">{{ item.takeStr }}</span>
              </h4>
              <p>审核人：{{ item.completeNameBy }}</p>
              <p>审核结果：{{ item.result }}</p>
              <p>审核时间：{{ item.completeStr }}</p>
              <p>用时：{{ item.diffAt }}</p>
              <p>审核建议：</p>
              <p style="color: #757575; padding: 4px 10px" v-html="item.completeDesc || '无'"></p>
            </div>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </template>
    <div v-else class="null-text">
      <div class="el-table__empty-text">暂无数据</div>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import { auditRecordListAPI, RecordListObj } from '../api';
  import { relativeTimeStr } from '@/utils';
  import dayjs from 'dayjs';

  export default defineComponent({
    props: {
      infoData: {
        type: Object,
        default: () => ({})
      }
    },
    setup(props) {
      const dataList = ref<RecordListObj[]>([]);
      const getListData = async () => {
        const { sn } = props.infoData || {};
        const res = await auditRecordListAPI(sn);
        if (res) {
          res.forEach((item) => {
            item.diffAt = relativeTimeStr(item.takeAt * 1000, item.completeAt * 1000);
            item.completeStr = dayjs(item.completeAt * 1000).format('YYYY-MM-DD HH:mm:ss');
            item.takeStr = dayjs(item.takeAt * 1000).format('YYYY-MM-DD HH:mm:ss');
          });
          dataList.value = res;
        }
      };

      getListData();

      return {
        dataList
      };
    }
  });
</script>

<style lang="less">
  .audit-box {
    .null-text {
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      height: 300px;
    }
    .flex-dl {
      display: flex;
      align-items: flex-start;
      justify-content: flex-start;
      margin-bottom: 15px;
      dt {
        margin-right: 15px;
        text-align: right;
        width: 100px;
      }
      dd {
        margin-left: 10px;
      }
    }

    .audit-card {
      color: #101010;

      h4 {
        font-size: 14px;
        font-weight: bold;
        line-height: 24px;
        display: flex;

        .take-time {
          margin-left: auto;
          font-size: 10px;
          color: #666666;
          font-weight: normal;
        }
      }

      p {
        font-size: 12px;
        line-height: 20px;
        word-break: break-all;
      }
    }

    .el-icon-success {
      color: #00b334;
      font-size: 16px;
    }
    .el-icon-error {
      color: #ff9e00;
      font-size: 16px;
    }
  }
</style>
