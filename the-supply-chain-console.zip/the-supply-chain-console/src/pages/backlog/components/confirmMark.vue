<!-- 确认同意/驳回原因 -->
<template>
  <el-dialog v-model="showDialog" @close="closeWindow" :title="title + '确认'">
    <h4 class="confirm-mark-title">{{ title }}结果： {{ result }}</h4>
    <EditCom :controller="editCtl"></EditCom>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { useDialog } from '@/utils';
  import { defineComponent, PropType } from 'vue';
  import EditCom, { useEdit } from '@/components/editor';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'confirm-mark',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      beforeClose: {
        type: Function as PropType<(content: string, close: () => void) => void>,
        default: () => {
          return (data: string) => {
            console.log(data);
          };
        }
      },
      result: {
        type: String as PropType<string>,
        default: ''
      },
      required: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      title: {
        type: String as PropType<string>,
        default: '审核'
      }
    },
    components: {
      EditCom
    },
    setup(props, { emit }) {
      const [editCtl, { getData, clear }] = useEdit({
        autoFocus: true,
        showFullScreen: true,
        placeholder: '请输入' + props.result + '意见' + (props.required ? '（必填）' : '（选填）')
      });
      const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
        if (!v) {
          clear();
        }
      });
      const confirm = () => {
        const data = getData();
        if (!data && props.required) {
          ElMessage.info('请输入' + props.result + '意见');
          return;
        }
        props.beforeClose?.(data, closeWindow);
      };
      return {
        editCtl,
        showDialog,
        closeWindow,
        confirm
      };
    }
  });
</script>
<style lang="less">
  .confirm-mark-title {
    font-weight: 500;
    color: @fontColor;
    margin-bottom: 10px;
  }
</style>
