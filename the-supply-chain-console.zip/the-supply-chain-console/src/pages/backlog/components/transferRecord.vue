<template>
  <div class="trans-box">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
    <!--    驳回详情弹窗-->
    <!--    <el-dialog title="提示" v-model="dialogVisible" width="50%">-->
    <!--      <div class="dialog-content">-->
    <!--        <p v-html="richText"></p>-->
    <!--      </div>-->
    <!--      <template #footer>-->
    <!--        <span class="dialog-footer">-->
    <!--          <el-button type="primary" @click="dialogVisible = false">关闭</el-button>-->
    <!--        </span>-->
    <!--      </template>-->
    <!--    </el-dialog>-->
  </div>
</template>

<script lang="ts">
  import { defineComponent, watch, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { withdrawTask } from '@/pages/backlog/api';

  export default defineComponent({
    components: {
      kmjsModule
    },
    props: {
      infoData: {
        type: Object,
        default: () => ({})
      }
    },
    setup(props) {
      let dialogVisible = ref(false);
      let richText = ref('');
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'table',
            name: 'title-table',
            permissions: [],
            params: {
              tableDataUrl: '/auth/bpm/instance/node/actor/relay/page',
              items: [
                {
                  type: 'table',
                  tableHead: [
                    {
                      label: '转办节点',
                      key: 'bpmInstanceNodeTitle'
                    },
                    {
                      label: '状态',
                      key: 'state',
                      width: 200,
                      type: 'mapText',
                      params: {
                        type: 'local',
                        localData: {
                          agreed: '已接收',
                          pending: '确认中',
                          rejected: '已谢绝',
                          retract: '已撤回'
                        }
                      }
                    },
                    {
                      label: '转办人',
                      key: 'createdNameBy'
                    },
                    {
                      label: '转办人建议',
                      key: 'createdDesc',
                      type: 'richText'
                    },
                    {
                      label: '接收人',
                      key: 'operateNameBy'
                    },
                    // {
                    //   label: '节点',
                    //   key: 'bpmInstanceNodeTitle'
                    // },
                    {
                      label: '接收人建议',
                      key: 'operateDesc',
                      type: 'richText'
                    },
                    {
                      label: '接收时间',
                      key: 'updatedAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                      }
                    },
                    {
                      label: '创建时间',
                      key: 'createdAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD hh:mm:ss'
                      }
                    },
                    {
                      label: '操作',
                      type: 'handle',
                      actions: [
                        // {
                        //   label: '驳回详情',
                        //   emit: 'goRejectDetail',
                        //   show: 'rule',
                        //   rules: [
                        //     {
                        //       columnKey: 'state',
                        //       columnValue: 'rejected'
                        //     }
                        //   ]
                        // }
                        {
                          label: '撤回',
                          emit: 'withdraw',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'state',
                              columnValue: 'pending'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ],
        params: {
          '/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              const { currentNodeList = [] } = props.infoData || {};
              obj.url = `${obj.url}/${currentNodeList[0]?.sn}`;
              return Promise.resolve(props.infoData ? obj : null);
            }
          }
        },
        handler: (moduleName, name, data) => {
          const { row = {} } = data[0] || {};
          switch (name) {
            // case 'tableGoRejectDetail':
            //   richText.value = row.describe;
            //   dialogVisible.value = true;
            //   break;
            case 'tableWithdraw':
              ElMessageBox.confirm(
                `确定要撤回转办给【${row.operateNameBy}】的${props.infoData.title}吗?`,
                '提示'
              ).then(async () => {
                const result = await withdrawTask(row.sn);
                if (!result) return;
                methods && methods['/title-table/refresh']();
                ElMessage.success('操作成功');
              });
              break;
            default:
              break;
          }
        }
      });

      watch(
        () => props.infoData,
        () => {
          methods && methods['/title-table/refresh']();
        }
      );

      return {
        moduleCtl,
        richText,
        dialogVisible
      };
    }
  });
</script>

<style lang="less">
  .trans-box {
    height: 500px;
    .kmjs-table-wrap {
      height: 100%;
    }
    .dialog-content {
      padding: 10px;
    }
  }
</style>
