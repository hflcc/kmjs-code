<template>
  <div class="flot-nav-wrap" @mousedown="move">
    <div class="item" @click="backTop">回到顶部</div>
    <template v-for="item in items" :key="item.elem">
      <div v-show="item.show" class="item" :class="{ active: item.active }" @click="goItem(item)">
        {{ item.label }}
      </div>
    </template>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, onUnmounted, ref } from 'vue';

  interface Item {
    label: string;
    elem: string;
    show: boolean;
    element: null | HTMLElement;
    active: boolean;
  }

  export default defineComponent({
    name: 'flot-nav-component',
    setup() {
      const itemsArr: Item[] = [
        {
          label: '事项信息',
          elem: 'msgArea',
          element: null,
          show: false,
          active: true
        },
        {
          label: '流程',
          elem: 'stepArea',
          show: false,
          element: null,
          active: false
        },
        {
          label: '表单',
          elem: 'formArea',
          show: false,
          element: null,
          active: false
        },
        {
          label: '日志',
          elem: 'logArea',
          show: false,
          element: null,
          active: false
        }
      ];
      let scrollElem: HTMLElement | null = null;
      let scrollElemOffsetTop = 0;
      const items = ref<Item[]>([]);
      /**
       * 监听dom变化，动态显示指定的菜单项
       * */
      const mutationObserver = new MutationObserver(() => {
        items.value = [];
        itemsArr.forEach((v) => {
          const elem = document.getElementById(v.elem);
          if (elem) {
            v.show = true;
            v.element = elem;
            items.value.push(v);
          }
        });
      });
      /**
       * 回到顶部
       * */
      const backTop = () => {
        scrollElem?.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      };
      /**
       * 监听滚动条的位置
       * */
      const scrollFun = (e: Event) => {
        const offsetTop = (e.target as HTMLElement)?.scrollTop;
        if (offsetTop) {
          items.value.forEach((v) => (v.active = false));
          for (let i = 0; i < items.value.length; i++) {
            const item = items.value[i];
            const next = items.value[i + 1];
            if (item.element) {
              if (next && next.element) {
                const offset = item.element.offsetTop - scrollElemOffsetTop;
                const nOffset = next.element.offsetTop - scrollElemOffsetTop;
                if (offsetTop < offset || (offsetTop > offset && offsetTop < nOffset)) {
                  item.active = true;
                  break;
                }
              } else {
                item.active = true;
              }
            }
          }
        }
      };
      /**
       * 滚动到指定的元素的位置
       * */
      const goItem = (item: Item) => {
        const elem = document.getElementById(item.elem);
        if (elem) {
          const top = elem.offsetTop;
          scrollElem?.scrollTo({
            top: Math.abs(top - scrollElemOffsetTop),
            behavior: 'smooth'
          });
        }
      };
      onMounted(() => {
        scrollElem = document.getElementById('wrapComMain');
        if (scrollElem) {
          scrollElemOffsetTop = scrollElem.offsetTop;
          mutationObserver.observe(scrollElem, {
            childList: true
          });
          scrollElem?.addEventListener('scroll', scrollFun);
          // 初始化一下菜单项
          itemsArr.forEach((v) => {
            const elem = document.getElementById(v.elem);
            if (elem) {
              v.show = true;
              v.element = elem;
              items.value.push(v);
            }
          });
        }
      });
      onUnmounted(() => {
        if (scrollElem) {
          mutationObserver.disconnect();
          scrollElem?.removeEventListener('scroll', scrollFun);
        }
      });

      const move = (e: MouseEvent) => {
        const odiv = e.target as HTMLDivElement; //获取目标元素
        //算出鼠标相对元素的位置
        const disX = e.clientX - odiv.offsetLeft;
        const disY = e.clientY - odiv.offsetTop;
        document.onmousemove = (e) => {
          //鼠标按下并移动的事件
          //用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
          const left = e.clientX - disX;
          const top = e.clientY - disY;

          //移动当前元素
          odiv.style.left = left + 'px';
          odiv.style.top = top + 'px';
        };
        document.onmouseup = () => {
          document.onmousemove = null;
          document.onmouseup = null;
        };
      };
      return {
        items,
        backTop,
        goItem,
        move
      };
    }
  });
</script>

<style scoped lang="less">
  .flot-nav-wrap {
    position: absolute;
    left: 90vw;
    top: 75vh;
    width: 112px;
    border-radius: 8px;
    background: @primary;
    padding: 30px 4px;
    z-index: 999999;
    cursor: move;

    .item {
      text-align: center;
      color: #fff;
      background: rgba(255, 255, 255, 0.5);
      cursor: pointer;
      font-size: 14px;
      padding: 7px 0;
      border-radius: 4px;

      & + .item {
        margin-top: 4px;
      }

      &:hover,
      &.active {
        background: #fff;
        color: @primary;
      }
    }
  }
</style>
