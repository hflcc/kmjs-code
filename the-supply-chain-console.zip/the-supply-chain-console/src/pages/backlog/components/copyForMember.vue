<template>
  <div class="trans-box">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, watch } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { cancelCopyAPI } from '../api';

  type Obj = { [i: string]: any };

  export default defineComponent({
    components: {
      kmjsModule
    },
    props: {
      infoData: {
        type: Object,
        default: () => ({})
      }
    },
    setup(props) {
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'table',
            name: 'title-table',
            permissions: [],
            params: {
              tableDataUrl: '/auth/bpm/instance/node/actor/page',
              items: [
                {
                  type: 'table',
                  tableHead: [
                    {
                      label: '抄送人',
                      key: 'createdNameBy'
                    },
                    {
                      label: '状态',
                      key: 'read',
                      width: 200,
                      type: 'mapText',
                      params: {
                        type: 'local',
                        localData: {
                          true: '已读',
                          false: '未读'
                        }
                      }
                    },
                    {
                      label: '抄送建议',
                      key: 'describe',
                      width: 300,
                      type: 'richText'
                    },
                    {
                      label: '接收人',
                      key: 'actorNameValue'
                    },
                    {
                      label: '创建时间',
                      key: 'createdAt',
                      formatter: 'dateTime',
                      params: {
                        dataTimeType: 'YYYY-MM-DD hh:mm:ss'
                      }
                    },
                    {
                      label: '操作',
                      type: 'handle',
                      actions: [
                        {
                          label: '撤回',
                          emit: 'cancelCopy',
                          show: 'rule',
                          rules: [
                            {
                              columnKey: 'read',
                              columnValue: 'false'
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          }
        ],
        params: {
          '/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              const { sn } = props.infoData || {};
              obj.url = `${obj.url}/${sn}/viewer`;
              return Promise.resolve(props.infoData ? obj : null);
            }
          }
        },
        handler: (moduleName, name, data) => {
          const { row = {} } = data[0] || {};
          switch (name) {
            case 'tableCancelCopy':
              ElMessageBox.confirm(
                `确定要撤回抄送给【${row.actorNameValue}】的${props.infoData.title}吗?`,
                '提示'
              )
                .then(() => {
                  handleCancelCopy(row);
                })
                .catch(() => {
                  console.log('cancel');
                });
              break;
            default:
              break;
          }
        }
      });

      /*
       * 确认取消抄送
       * */
      const handleCancelCopy = async (row: Obj) => {
        const res = await cancelCopyAPI(props.infoData?.sn, [row.sn]);
        if (res) {
          ElMessage.success('取消成功');
          refreshTable();
        }
      };

      /*
       * 刷新当前表格数据
       * */
      const refreshTable = () => {
        methods && methods['/title-table/refresh']();
      };

      watch(
        () => props.infoData,
        () => refreshTable()
      );

      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less">
  .trans-box {
    height: 500px;
    .kmjs-table-wrap {
      height: 100%;
    }
  }
</style>
