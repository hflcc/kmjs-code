<template>
  <div class="kmjs-card backlog-msg-wrap">
    <div class="title">事项信息</div>
    <div class="content">
      <div class="item">
        <label>事项：</label>
        <p>{{ data.bizTypeName }}</p>
      </div>
      <div class="item" v-if="isSubHistory">
        <label>状态：</label>
        <p>{{ data.stateDesc }}</p>
      </div>
      <div class="item" v-if="!isSubHistory">
        <label>当前流程节点：</label>
        <p>{{ data?.currentNodeList?.length > 0 ? data.currentNodeList[0]?.title : '' }}</p>
      </div>
      <div class="item">
        <label>总用时：</label>
        <dynamicTime v-if="data.state !== 'complete'" :time="data.startAt"></dynamicTime>
        <p v-else>{{ useTime }}</p>
      </div>
      <div class="item">
        <label>发起人：</label>
        <p>{{ data.createdNameBy }}</p>
      </div>
      <div class="item">
        <label>发起人部门：</label>
        <p>{{ data.createdOrgTreeName }}</p>
      </div>
      <div class="item">
        <label>发起时间：</label>
        <p>{{ createAt }}</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, PropType } from 'vue';
  import { formatterTimer, relativeTimeStr } from '@/utils';
  import { BacklogDef } from '@/pages/backlog/api';
  import dynamicTime from '@/components/dynamicTime';
  export default defineComponent({
    name: 'backlog-msg',
    props: {
      data: {
        type: Object as PropType<BacklogDef>,
        default: () => {
          return {};
        }
      },
      isSubHistory: {
        type: Boolean,
        default: false
      }
    },
    components: {
      dynamicTime
    },
    setup(props) {
      const createAt = computed(() => {
        if (props.data.startAt) {
          return formatterTimer(new Date(props.data.startAt * 1000), 'YYYY-MM-DD HH:mm:ss');
        } else {
          return '-';
        }
      });
      const useTime = computed(() => {
        if (props.data.startAt && props.data.completeAt) {
          return relativeTimeStr(
            props.data.startAt * 1000,
            (props.data.completeAt as number) * 1000
          );
        } else {
          return '--';
        }
      });
      return {
        createAt,
        useTime
      };
    }
  });
</script>
<style lang="less">
  .backlog-msg-wrap {
    .content {
      padding-top: 10px;
      display: grid;
      grid-row-gap: 10px;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: repeat(2, 1fr);

      .item {
        display: flex;
        align-items: center;
      }
    }
  }
</style>
