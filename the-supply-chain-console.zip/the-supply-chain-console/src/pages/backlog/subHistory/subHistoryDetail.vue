<template>
  <Wrap :params="wrapTitle">
    <Message :data="infoData || {}" isSubHistory></Message>
    <div v-if="formCtl" class="kmjs-card" style="padding: 0; border: none">
      <formModule :ctl="formCtl"></formModule>
    </div>
    <div class="gap-20"></div>
    <div class="kmjs-card">
      <div class="title">日志</div>
      <el-tabs activeName="first">
        <el-tab-pane label="消息记录" name="first">
          <div style="height: 300px"></div>
        </el-tab-pane>
        <el-tab-pane label="审核记录" name="second">
          <!--          <audit-record :infoData="infoData"></audit-record>-->
          <audit-record v-if="infoData?.sn" :sn="infoData?.sn"></audit-record>
        </el-tab-pane>
        <el-tab-pane label="转办记录" name="third">
          <transfer-record :infoData="infoData"></transfer-record>
        </el-tab-pane>
        <el-tab-pane label="抄送成员" name="fourth">
          <copy-for-member :infoData="infoData"></copy-for-member>
        </el-tab-pane>
      </el-tabs>
    </div>
  </Wrap>
</template>

<script lang="ts">
  import { defineComponent, onMounted, reactive, ref } from 'vue';
  import Wrap from '@/components/wrap/index.vue';
  import Message from '@/pages/backlog/components/message.vue';
  // import auditRecord from '../components/auditRecord.vue';
  import auditRecord from '@/components/auditRecord';
  import transferRecord from '../components/transferRecord.vue';
  import copyForMember from '../components/copyForMember.vue';
  import formModule, { FormCtl, FromConfig, useModule } from '@/formModule';
  import { BacklogDef, getBacklogInfo } from '@/pages/backlog/api';
  import { useRoute } from 'vue-router';

  export default defineComponent({
    name: 'backlog-detail',
    components: {
      Wrap,
      Message,
      auditRecord,
      transferRecord,
      copyForMember,
      formModule
    },
    setup() {
      const route = useRoute();
      const infoData = ref<BacklogDef | null>(null);
      const formCtl = ref<null | FormCtl>(null);
      const wrapTitle = reactive({
        title: '提交历史详情'
      });
      /**
       * 根据表单的配置，将数据转换为表单模块可以被识别的格式，对数据进行设置做显示
       * */
      const transformFormData = (resConfig: FromConfig, data: Record<string, any>) => {
        const mapData: Record<string, Record<string, any>> = {};
        resConfig.steps.forEach((v) => {
          const mapKey = v.step.property?.keyMapping ?? v.step.key;
          if (v.step.formType === 'grid') {
            mapData[v.step.key] = {
              data: data[mapKey]
            };
          } else {
            mapData[v.step.key] = {};
            v.items.forEach((s) => {
              const mapKey = s.item.property?.keyMapping ?? s.item.name;
              mapData[v.step.key][s.item.name] = data[mapKey];
            });
          }
        });
        return mapData;
      };
      /**
       * 获取历史详情数据
       */
      const getInfoData = async () => {
        if (!route.query.sn) {
          return;
        }
        const data: BacklogDef = await getBacklogInfo(route.query.sn as string);
        if (!data) return;
        infoData.value = data;
        // wrapTitle.title = data.title;
        const currentNode = data.currentNodeList[0];
        if (currentNode && currentNode.formDefSn) {
          const [ctl, methods] = useModule({
            params: {
              defSn: currentNode.formDefSn,
              type: 'detail',
              hideWrap: true
            },
            handler: (moduleName, name) => {
              if (name === 'ready') {
                // methods.setData(currentNode.formDataMap);
                methods.setData(transformFormData(methods.getResConfig(), currentNode.formDataMap));
              }
            }
          });
          formCtl.value = ctl;
        }
      };
      onMounted(() => {
        getInfoData();
      });
      return {
        infoData,
        wrapTitle,
        formCtl
      };
    }
  });
</script>

<style lang="less">
  .dropdown-menu-default {
    padding: 10px 0;

    .el-dropdown-menu__item {
      line-height: 36px;
      padding: 0 20px;
      margin: 0;
      font-size: 14px;
    }
  }
</style>
