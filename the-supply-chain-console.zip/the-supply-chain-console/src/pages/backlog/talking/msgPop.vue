<template>
  <!--  撤回消息-->
  <div class="msg-revoke" v-if="data.isRevoked">{{ data.from.nickname }}撤回了一条消息</div>

  <!-- 常规消息 -->
  <div class="msg" ref="msgRef" v-else>
    <div :class="data.flow === 'in' ? 'msg-left' : 'msg-right'">
      <div class="msg-time" v-if="data.flow === 'in'">
        {{ data.from?.nickname }}
        <span class="hover" style="margin-left: 8px">{{ formatDate(data.time) }}</span>
      </div>
      <div class="msg-time" v-else>
        <span class="hover" style="margin-right: 8px">{{ formatDate(data.time) }}</span>
        {{ data.from?.nickname }}
      </div>
      <div
        class="msg-msg"
        :class="data.flow === 'in' ? '' : 'reverse'"
        :id="'msg-' + data.messageKey"
      >
        <!--        <img :src="data.from?.avatar" alt="" class="head-img" />-->
        <div class="icon-img">{{ data.from?.nickname?.charAt(0) }}</div>
        <div class="msg-pop-root">
          <div
            class="msg-pop"
            v-if="data.messageType === 'TIMTextElem'"
            v-html="data.messageBody.text"
          ></div>
          <el-image
            :src="data.messageBody.url"
            class="msg-pop-img"
            v-else-if="data.messageType === 'TIMImageElem'"
            :preview-src-list="[data.messageBody.url]"
            :hide-on-click-modal="true"
          >
          </el-image>
          <div
            class="msg-pop msg-pop-file"
            v-else-if="data.messageType === 'TIMFileElem'"
            style="padding-left: 3px"
          >
            <img :src="fileIcon()" alt="" />
            <div class="msg-pop-file-info">
              <div>{{ data.messageBody.fileName }}</div>
              <!--            <a :href="data.fileUrl" download></a>-->
              <div style="font-size: 12px">{{ renderSize(data.messageBody.fileSize) }}</div>
            </div>
          </div>

          <div
            class="msg-pop-video"
            @click="videoUrl = data.messageBody.videoUrl"
            v-else-if="data.messageType === 'TIMVideoFileElem'"
          >
            <el-image :src="data.messageBody.thumbUrl" class="msg-pop-img" />
            <div class="video-mask">
              <img src="@/assets/icon_play.png" alt="" />
            </div>
          </div>

          <div
            class="msg-pop msg-pop-order"
            v-else-if="data.messageType === 'TIMCustomElem' && data.messageBody.desc === 'ORDER'"
          >
            <div class="order-title">正在咨询的订单</div>
            <div class="order-item">
              <img class="img" :src="images[messageBody.image]" alt="" />
              <div class="order-info">
                <div class="order-info-name">
                  {{ messageBody.name }}
                </div>
                <div class="order-info-info">
                  共{{ messageBody.quantityGoods }}件商品，合计￥{{ messageBody.orderPrice }}元
                </div>
              </div>
            </div>
            <div class="order-desc" style="margin-top: 6px">
              订单编号：{{ messageBody.orderSn }}
              <span class="copy" @click="copyValue(messageBody.orderSn)">复制</span>
            </div>
            <div class="order-desc">下单时间：{{ messageBody.orderDate }}</div>
          </div>
          <div
            class="msg-pop msg-pop-shop"
            v-else-if="data.messageType === 'TIMCustomElem' && data.messageBody.desc === 'SHOP'"
          >
            <img class="img" :src="images[messageBody.image]" alt="" />
            <div class="flex">
              <div class="msg-pop-shop-name">
                {{ messageBody.name }}
              </div>
              <div class="msg-pop-shop-price">{{ messageBody.priceStr }}</div>
            </div>
          </div>
        </div>
        <img
          v-if="data.messageType === 'TIMFileElem'"
          class="down-icon"
          src="@/assets/downfile.png"
          alt=""
          @click="downloadFiles(data.messageBody.fileUrl, data.messageBody.fileName)"
        />
      </div>
    </div>

    <div class="pop-video" v-if="videoUrl" @click.self="videoUrl = ''">
      <video :src="videoUrl" controls @keyup.esc="videoUrl = ''" autoplay="autoplay"></video>
      <i class="el-icon-circle-close close-icon" @click="videoUrl = ''"></i>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType, ref } from 'vue';
  import { ElMessage } from 'element-plus';
  import { getFileUrlBySeq } from '@/utils/commApi';
  import dayjs from 'dayjs';
  import { downloadFile } from '@/utils';

  // 订单信息
  interface OrderInfo {
    sn: string; // 店铺sn
    name: string; // 商品名称
    image: string; // 图片
    orderPrice: string; // 总价格
    orderSn: string; // 订单号
    orderDate: string; // 下单时间
    quantityGoods: number; // 商品数量
    typeOfMerchandize: number; // 商品种类
  }

  // 商品信息
  interface ShopInfo {
    sn: string;
    // 商品名称
    name: string;
    // 图片
    image: string;
    // 单价,范围价格
    price: string | number | string[];
    // 价格展示
    priceStr: string | '';
  }

  export default defineComponent({
    name: 'msgPop',
    props: {
      data: {
        // eslint-disable-next-line no-undef
        type: Object as PropType<ImChattingRecord>,
        required: true,
        default: () => {
          return {};
        }
      }
    },
    setup(props) {
      // 格式化文件大小的显示
      const renderSize = (value: number | null) => {
        if (null == value) {
          return '0 Bytes';
        }
        let unitArr = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        let srcSize = value;
        let index = Math.floor(Math.log(srcSize) / Math.log(1024));
        let size: number = srcSize / Math.pow(1024, index);
        return size.toFixed(2) + unitArr[index];
      };

      // const downloadFile = (fileUrl: string) => {
      //   window.open(fileUrl, 'download');
      // };

      const messageBody = ref<OrderInfo | ShopInfo | null>(null);
      const images = ref<{ [key: string]: string }>({});

      if (props.data.messageType === 'TIMCustomElem') {
        // eslint-disable-next-line no-undef
        const body = props.data.messageBody as ImFormatRecordCustom;
        if (body.desc === 'ORDER') {
          try {
            // eslint-disable-next-line no-undef
            let data = (props.data.messageBody as ImFormatRecordCustom).data;
            // if (typeof data !== 'string') {
            //   data = JSON.stringify(data);
            // }
            const order = JSON.parse(data) as OrderInfo;
            messageBody.value = order;
            getFileUrlBySeq(order.image).then((res) => {
              images.value[order.image] = res[order.image].url;
            });
          } catch (e) {
            messageBody.value = {
              sn: '',
              name: '',
              image: '',
              orderPrice: '',
              orderSn: '',
              orderDate: '',
              quantityGoods: 0,
              typeOfMerchandize: 0
            };
          }
        } else if (body.desc === 'SHOP') {
          try {
            // eslint-disable-next-line no-undef
            let data = (props.data.messageBody as ImFormatRecordCustom).data;
            // if (typeof data !== 'string') {
            //   data = JSON.stringify(data);
            // }
            const shop = JSON.parse(data) as ShopInfo;
            if (Array.isArray(shop.price)) {
              shop.priceStr = shop.price.join(' ');
            } else {
              shop.priceStr = '￥' + shop.price;
            }
            messageBody.value = shop;
            getFileUrlBySeq(shop.image).then((res) => {
              images.value[shop.image] = res[shop.image].url;
            });
          } catch (e) {
            messageBody.value = { sn: '', name: '', image: '', price: '', priceStr: '' };
          }
        }
      }
      // 格式化日期的显示
      const formatDate = (time: number | undefined) => {
        if (!time) {
          return '';
        }
        const date = dayjs(time);
        return date.format('YYYY-MM-DD HH:mm');
      };

      const videoUrl = ref('');
      // 显示视频
      const showVideo = (url: string) => {
        videoUrl.value = url;
      };

      const downloadFiles = (url: string, name: string) => {
        ElMessage.success('开始下载');
        downloadFile(url, name);
      };

      const fileIcon = (): string => {
        if (props.data.messageType === 'TIMFileElem') {
          // eslint-disable-next-line no-undef
          const body = props.data.messageBody as ImFormatRecordFile;
          if (body.fileName.endsWith('.doc') || body.fileName.endsWith('.docx')) {
            return require('@/assets/icon_word.png');
          }
          if (body.fileName.endsWith('.xls') || body.fileName.endsWith('.xlsx')) {
            return require('@/assets/icon_excal.png');
          }
          if (body.fileName.endsWith('.ppt') || body.fileName.endsWith('.pptx')) {
            return require('@/assets/icon_ppt.png');
          }
          if (body.fileName.endsWith('.pdf')) {
            return require('@/assets/icon_pdf.png');
          }
          // if (props.data.flow === 'in') {
          return require('@/assets/icon_file.png');
          // } else {
          //   return require('../../assets/file1.png');
          // }
        }
        return '';
      };

      return {
        renderSize,
        downloadFiles,
        messageBody,
        images,
        formatDate,
        showVideo,
        videoUrl,
        fileIcon
      };
    }
  });
</script>

<style lang="less" scoped>
  .msg {
    padding: 0 16px;
    margin: 15px 0;
    position: relative;

    &:hover .hover {
      display: initial;
    }

    &-left {
      display: flex;
      flex-direction: column;
      align-items: flex-start;

      .msg-pop {
        background: white;
        border-radius: 4px;
        padding: 8px;
        margin: 0 8px;
        color: #101010;
        white-space: pre-line;
        line-height: 18px;
        max-width: 600px;

        img {
          max-width: 300px;
        }
      }
    }

    &-right {
      display: flex;
      flex-direction: column;
      align-items: flex-end;

      .msg-pop {
        background: #409eff;
        border-radius: 4px;
        padding: 8px;
        margin: 0 8px;
        color: white;
        max-width: 600px;
        white-space: pre-line;
        line-height: 18px;
      }

      .msg-pop-order .order-des {
        color: #f4f4f5;
      }
    }

    &-pop-img {
      max-width: 150px;
      margin: 0 8px;
    }

    &-pop-file {
      margin: 8px;
      display: flex;

      img {
        height: 36px;
        //width: 24px;
        //margin-right: 5px;
      }

      &-info {
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        font-size: 14px;
      }
    }

    &-pop-order {
      display: flex;
      flex-direction: column;
      font-size: 14px;
      font-weight: 400;
      width: 300px;

      .order {
        color: #000000;

        &-title {
          line-height: 30px;
        }

        &-item {
          display: flex;
          margin: 4px 0;
          align-items: flex-end;
          font-size: 12px;
          background: #f4f4f4;
          padding: 5px;
          border-radius: 5px;

          .img {
            width: 52px;
            height: 52px;
            border-radius: 6px;
            margin-right: 8px;
          }

          .order-info {
            flex: 1 1 0%;
            width: 0px;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            height: 52px;

            &-name {
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              line-clamp: 2;
              -webkit-box-orient: vertical;
              font-size: 14px;
              color: #111111;
            }

            &-info {
              color: #a6a6a6;
            }
          }
        }

        &-desc {
          line-height: 18px;
          color: #909399;
          font-size: 12px;
        }
      }

      .copy {
        color: #409eff;
        font-size: 12px;
        cursor: pointer;
        float: right;
      }
    }

    &-pop-shop {
      display: flex;
      width: 300px;
      color: #000000;

      img {
        width: 60px;
        height: 60px;
        border-radius: 8px;
        margin-right: 8px;
      }

      .flex {
        display: flex;
        flex-direction: column;
        justify-content: space-around;
      }

      &-name {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        line-clamp: 2;
        -webkit-box-orient: vertical;
        font-size: 14px;
      }

      &-price {
        color: red;
      }
    }

    &-pop-video {
      position: relative;
      border-radius: 8px;

      .video-mask {
        background: linear-gradient(rgba(0, 0, 0, 0.15) 0%, rgba(0, 0, 0, 0) 100%);
        position: absolute;
        top: 0;
        left: 8px;
        right: 8px;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }

    .down-icon {
      width: 28px;
      height: 28px;
      margin: 8px 0;
    }

    &-msg {
      display: flex;
      flex-direction: row;
      margin-top: 8px;
      word-break: break-all;
      word-wrap: break-word;
    }

    .head-img {
      border-radius: 50%;
      height: 38px;
      width: 38px;
      //border: 1px solid #c7c7c7;
    }
    .icon-img {
      width: 36px;
      height: 36px;
      background: @primary;
      color: #fff;
      text-align: center;
      line-height: 36px;
      border-radius: 50%;
    }

    .read {
      color: #868484;
      font-size: 12px;
      margin-right: 46px;
      margin-top: 5px;
    }

    &-time {
      display: flex;
      align-items: center;

      span {
        font-size: 10px;
        color: #8c939d;
        display: none;
      }
    }

    .reverse {
      flex-direction: row-reverse;
    }

    .msg-pop-root {
      .read {
        text-align: right;
        margin: 3px 8px 0;
        color: #909399;
        font-size: 12px;
      }

      .unread {
        text-align: right;
        margin: 3px 8px 0;
        color: #666666;
        font-size: 12px;
      }
    }

    .menu {
      position: fixed;
      top: -9999px;
      left: -9999px;
      width: 60px;
      border-radius: 6px;
      padding: 2px;
      background: #fff;
      z-index: 3;

      > div {
        text-align: center;
        height: 33px;
        line-height: 33px;
        cursor: pointer;
      }

      > div:hover {
        background: #e1e1e1;
      }
    }
  }

  .msg-revoke {
    text-align: center;
    width: fit-content;
    height: 21px;
    //background: #e4e4e4;
    color: #666666;
    line-height: 21px;
    border-radius: 40px;
    font-size: 12px;
    margin: 12px auto;
    padding: 0 24px;
  }

  .pop-video {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 999;

    video {
      max-width: 80%;
      max-height: 80%;
    }
    .close-icon {
      color: white;
      font-size: 32px;
      margin: 3% -30px 0 5px;
      align-self: flex-start;
    }
  }
</style>
