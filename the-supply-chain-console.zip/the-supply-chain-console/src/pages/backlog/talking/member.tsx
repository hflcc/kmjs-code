import { computed, defineComponent, ref } from 'vue';
import './style.less';
import { useStore } from 'vuex';
import ChooseOrganization from '@/components/chooseOrganization/index.vue';
import DeleteMember from './deleteMember';
import { SearchRespons } from '@/components/chooseOrganization/api';
import { addImMember, deleteImMember } from '@/pages/backlog/api';

export default defineComponent({
  name: 'member',
  props: {
    bpmInstanceSn: {
      type: String,
      required: true
    },
    allowSendMessage: {
      type: Boolean,
      default: true
    },
    groupSn: {
      type: String,
      required: true
    }
  },
  components: {
    ChooseOrganization,
    DeleteMember
  },
  setup(props) {
    // store
    const store = useStore<RootState>();
    // 成员列表
    const memberList = computed<ImUserInfo[]>(() => {
      const member = store.state.im.groupMemberMap[props.groupSn] || {};
      return Object.values(member);
    });

    // 判断是否是群主
    const isGroupLeader = computed<boolean>(() => {
      if (memberList.value.length > 0) {
        return store.state.im.userInfo.accountSn === memberList.value[0].accountSn;
      }
      return false;
    });
    const showChooseOrganization = ref(false);
    const showDeleteMember = ref(false);
    const handleCommand = (command: string) => {
      if (command === 'add') {
        showChooseOrganization.value = true;
      } else if (command === 'minus') {
        showDeleteMember.value = true;
      }
    };
    // 选择成员后的返回
    const getChooseOrg = (selectData: SearchRespons[]) => {
      showChooseOrganization.value = false;
      const data = selectData.map((v) => {
        return {
          memberType: v.isHuman ? 'inst_user' : 'inst_org_tree',
          memberValue: v.scopeSn,
          orgTreeSn: v.isHuman ? v.parentSn : v.sn
        };
      });
      addImMember(props.bpmInstanceSn, data).then((res) => {
        if (res.success) {
          store.dispatch('im/getMemberList', {
            isIm: true,
            groupSn: props.groupSn
          });
        }
      });
    };

    // 删除成员
    const onDelete = (data: string) => {
      showDeleteMember.value = false;
      deleteImMember(props.bpmInstanceSn, data).then((res) => {
        if (res.success) {
          store.dispatch('im/getMemberList', {
            isIm: true,
            groupSn: props.groupSn
          });
        }
      });
    };

    return () => {
      return (
        <div class="member-page">
          <p style={{ marginBottom: '4px' }}>参与者{memberList.value.length}人</p>
          <div class="member-panel">
            <div class="member-list">
              {memberList.value.map((item) => {
                return (
                  <div class="member-item" title={item.nickname}>
                    {/*<img src={item.avatar} class="avatar" />*/}
                    <div class="icon">{item.nickname.charAt(0)}</div>
                    <div class="name">{item.nickname}</div>
                  </div>
                );
              })}
            </div>
            {isGroupLeader.value && props.allowSendMessage ? (
              <div class="member-list-manager">
                <el-dropdown
                  trigger="click"
                  onCommand={(command: string) => handleCommand(command)}
                  v-slots={{
                    dropdown: () => {
                      return (
                        <el-dropdown-menu>
                          <el-dropdown-item command="add">
                            <i
                              class="el-icon-plus"
                              style={{
                                border: '1px solid #d2d2d2',
                                padding: '3px',
                                color: '#b6b9b9'
                              }}
                            />
                            添加成员
                          </el-dropdown-item>
                          <el-dropdown-item command="minus">
                            <i
                              class="el-icon-minus"
                              style={{
                                border: '1px solid #d2d2d2',
                                padding: '3px',
                                color: '#b6b9b9'
                              }}
                            />
                            删除成员
                          </el-dropdown-item>
                        </el-dropdown-menu>
                      );
                    }
                  }}
                >
                  <div class="member-list-manager-btn">
                    <div class="member-list-manager-btn-icon">
                      <svg
                        class="icon"
                        viewBox="0 0 1024 1024"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                        p-id="4396"
                        width="22"
                        height="22"
                      >
                        <path
                          d="M745.2 476.3C819.3 437.8 870 360.6 870 271.8c0-127.1-103.7-230.5-231.2-230.5-32.3 0-63.5 6.6-92.8 19.4-30.6-12.8-64.2-19.9-99.3-19.9C304.6 40.8 189 156.1 189 297.7c0 100.4 58.1 187.5 142.5 229.7C142.5 578.1 3 750.3 3 954.5 3 969.1 14.9 981 29.6 981s26.6-11.9 26.6-26.5c0-214.7 175.2-389.3 390.5-389.3s390.5 174.6 390.5 389.3c0 14.6 11.9 26.5 26.6 26.5 14.7 0 26.6-11.9 26.6-26.5 0-204.2-139.5-376.4-328.5-427.1 8.3-4.2 16.4-8.8 24.2-13.8 1.6 0.1 3.3 0.1 5 0 12.3-1.3 24.8-2 37.2-2 189 0 342.7 153.3 342.7 341.6 0 14.6 11.9 26.5 26.6 26.5 14.7 0 26.6-11.9 26.6-26.5-0.2-176.9-117.7-327-279-376.9z m-106.4-382c98.2 0 178.1 79.6 178.1 177.5 0 92.4-71.2 168.5-161.7 176.7 30.9-42.4 49.3-94.5 49.3-150.8 0-81.1-38-153.5-97.1-200.7 10.2-1.8 20.7-2.7 31.4-2.7zM242.1 297.7c0-112.4 91.8-203.9 204.6-203.9s204.6 91.5 204.6 203.9-91.8 203.9-204.6 203.9-204.6-91.4-204.6-203.9z"
                          fill="#b6b9b9"
                          p-id="4397"
                        />
                      </svg>
                    </div>
                    <p>管理</p>
                  </div>
                </el-dropdown>
              </div>
            ) : (
              ''
            )}
          </div>
          <choose-organization
            v-model={showChooseOrganization.value}
            onOnConfirm={(d: any[]) => {
              getChooseOrg(d);
            }}
          />
          <delete-member
            v-model={showDeleteMember.value}
            onOnDelete={onDelete}
            groupSn={props.groupSn}
          />
        </div>
      );
    };
  }
});
