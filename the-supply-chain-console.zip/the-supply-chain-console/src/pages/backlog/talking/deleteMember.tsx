import { computed, defineComponent, PropType, ref } from 'vue';
import { useDialog } from '@/utils';
import UserItem from '@/components/chooseMember/user-item.vue';
import './style.less';
import { ElMessage } from 'element-plus';
import { useStore } from 'vuex';

interface Member {
  sn: string;
  scopeName: string;
  isCheck: boolean;
  disable: boolean;
}
export default defineComponent({
  name: 'deleteMember',
  props: {
    // 是否显示弹窗
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    groupSn: {
      type: String,
      required: true
    }
  },
  components: {
    UserItem
  },
  emits: ['on-delete'],
  setup(props, { emit }) {
    const store = useStore<RootState>();
    // 每次展示的时候渲染表格
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        textInput.value = '';
        const l: ImUserInfo[] = Object.values(store.state.im.groupMemberMap[props.groupSn]);
        list.value = l.map((item) => {
          return {
            sn: item.instUserSn ?? '',
            scopeName: item.nickname,
            isCheck: false,
            disable: !item.allowDelete,
            phoneNum: item.mobile ?? ''
          };
        });
      }
    });

    // 成员列表
    const list = ref<Member[]>([]);

    const onDelete = () => {
      const data = list.value.filter((item) => item.isCheck);
      if (data.length === 0) {
        return ElMessage.warning('请选择需要删除的成员');
      }
      emit('on-delete', data.map((k) => k.sn).join(','));
    };
    const textInput = ref('');

    // 过滤搜索
    const filterList = computed(() => {
      if (textInput.value) {
        return list.value.filter((item) => item.scopeName.includes(textInput.value));
      } else {
        return list.value;
      }
    });
    const checkList = computed(() => {
      return list.value.filter((item) => item.isCheck);
    });
    const closeTag = (data: Member) => {
      const idx = list.value.indexOf(data);
      if (idx !== -1) {
        list.value[idx].isCheck = false;
      }
    };

    // 选中回调
    const onCheck = (data: Member, check: boolean) => {
      const idx = list.value.indexOf(data);
      if (idx !== -1) {
        list.value[idx].isCheck = check;
      }
    };

    return () => {
      return (
        <el-dialog
          width={'700px'}
          v-model={showDialog.value}
          onClose={closeWindow}
          title="删除成员"
          v-slots={{
            footer: () => {
              return (
                <el-space>
                  <el-button onClick={closeWindow}>取消</el-button>
                  <el-button type={'primary'} onClick={onDelete}>
                    删除
                  </el-button>
                </el-space>
              );
            }
          }}
        >
          <div class="delete-page">
            <p>搜索</p>
            <el-input
              placeholder="搜索关键字"
              class="delete-page-search"
              v-model={textInput.value}
              v-slots={{
                append: () => {
                  return <el-button icon="el-icon-search" />;
                }
              }}
            />
            <div class="delete-page-list">
              {filterList.value.map((item) => {
                return (
                  <user-item
                    data={item}
                    onOnChecked={onCheck}
                    isCheck={item.isCheck}
                    disable={item.disable}
                  />
                );
              })}
            </div>
            <div class="value-area">
              <h4 class="value-area-title">已选</h4>
              <el-space style={{ flexWrap: 'wrap' }}>
                {checkList.value.map((item) => {
                  return (
                    <el-tag
                      closable={true}
                      onClose={() => closeTag(item)}
                      style={{ marginBottom: '8px' }}
                    >
                      {item.scopeName}
                    </el-tag>
                  );
                })}
              </el-space>
            </div>
          </div>
        </el-dialog>
      );
    };
  }
});
