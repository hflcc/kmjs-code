<template>
  <div class="editor">
    <div ref="editor" @keydown="onKeyDown"></div>

    <div class="footer">
      <div style="margin-right: 12px">Shift+Enter换行 Enter发送</div>
      <div class="btn" @click="sendMsg">发送</div>
    </div>

    <div class="editor-mask" v-if="finish">流程已结束</div>
    <div class="editor-mask" v-else-if="!isImOnline">您已在其他地方登录</div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue';
  // 引入wangeditor组件
  import E from 'wangeditor';
  import { ElMessage } from 'element-plus';
  import { useStore } from 'vuex';
  import { NodeType } from 'wangeditor/dist/text/getChildrenJSON';
  import {
    createFileMessage,
    createImageMessage,
    createTextMessage,
    createVideoMessage
  } from '@/utils/im/utils';
  import { getFileUrlBySeq, uploadFile as uploadImg } from '@/utils/commApi';
  import TIM from 'tim-js-sdk';
  import { sendImMessage } from '@/utils/im/api';

  const uploadIcon = require('@/assets/upload_file.png');
  const screenshotIcon = require('@/assets/screenshot.png');
  const uploadImgIcon = require('@/assets/upload_img.png');
  const { BtnMenu } = E;

  export default defineComponent({
    name: 'imEditor',
    props: {
      groupSn: {
        type: String,
        required: true
      },
      finish: {
        type: Boolean,
        required: true
      }
    },
    setup(props) {
      // 获取编辑器实例html
      const editor = ref();
      // 编辑器实例对象
      let instance: E | null;
      // store
      const store = useStore<RootState>();

      const isImOnline = computed(() => {
        return store.state.im.isImOnline;
      });

      // 输入内容发送到群组上
      // eslint-disable-next-line no-undef
      const send = (data: CreateMessageResult) => {
        if (data.success) {
          sendImMessage(props.groupSn, data.data).then();
        } else {
          ElMessage.error(data.data ? data.data : '发送失败');
        }
      };

      // 文件上传
      class UploadFile extends BtnMenu {
        constructor(editor: E) {
          // data-title属性表示当鼠标悬停在该按钮上时提示该按钮的功能简述
          const $elem = E.$(
            `<div class="w-e-menu file" >
                <input type="file" id="fileFile" style="filter:alpha(opacity=0);opacity:0;width: 0;height: 0;"/>
                <img style="width: 14px;height: 14px" src="${uploadIcon}">
                <video id="video" preload style="display: none"  />
            </div>
            <div class="menu-tips">
                    传输文件
                  </div>`
          );
          super($elem, editor);
        }

        // 菜单点击事件
        clickHandler() {
          let inputObj = document.getElementById('fileFile') as HTMLInputElement;
          inputObj.value = '';
          inputObj.onchange = (e) => uploadFile(e, 'sendFile');
          inputObj.click();
        }
        tryChangeActive() {
          this.active();
        }
      }

      // 图片上传
      class UploadImage extends BtnMenu {
        constructor(editor: E) {
          // data-title属性表示当鼠标悬停在该按钮上时提示该按钮的功能简述
          const $elem = E.$(
            `<div class="w-e-menu image" >
                <input type="file" id="imgFile"  accept=".jpg,.jpeg,.png,.gif,.webp,.jfif" style="filter:alpha(opacity=0);opacity:0;width: 0;height: 0;"/>
                <img style="width: 14px;height: 14px" src="${uploadImgIcon}">
            </div>
                  <div class="menu-tips">
                    传输图片
                  </div>`
          );
          super($elem, editor);
        }

        // 菜单点击事件
        clickHandler() {
          // 做任何你想做的事情
          // 可参考【常用 API】文档，来操作编辑器
          let inputObj = document.getElementById('imgFile') as HTMLInputElement;
          inputObj.value = '';
          inputObj.onchange = (e) => uploadFile(e, 'sendImg');
          inputObj.click();
        }

        tryChangeActive() {
          this.active();
        }
      }

      // 截图
      class Screenshot extends BtnMenu {
        constructor(editor: E) {
          // data-title属性表示当鼠标悬停在该按钮上时提示该按钮的功能简述
          const $elem = E.$(
            `<div class="w-e-menu screen" >
                     <img style="width: 14px;height: 14px" src="${screenshotIcon}">
                  </div>
                  <div class="menu-tips">
                    请使用系统截屏<br />WINDOWS系统：win徽标键+Shift+S<br />MAC系统：Command+Shift+4
                  </div>`
          );
          super($elem, editor);
        }

        // 菜单点击事件
        clickHandler() {
          // no
        }

        tryChangeActive() {
          this.active();
        }
      }

      function uploadFile(e: Event, event: string) {
        let files: FileList = (e.target as HTMLInputElement).files as FileList;
        if (files.length > 0) {
          const file = files[0];

          // 判断如果是图片，还是发送图片
          if (/.(gif|jpg|jpeg|png|webp|jfif)$/i.test(file.name)) {
            event = 'sendImg';
          }
          if (/.(mp4|rmvb|avi|flv|m2v|mkv)$/i.test(file.name)) {
            event = 'sendVideo';
          }
          if (event === 'sendImg') {
            if (!/.(gif|jpg|jpeg|png|webp|jfif)$/i.test(file.name)) {
              return ElMessage.warning('请选择图片文件');
            }
            createImageMessage(file).then((data) => {
              send(data);
            });
          } else if (event === 'sendVideo') {
            createVideoMessage(file).then((data) => {
              send(data);
            });
          } else if (event === 'sendFile') {
            createFileMessage(file).then((data) => {
              send(data);
            });
          }
        }
      }

      const seqMap: { [url: string]: string } = {};

      // 去除html化
      const htmlToStr = (context: string) => {
        let str = context.replace(/<xml>[\s\S]*?<\/xml>/gi, '');
        str = str.replace(/<style>[\s\S]*?<\/style>/gi, '');
        str = str.replace(/<\/?[^>]*>/g, '');
        str = str.replace(/[ |]*\n/g, '\n');
        str = str.replace(/&nbsp;/gi, ' ');
        str = str.replace(/<br\/>/gi, '\n');
        return str;
      };

      onMounted(() => {
        // 编辑器实例对象
        instance = new E(editor.value);
        instance.menus.extend('uploadFile', UploadFile);
        instance.menus.extend('uploadImage', UploadImage);
        instance.menus.extend('screenshot', Screenshot);
        // 自定义菜单
        instance.config.menus = [
          'emoticon', // 表情包
          'uploadFile', // 上传文件
          'uploadImage', // 上传图片
          'screenshot', // 截图
          'image' // 截图图片，没有这个，无法直接粘贴截图的图片
          // 'fontSize' //字号
        ];
        // 开启本地上传图片(这是后端上传链接)
        instance.config.customUploadImg = function (
          resultFiles: FileList,
          insertImgFn: (res: string) => void
        ) {
          uploadImg(resultFiles[0]).then((res) => {
            getFileUrlBySeq(res.seq).then((r) => {
              insertImgFn(r[res.seq].url);
              seqMap[r[res.seq].url] = res.seq;
            });
          });
        };
        // instance.config.uploadImgShowBase64 = true;
        // 限制上传图片格式
        // instance.config.uploadImgAccept = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
        // 设置编辑器高度
        instance.config.height = 80;
        // 设置编辑器页面层级
        instance.config.zIndex = 1;
        // 设置编辑器placeholder
        instance.config.placeholder = '';
        // 忽略粘贴内容中的图片
        instance.config.pasteIgnoreImg = true;
        // 关闭粘贴样式的过滤
        instance.config.pasteFilterStyle = true;
        // 是否显示全屏
        instance.config.showFullScreen = false;
        // 表情包配置
        instance.config.emotions = [
          {
            // tab 的标题
            title: '表情',
            // type -> 'emoji' / 'image'
            type: 'emoji',
            // content -> 数组
            content:
              '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 😘 😗 😙 😚 😋 😛 😝 😜 🤓 😎 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 😢 😭 😤 😠 😡 😳 😱 😨 🤗 🤔 😶 😑 😬 🙄 😯 😴 😷 🤑 😈 🤡 💩 👻 💀 👀 👣'.split(
                /\s/
              )
          },
          {
            // tab 的标题
            title: '手势',
            // type -> 'emoji' / 'image'
            type: 'emoji',
            // content -> 数组
            content:
              '👐 🙌 👏 🤝 👍 👎 👊 ✊ 🤛 🤜 🤞 ✌️ 🤘 👌 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤙 💪 🖕 ✍️ 🙏'.split(
                /\s/
              )
          }
        ];
        // 复制的转换
        instance.config.pasteTextHandle = htmlToStr;

        instance.config.onblur = function () {
          serviceStyle.left = '-9999px';
          serviceStyle.bottom = '9999px';
        };

        instance.create();

        // instance.txt.html(
        //   '<p><img src="https://resource.kmyun.cn/kmjs/7743221a9b1e49c9bbdc031576dd9794.png" style="max-width:100%;">水电费<br></p>'
        // );

        // 设置隐藏默认的图片选择器。没有图片选择器，截图图片，粘贴不进去
        const imgEle = document.getElementsByClassName('w-e-icon-image ')[0] as HTMLDivElement;
        if (imgEle && imgEle.parentElement) {
          imgEle.parentElement.style.display = 'none';
        }
      });
      /**
       * @name: 生命周期函数-----页面卸载之前
       * @author: camellia
       * @email: guanchao_gc@qq.com
       * @date: 2021-01-19
       */
      onBeforeUnmount(() => {
        instance?.destroy();
        instance = null;
      });
      watch(
        () => props.groupSn,
        (val) => {
          if (val) {
            instance?.txt.clear();
          }
        }
      );
      const serviceStyle = reactive({
        bottom: '9999px',
        left: '-9999px'
      });
      // 监听按键
      const onKeyDown = (e: KeyboardEvent) => {
        if (e.shiftKey && e.code == 'Enter') {
          // console.info('shift+回车');
          e.preventDefault();
          let EMPTY_P = '<p data-we-empty-p=""><br></p>';
          instance?.cmd.do('insertHTML', EMPTY_P);
        } else if (!e.shiftKey && !e.ctrlKey && !e.altKey && e.key == 'Enter') {
          // console.info('回车');
          e.preventDefault();
          sendMsg();
          // 只有两个人时不显示@功能
        }
      };

      const findTag = (str: NodeType): { type: string; value: string }[] => {
        let result: { type: string; value: string }[] = [];
        if (str.tag === 'p') {
          if (str.children.length > 0) {
            str.children.forEach((item) => {
              if (typeof item === 'string') {
                result.push({
                  type: 'text',
                  value: item
                });
              } else {
                return result.push(...findTag(item));
              }
            });
          }
        } else if (str.tag === 'img') {
          const img = str.attrs.find((i) => i.name === 'src');
          if (img)
            result.push({
              type: 'img',
              value: img.value
            });
        }
        return result;
      };
      const getContent = () => {
        const json = instance?.txt.getJSON();
        let temp: { type: string; value: string }[] = [];
        json?.forEach((item) => {
          if (typeof item !== 'string') {
            temp.push(...findTag(item));
          }
        });
        let result: { type: string; value: string }[] = [];
        temp.forEach((item) => {
          if (result.length > 0) {
            if (item.type === 'img') {
              result.push(item);
            } else {
              // 如果上一个也是text 则一起
              if (item.type === 'text') {
                // 如果是空 忽略
                if (!item.value) {
                  return;
                }
                const last = result[result.length - 1];
                if (last.type === 'text') {
                  last.value += '\n' + item.value;
                } else {
                  result.push(item);
                }
              }
            }
          } else {
            result.push(item);
          }
        });
        // console.log(result);
        return result;
      };

      // 发送
      const sendMsg = async () => {
        // const html = htmlToStr(instance?.txt.html() as string);
        // const html = instance?.txt.html() as string;
        const html = getContent();
        if (html.length === 0) {
          const text = instance?.txt.text() as string;
          if (text.trim().length === 0) {
            ElMessage.error('发送的内容为空');
            return;
          }
          if (text.trim().length > 5000) {
            ElMessage.error('发送的内容过长');
            return;
          }
          createTextMessage(text.trim()).then((data) => {
            send(data);
            instance?.txt.clear();
          });
        }

        html.forEach((item) => {
          if (item.type === 'text') {
            if (item.value.trim().length > 5000) {
              ElMessage.error('发送的内容过长');
              return;
            }
            createTextMessage(item.value.trim()).then((data) => {
              send(data);
              instance?.txt.clear();
            });
          } else if (item.type === 'img' && seqMap[item.value]) {
            send({
              success: true,
              data: {
                messageType: TIM.TYPES.MSG_IMAGE,
                messageBody: {
                  UUID: new Date().getTime() + '',
                  ImageFormat: 255,
                  ImageInfoArray: [
                    {
                      Type: 1,
                      Size: 0,
                      Width: 0,
                      Height: 0,
                      URL: seqMap[item.value]
                    }
                  ]
                }
              }
            });
            instance?.txt.clear();
          }
        });
      };

      return {
        editor,
        onKeyDown,
        sendMsg,
        serviceStyle,
        isImOnline
      };
    }
  });
</script>

<style scoped lang="less">
  .editor {
    position: relative;

    .editor-mask {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.08);
      z-index: 10;
      text-align: center;
      padding-top: 90px;
    }
    /deep/ .w-e-text-container {
      border-bottom: none !important;
    }

    /deep/ .w-e-menu .w-e-panel-container .w-e-panel-tab-content {
      height: 160px !important;
    }
    /deep/ .w-e-panel-container {
      margin-top: 0 !important;
      margin-left: 36px !important;
    }

    .footer {
      //position: absolute;
      //bottom: 15px;
      //right: 15px;
      z-index: 2;
      display: flex;
      align-items: center;
      color: #959595;
      border: 1px solid #c9d8db;
      padding: 0 16px 27px 0;
      justify-content: flex-end;
      border-top: none;
      margin: 0;

      .btn {
        height: 32px;
        line-height: 32px;
        width: 80px;
        font-size: 12px;
        color: #409eff;
        text-align: center;
        border: 1px solid;
        border-radius: 3px;
        cursor: pointer;
      }
    }

    .service-list {
      position: absolute;
      left: -9999px;
      z-index: 3;
      background: white;
      width: 100%;
      line-height: 28px;
      overflow: auto;
      max-height: 300px;
      > div {
        padding: 0 8px;
        display: flex;
        align-items: center;
        margin: 5px 0;
      }
      > div:hover {
        background: #e1e1e1;
      }

      img {
        width: 28px;
        height: 28px;
        margin-right: 5px;
        border-radius: 50%;
      }
    }

    /deep/ .w-e-text p {
      margin: 0 !important;
      word-break: break-all;
    }
    /deep/ .w-e-text {
      padding: 10px !important;
    }

    /deep/ .screen:hover + .menu-tips,
    /deep/ .file:hover + .menu-tips,
    /deep/ .image:hover + .menu-tips {
      display: block;
    }

    /deep/ .menu-tips {
      display: none;
      position: absolute;
      left: 16px;
      top: 45px;
      padding: 10px;
      line-height: 16px;
      color: #909399;
      z-index: 13;
      border-radius: 5px;
      border: 1px solid #e4e4e4;

      &::before {
        content: '';
        position: absolute;
        width: 0;
        height: 0;
        left: 120px;
        top: -15px;
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        border-bottom: 15px solid #e4e4e4;
      }

      &::after {
        content: '';
        position: absolute;
        width: 0;
        height: 0;
        left: 120px;
        top: -13px;
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        border-bottom: 15px solid #fff;
      }
    }

    /deep/ .file + .menu-tips {
      left: 24px;

      &::before,
      &::after {
        left: 30px;
      }
    }

    /deep/ .image + .menu-tips {
      left: 65px;

      &::before,
      &::after {
        left: 30px;
      }
    }
  }
</style>
