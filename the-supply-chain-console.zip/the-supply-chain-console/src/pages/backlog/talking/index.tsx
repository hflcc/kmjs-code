import { defineComponent, ref } from 'vue';
import './style.less';
import ImEditor from '@/pages/backlog/talking/imEditor.vue';
import MessagePanel from '@/pages/backlog/talking/messagePanel.vue';
import Member from '@/pages/backlog/talking/member';
import { useStore } from 'vuex';
import { clearImUnreadCount } from '@/pages/backlog/api';

export default defineComponent({
  name: 'talking',
  props: {
    groupSn: {
      type: String,
      required: true
    },
    allowSendMessage: {
      type: Boolean,
      default: true
    },
    bpmInstanceSn: {
      type: String,
      required: true
    }
  },
  components: {
    ImEditor,
    MessagePanel,
    Member
  },
  emits: ['on-close'],
  setup(props, { emit }) {
    const store = useStore<RootState>();
    store.dispatch('im/initImInfo', props.groupSn).then();

    // 清除未读数
    clearImUnreadCount(props.bpmInstanceSn).then();

    const talking = ref<null | HTMLDivElement>(null);

    const move = (e: MouseEvent) => {
      const target = talking.value; //获取目标元素
      if (!target) {
        return;
      }

      //算出鼠标相对元素的位置
      const disX = e.clientX - target.offsetLeft;
      const disY = e.clientY - target.offsetTop;
      document.onmousemove = (e) => {
        //鼠标按下并移动的事件
        //用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
        const left = e.clientX - disX;
        const top = e.clientY - disY;

        //移动当前元素
        target.style.left = left + 'px';
        target.style.top = top + 'px';
      };
      document.onmouseup = () => {
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };
    return () => {
      return (
        <div class="talking-page" ref={talking}>
          <header onMousedown={move}>
            <span>消息</span>
            <i class="el-icon-close" onClick={() => emit('on-close')} color="#000000" />
          </header>
          <Member
            bpmInstanceSn={props.bpmInstanceSn}
            allowSendMessage={props.allowSendMessage}
            groupSn={props.groupSn}
          />
          <div class="msg-list">
            <message-panel groupSn={props.groupSn} />
          </div>
          <div class="editor">
            <im-editor groupSn={props.groupSn} finish={!props.allowSendMessage} />
            {/*{props.allowSendMessage ? '' : <div class="editor-disabled">流程已结束</div>}*/}
          </div>
        </div>
      );
    };
  }
});
