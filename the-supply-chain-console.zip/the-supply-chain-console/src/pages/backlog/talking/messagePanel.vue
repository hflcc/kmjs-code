<template>
  <div style="height: 100%; position: relative" v-if="groupSn">
    <div v-show="isShowScrollBottomTips" class="newMessageTips" @click="scrollMessageListToBottom">
      回到最新位置
    </div>
    <div class="message-panel" ref="scroll" @scroll="onScroll">
      <!--   loading -->
      <div class="more" v-if="!isCompleted">
        <span @click="moreMsg">查看更多</span>
      </div>
      <div class="msg-divider" v-else>
        <div class="divider"></div>
        <div>对话开始</div>
        <div class="divider"></div>
      </div>

      <div v-for="(msg, idx) in chattingList" :key="msg.sn">
        <!--   显示时间标签，超过三分钟的消息，显示一次时间标签 -->
        <div
          v-if="idx > 0 && msg.time - chattingList[idx - 1].time > 3 * 60 * 1000"
          class="msg-date"
        >
          {{ formatDate(msg.time) }}
        </div>
        <div v-else-if="idx === 0" class="msg-date">
          {{ formatDate(msg.time) }}
        </div>
        <!--      显示消息内容-->
        <msg-pop :data="msg"></msg-pop>
      </div>
    </div>
  </div>
  <div class="message-panel" style="height: 100%; position: relative" v-else></div>
</template>

<script lang="ts">
  import { computed, defineComponent, nextTick, onActivated, ref, watchEffect } from 'vue';
  import MsgPop from './msgPop.vue';
  import { useStore } from 'vuex';
  import dayjs from 'dayjs';
  import TIM from 'tim-js-sdk';

  export default defineComponent({
    name: 'messagePanel',
    components: { MsgPop },
    props: {
      groupSn: {
        type: String,
        required: true
      }
    },
    setup(props) {
      // store
      const store = useStore<RootState>();
      const isCompleted = ref(false);

      const scroll = ref<null | HTMLDivElement>(null);

      // 聊天记录
      // eslint-disable-next-line no-undef
      const chattingList = computed<ImChattingRecord[]>(() => {
        const list = store.state.im.chattingRecordMap[props.groupSn] || [];
        // eslint-disable-next-line no-undef
        return list.filter((item: ImChattingRecord) => {
          if (item.messageType !== TIM.TYPES.MSG_CUSTOM) {
            return true;
          }
          // eslint-disable-next-line no-undef
          const body = item.messageBody as ImFormatRecordCustom;
          return body.desc === 'ORDER' || body.desc === 'SHOP';
        });
      });

      const scrollOffset = 80;

      // 如果滚到底部就保持在底部，否则提示是否要滚到底部
      const keepMessageListOnBottom = () => {
        if (!scroll.value) {
          return;
        }
        // 距离底部50px内强制滚到底部,否则提示有新消息
        if (
          preScrollHeight.value - scroll.value.clientHeight - scroll.value.scrollTop <
          scrollOffset
        ) {
          // 有图片的时候，加载会比较慢，所以需要延长下
          setTimeout(() => {
            if (!scroll.value) {
              return;
            }
            if (
              preScrollHeight.value - scroll.value.clientHeight - scroll.value.scrollTop <
              scrollOffset
            ) {
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              scroll.value.scrollTop = scroll.value.scrollHeight;
            }
          }, 400);
          isShowScrollBottomTips.value = false;
        } else {
          isShowScrollBottomTips.value = true;
        }
        preScrollHeight.value = scroll.value.scrollHeight;
      };
      // 滚动到底部
      const scrollMessageListToBottom = () => {
        nextTick(() => {
          if (!scroll.value) {
            return;
          }
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          scroll.value.scrollTop = scroll.value.scrollHeight;
          preScrollHeight.value = scroll.value?.scrollHeight;
          isShowScrollBottomTips.value = false;
        });
      };

      // 第一次加载聊天记录后，自动滚动到底部
      let firstLoad = true;
      // 监听聊天记录的变化
      watchEffect(() => {
        const list = chattingList.value;
        if (list.length > 0) {
          keepMessageListOnBottom();
          isCompleted.value = list[0].isFirst || false;
          if (firstLoad) {
            firstLoad = false;
            scrollMessageListToBottom();
          }
        } else {
          isCompleted.value = true;
        }
      });

      onActivated(() => {
        scrollMessageListToBottom();
      });

      // 加载更多的聊天记录
      const moreMsg = async () => {
        await store.dispatch('im/getServiceRecord', {
          lastSn: chattingList.value[0].sn,
          isIm: true
        });
        await nextTick(() => {
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          scroll.value.scrollTop = scroll.value.scrollHeight - preScrollHeight.value;
        });
      };

      // 格式化日期的显示
      const formatDate = (time: number | undefined) => {
        if (!time) {
          return '';
        }
        const date = dayjs(time);
        const dateNow = new Date(new Date(new Date().toLocaleDateString()).getTime()).getTime();

        const hm = date.format('HH:mm');
        // 今天
        if (time > dateNow) {
          return `今天  ${hm}`;
        } else if (time >= dateNow - 24 * 60 * 60 * 1000) {
          return `昨天  ${hm}`;
        } else if (time >= dateNow - 2 * 24 * 60 * 60 * 1000) {
          return `前天  ${hm}`;
        }

        return date.format('YYYY-MM-DD HH:mm');
      };

      // 回到最新位置的提示
      const isShowScrollBottomTips = ref(false);
      //
      const preScrollHeight = ref(0);
      // 滚动监听
      const onScroll = ({ target: { scrollTop } }: any) => {
        if (scroll.value) {
          isShowScrollBottomTips.value =
            preScrollHeight.value - scroll.value.clientHeight - scrollTop >= scrollOffset;
        }
      };

      return {
        moreMsg,
        chattingList,
        formatDate,
        isCompleted,
        onScroll,
        scroll,
        isShowScrollBottomTips,
        scrollMessageListToBottom
      };
    }
  });
</script>

<style lang="less" scoped>
  .message-panel {
    background: #f4f4f5;
    overflow: auto;
    height: 100%;
    //padding-top: 15px;

    //&::-webkit-scrollbar {
    //  display: none;
    //}

    .more {
      color: #528fff;
      text-align: center;
      margin: 8px 0;

      span {
        cursor: pointer;
      }
    }

    .msg-date {
      text-align: center;
      width: fit-content;
      height: 21px;
      background: #e4e4e4;
      color: #909399;
      line-height: 21px;
      border-radius: 40px;
      font-size: 12px;
      margin: 12px auto 0;
      padding: 0 24px;
    }

    .msg-start {
      text-align: center;
    }
    .msg-divider {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 30px;
      font-size: 13px;
      color: #909399;
      .divider {
        width: 50px;
        height: 1px;
        background: #e4e4e4;
        margin: 0 16px;
      }
    }
  }

  .newMessageTips {
    position: absolute;
    cursor: pointer;
    padding: 5px;
    width: 120px;
    margin: auto;
    left: 0;
    right: 0;
    bottom: 5px;
    font-size: 12px;
    text-align: center;
    border-radius: 10px;
    border: #e9eaec 1px solid;
    background-color: #fff;
    color: #2d8cf0;
    z-index: 15;
  }
</style>
