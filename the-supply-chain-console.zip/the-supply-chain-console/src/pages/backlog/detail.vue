<template>
  <Wrap v-if="show" :params="wrapTitle">
    <template #actions>
      <el-space style="margin-bottom: 20px">
        <el-button
          class="el-button--refresh"
          icon="el-icon-refresh-right"
          size="mini"
          @click="refreshData"
        ></el-button>
        <el-button v-if="canEdit" size="mini" @click="resetData"> 重置</el-button>
        <el-dropdown
          trigger="click"
          split-button
          size="mini"
          @command="downMenuCommand"
          @click="downMenuClick"
        >
          <el-badge :value="msgCount" class="item" :hidden="!infoData?.imAllowUse">
            <el-button
              icon="el-icon-chat-dot-round"
              style="border: none; background: transparent"
              size="mini"
              >消息
            </el-button>
          </el-badge>
          <template #dropdown>
            <el-dropdown-menu class="dropdown-menu-default">
              <el-dropdown-item v-show="canReply" command="zb">转办</el-dropdown-item>
              <el-dropdown-item v-show="canCopy" command="cs">抄送</el-dropdown-item>
              <el-dropdown-item v-show="!canReply && !canCopy" command="none"
                >无可用操作
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
        <el-button size="mini" @click="saveData"> 保存</el-button>
        <el-button
          v-for="item in actions"
          :key="item.sn"
          size="mini"
          :type="item.styleType"
          @click="playActionFun(item)"
          >{{ item.title }}
        </el-button>
      </el-space>
    </template>
    <Message id="msgArea" :data="infoData || {}"></Message>
    <div class="gap-20"></div>
    <!--v-if="infoData && infoData.sn" :sn="infoData.defSn"-->
    <Step
      id="stepArea"
      v-if="infoData && infoData.itemSn"
      :sn="infoData && infoData.itemSn"
      :step-data="infoData.nodeList"
    ></Step>
    <div v-if="formCtl" class="gap-20"></div>
    <div id="formArea" v-if="formCtl" class="kmjs-card">
      <div class="title">表单</div>
      <FromModule :ctl="formCtl"></FromModule>
    </div>
    <div class="gap-20"></div>
    <div class="kmjs-card" id="logArea">
      <div class="title">日志</div>
      <el-tabs v-model="tabActive">
        <!--        <el-tab-pane label="消息记录" name="first">-->
        <!--          <div style="height: 200px"></div>-->
        <!--        </el-tab-pane>-->
        <el-tab-pane label="审核记录" name="second">
          <!--          <audit-record v-if="infoData?.sn" :infoData="infoData"></audit-record>-->
          <audit-record v-if="infoData?.sn" :sn="infoData?.sn"></audit-record>
        </el-tab-pane>
        <el-tab-pane label="历史提交" name="third">
          <history-submit :infoData="infoData"></history-submit>
        </el-tab-pane>
        <el-tab-pane label="转办记录" name="fourth">
          <transfer-record :infoData="infoData"></transfer-record>
        </el-tab-pane>
        <el-tab-pane label="抄送成员" name="fifth">
          <copy-for-member :infoData="infoData"></copy-for-member>
        </el-tab-pane>
      </el-tabs>
    </div>
  </Wrap>
  <ChooseOrganization
    v-model="showChooseOrganization"
    @on-confirm="getChooseOrg"
    :sns="infoData?.scopeOfOrg"
  ></ChooseOrganization>
  <ConfirmMark
    v-model="confirmInfo.show"
    :result="confirmInfo.result"
    :required="confirmInfo.require"
    :title="confirmInfo.title"
    :before-close="confirmInfo.cb"
  ></ConfirmMark>
  <FlotNav />
  <Talking
    v-if="showMessage"
    :bpmInstanceSn="infoData?.sn"
    :allowSendMessage="infoData?.imAllowSendMessage"
    :group-sn="imGroupSn"
    @onClose="showMessage = false"
  />
</template>

<script lang="ts">
  import {
    computed,
    defineComponent,
    inject,
    nextTick,
    onMounted,
    onUnmounted,
    reactive,
    ref,
    watch
  } from 'vue';
  import Wrap from '@/components/wrap/index.vue';
  import Message from '@/pages/backlog/components/message.vue';
  import Step from '@/pages/backlog/components/steps.vue';
  import ChooseOrganization from '@/components/chooseOrganization/index.vue';
  import ConfirmMark from '@/pages/backlog/components/confirmMark.vue';
  import FromModule, { FormCtl, FromConfig, useModule } from '@/formModule';
  import FlotNav from './components/flotNav.vue';
  import auditRecord from '@/components/auditRecord';
  import historySubmit from './components/historySubmit.vue';
  import transferRecord from './components/transferRecord.vue';
  import copyForMember from './components/copyForMember.vue';
  import { useMessageArea } from './detailHook';
  import {
    ActionItem,
    BacklogDef,
    deleteBpmInstanceNodeForm,
    getBacklogInfo,
    getImUnreadCount,
    playAction,
    postBpmInstanceNodeForm
  } from './api';
  import { useStore } from 'vuex';
  import { ElMessage } from 'element-plus';
  import { useRoute } from 'vue-router';
  import { useReload } from '@/utils';
  import { Emitter } from 'emitt';
  import { getDraftBySn } from '@/formModule/api';
  import Talking from '@/pages/backlog/talking';

  export default defineComponent({
    name: 'backlog-detail',
    components: {
      Talking,
      Wrap,
      Message,
      Step,
      ConfirmMark,
      ChooseOrganization,
      FromModule,
      FlotNav,
      auditRecord,
      historySubmit,
      transferRecord,
      copyForMember
    },
    setup() {
      const route = useRoute();
      const store = useStore();
      const tabActive = ref('second');
      let activeActionItem: ActionItem | null = null;
      const actions = ref<ActionItem[]>([]);
      const formCtl = ref<null | FormCtl>(null);
      let formMethods: any, currentNode: any;
      const formData = ref<Record<string, unknown>>({});
      const infoData = ref<BacklogDef | null>(null);
      const result = ref('');
      const resultRequire = ref(false);
      const canReply = ref(false);
      const canCopy = ref(false);
      // 表单是否可以编辑;控制重置和保存按钮是否出现;
      const canEdit = ref(false);
      const show = ref(true);

      let { defSn } = route.query;
      if (!defSn) {
        defSn = route.path.split('_')[1];
      }
      const { reload } = useReload(route.name as string);
      // 消息区域处理
      const {
        showChooseOrganization,
        downMenuClick,
        downMenuCommand,
        showConfirmMarkFun,
        getChooseOrg,
        confirmInfo,
        showMessage
      } = useMessageArea(defSn as string, infoData);
      const wrapTitle = reactive({
        title: '-',
        hideBack: true
      });
      /**
       * 执行动作
       * */
      const playActionFun = (item: ActionItem) => {
        activeActionItem = item;
        // result.value = item.title;
        // resultRequire.value = Boolean(item.message);
        confirmInfo.value.title = '审核';
        confirmInfo.value.result = item.title;
        confirmInfo.value.require = Boolean(item.message);
        showConfirmMarkFun({
          title: '审核',
          result: item.title,
          require: Boolean(item.message),
          cb: getActionAdvice
        });
      };

      /*
       * 保存数据
       * */
      async function saveData() {
        if (
          formMethods &&
          typeof formMethods.saveDraft === 'function' &&
          typeof formMethods.getResConfig === 'function' &&
          typeof formMethods.getInstanceSn === 'function' &&
          currentNode.sn
        ) {
          await formMethods.saveDraft();
          const instanseSn = formMethods.getInstanceSn();
          postBpmInstanceNodeForm(currentNode.sn, instanseSn);
        }
      }

      /*
       * 重置数据
       * */
      async function resetData() {
        if (formMethods && typeof formMethods.getInstanceSn === 'function' && currentNode.sn) {
          const instanseSn = formMethods.getInstanceSn();
          if (instanseSn) {
            return deleteBpmInstanceNodeForm(currentNode.sn, instanseSn).then(() => {
              reRender();
            });
          }
          reRender();
        }
      }

      /*
       * 刷新数据
       * */
      function refreshData() {
        reRender();
      }

      const getActionAdvice = async (data: string, closeFun: () => void) => {
        const formData = await formMethods?.submitData();
        if (formData === null) return;
        const res = await playAction(defSn as string, activeActionItem?.sn as string, {
          formInstanceSn: formMethods?.getInstanceSn() ?? '',
          jsonFormData: JSON.stringify(formData?.mapData || {}),
          message: data
        });
        if (!res) return;
        ElMessage.success('操作成功');
        closeFun();
        reload?.();
      };
      /**
       * 根据表单的配置，将数据转换为表单模块可以被识别的格式，对数据进行设置做显示
       * */
      const transformFormData = (resConfig: FromConfig, data: Record<string, any>) => {
        const mapData: Record<string, Record<string, any>> = {};
        resConfig.steps.forEach((v) => {
          const mapKey = v.step.property?.keyMapping ?? v.step.key;
          if (v.step.formType === 'grid') {
            mapData[v.step.key] = {
              data: data[mapKey]
            };
          } else {
            mapData[v.step.key] = {};
            v.items.forEach((s) => {
              const mapKey = s.item.property?.keyMapping ?? s.item.name;
              mapData[v.step.key][s.item.name] = data[mapKey];
            });
          }
        });
        return mapData;
      };

      //#region 代办在激活状态下被领取时 需要触发钩子进行刷新数据
      const onEvent = inject<Emitter['on']>('eventOn');
      const offEvent = inject<Emitter['off']>('eventOff');

      // 重新触发渲染
      function reRender() {
        initData().then(() => {
          show.value = false;
          nextTick(() => {
            show.value = true;
          });
        });
      }

      if (onEvent && typeof defSn === 'string') {
        onEvent(defSn, reRender);
      }
      onUnmounted(() => {
        if (offEvent && typeof defSn === 'string') {
          offEvent(defSn, reRender);
        }
      });
      //#endregion

      onMounted(() => {
        initData();
      });

      async function initData() {
        const data: BacklogDef = await getBacklogInfo(defSn as string);
        if (!data) return;
        infoData.value = data;
        wrapTitle.title = data.title;
        // 修改tab的title
        store.commit('menu/SET_TAB_TITLE', { name: route.name, title: data.title });
        currentNode = data.currentNodeList[0];
        if (currentNode) {
          let historyData: Record<string, any>;
          canReply.value = currentNode.allowRelay;
          canCopy.value = currentNode.allowCopyForViewer;
          actions.value = currentNode.actions;
          if (currentNode.formInstanceSn) {
            const response = await getDraftBySn(currentNode.formInstanceSn);
            const result: Record<string, any> = {};
            response.forEach((item) => {
              const { stepKey, data } = item;
              result[stepKey] = data;
            });
            historyData = result;
          } else {
            formData.value = currentNode.formDataMap;
          }
          if (currentNode.state === 'process') {
            wrapTitle.title = data.title + '，请您审核~';
          }
          if (!currentNode.formDefSn) return;
          const [ctl, methods] = useModule({
            params: {
              defSn: currentNode.formDefSn,
              instanceSn: currentNode.formInstanceSn || '',
              type: currentNode.allowEdit ? 'edit' : 'detail',
              hideWrap: true
            },
            handler: (moduleName, name) => {
              if (name === 'ready') {
                if (historyData) {
                  methods.setData(historyData);
                } else {
                  methods.setData(transformFormData(methods.getResConfig(), formData.value));
                }
                const elem = document.getElementById('formArea');
                canEdit.value = methods.getCanEdit() && currentNode.allowEdit;
                if (elem) {
                  nextTick(() => {
                    elem.style.height = elem.clientHeight + 26 + 'px';
                    elem.style.overflow = 'hidden';
                  });
                }
              }
            }
          });
          formMethods = methods;
          formCtl.value = ctl;
        }
        if (data.imAllowUse) {
          await initIm();
        }
      }

      const imGroupSn = ref('');
      // 获取消息数量
      const msgCount = computed(() => {
        return store.state.im.imGroupMap[infoData.value?.imGroupSn || '']?.msgCount || 0;
      });

      // 处理IM
      async function initIm() {
        if (infoData.value) {
          imGroupSn.value = infoData.value?.imGroupSn || '';
          await store.dispatch('im/initImSdk');
          await store.dispatch('im/initTalking', {
            bpmSn: infoData.value.sn,
            groupSn: imGroupSn.value
          });
          // 更新消息数
          getImUnreadCount(infoData.value?.sn || '').then((res) => {
            const groupInfo = store.state.im.imGroupMap[imGroupSn.value];
            groupInfo.msgCount = res.data;
            store.commit('im/UPDATE_GROUP_INFO', groupInfo);
          });
          watch(
            () => showMessage.value,
            (val) => {
              store.commit('im/UPDATE_IM_SHOW', { sn: imGroupSn.value, isShow: val });
            }
          );
        }
      }

      return {
        show,
        saveData,
        resetData,
        refreshData,
        canEdit,
        canReply,
        canCopy,
        tabActive,
        formCtl,
        formData,
        result,
        resultRequire,
        actions,
        playActionFun,
        infoData,
        wrapTitle,
        showChooseOrganization,
        downMenuClick,
        downMenuCommand,
        getActionAdvice,
        getChooseOrg,
        confirmInfo,
        showMessage,
        imGroupSn,
        msgCount
      };
    }
  });
</script>

<style lang="less">
  .dropdown-menu-default {
    padding: 10px 0;

    .el-dropdown-menu__item {
      line-height: 36px !important;
      padding: 0 20px !important;
      margin: 0;
      font-size: 14px !important;
      width: 80px;
      text-align: center;
    }
  }
</style>
