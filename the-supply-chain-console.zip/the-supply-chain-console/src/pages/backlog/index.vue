<template>
  <div class="page">
    <kmjsModule :ctl="moduleCtl">
      <template #wrap-custom>
        <div class="kmjs-wrap-custom">
          <!-- 返回区域  -->
          <div class="back">
            <div style="font-size: 20px; font-weight: bolder; cursor: pointer; flex: 1">
              待办事件
            </div>
            <div class="right">
              <el-select
                v-model="isRead[currentName]"
                class="read-select"
                type="mini"
                v-show="showRead"
                @change="changeRead"
              >
                <el-option value="" label="全部"></el-option>
                <el-option value="true" label="已读"></el-option>
                <el-option value="false" label="未读"></el-option>
              </el-select>
              <el-button
                class="el-button--refresh"
                type="default"
                icon="el-icon-refresh-right"
                size="mini"
                @click="onRefresh"
              />
            </div>
          </div>
        </div>
      </template>
    </kmjsModule>
    <confirm-mark
      v-model="operatConfirm.show"
      :result="operatConfirm.result"
      title="操作"
      :required="false"
      :beforeClose="operatConfirmSubmit"
    ></confirm-mark>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, inject, nextTick, ref } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import {
    cancelCopyAPI,
    relayAgreed,
    relayRejected,
    takeTask,
    withdrawTask
  } from '@/pages/backlog/api';
  import { goToBpmDetail } from '@/pages/commonPage';
  import ConfirmMark from '@/pages/backlog/components/confirmMark.vue';
  import { Emitter } from 'emitt';

  export default defineComponent({
    name: 'backlog-list',
    components: {
      kmjsModule,
      ConfirmMark
    },
    setup() {
      const toDetail = (sn: string) => {
        goToBpmDetail(sn);
      };
      const operatConfirm = ref({
        show: false,
        result: '',
        sn: '',
        desc: '',
        instanceSn: ''
      });
      const eventEmit = inject<Emitter['emit']>('eventEmit');

      const success = require('../../assets/success.png');
      // 转办接收/拒收
      const operatConfirmSubmit = (content: string, closeDialog: () => void) => {
        let api =
          operatConfirm.value.result === '接收'
            ? relayAgreed(operatConfirm.value.sn, content)
            : relayRejected(operatConfirm.value.sn, content);
        api.then((r) => {
          if (r.success) {
            closeDialog();
            // 待接收
            methods['/tab-menu/value3/tab-menu/value/table1/refresh']();
            ElMessage.success('操作成功');
            if (operatConfirm.value.result === '接收') {
              // 已接收
              methods['/tab-menu/value3/tab-menu/value3/table2/refresh']();
              ElMessageBox.confirm(
                `<div style="text-align: center">
                    <img src="${success}" alt="" style="width: 48px;">
                    <div style="font-weight: bold">接收成功</div>
                     <div style="font-size: 12px">${operatConfirm.value.desc}，您可在【待办理】中查看或点击“立即办理”</div>
                </div>`,
                '提示',
                { dangerouslyUseHTMLString: true, confirmButtonText: '立即办理' }
              ).then(() => {
                toDetail(operatConfirm.value.instanceSn);
              });
            }
          }
        });
      };

      const currentName = ref('todo');
      const isRead = ref<{ [name: string]: string }>({
        todo: '',
        copy_by_me: ''
      });
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'slot',
            name: 'title-form-data',
            slotName: 'wrap-custom'
          },
          {
            type: 'tab-module',
            name: 'tab-menu',
            permissions: [],
            params: {
              defaultActive: 'todo'
            },
            children: [
              {
                type: 'tab-module-item',
                name: 'value',
                permissions: [],
                params: {
                  title: '待办理',
                  value: 'todo',
                  isBadge: true
                },
                children: [
                  {
                    name: 'table1',
                    type: 'table',
                    params: {
                      tableDataUrl: '/auth/bpm/instance/node/page/todo?sort=startAt,DESC',
                      items: [
                        {
                          type: 'search',
                          isSlot: true,
                          inputs: [
                            {
                              label: '事项',
                              key: 'title',
                              type: 'text'
                            },
                            {
                              label: '发起人',
                              key: 'initiatorName'
                            },
                            {
                              label: '发起部门',
                              key: 'initiatorOrgTreeName'
                            },
                            {
                              label: '创建时间',
                              key: 'createdAt',
                              type: 'daterange',
                              dateConfig: {
                                startKey: 'startAt',
                                endKey: 'endAt'
                              }
                            }
                          ]
                        },
                        {
                          type: 'table',
                          tableHead: [
                            {
                              key: 'title',
                              label: '事项',
                              type: 'matterType',
                              params: {
                                read: 'read'
                              }
                            },
                            {
                              label: '发起人',
                              key: 'initiatorName',
                              width: 200
                            },
                            {
                              label: '发起人部门',
                              key: 'initiatorOrgTreeName',
                              width: 200
                            },
                            {
                              label: '创建时间',
                              width: 140,
                              key: 'initialAt',
                              formatter: 'dateTime',
                              params: {
                                dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                              }
                            },
                            {
                              type: 'handle',
                              label: '操作',
                              width: 200,
                              fixed: 'right',
                              actions: [
                                {
                                  label: '立即办理',
                                  emit: 'transaction',
                                  show: 'rule',
                                  rules: [
                                    {
                                      columnKey: 'state',
                                      columnValue: 'process'
                                    }
                                  ]
                                },
                                {
                                  label: '领取任务',
                                  emit: 'getTask',
                                  show: 'rule',
                                  rules: [
                                    {
                                      columnKey: 'state',
                                      columnValue: 'none'
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  }
                ]
              },
              {
                type: 'tab-module-item',
                name: 'value3',
                permissions: [],
                params: {
                  title: '转办',
                  value: 'transfer',
                  isBadge: true
                },
                children: [
                  {
                    type: 'tab-module',
                    name: 'tab-menu',
                    permissions: [],
                    params: {
                      defaultActive: 'one'
                    },
                    children: [
                      {
                        type: 'tab-module-item',
                        name: 'value',
                        permissions: [],
                        params: {
                          title: '待接收',
                          value: 'one'
                        },
                        children: [
                          {
                            name: 'table1',
                            type: 'table',
                            params: {
                              tableDataUrl:
                                '/auth/bpm/instance/node/actor/relay/page/relay_to_me/pending?sort=startAt,DESC',
                              items: [
                                {
                                  type: 'search',
                                  isSlot: true,
                                  inputs: [
                                    {
                                      label: '事项',
                                      key: 'title',
                                      type: 'text'
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle'
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy'
                                    },
                                    {
                                      label: '创建时间',
                                      key: 'createdAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'startAt',
                                        endKey: 'endAt'
                                      }
                                    }
                                  ]
                                },
                                {
                                  type: 'table',
                                  tableHead: [
                                    {
                                      type: 'text',
                                      label: '事项',
                                      key: 'title'
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle',
                                      width: 200
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '转办建议',
                                      key: 'createdDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '创建时间',
                                      width: 140,
                                      key: 'createdAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      type: 'handle',
                                      label: '操作',
                                      width: 200,
                                      fixed: 'right',
                                      actions: [
                                        {
                                          label: '谢绝',
                                          emit: 'rejected'
                                        },
                                        {
                                          label: '接收',
                                          emit: 'agreed'
                                        }
                                      ]
                                    }
                                  ]
                                }
                              ]
                            }
                          }
                        ]
                      },
                      {
                        type: 'tab-module-item',
                        name: 'value3',
                        permissions: [],
                        params: {
                          title: '已接收的',
                          value: 'four'
                        },
                        children: [
                          {
                            name: 'table2',
                            type: 'table',
                            params: {
                              tableDataUrl:
                                '/auth/bpm/instance/node/actor/relay/page/relay_to_me/agreed?sort=updatedAt,DESC',
                              items: [
                                {
                                  type: 'search',
                                  isSlot: true,
                                  inputs: [
                                    {
                                      label: '事项',
                                      key: 'title',
                                      type: 'text'
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle'
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy'
                                    },
                                    {
                                      label: '接收时间',
                                      key: 'updatedAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'receiveStartAt',
                                        endKey: 'receiveEndAt'
                                      }
                                    },
                                    {
                                      label: '创建时间',
                                      key: 'createdAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'startAt',
                                        endKey: 'endAt'
                                      }
                                    }
                                  ]
                                },
                                {
                                  type: 'table',
                                  tableHead: [
                                    {
                                      label: '事项',
                                      key: 'title'
                                    },
                                    {
                                      label: '接收状态',
                                      key: 'state',
                                      width: 200,
                                      type: 'mapText',
                                      params: {
                                        type: 'local',
                                        localData: {
                                          agreed: '已接收',
                                          pending: '待接收',
                                          rejected: '已驳回',
                                          retract: '已撤回'
                                        }
                                      }
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle',
                                      width: 200
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '转办建议',
                                      key: 'createdDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '接收人建议',
                                      key: 'operateDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收时间',
                                      width: 140,
                                      key: 'updatedAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      label: '创建时间',
                                      width: 140,
                                      key: 'createdAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    }
                                  ]
                                }
                              ]
                            }
                          }
                        ]
                      },
                      {
                        type: 'tab-module-item',
                        name: 'value4',
                        permissions: [],
                        params: {
                          title: '我转办的',
                          value: 'five'
                        },
                        children: [
                          {
                            name: 'table2',
                            type: 'table',
                            params: {
                              tableDataUrl:
                                '/auth/bpm/instance/node/actor/relay/page/initiated?sort=updatedAt,DESC',
                              items: [
                                {
                                  type: 'search',
                                  isSlot: true,
                                  inputs: [
                                    {
                                      label: '事项',
                                      key: 'title',
                                      type: 'text'
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle'
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy'
                                    },
                                    {
                                      label: '接收时间',
                                      key: 'updatedAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'receiveStartAt',
                                        endKey: 'receiveEndAt'
                                      }
                                    },
                                    {
                                      label: '创建时间',
                                      key: 'createdAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'startAt',
                                        endKey: 'endAt'
                                      }
                                    }
                                  ]
                                },
                                {
                                  type: 'table',
                                  tableHead: [
                                    {
                                      label: '事项',
                                      key: 'title'
                                    },
                                    {
                                      label: '接收状态',
                                      key: 'state',
                                      width: 200,
                                      type: 'mapText',
                                      params: {
                                        type: 'local',
                                        localData: {
                                          agreed: '已接收',
                                          pending: '待接收',
                                          rejected: '已驳回',
                                          retract: '已撤回'
                                        }
                                      }
                                    },
                                    {
                                      label: '转办节点',
                                      key: 'bpmInstanceNodeTitle',
                                      width: 200
                                    },
                                    {
                                      label: '转办人',
                                      key: 'createdNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '转办人建议',
                                      key: 'createdDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'operateNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '接收人建议',
                                      key: 'operateDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收时间',
                                      width: 140,
                                      key: 'updatedAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      label: '创建时间',
                                      width: 140,
                                      key: 'createdAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      type: 'handle',
                                      label: '操作',
                                      width: 200,
                                      fixed: 'right',
                                      actions: [
                                        {
                                          label: '撤回',
                                          emit: 'withdraw',
                                          show: 'rule',
                                          rules: [
                                            {
                                              columnKey: 'state',
                                              columnValue: 'pending'
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  ]
                                }
                              ]
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              {
                type: 'tab-module-item',
                name: 'value4',
                permissions: [],
                params: {
                  title: '抄送',
                  value: 'five'
                },
                children: [
                  {
                    type: 'tab-module',
                    name: 'tab-menu',
                    permissions: [],
                    params: {
                      defaultActive: 'one'
                    },
                    children: [
                      {
                        type: 'tab-module-item',
                        name: 'value',
                        permissions: [],
                        params: {
                          title: '收到的',
                          value: 'one'
                        },
                        children: [
                          {
                            name: 'table1',
                            type: 'table',
                            params: {
                              tableDataUrl:
                                '/auth/bpm/instance/page/received_copy?sort=startAt,DESC',
                              items: [
                                {
                                  type: 'search',
                                  isSlot: true,
                                  inputs: [
                                    {
                                      label: '事项',
                                      key: 'title',
                                      type: 'text'
                                    },
                                    {
                                      label: '抄送人',
                                      key: 'initiatorNameBy'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'receiveNameBy'
                                    },
                                    {
                                      label: '创建时间',
                                      key: 'createdAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'startAt',
                                        endKey: 'endAt'
                                      }
                                    }
                                  ]
                                },
                                {
                                  type: 'table',
                                  tableHead: [
                                    {
                                      key: 'title',
                                      label: '事项',
                                      type: 'matterType',
                                      params: {
                                        read: 'read'
                                      }
                                    },
                                    {
                                      label: '抄送人',
                                      key: 'initiatorNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '抄送人建议',
                                      key: 'initiatorDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'receiveNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '创建时间',
                                      width: 140,
                                      key: 'createdAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      type: 'handle',
                                      label: '操作',
                                      width: 200,
                                      fixed: 'right',
                                      actions: [
                                        {
                                          label: '详情',
                                          emit: 'copyToTransaction'
                                        }
                                      ]
                                    }
                                  ]
                                }
                              ]
                            }
                          }
                        ]
                      },
                      {
                        type: 'tab-module-item',
                        name: 'value3',
                        permissions: [],
                        params: {
                          title: '我抄送的',
                          value: 'copy_by_me'
                        },
                        children: [
                          {
                            name: 'table2',
                            type: 'table',
                            params: {
                              tableDataUrl:
                                '/auth/bpm/instance/page/copy_by_me?sort=updatedAt,DESC',
                              items: [
                                {
                                  type: 'search',
                                  isSlot: true,
                                  inputs: [
                                    {
                                      label: '事项',
                                      key: 'title',
                                      type: 'text'
                                    },
                                    {
                                      label: '抄送人',
                                      key: 'initiatorNameBy'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'receiveNameBy'
                                    },
                                    {
                                      label: '创建时间',
                                      key: 'createdAt',
                                      type: 'daterange',
                                      dateConfig: {
                                        startKey: 'startAt',
                                        endKey: 'endAt'
                                      }
                                    }
                                  ]
                                },
                                {
                                  type: 'table',
                                  tableHead: [
                                    {
                                      label: '事项',
                                      key: 'title'
                                    },
                                    {
                                      label: '状态',
                                      key: 'read',
                                      width: 200,
                                      type: 'mapText',
                                      params: {
                                        type: 'local',
                                        localData: {
                                          true: '已读',
                                          false: '未读'
                                        }
                                      }
                                    },
                                    {
                                      label: '抄送人',
                                      key: 'initiatorNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '抄送人建议',
                                      key: 'initiatorDesc',
                                      width: 200,
                                      type: 'richText'
                                    },
                                    {
                                      label: '接收人',
                                      key: 'receiveNameBy',
                                      width: 200
                                    },
                                    {
                                      label: '创建时间',
                                      width: 140,
                                      key: 'createdAt',
                                      formatter: 'dateTime',
                                      params: {
                                        dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                                      }
                                    },
                                    {
                                      type: 'handle',
                                      label: '操作',
                                      width: 200,
                                      fixed: 'right',
                                      actions: [
                                        {
                                          label: '撤回',
                                          emit: 'copyToWithdraw',
                                          show: 'rule',
                                          rules: [
                                            {
                                              columnKey: 'read',
                                              columnValue: 'false'
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  ]
                                }
                              ]
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              },
              {
                type: 'tab-module-item',
                name: 'value1',
                permissions: [],
                params: {
                  title: '已办理',
                  value: 'two'
                },
                children: [
                  {
                    name: 'table2',
                    type: 'table',
                    params: {
                      tableDataUrl: '/auth/bpm/instance/node/page/complete?sort=updatedAt,DESC',
                      items: [
                        {
                          type: 'search',
                          isSlot: true,
                          inputs: [
                            {
                              label: '事项',
                              key: 'title',
                              type: 'text'
                            },
                            {
                              label: '发起人',
                              key: 'initiatorName'
                            },
                            {
                              label: '发起部门',
                              key: 'initiatorOrgTreeName'
                            },
                            {
                              label: '创建时间',
                              key: 'createdAt',
                              type: 'daterange',
                              dateConfig: {
                                startKey: 'startAt',
                                endKey: 'endAt'
                              }
                            }
                          ]
                        },
                        {
                          type: 'table',
                          tableHead: [
                            {
                              label: '事项',
                              key: 'title'
                            },
                            {
                              label: '审核状态',
                              key: 'stateDesc',
                              width: 200
                            },
                            {
                              label: '发起人',
                              key: 'initiatorName',
                              width: 200
                            },
                            {
                              label: '发起人部门',
                              key: 'initiatorOrgTreeName',
                              width: 200
                            },
                            {
                              label: '创建时间',
                              width: 140,
                              key: 'initialAt',
                              formatter: 'dateTime',
                              params: {
                                dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                              }
                            },
                            {
                              type: 'handle',
                              label: '操作',
                              width: 200,
                              fixed: 'right',
                              actions: [
                                {
                                  label: '查看详情',
                                  emit: 'manageTransaction'
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  }
                ]
              },
              {
                type: 'tab-module-item',
                name: 'value2',
                permissions: [],
                params: {
                  title: '已发起',
                  value: 'three'
                },
                children: [
                  {
                    name: 'table3',
                    type: 'table',
                    params: {
                      tableDataUrl: '/auth/bpm/instance/page/initiated?sort=updatedAt,DESC',
                      items: [
                        {
                          type: 'search',
                          isSlot: true,
                          inputs: [
                            {
                              label: '事项',
                              key: 'title',
                              type: 'text'
                            },
                            {
                              label: '发起人',
                              key: 'initiatorNameBy'
                            },
                            {
                              label: '发起部门',
                              key: 'initiatorOrgTreeName'
                            },
                            {
                              label: '创建时间',
                              key: 'createdAt',
                              type: 'daterange',
                              dateConfig: {
                                startKey: 'startAt',
                                endKey: 'endAt'
                              }
                            }
                          ]
                        },
                        {
                          type: 'table',
                          tableHead: [
                            {
                              label: '事项',
                              key: 'title'
                            },
                            {
                              label: '审核状态',
                              key: 'stateDesc',
                              width: 200
                            },
                            {
                              label: '发起人',
                              key: 'initiatorNameBy',
                              width: 200
                            },
                            {
                              label: '发起人部门',
                              key: 'initiatorOrgTreeName',
                              width: 200
                            },
                            {
                              label: '创建时间',
                              width: 140,
                              key: 'startAt',
                              formatter: 'dateTime',
                              params: {
                                dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                              }
                            },
                            {
                              type: 'handle',
                              label: '操作',
                              width: 200,
                              fixed: 'right',
                              actions: [
                                {
                                  label: '查看详情',
                                  emit: 'initiateTransaction'
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  }
                ]
              }
            ]
          }
        ],
        params: {
          '/tab-menu/value/table1': {
            beforeRequest: (obj: { [index: string]: any }) => {
              if (
                isRead.value[currentName.value] === 'true' ||
                isRead.value[currentName.value] === 'false'
              ) {
                obj.url = `${obj.url}&read=${isRead.value[currentName.value]}`;
              }
              return Promise.resolve(obj);
            }
          },
          '/tab-menu/value4/tab-menu/value3/table2': {
            beforeRequest: (obj: { [index: string]: any }) => {
              if (
                isRead.value[currentName.value] === 'true' ||
                isRead.value[currentName.value] === 'false'
              ) {
                obj.url = `${obj.url}&read=${isRead.value[currentName.value]}`;
              }
              return Promise.resolve(obj);
            }
          },
          '/tab-menu/value3/tab-menu/value/table1': {
            dataFormatter: (
              tableData: { operateNameBy?: string; relayScope?: string }[]
            ): { operateNameBy?: string; relayScope?: string }[] => {
              tableData.forEach((item) => {
                item.operateNameBy = item.operateNameBy || item.relayScope;
              });
              return tableData;
            }
          }
        },
        handler: (moduleName, name, data) => {
          // 监听切换tab
          if (name === 'tab-change') {
            const { name } = methods['/tab-menu/getActive']();
            if (name === 'todo') {
              currentName.value = name;
              return;
            }
            const n = methods['/tab-menu/value4/tab-menu/getActive']().name;
            if (name === 'five' && n === 'copy_by_me') {
              currentName.value = n;
              return;
            }
            currentName.value = name;
            return;
          }
          // console.info(moduleName + '_' + name);
          switch (moduleName + '_' + name) {
            case '/tab-menu/value/table1_tableGetTask':
              ElMessageBox.confirm(`确定要领取${data[0].row.title}任务吗?`, '提示').then(
                async () => {
                  const result = await takeTask(data[0].row.sn);
                  if (!result) return;
                  methods['/tab-menu/value/table1/refresh']();
                  nextTick(() => {
                    // toDetail(moduleName, data[0].row.instanceSn);
                    goToBpmDetail(data[0].row.instanceSn);
                    if (eventEmit) {
                      eventEmit(`${data[0].row.instanceSn}`, '');
                    }
                  });
                }
              );
              break;
            case '/tab-menu/value3/tab-menu/value4/table2_tableWithdraw':
              {
                const row = data[0].row;
                // 我转办的撤回
                ElMessageBox.confirm(
                  `确定要撤回转办给【${row.relayScope}】的${row.title}吗?`,
                  '提示'
                ).then(async () => {
                  const result = await withdrawTask(row.sn);
                  if (!result) return;
                  methods['/tab-menu/value3/tab-menu/value4/table2/refresh']();
                  ElMessage.success('操作成功');
                });
              }
              break;
            case '/tab-menu/value4/tab-menu/value3/table2_tableCopyToWithdraw':
              {
                const row = data[0].row;
                // 我抄送的撤回
                ElMessageBox.confirm(
                  `确定要撤回抄送给【${row.receiveNameBy}】的${row.title}吗?`,
                  '提示'
                ).then(async () => {
                  const result = await cancelCopyAPI(
                    data[0].row.instanceSn,
                    data[0].row.instanceNodeActorSn
                  );
                  if (!result) return;
                  methods['/tab-menu/value4/tab-menu/value3/table2/refresh']();
                  ElMessage.success('操作成功');
                });
              }
              break;
            case '/tab-menu/value/table1_tableTransaction':
            case '/tab-menu/value1/table2_tableManageTransaction':
            case '/tab-menu/value2/table3_tableInitiateTransaction':
            case '/tab-menu/value4/tab-menu/value/table1_tableCopyToTransaction':
              toDetail(data[0].row.instanceSn);
              if (eventEmit) {
                eventEmit(`${data[0].row.instanceSn}`, '');
              }
              break;
            case '/tab-menu/value3/tab-menu/value/table1_tableAgreed':
              {
                const row = data[0].row;
                operatConfirm.value = {
                  result: '接收',
                  show: true,
                  sn: row.sn,
                  desc: `已成功接收【${row.createdNameBy}】转办的${row.title}`,
                  instanceSn: row.instanceSn
                };
              }
              break;
            case '/tab-menu/value3/tab-menu/value/table1_tableRejected':
              operatConfirm.value = {
                result: '谢绝',
                show: true,
                sn: data[0].row.sn,
                desc: '',
                instanceSn: data[0].row.instanceSn
              };
              break;
            case '/tab-menu/value/table1_tableResponse': {
              const total = methods['/tab-menu/value/table1/getResponse']?.()?.totalElements ?? 0;
              methods['/tab-menu/setBadgeValue']('todo', total);
              break;
            }
            case '/tab-menu/value3/tab-menu/value/table1_tableResponse': {
              const total =
                methods['/tab-menu/value3/tab-menu/value/table1/getResponse']?.()?.totalElements ??
                0;
              methods['/tab-menu/setBadgeValue']('transfer', total);
              break;
            }
          }
        }
      });

      const trigger = inject<(name: string, data?: any) => void>('eventEmit');
      const onRefresh = () => {
        trigger?.('$refresh');
        console.log('moduleName:', methods);
      };

      // 计算是否需要显示是否已读
      const showRead = computed(() => {
        return currentName.value === 'todo' || currentName.value === 'copy_by_me';
      });

      // 修改是否已读
      const changeRead = () => {
        if (currentName.value === 'todo') {
          methods['/tab-menu/value/table1/refresh']();
        } else {
          methods['/tab-menu/value4/tab-menu/value3/table2/refresh']();
        }
      };
      return {
        onRefresh,
        moduleCtl,
        operatConfirm,
        operatConfirmSubmit,
        isRead,
        showRead,
        currentName,
        changeRead
      };
    }
  });
</script>

<style lang="less" scoped>
  .kmjs-wrap-custom {
    display: flex;
    flex-direction: column;
    width: 100%;
    background: #fff;
    overflow: hidden;

    .back {
      display: flex;
      padding-top: 10px;
      //padding-bottom: 10px;

      .right {
        margin-left: auto;
      }
    }

    .wrap-com-main {
      flex: 1;
      padding-bottom: 10px;
      overflow: auto;
      margin-top: 10px;
    }
    .read-select {
      width: 88px;
      margin-right: 8px;

      ::v-deep {
        .el-input__inner {
          height: 28px;
        }

        .el-input__prefix,
        .el-input__suffix {
          height: 28px;
        }

        /* 下面设置右侧按钮居中 */
        .el-input__suffix {
          top: -5px;
        }

        .el-input__icon {
          line-height: inherit;
        }

        .el-input__suffix-inner {
          display: inline-block;
        }
      }
    }
  }
</style>
