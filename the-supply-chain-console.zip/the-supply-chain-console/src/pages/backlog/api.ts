import ajax from '@/utils/axios';

export interface StepNodeItem {
  state: string;
  // 领取人姓名
  takeNameBy: string;
  // 领取时间
  takeAt: number | string;
  // 完成操作人姓名
  completeByName: string;
  // 完成时间
  completeAt: number | string;
  // 发起人
  createdNameBy: string;
  // 发起人部门
  createdOrgTreeName: string;
  // 发起时间
  startAt: number;
  title: string;
  sn: string;
  itemNodeSn: string;
  // 耗时
  takeTime: string;
  nodeType: string;
  executeType: 'sync' | 'osync';
}

export interface ActionItem {
  sn: string;
  title: string;
  describe: string;
  nextNodeSn: string;
  styleType: string;
  message: boolean;
}

export interface BacklogDef extends StepNodeItem {
  itemSn: string;
  imGroupSn: string;
  nodeList: StepNodeItem[][];
  currentNodeList: {
    actions: ActionItem[];
    formDefSn: string;
    itemNodeSn: string;
    sn: string;
    allowRelay: boolean;
    allowEdit: boolean;
    allowCopyForViewer: boolean;
    formDataMap: Record<string, unknown>;
    title: string;
    state: string;
  }[];
  scopeOfOrg: string[];
  // 是否有im的使用权限
  imAllowUse: boolean;
  // 是否可以发送消息
  imAllowSendMessage: boolean;
}

const params = {
  $InstId: true
};

// 审核记录list数据
export interface RecordListObj {
  // 领取人，优先取completeNameBy，考虑都为null时如何显示即可
  takeNameBy: string;
  // 审核人
  completeNameBy: string;
  // none待处理，process处理中，complete完成，expire过期
  state: 'none' | 'process' | 'complete' | 'expire';
  // 审核建议
  completeDesc: string;
  completeAt: number;
  completeStr: string;
  takeAt: number;
  takeStr: string;
  diffAt: string;
}

/**
 * 查询全部的流程线条上的节点，但是没有节点的状态
 * */
export const getBacklogDef = (sn: string): Promise<BacklogDef> => {
  return ajax.get(`/auth/bpm/def/item/${sn}/list`, {
    params: {
      ...params
    }
  });
};

/**
 * 查询流程线条上的节点（仅包含有状态）和事项的信息和事项有的动作
 * */
export const getBacklogInfo = (sn: string): Promise<BacklogDef> => {
  return ajax.get(`/auth/bpm/instance/${sn}/list?needFormData=true`, {
    params: {
      ...params
    }
  });
};

/**
 * 领取任务
 * */
export const takeTask = (sn: string) => {
  return ajax.put(`/auth/bpm/instance/node/${sn}/take`, undefined, {
    params: {
      ...params
    }
  });
};

/**
 * 执行任务
 * */
export const playAction = (
  instanceSn: string,
  action: string,
  data: {
    formInstanceSn?: string;
    jsonFormData?: string;
    message?: string;
  }
) => {
  return ajax.put(`/auth/bpm/instance/node/${instanceSn}/${action}`, data, {
    params: {
      ...params
    }
  });
};

/**
 * 取消抄送
 * */
export const cancelCopyAPI = (
  instanceSn: string,
  sns: string[]
): Promise<{ message?: string; success?: boolean }> => {
  return ajax.delete(`/auth/bpm/instance/node/actor/${instanceSn}/${sns}`, {
    params: {
      ...params
    }
  });
};

/**
 * 审核记录
 * */
export const auditRecordListAPI = (instanceSn: string): Promise<RecordListObj[]> => {
  return ajax.get(`/auth/bpm/instance/node/list/${instanceSn}/history`, {
    params: {
      ...params
    }
  });
};

export interface TurnPotRes {
  actorType: string;
  actorValue: string;
  actorValueName: string;
  describe?: string;
}

/**
 * 发起转办
 * */
export const turnPot = (
  instanceNodeSn: string,
  requestId: string,
  data: { requests: TurnPotRes[]; describe?: string }
) => {
  return ajax.post(`/auth/bpm/instance/node/actor/relay/${instanceNodeSn}/${requestId}`, data, {
    params: {
      ...params
    }
  });
};

/**
 * 发起抄送
 * */
export const togetherHavePot = (
  instanceSn: string,
  data: { requests: TurnPotRes[]; describe?: string }
) => {
  return ajax.put(`/auth/bpm/instance/node/actor/copy/${instanceSn}`, data, {
    params: {
      ...params
    }
  });
};

/**
 * 根据定义获取,流程，主要是需要中间的表单SN
 * */
export const getBpmDef = (
  sn: string
): Promise<{
  formDefSn: string;
  title: string;
  configDataMap: Record<string, unknown>;
}> => {
  return ajax.get(`/auth/bpm/def/${sn}`, {
    params: {
      ...params
    }
  });
};
/**
 * 新建流程
 * */
export const createBpm = (
  defSn: string,
  data: {
    bizSn?: string;
    formInstanceSn: string;
    jsonFormData: string;
    createdOrgTreeSn: string;
    createdOrgTreeName: string;
  }
): Promise<{ sn: string }> => {
  return ajax.post(`/auth/bpm/instance/${defSn}/${new Date().getTime()}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 待办接收--同意转办（接收）
 */
export const relayAgreed = (sn: string, describe: string) => {
  return ajax.put<undefined, { success: boolean; sn: string }>(
    `/auth/bpm/instance/node/actor/relay/${sn}/agreed`,
    {
      describe
    },
    {
      params: {
        $InstId: true
      }
    }
  );
};

/**
 * 待办接收--驳回转办（谢绝）
 */
export const relayRejected = (sn: string, describe: string) => {
  return ajax.put<undefined, { success: boolean; sn: string }>(
    `/auth/bpm/instance/node/actor/relay/${sn}/rejected`,
    {
      describe
    },
    {
      params: {
        $InstId: true
      }
    }
  );
};
/**
 * 待办撤回
 * @param sns 待转办sn集合,[array of string]
 */
export const withdrawTask = (sns: string) => {
  return ajax.delete<undefined, { success: boolean }>(
    `/auth/bpm/instance/node/actor/relay/${sns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

/*
 * 代办保存草稿实例sn
 * */
export const postBpmInstanceNodeForm = (instanceNodeSn: string, formInstanceSn: string) => {
  return ajax.post<undefined, { success: boolean }>(
    `/auth/bpm/instance/node/form/${instanceNodeSn}/${formInstanceSn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

/*
 * 代办保存草稿实例sn
 * */
export const deleteBpmInstanceNodeForm = (instanceNodeSn: string, formInstanceSn: string) => {
  return ajax.delete<undefined, { success: boolean }>(
    `/auth/bpm/instance/node/form/${instanceNodeSn}/${formInstanceSn}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 添加IM的成员
export const addImMember = (
  bpmInstanceSn: string,
  data: { orgTreeSn: string; memberType: string; memberValue: string }[]
) => {
  return ajax.post<undefined, { success: boolean }>(`/auth/bpm/im/member/${bpmInstanceSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

// 删除成员
export const deleteImMember = (bpmInstanceSn: string, memberSns: string) => {
  return ajax.delete<undefined, { success: boolean }>(
    `/auth/bpm/im/member/${bpmInstanceSn}/${memberSns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 获取未读消息数
export const getImUnreadCount = (bpmInstanceSn: string) => {
  return ajax.get<undefined, { success: boolean; data: number }>(
    `/auth/bpm/im/member/${bpmInstanceSn}/unread/count`,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};

// 清除未读数
export const clearImUnreadCount = (bpmInstanceSn: string) => {
  return ajax.delete<undefined, { success: boolean; data: number }>(
    `/auth/bpm/im/member/${bpmInstanceSn}/unread/count`,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};
