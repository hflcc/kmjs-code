import ajax from '@/utils/axios';
interface IDelData {
  message: string;
  success: boolean;
  [propName: string]: unknown;
}
/* 删除品牌入驻列表数据 */
export const delData = (sns: string): Promise<IDelData> => {
  return ajax.delete(`/auth/md/brand/enter/delete?sns=${sns}`, {
    params: {
      $InstId: true
    }
  });
};
