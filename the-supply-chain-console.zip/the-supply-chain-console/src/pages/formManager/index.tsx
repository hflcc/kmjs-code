import { defineComponent } from 'vue';
import kmjsModule, { useModule, ModuleConfig, ModuleCtl } from '@/components/modules/module/code';

/**
 * 表单配置列表
 * */
export default defineComponent({
  name: 'form-manager-page',
  components: {
    kmjsModule
  },
  setup() {
    const [ctl, methods] = useModule({
      config: [
        {
          type: 'wrap-module',
          name: 'wrap',
          params: {
            hideBack: true,
            title: '表单管理',
            actions: [
              {
                type: 'refresh',
                emit: 'refresh'
              },
              {
                type: 'createForm',
                label: '新建表单',
                emit: 'createForm',
                params: {
                  defSn: 'ff2c284c6e434687a8a9541722846486'
                }
              }
            ]
          },
          children: [
            {
              type: 'table',
              name: 'table',
              params: {
                tableDataUrl: '/auth/md/form/def/page',
                items: [
                  {
                    type: 'search',
                    inputs: [
                      {
                        label: 'sn',
                        key: 'sn',
                        type: 'text'
                      },
                      {
                        label: '表单名称',
                        key: 'name',
                        type: 'text'
                      },
                      {
                        label: '描述',
                        key: 'description',
                        type: 'text'
                      },
                      {
                        label: '创建人',
                        key: 'createByName'
                      },
                      {
                        label: '创建时间',
                        key: 'daterange',
                        type: 'daterange',
                        dateConfig: {
                          startKey: 'startTime',
                          endKey: 'endTime'
                        }
                      }
                    ]
                  },
                  {
                    type: 'table',
                    tableHead: [
                      {
                        label: 'sn',
                        key: 'sn',
                        width: 250
                      },
                      {
                        label: '表单名称',
                        key: 'name'
                      },
                      {
                        label: '描述',
                        key: 'description'
                      },
                      {
                        label: '创建人',
                        key: 'createByName',
                        width: 100
                      },
                      {
                        label: '创建时间',
                        key: 'createAt',
                        type: 'text',
                        width: 200,
                        formatter: 'dateTime'
                      },
                      {
                        type: 'handle',
                        label: '操作',
                        actions: [
                          {
                            type: 'tableEdit',
                            label: '编辑',
                            emit: 'detail',
                            params: {
                              defSn: 'ff2c284c6e434687a8a9541722846486',
                              dataSnKey: 'sn'
                            }
                          },
                          // {
                          //   type: 'tableCreate',
                          //   label: '预览',
                          //   emit: 'create',
                          //   params: {
                          //     defSn: '4d78fe83624a459da98f451dfc0050a9',
                          //     dataSnKey: 'sn'
                          //   }
                          // },
                          {
                            type: 'tableCreate',
                            label: '复制',
                            emit: 'copy',
                            params: {
                              defSn: 'ff2c284c6e434687a8a9541722846486',
                              dataSnKey: 'sn'
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            }
          ]
        }
      ]
    });
    return () => (
      <div class="page form-manager-page">
        <kmjs-module ctl={ctl}></kmjs-module>
      </div>
    );
  }
});
