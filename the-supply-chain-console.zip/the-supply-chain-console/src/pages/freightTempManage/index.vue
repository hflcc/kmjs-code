<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delBatchFreightTemp, delFreightTempManage } from '@/pages/freightTempManage/api';

  interface Methods {
    [propName: string]: () => void;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    address: string;
    areaSn: string;
    contactName: string;
    contactPhone: string;
    createName: string;
    createdAt: string;
    sn: string;
    type: string;
    [propName: string]: unknown;
  }

  export default defineComponent({
    name: 'freightTempManage',
    components: {
      kmjsModule
    },
    setup() {
      const [moduleCtl, methods] = useModule({
        /*config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '运费模板管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增模板',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: 'cfad21d2b3644a14aed621252a1d7321'
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                params: {
                  tableDataUrl: '/auth/ec/deliver/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '模板名称',
                          key: 'name',
                          type: 'text'
                        },
                        {
                          label: '是否包邮',
                          key: 'deliverFree',
                          type: 'select',
                          options: [
                            {label: '包邮', value: 'true'},
                            {label: '不包邮', value: 'false'}
                          ]
                        },
                        {
                          label: '计价方式',
                          key: 'type',
                          type: 'select',
                          dictionaryName: 'deliver_charge_type'
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '模板名称',
                          key: 'name'
                        },
                        {
                          label: '是否包邮',
                          key: 'deliverFree',
                          type: 'mapText',
                          params: {
                            type: 'local',
                            localData: {
                              true: '包邮',
                              false: '不包邮'
                            }
                          }
                        },
                        {
                          label: '计价方式',
                          key: 'type',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'deliver_charge_type'
                          }
                        },
                        {
                          label: '首件',
                          key: 'defaultNum'
                        },
                        {
                          label: '运费',
                          key: 'defaultAmount'
                        },
                        {
                          label: '续件',
                          key: 'addNum'
                        },
                        {
                          label: '运费',
                          key: 'addAmount'
                        },
                        {
                          label: '创建人',
                          key: 'createName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'freightTempDetail',
                              params: {
                                defSn: 'dc74df7b2acf4e579e75ea8475dbaffa',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'freightTempEdit',
                              params: {
                                defSn: 'cc2b5fd1bf624c3b85627a79023d5c55',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'freightTempDelete',
                              show: 'always'
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          type: 'danger',
                          emit: 'freightTempBatchDelete'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],*/
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          handlers[name] && handlers[name](data, methods);
        }
      });

      const handlers: Handlers = {
        // 删除运费模板
        tableFreightTempDelete: (list) => {
          const { row } = list[0] || {};
          const message = `确定要删除 【${row.name}】 运费模板吗？`;
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delFreightTempManage(row.sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        },
        tableFreightTempBatchDelete: (list) => {
          const selectedData: TableRow[] = list[0] || [];
          if (!selectedData.length) {
            ElMessage.error('请选择需要批量删除的运费模板');
            return;
          }
          const sns = selectedData.map((item) => item.sn);
          const message = '确定要删除已选运费模板吗？';
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delBatchFreightTemp(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };

      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less"></style>
