import ajax from '@/utils/axios';

/**
 * 删除运费模板
 */
export function delFreightTempManage(sn: string): Promise<{ success: boolean }> {
  return ajax.delete<{ addressSn: string }, { success: boolean }>(`/auth/ec/deliver/${sn}`, {
    params: {
      $InstId: true
    }
  });
}
/**
 * 批量删除地址
 */
export function delBatchFreightTemp(deliverSns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ deliverSns: string[] }, { success: boolean }>(
    `/auth/ec/deliver/sns?deliverSns=${deliverSns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
}
