<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delBrandData } from '@/pages/brandWarehouse/api';
  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sn: string;
    brandOn: string;
    brandName: string;
    brandType: string;
    brandIoc: string;
    effectiveTimeStart: string;
    effectiveTimeEnd: string;
    bizMdPlatformName: string;
    bizMdSupplierName: string;
    saleType: string;
    createdName: string;
    createdAt: number;
    remark: string;
  }
  export default defineComponent({
    name: 'brandWarehouse',
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        // 批量删除
        tableDeleteData: async (arr, methods) => {
          let [list] = arr;
          if (list instanceof Array) {
            if (!list.length) {
              ElMessage.error('请选择需要删除的数据');
              return;
            }
          } else {
            list = [list.row ? list.row : {}];
          }
          ElMessageBox.confirm('确认删除吗？')
            .then(async () => {
              const sns = list.map((item: TableRow) => item.sn).join(',');
              const res = await delBrandData(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '品牌库',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '0f866fdeaf6c42818c8a1a76d8dce12a'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/brand/supplier/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '编号',
                          key: 'brandOn',
                          type: 'text'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName',
                          type: 'text'
                        },
                        {
                          label: '品牌类型',
                          key: 'brandType',
                          type: 'select',
                          dictionaryName: 'brand_type'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierName',
                          type: 'text'
                        },
                        {
                          label: '有效时间',
                          key: 'expiredDate',
                          hideAuto: true,
                          type: 'expiredDate'
                        },
                        {
                          label: '销售方式',
                          key: 'saleType',
                          type: 'select',
                          dictionaryName: 'sale_type'
                        },
                        {
                          label: '创建人',
                          key: 'createdName',
                          type: 'text'
                        },

                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'createdAtStart',
                            endKey: 'createdAtEnd'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'brandOn',
                          width: 150
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName'
                        },
                        {
                          label: '品牌类型',
                          key: 'brandType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'brand_type'
                          }
                        },
                        {
                          type: 'image',
                          label: '品牌商标',
                          key: 'brandIoc',
                          params: {
                            width: '80px'
                          }
                        },
                        {
                          label: '有效时间',
                          key: 'expiredType',
                          type: 'expiredDate',
                          width: 200,
                          params: {
                            startKey: 'expiredStartAt',
                            endKey: 'expiredEndAt'
                          }
                        },
                        {
                          label: '平台',
                          key: 'bizMdPlatformName'
                        },
                        {
                          label: '供应商',
                          key: 'bizMdSupplierName'
                        },
                        {
                          label: '销售方式',
                          key: 'saleType',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'sale_type'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'remark',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'brandWarehouseDetail',
                              params: {
                                defSn: '98b234fd93d24f54a8e442a9d8183fae',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'brandWarehouseEdit',
                              params: {
                                defSn: 'c457cf72833c497eb364014a39eac961'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'deleteData'
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          emit: 'deleteData'
                        }
                      ]
                    }
                  ]
                },
                slotParam: []
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            beforeRequest: (requestObj: { url: string; params: Record<string, unknown> }) => {
              if (requestObj.params.expiredDate) {
                const { expiredType, expiredStartAt } = requestObj.params.expiredDate as {
                  expiredType: string;
                  expiredStartAt: number;
                };
                // 长期有效
                if (expiredType === 'permanent') {
                  requestObj.params.expiredType = expiredType;
                } else if (expiredStartAt > 0) {
                  requestObj.params = Object.assign(
                    requestObj.params,
                    requestObj.params.expiredDate
                  );
                }
              }
              return Promise.resolve(requestObj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          // console.log('moduleName', moduleName);
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
