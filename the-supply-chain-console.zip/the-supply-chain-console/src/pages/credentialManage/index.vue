<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"> </kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delCertificate, delBatchCertificate } from '@/api/credentialManage';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sns: string;
    sn: string;
  }
  export default defineComponent({
    name: 'credentialManage',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      // 选择模式，是单选还是多选
      selectMode: {
        type: String as PropType<'single' | 'multiple'>,
        default: ''
      }
    },
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        tableDeleData: async (list, methods) => {
          let sn = list[0].row.sn;
          ElMessageBox.confirm('确认删除吗？')
            .then(async () => {
              const res = await delCertificate(sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        },
        tableDelBatchCertificate: async (list) => {
          const selectedData: TableRow[] = list[0] || [];
          if (!selectedData.length) {
            ElMessage.error('请选择需要批量删除的证件');
            return;
          }
          const sns = selectedData.map((item) => item.sn);
          const message = '确定要删除已选中证件吗？';
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delBatchCertificate(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '证件管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增证件',
                  emit: 'createForm',
                  params: {
                    // 配置项
                    defSn: '90cc66661b6d11eca2b50c42a1da1656'
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                params: {
                  tableDataUrl: '/auth/md/qualification/instance/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '编号',
                          key: 'code',
                          type: 'text'
                        },
                        {
                          label: '证件名称',
                          key: 'qualificationDefName',
                          type: 'text'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'select',
                          dictionaryName: 'qualification_instance_audit_state'
                        },
                        {
                          label: '状态',
                          key: 'state',
                          type: 'select',
                          dictionaryName: 'qualification_state'
                        },
                        {
                          label: '证件编号',
                          key: 'serialCode',
                          type: 'text'
                        },
                        {
                          label: '有效时间',
                          key: 'expiredType',
                          type: 'select',
                          dictionaryName: 'qualification_instance_expired_type'
                        },
                        {
                          label: '创建人',
                          key: 'createdByName'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'code'
                        },
                        {
                          label: '证件名称',
                          key: 'qualificationDefName'
                        },
                        {
                          label: '审核状态',
                          key: 'auditState',
                          type: 'mapText',
                          params: {
                            showDiaLogIcon: true,
                            type: 'dictionary',
                            dictionaryName: 'qualification_instance_audit_state'
                          }
                        },
                        {
                          label: '状态',
                          key: 'state',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'qualification_state'
                          }
                        },
                        {
                          label: '证件类别',
                          key: 'category',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'qualification_instance_category'
                          }
                        },
                        {
                          label: '证件编号',
                          key: 'serialCode',
                          width: 180
                        },
                        {
                          label: '有效时间',
                          key: 'expiredType',
                          type: 'expiredDate',
                          width: 200,
                          params: {
                            startKey: 'expiredStartAt',
                            endKey: 'expiredEndAt'
                          }
                        },
                        {
                          type: 'fileListView',
                          label: '附件',
                          width: 140,
                          key: 'attaches'
                        },
                        {
                          label: '认证机构',
                          key: 'certifyInstName'
                        },
                        {
                          label: '创建人',
                          key: 'createdByName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          type: 'formatter',
                          width: 180,
                          params: {
                            formatter: 'dateTime',
                            formatterType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'content',
                          width: 250
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              emit: 'credentialDetail',
                              label: '详情',
                              params: {
                                defSn: 'b1a003e81f9211eca2b50c42a1da1656',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'credentialEdit',
                              show: 'rule',
                              params: {
                                defSn: '299b9e4328cf11eca2b50c42a1da1656',
                                dataSnKey: 'sn',
                                beforeCallCheck: [
                                  {
                                    type: 'bpm',
                                    queryKey: 'sn',
                                    defSn: '299b9e4328cf11eca2b50c42a1da1656'
                                  }
                                ]
                              },
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait|reject'
                                }
                              ]
                            },
                            {
                              label: '变更',
                              // type: 'tableBpm',
                              emit: 'credentialChange',
                              show: 'rule',
                              // params: {
                              //   bpmType: 'certificate_modify',
                              //   dataSnKey: 'sn'
                              //   // defSn: '7ca4820d2a6c11eca2b50c42a1da1656'
                              // },
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'expired|accept'
                                }
                              ]
                            },
                            {
                              label: '删除',
                              emit: 'deleData',
                              show: 'rule',
                              rules: [
                                {
                                  columnKey: 'auditState',
                                  columnValue: 'wait'
                                }
                              ]
                            }
                            // {
                            //   type: 'tableBpm',
                            //   label: '认证',
                            //   emit: 'credentialAuthentication',
                            //   show: 'rule',
                            //   params: {
                            //     dataSnKey: 'sn',
                            //     bpmType: 'certificate_add'
                            //   },
                            //   rules: [
                            //     {
                            //       columnKey: 'auditState',
                            //       columnValue: 'wait'
                            //     }
                            //   ]
                            // }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          type: 'danger',
                          emit: 'delBatchCertificate'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              obj.url = `${obj.url}`;
              return Promise.resolve(obj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
