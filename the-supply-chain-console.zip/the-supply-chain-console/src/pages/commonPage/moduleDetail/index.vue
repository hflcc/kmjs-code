<template>
  <kmjs-form-module v-if="ctlFun" :ctl="ctlFun"></kmjs-form-module>
</template>

<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import { useModule, FormCtl, getBusinessData } from '@/formModule';
  import { useStore } from 'vuex';
  import { formatterStrByObj, getChainData } from '@/utils';

  export default defineComponent({
    name: 'module-detail-edit',
    setup() {
      const store = useStore();
      const route = useRoute();
      let { defSn, sn } = route.query;
      if (!defSn) {
        const data = route.path.split('_');
        defSn = data[1];
        sn = data[2];
      }
      const ctlFun = ref<FormCtl | null>(null);
      if (defSn && sn) {
        getBusinessData(defSn as string, sn as string).then((res) => {
          const [ctl, methods] = useModule({
            params: {
              defSn: defSn as string,
              type: 'detail',
              hideWrap: true
            },
            handler: (moduleName, name) => {
              if (name === 'ready') {
                if (!res) return;
                // 这里是修改tab的显示名称
                let titleStr = methods.getResConfig().def.title;
                const codeArr = titleStr.match(new RegExp('{.*?(?<=})', 'gi'));
                if (codeArr && codeArr.length) {
                  codeArr.forEach((v) => {
                    const stepKey = v.replace('{', '').replace('}', '').split('.');
                    const titleData: string | Record<string, unknown> =
                      res.find((s) => s.stepKey === stepKey[0])?.data ?? '';
                    titleStr = formatterStrByObj(titleStr, { [stepKey[0]]: titleData });
                  });
                }
                // 修改tab的title
                store.commit('menu/SET_TAB_TITLE', {
                  name: route.name,
                  title: titleStr,
                  type: 'detail'
                });
                const obj: Record<string, Record<string, unknown>> = {};
                res.forEach((v) => {
                  obj[v.stepKey] = v.data;
                });
                methods.setData(obj);
              }
            }
          });
          ctlFun.value = ctl;
        });
      }

      return {
        ctlFun
      };
    }
  });
</script>
<style lang="less"></style>
