<template>
  <kmjs-form-module v-if="ctlFun && !isFinish" :ctl="ctlFun"></kmjs-form-module>
  <submitResult v-if="isFinish" :data="resultData" :close-tab="closeTab"></submitResult>
</template>

<script lang="ts">
  import { defineComponent, inject, ref } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useModule, FormCtl } from '@/formModule';
  import { useStore } from 'vuex';
  import { ElMessageBox } from 'element-plus';
  import useTabMenuHook from '@/layout/components/tabsMenu/tabMenuHooks';
  import useOrganization from '@/store/commModules/organization/useOrganization';
  import submitResult from '@/components/submitResultPlay';

  export default defineComponent({
    name: 'module-form-create',
    components: {
      submitResult
    },
    setup() {
      const { closeWindow, beforeCloseTab } = useTabMenuHook();
      const { activeOrganization } = useOrganization();
      const resultData = ref({});
      const eventEmit = inject<((name: string) => void) | null>('eventEmit', null);
      const isFinish = ref(false);
      const store = useStore();
      const route = useRoute();
      const router = useRouter();
      let { defSn, b, c } = route.query;
      if (!defSn) {
        defSn = route.path.split('_')[1];
      }
      const ctlFun = ref<FormCtl | null>(null);
      if (defSn) {
        const [ctl, methods] = useModule({
          params: {
            defSn: defSn as string,
            type: 'create',
            wrapConfig: {
              hideBack: true
            },
            setQueryData: () => {
              return Promise.resolve({
                orgTreeSn: activeOrganization.value?.sn ?? '',
                orgTreeName: activeOrganization.value?.name ?? '',
                ...route.query
              });
            }
          },
          handler: (moduleName, name, data) => {
            if (name === 'submitData') {
              resultData.value = {
                isSuccess: data[0].response.success,
                data: data[0].response.data
              };
              isFinish.value = true;
              if (c) {
                eventEmit?.(c as string);
              }
            }
            if (name === 'ready') {
              const config = methods.getResConfig();
              // 修改tab的title
              store.commit('menu/SET_TAB_TITLE', {
                name: route.name,
                title: config.def.title ?? config.def.name,
                type: 'create'
              });
            }
          }
        });
        ctlFun.value = ctl;
      }
      beforeCloseTab((next) => {
        if (isFinish.value) {
          next(true);
          return;
        }
        ElMessageBox.confirm('确认关闭窗口，系统不会主动保存您的数据', '关闭窗口')
          .then(() => {
            next(true);
          })
          .catch(() => next(false));
      });
      const routerName = route.name;
      const closeTab = () => {
        // 当前页面时跳转回去
        if (b && routerName === route.name) {
          router.push({ name: b as string });
        }
        closeWindow();
      };
      return {
        resultData,
        closeTab,
        ctlFun,
        isFinish
      };
    }
  });
</script>

<style lang="less"></style>
