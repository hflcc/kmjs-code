<template>
  <kmjs-form-module v-if="ctlFun && !isFinish" :ctl="ctlFun"></kmjs-form-module>
  <el-result v-if="isFinish" title="数据提交成功" icon="success" sub-title="">
    <template #extra>
      <el-button type="primary" size="medium" @click="closeTab">关闭页面</el-button>
    </template>
  </el-result>
</template>

<script lang="ts">
  import { defineComponent, inject, ref } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useModule, FormCtl, getBusinessData } from '@/formModule';
  import { useStore } from 'vuex';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import useTabMenuHook from '@/layout/components/tabsMenu/tabMenuHooks';
  import { formatterStrByObj, useReload } from '@/utils';
  import useOrganization from '@/store/commModules/organization/useOrganization';

  export default defineComponent({
    name: 'module-form-edit',
    setup() {
      const { closeWindow, beforeCloseTab } = useTabMenuHook();
      const { activeOrganization } = useOrganization();
      const eventEmit = inject<((name: string) => void) | null>('eventEmit', null);
      const isFinish = ref(false);
      const route = useRoute();
      const router = useRouter();
      const store = useStore();
      const { reload } = useReload(route.name as string);
      let { defSn, sn, c, b } = route.query;
      if (!defSn) {
        const data = route.path.split('_');
        defSn = data[1];
        sn = data[2];
      }
      const ctlFun = ref<FormCtl | null>(null);
      if (defSn && sn && ctlFun.value === null) {
        getBusinessData(defSn as string, sn as string).then((res) => {
          const [ctl, methods] = useModule({
            params: {
              defSn: defSn as string,
              type: 'edit',
              wrapConfig: {
                hideBack: true
              },
              setQueryData: () => {
                return Promise.resolve({
                  orgTreeSn: activeOrganization.value?.sn ?? '',
                  orgTreeName: activeOrganization.value?.name ?? ''
                });
              }
            },
            handler: (moduleName, name) => {
              if (name === 'submitData') {
                ElMessage.success('数据提交成功');
                reload();
                // isFinish.value = true;
                if (c) {
                  eventEmit?.(c as string);
                }
              }
              if (name === 'ready') {
                if (!res) return;
                // 这里是修改tab的显示名称
                let titleStr = methods.getResConfig().def.title;
                const codeArr = titleStr.match(new RegExp('{.*?(?<=})', 'gi'));
                if (codeArr && codeArr.length) {
                  codeArr.forEach((v) => {
                    const stepKey = v.replace('{', '').replace('}', '').split('.');
                    const titleData: string | Record<string, unknown> =
                      res.find((s) => s.stepKey === stepKey[0])?.data ?? '';
                    titleStr = formatterStrByObj(titleStr, { [stepKey[0]]: titleData });
                  });
                }
                // 修改tab的title
                store.commit('menu/SET_TAB_TITLE', {
                  name: route.name,
                  title: titleStr,
                  type: 'edit'
                });
                const obj: Record<string, Record<string, unknown>> = {};
                res.forEach((v) => {
                  obj[v.stepKey] = v.data;
                });
                methods.setData(obj);
              }
            }
          });
          ctlFun.value = ctl;
        });
      }
      beforeCloseTab((next) => {
        if (isFinish.value) {
          next(true);
          return;
        }
        ElMessageBox.confirm('确认关闭窗口，系统不会主动保存您的数据', '关闭窗口')
          .then(() => {
            next(true);
          })
          .catch(() => next(false));
      });
      const routerName = route.name;
      const closeTab = () => {
        // 当前页面时跳转回去
        if (b && routerName === route.name) {
          router.push({ name: b as string });
        }
        closeWindow();
      };
      return {
        isFinish,
        ctlFun,
        closeTab
      };
    }
  });
</script>
<style lang="less"></style>
