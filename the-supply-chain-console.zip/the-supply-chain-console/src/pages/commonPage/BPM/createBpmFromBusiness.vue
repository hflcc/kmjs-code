<!--新建流程从业务数据触发。表单一般是和业务数据的编辑一样。 需要对表单的默认数据进行一次设置后走编辑数据的流程-->
<template>
  <kmjs-form-module v-if="formCtl && !isFinish" :ctl="formCtl"></kmjs-form-module>
  <submitResult v-if="isFinish" :data="resultData" :close-tab="closeTab"></submitResult>
</template>

<script lang="ts">
  import { defineComponent, onMounted, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import { getBpmDef } from '@/pages/backlog/api';
  import { useModule, FormCtl, getBusinessData } from '@/formModule';
  import useOrganization from '@/store/commModules/organization/useOrganization';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { useStore } from 'vuex';
  import useTabMenuHook from '@/layout/components/tabsMenu/tabMenuHooks';
  import { getBpmAlertMsg } from '@/utils/commApi';
  import submitResult from '@/components/submitResultPlay';
  import { formatterStrByObj } from '@/utils';

  export default defineComponent({
    name: 'create-bpm-by-edit',
    components: {
      submitResult
    },
    setup() {
      const resultData = ref({});
      const { closeWindow, beforeCloseTab } = useTabMenuHook();
      const formCtl = ref<FormCtl | null>(null);
      const { activeOrganization } = useOrganization();
      const route = useRoute();
      const store = useStore();
      let { sn, bsn } = route.query;
      if (!sn || !bsn) {
        sn = route.path.split('_')[1];
        bsn = route.path.split('_')[2];
      }
      const isFinish = ref(false);
      onMounted(async () => {
        // 获取流程的数据，来获取表单的sn
        const resData = await getBpmDef(sn as string);
        if (!resData) return;
        if (!resData.formDefSn) {
          ElMessage.warning('获取数据失败。 请稍后重试');
          return;
        }
        // const businessData = await getBusinessData(resData.formDefSn, bsn as string);
        const [ctl, methods] = useModule({
          params: {
            defSn: resData.formDefSn,
            wrapConfig: {
              title: resData.title,
              hideBack: true,
              actions: []
            },
            type: 'create',
            setQueryData: () => {
              return Promise.resolve({
                bpmSn: sn as string,
                orgTreeSn: activeOrganization.value?.sn ?? '',
                orgTreeName: activeOrganization.value?.name ?? '',
                sn: bsn,
                configDataMap: resData.configDataMap ?? ''
              });
            },
            beforeSubmit: async (data: Record<string, unknown>) => {
              try {
                const res = await getBpmAlertMsg(sn as string, undefined, JSON.stringify(data));
                if (!res) return false;
                if (res.success) {
                  await ElMessageBox.confirm(res.title, '提示');
                } else {
                  await ElMessageBox.alert(res.title, '提示');
                }
                return true;
              } catch (e) {
                return false;
              }
            }
          },
          handler(moduleName: string, name: string, data: any[]) {
            if (name === 'submitData') {
              resultData.value = {
                isSuccess: data[0].response.success,
                data: data[0].response.data
              };
              isFinish.value = true;
            }
            if (name === 'ready') {
              const businessData = methods.getData?.();
              if (!businessData) return;
              // 这里是修改tab的显示名称
              let titleStr = methods.getResConfig().def.title;
              const codeArr = titleStr.match(new RegExp('{.*?(?<=})', 'gi'));
              if (codeArr && codeArr.length) {
                codeArr.forEach((v) => {
                  const stepKey = v.replace('{', '').replace('}', '').split('.');
                  const titleData: string | Record<string, unknown> =
                    businessData[stepKey[0]] ?? '';
                  titleStr = formatterStrByObj(titleStr, { [stepKey[0]]: titleData });
                });
                // 修改tab的title
              }
              store.commit('menu/SET_TAB_TITLE', {
                name: route.name,
                title: titleStr,
                type: 'create'
              });
            }
          }
        });
        formCtl.value = ctl;
      });
      beforeCloseTab((next) => {
        ElMessageBox.confirm('确认关闭窗口，系统不会主动保存您的数据', '关闭窗口')
          .then(() => {
            next(true);
          })
          .catch(() => next(false));
      });
      const closeTab = () => {
        closeWindow();
        // store.commit('menu/DEL_TAB_MENUS_BYPATH', route.path);
        // store.commit('menu/REMOVE_KEEP_ALIVE', route.name);
      };
      return {
        resultData,
        closeTab,
        isFinish,
        formCtl
      };
    }
  });
</script>
<style lang="less"></style>
