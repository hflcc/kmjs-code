<!--新建流程-->
<template>
  <kmjs-form-module v-if="formCtl && !isFinish" :ctl="formCtl"></kmjs-form-module>
  <submitResult v-if="isFinish" :data="resultData" :close-tab="closeTab"></submitResult>
</template>

<script lang="ts">
  import { defineComponent, onMounted, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import { getBpmDef } from '@/pages/backlog/api';
  import { useModule, FormCtl } from '@/formModule';
  import useOrganization from '@/store/commModules/organization/useOrganization';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { useStore } from 'vuex';
  import useTabMenuHook from '@/layout/components/tabsMenu/tabMenuHooks';
  import { getBpmAlertMsg } from '@/utils/commApi';
  import submitResult from '@/components/submitResultPlay';

  export default defineComponent({
    name: 'create-bpm',
    components: {
      submitResult
    },
    setup() {
      const resultData = ref({});
      const { closeWindow, beforeCloseTab } = useTabMenuHook();
      const formCtl = ref<FormCtl | null>(null);
      const isFinish = ref(false);
      const { activeOrganization } = useOrganization();
      const route = useRoute();
      const store = useStore();
      let { sn } = route.query;
      if (!sn) {
        sn = route.path.split('_')[1];
      }
      onMounted(async () => {
        const resData = await getBpmDef(sn as string);
        if (!resData) return;
        if (!resData.formDefSn) {
          ElMessage.warning('获取数据失败。 请稍后重试');
          return;
        }
        const [ctl, methods] = useModule({
          params: {
            defSn: resData.formDefSn,
            wrapConfig: {
              title: resData.title,
              hideBack: true,
              actions: []
            },
            type: 'create',
            setQueryData: () => {
              return Promise.resolve({
                bpmSn: sn,
                orgTreeSn: activeOrganization.value?.sn ?? '',
                orgTreeName: activeOrganization.value?.name ?? '',
                configDataMap: resData.configDataMap ?? {}
              });
            },
            beforeSubmit: async (data: Record<string, unknown>) => {
              try {
                const res = await getBpmAlertMsg(sn as string, undefined, JSON.stringify(data));
                if (!res) return false;
                if (res.success) {
                  await ElMessageBox.confirm(res.title, '提示');
                } else {
                  await ElMessageBox.alert(res.title);
                }
                return true;
              } catch (e) {
                return false;
              }
            }
          },
          handler(moduleName: string, name: string, data: any[]) {
            if (name === 'submitData') {
              ElMessage.success('提交成功');
              resultData.value = {
                isSuccess: data[0].response.success,
                data: data[0].response.data
              };
              isFinish.value = true;
              // router.back();
              // store.commit('menu/DEL_TAB_MENUS_BYPATH', route.path);
              // store.commit('menu/REMOVE_KEEP_ALIVE', 'create-bpm');
            }
            if (name === 'ready') {
              const config = methods.getResConfig();
              // 修改tab的title
              store.commit('menu/SET_TAB_TITLE', {
                name: route.name,
                title: config.def.title ?? config.def.name,
                type: 'create'
              });
            }
          }
        });
        formCtl.value = ctl;
      });
      beforeCloseTab((next) => {
        ElMessageBox.confirm('确认关闭窗口，系统不会主动保存您的数据', '关闭窗口')
          .then(() => {
            next(true);
          })
          .catch(() => next(false));
      });
      const closeTab = () => {
        closeWindow();
      };
      return {
        resultData,
        closeTab,
        isFinish,
        formCtl
      };
    }
  });
</script>
<style lang="less"></style>
