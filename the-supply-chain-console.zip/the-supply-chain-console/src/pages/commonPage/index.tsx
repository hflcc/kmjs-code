/**
 * 动态创建表单相关的路由。解决同时编辑多个表单路由无法复用的问题
 * */
import { defineComponent } from 'vue';
import moduleCreate from '@/pages/commonPage/moduleCreate/index.vue';
import moduleEdit from '@/pages/commonPage/moduleEdit/index.vue';
import moduleDetail from '@/pages/commonPage/moduleDetail/index.vue';
import createBpm from '@/pages/commonPage/BPM/createBpm.vue';
import createBpmFromBusiness from '@/pages/commonPage/BPM/createBpmFromBusiness.vue';
import bpmDetail from '@/pages/backlog/detail.vue';
import router from '@/router';
import { NavigationGuardNext, RouteLocationNormalized } from 'vue-router';

/**
 * 创建编辑表单页面
 * @param sn 表单定义的SN
 * @param businessSn 业务逻辑sn
 * */
export const goToFormEdit = (sn: string, businessSn: string, query?: Record<string, any>) => {
  const name = 'FME' + sn + '' + businessSn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name, query });
    return name;
  }
  const path = 'FME_' + sn + '_' + businessSn;
  const component = defineComponent({
    name: name,
    components: {
      moduleEdit
    },
    setup() {
      return () => <moduleEdit></moduleEdit>;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '编辑'
    }
  });
  router.push({ name, query });
  return name;
};
/**
 * 创建新增表单页面
 * @param sn 表单定义的SN
 * */
export const goToFormCreate = (sn: string, query?: Record<string, any>) => {
  if (!sn) return;
  const name = 'FMC' + sn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name, query });
    return name;
  }
  const path = 'FMC_' + sn;
  const component = defineComponent({
    name: name,
    components: {
      moduleCreate
    },
    render() {
      return <moduleCreate />;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name, // name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '新建'
    }
  });
  router.push({ name, query });
  return name;
};
/**
 * 创建表单详情页面
 * @param sn 表单定义SN
 * @param businessSn 业务数据SN
 * */
export const goToFormDetail = (sn: string, businessSn: string) => {
  const name = 'FMD' + sn + businessSn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name });
    return name;
  }
  const path = 'FMD_' + sn + '_' + businessSn;
  const component = defineComponent({
    name: name,
    components: {
      moduleDetail
    },
    setup() {
      return () => <moduleDetail></moduleDetail>;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '详情'
    }
  });
  router.push({ name });
  return name;
};

/**
 * 新建流程表单页面
 * @param bpmSn 流程定义SN
 * */
export const goToCreateBpm = (bpmSn: string) => {
  const name = 'FMB' + bpmSn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name });
    return name;
  }
  const path = 'FMB_' + bpmSn;
  const component = defineComponent({
    name: name,
    components: {
      createBpm
    },
    setup() {
      return () => <createBpm></createBpm>;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '流程'
    }
  });
  router.push({ name });
  return name;
};
/**
 * 从业务数据触发新建流程表单页面
 * @param bpmSn 流程定义SN
 * @param bsn 业务数据SN
 * */
export const goToCreateBpmByBusiness = (bpmSn: string, bsn: string) => {
  const name = 'FMBB' + bpmSn + bsn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name });
    return name;
  }
  const path = 'FMBB_' + bpmSn + '_' + bsn;
  const component = defineComponent({
    name: name,
    components: {
      createBpmFromBusiness
    },
    setup() {
      return () => <createBpmFromBusiness></createBpmFromBusiness>;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '流程'
    }
  });
  router.push({ name });
  return name;
};

/**
 * 打开待办详情
 * @param bpmSn 流程的定义SN
 * */
export const goToBpmDetail = (bpmSn: string) => {
  const name = 'FMBPD' + bpmSn;
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name });
    return name;
  }
  const path = 'FMBPD_' + bpmSn;
  const component = defineComponent({
    name: name,
    components: {
      bpmDetail: bpmDetail
    },
    setup() {
      return () => <bpmDetail />;
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      keepName: name,
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      title: '流程详情'
    }
  });
  router.push({ name });
  return name;
};
/**
 * 处理表单是404时,新建动态路由后在跳转。一般是用户直接复制url在新窗口打开导致
 * */
export const formRouterBuild = (route: RouteLocationNormalized, next: NavigationGuardNext) => {
  const url = route.path.substr(1).split('_');
  switch (url[0]) {
    case 'FMC':
      goToFormCreate(url[1], route.query);
      break;
    case 'FME':
      goToFormEdit(url[1], url[2], route.query);
      break;
    case 'FMD':
      goToFormDetail(url[1], url[2]);
      break;
    case 'FMB':
      goToCreateBpm(url[1]);
      break;
    case 'FMBB':
      goToCreateBpmByBusiness(url[1], url[2]);
      break;
    case 'FMBPD':
      goToBpmDetail(url[1]);
      break;
    default:
      next();
  }
};
