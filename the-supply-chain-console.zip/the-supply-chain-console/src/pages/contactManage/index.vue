<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"> </kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { delCerContact, delBatchContactSn } from './api';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sns: string;
    sn: string;
    name: string;
  }
  export default defineComponent({
    name: 'contactManage',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      // 选择模式，是单选还是多选
      selectMode: {
        type: String as PropType<'single' | 'multiple'>,
        default: ''
      }
    },
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        tableContactDeleData: async (list, methods) => {
          let sn = list[0].row.sn;
          const name = list[0].row.name;
          const message = `确认要删除【${name}】吗？`;
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delCerContact(sn);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('删除成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        },
        tableContactBatchDelete: async (list) => {
          const selectedData: TableRow[] = list[0] || [];
          if (!selectedData.length) {
            ElMessage.error('请选择需要批量删除的联系人');
            return;
          }
          const sns = selectedData.map((item) => item.sn);
          const message = '确定要删除已选中联系人吗？';
          ElMessageBox.confirm(message)
            .then(async () => {
              const res = await delBatchContactSn(sns);
              if (res) {
                methods['/title/title-table/refresh']();
                ElMessage.success('操作成功');
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '联系人管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'createForm',
                  params: {
                    // 配置项
                    defSn: 'ef37c23526cf46679d853dbaf5ee09d2 '
                  }
                }
              ]
            },
            children: [
              {
                type: 'table',
                name: 'title-table',
                params: {
                  tableDataUrl: '/auth/md/person/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '编号',
                          key: 'code',
                          type: 'text'
                        },
                        {
                          label: '姓名',
                          key: 'name',
                          type: 'text'
                        },
                        {
                          label: '电话号码',
                          key: 'phone',
                          type: 'text'
                        },
                        {
                          label: '职位',
                          key: 'job',
                          type: 'select',
                          dictionaryName: 'contact_job'
                        },
                        {
                          label: '创建人',
                          key: 'createdByName'
                        },
                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '编号',
                          key: 'code'
                        },
                        {
                          label: '姓名',
                          key: 'name'
                        },
                        {
                          label: '电话号码',
                          key: 'phone',
                          width: 180
                        },
                        {
                          label: '职位',
                          key: 'job',
                          type: 'mapText',
                          params: {
                            type: 'dictionary',
                            dictionaryName: 'contact_job'
                          }
                        },
                        {
                          label: '创建人',
                          key: 'createdByName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          type: 'formatter',
                          width: 180,
                          params: {
                            formatter: 'dateTime',
                            formatterType: 'YYYY-MM-DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'description'
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              emit: 'contactDetail',
                              label: '详情',
                              params: {
                                defSn: 'cbaecac163d14793af131758420b4d72 ',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'contactEdit',
                              params: {
                                defSn: '0095689dddae4c398b26114caaed9250',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'contactDeleData'
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          type: 'danger',
                          emit: 'contactBatchDelete'
                        }
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ],
        params: {
          '/title/title-table': {
            beforeRequest: (obj: { [index: string]: any }) => {
              obj.url = `${obj.url}`;
              return Promise.resolve(obj);
            }
          }
        },
        handler: (moduleName, name, data) => {
          console.log(moduleName, name, data);
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>
<style lang="less"></style>
