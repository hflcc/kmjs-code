import ajax from '@/utils/axios';

/*
 * 删除联系人api
 * */
export const delCerContact = (sn: string) => {
  return ajax.delete(`/auth/md/person//${sn}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 批量删除联系人
 */
export function delBatchContactSn(sns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ sns: string[] }, { success: boolean }>(`/auth/md/person/batch/${sns}`, {
    params: {
      $InstId: true
    }
  });
}
