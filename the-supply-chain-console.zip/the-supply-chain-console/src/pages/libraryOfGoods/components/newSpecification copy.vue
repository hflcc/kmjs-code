<!-- <template>
  <el-dialog v-model="showDialog" title="新增规格" @close="closeWindow" width="50%" top="10vh">
    <div class="from-pop-dialog">
      
  <el-form :model="formInline">
        <el-form-item v-for="(item, index) in formInline" :key="item">
          <div class="specification-big-box">
            <div class="specification-small-box">
              <div class="specification-name">
                <div class="label-name">规格名：</div>
                <el-input
                  class="element-input"
                  v-model="item.name"
                  placeholder="请输入规格名"
                ></el-input>
              </div>
              <div class="specification-name">
                <div class="label-name">规格值：</div>
                <div class="value-box">
                  <div class="input-box" v-for="children in item.children" :key="children">
                    <el-input
                      class="element-input"
                      v-model="children.name"
                      placeholder="请输入规格值"
                    ></el-input>
                    <i
                      @click.prevent="removeDomain(item, children, index)"
                      class="el-icon-circle-close cross"
                    ></i>
                  </div>
                  <span class="add-specification" @click="addDomain(index, item)">新增规格值</span>
                </div>
              </div>
            </div>
            <i class="el-icon-circle-close" @click.prevent="removeUser(item)"></i>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <div class="bottom-box">
        <div class="new-specification-name" v-if="formInline.length < 3">
          <el-button type="primary" plain @click="addUser">新增规格名</el-button>
        </div>
      </div>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取消</el-button>
        <el-button type="primary" @click="confirm">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>-->
<script lang="ts">
  //   import { defineComponent, PropType, ref } from 'vue';
  //   import { useDialog } from '@/utils';
  //   import { SpecsStore } from '@/pages/libraryOfGoods/api';
  //   import { useStore } from 'vuex';
  //   import { ElMessageBox } from 'element-plus';

  //   export default defineComponent({
  //     name: 'newSpecification',
  //     components: {},
  //     props: {
  //       modelValue: {
  //         type: Boolean as PropType<boolean>,
  //         default: true
  //       }
  //     },
  //     setup(props, { emit }) {
  //       const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
  //         if (v && store.state.goods.specs.length) {
  //           formInline.value = Object.assign([], store.state.goods.specs);
  //           if (!store.state.goods.isSpecsIndex) {
  //             isIndex.value = 0;
  //             formInline.value.map((res) => {
  //               isIndex.value += res.children.length;
  //             });
  //             store.commit('goods/SET_ISSPECSINDEX', isIndex.value);
  //           }
  //         }
  //       });
  //       const store = useStore<RootState>();
  //       // 当前新增的总数，控制唯一children下标
  //       const isIndex = ref(1);
  //       const formInline = ref<SpecsStore[]>([
  //         {
  //           name: '',
  //           index: 1,
  //           select: [],
  //           children: [
  //             {
  //               name: '',
  //               index: isIndex.value
  //             }
  //           ]
  //         }
  //       ]);
  //       // 新增规格名
  //       const addUser = () => {
  //         if (formInline.value.length < 3) {
  //           formInline.value.push({
  //             name: '',
  //             index: formInline.value.length + 1,
  //             select: [],
  //             children: [
  //               {
  //                 name: '',
  //                 index: ++isIndex.value
  //               }
  //             ]
  //           });
  //         } else {
  //           ElMessageBox.alert('新增数量达到上线，最多只能新增3个规格名');
  //         }
  //       };
  //       // 删除规格名
  //       const removeUser = (item: SpecsStore) => {
  //         console.log(item, 'item<<<<<');

  //         if (formInline.value.length > 1) {
  //           const index = formInline.value.indexOf(item);
  //           if (index !== -1) {
  //             formInline.value.splice(index, 1);
  //           }
  //         } else {
  //           ElMessageBox.alert('保留一个');
  //         }
  //       };
  //       // 新增规格值
  //       const addDomain = (index: number) => {
  //         if (formInline.value[index]?.children.length < 20) {
  //           formInline.value[index]?.children.push({
  //             index: ++isIndex.value,
  //             name: ''
  //           });
  //         } else {
  //           ElMessageBox.alert('新增数量达到上线');
  //         }
  //       };
  //       // 删除规格值
  //       const removeDomain = (item: SpecsStore, itemChildren: never, inx: number) => {
  //         console.log(item);

  //         if (formInline.value[inx]?.children.length > 1) {
  //           const index = formInline.value[inx]?.children.indexOf(itemChildren);
  //           if (index !== -1) {
  //             formInline.value[inx]?.children.splice(index, 1);
  //           }
  //         } else {
  //           ElMessageBox.alert('保留一个');
  //         }
  //       };

  //       // 确定新增
  //       const confirm = () => {
  //         // 删除
  //         formInline.value.map((item, index) => {
  //           if (item.index !== index + 1) {
  //             item.index = index + 1;
  //           }
  //         });
  //         console.log(formInline.value, 'formInline.value');
  //         store.commit('goods/SET_SPECS', formInline.value);
  //         store.commit('goods/SET_ISSPECSINDEX', isIndex.value);
  //         closeWindow();
  //       };
  //       //是否有存储规格

  //       // 新增规格名
  //       return {
  //         showDialog,
  //         formInline,
  //         closeWindow,
  //         addDomain,
  //         removeDomain,
  //         addUser,
  //         removeUser,
  //         confirm
  //       };
  //     }
  //   });
  //
</script>
<style lang="less" scoped>
  //   .from-pop-dialog {
  //     position: relative;
  //     max-height: 520px;
  //     overflow-y: scroll;
  //   }
  //   .add-specification {
  //     display: inline-block;
  //     margin-left: 10px;
  //     color: #3382d3;
  //   }
  //   .specification-big-box {
  //     display: flex;
  //     justify-content: space-between;
  //     align-items: center;
  //     padding: 20px 20px 0 20px;
  //     background: #f7f8fa;
  //     border-radius: 4px;
  //     .el-icon-circle-close {
  //       font-size: 20px;
  //       color: #ccc;
  //     }
  //   }
  //   .specification-small-box {
  //     .specification-name {
  //       display: flex;
  //       padding-bottom: 12px;
  //       .value-box {
  //         display: flex;
  //         flex-wrap: wrap;
  //         .input-box {
  //           position: relative;
  //           margin: 0 14px 12px 0;
  //           .cross {
  //             position: absolute;
  //             right: -7px;
  //             top: -7px;
  //             font-size: 16px;
  //             color: #ccc;
  //           }
  //         }
  //       }
  //       .element-input {
  //         width: 200px;
  //       }
  //       .label-name {
  //         min-width: 60px;
  //       }
  //     }
  //   }
  //   .bottom-box {
  //     width: 100%;
  //     background: #fff;
  //   }
  //   .new-specification-name {
  //     text-align: center;
  //   }
  //   .specification-btn {
  //     float: right;
  //   }
  //
</style>
