<!--<template>
   <el-dialog v-model="showDialog" title="选择规格" width="50%" @close="closeWindow">
    <div class="choice-box">
      <el-form :model="formSpecs">
        <el-form-item v-for="(item, index) in formSpecs" :key="index">
          <div class="choice-content">
            <p class="choice-name">{{ item.name }}</p>
            <div class="choice-radio">
              <el-checkbox-group
                v-model="item.select"
                :min="0"
                :max="1"
                v-for="children in item.children"
                :key="children.index"
                @change="isCheckbox(index)"
                :disabled="isDisabledFun(item, index)"
              >
                <el-checkbox :label="children.index" style="display: inline-block">
                  {{ children.name }}
                </el-checkbox>
              </el-checkbox-group>
            </div>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取消</el-button>
        <el-button type="primary" @click="confirm">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template> -->
<script lang="ts">
  //   import { defineComponent, PropType, ref } from 'vue';
  //   import { SkusData, SpecsStore } from '@/pages/libraryOfGoods/api';
  //   import { useStore } from 'vuex';
  //   import { useDialog } from '@/utils';

  //   export default defineComponent({
  //     props: {
  //       // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
  //       modelValue: {
  //         type: String as PropType<string>,
  //         default: ''
  //       },
  //       // 编辑数据
  //       compileData: {
  //         type: Object as PropType<SkusData>,
  //         required: true
  //       },
  //       // 是否为新增
  //       operation: {
  //         type: Boolean as PropType<boolean>,
  //         default: true
  //       },
  //       // 当前表单项的配置信息
  //       config: {
  //         type: Object as PropType<Record<string, any>>
  //       },
  //       // 更新数据到表单的整体数据中
  //       change: {
  //         type: Function as PropType<(data: { name: string; specIndexes: [] }) => void>,
  //         required: true
  //       }
  //     },
  //     setup(props, { emit }) {
  //       // 展示选中规格数据
  //       const isSelect = ref('');
  //       // 控制是否禁用
  //       const isDisabled = ref(false);
  //       // 绑定选择的规格(绑定到children下面的index值，index值是唯一)
  //       const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
  //         if (v) {
  //           formSpecs.value = Object.assign([], store.state.goods.specs);
  //           formSpecs.value.map((res) => {
  //             if (!res.select) {
  //               const key = 'select';
  //               const value: string[] = [];
  //               res[key] = value;
  //             } else {
  //               res.select = [];
  //             }
  //           });
  //           // 编辑勾选回显
  //           if (props.operation) {
  //             const indexes: any = ref(props.compileData.specIndexes);
  //             formSpecs.value.map((res) => {
  //               indexes.value.forEach((v: any) => {
  //                 res.children.map((child) => {
  //                   if (v == child.index) {
  //                     res.select?.push(v);
  //                   }
  //                 });
  //               });
  //             });
  //           }
  //         }
  //       });
  //       const store = useStore<RootState>();
  //       // 是否有规格数据
  //       const formSpecs = ref<SpecsStore[]>([]);
  //       // 控制按顺序选择规格
  //       const isDisabledFun = (item: SpecsStore, ind: number) => {
  //         // 总规格数
  //         const maxSpec = formSpecs.value.length;
  //         // 第一个
  //         if (ind === 0) {
  //           if (maxSpec === 1) {
  //             return false; // 只有一个规格，肯定可以编辑
  //           }
  //           // 如果他的下一个已经被选择，则第一个不给取消
  //           return formSpecs.value[ind + 1].select.length > 0;
  //         } else {
  //           // 判断是否是最后一个
  //           if (ind + 1 === maxSpec) {
  //             console.log(555);

  //             // 判断上一个是否被选择了，则这个可以被选择
  //             return formSpecs.value[ind - 1].select.length <= 0;
  //           } else {
  //             console.log(6666);

  //             // 这里判断不是最后一个。上一个已被选择，下一个没有被选
  //             return !(
  //               formSpecs.value[ind - 1].select.length > 0 &&
  //               formSpecs.value[ind + 1].select.length === 0
  //             );
  //           }
  //         }
  //       };

  //       // 控制最多只能选择3个
  //       const isCheckbox = (index: number) => {
  //         const list: any = ref([]);
  //         formSpecs.value.map((item) => {
  //           if (item.select.length) {
  //             console.log(item.select[0], 'item.select');
  //             list.value.push(item.select[0]);
  //           }
  //         });
  //         console.log(list.value.length, 'list.value.lengthlist.value.length');
  //         // if (list.value.length >= 3) {
  //         //   isDisabled.value = true;
  //         // } else {
  //         //   isDisabled.value = false;
  //         // }
  //       };
  //       // 确定选择规格
  //       const confirm = () => {
  //         const specIndexes: any = ref([]);
  //         isSelect.value = '';
  //         formSpecs.value.map((item, index) => {
  //           const selectNum = ref('');
  //           // 是否有选中
  //           if (item.select.length) {
  //             console.log('进来了');
  //             console.log(index, 'index');
  //             console.log(item, 'item');
  //             specIndexes.value.push(item.select[0]);
  //             item.children.map((itemChild) => {
  //               if (Number(item.select[0]) == itemChild.index) {
  //                 selectNum.value = item.name + '：' + itemChild.name;
  //                 isSelect.value += selectNum.value + '\n';
  //               }
  //             });
  //           }
  //         });
  //         // 传值给父组件表单
  //         if (isSelect.value != '') {
  //           props.change({ name: isSelect.value, specIndexes: specIndexes.value });
  //         } else {
  //           props.change({ name: '', specIndexes: [] });
  //         }
  //         closeWindow();
  //         isDisabled.value = false;
  //         emit('confirm', isSelect.value);
  //       };
  //       return {
  //         formSpecs,
  //         isSelect,
  //         isDisabled,
  //         showDialog,
  //         confirm,
  //         isDisabledFun,
  //         isCheckbox,
  //         closeWindow
  //       };
  //     }
  //   });
  //
</script>
<style lang="less" scoped>
  //   // 选择规格弹窗
  //   .choice-box {
  //     max-height: 500px;
  //     overflow-y: scroll;
  //     .choice-content {
  //       margin-bottom: 10px;
  //       .choice-name {
  //         margin-bottom: 10px;
  //       }
  //       .choice-radio {
  //         margin-left: 20px;
  //         display: flex;
  //         /deep/ .el-checkbox-group {
  //           margin-right: 10px;
  //           margin-bottom: 10px;
  //         }
  //       }
  //     }
  //   }
  //
</style>
