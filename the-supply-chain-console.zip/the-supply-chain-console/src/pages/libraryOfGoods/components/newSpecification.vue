<template>
  <el-dialog
    v-model="showDialog"
    :title="superiorCompile ? '编辑规格' : '新增规格'"
    @close="closeWindow"
    width="45%"
    top="10vh"
  >
    <el-form :model="formItemData" ref="editForm">
      <div class="specification-big-box">
        <el-form-item prop="name">
          <div class="specification-name">
            <div class="label-name">规格名：</div>
            <el-input
              class="element-input"
              v-model="formItemData.name"
              placeholder="请输入规格名"
              :disabled="inputDisabledList[0].name"
            ></el-input>
          </div>
        </el-form-item>
        <el-form-item prop="namePrice">
          <div class="specification-name">
            <div class="label-name">规格值：</div>
            <el-input
              class="element-input"
              v-model="formItemData.namePrice"
              placeholder="请输入规格值(选填)"
              :disabled="inputDisabledList[1].name"
            ></el-input>
          </div>
        </el-form-item>
        <el-form-item prop="namePriceTwo">
          <div class="specification-name">
            <div class="label-name">规格值：</div>
            <el-input
              class="element-input"
              v-model="formItemData.namePriceTwo"
              placeholder="请输入规格值(选填)"
              :disabled="inputDisabledList[2].name"
            ></el-input>
          </div>
        </el-form-item>
        <!-- <el-form-item prop="namePriceThree">
          <div class="specification-name">
            <div class="label-name">规格值：</div>
            <el-input
              class="element-input"
              v-model="formItemData.namePriceThree"
              placeholder="请输入规格值(选填)"
              :disabled="inputDisabledList[3].name"
            ></el-input>
          </div>
        </el-form-item> -->
      </div>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取消</el-button>
        <el-button type="primary" @click="confirm">保存</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import { defineComponent, nextTick, PropType, ref } from 'vue';
  import { ElForm, ElMessage } from 'element-plus';
  import { useDialog } from '@/utils';
  import { useStore } from 'vuex';
  import { SpecsChilden, SpecsStore } from '@/pages/libraryOfGoods/api';

  export default defineComponent({
    name: 'newSpecification',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      // 当前选中数据
      specificationData: {
        type: Object as PropType<SpecsStore>,
        required: true
      },
      // 是否子级新增和编辑
      superior: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      // 是否编辑子级
      superiorCompile: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      // 当前数据node,可拿到全部父节点
      superiorData: {
        type: Object as PropType<unknown>,
        required: true
      }
    },
    setup(props, { emit }) {
      const editForm = ref<InstanceType<typeof ElForm> | null>(null);
      const store = useStore<RootState>();
      // 当前新增的总数，控制唯一children下标
      const isIndex = ref(0);
      // 显示新增表单
      const formItemData = ref({
        name: '',
        namePrice: '',
        namePriceTwo: '',
        namePriceThree: ''
      });
      // 禁用输入框
      const inputDisabledList = ref([
        {
          name: false
        },
        {
          name: false
        },
        {
          name: false
        },
        {
          name: false
        }
      ]);
      // 当前全部数据
      const formList = ref<SpecsStore[]>([]);
      // 数据新增
      const formInline = ref<SpecsStore>({
        name: '',
        index: 0,
        select: [],
        children: []
      });
      // 子级编辑
      const sonFrom = ref<SpecsChilden>({
        name: '',
        index: 0,
        children: []
      });
      // 子级新增
      const sonFromNew = ref<SpecsChilden[]>([]);
      const listPop = ref([]);
      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        console.log(store.state.goods.specs, 'specs');
        console.log(store.state.goods.isSpecsIndex, 'isSpecsIndex');
        console.log(props.specificationData, 'specificationData');
        console.log(props.superiorData, 'superiorData<<');
        // 数据重置
        if (!v) {
          nextTick(() => {
            editForm.value?.resetFields();
            formInline.value = {
              name: '',
              index: 0,
              select: [],
              children: []
            };
            sonFrom.value = {
              name: '',
              index: 0,
              children: []
            };
            sonFromNew.value = [];
            formItemData.value = {
              name: '',
              namePrice: '',
              namePriceTwo: '',
              namePriceThree: ''
            };
            inputDisabledList.value = [
              {
                name: false
              },
              {
                name: false
              },
              {
                name: false
              },
              {
                name: false
              }
            ];
          });
        }
        if (v && store.state.goods.specs.length) {
          // 拿到全部规格数据
          formList.value = Object.assign([], store.state.goods.specs);
          // 新增总数
          isIndex.value = store.state.goods.isSpecsIndex;
          // 是否是子级操作
          if (props.superior) {
            listPop.value = familyTree(props.superiorData);
            // 回显弹窗
            if (listPop.value.length) {
              popupconTentShow(listPop.value);
            }
          }
        }
      });
      // 新增规格数据处理
      const newFun = (level?: number) => {
        // 声明name
        const { name, namePrice, namePriceTwo, namePriceThree } = formItemData.value;
        const names = [name, namePrice, namePriceTwo, namePriceThree];
        let tempParent: SpecsChilden[] | null = [];
        // 判断是否有规格名
        if (name) {
          if (props.superior) {
            tempParent = sonFromNew.value as SpecsChilden[];
          } else {
            // 最外层新增
            formInline.value.name = name;
            formInline.value.index = ++isIndex.value;
            tempParent = formInline.value.children as SpecsChilden[];
          }
          // 处理规格名
          for (let i = level ? level : 1; i < names.length; i++) {
            if (i != names.length - 1 && names[i] == '' && names[i + 1] != '') {
              return ElMessage.warning(`请输入第${i}位规格值才能输入下一个规格值`);
            } else {
              if (names[i]) {
                tempParent?.push(setChildren(names.slice(0, i + 1)));
                tempParent = tempParent[0].children as SpecsChilden[];
              }
            }
          }
          tempParent = null;
        } else {
          ElMessage.warning('请输入规格名');
        }
      };
      // 设置子节点
      const setChildren = (names: string[]) => {
        return {
          name: names.reduce((pre, name) => {
            if (pre) return pre + '*' + name;
            else return name;
          }, ''),
          index: ++isIndex.value,
          children: []
        };
      };

      // 回显弹窗数据
      const popupconTentShow = (list: never[]) => {
        // 编辑弹窗
        inputDisabledList.value.map((res, index) => {
          if (props.superiorCompile) {
            if (index + 1 == list.length) {
              res.name = false;
            } else {
              res.name = true;
            }
          } else {
            if (index < list.length) {
              res.name = true;
            } else {
              res.name = false;
            }
          }
        });
        let nameList: any = [];
        const obj: any = {};
        list.map((res: SpecsChilden) => {
          if (res.name.indexOf('*') != -1) {
            const name = res.name.split('*')[res.name.split('*').length - 1];
            nameList?.push(name);
          } else {
            nameList?.push(res.name);
          }
        });
        const arr = ['name', 'namePrice', 'namePriceTwo', 'namePriceThree'];
        for (let i = 0; i < arr.length; i++) {
          if (nameList[i]) {
            obj[arr[i]] = nameList[i];
          } else {
            obj[arr[i]] = '';
          }
        }
        formItemData.value = obj;
      };
      // 新增子级&编辑子级
      const sonNewFun = () => {
        const level: any = props.superiorData;
        // 子级编辑
        if (props.superiorCompile) {
          sonFrom.value = props.specificationData;
          const primaryName = ref('');
          if (sonFrom.value.sn && sonFrom.value.mixName) {
            primaryName.value = sonFrom.value.mixName.split('*')[level.level - 1];
            console.log(primaryName, 'primaryNameprimaryNameprimaryNameprimaryName');
          } else {
            primaryName.value = sonFrom.value.name.split('*')[level.level - 1];
          }
          flatten(sonFrom.value, primaryName.value);
        } else {
          newFun(level.level);
        }
      };
      const flatten = (node: SpecsChilden, isName: string) => {
        const level: any = props.superiorData;
        const { name, namePrice, namePriceTwo, namePriceThree } = formItemData.value;
        const names = [name, namePrice, namePriceTwo, namePriceThree];
        let reg = '/' + isName + '/g';
        if (node.mixName) {
          node.mixName = node.mixName.replace(eval(reg), names[level.level - 1]);
          node.name = names[level.level - 1];
        } else {
          node.name = node.name.replace(eval(reg), names[level.level - 1]);
        }
        const child = node.children;
        if (child != undefined && child.length > 0) {
          child.forEach((ele: SpecsChilden) => {
            if (ele.mixName) {
              ele.mixName = ele.mixName.replace(eval(reg), names[level.level - 1]);
            } else {
              ele.name = ele.name.replace(eval(reg), names[level.level - 1]);
            }
            if (ele.children?.length) {
              flatten(ele, isName);
            }
          });
        }
      };
      // 拿到所有父级
      function familyTree(arr1: any) {
        const temp: any = [];
        const forFn = (arr: any) => {
          if (arr.parent) {
            temp.unshift(arr.data);
            forFn(arr.parent);
          }
        };
        forFn(arr1);
        return temp;
      }
      // 确定新增
      const confirm = async () => {
        // 新增规格
        console.log(props.superior, 'props.superior');
        if (!props.superior) {
          await newFun();
          formList.value.push(formInline.value);
          store.commit('goods/SET_SPECS', formList.value);
          store.commit('goods/SET_ISSPECSINDEX', isIndex.value);
          emit('confirm', formInline.value);
          closeWindow();
        } else {
          // 子级新增&编辑
          await sonNewFun();
          // 编辑
          if (props.superiorCompile) {
            console.log(sonFrom.value, 'sonFrom.valuesonFrom.value');

            // emit('confirm', sonFrom.value);
          } else {
            emit('confirm', sonFromNew.value);
            store.commit('goods/SET_ISSPECSINDEX', isIndex.value);
          }
          closeWindow();
        }
      };
      return {
        showDialog,
        formItemData,
        editForm,
        inputDisabledList,
        closeWindow,
        confirm
      };
    }
  });
</script>
<style lang="less" scoped>
  .specification-big-box {
    padding: 20px 20px 0 20px;
    border-radius: 4px;
    .el-icon-circle-close {
      font-size: 20px;
      color: #ccc;
    }
  }
  .specification-name {
    display: flex;
    padding-bottom: 12px;
    .value-box {
      display: flex;
      flex-wrap: wrap;
      .input-box {
        position: relative;
        margin: 0 14px 12px 0;
        .cross {
          position: absolute;
          right: -7px;
          top: -7px;
          font-size: 16px;
          color: #ccc;
        }
      }
    }
    .element-input {
      width: 200px;
    }
    .label-name {
      min-width: 60px;
    }
  }
</style>
