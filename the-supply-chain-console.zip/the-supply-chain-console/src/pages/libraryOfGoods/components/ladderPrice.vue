<template>
  <div class="tiered-pricing" v-for="item in ladder" :key="item">
    <div class="price">
      <text>起始量</text>
      <el-input class="price-input" disabled v-model="item.min" size="small" placeholder="起始量" />
    </div>
    <div class="price">
      <text>结束量</text>
      <el-input class="price-input" disabled v-model="item.max" size="small" placeholder="结束量" />
    </div>
    <div class="price">
      <text>售价</text>
      <el-input
        type="number"
        ref="inputFocus"
        class="price-input"
        v-model="item.price"
        @blur="blur"
        size="small"
        min="0"
        placeholder="售价"
      />
    </div>
  </div>
  <p v-if="!ladder.length">暂未进行阶梯设置</p>
</template>
<script lang="ts">
  import { defineComponent, PropType, onMounted, ref, watch } from 'vue';
  import { StepPricesList } from '../api';

  export default defineComponent({
    props: {
      ladder: {
        type: Array as PropType<StepPricesList[]>,
        default: () => []
      },
      // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
      modelValue: {
        type: String as PropType<string>,
        default: ''
      },
      // 当前表单项的配置信息
      config: {
        type: Object as PropType<Record<string, any>>
      },
      // 更新数据到表单的整体数据中
      change: {
        type: Function as PropType<(data: Array<any>) => void>,
        required: true
      }
    },

    setup(props) {
      // 是否有值
      const isData = ref(0);
      const inputFocus = ref<HTMLElement | null>(null);
      onMounted(() => {
        inputFocus.value && inputFocus.value.focus();
      });
      watch(
        () => props.ladder,
        () => {
          props.change(props.ladder);
        }
      );
      // 失去焦点事件
      const blur = () => {
        console.log(props.ladder, 'props.ladder');
        props.ladder.map((item) => {
          item.price = item.price + '';
          if (item.price.replace(/\s+/g, '').length == 0) {
            isData.value = 2;
          } else {
            isData.value = 1;
          }
        });
        if (isData.value == 1) {
          props.change(props.ladder);
        } else {
          props.change([]);
        }
      };
      return {
        blur,
        inputFocus
      };
    }
  });
</script>
<style lang="less">
  .tiered-pricing {
    display: flex;
    align-items: center;
    padding: 4px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    .price {
      margin-right: 20px;
      .price-input {
        width: 120px;
        margin-left: 10px;
      }
    }
  }
</style>
