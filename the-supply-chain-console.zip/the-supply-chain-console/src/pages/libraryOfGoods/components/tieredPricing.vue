<template>
  <el-dialog v-model="showDialog" title="阶梯设置" @close="closeWindow" width="60%">
    <el-form ref="form" :model="formInlineList">
      <el-form-item
        v-for="(item, index) in formInlineList.formInline"
        :key="index"
        label="阶梯价"
        required
      >
        <div class="tiered-pricing">
          <el-form-item
            class="price"
            label="起始量"
            :prop="'formInline.' + index + '.min'"
            :rules="[
              {
                required: true,
                message: '请输入最小规格',
                trigger: 'blur'
              },
              {
                validator: validateAccount
              }
            ]"
          >
            <el-input class="price-input" v-model="item.min" size="small" placeholder="起始量" />
          </el-form-item>
          <el-form-item
            class="price"
            label="结束量"
            :prop="'formInline.' + index + '.max'"
            :rules="[
              {
                required: true,
                message: '请输入最大规格',
                trigger: 'blur'
              },
              {
                validator: validateAccount
              }
            ]"
          >
            <el-input class="price-input" v-model="item.max" size="small" placeholder="结束量" />
          </el-form-item>
          <el-icon
            class="el-icon-circle-close"
            :size="20"
            @click.prevent="removeTiered(item)"
          ></el-icon>
        </div>
      </el-form-item>
      <el-form-item v-if="formInlineList.formInline.length < 3">
        <el-button type="primary" size="small" @click="addTiered">添加阶梯价</el-button>
      </el-form-item>
      <el-form-item>
        <div class="select-box">
          <div class="btn">
            <el-button @click="closeWindow">取消</el-button>
            <el-button type="primary" @click="onSubmit">确定</el-button>
          </div>
        </div>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>
<script lang="ts">
  import { defineComponent, PropType, ref } from 'vue';
  import { useDialog } from '@/utils/hooks';
  import { StepPricesStore } from '@/pages/libraryOfGoods/api';
  import { useStore } from 'vuex';
  import { ElForm, ElMessage, ElMessageBox } from 'element-plus';
  export interface formList {
    formInline: StepPricesStore[];
  }

  export default defineComponent({
    name: 'tiered-pricing',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: true
      }
    },
    setup(props, { emit }) {
      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        if (v && store.state.goods.tiered.length) {
          console.log(store.state.goods.tiered, 'store.state.goods.tiered');

          formInlineList.value.formInline = Object.assign([], store.state.goods.tiered);
        }
      });
      // 验证输入
      const validateAccount = (rule: unknown, value: string, callback: (value?: Error) => void) => {
        const re = /^[1-9]\d*$/;
        if (!re.test(value)) {
          callback(new Error('请输入大于0的正整数'));
        } else {
          callback();
        }
      };
      const store = useStore<RootState>();
      const input = ref('');
      let formInlineList = ref<formList>({
        formInline: [
          {
            min: '',
            max: ''
          }
        ]
      });
      // 删除的数据
      const lineisDelete = ref<StepPricesStore[]>([]);
      // 新增阶梯价
      const addTiered = () => {
        if (formInlineList.value?.formInline.length < 3) {
          formInlineList.value?.formInline.push({
            min: '',
            max: ''
          });
        }
      };
      // 删除阶梯价
      const removeTiered = (item: any) => {
        if (formInlineList.value?.formInline.length > 1) {
          ElMessageBox.confirm('删除将会影响全局的阶梯价，确认删除吗？')
            .then(async () => {
              const index = formInlineList.value?.formInline.indexOf(item);
              if (index !== -1) {
                // 删除已有sn的数据需要将删除数据保存传回给后端
                if (item.sn) {
                  item.isDelete = true;
                  lineisDelete.value.push(item);
                }
                formInlineList.value?.formInline.splice(index, 1);
              }
            })
            .catch((err) => {
              console.log(err);
            });
        } else {
          ElMessageBox.alert('至少保留一个阶梯价');
        }
      };
      // 确定
      const form = ref<InstanceType<typeof ElForm>>();
      const onSubmit = () => {
        form.value?.validate((res) => {
          console.log(res, 'validate');
          if (res) {
            const isError = ref(true);
            formInlineList.value?.formInline.map((item, index) => {
              if (Number(item.min) >= Number(item.max)) {
                ElMessage.error('阶梯起始量不能大于或等于结束量');
                isError.value = false;
                return;
              }
              if (index >= 1) {
                const minIndex = formInlineList.value?.formInline[index - 1].max;
                if (Number(item.min) <= Number(minIndex)) {
                  ElMessage.error('下一阶梯起始量不能小于或等于上一阶梯结束量');
                  isError.value = false;
                  return;
                }
              }
            });
            console.log(isError.value, 'isError');
            if (!isError.value) {
              console.log(3333333);
              return false;
            }
            emit('submit', lineisDelete.value);
            store.commit('goods/SET_TIERED', formInlineList.value?.formInline);
            closeWindow();
          }
        });
      };
      return {
        addTiered,
        removeTiered,
        closeWindow,
        onSubmit,
        validateAccount,
        formInlineList,
        input,
        showDialog,
        form
      };
    }
  });
</script>
<style lang="less" scoped>
  .tiered-pricing {
    display: flex;
    align-items: center;
    padding: 4px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    .price {
      margin-right: 20px;
      .price-input {
        width: 120px;
      }
    }
  }
  .select-box {
    margin-bottom: 20px;
    .select-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 700;
    }
    .btn {
      padding-bottom: 20px;
      float: right;
    }
  }
</style>
