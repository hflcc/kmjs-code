<template>
  <div style="min-width: 772px">
    <el-dialog
      v-model="showDialog"
      :title="operation ? '编辑SKU' : '新增SKU'"
      @close="closeWindow()"
      top="6vh"
    >
      <div :style="{ height: '80vh', width: '100%' }">
        <kmjsModule style="height: 93%; overflow-y: scroll" :ctl="moduleCtl" ref="formRef">
          <template #from-specification="{ config, change }">
            <div class="standard">
              <el-input
                v-model="isSelect"
                disabled
                autosize
                type="textarea"
                placeholder="请选择规格"
              />
              <el-button type="primary" size="small" @click="selectSpecification"
                >选择规格</el-button
              >
              <specification
                v-model="dialogVisible"
                :config="config"
                :change="change"
                v-on:confirm="onConfirm"
                :operation="operation"
                :compileData="compileData"
                :clapList="clapList"
              ></specification>
            </div>
          </template>
          <template #from-data="{ modelValue, config, change }">
            <ladderPrice
              :model-value="modelValue"
              :config="config"
              :change="change"
              :ladder="ladder"
              :operation="operation"
            ></ladderPrice>
          </template>
        </kmjsModule>
        <div class="select-box">
          <div class="btn">
            <el-button size="small" @click="closeWindow()">取消</el-button>
            <el-button type="primary" size="small" @click="confirm">确定</el-button>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script lang="ts">
  import { defineComponent, PropType, ref, watch } from 'vue';
  import { useDialog } from '@/utils/hooks';
  import kmjsModule, { useModule } from '@/components/modules/module/code';
  import specification from '@/pages/libraryOfGoods/components/specification.vue';
  import ladderPrice from '@/pages/libraryOfGoods/components/ladderPrice.vue';
  import { SkusData, StepPricesStore, SpecsChilden } from '@/pages/libraryOfGoods/api';
  export default defineComponent({
    name: 'compile',
    components: {
      kmjsModule,
      specification,
      ladderPrice
    },
    props: {
      // 阶梯价
      ladder: {
        type: Array as PropType<StepPricesStore[]>,
        default: () => []
      },
      // 编辑数据
      compileData: {
        type: Object as PropType<SkusData>,
        required: true
      },
      clapList: {
        type: Array as PropType<SpecsChilden[]>,
        default: () => []
      },
      // 编辑or新增 false:新增 true：编辑
      operation: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      // 更新数据到表单的整体数据中
      change: {
        type: Function as PropType<(data: SkusData[]) => void>,
        required: true
      }
    },
    setup(props, { emit }) {
      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        if (v) {
          if (props.operation) {
            isSelect.value = props.compileData.name;
          } else {
            isSelect.value = '';
          }
        }
      });
      // 是否已加载过该表单name=$ready
      const isReady = ref(false);
      const isSelect = ref('');
      // 弹窗
      const dialogVisible = ref(false);
      // 编辑的数据
      const confirm = () => {
        methods['/title-form/getData']().then((res: { [l: string]: any }) => {
          if (res) {
            console.log(res, 'isSelect.value');
            if (res.name.specIndexes) {
              res.specIndexes = res.name.specIndexes;
              res.name = res.name.name;
            } else {
              if (props.compileData.specIndexes) {
                res.specIndexes = props.compileData.specIndexes;
                res.name = props.compileData.name;
              }
            }

            closeWindow();
            emit('confirm', res);
          }
        });
      };
      // 选择规格
      const selectSpecification = () => {
        dialogVisible.value = true;
      };
      // 点击确定返回数据
      const onConfirm = (val: string) => {
        isSelect.value = val;
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'form',
            name: 'title-form',
            permissions: [],
            params: {
              parentConfig: {
                labelWidth: '150px',
                labelPosition: 'right',
                dictionary: ['company_qualification'],
                showBtn: false
              },
              itemData: [
                {
                  label: '规格',
                  type: 'slot',
                  key: 'name',
                  slotName: 'from-specification',
                  validNames: ['required'],
                  defaultValue: ''
                },
                {
                  label: '型号',
                  type: 'text',
                  disabled: false,
                  key: 'model',
                  defaultValue: '',
                  validNames: ['required']
                },
                {
                  label: '建议零售价',
                  type: 'number',
                  disabled: false,
                  key: 'retailPrice',
                  defaultValue: '',
                  validNames: ['required'],
                  attr: { min: 0 }
                },
                {
                  label: '零售价',
                  type: 'number',
                  disabled: false,
                  key: 'price',
                  defaultValue: '',
                  validNames: ['required'],
                  attr: { min: 0 }
                },
                {
                  label: '重量',
                  type: 'number',
                  disabled: false,
                  key: 'weight',
                  defaultValue: '',
                  validNames: ['required'],
                  params: {
                    unit: 'kg'
                  },
                  attr: { min: 0 }
                },
                {
                  label: '体积',
                  type: 'number',
                  disabled: false,
                  key: 'volume',
                  defaultValue: '',
                  validNames: ['required'],
                  params: {
                    unit: 'cm³'
                  },
                  attr: { min: 0 }
                },
                {
                  label: '预览图',
                  disabled: false,
                  type: 'uploadImg',
                  key: 'icon',
                  defaultValue: '',
                  width: 1,
                  validNames: ['required'],
                  uploadConfig: {
                    limit: 1
                  }
                },
                {
                  label: '阶梯价',
                  type: 'slot',
                  key: 'stepPrices',
                  slotName: 'from-data',
                  validNames: ['required'],
                  defaultValue: []
                }
              ]
            },
            slotParam: [
              {
                name: 'from-specification',
                slotName: 'from-specification'
              },
              {
                name: 'from-data',
                slotName: 'from-data'
              }
            ]
          }
        ],
        params: {
          '/title-form': {
            valid: {
              name: [
                {
                  trigger: 'change',
                  validator: (rule: any, value: any, callback: (err?: Error) => void) => {
                    if (value == undefined) {
                      return callback(new Error('请选择规格'));
                    }
                    return callback();
                  }
                }
              ]
            }
          }
        },
        handler: (moduleName, name) => {
          // 编辑回显第一次编辑回显
          if (name === '$ready') {
            isReady.value = true;
            methods['/title-form/setData'](props.compileData);
          }
        }
      });
      // 编辑时数据回显
      watch(
        () => props.modelValue,
        () => {
          // 是否已经加载完毕表单
          if (isReady.value) {
            // 是编辑就回显
            if (props.operation) {
              methods['/title-form/setData'](props.compileData);
            }
          }
          if (!showDialog.value) {
            methods['/title-form/reset']();
          }
        },
        {
          deep: true
        }
      );
      return {
        moduleCtl,
        showDialog,
        isSelect,
        dialogVisible,
        closeWindow,
        confirm,
        selectSpecification,
        onConfirm
      };
    }
  });
</script>
<style lang="less" scoped>
  /deep/.el-dialog {
    min-width: 772px !important;
  }
  .standard {
    display: flex;
    align-items: center;
    /deep/.el-input--medium {
      max-width: 500px;
      margin-right: 10px;
    }
  }
  .select-box {
    margin-bottom: 20px;
    .btn {
      padding-bottom: 20px;
      float: right;
    }
  }
</style>
