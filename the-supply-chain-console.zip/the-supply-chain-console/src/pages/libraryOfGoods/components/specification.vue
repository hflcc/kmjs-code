<template>
  <el-dialog v-model="showDialog" title="选择规格" width="50%" @close="closeWindow">
    <div class="choice-box">
      <el-table ref="multipleTable" type="index" border :data="clapList" @select="select">
        <el-table-column type="selection" width="180" align="center"></el-table-column>

        <el-table-column prop="name" align="center" label="规格">
          <template #default="scope">
            <div>{{ scope.row.mixName ? scope.row.mixName : scope.row.name }}</div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取消</el-button>
        <el-button type="primary" @click="confirm">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script lang="ts">
  import { defineComponent, PropType, ref } from 'vue';
  import { SkusData, SpecsChilden } from '@/pages/libraryOfGoods/api';
  import { ElTable } from 'element-plus';
  import { useDialog } from '@/utils';

  export default defineComponent({
    components: {
      ElTable
    },
    props: {
      // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
      modelValue: {
        type: String as PropType<string>,
        default: ''
      },
      // 编辑数据
      compileData: {
        type: Object as PropType<SkusData>,
        required: true
      },
      clapList: {
        type: Array as PropType<SpecsChilden[]>,
        default: () => []
      },
      // 是否为新增
      operation: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      // 当前表单项的配置信息
      config: {
        type: Object as PropType<Record<string, any>>
      },
      // 更新数据到表单的整体数据中
      change: {
        type: Function as PropType<(data: { name: string; specIndexes: [] }) => void>,
        required: true
      }
    },
    setup(props, { emit }) {
      // 展示选中规格数据
      const isSelect = ref('');
      const specIndexes: any = ref([]);
      const multipleTable = ref(ElTable);
      // 控制是否禁用
      const isDisabled = ref(false);
      // 绑定选择的规格(绑定到children下面的index值，index值是唯一)
      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        if (v) {
          console.log(props.compileData.specIndexes, 'props.compileData.specIndexes');
        }
      });
      // 选中的数据
      const select = (selection: any) => {
        if (selection.length > 1) {
          let del_row = selection.shift();
          console.log(del_row, 'del_row');
          // 用于多选表格，切换某一行的选中状态，如果使用了第二个参数，则是设置这一行选中与否（selected 为 true 则选中）
          multipleTable?.value?.toggleRowSelection(del_row, false);
        }
        isSelect.value = selection[0].mixName ? selection[0].mixName : selection[0].name;
        specIndexes.value = [selection[0].index];
      };
      // 确定选择规格
      const confirm = () => {
        props.change({ name: isSelect.value, specIndexes: specIndexes.value });
        closeWindow();
        emit('confirm', isSelect.value);
      };
      return {
        isSelect,
        isDisabled,
        showDialog,
        multipleTable,
        confirm,
        closeWindow,
        select
      };
    }
  });
</script>
<style lang="less" scoped>
  // 选择规格弹窗
  .choice-box {
    max-height: 500px;
    overflow-y: scroll;
    .choice-content {
      margin-bottom: 10px;
      .choice-name {
        margin-bottom: 10px;
      }
      .choice-radio {
        margin-left: 20px;
        display: flex;
        /deep/ .el-checkbox-group {
          margin-right: 10px;
          margin-bottom: 10px;
        }
      }
    }
  }
  /deep/.el-table__header .el-table-column--selection {
    &::before {
      content: '选择';
    }
    .cell {
      display: none;
    }
  }
</style>
