<template>
  <div class="page" style="padding-top: 20px">
    <kmjsModule :ctl="moduleCtl"></kmjsModule>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import kmjsModule, { useModule } from '@/components/modules/module';
  import { ElMessage, ElMessageBox } from 'element-plus';
  import { deleteGoods } from '@/pages/libraryOfGoods/api';

  type Fn = () => void;
  interface Methods {
    [propName: string]: Fn;
  }
  interface Handlers {
    [propName: string]: (v: any[], methods: Methods) => void;
  }
  interface TableRow {
    sn: string;
    supplierName: string;
    brandName: string;
    goodsBrandTypeName: string;
    name: string;
    code: string;
    desc: string;
    createdByName: string;
    createdAt: number;
  }
  export default defineComponent({
    name: 'libraryOfGoodsIndex',
    components: {
      kmjsModule
    },
    setup() {
      const handlers: Handlers = {
        // 删除
        tableDeleData: async (list, methods) => {
          let sn: any = [];
          ElMessageBox.confirm('确认删除吗？')
            .then(async () => {
              if (list[0].length) {
                list[0].map((i: any) => {
                  sn.push(i.sn);
                });
              } else {
                sn.push(list[0].row.sn);
              }

              deleteGoods(sn).then((res) => {
                if (res.success) {
                  ElMessage.success('删除成功');
                  methods['/title/title-table/refreshAll']();
                } else {
                  ElMessage.error('删除失败');
                }
              });
            })
            .catch((err) => {
              console.log(err);
            });
        }
      };
      const [moduleCtl, methods] = useModule({
        config: [
          {
            type: 'wrap-module',
            name: 'title',
            params: {
              hideBack: true,
              title: '商品库管理',
              actions: [
                {
                  type: 'refresh',
                  emit: 'refresh'
                },
                {
                  label: '新增',
                  emit: 'createForm',
                  type: 'primary',
                  params: {
                    // 配置项
                    defSn: '3c7b0646064a4d9ba390b8663674f520'
                  }
                }
              ]
            },
            permissions: [],
            children: [
              {
                type: 'table',
                name: 'title-table',
                permissions: [],
                params: {
                  tableDataUrl: '/auth/md/goods/page',
                  items: [
                    {
                      type: 'search',
                      inputs: [
                        {
                          label: '商品名称',
                          key: 'goodsName',
                          type: 'text'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName',
                          type: 'text'
                        },
                        {
                          label: '供应商名称',
                          key: 'supplierName',
                          type: 'text'
                        },
                        {
                          label: '商品类型',
                          key: 'goodsBrandType',
                          type: 'select',
                          dictionaryName: 'goods_brand_type'
                        },
                        {
                          label: '编号',
                          key: 'code',
                          type: 'text'
                        },
                        {
                          label: '创建人',
                          key: 'createBy',
                          type: 'text'
                        },

                        {
                          label: '创建时间',
                          key: 'daterange',
                          type: 'daterange',
                          dateConfig: {
                            startKey: 'startAt',
                            endKey: 'endAt'
                          }
                        }
                      ]
                    },
                    {
                      type: 'table',
                      tableHead: [
                        {
                          label: '商品编号',
                          key: 'code'
                        },
                        {
                          label: '商品名称',
                          key: 'name'
                        },
                        {
                          label: '商品类型',
                          key: 'goodsBrandTypeName'
                        },
                        {
                          label: '品牌名称',
                          key: 'brandName'
                        },
                        {
                          label: '供应商名称',
                          key: 'supplierName'
                        },
                        {
                          label: '创建人',
                          key: 'createByName'
                        },
                        {
                          label: '创建时间',
                          key: 'createdAt',
                          formatter: 'dateTime',
                          width: 180,
                          params: {
                            dataTimeType: 'YYYY/MM/DD HH:mm:ss'
                          }
                        },
                        {
                          label: '备注',
                          key: 'desc',
                          width: 300
                        },
                        {
                          type: 'handle',
                          label: '操作',
                          actions: [
                            {
                              type: 'tableDetail',
                              label: '详情',
                              emit: 'supplierDetail',
                              params: {
                                defSn: '5a4b583a930e4e7da2f0d633818bf8c3',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              type: 'tableEdit',
                              label: '编辑',
                              emit: 'supplierEdit',
                              params: {
                                defSn: '1c16440343f7413cbaa34ff9c44d30ee',
                                dataSnKey: 'sn'
                              }
                            },
                            {
                              label: '删除',
                              emit: 'deleData'
                            }
                          ]
                        }
                      ],
                      actions: [
                        {
                          label: '删除',
                          emit: 'deleData'
                        }
                      ]
                    }
                  ]
                },
                slotParam: []
              }
            ]
          }
        ],
        handler: (moduleName, name, data) => {
          handlers[name] && handlers[name](data, methods);
        }
      });
      return {
        moduleCtl
      };
    }
  });
</script>

<style lang="less"></style>
