import ajax from '@/utils/axios';

// 规格
export interface SpecsStore {
  // 规格索引，请求方自行维护，不可重复，用于识别规格与SKU的关联关系，建议每新增一个规格自增一次即可
  index: number;
  // 规格名
  name: string;
  select?: string[];
  // 规格值
  children?: SpecsChilden[];
}
export interface SpecsChilden {
  index: number;
  // 规格名
  name: string;
  // sn
  sn?: string;
  // 是否删除
  isDelete?: boolean;
  // 规格名
  mixName?: string;
  // 规格值
  children?: SpecsChilden[];
}
// sku
export interface SkusData {
  name: string;
  model: string;
  retailPrice: string;
  price: string;
  weight: string;
  volume: string;
  icon: string;
  stepPrices: StepPricesList[];
  specIndexes: string;
}

// 阶梯价
export interface StepPricesStore {
  // 起始量
  min: string;
  // 结束量
  max: string;
  sn?: string;
}
// 阶梯价
export interface StepPricesList {
  // 起始量
  min: string;
  // 结束量
  max: string;
  // 售价（元）
  price?: string;
  sn?: string;
}
export interface BaseResp {
  success: boolean;
  message: string;
}
// 删除客服中心
export const deleteGoods = (sns: string[]): Promise<BaseResp> => {
  return ajax.delete<null, BaseResp>(`/auth/md/goods/${sns}`, {
    params: {
      $InstId: true
    }
  });
};
