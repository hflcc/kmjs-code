<!--<template>-->
<!--  <div class="page" style="padding-top: 20px">-->
<!--    <kmjs-table :ctl="tableCtl" :params="tableJSON" />-->
<!--    &lt;!&ndash; 规格弹窗 &ndash;&gt;-->
<!--    <newSpecification v-model="showNewSpecification"></newSpecification>-->
<!--    &lt;!&ndash; sku弹窗 &ndash;&gt;-->
<!--    <compile v-model="showNewProperty" :ladder="ladder" @on-confirm="getCompile"></compile>-->
<!--    &lt;!&ndash; 阶梯设置 &ndash;&gt;-->
<!--    <tieredPricing v-model="showTieredPricing"></tieredPricing>-->
<!--  </div>-->
<!--</template>-->
<!--<script lang="ts">-->
<!--  import { defineComponent, nextTick, ref } from 'vue';-->
<!--  import kmjsTable, { useTable } from '@/components/table/code';-->
<!--  import newSpecification from '@/pages/libraryOfGoods/components/newSpecification.vue';-->
<!--  import compile from '@/pages/libraryOfGoods/components/compile.vue';-->
<!--  import tieredPricing from '@/pages/libraryOfGoods/components/tieredPricing.vue';-->
<!--  import { StepPricesStore } from '@/pages/libraryOfGoods/api';-->
<!--  import { useStore } from 'vuex';-->
<!--  import { ElMessageBox } from 'element-plus';-->

<!--  export default defineComponent({-->
<!--    name: 'form-module-item-spec_price',-->
<!--    components: {-->
<!--      kmjsTable,-->
<!--      newSpecification,-->
<!--      compile,-->
<!--      tieredPricing-->
<!--    },-->
<!--    setup() {-->
<!--      const showNewProperty = ref(false);-->
<!--      const showNewSpecification = ref(false);-->
<!--      const showTieredPricing = ref(false);-->
<!--      const store = useStore<RootState>();-->
<!--      const ladder = ref<StepPricesStore[]>([]);-->
<!--      const getCompile = (data: StepPricesStore[]) => {-->
<!--        console.log(data, 111111);-->
<!--        nextTick(() => {-->
<!--          tableMethods.setTableData([data]);-->
<!--        });-->
<!--      };-->
<!--      const tableJSON = {-->
<!--        tableDataUrl: '',-->
<!--        items: [-->
<!--          {-->
<!--            type: 'title',-->
<!--            title: '规格及售价',-->
<!--            actions: [-->
<!--              {-->
<!--                label: '新增规格',-->
<!--                emit: 'newSpecification'-->
<!--              },-->
<!--              {-->
<!--                label: '新增sku',-->
<!--                emit: 'newCompile'-->
<!--              },-->
<!--              {-->
<!--                label: '阶梯设置',-->
<!--                emit: 'stairSet'-->
<!--              }-->
<!--            ]-->
<!--          },-->
<!--          {-->
<!--            type: 'table',-->
<!--            tableHead: [-->
<!--              {-->
<!--                label: '规格',-->
<!--                key: 'name'-->
<!--              },-->
<!--              {-->
<!--                label: '型号',-->
<!--                key: 'model'-->
<!--              },-->
<!--              {-->
<!--                label: '预览图',-->
<!--                key: 'icon',-->
<!--                type: 'image',-->
<!--                width: 80-->
<!--              },-->
<!--              {-->
<!--                label: '建议零售价(元)',-->
<!--                key: 'retailPrice'-->
<!--              },-->
<!--              {-->
<!--                label: '零售价(元)',-->
<!--                key: 'price'-->
<!--              },-->
<!--              {-->
<!--                label: '重量(kg)',-->
<!--                key: 'weight'-->
<!--              },-->
<!--              {-->
<!--                label: '体积(cm²)',-->
<!--                key: 'volume'-->
<!--              },-->
<!--              {-->
<!--                label: '阶梯售价',-->
<!--                key: 'stepPrices'-->
<!--              },-->
<!--              {-->
<!--                type: 'handle',-->
<!--                label: '操作',-->
<!--                actions: [-->
<!--                  {-->
<!--                    type: 'tableDetail',-->
<!--                    label: '',-->
<!--                    emit: 'supplierDetail'-->
<!--                  },-->
<!--                  {-->
<!--                    type: 'tableBpm',-->
<!--                    label: '删除',-->
<!--                    emit: 'supplierEdit'-->
<!--                  },-->
<!--                  {-->
<!--                    type: 'moveUp',-->
<!--                    label: '上移',-->
<!--                    emit: 'moveUp'-->
<!--                  },-->
<!--                  {-->
<!--                    type: 'moveDown',-->
<!--                    label: '下移',-->
<!--                    emit: 'moveDown'-->
<!--                  }-->
<!--                ]-->
<!--              }-->
<!--            ]-->
<!--          }-->
<!--        ]-->
<!--      };-->
<!--      const [tableCtl, tableMethods] = useTable({-->
<!--        tableHandler: (name, data) => {-->
<!--          console.log(name, 'name');-->
<!--          switch (name) {-->
<!--            // 新增规格-->
<!--            case 'titleNewSpecification':-->
<!--              showNewSpecification.value = true;-->
<!--              break;-->
<!--            // 新增sku-->
<!--            case 'titleNewCompile':-->
<!--              console.log();-->
<!--              if (!store.state.goods.specs.length) {-->
<!--                ElMessageBox.alert('请先设置规格');-->
<!--                return;-->
<!--              }-->
<!--              ladder.value = store.state.goods.tiered;-->
<!--              showNewProperty.value = true;-->
<!--              break;-->
<!--            // 阶梯设置-->
<!--            case 'titleStairSet':-->
<!--              showTieredPricing.value = true;-->
<!--              break;-->
<!--          }-->
<!--        }-->
<!--      });-->
<!--      return {-->
<!--        tableCtl,-->
<!--        tableJSON,-->
<!--        showNewSpecification,-->
<!--        showNewProperty,-->
<!--        showTieredPricing,-->
<!--        ladder,-->
<!--        getCompile-->
<!--      };-->
<!--    }-->
<!--  });-->
<!--</script>-->
<!--<style lang="less" scoped>-->
<!--  /deep/.el-table td div {-->
<!--    white-space: pre-wrap;-->
<!--  }-->
<!--</style>-->
