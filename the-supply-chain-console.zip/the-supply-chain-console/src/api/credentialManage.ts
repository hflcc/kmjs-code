import ajax from '@/utils/axios';

/*
 * 删除证件api
 * */
export const delCertificate = (sn: string) => {
  return ajax.delete(`/auth/md/qualification/instance/${sn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 批量删除证件
 */
export function delBatchCertificate(sns: string[]): Promise<{ success: boolean }> {
  return ajax.delete<{ sns: string[] }, { success: boolean }>(
    `/auth/md/qualification/instance/batch/${sns}`,
    {
      params: {
        $InstId: true
      }
    }
  );
}
