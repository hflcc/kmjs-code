import ajax, { file } from '@/utils/axios';

/*

 * 订单发货api

 * */

export const orderDeliveryAPI = (sn: string, data: { deliverType: string; billSn: string }) => {
  return ajax.put(`/auth/ec/order/delivery/${sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/*

 * 订单详情api

 * */

export const orderDetailAPI = (sn: string) => {
  return ajax.get(`/auth/ec/platform/order/${sn}`, {
    params: {
      $InstId: true
    }
  });
};

/*

 * 订单导出 全部/批量api

 * */

export const orderExportAPI = (data: string, orgTreeSn: string | undefined) => {
  return file(`/auth/ec/provider/order/export/${orgTreeSn}${data && '?' + data}`, {
    responseType: 'arraybuffer',

    params: {
      $InstId: true
    }
  });
};

/*

 * 获取物流信息

 * */

export const getTransInfoAPI = (billSn: string) => {
  return ajax.get(`/auth/ec/deliver/search/${billSn}`, {
    params: {
      $InstId: true
    }
  });
};

/*

 * 根据地址areaSn获取详细地址信息

 * */

export const getAreaWithSn = (areaSn: string) => {
  return ajax.get(`/auth/md/common/area/def/item/${areaSn}`, {
    params: {
      $InstId: true
    }
  });
};
