import ajax from '@/utils/axios';

/*
 * 修改店铺状态api
 * */
export const operateShopStateAPI = (sn: string, type: string) => {
  return ajax.put(`/auth/md/platform/shop/operate/${sn}/${type}`, undefined, {
    params: {
      $InstId: true
    }
  });
};

/*
 * 根据店铺sn修改店铺信息
 * */
export const modifyShopInfoAPI = (sn: string, data: { [index: string]: any }) => {
  return ajax.put(`/auth/md/platform/shop/${sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/*
 * 订单发货api
 * */
export const getShopDetailAPI = (sn: string) => {
  return ajax.get(`/auth/md/platform/shop/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
