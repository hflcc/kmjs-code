<template>
  <el-upload
    class="upload-demo"
    accept="image/*"
    :action="uploadUrl"
    :data="uploadData"
    :on-remove="handleRemove"
    :on-success="success"
    :file-list="fileList"
    :limit="limit"
    list-type="picture"
  >
    <el-button v-show="fileList < limit" size="small" type="primary">点击上传</el-button>
    <template #tip>
      <div class="el-upload__tip">图片尺寸建议宽750*高600PX</div>
    </template>
  </el-upload>
</template>

<script lang="ts">
  import { defineComponent, PropType, ref, watch } from 'vue';
  import { getImageUrlBySeq } from '@/utils/commApi';

  interface IFileListItem {
    seq?: string;
    url: string;
  }

  export default defineComponent({
    name: 'component-upload-img',
    props: {
      modelValue: {
        type: String as PropType<string>,
        default: ''
      },
      limit: {
        type: Number as PropType<number>,
        default: 1
      }
    },
    setup(props, { emit }) {
      const uploadUrl = process.env.VUE_APP_AXIOS_BASE_URL + '/auth/oss/upload/file';
      const uploadData = { dirName: 'kmjs' };
      const fileList = ref<IFileListItem[]>([]);
      const change = () => {
        emit('update:modelValue', fileList.value.map((v) => v.seq).join(','));
      };
      const getUrl = async (seqs: string) => {
        const res = await getImageUrlBySeq(seqs);
        if (res) {
          seqs.split(',').forEach((v: string) => {
            const item = res[v];
            fileList.value.push({
              seq: item.seq,
              url: item.url
            });
          });
        }
      };
      watch(
        () => props.modelValue,
        () => {
          if (props.modelValue === fileList.value.map((v) => v.seq).join(',')) return;
          if (props.modelValue === '') {
            fileList.value = [];
            return;
          }
          getUrl(props.modelValue).then();
        },
        {
          immediate: true
        }
      );
      /**
       * 删除文件
       * */
      const handleRemove = (file: IFileListItem, fls: IFileListItem[]) => {
        fileList.value = fls.map((v) => {
          return {
            seq: v.seq,
            url: v.url
          };
        });
        change();
      };
      const success = (res: any, file: IFileListItem, fls: IFileListItem[]) => {
        fileList.value = fls.map((v) => {
          return {
            seq: res.seq,
            url: v.url
          };
        });
        change();
      };
      return {
        uploadUrl,
        success,
        uploadData,
        handleRemove,
        fileList
      };
    }
  });
</script>
<style lang="less"></style>
