<template>
  <div :class="['kmjs-quick-content', border ? 'border' : '']">
    <h3 class="quick__title">{{ title }}</h3>
    <!-- 一级单选 -->
    <el-radio-group
      v-model="currentRadio"
      size="medium"
      style="margin-bottom: 10px"
      @change="radioChange"
    >
      <el-radio-button
        v-for="(item, index) in quickProcess.institutions"
        :key="index"
        :label="item.instInstSn"
      >
        {{ item.typeInstName }}
      </el-radio-button>
    </el-radio-group>

    <!-- 二级tab -->
    <el-tabs v-model="currentTab" @tab-click="tabChange">
      <el-tab-pane
        style="margin-top: 10px"
        v-for="item in quickProcess.organizations"
        :key="item.sn"
        :name="item.sn"
        :label="item.name"
        lazy
      >
        <el-descriptions :column="column">
          <el-descriptions-item v-for="(item, index) in quickProcess.items" :key="index">
            <div class="quick__content" @click="itemClick(item.value)">
              <img class="quick__icon" :src="item.icon" />
              <span class="quick__text">{{ item.title }}</span>
            </div>
          </el-descriptions-item>
        </el-descriptions>
      </el-tab-pane>
    </el-tabs>

    <el-empty v-show="!hasData" :image-size="100" :description="description" />
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref, computed, watchEffect, reactive, onMounted } from 'vue';
  import { isEmpty } from '@/utils/valid';
  import {
    QuickContentData,
    getInstitutions,
    getOrganizations,
    getBpmListByType
  } from '@/components/quickContent/api';

  import type { PropType } from 'vue';
  import { useStore } from 'vuex';

  let tabIndex: number | string = ''; // tab index

  interface TTab {
    active: boolean;
    index: number | string;
    paneName: string;
  }

  export default defineComponent({
    name: 'kmjs-quick-content',
    props: {
      title: {
        type: String as PropType<string>,
        default: ''
      },
      column: {
        type: Number as PropType<number>,
        default: 4
      },
      border: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      bpmType: {
        type: String as PropType<string>,
        default: ''
      }
    },
    emits: ['item-click'],
    setup(props, { emit }) {
      const store = useStore();
      const quickProcess = reactive<QuickContentData>({
        items: [],
        institutions: [],
        organizations: []
      });

      const hasData = computed(() => quickProcess.items.length !== 0);
      const description = computed(() => (!hasData.value ? `暂无${props.title}` : ''));

      /**
       * 获取组织列表
       */
      async function getOrganizationList(instInstSn: string) {
        const organizations = await getOrganizations(instInstSn);
        quickProcess.organizations = [];
        if (organizations && organizations.length) {
          organizations.forEach(({ sn, name, instSn }) => {
            quickProcess.organizations?.push({
              sn,
              name,
              instSn
            });
          });
          await getOrgResourceList(organizations[0].sn);
        }
      }

      /**
       * 获取组织下面的资源
       */
      async function getOrgResourceList(sn: string) {
        const instSn = quickProcess.organizations?.find((s) => s.sn === sn)?.instSn ?? '';
        const resources = await getBpmListByType(instSn, sn, props.bpmType);
        quickProcess.items = [];
        if (resources && resources.length) {
          // 预处理icon
          const _iconList = resources.map((item) => item.icon);
          const _ossObj = await getImagesUrl(_iconList);
          resources.forEach(({ icon, title, sn }) => {
            quickProcess.items.push({
              icon: (!isEmpty(_ossObj) && _ossObj[icon].url) || '',
              value: sn,
              title: title,
              isProcess: true
            });
          });
        }
      }

      /**
       * 通过图片sn批量拉取图片地址
       * @param seqs 通过图片sn
       */
      async function getImagesUrl(seqs: string[]) {
        const imgs = await store.dispatch('source/getOssUrl', seqs);
        return imgs || '';
      }

      async function initData() {
        // 获取当前平台绑定的机构列表
        const institutions = await getInstitutions();
        institutions.length &&
          institutions.forEach(({ instInstSn, typeInstName }) => {
            quickProcess.institutions?.push({
              instInstSn,
              typeInstName
            });
          });

        institutions.length && (await getOrganizationList(institutions[0].instInstSn));
      }

      // 选择机构
      const currentRadio = ref<string | undefined | number>('');

      function radioChange(value: string) {
        tabIndex = '';
        getOrganizationList(value);
      }

      // 机构下面的组织
      const currentTab = ref<string | undefined | number>('');

      function tabChange(tab: TTab) {
        if (tabIndex === tab.index) return;
        tabIndex = tab.index;
        getOrgResourceList(tab.paneName);
      }

      // 点击某一项快捷方式
      function itemClick(value: string) {
        emit('item-click', value);
      }

      watchEffect(() => {
        currentRadio.value =
          quickProcess.institutions?.length && quickProcess.institutions[0].instInstSn;
      });
      watchEffect(() => {
        currentTab.value =
          (quickProcess.organizations?.length && quickProcess.organizations[0].sn) || '';
      });

      onMounted(async () => {
        await initData();
      });

      return {
        currentRadio,
        currentTab,
        radioChange,
        itemClick,
        tabChange,
        hasData,
        description,
        quickProcess
      };
    }
  });
</script>

<style lang="less">
  .kmjs-quick-content {
    &.border {
      border: 1px solid #ddd;
    }

    padding: 20px;
    margin-bottom: 30px;

    .quick {
      &__title {
        font-weight: 700;
        margin-bottom: 20px;
      }

      &__content {
        padding-bottom: 10px;
        display: inline-block;
        cursor: pointer;
      }

      &__icon {
        display: inline-block;
        vertical-align: middle;
        width: 30px;
      }

      &__text {
        margin-left: 12px;
        display: inline-block;
        vertical-align: middle;
      }
    }
  }
</style>
