import ajax from '@/utils/axios';

export interface QuickContentData {
  // 机构
  institutions?: Array<{ instInstSn: string; typeInstName: string }>;
  // 组织
  organizations?: Array<{ name: string; sn: string; instSn: string; content?: string }>;
  // 列表数据
  items: Array<{ icon: string; value: string; title: string; isProcess?: boolean }>;

  [propName: string]: any;
}

interface TInstitutions {
  bizMdInstName: string;
  bizMdInstSn: string;
  instInstSn: string;
  state: string;
  typeInstName: string;
  typeInstSn: string;
}

interface TOrganizations {
  instName: string;
  instSn: string;
  name: string;
  sn: string;
  sort: number;
  type: string;
}

interface TOrgResources {
  icon: string;
  title: string;
  sn: string;
  scopeName: string;
  scopeSn: string;
}

/**
 * 当前机构绑定的平台机构列表
 * @param state 机构状态[normal正常][disabled停用]
 */
export const getInstitutions = (state?: string) => {
  return ajax.get<{ state: string }, Array<TInstitutions>>('/auth/md/inst/associate/inst_id/list', {
    params: {
      $InstId: true,
      state
    }
  });
};

/**
 * 获取当前app绑定的组织(机构)
 * @param instInstSn 所选机构sn
 * @param type 固定 `bpm`
 */
export const getOrganizations = (instInstSn: string, type = 'bpm') => {
  return ajax.get<null, Array<TOrganizations>>(`/auth/md/inst/org/current/${instInstSn}/${type}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 获取具体的流程
 * */
export const getBpmListByType = (instSn: string, orgSn: string, type = '') => {
  const url = type
    ? `/auth/bpm/def/${instSn}/${orgSn}/${type}`
    : `/auth/bpm/def/${instSn}/${orgSn}`;
  return ajax.get<null, Array<TOrgResources>>(url, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 获取指定机构中指定资源类型的数据
 * @param orgSn 组织sn
 * @param scope 作用类型 固定 `bpm`
 */
export const getOrgResources = (orgSn: string, scope = 'bpm') => {
  return ajax.get<null, Array<TOrgResources>>(
    `/auth/md/inst/org/tree/resource/list/org/${orgSn}/${scope}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};
