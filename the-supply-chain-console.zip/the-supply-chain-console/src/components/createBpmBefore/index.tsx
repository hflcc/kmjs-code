import { defineComponent, PropType } from 'vue';
import { useDialog } from '@/utils';
import quickContent from '@/components/quickContent/index.vue';

export default defineComponent({
  name: 'kmjs-create-bpm-before',
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    bpmType: {
      type: String as PropType<string>,
      default: ''
    }
  },
  components: {
    quickContent
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit }) {
    const { showDialog, closeWindow } = useDialog(props, emit);
    const getClickItem = (value: string) => {
      emit('getValue', value);
    };
    return () => {
      return (
        <el-dialog
          width={'80vw'}
          v-model={showDialog.value}
          destroy-on-close
          onClose={closeWindow}
          v-slots={{
            footer: () => {
              return <el-button onClick={closeWindow}>取消</el-button>;
            }
          }}
        >
          <quickContent onItemClick={getClickItem} bpmType={props.bpmType}></quickContent>
        </el-dialog>
      );
    };
  }
});
