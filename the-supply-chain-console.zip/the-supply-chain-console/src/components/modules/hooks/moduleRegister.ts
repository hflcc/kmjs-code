/**
 * 注册模块，主要是对外注册该组件内方法调用,以及接收外部的一些回调函数
 * */
import { inject, provide, computed, ref, Ref, UnwrapRef } from 'vue';
import { ComputedRef } from '@vue/reactivity';

interface ResisterModule<T> {
  emitHandler: (name: string, ...data: any[]) => void;
  params: ComputedRef<T>;
  emitOn: ((name: string, callBack: () => void) => void) | undefined;
  trigger: ((name: string, data?: any) => void) | undefined;
  permission: Ref<UnwrapRef<{ [moduleName: string]: string }>> | undefined;
  formModuleEvents: FormModuleEvents | null;
}

export const resisterModule = function <T, S>(moduleName: string, methods: S): ResisterModule<T> {
  const emitOn = inject<(name: string, callBack: () => void) => void>('eventOn');
  const trigger = inject<(name: string, data?: any) => void>('eventEmit');
  const permission = inject<Ref<UnwrapRef<{ [moduleName: string]: string }>>>('permission');
  // 接收动态参数
  const moduleParams = inject<Ref<UnwrapRef<{ [moduleName: string]: T }>>>('moduleParams');
  // 触发方法
  const moduleHandler =
    inject<(moduleName: string, emitName: string, data: any[]) => void>('moduleHandler');
  // 注册外部调用方法
  const registerMethods = inject<(name: string, method: () => void) => void>('registerMethods');
  Object.keys(methods).forEach((v) => {
    registerMethods?.(moduleName + '/' + v, (methods as unknown as Record<string, () => void>)[v]);
    registerMethods?.(moduleName + '/' + 'getName', () => moduleName);
  });
  /**
   * 对外触发方法
   * */
  const emitHandler = (name: string, ...data: any[]) => {
    if (typeof moduleHandler === 'function') {
      moduleHandler(moduleName, name, data);
    }
  };

  /**
   * 接收个性化配置
   * */
  const params = computed<T>(() => (moduleParams?.value?.[moduleName] as T) || ({} as T));
  /**
   * 表单模块特有的交互方法
   * */
  const formModuleEvents = inject<FormModuleEvents | null>('formModuleEvents', null);
  return {
    emitHandler,
    params,
    emitOn,
    trigger,
    permission,
    formModuleEvents
  };
};

export const useModuleParent = (
  methods: Record<string, () => void>,
  handler?: (moduleName: string, name: string, data: any[]) => void,
  optionsParams?: Record<string, any>
) => {
  // 记录所有入参
  const params = ref<Record<string, any>>(optionsParams || {});
  const emitFun = (moduleName: string, name: string, data: any[]) => {
    handler?.(moduleName, name, data);
  };
  const registerMethods = (name: string, method: () => void) => {
    // 记录所有组件的对外方法，供外部调用
    methods[name] = method;
  };
  provide('moduleHandler', emitFun);
  provide('moduleParams', params);
  provide('registerMethods', registerMethods);
};
