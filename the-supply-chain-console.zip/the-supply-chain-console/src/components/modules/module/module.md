# 采用JSON配置化展示页面

基本配置项如下

```text
{
  // 保证唯一行，但是我不会去检查它
  name: string;
  // slot 使用slot进行渲染， 必须有slotName配置项
  type: 'wrap-module' | 'tab-module' | 'tab-module-item' | 'table' | 'form' | 'slot';
  // 每个组件的配置项
  params?: any;
  // 如果需要动态slot使用这个
  slotName?: string;
  // 子组件
  children?: ModuleItem[];
  // 当前组件的权限
  permissions?: [];
  // 组件内部的slot配置 比如table的search区域可以自定义搜索
  slotParam?: {
    // slot 的位置。会将该组件插入到模块的指定位置
    name: string;
    // 在全局的slots中寻找都寻找不到的话就不进行渲染
    slotName: string;
  }[];
}
```

主要逻辑在`loopBuild.tsx`中递归构建页面

一般是通过SN去后台获取SN， SN的值来自于当前`router.meta.propertyList.module_def`字段

后续新的组件加入到module中，需要引入 `hooks`下的 `moduleRegister.ts` 注册一下，主要是方便暴露接口和获取动态的配置项。

如果有需要在模块内的事件流动， 通过 `emitOn`监听和`trigger`触发（本质上就是一个发布-订阅）。

事件名称建议以$开头。 比如说在wrap的action中有一个刷新按钮 触发`trigger('$refresh')`， 在table中`emitOn('$refresh')`

# provide/ inject

> 以下四个均在 `../hooks/moduleRegister.ts`中返回了钩子方法

```text
// 对外的接口 
provide('moduleHandler', emitFun); 

// 外部对内的动态配置 
provide('moduleParams', params): Ref<UnwrapRef<{ [moduleName: string]: string }>>; 

// 注册外部可主动调用的接口方法
// 比如说表格有 refresh刷新接口方法
provide('registerMethods', registerMethods): (name: string, method: () => void) => void; 

// 当前用户在当前module中所包含的权限 
provide('permission', permission):Ref<UnwrapRef<{ [key: string]: string }>>; 
  {key: label}的形式
```

# 使用

```Vue

<template>
  <div class="page">
    <kmjsModuleTable :ctl="moduleCtl">
      <!-- 内部的一些具名的slot -->
      <template #slotData>
        <p>我是外部的slot</p>
      </template>
      <!-- 根据模块的特性，有些是具有解构的插槽 -->
      <template #valueTableSearch="{ submitData }">
        <p @click="submitData()">表格高级搜索</p>
      </template>
      <template #from-data>
        <p>{{ formData }}</p>
      </template>
    </kmjsModuleTable>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import kmjsModuleTable, { useModule } from '@/components/modules/module';

export default defineComponent({
  name: 'demo-table',
  components: {
    kmjsModuleTable
  },
  setup() {
    const formData = ref({});
    // 这里这样去使用有待考量，是否过于复杂
    const form: { [l: string]: (data: any[]) => void } = {
      submit: (data: any[]) => {
        formData.value = data[0];
      }
    };
    const [ moduleCtl, methods ] = useModule({
      params: {
        // 模块名称是所有层级的名称组合在一起
        '/title/tab-menu/value/title-table': {
          reqBody: {
            a: 1
          }
        }
      },
      handler: (moduleName, name, data) => {
        console.log(moduleName, name, data);
        switch (moduleName) {
          case '/title/tab-menu/value2/title-form':
            form[name](data);
        }
      }
    });
    // 主动调用指定表格的刷新方法
    methods['/title/tab-menu/value/title-table/refresh']()
    return {
      moduleCtl,
      formData
    };
  }
});
</script>
<style lang="less"></style>


```
