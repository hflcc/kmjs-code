import { ModuleItem } from '@/components/utils/commonType';

export interface ModuleConfig {
  params?: Record<string, any>;
  handler?: (moduleName: string, name: string, data: any[]) => void;
  config?: ModuleItem[];
}

export type ModuleCtl = () => [
  ModuleConfig,
  { [moduleName: string]: () => void },
  ModuleItem[] | undefined
];
export const useModule = function (
  params: ModuleConfig = {}
): [ctl: ModuleCtl, method: { [moduleName: string]: (...argus: any) => any }] {
  const method = {};
  const ctl = (): [
    ModuleConfig,
    { [moduleName: string]: () => void },
    ModuleItem[] | undefined
  ] => {
    return [params, method, params.config];
  };
  return [ctl, method];
};
