import { defineComponent, nextTick, PropType, provide, ref } from 'vue';
import { ModuleItem } from '@/components/utils/commonType';
import loopBuild from '@/components/modules/module/loopBuild';
import tab from '@/components/modules/components/tabs';
import kmjsWrapModule from '@/components/wrap/module';
import { ModuleConfig } from './useModule';
import { getModuleJSON } from '@/utils/commApi';
import { useRoute } from 'vue-router';
import { useModuleParent } from '@/components/modules/hooks/moduleRegister';
import empty from '@/assets/empty.svg';

export * from './useModule';
export default defineComponent({
  name: 'module-table',
  props: {
    ctl: {
      type: Function as PropType<() => [ModuleConfig, Record<string, () => void>]>,
      required: true
    }
  },
  components: {
    'kmjs-tab-module': tab,
    'kmjs-tab-module-item': tab.Item,
    'kmjs-wrap-module': kmjsWrapModule
  },
  setup(props) {
    const route = useRoute();
    const errMsg = ref('');
    const configSn = (route.meta.propertyList as { [l: string]: string })?.module_def;
    // 当前页面的所有权限
    const permission = ref<{ [key: string]: string }>({});
    // 整个模块的配置项
    const config = ref<ModuleItem[]>([]);
    // 记录所有组件的对外方法，供外部调用
    let methods: { [moduleMethodName: string]: () => void } = {};

    let options: ModuleConfig = {};
    if (typeof props.ctl === 'function') {
      [options, methods] = props.ctl();
    }
    useModuleParent(methods, options.handler, options.params);
    if (configSn) {
      getModuleJSON(configSn).then((res) => {
        if (res) {
          permission.value = res.actionList;
          try {
            config.value = JSON.parse(res.configJson);
            nextTick(() => {
              options.handler?.('', '$ready', []);
            });
          } catch (e) {
            console.log(e);
            errMsg.value = '配置文件载入错误， 请联系客服。';
          }
        }
      });
    }
    provide('permission', permission);
    return { config, errMsg };
  },
  render() {
    const { config, errMsg } = this;
    if (errMsg) {
      return (
        <div class="module-table-wrap page">
          <el-empty
            description={errMsg}
            v-slots={{
              image: () => {
                return <img src={empty} />;
              }
            }}
          ></el-empty>
        </div>
      );
    }
    return (
      <div class="module-table-wrap page">
        {config.map((v) => {
          return loopBuild(v, '', this.$slots);
        })}
      </div>
    );
  }
});
