/**
 * 本地模式模块配置
 * */
import { defineComponent, nextTick, PropType, provide, ref } from 'vue';
import { ModuleItem } from '@/components/utils/commonType';
import loopBuild from '@/components/modules/module/loopBuild';
import tab from '@/components/modules/components/tabs';
import kmjsWrapModule from '@/components/wrap/module';
import { ModuleConfig } from './useModule';

export * from './useModule';
export default defineComponent({
  name: 'module-table',
  props: {
    ctl: {
      type: Function as PropType<
        () => [ModuleConfig, { [moduleMethodName: string]: () => void }, ModuleItem[]]
      >,
      required: true
    }
  },
  components: {
    'kmjs-tab-module': tab,
    'kmjs-tab-module-item': tab.Item,
    'kmjs-wrap-module': kmjsWrapModule
  },
  setup(props) {
    // 当前页面的所有权限
    // const permission = ref<{ [key: string]: string }>({});
    // 整个模块的配置项
    const config = ref<ModuleItem[]>([]);
    // 记录所有入参
    const params = ref<{ [moduleName: string]: any }>({});
    // 记录所有组件的对外方法，供外部调用
    let methods: { [moduleMethodName: string]: () => void } = {};

    let options: ModuleConfig = {};
    if (typeof props.ctl === 'function') {
      [options, methods, config.value] = props.ctl();
    }
    params.value = options?.params || {};
    const emitFun = (moduleName: string, name: string, data: any[]) => {
      options.handler?.(moduleName, name, data);
    };
    const registerMethods = (name: string, method: () => void) => {
      methods[name] = method;
    };
    provide('moduleHandler', emitFun);
    provide('moduleParams', params);
    provide('registerMethods', registerMethods);
    // 本地编码模式 不做权限校验
    provide('permission', null);
    nextTick(() => {
      options.handler?.('', '$ready', []);
    });
    return { config };
  },
  render() {
    const { config } = this;
    return (
      <div class="module-table-wrap page">
        {config.map((v) => {
          return loopBuild(v, '', this.$slots);
        })}
      </div>
    );
  }
});
