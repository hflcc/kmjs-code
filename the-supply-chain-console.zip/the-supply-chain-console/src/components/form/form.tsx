import { defineComponent, inject, nextTick, PropType, provide, reactive, ref } from 'vue';
import { ElForm } from 'element-plus';
import {
  ParentConfig,
  FormItem,
  validItem,
  InputType,
  ValidCallBack,
  FormItemAction
} from '@/components/form/type';
import buildItem from '@/components/form/items';
import {
  playShowRule,
  getDataFromBusiness,
  getDataFromForm,
  useDateRule,
  useDictionary,
  useValid
} from '@/components/form/utils';
import { TagItem } from '@/components/utils/commonType';
import { formatterStrByObj, formatterTimer, getChainData } from '@/utils';
import { goToFormCreate } from '@/pages/commonPage';
import { useRouter } from 'vue-router';

export default defineComponent({
  name: 'formComponent',
  props: {
    itemData: {
      type: Array as PropType<FormItem[]>,
      require: true
    },
    parentConfig: {
      type: Object as PropType<ParentConfig>,
      require: true
    },
    formModuleEvents: {
      type: Object as PropType<FormModuleEvents>
    }
  },
  setup(props, ctx) {
    const router = useRouter();
    // 配合表单模块逻辑
    const tabKey = inject('tabKey', '');
    // 是否表格属性
    const tabGridDetail = inject<Record<string, FormatTabGridDetail>>('tabGridDetail', {});
    // 存储表单的配置项
    const options = ref(props.itemData as FormItem[]);
    // 表单的数据默认值 v-model="XXX"的XXX
    const defaultData: { [label: string]: any } = {};
    // 表单的数据  v-model="XXX"的XXX
    const formData = reactive<{ [label: string]: any }>({});
    // 表单的校验数据
    const validData = reactive<Record<string, validItem[]>>({});
    // el-form 的实例
    const formElem = ref<null | InstanceType<typeof ElForm>>(null);
    // 字典应用
    if (props.parentConfig?.dictionary && Array.isArray(props.parentConfig?.dictionary)) {
      useDictionary(props.parentConfig.dictionary, options.value);
    }
    // 各种规则应用
    options.value.forEach((v) => {
      // 设置日期可选择的区间控制
      useDateRule(v);
      // 应用校验规则
      useValid(v);
      // 对一些特殊类型进行数据转换
      if (typeof formData[v.key] === 'undefined' && v.type !== InputType.button) {
        if (
          (v.type === InputType.daterange || v.type === InputType.checkbox) &&
          !Array.isArray(v.defaultValue)
        ) {
          defaultData[v.key] = [];
          formData[v.key] = [];
        } else {
          defaultData[v.key] = v.defaultValue;
          formData[v.key] = v.defaultValue;
        }
        if (v.type === InputType.address && typeof v.defaultValue !== 'object') {
          defaultData[v.key] = { areaSn: '', address: '' };
          formData[v.key] = { areaSn: '', address: '' };
        }
        if (v.type === InputType.uploadFile || v.type === InputType.uploadImg) {
          defaultData[v.key] = [];
          formData[v.key] = [];
        }
      }
      if (v.valid) validData[v.key] = v.valid;
      if (v.linkageConfig?.sourceType === 'business') {
        getDataFromBusiness(v, formData, tabKey, props.formModuleEvents, true).then(() => {
          playShowRule(
            v.key,
            formData[v.key],
            options.value,
            formData,
            defaultData,
            true,
            tabGridDetail,
            tabKey,
            tabKey,
            props.formModuleEvents
          );
        });
      }
      if (v.linkageConfig?.sourceType === 'mapping') {
        getDataFromForm(
          v,
          formData,
          tabKey,
          props.formModuleEvents,
          tabGridDetail[tabKey]?.isGrid ?? false
        );
      }
      playShowRule(
        v.key,
        formData[v.key],
        options.value,
        formData,
        defaultData,
        true,
        tabGridDetail,
        tabKey,
        tabKey,
        props.formModuleEvents
      );
    });
    provide('setValidRule', (name: string, validCallBakc: ValidCallBack) => {
      if (Array.isArray(validData[name])) {
        validData[name].unshift({
          validator: validCallBakc,
          trigger: 'change'
        });
      } else {
        validData[name] = [
          {
            validator: validCallBakc,
            trigger: 'change'
          }
        ];
      }
    });
    // 为表格的搜索做服务，展示搜索的条件文字版， 后台收到的是文字版对应的code
    const targetValue: Record<string, string> = {};
    provide('setTargetValue', (key: string, tv: string) => {
      targetValue[key] = tv;
    });
    /**
     * 对一些特殊的数据进行特殊处理
     * */
    const buildData = () => {
      const data = { ...formData };
      options.value.forEach((v) => {
        if (!v.show) {
          Reflect.deleteProperty(data, v.key);
        }
      });
      const returnData: TagItem[] = [];
      // 处理成指定的格式输出
      Object.keys(data).forEach((v) => {
        const item = options.value.find((s) => s.key === v);
        if (item) {
          let tagValue = targetValue[v] || data[v];
          // 对于使用select，checkbox，radio等转译成显示的label
          if (Array.isArray(item.options)) {
            tagValue = item.options.find((v) => v.value === tagValue)?.label || tagValue;
          }
          const obj: TagItem = {
            tagLabel: item.label as string,
            tagValue,
            key: [],
            value: []
          };
          switch (item.type) {
            case InputType.daterange:
              if (Array.isArray(tagValue) && tagValue.length > 0) {
                const objData: { startKey?: number; endKey?: number } = {};
                if (item.dateConfig?.startKey) {
                  obj.key.push(item.dateConfig?.startKey);
                  obj.value.push(new Date(tagValue[0]).getTime() / 1000);
                  objData.startKey = new Date(tagValue[0]).getTime() / 1000;
                }
                if (item.dateConfig?.endKey) {
                  obj.key.push(item.dateConfig?.endKey);
                  obj.value.push(new Date(tagValue[1]).getTime() / 1000);
                  objData.endKey = new Date(tagValue[1]).getTime() / 1000;
                }
                obj.key.push(item.key);
                obj.value.push(objData);
                obj.tagValue = `${formatterTimer(new Date(tagValue[0]))} 至 ${formatterTimer(
                  new Date(tagValue[1])
                )}`;
              }
              break;
            case InputType.date:
              obj.key.push(item.key);
              obj.value.push(tagValue ? new Date(tagValue).getTime() / 1000 : '');
              break;
            case InputType.uploadImg:
              obj.key.push(item.key);
              obj.value.push(tagValue);
              break;
            default:
              obj.key.push(item.key);
              obj.value.push(data[v]);
              break;
          }
          returnData.push(obj);
        }
      });
      return returnData;
    };
    /**
     * 重置表单的数据
     * */
    const reset = (): Record<string, unknown> => {
      formElem.value?.resetFields();
      nextTick(() => {
        formElem.value?.clearValidate();
      });
      const data = { ...defaultData };
      ctx.emit('reset-fun', data);
      return data;
    };
    const getData = async (): Promise<TagItem[] | false> => {
      const data = await formElem.value?.validate();
      if (data) {
        return buildData();
      } else {
        return false;
      }
    };
    // 清除提示
    const clearValidate = () => {
      formElem.value?.clearValidate();
    };
    const setData = (data: { [l: string]: any }) => {
      // 对于时间间隔控件特殊处理，因为对外是两个key，但是对于内部逻辑来说是一个key
      const dateRangeItem = options.value.filter((s) => s.type === InputType.daterange);
      // 时间控件
      const dateItem = options.value.filter((s) => s.type === InputType.date);
      // 开关
      const switchItem = options.value.filter((s) => s.type === InputType.switch);
      // 地区选择
      const addressItem = options.value.filter((s) => s.type === InputType.address);
      // 图片上传
      const uploadImgItem = options.value.filter((s) => s.type === InputType.uploadImg);
      if (dateRangeItem.length > 0) {
        dateRangeItem.forEach((v) => {
          const startKey = v.dateConfig?.startKey;
          const endKey = v.dateConfig?.endKey;
          if (startKey && data[startKey] && endKey && data[endKey]) {
            formData[v.key] = [data[startKey] * 1000, data[endKey] * 1000];
            Reflect.deleteProperty(data, startKey);
            Reflect.deleteProperty(data, endKey);
          } else {
            let obj: Record<string, number> = data[v.key];
            if (typeof obj === 'string') {
              try {
                obj = JSON.parse(obj);
              } catch (e) {
                obj = {};
              }
              formData[v.key] = [obj[startKey as string] * 1000, obj[endKey as string] * 1000];
            }
          }
          Reflect.deleteProperty(data, v.key);
        });
      }
      if (dateItem.length > 0) {
        dateItem.forEach((v) => {
          const value = data[v.key];
          formData[v.key] = value ? new Date(Number(value) * 1000) : '';
          Reflect.deleteProperty(data, v.key);
        });
      }
      if (switchItem.length > 0) {
        switchItem.forEach((v) => {
          if (typeof data[v.key] === 'string') {
            formData[v.key] = data[v.key] === 'true';
          } else {
            formData[v.key] = Boolean(data[v.key]);
          }
          Reflect.deleteProperty(data, v.key);
        });
      }
      if (addressItem.length > 0) {
        addressItem.forEach((v) => {
          try {
            const value = data[v.key];
            if (!value || typeof value === 'string') {
              const jsonData = JSON.parse(value);
              data[v.key] = {
                areaSn: jsonData.areaSn ?? '',
                address: jsonData.address ?? ''
              };
            }
          } catch (e) {
            data[v.key] = {
              areaSn: '',
              address: ''
            };
          }
        });
      }
      if (uploadImgItem.length > 0) {
        uploadImgItem.forEach((v) => {
          // 是ssid的字符串ID
          const dataStr = data[v.key];
          if (typeof dataStr === 'string') {
            if (!dataStr) {
              formData[v.key] = [];
              return;
            }
            try {
              const data = JSON.parse(dataStr);
              if (Array.isArray(data)) {
                formData[v.key] = data;
              } else {
                formData[v.key] = [data];
              }
            } catch (e) {
              formData[v.key] = dataStr.split(',').map((v: string) => {
                return {
                  name: '',
                  ossId: v
                };
              });
              Reflect.deleteProperty(data, v.key);
            }
          }
        });
      }
      Object.assign(formData, data);
      options.value.forEach((v) => {
        playShowRule(
          v.key,
          formData[v.key],
          options.value,
          formData,
          defaultData,
          false,
          tabGridDetail,
          tabKey,
          tabKey,
          props.formModuleEvents
        );
        props.formModuleEvents?.change(tabKey, v.key, formData[v.key]);
      });
    };
    /**
     * 提交表单的数据
     * */
    const submit = async () => {
      const returnData = await getData();
      ctx.emit('submit-fun', returnData);
    };
    /**
     * 用户改变数据，监听所以子元素的onChang事件
     * */
    const change = ({ key, value }: { key: string; value: any }) => {
      if (value instanceof Event) return;
      playShowRule(
        key,
        value,
        options.value,
        formData,
        defaultData,
        true,
        tabGridDetail,
        tabKey,
        tabKey,
        props.formModuleEvents
      );
      ctx.emit('from-change', { key, value });
      // 通知表单模块数据更新
      props.formModuleEvents?.change(tabKey, key, value);
    };
    /**
     * 表单模块
     * */
    props.formModuleEvents?.onChange(tabKey, (tbName, key, value) => {
      playShowRule(
        key,
        value,
        options.value,
        formData,
        defaultData,
        true,
        tabGridDetail,
        tbName,
        tabKey,
        props.formModuleEvents
      );
      clearValidate();
    });
    const localFormModuleEvent: {
      // 子表单间互相修改指定tab下的表单内指定key的数据
      setData: (tabKey: string, key: string, data: any) => void;
      //子表单间互相获取指定tab下的表单指定key的数据
      getData: (tabKey: string, key: string) => any;
    } = {
      // 子表单间互相修改指定tab下的表单内指定key的数据
      setData: (tn: string, key: string, data: any) => {
        if (tabKey === tn) {
          setData({ [key]: data });
        } else {
          props.formModuleEvents?.setData(tn, key, data);
        }
      },
      //子表单间互相获取指定tab下的表单指定key的数据
      getData: (tn: string, key: string) => {
        if (tabKey === tn) {
          return getChainData(formData, key);
        } else {
          return props.formModuleEvents?.getData(tn, key);
        }
      }
    };
    /**
     * 业务弹窗获取到数据时，对于表单中某些依赖关系不好处理，主要体现在，组件直接返回字符串，但是部分项目依赖该项业务数据对象中的某个key时
     * 由组件主动调用该props传入的函数进行触发调用
     * */
    const businessDialogUsePlayRule = (item: FormItem, businessData: Record<string, any>) => {
      playShowRule(
        item.key,
        businessData,
        options.value,
        formData,
        defaultData,
        true,
        tabGridDetail,
        tabKey,
        tabKey,
        props.formModuleEvents
      );
      clearValidate();
    };
    /**
     * 表单项后的动作扩展
     * */
    const actionPlay = async (item: FormItem, action: FormItemAction) => {
      switch (action.type) {
        case 'navigate':
          // 跳转新的页面进行添加
          router.push({
            name: action.value
          });
          break;
        case 'refresh':
          if (item.linkageConfig?.sourceType === 'business') {
            const value = formData[item.key];
            await getDataFromBusiness(item, formData, tabKey, props.formModuleEvents, true);
            // todo 暂时处理，后续可能会有问题 刷新的同时，保证对应的关联成功运行
            await playShowRule(
              item.key,
              '',
              options.value,
              formData,
              defaultData,
              true,
              tabGridDetail,
              tabKey,
              tabKey,
              props.formModuleEvents
            );
            await playShowRule(
              item.key,
              value,
              options.value,
              formData,
              defaultData,
              true,
              tabGridDetail,
              tabKey,
              tabKey,
              props.formModuleEvents
            );
          }
          break;
      }
    };
    return {
      defaultData,
      buildData,
      setData,
      clearValidate,
      getData,
      options,
      formElem,
      formData,
      validData,
      reset,
      submit,
      change,
      businessDialogUsePlayRule,
      localFormModuleEvent,
      actionPlay,
      tabKey
    };
  },
  render() {
    const {
      tabKey,
      parentConfig,
      validData,
      formData,
      options,
      submit,
      reset,
      change,
      businessDialogUsePlayRule,
      localFormModuleEvent,
      actionPlay
    } = this;
    const slots = this.$slots;
    const child = options?.map((v, i) => {
      if (v.show && v.type !== InputType.hide) {
        if (i === 0 && v.type === InputType.text) {
          if (!v.attr) {
            v.attr = {};
          }
          v.attr.autofocus = true;
        }
        let tip = v.tip;
        if (tip) {
          tip = formatterStrByObj(tip, { [tabKey]: formData });
        }
        return (
          <el-form-item label={v.label + ':'} prop={v.key} key={v.key}>
            {buildItem(
              v,
              formData,
              v.input?.length || 0,
              {
                change,
                businessDialogUsePlayRule,
                formModuleEvents: localFormModuleEvent,
                actionPlay
              },
              slots
            )}
            <p v-show={tip} style={{ color: '#999', whiteSpace: 'break-spaces' }}>
              * {tip}
            </p>
          </el-form-item>
        );
      } else {
        return null;
      }
    });
    return (
      <el-form
        show-message={parentConfig?.showMessage || true}
        ref="formElem"
        size={parentConfig?.size || 'medium'}
        rules={validData}
        model={formData}
        label-width={parentConfig?.labelWidth || ''}
        inline={typeof parentConfig?.inline === 'boolean' ? parentConfig.inline : false}
        label-position={parentConfig?.labelPosition || 'left'}
        disabled={parentConfig?.disabled || false}
      >
        {child}
        {parentConfig?.showBtn === false ? null : (
          <el-form-item>
            <el-button type="primary" onClick={submit}>
              {parentConfig?.submitText || '提交'}
            </el-button>
            <el-button onClick={reset}>{parentConfig?.resetText || '重置'}</el-button>
          </el-form-item>
        )}
      </el-form>
    );
  }
});
