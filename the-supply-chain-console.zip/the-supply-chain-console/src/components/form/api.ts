import ajax, { Res } from '@/utils/axios';
import { FormItem, ShowRule } from '@/components/form/type';

interface ConfigJson {
  parentConfig: { [label: string]: any };
  itemData: FormItem[];
  showRules: ShowRule[];
  sn: string;
}

/**
 * 根据sn获取表单的配置项
 * */
export const getJson = async (sn: string): Promise<ConfigJson | null> => {
  // return ajax.post<{ sn: string }, Res<ConfigJson>>('/api/getconfig', {
  //   sn
  // });
  const res = await ajax.get<null, { [l: string]: ConfigJson }>('/snJSON.json', {
    params: {
      $noBase: true
    }
  });
  if (res) {
    return res[sn];
  } else {
    return null;
  }
};

/**
 * 根据字典名称获取对应的字典数据
 * */
export const getDictionary = (...names: string[]): Promise<Res<{ [label: string]: any[] }>> => {
  return ajax.post<{ names: string[] }, Res<{ [label: string]: any[] }>>('/api/getDictionary', {
    names
  });
};
