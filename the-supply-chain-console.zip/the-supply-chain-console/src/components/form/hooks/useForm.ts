import { FormMethods, UseFormProps } from '@/components/form/type';

export function useFrom(props: UseFormProps): [(m: FormMethods) => void, FormMethods] {
  let FormInterance: FormMethods;
  const ctl = (methos: FormMethods) => {
    FormInterance = methos;
    return props;
  };
  const methos: FormMethods = {
    setData(data: { [k: string]: any }) {
      FormInterance.setData(data);
    },
    reset() {
      return FormInterance.reset();
    },
    getData() {
      return FormInterance.getData();
    }
  };
  return [ctl, { ...methos }];
}
