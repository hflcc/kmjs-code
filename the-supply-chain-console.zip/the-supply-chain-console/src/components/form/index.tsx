import { defineComponent, inject, PropType, provide, reactive, ref } from 'vue';
import formComponent from '@/components/form/form';
import { FormItem, ParentConfig, validItem } from '@/components/form/type';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import { TagItem } from '@/components/utils/commonType';

export * from '@/components/form/items/useValid';

export interface CtlFun {
  setData: (data: Record<string, unknown>) => void;
  getNoVerifyData: () => Record<string, unknown> | null;
  getData: () => Promise<Record<string, unknown> | null>;
  reset: () => Record<string, unknown> | null;
  clearValidate: () => void;
}

export default defineComponent({
  name: 'formComponentWrap',
  props: {
    params: {
      type: Object as PropType<{ parentConfig: ParentConfig; itemData: FormItem[] }>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      default: ''
    },
    getCtlFun: {
      type: Function as PropType<(ctl: CtlFun) => void>,
      default: () => {
        // nothing
      }
    }
  },
  components: {
    formComponent
  },
  setup(props) {
    // 配合表单模块逻辑
    const tabKey = inject('tabKey', '');
    const tabName = inject('tabName', '');
    if (!tabKey) {
      const nowName = props.moduleName.split('/form')[0].split('/').slice(-1)[0];
      provide('tabKey', nowName);
    }
    const formRef = ref<InstanceType<typeof formComponent> | null>(null);
    // 存储表单的配置项
    const options = ref<FormItem[]>(props.params.itemData);
    // 最外层的配置项， 一般用在el-form上
    const parentConfig = reactive<{ [label: string]: any }>(props.params.parentConfig);
    const ctlFun: CtlFun = {
      clearValidate() {
        formRef.value?.clearValidate();
      },
      setData(data: { [k: string]: any }) {
        formRef.value?.setData(data);
      },
      getNoVerifyData() {
        const formData = formRef.value?.buildData();
        if (formData) {
          const data: { [l: string]: string } = {};
          formData.forEach((v) => {
            for (let i = 0; i < v.key.length; i++) {
              data[v.key[i]] = v.value[i];
            }
          });
          return data;
        } else {
          return null;
        }
      },
      async getData() {
        try {
          const formData = await formRef.value?.getData();
          if (formData) {
            const data: { [l: string]: string } = {};
            formData.forEach((v) => {
              for (let i = 0; i < v.key.length; i++) {
                data[v.key[i]] = v.value[i];
              }
            });
            return data;
          }
        } catch (e) {
          // nothing
        }
        return Promise.reject(`[${tabName}] 数据有误，请完善`);
      },
      reset() {
        return formRef.value?.reset() || {};
      }
    };
    if (typeof props.getCtlFun === 'function') {
      props.getCtlFun(ctlFun);
    }
    const { emitHandler, params, formModuleEvents } = resisterModule<
      {
        valid: {
          [key: string]: validItem[];
        };
        inputParams: {
          [key: string]: any;
        };
      },
      CtlFun
    >(props.moduleName, ctlFun);
    options.value.forEach((v: FormItem) => {
      v.attr = v.attr
        ? Object.assign(v.attr, {
            style: {
              width: '500px'
            }
          })
        : {
            style: {
              width: '500px'
            }
          };
      if (v.disabled) {
        v.attr = Object.assign(v.attr, { disabled: true });
      }
      if (params.value.valid && Object.keys(params.value.valid)) {
        const valid = params.value.valid;
        if (Array.isArray(valid[v.key])) {
          v.valid = valid[v.key];
        }
      }
      if (params.value.inputParams && Object.keys(params.value.inputParams)) {
        v.attr = Object.assign(v.attr, params.value.inputParams[v.key] ?? {});
      }
    });
    // 事件总揽函数，通过这个函数将事件暴露出去
    const emitFun = (name: string, value: TagItem[] | Record<string, any>) => {
      if (name === 'submit') {
        const data: { [l: string]: string } = {};
        value.forEach((v: TagItem) => {
          for (let i = 0; i < v.key.length; i++) {
            data[v.key[i]] = v.value[i];
          }
        });
        emitHandler?.(name, data);
        return;
      }
      emitHandler?.(name, value);
    };
    return {
      ctlFun,
      formRef,
      options,
      parentConfig,
      emitFun,
      formModuleEvents
    };
  },
  render() {
    const { options, parentConfig, emitFun, formModuleEvents } = this;
    const slots = this.$slots;
    return options.length ? (
      <formComponent
        ref="formRef"
        itemData={options}
        parentConfig={parentConfig}
        onSubmitFun={(value: any) => {
          emitFun('submit', value);
        }}
        onResetFun={(value: any) => {
          emitFun('reset', value);
        }}
        formModuleEvents={formModuleEvents}
        v-slots={slots}
      />
    ) : (
      '<p>表单载入中。，，</p>>'
    );
  }
});
