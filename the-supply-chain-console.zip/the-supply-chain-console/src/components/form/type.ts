export type FormItemFun = (
  item: FormItem,
  formData: Record<string, any>,
  change: (data: { key: string; value: any }) => void
) => JSX.Element;

export enum InputType {
  text = 'text',
  number = 'number',
  radio = 'radio',
  checkbox = 'checkbox',
  select = 'select',
  date = 'date',
  dateTime = 'dateTime',
  switch = 'switch',
  textArea = 'textArea',
  button = 'button',
  // 带有间隔的时间选者器
  daterange = 'daterange',
  uploadImg = 'uploadImg',
  uploadFile = 'uploadFile',
  area = 'area',
  address = 'address',
  hide = 'hide',
  slot = 'slot',
  qualificationDef = 'qualificationDef',
  expiredDate = 'expiredDate',
  stepInput = 'stepInput',
  // 新增富文本表单类型
  richText = 'richText',
  // 新增远程搜索的选择器表单类型
  searchSelect = 'searchSelect',
  multipleSelect = 'multipleSelect',
  // 运费模板类型
  freightTemplateInfo = 'freightTemplateInfo'
}

export enum EventName {
  submit = 'submit',
  reset = 'reset'
}

export interface ParentConfig {
  // 需要去查询的字典名称，统一读取后赋值
  dictionary?: string[];
  labelWidth: string | number;
  inline: boolean;
  labelPosition: 'right' | 'left' | 'top';
  showMessage?: boolean;
  resetText?: string;
  submitText?: string;
  size?: 'mini' | 'small' | 'medium';
  showBtn: boolean;
  disabled?: boolean;
}

export type ValidCallBack = (rule: validItem, value: any, callback: (err?: Error) => void) => any;

export interface validItem {
  validator?: ValidCallBack;
  required?: boolean;
  valid?: RegExp | string;
  message?: string;
  trigger: 'change' | 'input' | 'blur';
  max?: number;
  min?: number;
  type?: string;
  fields?: Record<
    number,
    {
      type: string;
      required: boolean;
      message: string;
    }
  >;
}

export interface FormInput {
  label?: string;
  defaultValue?: any;
  attr?: { [label: string]: any };
  placeholder?: string;
  eventName?: string;
}

export interface DateConfig {
  canChoose?: {
    // 日期像前推X天
    dateBefore?: number;
    // 日期像后推X天
    dateAfter?: number;
    // 时间间隔 以逗号间隔
    dateRanger?: string;
    // 是否是可以选择的
    canPlay: boolean;
  }[];
  // 时间开始的key
  startKey?: string;
  // 时间结束的key
  endKey?: string;
}

// 联动控制逻辑
export interface ShowRule {
  // 哪个key触发
  // 依赖哪个key的变化触发
  sourceKey: string;
  // 显示规则时，具体某个值等于哪个值时出现，如果是any的话，就是只有有值就触发规则
  // 计算规则时，记录依赖哪些key的取值表达式
  sourceValue: string[] | 'any';
  // show 显示隐藏 mathComputed 数学计算 disable 是否可编辑
  ruleType?: 'show' | 'hide' | 'mathComputed' | 'disable';
  // 加，减，乘，除
  mathType?: 'add' | 'subtract' | 'multiply' | 'divide';
  // 不可编辑的附加项目，
  // 为false，表示不满足条件时，该项目不可编辑
  // 为true，表示满足条件时，该项目不可编辑
  // 默认按false处理
  disable?: boolean;
}

// 上传文件的配置项
export interface UploadConfig {
  // 最大上传文件的显示数量
  limit?: number;
  // 大小限制 以KB为单位
  size?: number;
  // 提示文字
  tip: string[];
}

export interface OptionsItem {
  label: string;
  value: string;
  disabled?: boolean;
  businessData?: Record<string, any>;
}

export interface LinkageConfig {
  // 是否正在请求中
  _isLoading: boolean;
  // 业务数据是否来自无（none）｜ 业务(business) | mapping（来自于别的表单数据（主要服务于表单模块））
  sourceType: 'none' | 'business' | 'mapping' | 'selector';
  // business 来自后台业务数据的请求地址
  // mapping 表单模块的位置
  serverUrl?: string;
  // 后台业务数据中对应的key
  businessKeyMap?: {
    label: string;
    value: string;
  };
  // 请求数据时，依赖哪些表单中的值
  source?: {
    // 表单内的key
    key: string;
    // 表单内的数据
    value: string[];
    // 业务数据请求的key
    businessKey: string;
  }[];
  // 设置多个值 当前值改变时，改变对应表单中某些字段的值
  play?: {
    // 表单系统内使用时，存在tab的概念，使用这个记录
    [tabKey: string]: {
      // 对应表单内的key
      sourceFormKey: string;
      // 业务数据的key | 表单字段Key： 业务字段Key的对应
      businessFormKey: string | Record<string, string>;
    }[];
  };
  // 不轮什么情况下都执行一次play
  playAnyTime?: boolean;
  // 对表单执行的一些动作
  action: 'play' | 'init';
}

export interface FormItemAction {
  type: 'navigate' | 'refresh';
  label: string;
  value: string;
}

export interface FormItem {
  show?: boolean;
  // 校验规则
  validNames?: string[];
  // 自定义校验规则
  validFlexible?: validItem[];
  // 表单项显示的文字，
  label?: string;
  // 接受用户输入值的key1
  key: string;
  // 输入框内的提示文字
  placeholder?: string;
  // 渲染表单时的默认值
  defaultValue: any;
  // 表单类型
  type?: InputType;
  // 同时多个表单时的配置项
  input?: FormInput[];
  // 校验项，校验规则实例化后存储的位置，不在传入的配置JSON中体现
  valid?: validItem[];
  // 基本select的option的数据源，也在 radio和checkbox
  options?: OptionsItem[];
  disabled: boolean;
  // 其他HTML属性
  attr?: { [label: string]: any };
  // 事件名称
  eventName?: EventName;
  // 字典名称,一般用与从后台字典数据库中取值时的值
  dictionaryName?: string;
  // 时间相关的配置
  dateConfig?: DateConfig;
  // 联动显示使用
  rules?: ShowRule[];
  // 上传管理配置
  uploadConfig?: UploadConfig;
  slotName?: string;
  // 特殊配置
  params?: Record<string, any>;
  // 提示信息
  tip?: string;
  // 数据联动/数据来自业务数据配置项
  linkageConfig?: LinkageConfig;
  // 来自表单模块的配置项
  renderConfig: ResItem;
  // 单元项目后的动作，目前仅在select下加入
  actions?: FormItemAction[];
}

export interface FormMethods {
  setData: (data: { [k: string]: any }) => void;
  getData: () => Promise<{ [l: string]: any }>;
  reset: () => { [l: string]: any };
}

export interface UseFormProps {
  sn: string;
  handlder: (name: string, data: any[]) => void;
}
