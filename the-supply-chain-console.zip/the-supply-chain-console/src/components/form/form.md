# 表格控件使用基本说明

> 初心：  
> &nbsp;&nbsp;&nbsp;&nbsp;是配合可视化配置平台，通过JSON来主导表格的样式标签
> > 可视化配置平台还在开发中，优先级过于低

## 基本使用例子

```vue

<template>
  <kmjsTable :ctl="tableCtl"></kmjsTable>
</template>
<script lang="ts">
import { defineComponent } from 'vue';
import kmjsForm, { useFrom } from '@/components/form';

export default defineComponent({
  name: 'project-index',
  components: {
    kmjsForm
  },
  setup() {
    const [ tableCtl, tableMethods ] = useFrom({
      sn: 'project', // 获取JSON指定的key
      // 这里是所有的事件分发。
      handler: (name: string, data: any[]) => {
        // 如果不确定按钮对应的事件名称，可以先console.log(name,data)查看
        console.log(name, data)
      }
    });
    return { tableCtl };
  }
});
</script>
```

## table JSON配置项详解

```

```
