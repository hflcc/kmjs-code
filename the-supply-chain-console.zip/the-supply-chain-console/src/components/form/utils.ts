/**
 * 获取全部的字典中的数据，并递归循环赋值给对应的options中的option
 * */
import { FormItem, InputType, validItem } from '@/components/form/type';
import { useStore } from 'vuex';
import { getBusinessDataByForm } from '@/utils/commApi';
import { getChainData, math } from '@/utils';

export type ValidFun = (rule: validItem, value: any, callback: (err?: Error) => void) => void;
const validFun: ValidFun = (rule, value, callback) => {
  if (!value) return callback();
  if ((rule.valid as RegExp)?.test(value)) {
    return callback();
  } else {
    return callback(new Error(rule.message));
  }
};

// 默认包含的校验项，后续可在这里进行补充
const validRules: {
  [s: string]: validItem;
} = {
  required: {
    required: true,
    message: '请完成${label}',
    trigger: 'change'
  },
  email: {
    validator: validFun,
    valid: /^([a-zA-Z\d])(\w|-)+@[a-zA-Z\d]+\.[a-zA-Z]{2,4}$/,
    message: '请输入正确的邮箱',
    trigger: 'change'
  },
  integer: {
    validator: validFun,
    valid: /^[1-9]\d*$/,
    message: '请输入整数',
    trigger: 'change'
  },
  number: {
    validator: validFun,
    valid: /^[+-]?\d+(\.\d+)?$/,
    message: '请输入数字',
    trigger: 'change'
  },
  idCard: {
    validator: validFun,
    valid:
      /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}$)/,
    message: '请输入正确的身份证号码',
    trigger: 'change'
  },
  phone: {
    validator: validFun,
    valid: /^[1][3456789][0-9]{9}$/,
    message: '请输入正确的手机号',
    trigger: 'change'
  }
};
/**
 * 应用字典规则。将字典的数据，替换options中的值
 * @param dictionary 字典名称
 * @param options 表单配置项
 * */
export const useDictionary = async (dictionary: string[], options: FormItem[]) => {
  const store = useStore();
  // 不知道为什么有些时候获取不到
  if (!store) return;
  const dictionaries: { [l: string]: DictionariesItem[] } = await store.dispatch(
    'dictionaries/getData',
    dictionary
  );
  if (dictionaries) {
    dictionary.forEach((v) => {
      options.forEach((o) => {
        if (o.dictionaryName === v) {
          o.options = dictionaries[v].map((v) => {
            return {
              label: v.name,
              value: v.code
            };
          });
        }
      });
    });
  }
};
/**
 * 设置日期可选择的区间控制
 * */
export const useDateRule = (o: FormItem) => {
  if (
    o.dateConfig &&
    (o.type === InputType.date ||
      o.type === InputType.expiredDate ||
      o.type === InputType.daterange)
  ) {
    if (!o.params) o.params = {};
    o.params.disabledDate = o.dateConfig.canChoose?.map((s) => {
      return (t: Date): boolean => {
        const now = new Date();
        now.setHours(0);
        now.setMinutes(0);
        now.setSeconds(0);
        now.setMilliseconds(0);
        const nowTime = now.getTime();
        const time = t.getTime();
        let flag = true;
        // 区间内的几天可以选择
        if (s.dateRanger) {
          const timeStep = s.dateRanger.split(',');
          flag = time >= new Date(timeStep[0]).getTime() && time <= new Date(timeStep[1]).getTime();
        }
        // 当前像前推的几天可以选择
        if (typeof s.dateBefore === 'number') {
          if (s.dateBefore > 0) {
            now.setDate(now.getDate() - s.dateBefore);
            const newDate = new Date(now);
            flag = time >= newDate.getTime() && time <= nowTime;
          }
          // 小于0 说明截止时间是当天
          if (s.dateBefore < 0) {
            flag = time <= nowTime;
          }
        }
        // 当前像后推几天可以选择
        if (typeof s.dateAfter === 'number') {
          if (s.dateAfter > 0) {
            const newDate = new Date(now.setDate(now.getDate() + s.dateAfter));
            flag = time < newDate.getTime() && time >= nowTime;
          }
          // 小于0 说明截止时间是当天
          if (s.dateAfter < 0) {
            flag = time >= nowTime;
          }
        }
        // 这里控制上述规则是否反向成立
        if (s.canPlay) {
          // 按照上述规则进行限制
          return !flag;
        } else {
          // 按照上述规则反向进行限制 即 '区间内的几天可以选择'变为'区间内的几天可以不选择， 别的可以被选择'
          return flag;
        }
      };
    });
  }
};

/**
 * 应用校验规则
 * */
export const useValid = (o: FormItem): void => {
  if (o.type === InputType.hide) return;
  if (!Array.isArray(o.valid)) {
    o.valid = [];
  }
  if (Array.isArray(o.validNames)) {
    o.validNames.forEach((v: string) => {
      if (validRules[v]) {
        const item = { ...(validRules[v] as validItem) };
        if (v === 'required') {
          if (
            o.type === InputType.checkbox ||
            o.type === InputType.uploadImg ||
            o.type === InputType.uploadFile ||
            o.type === InputType.daterange
          ) {
            item.type = 'array';
            if (o.type === InputType.daterange) {
              item.fields = {
                0: {
                  type: 'date',
                  required: true,
                  message: '请选择开始时间'
                },
                1: {
                  type: 'date',
                  required: true,
                  message: '请选择结束时间'
                }
              };
            }
          }
          if (o.type === InputType.date || o.type === InputType.dateTime) {
            item.type = 'date';
          }
          if (o.type === InputType.uploadImg || o.type === InputType.uploadFile) {
            item.message = '请上传${label}';
          }
        }
        item.message = item.message?.replace('${label}', o.label || '');
        o.valid?.push(item);
      }
    });
  }
  if (Array.isArray(o.validFlexible)) {
    o.validFlexible.forEach((v) => {
      if (!v.valid) return;
      v.trigger = v.trigger ?? 'change';
      v.valid = new RegExp(v.valid);
      v.validator = validFun;
      o.valid?.push(v);
    });
  }
};

/**
 * 获取别的表单数据，并设置在表单上
 * */
export const getDataFromForm = (
  item: FormItem,
  formData: Record<string, any>,
  currentTabName: string,
  formModuleEvents?: FormModuleEvents,
  isRefresh = false
) => {
  if (!item.linkageConfig || (!isRefresh && item.options?.length)) {
    return;
  }
  const linkageConfig = item.linkageConfig;
  const [tabKey, formKey] = linkageConfig?.serverUrl?.split('.') || [];
  let resData: Record<string, any>[] | undefined;
  if (tabKey === currentTabName) {
    resData = formData[formKey] as Record<string, any>[];
  } else {
    resData = formModuleEvents?.getData(tabKey, formKey) as Record<string, any>[];
  }
  item.options =
    resData?.map((v) => {
      const s = v[linkageConfig?.businessKeyMap?.value as string];
      return {
        label: v[linkageConfig?.businessKeyMap?.label as string],
        value: typeof s === 'object' ? s : s.toString(),
        businessData: v
      };
    }) ?? [];
};
/**
 * 获取业务数据，并设置在表单上
 * @param item 当前表单项的配置信息
 * @param formData 当前表单的数据
 * @param currentTabName 当前表单的tabKey
 * @param formModuleEvents 表单模块中tab间的交互方法
 * @param isRefresh 当前函数是否用于刷新数据
 * @param clearData 当不满足条件时是否清空当前已有的值
 * */
export const getDataFromBusiness = async (
  item: FormItem,
  formData: Record<string, any>,
  currentTabName: string,
  formModuleEvents?: FormModuleEvents,
  isRefresh = false,
  clearData = true
) => {
  // 先判断是否都是不依赖别的项目的，如果是并且是已经完成状态，停止执行
  const rules = item.linkageConfig?.source?.filter((v) => v.key === '*') ?? [];
  if (
    !item.linkageConfig ||
    (rules.length === item.linkageConfig?.source?.length && !isRefresh) ||
    item.linkageConfig?._isLoading
  ) {
    return;
  }
  // 在生成对应的请求参数
  const requestObj: Record<string, any> = {};
  item.linkageConfig?.source?.forEach((v) => {
    if (v.key === '*') {
      if (v.businessKey) {
        requestObj[v.businessKey] = v.value.join(',');
      } else {
        // 允许通过非空校验
        requestObj['@null'] = 'null';
      }
    } else {
      const keys = v.key.split('.');
      if (keys[0] === '*') {
        // todo 多个参数取值问题
        requestObj[v.businessKey] = formData[keys[1]];
      } else {
        let data;
        if (keys[0] === currentTabName) {
          // data = formData[keys[1]];
          data = getChainData(formData, keys.slice(1).join('.'));
        } else {
          data = formModuleEvents?.getData(keys[0], keys[1].split('.')[0]);
        }

        requestObj[v.businessKey] = data || undefined;
      }
    }
  });
  const values = Object.values(requestObj);
  if (!values.length || values.includes(undefined)) {
    if (clearData) {
      formData[item.key] = '';
    }
    item.options = [];
    return;
  }
  // 去除允许通过非空校验
  Reflect.deleteProperty(requestObj, '@null');
  const linkageConfig = item.linkageConfig;
  linkageConfig._isLoading = true;
  const resData = await getBusinessDataByForm(linkageConfig?.serverUrl ?? '', requestObj);
  linkageConfig._isLoading = false;
  if (!resData) return false;
  item.options = resData.map((v) => {
    const s = v[linkageConfig.businessKeyMap?.value as string];
    return {
      label: v[linkageConfig.businessKeyMap?.label as string],
      value: typeof s === 'object' ? s : s.toString(),
      businessData: v
    };
  });
  return true;
};

/**
 * 应用显示联动显示规则, 判断值是否符合预设值符合的话显示，不符合隐藏
 * 同时应用联动规则，判断当前项目是否需要去操作别的项目和是否依赖别的项目
 * @param key 当前用户修改的表单项的key
 * @param value 当前用户修改的表单项的值
 * @param items 表单项
 * @param formData 表单的数据
 * @param defaultData 表单的默认数据
 * @param clearData 是否清空隐藏选项的数据
 * @param tabGridDetail 处理跨tab时操作表格数据
 * @param tabName 当前变化数据所属于的tabName
 * @param currentTabName 当前表单的tabName
 * @param formModuleEvents 表单模块提供的方法
 * @param getDataFromBusinessFlag 是否必须请求一次业务数据
 * */
export const playShowRule = async (
  key: string,
  value: any,
  items: FormItem[],
  formData: Record<string, any>,
  defaultData: Record<string, any>,
  clearData = true,
  tabGridDetail: Record<string, FormatTabGridDetail>,
  tabName = '*',
  currentTabName = '*',
  formModuleEvents?: FormModuleEvents,
  getDataFromBusinessFlag?: boolean
) => {
  const length = items.length;
  for (let i = 0; i < length; i++) {
    const item = items[i];
    // 控制是否展示
    const showRules =
      item.rules?.filter(
        // 这里是排除tabName.formKey.valueKey等多级取值导致的问题
        (v) =>
          v.sourceKey.split('.').slice(0, 2).join('.') ===
          (key ? [tabName, key].join('.') : tabName)
      ) ?? [];
    if (showRules.length) {
      showRules.forEach((v) => {
        // 对显示逻辑进行处理
        if (v.ruleType === 'show' || v.ruleType === 'hide') {
          item.show = v.ruleType === 'hide';
          // 单独判断只要有值就展示的
          if (value && v.sourceValue === 'any') {
            item.show = true;
            return;
          }
          // 针对修改的值是对象的
          if (typeof value === 'object') {
            // 去除tabName和表单内的字符串
            const key = v.sourceKey.split('.').slice(2).join('.');
            // 从对象中去除指定的值进行比较
            const data = getChainData(value, key);
            const flag = v.sourceValue.includes(data as string);
            item.show = v.ruleType === 'show' ? flag : !flag;
          } else {
            // 针对值是字符串的
            const flag = v.sourceValue.includes(value as string);
            item.show = v.ruleType === 'show' ? flag : !flag;
          }
          if (
            ((v.ruleType === 'show' && item.show === false) ||
              (v.ruleType === 'hide' && item.show === true)) &&
            clearData
          ) {
            formData[item.key] = defaultData[item.key];
            playShowRule(
              item.key,
              defaultData[item.key],
              items,
              formData,
              defaultData,
              clearData,
              tabGridDetail,
              tabName,
              currentTabName,
              formModuleEvents
            );
          }
        }
        // 对数学计算逻辑进行计算
        if (v.ruleType === 'mathComputed') {
          const fun = math[v?.mathType as 'add' | 'subtract' | 'multiply' | 'divide'];
          if (typeof fun !== 'function') return;
          const parameter: number[] = (v.sourceValue as string[]).map((v) => {
            if (v === '*') {
              return Number(formData[item.key]) || 0;
            }
            // 拆解取值表达式
            const keys = v.split('.');
            // 临时变量记录下取到的表单值
            let lfd;
            // 当前表单
            if (keys[0] === currentTabName || keys[0] === '*') {
              lfd = formData[keys[1]];
            } else {
              lfd = formModuleEvents?.getData(keys[0], keys[1]);
            }
            lfd = getChainData(lfd, keys.slice(2).join('.'));
            return Number(lfd) || 0;
          });
          formData[item.key] = fun(parameter);
          if (clearData) {
            // 处理连续依赖
            playShowRule(
              item.key,
              defaultData[item.key],
              items,
              formData,
              defaultData,
              clearData,
              tabGridDetail,
              tabName,
              currentTabName,
              formModuleEvents
            );
          }
        }
        // 对disable逻辑进行处理
        if (v.ruleType === 'disable') {
          const targetTab = v.sourceKey.split('.')[0];
          let data;
          // 先判断下是否依赖的当前表单
          if (targetTab === currentTabName) {
            data = getChainData(formData, v.sourceKey.split('.').slice(1).join('.'));
          } else {
            data = formModuleEvents?.getData(targetTab, v.sourceKey.split('.')[1] || '');
          }
          // 是否满足规则
          let flag;
          if (v.sourceValue.length === 0) {
            // 如果没有指定依赖的值，那么说明只要有值就满足情况
            // 这里由于存在逻辑删除的数据过滤逻辑删除的数据
            flag = Array.isArray(data) ? data.filter((s) => !s.isDelete).length > 0 : Boolean(data);
          } else {
            // 具有值的范围时，只要具有某个值就满足情况
            flag = v.sourceValue.includes(data);
          }
          // v.disable
          // 为false，表示不满足条件时，该项目不可编辑
          // 为true，表示满足条件时，该项目不可编辑
          // 默认按false处理
          item.disabled = (!v.disable && !flag) || (Boolean(v.disable) && flag);
        }
      });
    } else {
      item.show = item.show ?? true;
      item.disabled = item.disabled ?? false;
    }
    // 控制联动逻辑
    if (item.linkageConfig) {
      if (item.linkageConfig.action === 'play' && item.key === key) {
        // 处理需要设置某个表单的值
        if (
          item.key === key &&
          item.linkageConfig.play &&
          (clearData || item.linkageConfig.playAnyTime || getDataFromBusinessFlag)
        ) {
          // 遍历需要修改的Key
          Object.keys(item.linkageConfig.play).forEach((s) => {
            const v = item.linkageConfig?.play?.[s];
            let businessData: Record<string, any> | null = null;
            // 普通的select 联动逻辑
            if (item.linkageConfig?.sourceType === 'business') {
              businessData = item.options?.find((q) => q.value === value)?.businessData || null;
            }
            // 传入的是一个对象时直接使用该对象的数据进行处理
            if (typeof value === 'object') {
              businessData = value;
            }
            // 处理表格逻辑
            if (tabGridDetail[s]?.isGrid) {
              const setData: Array<Record<string, any>> = [];
              const oldData = formModuleEvents?.getData(s, '');
              if (businessData) {
                let tableKey = '';
                const unionKey = tabGridDetail[key]?.unionKey;
                // 计算表格字段放在业务数据的那里
                v?.forEach((item) => {
                  if (
                    typeof item.businessFormKey === 'string' &&
                    item.businessFormKey.indexOf('.') !== -1
                  ) {
                    const strList = item.businessFormKey.split('.');
                    tableKey = strList[0];
                  }
                });
                // 取出数据
                if (tableKey && Array.isArray(businessData[tableKey])) {
                  setData.push(
                    ...businessData[tableKey].map((dataItem: any) => {
                      v?.forEach((mapItem) => {
                        // 与业务数据映射
                        if (
                          typeof mapItem.businessFormKey === 'string' &&
                          mapItem.businessFormKey.indexOf('.') !== -1
                        ) {
                          const key = (mapItem.businessFormKey as string)
                            .split('.')
                            .slice(1)
                            .join('.');
                          dataItem[mapItem.sourceFormKey] = getChainData(dataItem, key);
                        } else {
                          dataItem[mapItem.sourceFormKey] = getChainData(
                            businessData,
                            mapItem.businessFormKey as string
                          );
                        }
                      });
                      return dataItem;
                    })
                  );
                }
                setData.forEach((newItem) => {
                  oldData.forEach((oldItem: any) => {
                    if (newItem[unionKey] === oldItem[unionKey]) {
                      Object.assign(newItem, oldItem);
                    }
                  });
                });
                formModuleEvents?.setData(s, 'data', setData);
              }
            } else {
              v?.forEach((d) => {
                let setData: string | Record<string, any> = '';
                if (businessData) {
                  if (typeof d.businessFormKey === 'string') {
                    setData = getChainData(businessData as Record<string, any>, d.businessFormKey);
                  } else {
                    // 设置一个对象
                    const obj: Record<string, any> = {};
                    Object.keys(d.businessFormKey).forEach((s) => {
                      const vKey = (d.businessFormKey as Record<string, string>)[s];
                      obj[s] = getChainData(businessData as Record<string, any>, vKey);
                    });
                    setData = obj;
                  }
                }
                // 判断是否操作的是当前实例的表单
                if (s === currentTabName || typeof tabGridDetail[s] === 'undefined') {
                  const oldData = formData[d.sourceFormKey];
                  if (JSON.stringify(oldData) === JSON.stringify(setData)) return;
                  formData[d.sourceFormKey] = setData;
                } else {
                  const oldData = formModuleEvents?.getData(s, d.sourceFormKey);
                  // 先判断是否一致，一致的话不进行设置，防止进入无限递归
                  if (JSON.stringify(oldData) === JSON.stringify(setData)) return;
                  formModuleEvents?.setData(s, d.sourceFormKey, setData);
                }
              });
            }
          });
        }
      }
      if (item.linkageConfig.action === 'init' && item.key === key && value && clearData) {
        formModuleEvents?.reloadForm(value);
      }
      if (
        item.linkageConfig?.sourceType === 'business' ||
        item.linkageConfig?.sourceType === 'selector'
      ) {
        // 处理请求数据时依赖别的值
        const linkedRules =
          item.linkageConfig.source?.filter(
            (v) => v.key.split('.').slice(0, 2).join('.') === [tabName, key].join('.')
          ) ?? [];
        // 这里要确认是否具有依赖关系
        if (linkedRules.length) {
          if (clearData && formData[item.key] && item.key !== key) {
            formData[item.key] = '';
            item.options = [];
            // 继续处理依赖当前修改值的依赖
            playShowRule(
              item.key,
              '',
              items,
              formData,
              defaultData,
              clearData,
              tabGridDetail,
              tabName,
              currentTabName,
              formModuleEvents
            );
          }
          if (item.linkageConfig?.sourceType === 'business') {
            // 获取业务数据
            const flag = await getDataFromBusiness(
              item,
              formData,
              currentTabName,
              formModuleEvents,
              false,
              clearData
            );
            if (item.key !== key && (flag || item.linkageConfig.playAnyTime)) {
              // 处理异步业务数据到来后，无法正确设置数据问题
              playShowRule(
                item.key,
                formData[item.key],
                items,
                formData,
                defaultData,
                clearData,
                tabGridDetail,
                tabName,
                currentTabName,
                formModuleEvents,
                flag
              );
            }
          }
        }
      }
      if (item.linkageConfig?.sourceType === 'mapping') {
        getDataFromForm(item, formData, currentTabName, formModuleEvents);
      }
    }
  }
};
