import { inject, InjectionKey, provide } from 'vue';
import { ValidCallBack } from '@/components/form/type';

export interface ValidateError {
  message: string;
  field: string;
}

export interface FieldErrorList {
  [field: string]: ValidateError[];
}

export interface ValidateFieldCallback {
  (isValid?: boolean, invalidFields?: FieldErrorList): void;
}

export interface ElFormItemContext {
  prop?: string;
  validateState: string;
  formItemMitt: {
    emit<T = any>(type: string | symbol, event?: T): void;
  };

  validate(callback?: ValidateFieldCallback): void;

  updateComputedLabelWidth(width: number): void;

  addValidateEvents(): void;

  removeValidateEvents(): void;

  resetField(): void;

  clearValidate(): void;
}

const elFormItemKey: InjectionKey<ElFormItemContext> = 'elFormItem' as any;
/**
 * 触发element-ui的校验
 * */
export const useValid = function () {
  const elFormItem = inject(elFormItemKey, {} as ElFormItemContext);
  const itemMitt = elFormItem.formItemMitt;
  const setValidRule = inject<(name: string, cb: ValidCallBack) => void>('setValidRule');
  const validChange = (value: any) => {
    itemMitt?.emit('el.form.change', [value]);
  };
  provide('elFormItem', Object.assign(elFormItem, { formItemMitt: null }));
  return {
    validChange,
    setValidRule
  };
};
