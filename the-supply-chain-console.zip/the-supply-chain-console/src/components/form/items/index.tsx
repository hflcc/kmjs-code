import { h, readonly, resolveComponent } from 'vue';
import { FormItem, FormItemAction, InputType, OptionsItem } from '@/components/form/type';
import uploadImg from '@/components/form/items/upload-img';
import uploadFile from '@/components/form/items/upload-file';
import searchSelect from '@/components/form/items/searchSelect';
import areaChoose from '@/components/form/items/areaChoose';
import addressChoose from '@/components/form/items/addressChoose';
import qualificationDef from '@/components/form/items/qualificationDef';
import richText from '@/components/form/items/richText';
import expiredDate from '@/components/form/items/expiredDate';
import freightTemplateInfo from '@/components/form/items/freightTemplateInfo';
import dateRangePicker from '@/components/form/items/dateRangePicker';
import {
  formatterPrice,
  formatterTimer,
  formatterValueBeforeOrAfterPoint,
  formatterValueMaxOrMin
} from '@/utils';
import { Slots } from '@vue/runtime-core';

const timeDetail = (item: FormItem, data: number | number[]) => {
  if (item.type === InputType.daterange && Array.isArray(data)) {
    return (
      <p>
        {formatterTimer(new Date(data[0]), item.params?.formatter || 'YYYY-MM-DD')} {' 至 '}
        {formatterTimer(new Date(data[1]), item.params?.formatter || 'YYYY-MM-DD')}
      </p>
    );
  } else {
    return (
      <p>
        {data
          ? formatterTimer(new Date(data as number), item.params?.formatter || 'YYYY-MM-DD')
          : '--'}
      </p>
    );
  }
};

const textDetail = (data: string, unit = '') => {
  return (
    <p>
      {data ?? '--'} {unit}
    </p>
  );
};

const optionDetail = (data: string | string[], options: OptionsItem[] = [], unit = '') => {
  let key: string[] = [];
  if (Array.isArray(data)) {
    key = data.map((v) => {
      const key = options.find((s) => s.value === v);
      return key?.label || v;
    });
  } else {
    key = [options.find((s) => s.value === data)?.label || data];
  }
  return (
    <p>
      {key.join('、') ?? '--'} {unit}
    </p>
  );
};

interface BuildFormItemEvent {
  change: (data: { key: string; value: any }) => void;
  businessDialogUsePlayRule?: (item: FormItem, businessData: Record<string, any>) => void;
  formModuleEvents?: {
    // 子表单间互相修改指定tab下的表单内指定key的数据
    setData: (tabName: string, key: string, data: any) => void;
    //子表单间互相获取指定tab下的表单指定key的数据
    getData: (tabName: string, key: string) => any;
  };
  actionPlay?: (item: FormItem, actionItem: FormItemAction) => void;
}

/**
 * 创建form表单的子项目，渲染具体的表单控件
 * @param item 渲染子控件用到的数据
 * @param formData 记录表单录入数据的数据源
 * @param length 需要渲染控件的数量
 * @param event 预先定义好的事件
 * @return jsx.element
 * */
const buildItem = (
  item: FormItem,
  formData: { [label: string]: any },
  length: number,
  event: BuildFormItemEvent,
  slots: Slots
) => {
  const defaultInputPlaceholder = `请输入${item.label}`;
  const defaultSelectPlaceholder = `请选择${item.label}`;
  const deafult = () => {
    let elem = (
      <el-space>
        <el-input
          v-model={formData[item.key]}
          onChange={(e: string) => event.change({ key: item.key, value: e })}
          {...item.attr}
        />
        <span>{item.params?.unit}</span>
      </el-space>
    );
    try {
      const elVNode = resolveComponent('form-item-' + item.type);
      if (typeof elVNode !== 'string') {
        elem = h(elVNode, {
          modelValue: formData[item.key],
          config: item,
          disabled: item.disabled,
          formData: readonly(formData),
          formModuleEvents: event.formModuleEvents,
          linkPlay: (businessData: Record<string, any>) => {
            event.businessDialogUsePlayRule?.(item, businessData);
          },
          change: (value: unknown, change = false) => {
            formData[item.key] = value;
            if (change) {
              event.change({ key: item.key, value: value });
            }
          }
        });
      }
    } catch (e) {
      console.log(e);
      // 寻找不到时，渲染默认的input框
    }
    return elem;
  };
  switch (item.type) {
    case InputType.text:
      if (formData[item.key] && typeof formData[item.key] === 'object') {
        formData[item.key] = JSON.stringify(formData[item.key]);
      }
      if (item.disabled || item.attr?.disabled) {
        if (item.validNames?.includes('number')) {
          return textDetail(formatterPrice(Number(formData[item.key])), item.params?.unit);
        }
        return textDetail(formData[item.key], item.params?.unit);
      }
      return (
        <el-space>
          <el-input
            v-model={formData[item.key]}
            placeholder={item.placeholder ?? defaultInputPlaceholder}
            onChange={(e: string) => {
              let result = formatterValueBeforeOrAfterPoint(
                e,
                item.params?.beforePoint,
                item.params?.afterPoint
              );

              // 处理数字类型的最大值，最小值
              if (item.validNames?.includes('number') || item.validNames?.includes('integer')) {
                if (item.params?.type === 'mapping') {
                  const maxKey = item.params?.max.split('.');
                  const max = event.formModuleEvents?.getData(maxKey[0], maxKey[1]);

                  const minKey = item.params?.min.split('.');
                  const min = event.formModuleEvents?.getData(minKey[0], minKey[1]);

                  result = formatterValueMaxOrMin(result, max, min);
                } else {
                  result = formatterValueMaxOrMin(result, item.params?.max, item.params?.min);
                }
              }

              // number类型时，转成数字
              if (item.validNames?.includes('number') && !isNaN(Number(result))) {
                formData[item.key] = Number(result);
              } else {
                formData[item.key] = result;
              }
              event.change({ key: item.key, value: e });
            }}
            {...item.attr}
          />
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.number:
      if (item.disabled || item.attr?.disabled) {
        return textDetail(formData[item.key]);
      }
      return (
        <el-space>
          <el-input
            type="number"
            v-model={formData[item.key]}
            placeholder={item.placeholder ?? defaultInputPlaceholder}
            onChange={(e: string) => event.change({ key: item.key, value: e })}
            {...item.attr}
          />
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.radio:
      if (item.disabled || item.attr?.disabled) {
        return optionDetail(formData[item.key], item.options);
      }
      Reflect.deleteProperty(item.attr?.style, 'width');
      return (
        <el-radio-group v-model={formData[item.key]} {...item.attr}>
          {item.options?.map((i) => (
            <el-radio
              label={i.value}
              disabled={i.disabled}
              onChange={(e: string) => event.change({ key: item.key, value: e })}
              {...item.attr}
            >
              {i.label}
            </el-radio>
          ))}
        </el-radio-group>
      );
    case InputType.checkbox:
      if (typeof formData[item.key] === 'string') {
        try {
          // 尝试着把数组字符串转回去。失败的话就什么都不管
          formData[item.key] = JSON.parse(formData[item.key] as string);
        } catch (e) {
          // nothing
        }
      }
      if (item.disabled || item.attr?.disabled) {
        return optionDetail(formData[item.key], item.options);
      }
      Reflect.deleteProperty(item.attr?.style, 'width');
      return (
        <el-checkbox-group
          v-model={formData[item.key]}
          onChange={(e: string) => event.change({ key: item.key, value: e })}
          {...item.attr}
        >
          {item.options?.map((i) => (
            <el-checkbox label={i.value} diabled={i.disabled} {...item.attr}>
              {i.label}
            </el-checkbox>
          ))}
        </el-checkbox-group>
      );
    case InputType.select:
      if (item.disabled || item.attr?.disabled) {
        return optionDetail(formData[item.key], item.options, item.params?.unit);
      }
      if (item.options && Array.isArray(item.options) && item.options.length === 1) {
        formData[item.key] = item.options[0].value;
      }
      return (
        <el-space>
          <el-select
            v-model={formData[item.key]}
            filterable
            placeholder={item.placeholder ?? defaultSelectPlaceholder}
            onChange={(e: string) => event.change({ key: item.key, value: e })}
            {...item.attr}
          >
            {item.options?.map((v) => (
              <el-option key={v.value} label={v.label} value={v.value} />
            ))}
          </el-select>
          <span>{item.params?.unit}</span>
          {item?.actions?.map((s) => {
            return (
              <el-button type="text" onClick={() => event.actionPlay?.(item, s)}>
                {s.label}
              </el-button>
            );
          })}
        </el-space>
      );
    case InputType.multipleSelect:
      if (!Array.isArray(formData[item.key])) {
        try {
          const arr = JSON.parse(formData[item.key]);
          if (Array.isArray(arr)) {
            formData[item.key] = arr;
          } else {
            formData[item.key] = [];
          }
        } catch (e) {
          formData[item.key] = [];
        }
      }
      if (item.disabled || item.attr?.disabled) {
        return (
          <el-space>
            {formData[item.key].map((v: string) => {
              return <el-tag type="info">{v}</el-tag>;
            })}
          </el-space>
        );
      }
      return (
        <el-space>
          <el-select
            v-model={formData[item.key]}
            filterable
            multiple
            placeholder={item.placeholder ?? defaultSelectPlaceholder}
            onChange={(e: string[]) => {
              event.change({ key: item.key, value: e });
            }}
            {...item.attr}
          >
            {item.options?.map((v) => (
              <el-option key={v.value} label={v.label} value={v.value} />
            ))}
          </el-select>
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.searchSelect:
      return searchSelect(item, formData, event.change);
    case InputType.date:
      if (item.disabled || item.attr?.disabled) {
        if (Number(formData[item.key]) < 2649600000) {
          formData[item.key] *= 1000;
        }
        return timeDetail(item, formData[item.key]);
      }
      return (
        <el-space>
          <el-date-picker
            type="date"
            v-model={formData[item.key]}
            placeholder={item.placeholder ?? defaultSelectPlaceholder}
            onChange={(e: string) => event.change({ key: item.key, value: e })}
            disabledDate={item.params?.disabledDate?.[0] ?? ''}
            {...item.attr}
          />
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.dateTime:
      if (item.disabled || item.attr?.disabled) {
        if (Number(formData[item.key]) < 2649600000) {
          formData[item.key] *= 1000;
        }
        return timeDetail(item, formData[item.key]);
      }
      return (
        <el-space>
          <el-date-picker
            type="datetime"
            v-model={formData[item.key]}
            placeholder={item.placeholder ?? defaultSelectPlaceholder}
            onChange={(e: string) => event.change({ key: item.key, value: e })}
            {...item.attr}
          />
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.switch:
      formData[item.key] = Boolean(Number(formData[item.key]));
      if (item.disabled || item.attr?.disabled) {
        return textDetail(formData[item.key] ? '是' : '否');
      }
      return (
        <el-switch
          v-model={formData[item.key]}
          onChange={(e: string) => event.change({ key: item.key, value: e })}
          {...item.attr}
        />
      );
    case InputType.textArea:
      if (formData[item.key] && typeof formData[item.key] === 'object') {
        formData[item.key] = JSON.stringify(formData[item.key]);
      }
      if (item.disabled || item.attr?.disabled) {
        return textDetail(formData[item.key]);
      }
      return (
        <el-space>
          <el-input
            type="textarea"
            maxlength={item.attr?.maxLength || ''}
            show-word-limit
            autosize={{ minRows: 4, maxRows: 6 }}
            input-style={{
              paddingBottom: '20px'
            }}
            v-model={formData[item.key]}
            placeholder={item.placeholder ?? defaultInputPlaceholder}
            onChange={(e: string) => event.change({ key: item.key, value: e })}
            {...item.attr}
          />
          <span>{item.params?.unit}</span>
        </el-space>
      );
    case InputType.daterange:
      if (item.disabled || item.attr?.disabled) {
        if (Number(formData[item.key][0]) < 2649600000) {
          formData[item.key][0] *= 1000;
        }
        if (Number(formData[item.key][1]) < 2649600000) {
          formData[item.key][1] *= 1000;
        }
        return timeDetail(item, formData[item.key]);
      }
      return dateRangePicker(item, formData, event.change);
    case InputType.uploadImg:
      return uploadImg(item, formData);
    case InputType.uploadFile:
      return uploadFile(item, formData);
    case InputType.area:
      return areaChoose(item, formData, event.change);
    case InputType.address:
      return addressChoose(item, formData, event.change);
    case InputType.qualificationDef:
      return qualificationDef(item, formData, event.change);
    case InputType.richText:
      return richText(item, formData, event.change);
    case InputType.expiredDate:
      return expiredDate(item, formData, event.change);
    case InputType.freightTemplateInfo:
      return freightTemplateInfo(item, formData, event.change);
    case InputType.slot:
      if (item.slotName) {
        return (
          slots[item.slotName]?.({
            modelValue: formData[item.key],
            config: item,
            disabled: item.disabled,
            formData: readonly(formData),
            formModuleEvents: event.formModuleEvents,
            linkPlay: (businessData: Record<string, any>) => {
              event.businessDialogUsePlayRule?.(item, businessData);
            },
            change: (value: unknown, change = false) => {
              formData[item.key] = value;
              if (change) {
                event.change({ key: item.key, value: value });
              }
            }
          }) ?? null
        );
      }
      return null;
    default:
      return deafult();
  }
};

export default buildItem;
