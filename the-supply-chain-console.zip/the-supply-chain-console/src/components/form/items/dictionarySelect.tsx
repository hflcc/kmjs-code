import { FormItem } from '@/components/form/type';

/**
 * 根据指定的字典表名去自动查询选项的select
 * */
