/**
 * 公共选择器的模版,
 * 处理选中，反选，多选的公共逻辑，外部传入表格的配置即可
 * */

import { defineComponent, PropType, ref, watch } from 'vue';
import { formatterEmptyUrl, formatterStrByObj, useDialog } from '@/utils';
import kmjsModule, { ModuleCtl, useModule } from '@/components/modules/module/code';
import { TableConfig } from '@/components/table/kmjsTableType';
import './index.less';
import { isEqual, unionWith } from 'lodash';

interface BusinessData extends Record<string, string | boolean> {
  _isChecked: boolean;
  _isDisable: boolean;
}

export interface CommBusinessDialog {
  closeWindow: () => void;
}

export default defineComponent({
  name: 'comm-business-dialog',
  props: {
    // 是否显示弹窗
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 配置项
    params: {
      type: Object as PropType<ResSteButtons>,
      required: true
    },
    // 外部表格数据的主key集合
    tableData: {
      type: Object as PropType<{
        snKey: string;
        snArr: string[];
        tableData: Array<Record<string, any>>;
        formToBusinessKeyMapping: Record<string, string>;
      }>,
      required: true
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 部分业务接口请求，根据不同的场景，有一个默认的入参数，在这里提供，需加入请求接口中
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    },
    // 表格的配置文件
    tableConfig: {
      type: Object as PropType<TableConfig>,
      required: true
    },
    // 显示已选中的name的业务数据key
    nameKey: {
      type: String as PropType<string>,
      default: 'name'
    },
    dataFormatter: {
      type: Function as PropType<(methods: BusinessData[]) => BusinessData[]>
    },
    // 是否发送需要过滤的请求入参
    isFilter: {
      type: Boolean as PropType<boolean>,
      default: true
    }
  },
  components: {
    kmjsModule
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit }) {
    // 这里主要是对比主键，主键可以确认是字符串类型
    let tableData: BusinessData[] = [];
    // false 多选
    // true 单选
    let selectModel = false;
    // 记录数据的主key，来自于 props.tableData.snKey
    let snKeyName = '';
    // 记录当前用户已经选择的数据的主key, 一般会是一个字符串的
    const activeData = ref<{ name: string; value: string }[]>([]);
    // 记录已选数据
    const activeBusinessData = new Map<string, Record<string, unknown>>();
    // 渲染表格的配置
    const moduleCtl = ref<ModuleCtl | null>(null);
    // 方法收集
    let methods: { [moduleName: string]: (...argus: any) => any };
    /**
     * 表格数据选中或反选中时处理
     * */
    const changeCheckbox = (data: { data: Record<string, string>; checked: boolean }) => {
      if (data.checked) {
        // 单选模式下,选中一个需要将其他选中的置为不选中;
        if (selectModel && methods['/table/setCheckDisabled']) {
          tableData.forEach((s, i) => {
            if (s[snKeyName] !== data.data[snKeyName]) {
              methods['/table/setCheckDisabled'](i, false, false);
            }
          });
        }
        buildData();
        activeBusinessData.set(data.data[snKeyName], data.data);
      } else {
        // 当前操作数据,是否在选中数据里面;
        const index = activeData.value.findIndex((s) => s.value === data.data[snKeyName]);
        if (index === -1) return;
        activeData.value.splice(index, 1);
      }
    };
    /**
     * 表格内部修改数据时，部分字段响应丢失，在这里进行下同步更新
     * */
    const buildData = () => {
      const data = methods['/table/getCheckData']?.();
      data.forEach((k: BusinessData) => {
        const index = activeData.value.findIndex((s) => s.value === k[snKeyName]);
        if (index === -1) {
          activeData.value.push({
            name: k[props.nameKey] as string,
            value: k[snKeyName] as string
          });
          return;
        }
      });
    };
    // 每次展示的时候渲染表格
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        snKeyName = props.tableData.snKey;
        selectModel = props.params?.params?.selectMode === 'single';
        const [ctl, med] = useModule({
          config: [
            {
              type: 'table',
              name: 'table',
              params: props.tableConfig
            }
          ],
          params: {
            '/table': {
              beforeRequest: (requestObj: { url: string; params: any }) => {
                if (Object.keys(props.requestData).length) {
                  const value = Object.values(props.requestData).findIndex(
                    (s) => s === null && typeof s === 'undefined'
                  );
                  if (value > -1) {
                    return Promise.resolve(null);
                  }
                  Object.assign(requestObj.params, props.requestData);
                  if (props.isFilter) {
                    requestObj.params['filterSns'] = props.tableData.snArr?.join(',') ?? '';
                  }
                  requestObj.url = formatterStrByObj(requestObj.url, props.requestData);
                }
                // 判断是否还有未转义的字符
                if (requestObj.url.indexOf('${') >= 0) {
                  requestObj.url = formatterEmptyUrl(requestObj.url);
                }
                return Promise.resolve(requestObj);
              },
              dataFormatter: (data: BusinessData[]) => {
                // 数据有些需要拍平
                if (props.dataFormatter) {
                  data = props.dataFormatter(data);
                }
                tableData = data;
                return data.map((s) => {
                  // 翻页时选中数据
                  s._checked = Boolean(
                    activeData.value.find((k) => k.value === (s[snKeyName] as string))
                  );
                  return s;
                });
              }
            }
          },
          handler: (moduleName, name, data) => {
            switch (moduleName + '_' + name) {
              case '/table_tableCheckboxChange':
                changeCheckbox(data[0]);
                break;
              case '/table_tableTriggerCheckAll':
                if (selectModel) {
                  if (data[0][0].checked) {
                    changeCheckbox(data[0][0]);
                  } else {
                    tableData.forEach((s, i) => {
                      methods['/table/setCheckDisabled']?.(i, false, false);
                    });
                    activeData.value = [];
                  }
                } else {
                  if (data[0][0].checked) {
                    const list = tableData.map((item) => {
                      activeBusinessData.set(
                        item[snKeyName] as string,
                        item as Record<string, string>
                      );
                      return {
                        name: item[props.nameKey] as string,
                        value: item[snKeyName] as string
                      };
                    });
                    // 需要去重，已选择的
                    activeData.value = unionWith(activeData.value, list, isEqual);
                  } else {
                    // activeData.value = [];
                    // 去除当前页的全选，找到已选的 去除
                    clearActiveData();
                  }
                }
                break;
            }
          }
        });
        moduleCtl.value = ctl;
        methods = med;
      } else {
        moduleCtl.value = null;
      }
    });
    // 关闭弹窗,清空已选数据
    watch(
      () => showDialog.value,
      (newValue: boolean) => {
        if (!newValue) {
          clearActiveData();
        }
      }
    );
    // 去除当前页的全选，找到已选的 去除
    const clearActiveData = () => {
      tableData.forEach((item) => {
        const index = activeData.value.findIndex((s) => s.value === (item[snKeyName] as string));
        if (index === -1) return;
        activeData.value.splice(index, 1);
      });
    };
    const getData = () => {
      // const data = methods['/table/getCheckData']?.();
      const list = activeData.value.map((item) => {
        const r = activeBusinessData.get(item.value);
        if (r) {
          r['_checked'] = false;
        }
        return r;
      });
      emit('getValue', list);
    };

    const closeTag = (tag: { name: string; value: string }) => {
      const i = tableData.findIndex((item) => (item[snKeyName] as string) === tag.value);
      if (i !== -1) {
        methods['/table/setCheckDisabled']?.(i, false, false);
      }
    };
    return {
      moduleCtl,
      showDialog,
      closeWindow,
      getData,
      activeData,
      closeTag
    };
  },
  render() {
    const { params, moduleCtl, showDialog, closeWindow, getData, activeData, closeTag } = this;
    const slots = this.$slots;
    const formMdule = moduleCtl ? <kmjsModule ctl={moduleCtl}></kmjsModule> : null;
    return (
      <el-dialog
        width={'80vw'}
        v-model={showDialog}
        onClose={closeWindow}
        title={params.title}
        destroy-on-close
        top={'10vh'}
        v-slots={{
          footer: () => {
            return (
              <el-space>
                {slots.preButton?.()}
                <el-button onClick={closeWindow}>取消</el-button>
                <el-button type={'primary'} onClick={getData}>
                  确认
                </el-button>
              </el-space>
            );
          }
        }}
      >
        <div style={{ height: '65vh', width: '100%' }}>{formMdule}</div>
        {activeData.length > 0 ? (
          <div class="value-area">
            <h4 class="value-area-title">已选</h4>
            <el-space style={{ flexWrap: 'wrap' }}>
              {activeData.map((item) => {
                return (
                  <el-tag
                    closable={true}
                    onClose={() => closeTag(item)}
                    style={{ marginBottom: '8px' }}
                  >
                    {item.name}
                  </el-tag>
                );
              })}
            </el-space>
          </div>
        ) : (
          ''
        )}
      </el-dialog>
    );
  }
});
