import { defineComponent, onMounted, onUnmounted, PropType, reactive, ref } from 'vue';
import './style.less';
import { goToCreateBpmByBusiness, goToFormDetail } from '@/pages/commonPage';
import { createBpmByDefSn, getBpmAlertMsg } from '@/utils/commApi';
import { ElMessageBox } from 'element-plus';
import useOrganization from '@/store/commModules/organization/useOrganization';
import tim from '@/utils/tim';

export default defineComponent({
  name: 'form-submit-result',
  props: {
    data: {
      type: Object as PropType<{ data: SubmitResultData; isSuccess: boolean }>,
      default: () => ({
        isSuccess: false,
        title: '',
        subTitle: '',
        data: [],
        action: []
      })
    },
    closeTab: {
      type: Function as PropType<() => void>,
      default: () => {
        // nothing
      }
    },
    showCountdown: {
      type: Boolean as PropType<boolean>,
      default: true
    }
  },
  setup(props) {
    const { activeOrgan } = useOrganization();
    const renderData = ref(props.data);
    const time = ref(10);
    let timeout: number;
    const staticBpm = (bpmDefSn: string, businessSn: string) => {
      getBpmAlertMsg(bpmDefSn, businessSn).then((res) => {
        if (!res) return;
        if (res.success) {
          ElMessageBox.confirm(res.title, '提示').then(() => {
            createBpmByDefSn(bpmDefSn as string, {
              bizSn: businessSn as string,
              createdOrgTreeSn: activeOrgan.value?.sn || '',
              createdOrgTreeName: activeOrgan.value?.name || ''
            }).then((res) => {
              if (!res) return;
              renderData.value = {
                isSuccess: res.success,
                data: {
                  data: res.data,
                  title: res.title,
                  subTitle: res.subTitle,
                  action: [
                    {
                      type: 'close',
                      name: '关闭页面'
                    }
                  ]
                }
              };
              if (props.showCountdown) {
                time.value = 10;
                timeout = setInterval(timeSub, 1000);
              }
            });
          });
        } else {
          ElMessageBox.alert(res.title);
        }
      });
    };
    const bpmWindowConfig = reactive({
      type: '',
      businessSn: ''
    });
    const showBpmWindow = ref(false);
    /**
     * 隐藏流程类型选择弹窗
     * */
    const hideBpmWindow = () => {
      showBpmWindow.value = false;
    };
    /**
     * 获取用户在弹窗中选择的流程SN，并根据是否需要跳转页面来判断是否跳转页面还是直接发起流程
     * */
    const getBpmSn = (bpmSn: string) => {
      hideBpmWindow();
      staticBpm(bpmSn, bpmWindowConfig.businessSn);
    };
    const play = (s: SubmitResultAction) => {
      switch (s.type) {
        case 'bpm':
          if (s.bpmDefSn && s.businessSn) {
            timeout && clearInterval(timeout);
            staticBpm(s.bpmDefSn, s.businessSn);
          }
          break;
        case 'bpmPopup':
          if (s.businessSn && s.bpmType) {
            bpmWindowConfig.businessSn = s.businessSn;
            bpmWindowConfig.type = s.bpmType;
            showBpmWindow.value = true;
            timeout && clearInterval(timeout);
          }
          break;
        case 'close':
          clearInterval(timeout);
          props.closeTab();
          break;
        case 'detail':
          if (s.businessSn && s.formDefSn) {
            goToFormDetail(s.formDefSn, s.businessSn);
          }
          break;
      }
    };
    const timeSub = () => {
      time.value--;
      if (time.value <= 0) {
        props.closeTab();
        clearInterval(timeout);
      }
    };
    onMounted(() => {
      if (props.showCountdown) {
        timeout = setInterval(timeSub, 1000);
      }
    });
    onUnmounted(() => {
      timeout && clearInterval(timeout);
    });
    return () => {
      const { data, isSuccess } = renderData.value;
      if (!data) {
        return (
          <el-result
            title={`提交${isSuccess ? '成功' : '失败'}`}
            icon={isSuccess ? 'success' : 'error'}
            sub-title={''}
            v-slots={{
              extra: () => {
                return (
                  <div>
                    <el-button
                      type="close"
                      onClick={() => play({ type: 'close' } as SubmitResultAction)}
                    >
                      关闭
                    </el-button>
                    <div class="gap-40"></div>
                    {props.showCountdown ? (
                      <p style={{ color: '#999' }}>{time.value}秒后自动关闭</p>
                    ) : null}
                  </div>
                );
              }
            }}
          />
        );
      }
      return (
        <>
          <el-result
            title={data.title ?? `提交${isSuccess ? '成功' : '失败'}`}
            icon={isSuccess ? 'success' : 'error'}
            sub-title={data.subTitle ?? ''}
            v-slots={{
              extra: () => {
                if (data) {
                  return (
                    <div class="form-submit-result-data">
                      <table cellpadding={0} cellspacing={0}>
                        <tbody>
                          {data.data?.map((s) => (
                            <tr>
                              <td>{s.label}</td>
                              <td>{s.value}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      <div class="gap-40"></div>
                      <el-spaces>
                        {data.action?.map((s) => {
                          return (
                            <el-button
                              type={s.type === 'close' ? 'default' : 'primary'}
                              onClick={() => play(s)}
                            >
                              {s.name}
                            </el-button>
                          );
                        })}
                      </el-spaces>
                      <div class="gap-40"></div>
                      {props.showCountdown ? (
                        <p style={{ color: '#999' }}>{time.value}秒后自动关闭</p>
                      ) : null}
                    </div>
                  );
                } else {
                  return (
                    <div>
                      <el-button
                        type="close"
                        onClick={() => play({ type: 'close' } as SubmitResultAction)}
                      >
                        关闭
                      </el-button>
                      <div class="gap-40"></div>
                      {props.showCountdown ? (
                        <p style={{ color: '#999' }}>{time.value}秒后自动关闭</p>
                      ) : null}
                    </div>
                  );
                }
              }
            }}
          />
          <kmjs-create-bpm-before
            v-model={showBpmWindow.value}
            onGetValue={getBpmSn}
            onCloseDialog={hideBpmWindow}
            bpmType={bpmWindowConfig.type}
          />
        </>
      );
    };
  }
});
