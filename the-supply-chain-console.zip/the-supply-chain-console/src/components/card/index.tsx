import { defineComponent, PropType } from 'vue';

export default defineComponent({
  name: 'kmjs-card',
  props: {
    params: {
      type: Object as PropType<{ title: string }>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      required: true
    }
  },
  render() {
    const { params } = this;
    return (
      <div class="kmjs-card">
        <div class="title">{params.title}</div>
        <div class="content">{this.$slots.default?.()}</div>
      </div>
    );
  }
});
