<script lang="tsx">
  import { defineComponent, ref, PropType, watch } from 'vue';
  import { getFileUrlBySeq, uploadFile as uploadAjax } from '@/utils/commApi';

  export default defineComponent({
    name: 'UploadImg',
    props: {
      imgInfo: {
        type: Object as PropType<{ name: string; ossId: string; url: string }>,
        default: () => {
          return {
            name: '',
            ossId: '',
            url: ''
          };
        }
      },
      // 允许访问的文件类型
      inputAccept: {
        type: String as PropType<string>,
        default: 'image/*'
      }
    },
    emits: ['view-img', 'remove', 'finish'],
    setup(props, { emit }) {
      const currentImg = ref(props.imgInfo);
      const fileInput = ref<HTMLInputElement | null>(null);

      // 查看大图/文件
      function imgBigView() {
        emit('view-img', currentImg.value.url);
      }

      function addFile() {
        fileInput.value?.click();
      }

      // 删除操作
      function removeImg() {
        (fileInput.value as HTMLInputElement).value = '';
        // 删除图片
        currentImg.value = {
          ossId: '',
          url: '',
          name: ''
        };
        emit('remove');
      }

      // 上传文件
      const uploadFile = async (file: File, path?: string) => {
        const res = await uploadAjax(file as File, path);
        if (res) {
          currentImg.value.ossId = res.seq;
          emit('finish', res.seq);
        }
      };

      // 将图片文件转成BASE64格式
      function html5Reader(file: File) {
        const reader = new FileReader();
        reader.onload = function () {
          // base64 临时图片url
          currentImg.value.url = reader.result as string;

          uploadFile(file as File);
        };
        reader.readAsDataURL(file);
      }

      function fileChanged() {
        const list = fileInput.value?.files;
        for (let i = 0; i < (list as FileList).length; i++) {
          html5Reader((list as FileList)[i]);
        }
        (fileInput.value as HTMLInputElement).value = '';
      }

      async function getImgUrl(seq: string) {
        const res = await getFileUrlBySeq(seq);
        if (res) {
          currentImg.value.url = res[seq] && res[seq].url;
        }
      }

      watch(
        () => props.imgInfo.ossId,
        (nv) => {
          getImgUrl(nv);
        },
        {
          immediate: true
        }
      );

      return {
        fileInput,
        currentImg,
        imgBigView,
        removeImg,
        addFile,
        fileChanged
      };
    },
    render() {
      const { currentImg, imgBigView, removeImg, fileChanged, inputAccept, addFile } = this;

      return (
        <div class="uploader">
          <div
            class="file"
            onClick={(event: MouseEvent) => {
              event.stopPropagation();
              imgBigView();
            }}
          >
            <img v-show={currentImg.url} src={currentImg.url} onDragstart={() => false} />
            <div v-show={!currentImg.url} onClick={addFile} class="add-file">
              <i class="icon el-icon-plus"></i>
            </div>
            <i
              v-show={currentImg.url}
              class="icon el-icon-close file-remove"
              onClick={(event: MouseEvent) => {
                event.stopPropagation();
                removeImg();
              }}
            ></i>
          </div>
          <input ref="fileInput" type="file" onChange={fileChanged} accept={inputAccept} />
        </div>
      );
    }
  });
</script>

<style lang="less">
  .uploader {
    .file {
      position: relative;
      width: 50px;
      height: 50px;
      text-align: center;
      margin-right: 25px;
      border: 1px solid #dcdfe6;
      background-color: #fff;
      cursor: pointer;
      &:hover .file-remove {
        display: inline;
      }
      img {
        width: 100%;
        height: 100%;
      }
      .file-remove {
        position: absolute;
        top: 0;
        right: 0;
        display: none;
        color: #ddd;
        cursor: pointer;
        background: rgba(0, 0, 0, 0.5);
      }
    }
    .add-file {
      width: 50px;
      height: 50px;
      text-align: center;
      line-height: 50px;
      cursor: pointer;
    }
    input[type='file'] {
      display: none;
    }
  }
</style>
