import ajax from '@/utils/axios';

export interface CategoryItem {
  name: string;
  sn: string;
  items: Array<{
    name: string;
    ossId: string;
    sn: string;
    goodsSns: string[];
    [key: string]: string | string[];
  }>;
  [key: string]: string | CategoryItem['items'];
}
export interface CategoryInfo {
  name: string;
  sn: string;
  ossId: string;
  items: CategoryItem[];
  [key: string]: string | CategoryItem[];
}

interface Category {
  name: string;
  sn: string;
}
export interface ShopCategory {
  name: string;
  sn: string;
  value: Array<{
    name: string;
    sn: string;
    value: Array<Category>;
  }>;
}

/**
 * 获取分类信息
 */
export const getClassifyInfo = (defSn: string): Promise<CategoryInfo[]> => {
  return ajax.get(`/auth/md/common/shop/category/preview/${defSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 获取店铺类目
 */
export const getShopCategory = (shopSn: string): Promise<ShopCategory[]> => {
  return ajax.get(`/auth//md/shop/category/${shopSn}`, {
    params: {
      $InstId: true
    }
  });
};
