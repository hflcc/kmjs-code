<template>
  <div class="classify-container">
    <div class="classify__left">
      <LeftPanel
        v-model="currentIndex"
        :errorCount="errorCount"
        :list="firstCategory"
        @deleteItem="deleteItem"
        @changeOriginal="changeOriginal"
        @categoryChange="categoryChange"
        @addData="addData"
        @changeName="changeName"
      />
    </div>
    <div class="classify__right">
      <el-form ref="formElem" :model="tableForm" size="mini" @submit.prevent>
        <el-table
          :data="tableForm.tableData"
          border
          :default-expand-all="true"
          @expand-change="expandChange"
          style="width: 100%; margin-bottom: 20px"
        >
          <el-table-column type="expand" min-width="7%">
            <template v-slot="{ row, $index }" style="padding: 0px">
              <div :class="['expand-item']" v-for="(item, index) in row.items" :key="index">
                <div class="classify__right--input">
                  <el-form-item
                    :prop="`tableData.${$index}.items.${index}.name`"
                    :rules="tableForm.tableRule.name"
                  >
                    <el-input
                      class="w160"
                      maxlength="20"
                      v-model="item.name"
                      placeholder="请输入三级分类"
                    />
                  </el-form-item>
                </div>
                <div class="classify__right--img">
                  <el-form-item
                    :prop="`tableData.${$index}.items.${index}.ossId`"
                    :rules="tableForm.tableRule.ossId"
                  >
                    <uploadImg
                      style="margin-top: 2px"
                      :key="`tableData.${$index}.items.${index}.ossId`"
                      :img-info="{ name: '', ossId: row.items[index].ossId, url: '' }"
                      @remove="
                        (params) =>
                          remove({
                            items: row.items,
                            index,
                            field: `tableData.${$index}.items.${index}.ossId`
                          })
                      "
                      @finish="
                        (params) =>
                          finish({
                            seq: params,
                            items: row.items,
                            index,
                            field: `tableData.${$index}.items.${index}.ossId`
                          })
                      "
                    />
                  </el-form-item>
                </div>
                <div class="classify__right--good">
                  <el-form-item
                    :prop="`tableData.${$index}.items.${index}.goodsSns`"
                    :rules="tableForm.tableRule.goodsSns"
                  >
                    <div @click="selectGoods(row.items, $index, index)">
                      <span class="tip">&plus; 关联宝贝</span>
                      <span class="count">{{ getCount(row.items[index].goodsSns) }}</span>
                    </div>
                  </el-form-item>
                </div>
                <div class="classify__right--operation">
                  <i
                    class="el-icon-top icon"
                    :style="{ color: index === 0 ? '#eee' : '' }"
                    @click="handleMoveUp({ index, flag: true, data: row.items })"
                  />
                  <i
                    class="el-icon-bottom icon"
                    :style="{ color: index === row.items.length - 1 ? '#eee' : '' }"
                    @click="handleMoveDown({ index, flag: true, data: row.items })"
                  />
                  <i
                    class="el-icon-delete icon"
                    :style="{ color: index === 0 ? '#eee' : '' }"
                    @click="handleDelete({ index, flag: true, data: row.items })"
                  />
                </div>
              </div>
              <div class="expand-item expand-item-add">
                <el-button type="primary" size="mini" @click="addThirdData(row.items)"
                  >新增三级分类</el-button
                >
              </div>
            </template>
          </el-table-column>

          <el-table-column label="分类名称" min-width="34%">
            <template v-slot="{ row, $index }">
              <!-- fix: 不知道为什么会出现 -1 的下标 -->
              <el-form-item
                v-if="$index >= 0"
                :prop="`tableData.${$index}.name`"
                :rules="tableForm.tableRule.name"
              >
                <el-input
                  class="w160"
                  maxlength="20"
                  v-model="row.name"
                  placeholder="请输入二级分类"
                />
                <el-button
                  class="table-button"
                  v-if="$index === tableForm.tableData.length - 1"
                  type="primary"
                  size="mini"
                  @click="addSecondData()"
                  >新增二级分类</el-button
                >
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column label="分类图片" min-width="20%" />
          <el-table-column label="关联宝贝" min-width="23%" />
          <el-table-column label="操作" min-width="16%">
            <template v-slot="{ $index }">
              <el-button
                size="mini"
                :disabled="$index === 0"
                @click="handleMoveUp({ index: $index, data: tableForm.tableData })"
              >
                <i class="el-icon-top"></i>
              </el-button>
              <el-button
                size="mini"
                :disabled="$index === tableForm.tableData.length - 1"
                @click="handleMoveDown({ index: $index, data: tableForm.tableData })"
              >
                <i class="el-icon-bottom"></i>
              </el-button>
              <el-button
                size="mini"
                :disabled="tableForm.tableData.length === 1"
                type="danger"
                @click="handleDelete({ index: $index, data: tableForm.tableData })"
              >
                <i class="el-icon-delete"></i>
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
    </div>

    <!-- 商品选择器 -->
    <goodsSelect
      v-model="showGoodSelect"
      :renderData="{ category: category }"
      :goodsSns="currentGoodsSns"
      :shopSn="shopSn"
      @getValue="getSelectValue"
    />
  </div>
</template>

<script lang="ts">
  import { defineComponent, nextTick, onMounted, reactive, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import uploadImg from '@/components/classify/uploadImg.vue';
  import LeftPanel from '@/components/classify/leftPanel.vue';
  import useOperaction from '@/components/classify/useOperation';
  import goodsSelect, { GoodItem } from '@/components/classify/component/index';
  import {
    CategoryInfo,
    CategoryItem,
    getClassifyInfo,
    getShopCategory,
    ShopCategory
  } from '@/components/classify/api';

  export default defineComponent({
    name: 'classify',
    components: {
      LeftPanel,
      uploadImg,
      goodsSelect
    },
    setup() {
      const {
        moveUp,
        moveDown,
        checkData,
        errorCount,
        tableForm,
        formElem,
        firstCategory,
        allCategory
        // validateField
      } = useOperaction();

      const currentIndex = ref<number>(0);

      function titleClick(index: number) {
        currentIndex.value = index;
      }

      function deleteItem(index: number) {
        allCategory.value.splice(index, 1);

        // 不管删除哪一条数据，直接重置成当前数据的第一项
        tableForm.tableData = allCategory.value[0].items;
        validate();
      }

      // 表单展开的时候触发验证
      function expandChange() {
        nextTick(() => {
          formElem.value?.validate();
        });
      }

      function handleMoveUp(params: { index: number; flag: false; data: unknown[] }) {
        if (!params.flag && params.index > 0) {
          // 如果不是第一条数据，往上移动
          moveUp(params, () => formElem.value?.clearValidate());
        } else if (params.flag && params.index > 0) {
          moveUp(params, () => formElem.value?.clearValidate());
        }
        validate();
      }

      function handleMoveDown(params: { index: number; flag: false; data: unknown[] }) {
        if (!params.flag && params.index + 1 !== tableForm.tableData.length) {
          // 如果当前数据不是最后一条，往下移动
          moveDown(params, () => formElem.value?.clearValidate());
        } else if (params.flag && params.index + 1 !== params.data.length) {
          moveDown(params, () => formElem.value?.clearValidate());
        }
        validate();
      }

      function handleDelete(params: { index: number; flag: false; data: unknown[] }) {
        if (!params.flag) {
          tableForm.tableData.splice(params.index, 1);
        } else {
          if (params.data.length < 2) {
            return false;
          }
          allCategory.value.splice(params.index, 1);
          params.data.splice(params.index, 1);
        }
        validate();
      }

      // 新增三级数据
      function addThirdData(data: CategoryItem['items']) {
        data.push({ sn: '', name: '', ossId: '', goodsSns: [] });
        validate();
      }

      // 新增二级数据
      function addSecondData() {
        allCategory.value[currentIndex.value].items.push({
          sn: '',
          name: '',
          items: [
            {
              name: '',
              sn: '',
              ossId: '',
              goodsSns: []
            }
          ]
        });
        tableForm.tableData = allCategory.value[currentIndex.value].items;
        validate();
      }

      // 数组元素交换位置
      function swapArray(arr: CategoryInfo[], index1: number, index2: number) {
        let temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
        return arr;
      }

      // 移动数据
      function changeOriginal(origin: { oldIndex: number; newIndex: number }, flag: string) {
        if (!flag) {
          swapArray(allCategory.value, origin.oldIndex, origin.newIndex);
        } else if (flag === 'pop') {
          allCategory.value.unshift(allCategory.value.pop() as CategoryInfo);
        } else if (flag === 'shift') {
          allCategory.value.push(allCategory.value.shift() as CategoryInfo);
        }

        // 改变位置之后重新赋值当前的数据
        tableForm.tableData = allCategory.value[origin.newIndex].items;
        validate();
      }

      // 点击切换分类
      function categoryChange(index: number) {
        if (index > allCategory.value.length - 1) {
          allCategory.value.push({
            sn: '',
            name: '',
            ossId: '',
            items: [
              {
                name: '',
                sn: '',
                items: [{ name: '', ossId: '', sn: '', goodsSns: [] }]
              }
            ]
          });
        }
        tableForm.tableData = allCategory.value[index].items;
        validate();
      }

      // 左侧输入完成之后，新增右侧数据
      function addData(value: string) {
        allCategory.value.push({
          sn: '',
          name: value,
          ossId: '',
          items: [
            {
              name: '',
              sn: '',
              items: [{ name: '', ossId: '', sn: '', goodsSns: [] }]
            }
          ]
        });
      }

      function changeName(value: string, index: number) {
        nextTick(() => {
          allCategory.value[index].name = value;
        });
      }

      function getCount(data: string[]) {
        return data && data.length ? data.length : 0;
      }

      // 选择商品
      const selectIndex = ref<{ start: number; end: number }>({ start: 0, end: 0 });
      const category = reactive<ShopCategory[]>([]);
      const currentGoodsSns = ref<string[]>([]);

      function selectGoods(items: CategoryItem['items'], $index: number, index: number) {
        currentGoodsSns.value = items[index].goodsSns ?? [];
        selectIndex.value = { start: $index, end: index };
        showGoodSelect.value = true;
      }

      function getSelectValue(selectData: GoodItem[]) {
        const goodsSns = selectData.length && selectData.map((item) => item.sn);
        tableForm.tableData[selectIndex.value.start].items[selectIndex.value.end].goodsSns =
          goodsSns as string[];
        showGoodSelect.value = false;
        validate();
      }

      function remove(params: { items: CategoryItem['items']; index: number; field: string }) {
        params.items[params.index].ossId = '';
        // validateField(formElem.value, params.field);
        validate();
      }
      function finish(params: {
        seq: string;
        items: CategoryItem['items'];
        index: number;
        field: string;
      }) {
        params.items[params.index].ossId = params.seq;
        // validateField(formElem.value, params.field);
        validate();
      }

      const showGoodSelect = ref<boolean>(false);

      const route = useRoute();
      const defSn = route.query.defSn as string;
      const shopSn = route.query.shopSn as string;
      async function _getClassifyInfo() {
        const res = await getClassifyInfo(defSn);
        if (res && res.length) {
          // 获取一级分类
          firstCategory.value = res.map((item) => {
            return {
              name: item.name,
              sn: item.sn,
              show: false
            };
          });
          allCategory.value = res;
          tableForm.tableData = allCategory.value[currentIndex.value].items;
          validate();
        }
      }

      function validate() {
        nextTick(() => {
          formElem.value?.validate();
          checkData();
        });
      }

      // 获取店铺类目（搜索项）
      function _getShopCategory() {
        getShopCategory(shopSn).then((res) => {
          category.push(...res);
        });
      }

      onMounted(async () => {
        await _getClassifyInfo();
        _getShopCategory();
      });

      // onActivated(async () => {
      //   await _getClassifyInfo();
      // });

      return {
        currentIndex,
        titleClick,
        deleteItem,
        tableForm,
        formElem,
        addSecondData,
        handleMoveUp,
        handleMoveDown,
        handleDelete,
        addThirdData,
        expandChange,
        errorCount,
        checkData,
        firstCategory,
        changeOriginal,
        categoryChange,
        addData,
        getCount,
        changeName,
        remove,
        finish,
        allCategory,
        showGoodSelect,
        category,
        selectGoods,
        getSelectValue,
        currentGoodsSns,
        shopSn
      };
    }
  });
</script>

<style lang="less">
  .classify {
    &-container {
      display: flex;
    }
    &__left {
      flex: 1;
    }
    &__right {
      display: inline-block;
      vertical-align: text-top;
      width: 98%;
      min-width: 900px;
      .table-button {
        display: inline-block;
        margin-left: 10px;
      }

      .expand-item {
        position: relative;
        width: 100%;
        height: 70px;
        line-height: 70px;
        padding-left: 20px;
        margin-left: 20px;
        padding-bottom: 10px;
        border-left: 1px solid #ebeef5;
        &:hover {
          background-color: #f5f7fa;
        }
        &:before {
          position: absolute;
          left: -1px;
          top: -32px;
          content: ' ';
          width: 1px;
          height: 32px;
          background-color: #ebeef5;
        }
        &:after {
          position: absolute;
          left: 0;
          top: 36px;
          content: ' ';
          width: 20px;
          height: 1px;
          background-color: #ebeef5;
        }
        + .expand-item {
          border-top: 1px solid #ebeef5;
        }
      }
      .expand-item-add {
        position: relative;
        padding-left: 20px;
        border-left: none;
        // 是剩下一个新增三级分类时按钮样式
        &:nth-last-child(1):first-child {
          &:before {
            content: ' ';
            position: absolute;
            top: -32px;
            left: 0px;
            height: 68px;
            width: 1px;
            background-color: #ebeef5;
          }
        }
        &:before {
          content: ' ';
          position: absolute;
          top: -1px;
          left: 0px;
          height: 36px;
          width: 1px;
          background-color: #ebeef5;
        }
        &:after {
          content: ' ';
          position: absolute;
          top: 35px;
          left: 0px;
          height: 1px;
          width: 20px;
          background-color: #ebeef5;
        }
      }

      &--input {
        display: inline-block;
        width: 34%;
      }
      &--img {
        display: inline-block;
        width: 20%;
        .img {
          display: inline-block;
          vertical-align: middle;
          width: 36px;
          height: 36px;
        }
      }
      &--good {
        display: inline-block;
        width: 23%;
        user-select: none;
        .tip {
          cursor: pointer;
          padding: 5px 8px;
          border: 1px solid #dcdfe6;
          border-top-left-radius: 4px;
          border-bottom-left-radius: 4px;
        }
        .count {
          padding: 5px 8px;
          border: 1px solid #dcdfe6;
          border-left-style: none;
          border-top-right-radius: 4px;
          border-bottom-right-radius: 4px;
          background-color: #f8f8f8;
        }
      }
      &--operation {
        display: inline-block;
        text-align: center;
        width: 15%;
        .icon {
          margin-left: 10px;
          font-size: 18px;
          color: #000;
          cursor: pointer;
        }
      }

      // el-form样式重置
      .el-form-item--mini.el-form-item,
      .el-form-item--small.el-form-item {
        margin-bottom: 12;
      }
    }
  }
  .el-table--border th,
  .el-table__fixed-right-patch {
    border-right: 0;
  }

  .el-table--border td,
  .el-table--border th,
  .el-table__body-wrapper .el-table--border.is-scrolling-left ~ .el-table__fixed {
    border-right: 0;
  }

  .el-table__expanded-cell[class*='cell'] {
    padding: 0 0 0 50px;
  }

  .el-table__body {
    width: 100%;
  }

  .w160 {
    width: 160px;
  }
</style>
