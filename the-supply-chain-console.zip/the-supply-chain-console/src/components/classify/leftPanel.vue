<template>
  <div class="left-container">
    <draggable-comp
      :list="currentList"
      :disabled="!enabled"
      :item-key="() => ''"
      class="list-group"
      moviing-class="moviing"
      handle=".move"
      :move="checkMove"
      @start="draggingStart"
      @end="draggingEnd"
    >
      <template #item="{ element, index }">
        <div
          :class="[
            'left-container__wrapper',
            index === currentIndex ? 'active' : '',
            element.name === '' ? 'error' : ''
          ]"
        >
          <!-- @keydown.enter="handleBlur($event, element, index)" -->
          <el-input
            class="left-container__input"
            style="width: 164px"
            :key="index"
            maxlength="20"
            placeholder="请输入一级分类名称"
            v-if="element.show"
            v-model="element.name"
            ref="inputEl"
            @input="handleInput($event, element, index)"
            @blur="handleBlur($event, element, index)"
          />
          <span
            class="left-container__text"
            :title="element.name"
            v-if="!element.show"
            @click="selectCategory(index)"
          >
            {{ element.name }}
          </span>
          <div class="left-container__operations">
            <i class="operation el-icon-edit" title="编辑" @click="handleEdit(index)"></i>
            <i class="operation el-icon-rank move" title="移动"></i>
            <!-- :style="{ color: currentList.length === 1 ? '#eee' : '' }" -->
            <i class="operation el-icon-delete" title="删除" @click="handleDelete(index)"></i>
          </div>
          <el-badge
            v-show="errorCount[index] && errorCount[index].count > 0"
            :value="(errorCount[index] && errorCount[index].count) || 0"
            type="danger"
            class="badge"
          />
        </div>
      </template>
    </draggable-comp>
    <el-button class="button" type="primary" size="mini" @click="handleAdd">新增一级分类</el-button>
  </div>
</template>

<script lang="ts">
  import { ElInput, ElMessage } from 'element-plus';
  import { defineComponent, nextTick, PropType, ref, watch } from 'vue';
  import DraggableComp from 'vuedraggable';
  import { isEmpty } from '@/utils/valid';

  interface MoveEvent<T> {
    dragged: HTMLDivElement;
    draggedContext: { element: T; index: number; futureIndex: number };
    [key: string]: unknown;
  }

  interface DraggableIndex {
    newDraggableIndex: number | undefined;
    newIndex: number | undefined;
    oldDraggableIndex: number;
    oldIndex: number;
    [key: string]: unknown;
  }

  interface Item {
    name: string;
    sn: string;
    show: boolean;
    // label?: string;
    isNew?: boolean; // 是否是新增加的元素
  }

  export default defineComponent({
    name: 'leftPanel',
    components: {
      DraggableComp
    },
    props: {
      modelValue: {
        type: Number as PropType<number>,
        default: 0
      },
      list: {
        type: Array as PropType<Item[]>,
        default: () => []
      },
      errorCount: {
        type: Array as PropType<{ count: number }[]>,
        default: () => []
      }
    },
    emits: [
      'deleteItem',
      'update:modelValue',
      'changeOriginal',
      'categoryChange',
      'addData',
      'changeName'
    ],
    setup(props, { emit }) {
      const currentList = ref<Item[]>([]);
      const moveStart = ref<number>(-1);
      const moveEnd = ref<number>(-1);

      const enabled = ref(true);
      // 当前选中的一级类目
      const currentIndex = ref<number>(0);

      const inputEl = ref<InstanceType<typeof ElInput> | null>(null);
      function handleAdd() {
        currentList.value.push({ show: true, name: '', sn: '', isNew: true });

        nextTick(() => {
          inputEl.value?.focus();
        });
      }
      function handleEdit(index: number) {
        currentList.value[index].show = !currentList.value[index].show;
      }

      function handleDelete(index: number) {
        if (currentList.value.length < 2) {
          ElMessage.error('最少保留一个分类');
          return false;
        }
        currentList.value.splice(index, 1);

        emit('deleteItem', index);
        // 不管删除哪条，删除之后默认选中第一条数据
        emit('update:modelValue', 0);
        nextTick(() => {
          selectCategory(0);
        });
      }

      // 实时移动变化
      function checkMove(e: MoveEvent<Item>) {
        console.log('开始 index: ' + e.draggedContext.index);
        console.log('停止 index: ' + e.draggedContext.futureIndex);
      }

      // 拖拽开始
      const dragging = ref(false);
      function draggingStart(dragEvent: DraggableIndex) {
        dragging.value = true;
        moveStart.value = dragEvent.oldIndex;
      }

      // 结束拖拽
      function draggingEnd(dragEvent: DraggableIndex) {
        dragging.value = false;
        currentIndex.value = dragEvent.newIndex as number;
        moveEnd.value = dragEvent.newIndex as number;

        if (moveStart.value !== moveEnd.value) {
          if (moveStart.value === currentList.value.length - 1 && moveEnd.value === 0) {
            // 最后一个移动到第一个
            emit('changeOriginal', { oldIndex: moveStart.value, newIndex: moveEnd.value }, 'pop');
          } else if (moveStart.value === 0 && moveEnd.value === currentList.value.length - 1) {
            // 第一个移动到最后一个
            emit('changeOriginal', { oldIndex: moveStart.value, newIndex: moveEnd.value }, 'shift');
          } else {
            emit('changeOriginal', { oldIndex: moveStart.value, newIndex: moveEnd.value }, '');
          }
        }
        selectCategory(currentIndex.value);
      }

      // 点击切换当前分类
      function selectCategory(index: number) {
        currentIndex.value = index;
        emit('update:modelValue', index);
        emit('categoryChange', index);
      }

      function handleBlur(event: { target: { value: string } }, item: Item, index: number) {
        const value = event.target.value;
        item.show = false;
        item.name = value;
        if (isEmpty(value) && item.isNew) {
          currentList.value.length > 2 ? currentList.value.splice(index, 1) : null;
          return false;
        } else if (!isEmpty(value) && item.isNew) {
          currentIndex.value = index;
          nextTick(() => {
            emit('categoryChange', index);
          });
          return false;
        }
        emit('changeName', value, index);
      }

      function handleInput(value: string, item: Item, index: number) {
        item.name = value;
        if (!isEmpty(value) && item.isNew) {
          item.isNew = false;
          emit('addData', value);
          currentIndex.value = index;
          emit('update:modelValue', index);
          nextTick(() => {
            emit('categoryChange', index);
          });
        }
      }

      watch(
        () => props.list,
        (nv) => {
          currentList.value = nv;
        }
      );

      return {
        currentList,
        enabled,
        dragging,
        handleAdd,
        handleEdit,
        handleDelete,
        checkMove,
        draggingStart,
        draggingEnd,
        selectCategory,
        currentIndex,
        inputEl,
        handleBlur,
        handleInput
      };
    }
  });
</script>

<style lang="less">
  .moving {
    opacity: 0.5;
    background: #c8ebfb;
  }
  .left-container {
    margin-right: 30px;
    display: inline-block;
    vertical-align: text-top;
    width: 230px;
    &__wrapper {
      position: relative;
      border: 1px solid #ddd;
      line-height: 44px;
      height: 44px;
      box-sizing: border-box;
      text-align: left;
      user-select: none;
      + .left-container__wrapper {
        border-top: none;
      }
      &.active {
        background-color: #f5f7fa;
      }
      &.error {
        border: 1px solid #f56c6c;
      }
      &:hover {
        .left-container__operations {
          display: block;
        }
      }
    }
    &__text {
      display: inline-block;
      width: 170px;
      height: 44px;
      line-height: 44px;
      overflow: hidden;
      font-size: 14px;
      padding: 0 10px;
      white-space: nowrap;
      box-sizing: border-box;
      cursor: pointer;
    }
    &__input {
      .el-input__inner {
        border: none;
      }
    }
    &__operations {
      display: none;
      position: absolute;
      right: -8px;
      top: 0;
      width: 76px;
      font-size: 14px;
      cursor: pointer;
      user-select: none;
      .operation {
        margin-left: 8px;
      }
      .move {
        cursor: move;
      }
    }

    .button {
      margin-top: 20px;
    }

    .badge {
      position: absolute;
      top: -14px;
      right: -10px;
    }
  }
</style>
