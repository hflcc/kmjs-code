import { defineComponent, PropType, ref } from 'vue';
import { TagItem } from '@/components/utils/commonType';
import { ShopCategory } from '@/components/classify/api';

interface CategoryTreeItem {
  label: string;
  value: string;
  children?: CategoryTreeItem[];
}

export default defineComponent({
  name: 'goods-select-search',
  props: {
    change: {
      type: Function as PropType<(data: TagItem[]) => void>,
      required: true
    },
    data: {
      type: Object as PropType<{
        category: ShopCategory[];
        brand: {
          name: string;
          value: {
            name: string;
            sn: string;
          };
        }[];
      }>,
      required: true
    }
  },
  setup(props) {
    const categoryTree: CategoryTreeItem[] = [];
    const formData = ref({
      name: '',
      brand: '',
      categoryFirst: '',
      categorySecond: '',
      categoryThird: ''
    });
    /**
     * 商品
     * */
    const brandOptions = ref<{ label: string; value: string }[]>([]);
    /**
     * 构建品牌数据
     * */
    brandOptions.value =
      (Array.isArray(props.data.brand) &&
        props.data.brand?.map((s) => {
          return {
            label: s.name,
            value: s.value.sn
          };
        })) ||
      [];
    /**
     * 构建类目树
     * */
    Array.isArray(props.data.category) &&
      props.data.category?.forEach((item) => {
        // 构建第一层的数据
        const firstObj: CategoryTreeItem = {
          label: item.name,
          value: item.sn,
          children: []
        };

        // 构建第二层的数据
        let secondObj: CategoryTreeItem = { label: '', value: '', children: [] };
        item.value.length &&
          item.value.forEach((i) => {
            secondObj = {
              label: i.name,
              value: i.sn,
              children: []
            };
            firstObj.children?.push(secondObj);
          });

        // 构建第三层的数据
        let thirdObj: CategoryTreeItem = { label: '', value: '', children: [] };
        item.value.length &&
          item.value[0].value.length &&
          item.value[0].value.forEach((i) => {
            thirdObj = {
              label: i.name,
              value: i.sn,
              children: []
            };
            secondObj.children?.push(thirdObj);
          });

        categoryTree.push(firstObj);
      });

    /**
     * 类目1级
     * */
    const categoryFirstOptions = ref<{ label: string; value: string }[]>([]);
    /**
     * 类目2级
     * */
    const categorySecondOptions = ref<CategoryTreeItem[]>([]);
    /**
     * 类目3级
     * */
    const categoryThirdOptions = ref<{ label: string; value: string }[]>([]);
    /**
     * 类目三级联动的处理逻辑，根据上一级生成下一级别的option的数据。并清空不直接关联等级的数据
     * @param level 等级 0 是最高级， 1 一级， 2二级， 3是三级 仅处理0， 1， 2对应的逻辑即可
     * */
    const categorySelectChange = (level: number, value: string) => {
      switch (level) {
        case 0:
          categorySecondOptions.value = [];
          formData.value.categorySecond = '';
          categoryThirdOptions.value = [];
          formData.value.categoryThird = '';
          categoryFirstOptions.value = categoryTree.map((s) => {
            return {
              label: s.label,
              value: s.value
            };
          });
          break;
        case 1:
          categoryThirdOptions.value = [];
          formData.value.categoryThird = '';
          formData.value.categorySecond = '';
          categorySecondOptions.value = categoryTree.find((s) => s.value === value)?.children ?? [];
          break;
        case 2:
          formData.value.categoryThird = '';
          categoryThirdOptions.value =
            categorySecondOptions.value
              .find((s) => s.value === value)
              ?.children?.map((s) => {
                return {
                  label: s.label,
                  value: s.value
                };
              }) ?? [];
          break;
      }
    };
    categorySelectChange(0, '');
    /**
     * 重置整个表单
     * */
    const reset = () => {
      formData.value = {
        name: '',
        brand: '',
        categoryFirst: '',
        categorySecond: '',
        categoryThird: ''
      };
    };
    /**
     * 构建搜索需要的数据结构，提交给表单控件进行搜索
     * */
    const search = () => {
      const arr: TagItem[] = [];
      arr.push({
        tagLabel: '商品名称',
        tagValue: formData.value.name,
        key: ['name'],
        value: [formData.value.name]
      });
      arr.push({
        tagLabel: '品牌',
        // tagValue: brandOptions.value.find((s) => s.value === formData.value.brand)?.label ?? '',
        tagValue: formData.value.brand,
        key: ['brand'],
        value: [formData.value.brand]
      });
      /**
       * 这里类目取最后一级有值的
       * */
      const categorySnValue = [
        formData.value.categoryThird,
        formData.value.categorySecond,
        formData.value.categoryFirst
      ];
      const categorySnLabels = [
        categoryThirdOptions.value.find((s) => s.value === formData.value.categoryThird)?.label ??
          '',
        categorySecondOptions.value.find((s) => s.value === formData.value.categorySecond)?.label ??
          '',
        categoryFirstOptions.value.find((s) => s.value === formData.value.categoryFirst)?.label ??
          ''
      ];
      const labels: string[] = [];
      let categorySn = '';
      categorySnValue.forEach((s, i) => {
        if (s) {
          labels.push(categorySnLabels[i]);
          if (!categorySn) categorySn = s;
        }
      });
      arr.push({
        tagLabel: '类目',
        tagValue: labels.reverse().join('>'),
        key: ['categorySn'],
        value: [categorySn]
      });
      props.change(arr);
    };

    return () => {
      return (
        <el-form model={formData} inline size={'mini'}>
          <el-form-item label="商品名称">
            <el-input v-model={formData.value.name}></el-input>
          </el-form-item>
          <el-form-item label="品牌">
            <el-input v-model={formData.value.brand}></el-input>
          </el-form-item>
          {/* <el-form-item label="品牌">
            <el-select v-model={formData.value.brandSn}>
              {brandOptions.value.map((v) => {
                return <el-option label={v.label} value={v.value} key={v.value}></el-option>;
              })}
            </el-select>
          </el-form-item> */}
          <el-form-item label="类目">
            <el-space>
              <el-select
                clearable
                v-model={formData.value.categoryFirst}
                onChange={(v: string) => categorySelectChange(1, v)}
              >
                {categoryFirstOptions.value.map((v) => {
                  return <el-option label={v.label} value={v.value} key={v.value}></el-option>;
                })}
              </el-select>
              <el-select
                clearable
                v-model={formData.value.categorySecond}
                onChange={(v: string) => categorySelectChange(2, v)}
              >
                {categorySecondOptions.value.map((v) => {
                  return <el-option label={v.label} value={v.value} key={v.value}></el-option>;
                })}
              </el-select>
              <el-select clearable v-model={formData.value.categoryThird}>
                {categoryThirdOptions.value.map((v) => {
                  return <el-option label={v.label} value={v.value} key={v.value}></el-option>;
                })}
              </el-select>
            </el-space>
          </el-form-item>
          <el-form-item>
            <el-button onClick={reset}>清空</el-button>
            <el-button type={'primary'} onClick={search}>
              搜索
            </el-button>
          </el-form-item>
        </el-form>
      );
    };
  }
});
