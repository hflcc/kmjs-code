import { defineComponent, nextTick, PropType } from 'vue';
import kmjsTable, { useTable } from '@/components/table/code';
import { TableConfig } from '@/components/table/kmjsTableType';
import { GoodItem } from '@/formModule/businessFormDialog/goodsSelect';

export default defineComponent({
  name: 'active-goods-table-cpt',
  props: {
    data: {
      type: Array as PropType<GoodItem[]>,
      default: () => []
    },
    delOne: {
      type: Function as PropType<(data: { data: GoodItem; checked: false }) => void>,
      required: true
    },
    delAll: {
      type: Function as PropType<(arr: GoodItem[]) => void>,
      required: true
    }
  },
  components: {
    kmjsTable
  },
  setup(props) {
    const [ctl, methods] = useTable({
      tableHandler: (name, data) => {
        switch (name) {
          case 'tableDelete':
            props.delOne({ data: data[0].row, checked: false });
            nextTick(() => {
              methods.setTableData(props.data);
            });
            break;
          case 'tableDelAll':
            props.delAll(data[0]);
            nextTick(() => {
              methods.setTableData(props.data);
            });
            break;
        }
      }
    });
    const params: TableConfig = {
      tableDataUrl: '',
      items: [
        {
          type: 'table',
          tableHead: [
            {
              label: '商品名称',
              key: 'name'
            },
            {
              label: '库存',
              key: 'saledCount'
            },
            {
              type: 'handle',
              label: '操作',
              actions: [
                {
                  label: '删除',
                  emit: 'delete'
                }
              ]
            }
          ],
          actions: [
            {
              label: '删除',
              type: 'danger',
              emit: 'delAll'
            }
          ]
        }
      ]
    };
    nextTick(() => {
      methods.setTableData(props.data);
    });
    return () => (
      <div style={{ height: '40vh' }}>
        <kmjsTable ctl={ctl} params={params}></kmjsTable>
      </div>
    );
  }
});
