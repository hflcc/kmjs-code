import { computed, defineComponent, PropType, ref } from 'vue';
import { formatterPrice, useDialog } from '@/utils';
import kmjsModule, { ModuleCtl, useModule } from '@/components/modules/module/code';
import { ElMessage } from 'element-plus';
import tableSearch from './tableSearch';
import activeGoodsTable from './activeGoodsTable';
import { TagItem } from '@/components/utils/commonType';
import { ShopCategory } from '@/components/classify/api';

export interface GoodItem {
  _checked: boolean;
  _disabled: boolean;
  isDelete: boolean;
  autoRefund: boolean;
  bizMdGoodsSn: string;
  bizMdInstSn: string;
  brand: string;
  category: string;
  count: number;
  deliverFeeType: string;
  deliverFeeValue: string;
  deliverPaymentType: string;
  goodsType: string;
  imported: boolean;
  name: string;
  price: number;
  quantity: number;
  releasedAt: number;
  retailPrice: number;
  shippingAddress: string;
  skuName: string;
  sn: string;
  sort: number;
  state: string;
  totalPrice: number;
  totalRetailPrice: number;
  unit: string;
  icon: string;
  saledCount: number;
  minPrice: number;
  maxPrice: number;
}

export default defineComponent({
  name: 'goodsSelector',
  props: {
    // 是否显示弹窗
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<{
        category: ShopCategory[];
        brand: {
          name: string;
          value: {
            name: string;
            sn: string;
          };
        }[];
      }>,
      required: true
    },
    // 已选sn
    goodsSns: {
      type: Array as PropType<string[]>,
      default: () => []
    },
    shopSn: {
      type: String as PropType<string>,
      required: true
    }
  },
  components: {
    kmjsModule,
    activeGoodsTable,
    tableSearch
  },
  emits: ['closeDialog', 'getValue', 'update:modelValue'],
  setup(props, { emit }) {
    let currentTableData: GoodItem[] = [];
    const moduleCtl = ref<ModuleCtl | null>(null);
    let methods: { [moduleName: string]: (...argus: any) => any };
    const activeGoods = ref<GoodItem[]>([]);
    const showActiveGoods = computed(() => {
      const arr: GoodItem[] = [];
      activeGoods.value.forEach((s) => {
        if (!s.isDelete) {
          arr.push(s);
        }
      });
      return arr;
    });
    const showActiveTable = ref(false);
    const categorySns = () => {
      const arr: string[] = [];
      if (Array.isArray(props.renderData?.category)) {
        props.renderData.category?.forEach((s) => {
          // 取最后一个的SN
          // arr.push(s.value.slice(-1)[0].sn);
          s.value.length && arr.push(s.value.slice(-1)[0].sn);
        });
      }
      return arr.join(',');
    };

    /**
     * 表格数据选中或反选中时处理
     * */
    const changeCheckbox = (data: { data: GoodItem; checked: boolean }) => {
      const index = activeGoods.value.findIndex((s) => s.sn === data.data.sn);
      if (data.checked) {
        buildData();
      } else {
        if (index === -1) return;
        activeGoods.value.splice(index, 1);
        const tableIndex = currentTableData.findIndex((s) => s.sn === data.data.sn);
        if (tableIndex > -1) {
          methods['/title/title-table/setCheckDisabled']?.(tableIndex, undefined, false);
        }
      }
    };
    /**
     * 表格内部修改数据时，部分字段响应丢失，在这里进行下同步更新
     * */
    const buildData = () => {
      const data = methods['/title/title-table/getCheckData']();
      data.forEach((k: GoodItem) => {
        const index = activeGoods.value.findIndex((s) => s.sn === k.sn);
        if (index === -1) {
          activeGoods.value.push(k);
          return;
        }
        activeGoods.value.splice(index, 1, k);
      });
    };
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        activeGoods.value = [];
        const [ctl, med] = useModule({
          config: [
            {
              type: 'wrap-module',
              name: 'title',
              params: {
                hideBack: true,
                title: '选择商品',
                actions: [
                  {
                    type: 'refresh',
                    emit: 'refresh'
                  }
                ]
              },
              permissions: [],
              children: [
                {
                  type: 'table',
                  name: 'title-table',
                  params: {
                    tableDataUrl: '/auth/md/shop/goods/page',
                    items: [
                      {
                        type: 'search',
                        isSlot: true,
                        inputs: [
                          {
                            label: '商品名称',
                            key: 'name',
                            type: 'text'
                          }
                        ]
                      },
                      {
                        type: 'table',
                        tableHead: [
                          {
                            label: '商品名称',
                            key: 'name'
                          },
                          {
                            label: '品牌',
                            key: 'brand'
                          },
                          {
                            label: '类目',
                            key: 'category'
                          },
                          {
                            type: 'image',
                            label: '图片',
                            key: 'ossId',
                            width: 80,
                            params: {
                              width: '30px'
                            }
                          },
                          {
                            label: '库存',
                            key: 'saledCount',
                            width: 100,
                            align: 'right'
                          },
                          {
                            type: 'slot',
                            label: '售价',
                            key: 'priceRange',
                            align: 'right'
                          },
                          {
                            label: '备注',
                            key: 'remark',
                            align: 'right'
                          }
                        ]
                      }
                    ]
                  },
                  slotParam: [
                    {
                      name: 'search',
                      slotName: 'search'
                    },
                    {
                      name: 'priceRange',
                      slotName: 'priceRangeValue'
                    }
                  ]
                }
              ]
            }
          ],
          params: {
            '/title/title-table': {
              beforeRequest: (requestObj: { url: string; params: { [key: string]: string } }) => {
                buildData();
                requestObj.params.categorySns = categorySns();
                requestObj.params.shopSn = props.shopSn;
                return Promise.resolve(requestObj);
              },
              dataFormatter: (data: GoodItem[]) => {
                currentTableData = data;

                // 设置已选中数据
                props.goodsSns.length &&
                  props.goodsSns.forEach((item) => {
                    data.map((s) => {
                      if (item === s.sn) {
                        s._checked = true;
                        activeGoods.value.push(s);
                      }
                    });
                  });

                return data.map((s) => {
                  // 翻页时选中数据
                  const index = activeGoods.value.findIndex((k) => k.sn === s.sn);
                  if (index > -1) {
                    s._checked = true;
                  }
                  return s;
                });
              }
            }
          },
          handler: (moduleName, name, data) => {
            switch (moduleName + '_' + name) {
              case '/title/title-table_tableCheckboxChange':
                changeCheckbox(data[0]);
                break;
              case '/title/title-table_tableTriggerCheckAll':
                data[0].forEach((s: { data: GoodItem; checked: boolean }) => {
                  changeCheckbox(s);
                });
                break;
            }
          }
        });
        moduleCtl.value = ctl;
        methods = med;
      } else {
        moduleCtl.value = null;
      }
    });
    /*
     * 删除item之后调用,清除外层列表的数据
     * */
    const removeItemCallback = () => {
      const data = methods['/title/title-table/getTableData']() as GoodItem[];
      const skuList = activeGoods.value.map((itemChild) => itemChild.sn);
      data.forEach((item, index) => {
        if (!skuList.includes(item.sn)) {
          item.quantity = 0;
        }
      });
      // methods['/title/title-table/setTableData'](data);
    };
    /**
     * 返回用户已经选择的数据
     * */
    const getData = async () => {
      buildData();
      if (activeGoods.value.length > 100) {
        ElMessage.error('最多仅可选择100个商品');
        return;
      }
      const agData = activeGoods.value.filter((s) => !s.isDelete);
      if (agData.filter((s) => s.quantity === 0).length) {
        ElMessage.error('请注意部分商品的采购数量为0');
        return;
      }
      emit('getValue', activeGoods.value);
    };
    return () => {
      const formModule = moduleCtl.value ? (
        <kmjsModule
          ctl={moduleCtl.value}
          v-slots={{
            search: ({ submitData }: { submitData: (tags: TagItem[]) => void }) => {
              return <tableSearch data={props.renderData} change={submitData}></tableSearch>;
            },
            priceRangeValue: ({ row }: { row: GoodItem }) => {
              return (
                <span>
                  {formatterPrice(row.minPrice)}-{formatterPrice(row.maxPrice)}
                </span>
              );
            }
          }}
        />
      ) : null;
      return (
        <el-dialog
          width="80vw"
          top="1vh"
          v-model={showDialog.value}
          onClosed={closeWindow}
          destroy-on-close
          v-slots={{
            footer: () => {
              return (
                <el-space>
                  <el-button onClick={closeWindow}>取消</el-button>
                  <el-button
                    type={'primary'}
                    onClick={() => {
                      // 解决用户在步进器中输入后直接点击提交按钮是，数量获取失败的问题
                      setTimeout(() => {
                        getData();
                      }, 100);
                    }}
                  >
                    确认
                  </el-button>
                </el-space>
              );
            }
          }}
        >
          <div style={{ height: '75vh', width: '100%' }}>
            {formModule}
            <el-popover
              placement="top"
              width={650}
              trigger="click"
              auto-close={0}
              onHide={() => {
                removeItemCallback();
              }}
              onShow={() => {
                // buildActiveData();
                showActiveTable.value = true;
              }}
              onAfterLeave={() => {
                showActiveTable.value = false;
              }}
              v-slots={{
                reference: () => (
                  <el-button
                    style={{ width: '130px' }}
                    type={showActiveGoods.value.length <= 100 ? 'primary' : 'danger'}
                    size="mini"
                  >
                    {showActiveTable.value
                      ? '收起'
                      : '已选商品(' + showActiveGoods.value.length + '/100)'}
                  </el-button>
                )
              }}
            >
              {showActiveTable.value ? (
                <activeGoodsTable
                  data={showActiveGoods.value}
                  delOne={changeCheckbox}
                  delAll={(arr: GoodItem[]) => {
                    arr.forEach((s) => {
                      changeCheckbox({
                        data: s,
                        checked: false
                      });
                    });
                  }}
                />
              ) : null}
            </el-popover>
          </div>
        </el-dialog>
      );
    };
  }
});
