import { ElForm } from 'element-plus';
import { reactive, Ref, ref } from 'vue';
import { CategoryInfo, CategoryItem } from './api';

interface Operation {
  moveUp: (
    params: { flag: boolean; index: number; data: unknown[] },
    callback?: (() => void) | undefined
  ) => void;
  moveDown: (
    params: { flag: boolean; index: number; data: unknown[] },
    callback?: (() => void) | undefined
  ) => void;
  checkData: () => boolean;
  errorCount: Ref<{ count: number }[]>;
  tableForm: {
    tableData: CategoryItem[];
    tableRule: {
      [key: string]: { required: boolean; message: string; trigger: string } | unknown[];
    };
  };
  formElem: Ref<null | InstanceType<typeof ElForm>>;
  validForm: (callback: (v: boolean | undefined) => void) => Promise<void>;
  allCategory: Ref<CategoryInfo[]>;
  firstCategory: Ref<{ name: string; sn: string; show: boolean }[]>;
  validateField(form: null | InstanceType<typeof ElForm>, field: string): void;
}

export default function (): Operation {
  const formElem = ref<null | InstanceType<typeof ElForm>>(null);
  async function validForm(callback: (v: boolean | undefined) => void) {
    formElem.value?.validate((valid: boolean | undefined) => {
      callback(valid);
    });
  }

  // 手动验证表单字段
  function validateField(form: null | InstanceType<typeof ElForm>, field: string) {
    form?.validateField(field, (error: string) => {
      if (!error) {
        console.log('OK');
      } else {
        return false;
      }
    });
  }

  // 接口返回的数据
  const allCategory = ref<CategoryInfo[]>([]);
  const firstCategory = ref<{ name: string; sn: string; show: boolean }[]>([]);

  // 表格数据
  const tableForm = reactive<{
    tableData: CategoryItem[];
    tableRule: {
      [key: string]: { required: boolean; message: string; trigger: string } | unknown[];
    };
  }>({
    tableData: [],
    tableRule: {
      name: { required: true, message: '请输入分类名称', trigger: 'blur' },
      ossId: { required: true, message: '请上传图片', trigger: 'change' },
      goodsSns: [
        { required: true, message: '请选择商品', trigger: 'change' },
        {
          validator: (rule: unknown, value: number, callback: (error?: Error) => void) => {
            if (value <= 0) {
              callback(new Error('请选择商品'));
            } else {
              callback();
            }
          },
          trigger: 'change'
        }
      ]
    }
  });

  function moveUp(
    params: { flag: boolean; index: number; data: unknown[] },
    callback?: () => void
  ) {
    const upData = params.data[params.index - 1];
    params.data.splice(params.index - 1, 1);
    params.data.splice(params.index, 0, upData);
    callback && callback();
  }

  function moveDown(
    params: { flag: boolean; index: number; data: unknown[] },
    callback?: () => void
  ) {
    const downData = params.data[params.index + 1];
    params.data.splice(params.index + 1, 1);
    params.data.splice(params.index, 0, downData);
    callback && callback();
  }

  // 收集需要必填但是没填的数据个数，只验证包含的字段
  const fields = ['name'];
  const thirdFields = ['name', 'ossId', 'goodsSns'];
  const errorCount = ref<{ count: number }[]>([]);
  const isArray = (data: unknown) => Object.prototype.toString.call(data) === '[object Array]';
  function checkData() {
    errorCount.value.length = 0;
    allCategory.value.forEach((category: CategoryInfo) => {
      let error = 0;
      Object.keys(category).forEach((element) => {
        if (fields.includes(element) && !category[element]) {
          error++;
        } else if (element === 'items' && isArray(category[element])) {
          category[element].forEach((second: CategoryItem) => {
            Object.keys(second).forEach((secondItem) => {
              // 验证二级数据里面的name
              if (fields.includes(secondItem) && !second[secondItem]) {
                error++;
              } else if (secondItem === 'items' && isArray(second[secondItem])) {
                second[secondItem].forEach((thirdItem) => {
                  Object.keys(thirdItem).forEach((item) => {
                    // 验证三级数据
                    if (
                      thirdFields.includes(item) &&
                      (!thirdItem[item] || !thirdItem[item].length)
                    ) {
                      error++;
                    }
                  });
                });
              }
            });
          });
        }
      });
      // console.log(`第${index + 1}行错误个数：${error}`);
      errorCount.value.push({ count: error });
    });

    // 判断是否有存在空值的情况
    return errorCount.value.some((item) => item.count > 0);
  }

  return {
    moveUp,
    moveDown,
    checkData,
    errorCount,
    tableForm,
    formElem,
    validForm,
    allCategory,
    firstCategory,
    validateField
  };
}
