import { defineComponent, PropType, ref } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import auditRecord from '@/components/auditRecord';
import './style.less';

export default defineComponent({
  name: 'table-cell-item-stateType',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    // 状态作为KEY。eg: ON: { name:'在线'， color: '#ff0000'}
    params: {
      type: Object as PropType<Record<string, { name: string; color: string }>>, // 这里可以修改为自己定义的params的接口
      required: true
    }
  },
  components: {
    auditRecord
  },
  setup(props) {
    const data = ref<string>(props.row[props.column['property']] as string);
    const o = ref<null | { name: string; color: string }>(props.params[data.value]);

    return () => {
      return (
        <div class="state-warp">
          {data.value === '-' || !o.value ? (
            '-'
          ) : (
            <p>
              <i class="state" style={{ background: o.value?.color || 'red' }} />
              {o.value?.name}
            </p>
          )}
        </div>
      );
    };
  }
});
