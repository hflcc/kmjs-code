/**
 * 倒计时表格内版本
 * */
import { defineComponent, PropType } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import dynamicTime from '@/components/dynamicTime';

export default defineComponent({
  name: 'table-cell-item-dynamicTime',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<{ property: string }>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<Record<string, string>>,
      required: true
    }
  },
  components: {
    dynamicTime
  },
  setup(props) {
    const data = Number(props.row[props.column.property]) || 0;
    return () => {
      return data ? <dynamicTime time={data} isBegin={false} /> : '--';
    };
  }
});
