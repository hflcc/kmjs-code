import { defineComponent, PropType, ref, watch } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import { math } from '@/utils';

interface Expansion {
  key: 'formula';
  type: 'mapping' | 'original';
  value: string;
}

export default defineComponent({
  name: 'table-cell-item-numberRate',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<Record<string, any>>, // 这里可以修改为自己定义的params的接口
      required: false
    }
  },
  setup(props) {
    const data = ref<string>(props.row[props.column['property']] as string);
    const displayText = ref('');
    const updateValue = (val: string): string => {
      let result = val;
      if (props.params?.renderParams?.property?.expansions) {
        const list = props.params?.renderParams?.property?.expansions as Expansion[];
        list.forEach((item) => {
          if (item.key === 'formula' && item.type === 'mapping') {
            try {
              const formula = props.row[item.value.split('.')[1]] as string;
              if (formula === 'rate') {
                result = math.accMul(val, 100) + '%';
              }
            } catch (e) {
              // e
            }
          }
        });
      }
      return result;
    };

    watch(
      () => data,
      async (key) => {
        displayText.value = updateValue(data.value);
      },
      {
        immediate: true
      }
    );
    return () => {
      return <p>{displayText.value}</p>;
    };
  }
});
