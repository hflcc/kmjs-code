/**
 * 处理表单内部数据来自于别的表单的输入，即数据是本地内部流通，会通过inject获取到表单内部的交互方法，对数据进行获取并动态更新
 * */
import { defineComponent, inject, PropType, ref, watch } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';

export default defineComponent({
  name: 'table-cell-item-expansion',
  props: {
    row: {
      type: Object as PropType<Record<string, Record<string, string> | string>>,
      required: true
    },
    column: {
      type: Object as PropType<{ property: string }>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<
        Record<
          string,
          | {
              code: string;
              label: string;
            }
          | string
        >
      >,
      required: true
    }
  },
  setup(props) {
    /**
     * 表单模块特有的交互方法
     * */
    const formModuleEvents = inject<FormModuleEvents | null>('formModuleEvents', null);
    /**
     * 数据的对应关系
     * */
    const mapping: {
      code: string;
      label: string;
    } = (props.params.mapping as {
      code: string;
      label: string;
    }) ?? { code: 'code', label: 'label' };
    /**
     * 表单模块内部的数据的地址
     * */
    const sourceUrl: string = (props.params.sourceValue as string) ?? '';
    /**
     * 表单内部数据的对应关系
     * */
    const data = ref<Record<string, string>>({});
    const value = ref('');
    /**
     * 当存在sourceUrl时生成本地的数据对应关系
     * */
    const buildData = () => {
      if (!sourceUrl) return;
      const obj: Record<string, string> = {};
      const [tabKey, formKey] = sourceUrl.split('.') || [];
      const resData = (formModuleEvents?.getData(tabKey, formKey) as Record<string, any>[]) ?? [];
      resData?.forEach((v) => {
        const s = v[mapping.code as string];
        obj[s] = v[mapping.label as string];
      });
      data.value = obj;
      value.value = obj[props.row[props.column.property] as string];
    };
    if (sourceUrl) {
      buildData();
    } else {
      value.value = (props.row[props.column.property] as { label: string })?.label || '';
    }
    return () => {
      return <p class={'ssss-ascascas'}>{value.value}</p>;
    };
  }
});
