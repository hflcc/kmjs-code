import { defineComponent, PropType, ref } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import auditRecord from '@/components/auditRecord';
const readIcon = require('../../../assets/icon_read.png');
const unreadIcon = require('../../../assets/icon_unread.png');
export default defineComponent({
  name: 'table-cell-item-matterType',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<Record<string, string>>, // 这里可以修改为自己定义的params的接口
      required: true
    }
  },
  components: {
    auditRecord
  },
  setup(props) {
    const data = ref<string>(props.row[props.column['property']] as string);
    const o = ref<null | string>(props.row[props.params['read']]);

    return () => {
      return (
        <p>
          <img src={o.value ? readIcon : unreadIcon} style="width: 16px; margin-bottom: -3px" />
          {data.value}
        </p>
      );
    };
  }
});
