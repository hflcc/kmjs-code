import { defineComponent, PropType } from 'vue';
import { formatterPrice } from '@/utils';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
/**
 * 价格区间展示
 * min 最小区间
 * max 最大区间
 * price 价格
 * */

interface StepPrice {
  min: string;
  max: string;
  price?: string;
  minPrice?: number;
  maxPrice?: number;
}
export default defineComponent({
  name: 'table-cell-item-skuStepPriceInfo',
  props: {
    row: {
      type: Object as PropType<Record<string, unknown>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<Record<string, string>>, // 这里可以修改为自己定义的params的接口
      required: true
    }
  },
  setup(props) {
    // console.log(props, 'props');

    return () => {
      const stepPrices = props.row[props.column['property']]
        ? (props.row[props.column['property']] as StepPrice[])
        : (props.row.step_prices as StepPrice[]);
      return (
        <div style="width:100%;">
          {stepPrices.map((item: StepPrice) => {
            return (
              <div style="display: flex;justify-content: space-between;">
                <div>
                  {item.min} - {item.max}
                </div>
                {item.price ? <div>{formatterPrice(Number(item.price))}</div> : ''}
                {item.minPrice && item.maxPrice ? (
                  <div>
                    {formatterPrice(item.minPrice)} ~ {formatterPrice(item.maxPrice)}
                  </div>
                ) : (
                  ''
                )}
              </div>
            );
          })}
        </div>
      );
    };
  }
});
