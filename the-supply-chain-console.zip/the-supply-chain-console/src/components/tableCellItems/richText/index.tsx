import { computed, defineComponent, PropType, ref, watch } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import auditRecord from '@/components/auditRecord';
import './style.less';

export default defineComponent({
  name: 'table-cell-item-richText',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<Record<string, string>>, // 这里可以修改为自己定义的params的接口
      required: false
    }
  },
  components: {
    auditRecord
  },
  setup(props) {
    const show = ref(false);
    const data = ref<string>(props.row[props.column['property']] as string);
    const formatData = ref('');
    // 去除html化
    const htmlToStr = (context: string | undefined) => {
      if (!context) {
        return '';
      }
      let str = context.replace(/<xml>[\s\S]*?<\/xml>/gi, '');
      str = str.replace(/[ |]*\n/g, '\n');
      str = str.replace(/&nbsp;/gi, ' ');
      str = str.replace(/<br\/>/gi, '\n');
      str = str.replace(/<br>/gi, '\n');
      str = str.replace(/<\/p>/gi, '</p>\n'); // 给p标签变成换行符
      str = str.replace(/<style>[\s\S]*?<\/style>/gi, '');
      str = str.replace(/<\/?[^>]*>/g, '');
      str = str.replace(/\n+/g, '\n'); // 处理连续换行符，变为一个
      return str.trim();
    };

    watch(
      () => data,
      async (key) => {
        formatData.value = htmlToStr(data.value);
      },
      {
        immediate: true
      }
    );
    return () => {
      return (
        <div class="rich-warp">
          {formatData.value.length > 0 ? formatData.value : '--'}
          {formatData.value.length > 0 ? (
            <el-popover
              placement="top"
              width={600}
              v-slots={{
                reference: () => <i class="icon el-icon-chat-dot-round"></i>
              }}
              trigger="hover"
              onShow={() => (show.value = true)}
              onAfterLeave={() => (show.value = false)}
            >
              <div class="rich-content" v-html={data.value} />
            </el-popover>
          ) : (
            ''
          )}
        </div>
      );
    };
  }
});
