<template>
  <div class="user-item-wrap">
    <el-checkbox
      v-if="showCheckbox"
      style="margin: 0 10px"
      v-model="checked"
      @change="checkboxChange"
      :disabled="disable"
    ></el-checkbox>
    <div class="user-item-content">
      <div class="icon">{{ data.scopeName.charAt(0) }}</div>
      <div class="info">
        <h4 class="info-title">
          {{ data.scopeName }} <span v-if="data.phoneNum">（{{ data.phoneNum }}）</span>
        </h4>
        <p class="info-content">-</p>
        <p class="info-content" v-if="data.orgName">{{ data.orgName + '-' + data.orgTreeName }}</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType, ref, watch } from 'vue';
  import { SearchRespons } from '../chooseOrganization/api';

  export default defineComponent({
    name: 'user-item-component',
    props: {
      showCheckbox: {
        type: Boolean as PropType<boolean>,
        default: true
      },
      data: {
        type: Object as PropType<SearchRespons>,
        default: () => {
          return {};
        }
      },
      isCheck: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      disable: {
        type: Boolean as PropType<boolean>,
        default: false
      }
    },
    setup(props, { emit }) {
      const checked = ref(props.isCheck);

      watch(
        () => props.isCheck,
        (val) => {
          checked.value = val;
        }
      );

      const checkboxChange = () => {
        emit('on-checked', props.data, checked.value);
      };
      return { checkboxChange, checked };
    }
  });
</script>
<style lang="less">
  .user-item-wrap {
    display: flex;
    align-items: center;
    padding: 8px 0;

    .user-item-content {
      display: flex;
      flex: 1;
      align-items: center;

      .icon {
        width: 36px;
        height: 36px;
        background: @primary;
        color: #fff;
        text-align: center;
        line-height: 36px;
        margin-right: 8px;
        border-radius: 6px;
      }

      .info {
        color: @secondFontColor;

        .info-title {
          font-weight: 500;
          color: @fontColor;
          line-height: 16px;
        }
        &-content {
          color: #9b9b9b;
          line-height: 14px;
        }
      }
    }
  }
</style>
