import { defineComponent, PropType, ref } from 'vue';
import wrapVue from '@/components/wrap/index.vue';
import { Btns } from '@//components/utils/commonType';
import { buildBtn } from '@/components/utils/buildTsx/btn';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import { checkPermission } from '@/utils/permission';
import { goToFormCreate, goToCreateBpm } from '@/pages/commonPage/index';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';
import { useDEToLRefresh } from '@/utils';

export interface WrapConfig {
  title?: string;
  hideBack?: boolean;
  actions?: Btns[];
}

export default defineComponent({
  name: 'warp-module',
  components: {
    wrapVue
  },
  props: {
    params: {
      type: Object as PropType<WrapConfig>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      required: true
    },
    actions: {
      type: Array as PropType<unknown[]>
    }
  },
  setup(props) {
    const { setCallBack } = useDEToLRefresh();
    const { emitHandler, trigger, permission } = resisterModule(props.moduleName, {});
    const router = useRouter();
    const showBpmWindow = ref(false);
    const bpmWindowConfig = ref({
      title: '',
      type: ''
    });
    const hideBpmWindow = () => {
      showBpmWindow.value = false;
    };
    const getBpmSn = (bpmSn: string) => {
      hideBpmWindow();
      goToCreateBpm(bpmSn);
    };
    const emitFun = (name: string, ...data: any[]) => {
      const [config] = data;
      switch (name) {
        case '$refresh':
          trigger?.('$refresh');
          return;
        case 'location':
          /**
           * 定位
           * */
          router.push({ name: 'location' });
          return;
        case 'createBpm':
          /**
           * 开始新的流程 显示选择流程弹窗
           * */
          showBpmWindow.value = true;
          bpmWindowConfig.value.type = config.params.bpmType || '';
          return;
        case 'createForm':
          /**
           * 开始新的表单
           * */
          if (!config.params?.defSn) {
            ElMessage.warning('没有找到表单SN');
          }
          // 新增返回后刷新数据
          goToFormCreate(
            config.params?.defSn,
            setCallBack(() => {
              trigger?.('$refresh');
            })
          );
          return;
        default:
          emitHandler(name);
          break;
      }
    };
    return {
      getBpmSn,
      hideBpmWindow,
      bpmWindowConfig,
      showBpmWindow,
      emitFun,
      permission
    };
  },
  render() {
    const { params, emitFun, permission, showBpmWindow, getBpmSn, bpmWindowConfig, hideBpmWindow } =
      this;
    const actionsSlot = () => {
      return params.actions?.map((v) => {
        // 进行权限判断
        if (checkPermission(v.emit, permission) || v.type === 'refresh') {
          return buildBtn(v, emitFun, undefined, 'mini');
        } else {
          return undefined;
        }
      });
    };
    return (
      <>
        <wrap-vue
          params={params}
          v-slots={{ actions: actionsSlot, default: this.$slots.default }}
        />
        <kmjs-create-bpm-before
          v-model={showBpmWindow}
          onGetValue={getBpmSn}
          onCloseDialog={hideBpmWindow}
          bpmType={bpmWindowConfig.type}
        ></kmjs-create-bpm-before>
      </>
    );
  }
});
