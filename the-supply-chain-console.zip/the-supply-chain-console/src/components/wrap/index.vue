<template>
  <div class="kmjs-wrap">
    <!-- 返回区域  -->
    <div class="back">
      <div
        style="font-size: 20px; font-weight: bolder; cursor: pointer; flex: 1"
        v-if="params.hideBack"
      >
        {{ params.title }}
      </div>
      <div
        style="font-size: 20px; font-weight: bolder; cursor: pointer; flex: 1"
        @click="back"
        v-else
      >
        <i class="el-icon-arrow-left"></i> {{ params.title }}
      </div>
      <div class="right">
        <slot name="actions"></slot>
      </div>
    </div>
    <div id="wrapComMain" class="wrap-com-main">
      <slot></slot>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { useRouter } from 'vue-router';
  import { WrapConfig } from '@/components/wrap/module';

  export default defineComponent({
    name: 'kmjs-wrap',
    props: {
      params: {
        type: Object as PropType<WrapConfig>,
        default: () => {
          return {};
        }
      },
      backFun: {
        type: Function as PropType<() => void>
      }
    },
    setup(props) {
      const router = useRouter();
      const back = () => {
        if (typeof props.backFun === 'function') {
          props.backFun();
        } else {
          router.back();
        }
      };
      return {
        back
      };
    }
  });
</script>
<style lang="less">
  .kmjs-wrap {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background: #fff;
    overflow: hidden;

    .back {
      display: flex;
      padding-top: 10px;
      //padding-bottom: 10px;

      .right {
        margin-left: auto;
      }
    }

    .wrap-com-main {
      flex: 1;
      padding-bottom: 10px;
      overflow: auto;
      margin-top: 10px;
    }
  }
</style>
