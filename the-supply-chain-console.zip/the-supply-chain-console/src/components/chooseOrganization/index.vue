<template>
  <el-dialog v-model="showDialog" title="选择部门或成员" @close="closeWindow">
    <div class="choose-organization-modal-wrap">
      <div class="choose-area">
        <div class="left item">
          <div class="item-title">搜索</div>
          <div class="item-content">
            <el-input v-model="textInput" @keydown.enter="search" placeholder="搜索">
              <template #append>
                <el-button icon="el-icon-search" @click="search"></el-button>
              </template>
            </el-input>
            <div class="search-area">
              <div class="search-title">您可能想要找</div>
              <div class="search-content" v-if="searchList.length">
                <UserItem
                  v-for="item in searchList"
                  :key="item.sn"
                  :is-check="computedIsCheck(item)"
                  @on-checked="changeTags"
                  :data="item"
                ></UserItem>
              </div>
              <div class="search-content" v-else>
                <el-empty style="height: 100%" :description="emptyText"></el-empty>
              </div>
            </div>
          </div>
        </div>
        <div class="line"></div>
        <div class="right item">
          <div class="item-title">按组织架构选择</div>
          <div class="item-content">
            <el-select
              v-model="organizationSelect"
              @change="changeOrganizationSelect"
              placeholder="请选择"
            >
              <el-option
                v-for="item in organizationOptions"
                :key="item.sn"
                :label="item.name"
                :value="item.sn"
              >
              </el-option>
            </el-select>
            <div class="search-area">
              <div class="search-content">
                <el-tree
                  ref="elTreeElem"
                  :data="treeData"
                  :props="treeProps"
                  :load="loadNode"
                  :default-checked-keys="treeCheckShow"
                  lazy
                  node-key="sn"
                  show-checkbox
                  @check="treeChecked"
                >
                  <template #default="{ data }">
                    <p v-if="!data.isHuman">{{ data.name }}</p>
                    <UserItem v-else :data="data" :show-checkbox="false"></UserItem>
                  </template>
                </el-tree>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="value-area" v-show="showTags.length" style="padding-top: 40px">
        <h4 class="value-area-title">已选</h4>
        <el-space style="flex-wrap: wrap">
          <el-tag
            v-for="tag in showTags"
            :key="tag.sn"
            closable
            @close="closeTag(tag)"
            style="margin-bottom: 8px"
          >
            {{ tag.scopeName || tag.name }}
          </el-tag>
        </el-space>
      </div>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeWindow">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { computed, defineComponent, nextTick, PropType, Ref, ref, UnwrapRef } from 'vue';
  import { useDialog } from '@/utils';
  import UserItem from './user-item.vue';
  import { getAllOrg, getOrgTreeChild, getSearchOrgChild, SearchRespons } from './api';
  import { ElMessage, ElTree } from 'element-plus';
  import { useStore } from 'vuex';

  const tagsLogic = (elTreeElem: Ref<UnwrapRef<InstanceType<typeof ElTree> | null>>) => {
    // 记录搜索选中的项目
    const searchTags = ref<SearchRespons[]>([]);
    // 记录树图选中的项目, 不包含重复的，同时如果父节点被选中，子节点被父节点代替，子节点不显示
    const treeCheck = ref<SearchRespons[]>([]);
    // 记录所有树图被选中的项目的sn，主要是用了页面的展示效果，逻辑上没有任何用处
    // 设置这个的原因是，同一个人可能在不通的组织下挂靠，数据中的sn是不相同的，但是同一个人的scopeSn是相同的
    // 树图组件，需要一个全图唯一的ID， sn刚好能满足这个
    // 这里不直接存储SN是需要记录一下scopeSn和sn的映射，数据中刚刚就有
    const treeCheckSn = ref<SearchRespons[]>([]);
    const { treeChecked } = treeLogic(treeCheck, treeCheckSn);
    /**
     * 计算显示已选中的标签
     * */
    const showTags = computed<SearchRespons[]>(() => {
      // 先根据scopeSn进去去重， 在渲染数据
      const newNodeArr: SearchRespons[] = ([] as SearchRespons[]).concat(
        treeCheck.value,
        searchTags.value
      );
      const scopeSn: string[] = Array.from(new Set(newNodeArr.map((v) => v.scopeSn)));
      return scopeSn.map((v) => newNodeArr.find((s) => s.scopeSn === v) as SearchRespons);
    });
    // 操作tag的值
    const changeTags = (data: SearchRespons, checked: boolean) => {
      const index = searchTags.value.findIndex((s) => s.scopeSn === data.scopeSn);
      if (checked) {
        if (index < 0) {
          searchTags.value.push(data);
        }
      } else {
        if (index > -1) {
          searchTags.value.splice(index, 1);
        }
      }
    };
    // 清空所有的tag 在init时调用
    const clearTags = () => {
      searchTags.value = [];
      treeCheck.value = [];
    };
    /**
     * 计算搜索出来的列表是否被选中
     * */
    const computedIsCheck = (item: SearchRespons) => {
      return searchTags.value.includes(item);
    };
    /**
     * 关闭某个标签
     * */
    const closeTag = async (item: SearchRespons) => {
      changeTags(item, false);
      const treeNode = treeCheckSn.value.filter((s) => s.scopeSn === item.scopeSn);
      treeNode.forEach((v) => {
        elTreeElem.value?.setChecked(v.sn, false, true);
      });
      await nextTick();
      treeChecked(undefined, {
        checkedNodes: (elTreeElem.value?.getCheckedNodes(false, false) as SearchRespons[]) || []
      });
    };
    /**
     * 给tree的default-checked-key属性
     * 控制树图上哪些显示选中
     * */
    const treeCheckShow = computed<string[]>(() => {
      return treeCheckSn.value.map((v) => v.sn);
    });
    return {
      treeCheckShow,
      treeCheckSn,
      treeCheck,
      showTags,
      changeTags,
      computedIsCheck,
      clearTags,
      closeTag
    };
  };

  const searchLogic = (props: { sns: string[] }) => {
    const emptyText = ref('请输入需要搜索的内容进行搜索');
    // input的值
    const textInput = ref('');
    // 模糊搜索的数据
    const searchList = ref<SearchRespons[]>([]);
    /**
     * 模糊搜索
     * */
    const search = async () => {
      if (!textInput.value) {
        ElMessage.warning('请输入搜索的名称');
        return;
      }
      const result = await getSearchOrgChild(textInput.value, props.sns.join(','));
      if (!result) return;
      if (result.content.length === 0) {
        emptyText.value = '搜索内容为空';
      }
      searchList.value = result.content.map((item) => {
        return {
          id: 0,
          sn: item.bizMdInstOrgTreeResource.sn,
          scope: item.bizMdInstOrgTreeResource.scope,
          scopeSn: item.bizMdInstOrgTreeResource.scopeSn,
          scopeName: item.bizMdInstOrgTreeResource.scopeName,
          sort: item.bizMdInstOrgTreeResource.sort,
          sysUserId: item.bizMdInstUser.sysUserId,
          orgName: item.bizMdInstOrg.name,
          orgSn: item.bizMdInstOrg.sn,
          orgTreeSn: item.bizMdInstOrgTree.sn,
          orgTreeName: item.bizMdInstOrgTree.name,
          parentSn: item.bizMdInstOrgTree.sn,
          parentId: item.bizMdInstOrgTree.parentId,

          instSn: item.bizMdInstUser.instSn,
          instName: item.bizMdInstUser.instName,
          name: item.bizMdInstUser.name,
          phoneNum: item.bizMdInstUser.phoneNum,
          disabled: false,
          isHuman: true
        };
      });
    };
    return {
      emptyText,
      textInput,
      searchList,
      search
    };
  };

  const treeLogic = (
    treeCheck: Ref<UnwrapRef<SearchRespons[]>>,
    treeCheckSn: Ref<UnwrapRef<SearchRespons[]>>
  ) => {
    const store = useStore();
    const currentUserId = store.getters['user/userMsg'].userId;
    const treeData = ref<SearchRespons[]>([]);
    const organizationOptions = ref<{ name: string; sn: string }[]>([]);
    const organizationSelect = ref('');
    const treeProps = {
      label: 'name',
      children: 'children',
      isLeaf: 'isHuman'
    };
    /**
     * 获取树的选中的节点
     * */
    const treeChecked = (data: any, { checkedNodes }: { checkedNodes: SearchRespons[] }) => {
      console.log(data, checkedNodes);
      const arr: SearchRespons[] = [];
      treeCheckSn.value = checkedNodes;
      const checkedKeys = checkedNodes.map((v) => v.scopeSn);
      // 对选中节点的父节点SN和所有选中节点的SN进行对比，如果父节点SN在已选中的SN中，就说明当前父节点被选中，直接使用父节点的名称代替
      checkedNodes.forEach((v) => {
        // '0'是根节点，不考虑
        if (v.parentSn === '0') {
          arr.push(v);
          return;
        }
        if (!checkedKeys.includes(v.parentSn)) {
          arr.push(v);
        }
      });
      treeCheck.value = arr;
    };
    /**
     * 获取树上的分组select的选中的值
     * */
    const changeOrganizationSelect = async (e: string) => {
      treeData.value = [];
      treeData.value = await getTreeData();
    };
    /**
     * 获取所以的可以选择的组织数据
     * */
    const getOrg = async (sns: string) => {
      const data = await getAllOrg(sns);
      if (!data) return;
      organizationOptions.value = data;
      organizationSelect.value = data[0].sn;
      changeOrganizationSelect(data[0].sn);
    };
    /**
     * 获取组织下的详细的组织树
     * */
    const getTreeData = async (parentSN = '0'): Promise<any[]> => {
      const data = await getOrgTreeChild(organizationSelect.value, parentSN);
      if (!data) return [];
      data.forEach((v) => {
        v.parentSn = parentSN;
        if (!v.scopeSn) {
          v.scopeSn = v.sn;
        }
      });
      return data;
    };
    /**
     * 异步加载树形结构的数据，由于存在同一个人挂在不同机构时，sn是不同的，但是scopeSn是相同的，因此在这里根据scopeSn进行便利一下又没有被选中，有的话将当前节点加入进去
     * */
    const loadNode = async (
      node: { level: number; data: { id: number; sn: string; resources: any[] } },
      resolve: (data: any[]) => void
    ) => {
      if (node.level === 0) return;
      const data = await getTreeData(node.data.sn);
      if (Array.isArray(node.data.resources) && node.data.resources.length > 0) {
        node.data.resources.forEach((v) => {
          if (v.sysUserId === currentUserId) {
            v.disabled = true;
          }
          v.parentSn = node.data.sn;
          v.parentId = node.data.id;
          v.isHuman = true;
          data.push(v);
        });
      }
      resolve(data);
    };
    return {
      organizationSelect,
      organizationOptions,
      treeData,
      treeProps,
      treeChecked,
      changeOrganizationSelect,
      getOrg,
      loadNode
    };
  };

  export default defineComponent({
    name: 'choose-organization-modal',
    components: {
      UserItem
    },
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      },
      sns: {
        type: Array as PropType<string[]>,
        default: () => []
      }
    },
    // emits: ['on-confirm'],
    emits: {
      'update:modelValue': null,
      closeDialog: null,
      'on-confirm': (payload: SearchRespons[]): boolean => {
        console.log(payload);
        return payload.length > 0;
      }
    },
    setup(props, { emit }) {
      const elTreeElem = ref<InstanceType<typeof ElTree> | null>(null);
      const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
        if (v) {
          init();
        }
      });
      const { textInput, searchList, search, emptyText } = searchLogic(props);
      const {
        treeCheckShow,
        treeCheckSn,
        showTags,
        treeCheck,
        changeTags,
        computedIsCheck,
        clearTags,
        closeTag
      } = tagsLogic(elTreeElem);
      const {
        organizationSelect,
        organizationOptions,
        treeData,
        treeProps,
        treeChecked,
        changeOrganizationSelect,
        getOrg,
        loadNode
      } = treeLogic(treeCheck, treeCheckSn);
      /**
       * 确认将数据返回出去
       * */
      const confirm = () => {
        if (showTags.value.length === 0) {
          ElMessage.warning('请选中一条数据后操作');
          return;
        }
        emit('on-confirm', showTags.value);
      };
      /**
       * 初始化，获取组织架构的下拉框数据，并默认获取第一级的树形图数据
       * */
      const init = () => {
        emptyText.value = '请输入需要搜索的内容进行搜索';
        textInput.value = '';
        searchList.value = [];
        clearTags();
        elTreeElem?.value?.setCheckedKeys([], false);
        getOrg(props.sns?.join(','));
      };
      return {
        treeCheckShow,
        elTreeElem,
        emptyText,
        searchList,
        textInput,
        showTags,
        treeData,
        treeProps,
        organizationSelect,
        organizationOptions,
        showDialog,
        search,
        confirm,
        closeWindow,
        loadNode,
        treeChecked,
        changeOrganizationSelect,
        computedIsCheck,
        changeTags,
        closeTag
      };
    }
  });
</script>

<style lang="less">
  .choose-organization-modal-wrap {
    .choose-area {
      display: flex;
      height: 100%;

      .line {
        width: 1px;
        background: #aaa;
        margin: 0 20px;
      }

      .item {
        flex: 1;

        .item-title {
          color: #333;
          font-weight: 500;
        }

        .item-content {
          padding-top: 10px;
          height: 40vh;
        }
      }

      .item-content {
        display: flex;
        flex-direction: column;

        .search-area {
          flex: 1;
          display: flex;
          flex-direction: column;
          margin-top: 10px;
          border-radius: 4px;
          overflow: hidden;
          border: 1px solid @borderColor;

          .search-title {
            padding: 4px 10px;
            color: #aaa;
            background: #eee;
          }

          .search-content {
            flex: 1;
            overflow: auto;
          }
        }
      }
    }

    .value-area {
      padding-top: 10px;

      .value-area-title {
        margin: 10px 0;
        font-weight: 500;
        color: @fontColor;
      }
    }
  }

  .el-tree .el-tree-node__content {
    min-height: 26px;
    height: auto;
  }
</style>
