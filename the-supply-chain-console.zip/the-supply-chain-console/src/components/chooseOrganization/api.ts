import ajax from '@/utils/axios';

export interface SearchRespons {
  sn: string;
  scope: string;
  scopeSn: string;
  scopeName: string;
  sort: number;
  orgName: string;
  orgSn: string;
  orgTreeSn: string;
  orgTreeName: string;
  instSn: string;
  instName: string;
  name: string;
  parentSn: string;
  disabled: boolean;
  resources?: SearchRespons[];
  isHuman?: boolean;
  isCheck?: boolean;
  parentId: number;
  id: number;
  phoneNum?: string;
  sysUserId: number;
}

const params = {
  $InstId: true
};

interface Org {
  name: string;
  sn: string;
  parentId: number;
}

interface Search {
  bizMdInstOrg: Org;
  bizMdInstOrgTree: Org;
  bizMdInstOrgTreeResource: SearchRespons;
  bizMdInstUser: SearchRespons;
}

/**
 * 根据当前机构的所有组织
 * */
export const getAllOrg = (sns?: string): Promise<{ name: string; sn: string }[]> => {
  const api = sns ? `/auth/md/inst/org/list?sns=${sns}` : '/auth/md/inst/org/list';
  return ajax.get(api, {
    params: {
      ...params
    }
  });
};
/**
 * 获取父级组织树sn下的子组织树，且可以根据scope获取指定类型的树资源
 */
export const getOrgTreeChild = (
  orgSn: string,
  parentSn: string,
  scope = 'inst_user'
): Promise<any[]> => {
  return ajax.get(`/auth/md/inst/org/tree/list/${orgSn}/${parentSn}/${scope}`, {
    params: {
      ...params
    }
  });
};
/**
 * 获取当前机构中指定资源类型的数据
 * */
export const getSearchOrgChild = (
  queryName: string,
  orgSns?: string,
  scope = 'inst_user'
): Promise<{ content: Search[] }> => {
  // const data = orgSns ? `?orgSns=${orgSns}` : '';
  return ajax.get(`/auth/md/inst/org/tree/resource/page/es/inst/${scope}`, {
    params: {
      ...params,
      page: 0,
      size: 1000,
      scopeName: queryName,
      orgSns: orgSns ?? ''
    }
  });
};

/**
 * 获取当前机构中指定资源类型的数据
 * */
export const getSearchOrg = (queryName: string): Promise<{ content: SearchRespons[] }> => {
  return ajax.get('/auth/md/inst/org/tree/page', {
    params: {
      ...params,
      page: 0,
      size: 1000,
      name: queryName
    }
  });
};
