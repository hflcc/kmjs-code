import ajax from '@/utils/axios';

export interface AuditRecordData {
  title: string;
  completeAt: number;
  completeDesc: string;
  completeNameBy: string;
  createdNameBy: string;
  result: string;
  state: string;
  takeAt: number;
  takeNameBy: string;
}

/**
 * 根据流程实例SN获取
 * */
export const getAuditRecordData = (instanceSn: string): Promise<AuditRecordData[]> => {
  return ajax.get(`/auth/bpm/instance/node/list/${instanceSn}/history`, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 根据业务数据查询
 * */
export const getAuditRecordDataByBizSn = (bizSn: string): Promise<AuditRecordData[]> => {
  return ajax.get(`/auth/bpm/instance/node/list/biz_sn/${bizSn}/history`, {
    params: {
      $noLoad: true
    }
  });
};
