import { defineComponent, PropType, ref } from 'vue';
import {
  AuditRecordData,
  getAuditRecordData,
  getAuditRecordDataByBizSn
} from '@/components/auditRecord/api';
import { formatterTimer, relativeTimeStr } from '@/utils';
import './index.less';
export default defineComponent({
  name: 'audit-recode-component',
  props: {
    sn: {
      type: String as PropType<string>,
      default: ''
    },
    type: {
      type: String as PropType<'table' | 'bpm'>,
      default: 'bpm'
    }
  },
  setup(props) {
    const data = ref<AuditRecordData[]>([]);
    const getData = async () => {
      const fun = props.type === 'bpm' ? getAuditRecordData : getAuditRecordDataByBizSn;
      const res = await fun(props.sn);
      if (res) {
        data.value = res;
      }
    };
    getData();
    return () => {
      return (
        <div class="audit-recode-component-wrap">
          {data.value.length ? (
            <el-timeline style={{ margin: '8px' }}>
              {data.value.map((s, i) => {
                return (
                  <el-timeline-item
                    hide-timestamp
                    placement="top"
                    icon="el-icon-success"
                    size="large"
                  >
                    {i == 0 ? (
                      <el-card class="audit-card" body-style={{ padding: '12px 16px' }}>
                        <h1>{s.title}</h1>
                        <p>发起人：{s.completeNameBy ?? s.takeNameBy}</p>
                        <p>
                          发起时间：
                          {s.takeAt
                            ? formatterTimer(new Date(s.takeAt * 1000), 'YYYY-MM-DD HH:mm:ss')
                            : ''}
                        </p>
                      </el-card>
                    ) : (
                      <el-card class="audit-card" body-style={{ padding: '12px 16px' }}>
                        <h1>
                          <span>{s.title}</span>
                          <span class="take-time">
                            {s.takeAt
                              ? formatterTimer(new Date(s.takeAt * 1000), 'YYYY-MM-DD HH:mm:ss')
                              : ''}
                          </span>
                        </h1>
                        <p>审核人：{s.completeNameBy ?? s.takeNameBy}</p>
                        <p>审核结果：{s.result}</p>
                        <p>
                          审核时间：
                          {s.completeAt
                            ? formatterTimer(new Date(s.completeAt * 1000), 'YYYY-MM-DD HH:mm:ss')
                            : '--'}
                        </p>
                        <p>
                          用时：
                          {s.completeAt && s.takeAt
                            ? relativeTimeStr(s.takeAt * 1000, s.completeAt * 1000)
                            : '--'}
                        </p>
                        <p>审核建议：</p>
                        <div class="desc" innerHTML={s.completeDesc} />
                      </el-card>
                    )}
                  </el-timeline-item>
                );
              })}
            </el-timeline>
          ) : (
            <el-empty description="暂无审核数据"></el-empty>
          )}
        </div>
      );
    };
  }
});
