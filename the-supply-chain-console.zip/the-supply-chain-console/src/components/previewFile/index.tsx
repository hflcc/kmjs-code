/**
 * 预览文件，目前支持预览图片和pdf
 * */
import { defineComponent, PropType } from 'vue';
import { useDialog } from '@/utils';

export default defineComponent({
  name: 'kmjs-preview-file',
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    data: {
      type: Array as PropType<{ type: string; url?: string }[]>,
      required: true
    }
  },
  setup(props, { emit }) {
    const { showDialog, closeWindow } = useDialog(props, emit);
    return () => (
      <el-dialog v-model={showDialog.value} width="80vw" title="文件预览" onClose={closeWindow}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0' }}>
          {props.data.map((v) => {
            if (v.type === 'image') {
              return (
                <img
                  src={v.url}
                  style={{
                    border: '1px solid #999',
                    margin: '0 auth',
                    maxHeight: '60vh',
                    maxWidth: '80vw'
                  }}
                ></img>
              );
            }
            if (v.type === 'pdf') {
              return (
                <iframe
                  src={v.url}
                  style={{ height: '60vh', width: '80vw' }}
                  frameborder="0"
                ></iframe>
              );
            }
          })}
        </div>
      </el-dialog>
    );
  }
});
