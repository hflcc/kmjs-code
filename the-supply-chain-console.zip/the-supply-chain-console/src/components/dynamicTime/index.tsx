/**
 * 动态倒计时组件， 传入一个时间计算与当前时间的对比
 * */
import { defineComponent, onMounted, onUnmounted, PropType, ref } from 'vue';
import { relativeTimeStr } from '@/utils';

export default defineComponent({
  name: 'dynamic-time',
  props: {
    // 传入的时间戳，一般是秒级别的数字
    time: {
      type: Number as PropType<number>,
      default: 0
    },
    // 传入的时间是开始值还是结束值
    isBegin: {
      type: Boolean as PropType<boolean>,
      default: true
    }
  },
  setup(props) {
    let timeout: number;
    const time = ref('');
    onMounted(() => {
      timeout = setInterval(() => {
        if (props.time && Number(props.time) > 0) {
          const now = new Date().getTime();
          const data = props.isBegin ? [props.time * 1000, now] : [now, props.time * 1000];
          time.value = relativeTimeStr(data[0], data[1]);
        } else {
          time.value = '';
        }
      }, 1000);
    });
    onUnmounted(() => {
      if (timeout) {
        clearInterval(timeout);
      }
    });
    return () => {
      return <p>{time.value ?? '-'}</p>;
    };
  }
});
