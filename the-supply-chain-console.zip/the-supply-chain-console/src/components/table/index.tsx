import { defineComponent, nextTick, onMounted, PropType, provide, readonly, ref } from 'vue';
import tableTitle from '@/components/table/title';
import tableSearch from '@/components/table/search';
import tableTable from '@/components/table/table';
import {
  Options,
  TableConfig,
  TableMethods,
  UseTableProps
} from '@/components/table/kmjsTableType';
import './style.less';
import { getTableData } from '@/components/table/api';
import { PageData } from '@/components/table/logic/getData';
import useOrganization from '@/store/commModules/organization/useOrganization';
import useDataFormatter from '@/components/table/logic/useFormatter';
import { buildTablePageItem } from '@/components/table/components';
import useTableDictionary from '@/components/table/logic/useDictionary';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import usePermission from '@/components/table/logic/permission';
import { provideLocalEmit } from '@/components/table/components/commSetup';
import { useRouter } from 'vue-router';
import { useDEToLRefresh } from '@/utils';
import submitResult from '@/components/submitResultPlay';
import useBpm from '@/components/table/logic/bpm';
import { Btns } from '@/components/utils/commonType';

export * from './useTable';

export default defineComponent({
  name: 'kmjs-table',
  components: {
    tableTitle,
    tableSearch,
    tableTable,
    submitResult
  },
  props: {
    ctl: {
      type: Function as PropType<(methods: TableMethods) => UseTableProps>
    },
    params: {
      type: Object as PropType<TableConfig>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      default: ''
    }
  },
  setup(props) {
    let resData = {};
    const { setCallBack } = useDEToLRefresh();
    const router = useRouter();
    // 存储表格配置
    const tableConfig = ref<TableConfig>(props.params);
    // 表格数据
    const tableContentData = ref();
    // 额外的请求入参，query上
    let defaultReqBody: { [l: string]: any } = {};
    // 额外的请求入参，path上
    let defaultPathBody: string[] = [];
    // 占位，接收传入的格式化的方法
    let dataFormatterFun: (data: any) => any;
    // 占位，发送请求前，将请求对象。便于对数据进行处理
    let beforeRequest: (requestObj: {
      url: string;
      params: { [l: string]: any };
    }) => Promise<{ url: string; params: { [l: string]: any } }>;
    // 是否载入配置项成功，如果没有成功，切换机构时不去请求数据
    let loadConfig = false;
    // 表格组件的实例
    const tableVNode = ref<InstanceType<typeof tableTable> | null>(null);
    // 对外接口
    const ctlFun: TableMethods = {
      setTableData: () => {
        // todo
      },
      getResponse: () => readonly(resData),
      // 请求当前页
      refresh() {
        search();
      },
      // 从第一页从新请求
      refreshAll() {
        changePage(1);
      },
      // 获取发起请求时的入参
      async getSearchData() {
        let requestObj = {
          url: '',
          params: searchValue.value
        };
        if (typeof beforeRequest === 'function') {
          requestObj = await beforeRequest({ url: '', params: requestObj });
          if (!requestObj) {
            return searchValue.value;
          }
        }
        return requestObj.params;
      },
      // 获取当前表格渲染的数据
      getTableData() {
        return [...tableContentData.value];
      },
      // 获取表单checked选中的数据
      getCheckData() {
        return tableVNode.value?.checkItemData ?? [];
      },
      // 设置搜索中某些搜索的项可被用户选择的值，比如说某个select的数据来自于后台数据, 通过key去选中
      setSearchOptions(key: string, data: Options[]) {
        const searchConfig = tableConfig.value.items.find((s) => s.type === 'search');
        if (!searchConfig) return;
        const item = searchConfig.inputs?.find((s) => s.key === key);
        if (!item) return;
        item.options = data;
      },
      // 设置表格数据中某一条数据不可选
      setCheckDisabled: (i: number, disabled: boolean, isCheck = false) => {
        tableVNode.value?.changeDisable(i, disabled, isCheck);
      }
    };
    const emptyText = ref('数据加载，，，');
    provide('emptyText', emptyText);
    /**
     * 获取表格数据
     * */
    const getData = async (req: any) => {
      if (!loadConfig) return;
      let requestObj = {
        // 混入额外的path入参
        url: (tableConfig.value?.tableDataUrl || '') + defaultPathBody.join('/'),
        // 混入额外的query入参
        params: Object.assign(req, defaultReqBody)
      };
      if (typeof beforeRequest === 'function') {
        requestObj = await beforeRequest(requestObj);
        if (!requestObj) {
          return;
        }
      }
      tableContentData.value = [];
      emptyText.value = '数据加载，，，';
      const res = await getTableData(
        requestObj.url,
        requestObj.params,
        activeOrgan.value?.id || undefined // 机构ID
      );
      if (res) {
        resData = res;
        if (!res?.content.length) {
          emptyText.value = '暂无数据';
          return;
        }
        let data = res?.content?.map((v: any, i: number) => {
          v._sn = v.sn || (new Date().getTime() + i).toString(16);
          dataFormatter(v); // 格式化数据
          return v;
        });
        // 自定义的格式化数据
        if (typeof dataFormatterFun === 'function') {
          data = dataFormatterFun(data);
        }
        tableContentData.value = data;
        // 设置总条数
        setTotalDataNum(res.totalElements);
        // 解决fixed纵向滑动条行样式错乱问题
        nextTick(() => {
          tableVNode.value?.renderTable();
        });
        emitHandler('tableResponse', readonly(res));
      } else {
        emptyText.value = '加载失败，请重试';
      }
    };
    // 注册成模块内部控件
    const { emitHandler, params, emitOn, permission } = resisterModule<UseTableProps, TableMethods>(
      props.moduleName,
      ctlFun
    );
    const { setFormatterMap, dataFormatter } = useDataFormatter();
    emitOn?.('$refresh', () => {
      search();
    });
    /**
     * 搜索的主要逻辑函数
     * */
    const { search, setTotalDataNum, changePage, searchValue } = PageData(getData);
    /**
     * 监听用户切换机构
     * */
    const localOrganData = {
      activeOrganSn: '',
      activeOrganizationSn: '',
      activeChannelSn: ''
    };
    const { activeOrgan, activeOrganization } = useOrganization((dataObj) => {
      // 由于加入了组织机构根据菜单配置展示，导致组织结构一直在发生变化，因此这里记录下当前页面的组织机构
      if (
        dataObj.activeOrgan?.sn === localOrganData.activeOrganSn &&
        dataObj.activeOrganization?.sn === localOrganData.activeOrganizationSn &&
        dataObj.activeChannel?.sn === localOrganData.activeChannelSn
      ) {
        return;
      }
      if (dataObj.activeOrganization?.sn) {
        localOrganData.activeOrganSn = dataObj.activeOrgan?.sn ?? '';
        localOrganData.activeOrganizationSn = dataObj.activeOrganization?.sn ?? '';
        localOrganData.activeChannelSn = dataObj.activeChannel?.sn ?? '';
      }
      search();
    });
    let options: UseTableProps;
    // 接收控制器中的参数初始化组件
    if (typeof props.ctl === 'function') {
      options = props.ctl(ctlFun);
    } else {
      options = params.value;
    }
    defaultReqBody = options.reqBody || {};
    defaultPathBody = options.pathBody || [];
    if (typeof options.dataFormatter === 'function') {
      dataFormatterFun = options.dataFormatter;
    }
    if (typeof options.beforeRequest === 'function') {
      beforeRequest = options.beforeRequest;
    }

    /** 新建流程逻辑区域  start**/
    const {
      showBpmResultWindow,
      bpmWindowConfig,
      hideBpmWindow,
      createBpmResultData,
      closeBpmResultWindow,
      showBpmWindow,
      getBpmSn,
      play
    } = useBpm(search, setCallBack);
    provideLocalEmit((name: string, ...data: any[]) => {
      // 刷新按钮事件
      if (name === 'title$refresh') {
        return search();
      }
      const types = [
        'tableTableBpmStatic',
        'tableTableCreate',
        'tableTableEdit',
        'tableTableDetail',
        'tableTableBpm'
      ];
      // 处理以上特殊的按钮类型的后续动作
      if (types.includes(name)) {
        play(name, data as [{ row: Record<string, unknown> }, Btns]);
        return;
      }
      options.tableHandler?.(name, data);
      emitHandler?.(name, ...data);
    });
    useTableDictionary(tableConfig.value.items);
    setFormatterMap(tableConfig.value);
    usePermission(tableConfig.value.items, permission?.value);
    onMounted(() => {
      loadConfig = true;
      search();
    });
    return {
      showBpmResultWindow,
      createBpmResultData,
      closeBpmResultWindow,
      bpmWindowConfig,
      showBpmWindow,
      getBpmSn,
      hideBpmWindow,
      tableVNode,
      tableConfig,
      tableContentData
    };
  },
  render() {
    const {
      showBpmResultWindow,
      createBpmResultData,
      closeBpmResultWindow,
      tableConfig,
      tableContentData,
      showBpmWindow,
      bpmWindowConfig,
      getBpmSn,
      hideBpmWindow
    } = this;
    const slots = this.$slots;
    const length = tableConfig?.items.length || 0;
    return (
      <div class="kmjs-table-wrap" style="display: flex;flex-direction: column;">
        {tableConfig?.items.map((v, i) => {
          return (
            <>
              {buildTablePageItem(v, tableContentData, slots)}
              {i < length - 1 ? <div class="line"></div> : null}
            </>
          );
        })}
        <kmjs-create-bpm-before
          v-model={showBpmWindow}
          onGetValue={getBpmSn}
          onCloseDialog={hideBpmWindow}
          bpmType={bpmWindowConfig.type}
        />
        <el-dialog
          destroy-on-close
          v-model={showBpmResultWindow}
          v-slots={{
            footer: () => {
              return (
                <el-button type={'primary'} onClick={closeBpmResultWindow}>
                  确认
                </el-button>
              );
            }
          }}
        >
          <submitResult data={createBpmResultData} showCountdown={false}></submitResult>
        </el-dialog>
      </div>
    );
  }
});
