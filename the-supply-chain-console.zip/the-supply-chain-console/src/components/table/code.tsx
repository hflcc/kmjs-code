/**
 * 本地模式，数据来源于外部接口设置，不来自外部请求数据。同时加入隐藏分页的配置项
 * */
import { defineComponent, nextTick, onMounted, PropType, ref } from 'vue';
import tableTitle from '@/components/table/title';
import tableSearch from '@/components/table/search';
import tableTable from '@/components/table/table';
import {
  Options,
  TableConfig,
  TableMethods,
  UseTableProps
} from '@/components/table/kmjsTableType';
import './style.less';
import { PageData } from '@/components/table/logic/getData';
import useOrganization from '@/store/commModules/organization/useOrganization';
import useDataFormatter from '@/components/table/logic/useFormatter';
import { buildTablePageItem } from '@/components/table/components';
import useTableDictionary from '@/components/table/logic/useDictionary';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import usePermission from '@/components/table/logic/permission';
import { provideLocalEmit } from '@/components/table/components/commSetup';
import { useRouter } from 'vue-router';
import { goToFormEdit, goToFormDetail } from '@/pages/commonPage/index';
import { useDEToLRefresh } from '@/utils';
import store from '@/store';

export * from './useTable';

export default defineComponent({
  name: 'kmjs-table',
  components: {
    tableTitle,
    tableSearch,
    tableTable
  },
  props: {
    ctl: {
      type: Function as PropType<(methods: TableMethods) => UseTableProps>
    },
    params: {
      type: Object as PropType<TableConfig>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      default: ''
    }
  },
  setup(props) {
    const { setCallBack } = useDEToLRefresh();
    const router = useRouter();
    // 存储表格配置
    const tableConfig = ref<TableConfig>(props.params);
    // 表格数据
    const tableContentData = ref();
    // 额外的请求入参，query上
    let defaultReqBody: { [l: string]: any } = {};
    // 额外的请求入参，path上
    let defaultPathBody: string[] = [];
    // 占位，接收传入的格式化的方法
    let dataFormatterFun: (data: any) => any;
    // 占位，发送请求前，将请求对象。便于对数据进行处理
    let beforeRequest: (requestObj: {
      url: string;
      params: { [l: string]: any };
    }) => Promise<{ url: string; params: { [l: string]: any } }>;
    // 是否载入配置项成功，如果没有成功，切换机构时不去请求数据
    let loadConfig = false;
    // 表格组件的实例
    const tableVNode = ref<InstanceType<typeof tableTable> | null>(null);
    // 需要设置表格常量数据的key
    const tableConst: Array<{
      key: string;
      sourceType: 'currUser' | 'currInst' | 'currTime';
      sourceValue: string;
    }> = [];
    const tableDefaultValue: Array<{ key: string; initial: any }> = [];
    // 取出表格的配置
    const tableOption = tableConfig.value.items.filter((item) => {
      return item.type === 'table';
    });
    // 将表格遍历一次,然后将常量key取出来
    tableOption.forEach((item) => {
      item.tableHead?.forEach(({ key, params }) => {
        const { sourceType, sourceValue, initial } = params?.renderParams || {};
        if (key && sourceType) {
          if (sourceType === 'currUser' || sourceType === 'currInst' || sourceType === 'currTime') {
            tableConst.push({
              key,
              sourceType,
              sourceValue
            });
          }
        }
        if (key && initial) {
          tableDefaultValue.push({
            key,
            initial
          });
        }
      });
    });
    // 对外接口
    const ctlFun: TableMethods = {
      // 请求当前页
      refresh() {
        search();
      },
      getResponse() {
        return {};
      },
      // 从第一页从新请求
      refreshAll() {
        changePage(1);
      },
      // 获取发起请求时的入参
      async getSearchData() {
        let requestObj = {
          url: '',
          params: searchValue.value
        };
        if (typeof beforeRequest === 'function') {
          requestObj = await beforeRequest({ url: '', params: requestObj });
          if (!requestObj) {
            return searchValue.value;
          }
        }
        return requestObj.params;
      },
      // 获取当前表格渲染的数据
      getTableData() {
        if (tableContentData.value) {
          return [...tableContentData.value];
        }
        return [];
      },
      // 获取表单checked选中的数据
      getCheckData() {
        return tableVNode.value?.checkItemData ?? [];
      },
      // 设置搜索中某些搜索的项可被用户选择的值，比如说某个select的数据来自于后台数据, 通过key去选中
      setSearchOptions(key: string, data: Options[]) {
        const searchConfig = tableConfig.value.items.find((s) => s.type === 'search');
        if (!searchConfig) return;
        const item = searchConfig.inputs?.find((s) => s.key === key);
        if (!item) return;
        item.options = data;
      },
      // 设置表格数据中某一条数据不可选
      setCheckDisabled: (i: number, disabled: boolean, isCheck = false) => {
        tableVNode.value?.changeDisable(i, disabled, isCheck);
      },
      setTableData: (res) => {
        tableContentData.value = [];
        let data = res.map((v: any) => {
          dataFormatter(v); // 格式化数据
          return v;
        });
        // 自定义的格式化数据
        if (typeof dataFormatterFun === 'function') {
          data = dataFormatterFun(data);
        }
        // 格式化常量
        data.forEach((item) => {
          // 设置常量
          tableConst.forEach(({ key, sourceValue, sourceType }) => {
            if (!item[key]) {
              // 常量值不存在;需要手动塞入
              if (sourceType === 'currUser') {
                item[key] = store.getters['user/userMsg'][sourceValue];
              } else if (sourceType === 'currInst') {
                item[key] = store.getters['organization/activeOrgan'][sourceValue];
              } else if (sourceType === 'currTime') {
                const time = (new Date().getTime() / 1000).toString();
                item[key] = parseInt(time);
              }
            }
          });
          // 设置默认值
          tableDefaultValue.forEach(({ key, initial }) => {
            if (!item[key]) {
              item[key] = initial;
            }
          });
        });
        nextTick(() => {
          tableContentData.value = data;
        });
      }
    };
    // 注册成模块内部控件
    const { emitHandler, params, emitOn, permission } = resisterModule<UseTableProps, TableMethods>(
      props.moduleName,
      ctlFun
    );
    const { setFormatterMap, dataFormatter } = useDataFormatter();
    emitOn?.('$refresh', () => {
      search();
    });
    /**
     * 搜索的主要逻辑函数
     * */
    const { search, changePage, searchValue } = PageData();
    // 隐藏分页控件
    changePage(-1);
    let options: UseTableProps;
    // 接收控制器中的参数初始化组件
    if (typeof props.ctl === 'function') {
      options = props.ctl(ctlFun);
    } else {
      options = params.value;
    }
    defaultReqBody = options.reqBody || {};
    defaultPathBody = options.pathBody || [];
    if (typeof options.dataFormatter === 'function') {
      dataFormatterFun = options.dataFormatter;
    }
    if (typeof options.beforeRequest === 'function') {
      beforeRequest = options.beforeRequest;
    }

    /** 新建流程逻辑区域  start**/
    const showBpmWindow = ref(false);
    let clickSn = '';
    const bpmWindowConfig = ref({
      title: ''
    });
    const hideBpmWindow = () => {
      showBpmWindow.value = false;
    };
    const getBpmSn = (bpmSn: string) => {
      hideBpmWindow();
      router.push({
        name: 'createBpmEdit',
        query: {
          sn: bpmSn,
          bsn: clickSn
        }
      });
    };
    /** 新建流程逻辑区域 end **/
    const toDetailOrEdit = (type: string, defSn: string, sn: string) => {
      // 处理跳转详情/编辑时的逻辑
      switch (type) {
        case 'tableTableDetail':
          goToFormDetail(defSn, sn);
          break;
        case 'tableTableEdit':
          goToFormEdit(defSn, sn, setCallBack(search));
          break;
        case 'tableTableBpm':
          clickSn = sn;
          showBpmWindow.value = true;
          break;
      }
    };
    provideLocalEmit((name: string, ...data: any[]) => {
      // 刷新按钮事件
      if (name === 'title$refresh') {
        return search();
      }
      if (name === 'tableTableEdit' || name === 'tableTableDetail' || name === 'tableTableBpm') {
        const [tableCellData, config] = data;
        return toDetailOrEdit(
          name,
          config.params.defSn,
          tableCellData.row[config.params.dataSnKey]
        );
      }
      options.tableHandler?.(name, data);
      emitHandler?.(name, ...data);
    });
    useTableDictionary(tableConfig.value.items);
    setFormatterMap(tableConfig.value);
    usePermission(tableConfig.value.items, permission?.value);
    onMounted(() => {
      loadConfig = true;
      search();
    });
    return {
      showBpmWindow,
      getBpmSn,
      hideBpmWindow,
      tableVNode,
      tableConfig,
      tableContentData
    };
  },
  render() {
    const { tableConfig, tableContentData, showBpmWindow, getBpmSn, hideBpmWindow } = this;
    const slots = this.$slots;
    const length = tableConfig?.items.length || 0;
    return (
      <div class="kmjs-table-wrap" style="display: flex;flex-direction: column;">
        {tableConfig?.items.map((v, i) => {
          return (
            <>
              {buildTablePageItem(v, tableContentData, slots)}
              {i < length - 1 ? <div class="line"></div> : null}
            </>
          );
        })}
        <kmjs-create-bpm-before
          v-model={showBpmWindow}
          onGetValue={getBpmSn}
          onCloseDialog={hideBpmWindow}
        ></kmjs-create-bpm-before>
      </div>
    );
  }
});
