import ajax from '@/utils/axios';
import { TableConfig } from '@/components/table/kmjsTableType';

const getTableConfig = async (url: string, sn: string): Promise<TableConfig | null> => {
  const res = await ajax.get<null, { [l: string]: TableConfig }>('/snJSON.json', {
    params: {
      $noBase: true
    }
  });
  if (res) {
    return res[sn];
  } else {
    return null;
  }
};

const getTableData = (url: string, req: any, InstId?: number): Promise<any> => {
  return ajax.get(url, {
    params: req,
    headers: {
      InstId
    }
  });
};

// 获取代办是否在流程中,决定是否可以编辑;
const getBpmInstanceProcessing = (defSn: string, bizSn: string) => {
  return ajax.get<null, { success: boolean; message: string | null }>(
    `/auth/bpm/instance/processing/${defSn}/${bizSn}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

export { getTableData, getTableConfig, getBpmInstanceProcessing };
