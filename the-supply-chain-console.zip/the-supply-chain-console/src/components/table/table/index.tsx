import {
  computed,
  defineComponent,
  h,
  inject,
  PropType,
  Ref,
  ref,
  resolveComponent,
  UnwrapRef,
  VNode,
  watch
} from 'vue';
import { localEmit } from '@/components/table/components/commSetup';
import {
  BuildCellEvent,
  TableColumn,
  TablePageItem,
  TableParams
} from '@/components/table/kmjsTableType';
import { Btns, TagItem } from '@/components/utils/commonType';
import { buildBtn, buildDropdown, renderUnclickable } from '@/components/utils/buildTsx/btn';
import { ElTable, ElNotification } from 'element-plus';
import tablePagination from './pagination';
import useCheckbox from '@/components/table/table/useCheckbox';
// table的扩展
import * as cellContent from './tableCellTypes';
import { ConcreteComponent, Slots } from '@vue/runtime-core';
import { sum } from 'lodash';
import { formatterNumber } from '@/utils/formatter';
import TableDialog from '@/components/table/dialog';
import { getBpmInstanceProcessing } from '../api';

enum alignType {
  left = 'flex-start',
  center = 'center',
  right = 'flex-end'
}

/**
 * 构造表格的cell
 * @param v 单元格的配置
 * @param slots 表格控件的slot，用以渲染slot类型的组件
 * @param localEmitFun 对外触发事件的回调函数
 * @param event 表格内部的事件传递
 * */
const buildColumn = (
  v: TableColumn,
  slots: Slots,
  localEmitFun: (...data: any) => void,
  event: BuildCellEvent
) => {
  if (typeof localEmitFun === 'function') {
    const result = localEmitFun;
    localEmitFun = (...args) => {
      const promiseList: any[] = [];
      if (
        args[1] &&
        args[1].btnConfig &&
        args[1].btnConfig.params &&
        Array.isArray(args[1].btnConfig.params.beforeCallCheck) &&
        args[1].row
      ) {
        const list = args[1].btnConfig.params.beforeCallCheck;
        const row = args[1].row;
        // const hintText: string[] = [];
        list.map((item: { type: 'bpm'; queryKey: string; defSn: string }) => {
          // const defSn = item.queryKey;
          const defSn = row[item.queryKey];
          promiseList.push(
            new Promise((resolve) => {
              getBpmInstanceProcessing(item.defSn, defSn)
                .then((res) => {
                  if (res.success) {
                    // hintText.push(res.message);
                    ElNotification({
                      type: 'error',
                      title: '提示',
                      message: res.message || '您已提交数据变更，审核成功后将覆盖该数据',
                      duration: 4000
                    });
                  }
                  resolve(!res.success);
                })
                .catch(() => {
                  resolve(false);
                });
            })
          );
        });
      }
      Promise.all<boolean>(promiseList).then((res) => {
        if (!res.includes(false)) {
          result(...args);
        }
      });
    };
  }
  if (v.type === 'hide') {
    return null;
  }
  const renderTableDialog = ({
    row,
    column,
    $index
  }: {
    row: any;
    column: any;
    $index: number;
  }) => {
    return h(TableDialog, {
      row,
      column,
      cellIndex: $index,
      event,
      params: v.params
    });
  };
  let renderContent = ({
    row,
    column,
    $index
  }: {
    row: any;
    column: any;
    $index: number;
  }): JSX.Element | Array<JSX.Element | null> => {
    const kmjsTableDialog = v.params?.showDiaLogIcon
      ? renderTableDialog({ row, column, $index })
      : '';
    if (v.type) {
      const globalCellItem =
        v.type === 'text' ? 'text' : resolveComponent('table-cell-item-' + v.type);
      if (typeof globalCellItem === 'string') {
        return (
          <div style="white-space:pre-line;">
            {v.params?.beforeText}
            {row[column.property] ?? '--'}
            {v.params?.endText}
            {kmjsTableDialog}
          </div>
        );
      } else {
        const children = [
          h(globalCellItem, {
            row,
            column,
            cellIndex: $index,
            event,
            params: v.params
          })
        ];
        if (v.params?.showDiaLogIcon) children.push(kmjsTableDialog as VNode);
        return h('div', {}, children);
      }
    } else {
      return (
        <div>
          {v.params?.beforeText}
          {row[column.property] ?? '--'}
          {v.params?.endText}
          {kmjsTableDialog}
        </div>
      );
    }
  };
  /**
   * 策略模式进行扩展
   * */
  const cellType: {
    [l: string]: ({ row, column }: { row: any; column: any; $index: number }) => any;
  } = {
    handle: function ({ row, column, $index }) {
      if (localEmitFun && v.actions?.length) {
        const s = v.actions.slice();
        /**
         * 将详情、编辑、删除 三种类型的按钮截取出来，并按照顺序排列
         * */
        const detail = [];
        const edit = [];
        const del = [];
        for (let i = 0; i < s.length; i++) {
          if (s[i].label === '详情') {
            detail.push(s[i]);
            s.splice(i, 1);
            i--;
            continue;
          }
          if (s[i].label === '编辑') {
            edit.push(s[i]);
            s.splice(i, 1);
            i--;
            continue;
          }
          if (s[i].label === '删除') {
            del.push(s[i]);
            s.splice(i, 1);
            i--;
          }
        }
        const actions = [...detail, ...edit, ...del, ...s];
        // btns 展示规则计算
        let btnData: Array<{
          btnConfig: Btns;
          emit: (name: string, ...data: any[]) => void;
          data: any;
        } | null> = actions.map((s) => {
          if (s.type === 'unclickable') {
            const copy = Object.assign({}, s);
            if (!copy.rules || !Array.isArray(copy.rules)) {
              return {
                btnConfig: copy,
                emit: localEmitFun,
                data: {
                  row,
                  column,
                  btnConfig: copy
                }
              };
            }
            const result =
              copy.rules
                .map((r): boolean => {
                  const values = r.columnValue.split('|');
                  return values.indexOf(row[r.columnKey]?.toString()) > -1;
                })
                .indexOf(true) > -1;
            if (result) {
              copy.type = 'text';
            }
            return {
              btnConfig: copy,
              emit: localEmitFun,
              data: {
                row,
                column,
                btnConfig: copy
              }
            };
          }
          let flags: boolean[] = [];
          switch (s.show) {
            case 'rule':
              if (!s.rules || !Array.isArray(s.rules)) {
                return null;
              }
              // 默认是满足一项即为真
              flags = s.rules.map((r): boolean => {
                const values = r.columnValue.split('|');
                return values.indexOf(row[r.columnKey]?.toString()) > -1;
              });
              if ((!s.ruleType || s.ruleType === 'or') && flags.includes(true)) {
                return {
                  btnConfig: s,
                  emit: localEmitFun,
                  data: {
                    row,
                    column,
                    btnConfig: s
                  }
                };
              }
              if (s.ruleType === 'and' && !flags.includes(false)) {
                return {
                  btnConfig: s,
                  emit: localEmitFun,
                  data: {
                    row,
                    column,
                    btnConfig: s
                  }
                };
              }
              return null;
            case 'never':
              return null;
            default:
              return {
                btnConfig: s,
                emit: localEmitFun,
                data: {
                  row,
                  column,
                  btnConfig: s
                }
              };
          }
        });
        const unclickable = btnData.filter((item) => item && item.btnConfig.type === 'unclickable');
        // 过滤不展示的按钮
        btnData = btnData.filter((item) => item && item.btnConfig.type !== 'unclickable');
        const renderData =
          btnData.length > 3
            ? [buildDropdown(btnData)]
            : btnData.map((item) => {
                if (item) {
                  return buildBtn(item.btnConfig, item.emit, 'text', undefined, item.data);
                }
                return null;
              });
        return [
          ...renderData,
          ...(unclickable?.map((s) => s && renderUnclickable(s.btnConfig)) ?? [])
        ];
      }
    },
    mapText: cellContent.mapText(v.params),
    image: cellContent.image(v.params, event.renderTable),
    rangeText: cellContent.rangeText(v.params),
    formatter: cellContent.formatter(v.params),
    listView: cellContent.listView(v.params),
    fileListView: cellContent.fileListView(v.params),
    expiredDate: cellContent.expiredDate(v.params),
    address: cellContent.address,
    area: cellContent.area,
    slot: ({ row, column, $index }: { row: any; column: any; $index: number }) => {
      return slots[v.key as string]?.({ row, column, $index });
    },
    stepInput: cellContent.stepInput(v.params, event.changeDisable)
  };
  if (typeof cellType[v.type as string] === 'function') {
    const contentStyle = {
      display: 'flex',
      'align-items': 'center',
      'justify-content': v.align ? alignType[v.align] : alignType.left
    };
    renderContent = ({ row, column, $index }: { row: any; column: any; $index: number }) => {
      return (
        <div style={contentStyle}>
          {cellType[v.type as string]({ row, column, $index })}
          {v.params?.showDiaLogIcon ? renderTableDialog({ row, column, $index }) : ''}
        </div>
      );
    };
  }
  const contentSlots = {
    default: renderContent
  };
  const fixed = v.type === 'handle' ? 'right' : v?.fixed;
  return (
    <el-table-column
      prop={v.key}
      label={v.label}
      width={v?.width}
      minWidth={v?.width ? undefined : 150}
      fixed={fixed}
      align={v.align ?? 'left'}
      v-slots={contentSlots}
    />
  );
};
export default defineComponent({
  name: 'kmjs-table-table',
  props: {
    columns: {
      type: Array as PropType<TableColumn[]>,
      default: () => []
    },
    tableData: {
      type: Array as PropType<any[]>,
      default: () => []
    },
    actions: {
      type: Array as PropType<Btns[]>,
      default: () => []
    },
    tableConfig: {
      type: Object as PropType<TableParams>,
      default: () => null
    },
    config: {
      type: Object as PropType<TablePageItem>
    }
  },
  components: {
    tablePagination,
    cellImg: cellContent.cellImg
  },
  setup(props) {
    const permission = inject<Ref<UnwrapRef<{ [moduleName: string]: string }>>>(
      'permission',
      ref({})
    );
    // 是否单选
    const isSingle = props.config?.tableSelectMode === 'single';
    const emptyText = inject<string>('emptyText', '');
    const searchTags = inject<TagItem[]>('searchTags', []);
    const closeTag = inject<(key: string) => void>('closeTag', (s) => {
      // nothing
    });
    const clearTag = inject<() => void>('clearTag', () => {
      // nothing
    });
    const elem = ref<null | HTMLDivElement>(null);
    const { localEmitFun } = localEmit('table');
    const { checkAll, triggerCheckAll, checkData, initCheckData, changeDisable, checkboxChange } =
      useCheckbox(localEmitFun);
    const tableInterface = ref<InstanceType<typeof ElTable> | null>(null);
    // 赛选已经勾选的条目
    const checkItemData = computed(() => {
      const arr: any[] = [];
      checkData.value.forEach((s, i: number) => {
        if (s.isCheck) {
          arr.push(props.tableData[i]);
        }
      });
      return arr;
    });
    // 将表格重新渲染
    const renderTable = () => {
      tableInterface.value?.doLayout();
    };
    initCheckData(props.tableData);
    watch(
      () => props.tableData.length,
      () => initCheckData(props.tableData)
    );
    const summaryMethod = (param: any) => {
      const { columns, data } = param;
      const sums: string[] = [];
      columns.forEach((column: { property: string }, index: number) => {
        if (index === 0) {
          sums[index] = '合计';
          return;
        }
        const SummaryKeyToPoint: { [key: string]: number } = {};
        const SummaryShowKeys =
          props.tableConfig?.summaryShowKeys?.map((item) => {
            SummaryKeyToPoint[item.key] = item.afterPoint;
            return item.key;
          }) || [];
        if (SummaryShowKeys.includes(column.property)) {
          const sumData: number[] = data.map((v: any) => Number(v[column.property]) || 0);
          sums[index] = formatterNumber(sum(sumData), SummaryKeyToPoint[column.property]);
        } else {
          sums[index] = '';
        }
      });
      return sums;
    };
    // 记录展开的行
    const expandRowKeys = ref([]);
    const onExpandChange = (row: any, expandedRows: any) => {
      console.log(row, expandedRows);
    };
    return {
      elem,
      checkItemData,
      localEmitFun,
      isSingle,
      tableInterface,
      checkAll,
      clearTag,
      triggerCheckAll,
      checkboxChange,
      checkData,
      searchTags,
      closeTag,
      changeDisable,
      renderTable,
      summaryMethod,
      permission,
      emptyText,
      expandRowKeys,
      onExpandChange
    };
  },
  render() {
    const {
      permission,
      tableConfig,
      summaryMethod,
      isSingle,
      clearTag,
      searchTags,
      closeTag,
      columns,
      tableData,
      actions,
      localEmitFun,
      checkAll,
      checkItemData,
      triggerCheckAll,
      checkboxChange,
      checkData,
      changeDisable,
      renderTable,
      emptyText,
      expandRowKeys,
      onExpandChange
    } = this;
    const slots = this.$slots;
    let expandTemplate: null | ConcreteComponent | string = null;
    if (tableConfig?.isExpand && tableConfig?.templateName) {
      expandTemplate = resolveComponent('table-expand-' + tableConfig.templateName);
      expandTemplate = typeof expandTemplate === 'string' ? null : expandTemplate;
    }
    return (
      <>
        {searchTags?.length ? (
          <div class="kmjs-table-tags-wrap">
            <label style={{ color: '#999', whiteSpace: 'nowrap' }}>检索内容：</label>
            <el-scrollbar>
              <div class="content">
                <div style="white-space: nowrap">
                  {searchTags?.map((v) => {
                    return (
                      <el-tag
                        style="margin-right: 10px"
                        closable
                        size="small"
                        type="info"
                        onClose={() => closeTag?.(v.tagLabel)}
                      >
                        {v.tagLabel}:
                        {Array.isArray(v.tagValue) ? v.tagValue.join(' - ') : v.tagValue}
                      </el-tag>
                    );
                  })}
                </div>
              </div>
            </el-scrollbar>
            <p
              style={{ color: '#999', whiteSpace: 'nowrap', cursor: 'pointer' }}
              onClick={clearTag}
            >
              清除全部
            </p>
          </div>
        ) : null}
        <div ref="elem" style={{ flex: 1 }} class="kmjs-table-table-wrap">
          <el-table
            expand-row-keys={expandRowKeys}
            height="100%"
            ref="tableInterface"
            size="mini"
            header-cell-style={{ backgroundColor: '#eee', color: '#333' }}
            data={tableData}
            row-key={'_sn'}
            empty-text={emptyText}
            show-summary={tableConfig?.summary ?? false}
            summary-method={summaryMethod}
          >
            <el-table-column
              width="80"
              align="center"
              fixed={'left'}
              v-slots={{
                header: () => {
                  // 单选不展示表头的checkbox
                  if (isSingle) {
                    return <span>选择</span>;
                  }
                  return (
                    <el-checkbox v-model={checkAll} onChange={triggerCheckAll}>
                      选择
                    </el-checkbox>
                  );
                },
                default: ({ row, $index }: { row: any; $index: number }) => {
                  if (!checkData[$index]) return null;
                  return (
                    <el-checkbox
                      v-model={checkData[$index].isCheck}
                      disabled={checkData[$index]?.isDisabled}
                      onChange={(v: boolean) => checkboxChange(row, v)}
                    />
                  );
                }
              }}
            />
            {expandTemplate ? (
              <el-table-column
                type="expand"
                fixed={'left'}
                v-slots={{
                  default: ({ row, column, $index }: { row: any; column: any; $index: number }) => {
                    return h(expandTemplate as string, {
                      row,
                      column,
                      cellIndex: $index,
                      event: {
                        changeDisable,
                        renderTable
                      },
                      localEmitFun,
                      permission: permission ?? {}
                    });
                  }
                }}
              />
            ) : null}

            <el-table-column
              width="55"
              label="序号"
              align="center"
              fixed={'left'}
              v-slots={{
                default: ({ $index }: { $index: number }) => {
                  return <p>{$index + 1}</p>;
                }
              }}
            />
            {columns.map((v) =>
              buildColumn(v, slots, localEmitFun, {
                changeDisable,
                renderTable,
                refresh: () => {
                  // todo
                }
              })
            )}
          </el-table>
        </div>
        <table-pagination actions={actions} checkData={checkItemData} />
      </>
    );
  }
});
