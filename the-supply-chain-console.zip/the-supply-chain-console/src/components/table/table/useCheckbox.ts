import { computed, ref, unref } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';

export default function (localEmitFun: (name: string, ...data: any[]) => void) {
  let currentTableData: Record<string, any>[] = [];
  const checkData = ref<{ isCheck: boolean; isDisabled: boolean }[]>([]);
  const initCheckData = (tableData: any[]) => {
    currentTableData = tableData;
    const length = tableData.length;
    checkData.value = [];
    for (let i = 0; i < length; i++) {
      checkData.value.push({
        isCheck: tableData[i]._checked ?? false,
        isDisabled: tableData[i]._disable ?? false
      });
    }
  };
  const checkAll = computed(
    () =>
      checkData.value.length > 0 &&
      checkData.value.findIndex((s) => {
        // 忽略被disabled的
        return !s.isDisabled && !s.isCheck;
      }) === -1
  );
  const triggerCheckAll = () => {
    const flag = !checkAll.value;
    const data: {
      data: Record<string, any>;
      checked: boolean;
    }[] = [];
    checkData.value.forEach((s, i) => {
      if (!s.isDisabled) {
        data.push({
          data: Object.assign({}, currentTableData[i]),
          checked: flag
        });
        s.isCheck = flag;
      }
    });
    localEmitFun('triggerCheckAll', data);
  };
  /**
   * 切换指定索引的表格数据的checkbox的disabled状态
   * @param i 数据的索引
   * @param disabled 是否可选
   * @param isCheck 是否选中当前的数据
   * */
  const changeDisable: BuildCellEvent['changeDisable'] = (i, disabled, isCheck = false) => {
    if (typeof disabled === 'boolean') {
      checkData.value[i].isDisabled = disabled;
    }
    if (checkData.value[i].isCheck !== isCheck) {
      checkData.value[i].isCheck = isCheck;
      checkboxChange(currentTableData[i], isCheck);
    }
  };

  const checkboxChange = (row: Record<string, any>, value: boolean) => {
    localEmitFun('checkboxChange', {
      data: Object.assign({}, row),
      checked: value
    });
  };
  return {
    checkAll,
    triggerCheckAll,
    checkData,
    initCheckData,
    changeDisable,
    checkboxChange
  };
}
