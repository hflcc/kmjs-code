import { ComponentInternalInstance } from '@vue/runtime-core';

interface Funs {
  triggerCheckAll: () => void;
  getCheckData: () => any[];
}

export default function (): [(instance: ComponentInternalInstance | null) => void, Funs] {
  let currInstance: ComponentInternalInstance | null = null;
  const ctl = (instance: ComponentInternalInstance | null) => {
    currInstance = instance;
  };
  return [
    ctl,
    {
      triggerCheckAll() {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        currInstance?.triggerCheckAll();
      },
      getCheckData() {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        return currInstance?.checkData.value;
      }
    }
  ];
}
