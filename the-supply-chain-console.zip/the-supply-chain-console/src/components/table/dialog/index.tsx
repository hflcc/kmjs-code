import { defineComponent, PropType, ref, resolveComponent, h } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import auditRecord from '@/components/auditRecord';
import dialogType1 from './dialogType1';
interface TableParams {
  dialogName?: string;
  dialogTrigger?: 'hover' | 'click' | 'focus';
  dialogIconName?: string;
  snKey: string;
}
export default defineComponent({
  name: 'table-dialog',
  props: {
    row: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    params: {
      type: Object as PropType<TableParams>, // 这里可以修改为自己定义的params的接口
      required: true,
      validator(value: TableParams) {
        if (value.dialogTrigger) {
          return ['hover', 'click', 'focus'].includes(value.dialogTrigger);
        } else {
          return true;
        }
      }
    }
  },
  components: {
    auditRecord,
    dialogType1
  },
  setup(props: { params: TableParams; row: Record<string, string> }) {
    const sn = props.row[props.params?.snKey ?? 'sn'] as string;
    // 根据组件名，渲染不同弹窗
    const componentName = props.params?.dialogName || 'auditRecord';
    const dialogTrigger = props.params?.dialogTrigger || 'hover';
    const dialogIconName = props.params?.dialogIconName || 'el-icon-document-checked';
    const visible = ref(false);
    const top = ref(0);
    function showCb() {
      if (!visible.value) visible.value = true;
      const dom = document.getElementById(sn);
      if (dom) {
        const style = dom.getBoundingClientRect();
        top.value = style.top - 50;
      }
    }
    return () => {
      return (
        <el-popover
          placement="top"
          width={800}
          v-slots={{
            reference: () => <i id={sn} class={`icon ${dialogIconName}`}></i>
          }}
          trigger={dialogTrigger}
          onShow={showCb}
        >
          <div style={`height: ${top.value}px;`}>
            {visible.value
              ? h(resolveComponent(componentName), {
                  sn: sn,
                  type: 'table'
                })
              : ''}
          </div>
        </el-popover>
      );
    };
  }
});
