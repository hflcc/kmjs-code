import { TablePageItem } from '@/components/table/kmjsTableType';
import { Btns } from '@/components/utils/commonType';
import { checkPermission } from '@/utils/permission';

const comparison = (actions: Btns[], permission: { [key: string]: string }): Btns[] => {
  const newArr: Btns[] = [];
  actions.forEach((v) => {
    if (checkPermission(v.emit, permission)) {
      newArr.push(v);
    }
  });
  return newArr;
};

/**
 * 计算表格配置项中的按钮权限，不满足权限的将不渲染
 * */

const usePermission = (config: TablePageItem[], permission?: { [key: string]: string }) => {
  if (!config || !permission || !config.length) return;
  config.forEach((v) => {
    if (Array.isArray(v.actions)) {
      v.actions = comparison(v.actions, permission);
    }
    if (v.type === 'table') {
      const tableHander = v.tableHead?.find((s) => s.type === 'handle');
      if (tableHander && Array.isArray(tableHander.actions)) {
        tableHander.actions = comparison(tableHander.actions, permission);
      }
    }
  });
};

export default usePermission;
