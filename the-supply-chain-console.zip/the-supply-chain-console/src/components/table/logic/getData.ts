import { computed, provide, ref } from 'vue';
import { TagItem } from '@/components/utils/commonType';

/**
 * 分页请求数据的逻辑
 * */
export function PageData(getData?: (params: any) => void) {
  const searchTags = ref<TagItem[]>([]);
  // 记录当前用户的搜索入参， 分页直接用这个作为请求入参。
  const searchValue = computed(() => {
    const data: { [l: string]: string } = {};
    searchTags.value.forEach((v) => {
      for (let i = 0; i < v.key.length; i++) {
        data[v.key[i]] = v.value[i];
      }
    });
    return data;
  });
  const pageNo = ref<number>(1);
  const pageSize = ref(10);
  const totalDataNum = ref(0);
  const search = () => {
    getData?.({
      ...searchValue.value,
      page: pageNo.value - 1,
      size: pageSize.value
    });
  };
  /**
   * 点击搜索按钮时，更新请求入参
   * */
  const setSearchValue = (value: TagItem[]) => {
    value.forEach((v) => {
      const index = searchTags.value.findIndex((s) => s.tagLabel === v.tagLabel);
      if (index > -1) {
        searchTags.value.splice(index, 1);
        if (v.value[0]) searchTags.value.push(v);
      } else {
        if (v.value[0]) searchTags.value.push(v);
      }
    });
    changePage(1);
  };
  /**
   * 设置总数据条数
   * */
  const setTotalDataNum = (num: number) => {
    totalDataNum.value = num;
  };
  /**
   * 修改页面
   * */
  const changePage = (num: number) => {
    pageNo.value = num;
    search();
  };
  /**
   * 修改每页条数
   * */
  const changePageSize = (num: number) => {
    pageSize.value = num;
    search();
  };
  const closeTag = (tagLabel: string) => {
    const index = searchTags.value.findIndex((s) => s.tagLabel === tagLabel);
    if (index > -1) {
      searchTags.value.splice(index, 1);
    }
    changePage(1);
  };
  const clearTag = () => {
    searchTags.value = [];
    changePage(1);
  };
  provide('setSearchValue', setSearchValue);
  provide('changePage', changePage);
  provide('changePageSize', changePageSize);
  provide('totalDataNum', totalDataNum);
  provide('pageNo', pageNo);
  provide('pageSize', pageSize);
  provide('searchTags', searchTags);
  provide('closeTag', closeTag);
  provide('clearTag', clearTag);
  return {
    search,
    setTotalDataNum,
    changePage,
    searchValue
  };
}
