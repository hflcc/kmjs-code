/**
 * 对数据进行指定的格式化处理
 * */
import { TableConfig } from '@/components/table/kmjsTableType';
import { FormatterType } from '@/components/table/kmjsTableType';
import { formatterPrice, formatterTimer } from '@/utils';

/**
 * dateTime 格式化为时间组件， 通过 params.dataTimeType 传入格式的格式 默认为 'YYYY-MM-DD'
 *
 * */

export const formatterEven: any = {
  dateTime: (value: number, type = 'YYYY-MM-DD') => {
    if (typeof value === 'string') {
      return value;
    }
    if (!value) return undefined;
    return formatterTimer(new Date(value * 1000), type);
  },
  price: (value: number) => {
    return formatterPrice(Number(value));
  }
};

export default function useDataFormatter() {
  // 记录对应的数据key已经需要的格式化类型， 对后续的表格数据进行该方式的格式化
  const formatterMap: { [l: string]: string } = {};
  const setFormatterMap = (options: TableConfig) => {
    const tabHead = options.items.find((s) => s.type === 'table');
    tabHead?.tableHead?.forEach((v) => {
      if (v.formatter) {
        if (v.formatter === FormatterType.dateTime) {
          formatterMap[v.key as string] = `dateTime|${v.params?.dataTimeType || 'YYYY-MM-DD'}`;
        } else {
          formatterMap[v.key as string] = `${v.formatter}`;
        }
      }
    });
  };

  const dataFormatter = (tableData: any) => {
    if (Object.keys(formatterMap).length <= 0) return;
    Object.keys(tableData).forEach((v) => {
      if (formatterMap[v]) {
        const funPlay = formatterMap[v].split('|');
        tableData[v] = formatterEven[funPlay[0]]?.call(null, tableData[v], ...funPlay.slice(1));
      }
    });
  };
  return {
    setFormatterMap,
    dataFormatter
  };
}
