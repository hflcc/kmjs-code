import { Btns } from '@/components/utils/commonType';
import { ref } from 'vue';
import {
  goToCreateBpmByBusiness,
  goToFormCreate,
  goToFormDetail,
  goToFormEdit
} from '@/pages/commonPage';
import { createBpmByDefSn, getBpmAlertMsg } from '@/utils/commApi';
import { ElMessageBox } from 'element-plus';
import useOrganization from '@/store/commModules/organization/useOrganization';

const useBpm = (
  search: () => void,
  setCallBack: (callBack: () => void) => {
    b: string;
    c: string;
  }
) => {
  const { activeOrganization } = useOrganization();
  const showBpmResultWindow = ref(false);
  const createBpmResultData = ref<{ isSuccess: boolean; data: SubmitResultData }>({
    isSuccess: false,
    data: {
      title: '',
      subTitle: ''
    }
  });
  const closeBpmResultWindow = () => {
    showBpmResultWindow.value = false;
  };
  const showBpmWindow = ref(false);
  let clickSn = '';
  // 用户点击当前行按钮时，记录当前行的数据和按钮的配置
  let clickRow: null | [{ row: Record<string, unknown> }, Btns] = null;

  const bpmWindowConfig = ref({
    title: '',
    type: ''
  });
  /**
   * 隐藏流程类型选择弹窗
   * */
  const hideBpmWindow = () => {
    showBpmWindow.value = false;
  };
  /**
   * 获取用户在弹窗中选择的流程SN，并根据是否需要跳转页面来判断是否跳转页面还是直接发起流程
   * */
  const getBpmSn = (bpmSn: string) => {
    if (!clickRow) return;
    const [tableCellData, config] = clickRow;
    hideBpmWindow();
    if (config.params?.noForm) {
      const obj = Object.assign({}, config.params, {
        defSn: bpmSn
      });
      staticCreateBpm(obj as Record<string, string>, tableCellData.row);
      clickRow = null;
      return;
    }
    goToCreateBpmByBusiness(bpmSn, clickSn);
    clickRow = null;
  };

  /**
   * 直接发起流程函数，先获取提示信息，用户确认后直接发起流程
   * */
  const staticCreateBpm = (params: Record<string, string>, rowData: Record<string, unknown>) => {
    getBpmAlertMsg(params.defSn, undefined, JSON.stringify(rowData)).then((res) => {
      if (!res) return;
      if (res.success) {
        ElMessageBox.confirm(res.title, '提示').then(() => {
          createBpmByDefSn(params?.defSn, {
            bizSn: rowData[params?.dataSnKey || 'sn'] as string,
            jsonFormData: JSON.stringify(rowData),
            createdOrgTreeSn: activeOrganization.value?.sn || '',
            createdOrgTreeName: activeOrganization.value?.name || ''
          }).then((res) => {
            if (res) {
              createBpmResultData.value = {
                isSuccess: res.success,
                data: {
                  title: res.title,
                  subTitle: res.subTitle,
                  data: res.data
                }
              };
              // 刷新数据
              showBpmResultWindow.value = true;
              search();
            }
            return;
          });
        });
      } else {
        ElMessageBox.alert(res.title);
      }
    });
  };

  const play = (name: string, data: [{ row: Record<string, unknown> }, Btns]) => {
    clickRow = data;
    const [tableCellData, config] = data;
    // 处理跳转详情/编辑时的逻辑
    switch (name) {
      case 'tableTableDetail':
        goToFormDetail(
          config.params?.defSn,
          tableCellData.row[config.params?.dataSnKey || 'sn'] as string
        );
        break;
      case 'tableTableCreate':
        goToFormCreate(
          config.params?.defSn || tableCellData.row[config.params?.dataSnKey || 'sn'],
          {
            sn: tableCellData.row['sn']
          }
        );
        break;
      case 'tableTableEdit':
        goToFormEdit(
          config.params?.defSn,
          tableCellData.row[config.params?.dataSnKey || 'sn'] as string,
          setCallBack(search)
        );
        break;
      case 'tableTableBpm':
        clickSn = tableCellData.row[config.params?.dataSnKey || 'sn'] as string;
        if (config.params?.defSn) {
          goToCreateBpmByBusiness(config.params.defSn, clickSn);
        } else {
          showBpmWindow.value = true;
          bpmWindowConfig.value.type = config.params?.bpmType || '';
        }
        break;
      case 'tableTableBpmStatic':
        staticCreateBpm(config.params as Record<string, string>, tableCellData.row);
        break;
    }
  };

  return {
    showBpmResultWindow,
    bpmWindowConfig,
    hideBpmWindow,
    createBpmResultData,
    closeBpmResultWindow,
    showBpmWindow,
    getBpmSn,
    play
  };
};

export default useBpm;
