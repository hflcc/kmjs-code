import { TablePageItem } from '@/components/table/kmjsTableType';
import store from '@/store';

/**
 * 预先加载表格配置的字典数据
 * */
export default async function useTableDictionary(config: TablePageItem[]) {
  const dictionaryNames: string[] = [];
  const tableConfig = config.find((s) => s.type === 'table');
  tableConfig?.tableHead?.forEach((v) => {
    if (v.type === 'mapText' && v.params.type === 'dictionary') {
      dictionaryNames.push(v.params.dictionaryName);
    }
  });
  await store.dispatch('dictionaries/getData', dictionaryNames);
}
