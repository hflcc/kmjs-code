import { defineComponent, PropType } from 'vue';
import { buildBtn } from '@/components/utils/buildTsx/btn';
import { Btns } from '@/components/utils/commonType';
import { localEmit } from '@/components/table/components/commSetup';

export default defineComponent({
  name: 'kmjs-table-title',
  props: {
    title: {
      type: String as PropType<string>,
      default: ''
    },
    actions: {
      type: Array as PropType<Btns[]>,
      default: () => []
    }
  },
  setup() {
    const { localEmitFun } = localEmit('title');
    return {
      localEmitFun
    };
  },
  render() {
    const { localEmitFun, actions, title } = this;
    return (
      <div class="kmjs-table-title-wrap">
        <h1 class="title">{title}</h1>
        <div class="btn-area">
          {/*<el-button*/}
          {/*  class="el-button--refresh"*/}
          {/*  type="default"*/}
          {/*  icon="el-icon-refresh-right"*/}
          {/*  size="medium"*/}
          {/*  onClick={() => {*/}
          {/*    localEmitFun('$refresh');*/}
          {/*  }}*/}
          {/*></el-button>*/}
          {actions.map((v) => {
            return buildBtn(v, localEmitFun);
          })}
        </div>
      </div>
    );
  }
});
