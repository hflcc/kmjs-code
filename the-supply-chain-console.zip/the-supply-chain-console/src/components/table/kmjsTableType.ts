import { FormItem } from '@/components/form/type';
import { Btns } from '@/components/utils/commonType';

export enum FormatterType {
  dateTime = 'dateTime',
  mapText = 'mapText',
  price = 'price'
}

export interface Options {
  label: string;
  value: string;
}

export interface BtnShowRule {
  // 表格中控制按钮展示的key
  columnKey: string;
  // 表格中控制按钮展示的key对应的值， 就是说某个key的值是这个时，按钮展示
  columnValue: any;
}

export type TableCell =
  | 'hide'
  | 'text'
  | 'mapText'
  | 'rangeText'
  | 'slot'
  | 'handle'
  | 'image'
  | 'address'
  | 'formatter'
  | 'fileListView'
  | 'listView'
  | 'expiredDate'
  | 'area'
  | 'expansion'
  | 'stepInput' // 步进器 是一个数字输入框
  | undefined;

export interface TableColumn {
  fixed?: string;
  // 表格单元格渲染出现的类型
  type?: TableCell;
  label: string;
  // 操作栏时可为空
  key?: string;
  row?: number | 'key';
  rowKey?: string;
  actions?: Btns[];
  width?: number;
  align?: 'left' | 'right';
  // 对内容的简单格式化， 详情请看 src/components/table/logic/useFormatter.ts
  formatter?: FormatterType | undefined;
  // 后续类型扩展时的配置参数的位置
  params?: any;
}

interface SummaryShowKeyItem {
  key: string;
  afterPoint: number;
}

export interface TableParams {
  summary?: boolean;
  summaryShowKeys?: SummaryShowKeyItem[];
  isExpand?: boolean;
  templateName?: string;
}

export interface TablePageItem {
  // 多个表格存在时需要这个name
  name?: '';
  // 搜索或者分页时触发的数据变化的table
  tableName?: '';
  // 表格页面组成的类型
  type: 'title' | 'search' | 'table';
  isSlot?: boolean;
  title?: string;
  actions?: Btns[];
  inputs?: FormItem[];
  tableHead?: TableColumn[];
  tableConfig?: TableParams;
  tableSelectMode?: 'multiple' | 'single';
}

export interface TableConfig {
  // 请求表格数据的接口地址
  tableDataUrl: string;
  items: TablePageItem[];
}

export interface TableMethods {
  // 触发从新搜索，当前页面搜索
  refresh: () => void;
  // 从第一页搜索
  refreshAll: () => void;
  // 获取搜索区域用户的输入的数据
  getSearchData: () => Promise<{ [l: string]: any }>;
  getResponse: () => Readonly<Record<string, unknown>>;
  setTableData: (data: any[]) => void;
  getTableData: () => any[];
  getCheckData: () => any[];
  setSearchOptions: (key: string, data: Options[]) => void;
  setCheckDisabled: (i: number, disabled: boolean, isCheck: boolean) => void;
}

export interface UseTableProps {
  reqBody?: { [l: string]: any };
  pathBody?: string[];
  dataFormatter?: (tableData: any[]) => any[];
  tableHandler?: (name: string, data: any[]) => void;
  beforeRequest?: (requestObj: {
    url: string;
    params: any;
  }) => Promise<{ url: string; params: any }>;
}

export type BuildCellEvent = {
  // 改变checkbox的是否可选的disable状态
  changeDisable: (i: number, disabled: boolean | undefined, isCheck: boolean) => void;
  // 触发表格重新渲染
  renderTable: () => void;
  // 刷新表格数据，从新请求数据
  refresh: () => void;
};
