# 表格控件使用基本说明

> 初心：  
> &nbsp;&nbsp;&nbsp;&nbsp;是配合可视化配置平台，通过JSON来主导表格的样式标签
> > 可视化配置平台还在开发中，优先级过于低

## 基本使用例子

```vue

<template>
  <kmjsTable :ctl="tableCtl"></kmjsTable>
</template>
<script lang="ts">
import { defineComponent } from 'vue';
import kmjsTable, { useTable } from '@/components/table';

export default defineComponent({
  name: 'project-index',
  components: {
    kmjsTable
  },
  setup() {
    const [ tableCtl, tableMethods ] = useTable({
      sn: 'project', // 获取JSON指定的key
      pathBody: [],// 该数组内的字符串会默认拼接到请求表格数据的url上面
      reqBody: {},// 该对象内的数据，会作为请求表格数据的query,
      // 该函数，会在数据请求完成后调用。可以对请求数据做进一步的处理
      dataFormatter: (tableData) => {
        return tableData;
      },
      // 这里是所有的事件分发。 事件名称是， 当前按钮处的区域+定义的事件名称（首字母大写）
      // 如果不确定按钮对应的事件名称，可以先console.log(name,data)查看
      tableHandler: (name: string, data: any[]) => {
        // 如果不确定按钮对应的事件名称，可以先console.log(name,data)查看
        console.log(name, data)
        switch (name) {
          case 'tableHuman': // 表示，表格中的按钮绑定了human的事件
            break;
          default:
            break;
        }
      }
    });
    // 从第一页进行请求
    tableMethods.refreshSearch()
    // 从新请求有当前页数据
    tableMethods.search()
    return { tableCtl };
  }
});
</script>
```

## table JSON配置项详解

```
{
  "tableDataUrl": "",// 请求表格数据的地址
  "items": [
    {
      "type": "title", // 头部区域
      "title": "消费明细" // 头部区域的文字
      "actions": [ // 头部右边的按钮
          {
            "type": "primary", // 按钮的类型
            "label": "新增配置", // 按钮的文字
            "emit": "showSwitchDialog" // 按钮被点击时触发的事件名称
          }
        ]
    },
    {
      "type": "search", // 搜索区域
      "isSlot": true, // 高级搜索是否使用slot， 有些比较灵活的情况下比如说某个选项是和当前业务逻辑强耦合的
      "inputs": [ // 这里的配置项和动态表单的一致
        {
          "label": "姓名",
          "key": "actorUserName",
          "type": "text"
        },
        {
          "label": "手机号",
          "key": "actorUserPhone",
          "type": "text"
        },
        {
          "label": "方案",
          "key": "projectSn",
          "type": "select",
          "options": [
          ]
        },
        {
          "label": "推荐人姓名",
          "key": "actorName",
          "type": "text"
        },
        {
          "label": "推荐人手机号",
          "key": "actorPhone",
          "type": "text"
        },
        {
          "label": "来源",
          "key": "resultTypeName",
          "type": "select"
        },
        {
          "label": "消费时间",
          "key": "bizAt",
          "type": "daterange",
          "dateConfig": {
            "startKey": "completeStartAt",
            "endKey": "completeEndAt"
          }
        }
      ]
    },
    {
      "type": "table", // 表格区域
      "tableHead": [ // 表头
        // type 具有 text（默认）文字， image 图片， mapText code转name， handle 展示按钮，rangeText 两个字段组合展示；
        { // cell 的类型 不写type的话默认是text
          "label": "ID",
          "key": "id"
        },
        {
          "type": "image", // 图片类型
          "label": "落地页面图片", // 表头中的文字
          "key": "final_img", // 表头的key
          "width": 200 // 宽度
        },
        {
          "label": "消费时间",
          "key": "createdAt",
          "formatter": "dateTime", // 对数据进行格式化
          "params": { // 扩展参数，一般直接用于tableCell子组件的渲染
            "dataTimeType": "时间格式化需要的格式 默认是YYYY-MM-DD, 入参按照 moment.js的formatter格式一致"
          }
        },
        {
          "label": "周期",
          "key": "time",
          "type": "rangeText", // 两个字段组合展示 xxxx~xxxx
          "params": {
            "startKey": "startAt", // 开始的字段key
            "endKey": "endAt", // 结束的字段key
            "formatter"?: "dateTime" // 需要对数据格式时可选的格式
            "formatterType"?: "YYYY-MM-DD" // 格式化对应入参
          }
        },
        {
          "label": "提成人类型",
          "key": "type",
          "type": "mapText", // 应用于后台返回CODE时前端展示code对应的文字
          "params": {
            // mapText的配置项
            "type": "local" | "dictionary", 本地数据模式 ｜ 字典模式
            "dictionaryName"?: "字典名称",
            "localData"?: { // 本地数据模式的数据
              "sales": "业务员",
              "partner": "合伙人"
            }
          }
        },
        {
          "type": "handle", // tableCell中展示按钮，默认是text类型
          "label": "操作", // 表头文字
          "actions": [
            {
              "label": "查看合伙人", // 按钮文字
              "emit": "seePartner" // 按钮被点击时触发的事件
            },
            {
              "label": "转移合伙人",
              "emit": "transPartner",// 按钮被点击时触发的事件
              "show"?: "rule", // 控制按钮是否展示 有三个可选值 always（默认值） 一直展示 never 从不展示 rule 根据规则（rules）来判断是否展示
              "rules"?: [
                {
                  "columnKey": "showTrans", // 需要数据中的哪个key来控制展示
                  "columnValue": "true" // key对应的值是什么情况下展示
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```
