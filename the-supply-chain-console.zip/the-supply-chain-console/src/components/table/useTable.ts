import { Options, TableMethods, UseTableProps } from '@/components/table/kmjsTableType';

export function useTable(props: UseTableProps): [(m: TableMethods) => void, TableMethods] {
  let tableInterance: TableMethods;
  const ctl = (methos: TableMethods) => {
    tableInterance = methos;
    return props;
  };
  const methos: TableMethods = {
    refreshAll() {
      tableInterance?.refreshAll?.();
    },
    refresh() {
      tableInterance?.refresh?.();
    },
    getSearchData() {
      return tableInterance?.getSearchData();
    },
    getResponse: () => tableInterance?.getResponse(),
    setTableData(data: any[]) {
      return tableInterance?.setTableData(data);
    },
    setCheckDisabled(i: number, disabled: boolean, isCheck: boolean) {
      tableInterance?.setCheckDisabled(i, disabled, isCheck);
    },
    setSearchOptions(key: string, data: Options[]) {
      tableInterance?.setSearchOptions(key, data);
    },
    getTableData() {
      return tableInterance?.getTableData();
    },
    getCheckData() {
      return tableInterance?.getCheckData();
    }
  };
  return [ctl, { ...methos }];
}
