import { defineComponent, inject, PropType, reactive, ref } from 'vue';
import kmjsFrom from '@/components/form/form';
import { FormItem, ParentConfig } from '@/components/form/type';
import buildFormItem from './buildFormItem';
import autoSearch from '@/components/table/search/autoSearch.tsx';
import { TagItem } from '@/components/utils/commonType';
import { localEmit } from '@/components/table/components/commSetup';

interface SearchItem extends FormItem {
  hideAuto: boolean;
}

export default defineComponent({
  name: 'kmjs-table-search',
  props: {
    searchItem: {
      type: Array as PropType<SearchItem[]>,
      default: () => []
    }
  },
  components: {
    kmjsFrom,
    autoSearch
  },
  setup(props) {
    const { localEmitFun } = localEmit('search');
    const onSearch = inject<(data: any) => void>('setSearchValue');
    const items = buildFormItem(props.searchItem);
    const formConfig = reactive<ParentConfig>({
      dictionary: items.dictionarys,
      showMessage: false,
      inline: true,
      labelWidth: '',
      labelPosition: 'left',
      submitText: '搜索',
      resetText: '重置',
      size: 'mini',
      showBtn: true
    });
    const showDetail = ref(false);
    const changeShowDetail = () => {
      showDetail.value = !showDetail.value;
    };
    const formData = ref<SearchItem[]>(props.searchItem);
    /**
     * 提交数据给请求函数
     * @param data 请求的入参数
     * */
    const submitData = (data: TagItem[]) => {
      // debugger;
      const searchData: TagItem[] = [];
      data.forEach((v) => {
        // 时间间隔选择器特殊处理
        const dateRangeIndex = v.key.indexOf('daterange');
        if (dateRangeIndex > -1) {
          v.key.splice(dateRangeIndex, 1);
          v.value.splice(dateRangeIndex, 1);
        }
        for (let i = 0; i < v.value.length; i++) {
          if (v.value[i] === undefined || v.value[i] === '') {
            v.value.splice(i, 1);
            v.key.splice(i, 1);
            i--;
          }
        }
        searchData.push(v);
      });
      onSearch?.(searchData);
    };
    return {
      localEmitFun,
      showDetail,
      changeShowDetail,
      autoSearch,
      formConfig,
      formData,
      submitData
    };
  },
  render() {
    const { formConfig, formData, submitData, changeShowDetail, showDetail, localEmitFun } = this;
    const slots = this.$slots;
    return (
      <div class="kmjs-table-search-wrap">
        {/*基本搜索*/}
        <autoSearch
          // 过滤下不显示在模糊搜索中的内容
          searchTypes={formData.filter((s) => !s.hideAuto)}
          onSubmit={submitData}
          v-slots={{
            default() {
              return (
                <el-button type="text" onClick={changeShowDetail}>
                  {showDetail ? '快捷搜索' : '高级搜索'}
                </el-button>
              );
            }
          }}
        />
        {/*高级搜索*/}
        {showDetail ? (
          <>
            <div class="line" />
            {slots['default'] ? (
              slots['default']({ submitData })
            ) : (
              <div class="detail-search">
                <kmjs-from
                  parentConfig={formConfig}
                  itemData={formData}
                  onFromChange={(data: { key: string; value: string }) =>
                    localEmitFun('searchChange', data)
                  }
                  onSubmitFun={submitData}
                />
              </div>
            )}
          </>
        ) : null}
      </div>
    );
  }
});
