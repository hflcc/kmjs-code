/**
 * 直接将form的子选项扩展拿过来，进行渲染
 * */
import { defineComponent, PropType, ref } from 'vue';
import buildFormItem from '@/components/form/items';
import { FormItem, InputType } from '@/components/form/type';
import { TagItem } from '@/components/utils/commonType';
import { formatterTimer } from '@/utils';
import store from '@/store';
import { ElMessage } from 'element-plus';

export default defineComponent({
  name: 'table-auto-search',
  props: {
    searchTypes: {
      type: Array as PropType<FormItem[]>,
      required: true
    }
  },
  setup: function (props, { emit }) {
    // 记录用户输入的值
    const formData = ref<{ [l: string]: any }>({});
    // 表单的默认值
    const defaultData: { [l: string]: any } = {};
    // 缓存当前用户选择模糊搜索对应的表单配置项
    const checkItem = ref<FormItem>();
    // 记录缓存当前用户选择模糊搜索的key
    const searchType = ref('');
    // 记录搜索的key和默认值
    props.searchTypes.forEach((v) => {
      formData.value[v.key] = '';
      defaultData[v.key] = '';
    });
    // 改变模糊搜索的类型，并记录下默认搜索对应的表单配置项
    const changeSearchType = (v: string) => {
      checkItem.value = props.searchTypes.find((s) => s.key === v);
      if (checkItem.value?.dictionaryName && !checkItem.value?.options?.length) {
        store.dispatch('dictionaries/getData', [checkItem.value?.dictionaryName]).then((res) => {
          if (checkItem.value) {
            checkItem.value.options = res[checkItem.value.dictionaryName as string].map(
              (v: DictionariesItem) => {
                return {
                  label: v.name,
                  value: v.code
                };
              }
            );
          }
        });
      }
      searchType.value = v;
      formData.value = { ...defaultData };
    };
    // 默认选中第一个
    changeSearchType(props.searchTypes[0]?.key);
    const reset = () => {
      formData.value = { ...defaultData };
    };
    /**
     * 提交数据， 触发搜索
     * */
    const submit = () => {
      const item = checkItem.value;
      const key = item?.key;
      if (!key) return;
      const returnData: TagItem[] = [];
      if (item) {
        let tagValue = formData.value[key];
        // 对于使用select，checkbox，radio等转译成显示的label
        if (Array.isArray(item.options)) {
          tagValue = item.options.find((v) => v.value === tagValue)?.label || tagValue;
        }
        const obj: TagItem = {
          tagLabel: item.label as string,
          tagValue,
          key: [],
          value: []
        };
        // 对于时间间隔特殊处理
        if (item.type === InputType.daterange) {
          if (Array.isArray(tagValue) && tagValue.length > 0 && tagValue[0] && tagValue[1]) {
            if (item.dateConfig?.startKey) {
              obj.key.push(item.dateConfig?.startKey);
              obj.value.push(new Date(tagValue[0]).getTime() / 1000);
            }
            if (item.dateConfig?.endKey) {
              obj.key.push(item.dateConfig?.endKey);
              obj.value.push(new Date(tagValue[1]).getTime() / 1000);
            }
            obj.tagValue = `${formatterTimer(new Date(tagValue[0]))} 至 ${formatterTimer(
              new Date(tagValue[1])
            )}`;
          } else {
            ElMessage.info('请选择开始时间和结束时间');
            return;
          }
        } else {
          obj.key.push(item.key);
          obj.value.push(formData.value[key]);
        }
        returnData.push(obj);
      }
      emit('submit', returnData);
      reset();
    };

    return { checkItem, formData, changeSearchType, searchType, submit, reset };
  },
  render() {
    const { checkItem, formData, searchTypes, changeSearchType, searchType, submit } = this;
    const slots = this.$slots;
    const options = searchTypes.map((item) => {
      return <el-option value={item.key} label={item.label} key={item.key} />;
    });
    return (
      <div class="auto-search-area">
        <div class="search-input-area">
          <el-select
            v-model={searchType}
            size="mini"
            style={{ width: '150px' }}
            onChange={changeSearchType}
            placeholder="请选择搜索项"
          >
            {options}
          </el-select>
          {checkItem ? (
            <div class="center-input">
              {buildFormItem(
                Object.assign({}, checkItem, {
                  attr: { style: { width: '300px' }, size: 'mini' }
                }),
                formData,
                1,
                {
                  change: () => ''
                },
                slots
              )}
            </div>
          ) : (
            ''
          )}
          <el-button size="mini" onClick={submit}>
            搜索
          </el-button>
        </div>
        {slots['default']?.()}
      </div>
    );
  }
});
