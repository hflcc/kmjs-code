/**
 * 转换数据类型
 * */
import { FormItem } from '@/components/form/type';

export default function (inputs: FormItem[]): {
  dictionarys: string[];
} {
  const dictionarys: string[] = [];
  inputs.forEach((s) => {
    if (s.dictionaryName) {
      dictionarys.push(s.dictionaryName);
    }
    s.show = true;
  });
  return {
    dictionarys
  };
}
