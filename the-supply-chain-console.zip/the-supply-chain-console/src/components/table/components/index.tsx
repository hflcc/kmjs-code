import { TablePageItem } from '@/components/table/kmjsTableType';
import { Slots } from '@vue/runtime-core';
// import tableTitle from '@/components/table/title';
import tableSearch from '@/components/table/search';
import tableTable from '@/components/table/table';

/**
 * 搭建整体表格页框架
 * */
export const buildTablePageItem = (v: TablePageItem, tableContentData: any[], slots: Slots) => {
  switch (v.type) {
    case 'title':
      return <tableTitle title={v.title} actions={v.actions} />;
    case 'search':
      if (v.isSlot) {
        return <tableSearch searchItem={v.inputs} v-slots={slots['search']}></tableSearch>;
      } else {
        return <tableSearch searchItem={v.inputs} />;
      }
    case 'table':
      return (
        <tableTable
          ref="tableVNode"
          tableData={tableContentData}
          columns={v.tableHead}
          actions={v.actions}
          v-slots={slots}
          tableConfig={v.tableConfig}
          config={v}
        />
      );
    default:
      return null;
  }
};
