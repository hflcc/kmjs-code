import { inject, provide } from 'vue';
import { firstUpperCase } from '@/utils';

/**
 * 公共注册接收方法
 * */
export function provideLocalEmit(callBack: (name: string, data: unknown[]) => void) {
  // 向下传播方法， 供各个功能组件对外触发事件
  provide('emitFun', callBack);
}

/**
 * 公共对外抛方法处理
 * */
export function localEmit(componentName: string) {
  const emitFun = inject<(name: string, ...data: any[]) => void>('emitFun');
  const localEmitFun = (name: string, ...data: any[]) => {
    emitFun?.(componentName + firstUpperCase(name), ...data);
  };
  return {
    localEmitFun
  };
}
