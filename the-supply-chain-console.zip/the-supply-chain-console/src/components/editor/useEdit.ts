import { ref } from 'vue';

export interface Options {
  autoFocus?: boolean;
  onchange?: (html: string) => void;
  onblur?: (html: string) => void;
  onfocus?: (html: string) => void;
  menus?: string[];
  showFullScreen?: boolean;
  // 拥有可以编辑的权限
  permission?: string[];
  placeholder?: string;
}

export interface EditVnode {
  setData: (data: string) => void;
  getData: () => string;
  clear: () => void;
  setDisabled: (flag: boolean) => void;
}

export interface EditFun extends EditVnode {
  a?: 1;
}

/**
 * 返回一个controller和方法的接口
 * */
export const useEdit = (
  options: Options
): [(obj: { setOptions: (op: Options) => EditVnode }) => void, EditFun] => {
  const edit = ref<Nullable<EditVnode>>(null);
  // 这里临时存下没有实例化前调用的方法，
  // [要设置的内容, 是否禁用]
  const defaultData: [Nullable<string>, Nullable<boolean>] = [null, null];
  const obj: EditFun = {
    getData() {
      return edit.value?.getData() || '';
    },
    clear() {
      edit.value?.clear();
    },
    setDisabled(value: boolean) {
      if (edit.value) {
        edit.value.setDisabled(value);
      } else {
        defaultData[1] = value;
      }
    },
    setData(data: string) {
      if (edit.value) {
        edit.value.setData(data);
      } else {
        defaultData[0] = data;
      }
    }
  };
  const controller = (ev: { setOptions: (op: Options) => EditVnode }) => {
    edit.value = ev.setOptions(options);
    if (typeof defaultData[0] === 'string') {
      edit.value.setData(defaultData[0]);
      defaultData[0] = null;
    }
    if (typeof defaultData[1] === 'boolean') {
      edit.value.setDisabled(defaultData[1]);
      defaultData[1] = null;
    }
  };
  return [controller, obj];
};
