import { defineComponent, onMounted, PropType, getCurrentInstance } from 'vue';
// import { checkPermission } from '@/utils/permission';
import { ElMessageBox } from 'element-plus';
import './style.less';
import E from 'wangeditor';
import { Options, EditVnode } from './useEdit';
import xss from 'xss';
import { getFileUrlBySeq, uploadFile } from '@/utils/commApi';

/**
 * 初始化编辑器
 * @param options {Options} 配置项
 * @return E 实例化后的编辑器实例
 * */
const initEditor = (id: string, options: Required<Options>) => {
  const editor = new E('#' + id);
  editor.config.focus = options.autoFocus;
  editor.config.onblur = options.onblur;
  editor.config.onfocus = options.onfocus;
  editor.config.onchange = options.onchange;
  editor.config.menus = options.menus;
  editor.config.zIndex = 100;
  editor.config.onchangeTimeout = 400;
  // 是否显示全屏
  editor.config.showFullScreen = options.showFullScreen;
  // 隐藏插入网络图片的功能
  editor.config.showLinkImg = false;
  // 隐藏插入网络视频的功能
  // editor.config.showLinkVideo = false;
  // 图片使用base64
  // editor.config.uploadImgShowBase64 = true;
  // 开启本地上传图片(这是后端上传链接)
  editor.config.customUploadImg = function (
    resultFiles: FileList,
    insertImgFn: (res: string) => void
  ) {
    uploadFile(resultFiles[0]).then((res) => {
      getFileUrlBySeq(res.seq).then((r) => {
        insertImgFn(r[res.seq].url.replace(/([?#])[^'"]*/, ''));
      });
    });
  };
  // 默认提示文字
  editor.config.placeholder = options.placeholder || '请输入';

  // 配置粘贴文本的内容处理
  editor.config.pasteTextHandle = function (pasteStr: string) {
    // 对粘贴的文本进行处理，然后返回处理后的结果
    return pasteStr.replace(/<o:p>[\s\S]*?<\/o:p>/g, '');
  };

  // editor.config.fontSizes = {
  //   'x-small': { name: '10px', value: '1' },
  //   'small': { name: '13px', value: '2' },
  //   'normal': { name: '16px', value: '3' },
  //   'large': { name: '18px', value: '4' },
  //   'x-large': { name: '24px', value: '5' },
  //   'xx-large': { name: '32px', value: '6' },
  //   'xxx-large': { name: '48px', value: '7' },
  // }
  editor.config.colors = [
    '#000000',
    '#666666',
    '#cccccc',
    '#d9d9d9',
    '#980000',
    '#ff0000',
    '#ff9900',
    '#ffff00',
    '#00ff00',
    '#00ffff',
    '#4a86e8',
    '#0000ff',
    '#9900ff',
    '#ff00ff',
    '#e6b8af',
    '#f4cccc',
    '#fce5cd',
    '#fff2cc',
    '#d9ead3',
    '#d0e0e3',
    '#c9daf8',
    '#cfe2f3',
    '#d9d2e9',
    '#ead1dc',
    '#dd7e6b',
    '#ea9999',
    '#f9cb9c',
    '#ffe599',
    '#b6d7a8',
    '#a2c4c9',
    '#a4c2f4',
    '#9fc5e8',
    '#b4a7d6',
    '#d5a6bd',
    '#cc4125',
    '#e06666',
    '#f6b26b',
    '#ffd966',
    '#93c47d',
    '#76a5af',
    '#6d9eeb',
    '#6fa8dc',
    '#8e7cc3',
    '#c27ba0',
    '#a61c00',
    '#cc0000',
    '#e69138',
    '#f1c232',
    '#6aa84f',
    '#45818e',
    '#3c78d8',
    '#3d85c6',
    '#674ea7',
    '#a64d79',
    '#5b0f00',
    '#660000',
    '#783f04',
    '#7f6000',
    '#274e13',
    '#0c343d',
    '#1c4587',
    '#073763',
    '#20124d',
    '#4c1130'
  ];

  // 表情包配置
  editor.config.emotions = [
    {
      // tab 的标题
      title: '表情',
      // type -> 'emoji' / 'image'
      type: 'emoji',
      // content -> 数组
      content:
        '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 😘 😗 😙 😚 😋 😛 😝 😜 🤓 😎 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 😢 😭 😤 😠 😡 😳 😱 😨 🤗 🤔 😶 😑 😬 🙄 😯 😴 😷 🤑 😈 🤡 💩 👻 💀 👀 👣'.split(
          /\s/
        )
    },
    {
      // tab 的标题
      title: '手势',
      // type -> 'emoji' / 'image'
      type: 'emoji',
      // content -> 数组
      content:
        '👐 🙌 👏 🤝 👍 👎 👊 ✊ 🤛 🤜 🤞 ✌️ 🤘 👌 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤙 💪 🖕 ✍️ 🙏'.split(
          /\s/
        )
    }
  ];
  editor.config.customAlert = function (s: string, t: string) {
    switch (t) {
      case 'success':
        ElMessageBox.alert(s, {
          type: 'success'
        });
        break;
      case 'info':
        ElMessageBox.alert(s, {
          type: 'info'
        });
        break;
      case 'warning':
        ElMessageBox.alert(s, {
          type: 'warning'
        });
        break;
      case 'error':
        ElMessageBox.alert(s, {
          type: 'error'
        });
        break;
      default:
        ElMessageBox.alert(s, {
          type: 'info'
        });
        break;
    }
  };
  // 屏蔽视频
  // editor.config.excludeMenus = ['video'];
  editor.create();
  return editor;
};
export { useEdit } from './useEdit';
export default defineComponent({
  name: 'kmjs-editor',
  props: {
    controller: {
      type: Function as PropType<(obj: { setOptions: (op: Options) => EditVnode }) => void>,
      default: () => {
        return null;
      }
    }
  },
  setup(props) {
    const current = getCurrentInstance();
    const elemId = 'editorWrap-' + current?.uid ?? new Date().getTime().toString(16);
    let editor: E;
    // 记录下是否被禁用
    let disable = false;
    // 是否可以编辑的权限控制， true 说明权限通过校验可以编辑， false说明没有编辑的权限
    // let permission = true;
    let options: Options = {
      autoFocus: false,
      menus: [
        'head',
        'bold',
        'fontSize',
        'fontName',
        'italic',
        'underline',
        'strikeThrough',
        'indent',
        'lineHeight',
        'foreColor',
        'backColor',
        'link',
        'list',
        'todo',
        'justify',
        'quote',
        'emoticon',
        'image',
        'table',
        'code',
        'splitLine',
        'undo',
        'redo'
      ],
      showFullScreen: false
    };
    const clearContent = () => {
      editor?.txt.clear();
    };
    const setDisabled = (flag: boolean) => {
      disable = flag;
      if (flag) {
        editor?.disable();
      } else {
        editor?.enable();
      }
    };
    const change = (html: string, fun?: (html: string) => void) => {
      // || !permission
      if (disable) return;
      fun?.(xss(html));
    };
    onMounted(() => {
      props.controller({
        setOptions(op: Options) {
          options = Object.assign({}, options, op, {
            onblur: (html: string) => {
              change(html, op.onblur);
            },
            onfocus: (html: string) => {
              change(html, op.onfocus);
            },
            onchange: (html: string) => {
              change(html, op.onchange);
            }
          });
          editor = initEditor(elemId, options as Required<Options>);
          if (options.permission) {
            // permission = checkPermission(options.permission);
            // if (!permission) {
            //   setDisabled(true);
            // }
          }
          return {
            getData(): string {
              return xss(editor?.txt.html() as string) || '';
            },
            clear: clearContent,
            setDisabled,
            setData(data: string) {
              editor?.txt.html(data);
            }
          };
        }
      });
    });
    return () => {
      return <div class="editor-wrap" id={elemId}></div>;
    };
  }
});
