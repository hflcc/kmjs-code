import { BtnShowRule } from '@/components/table/kmjsTableType';

export interface Btns {
  // 按钮渲染类型 大部分对应element的样式， refresh显示刷新图标
  // tableDetail 表格中的详情模式，自动处理跳转详情
  // tableEdit 表格中的编辑模式， 自动处理跳转编辑
  // createBpm 新建流程
  type?:
    | 'default'
    | 'text'
    | 'refresh'
    | 'primary'
    | 'tableDetail'
    | 'tableEdit'
    | 'createBpm'
    | 'danger'
    | 'unclickable'
    | 'warning';
  label: string;
  emit: string;
  // 按钮是否展示 默认值是 'always'
  show?: 'always' | 'never' | 'rule';
  ruleType?: 'or' | 'and';
  // 满足数组中的规则时，会展示按钮
  rules?: BtnShowRule[];
  params?: Record<string, any>;
  btnConfig?: any;
}

export interface ModuleItem {
  // 保证唯一行，但是我不会取检查它
  name: string;
  // slot 使用slot进行渲染， 必须有slotName配置项
  type:
    | 'wrap-module'
    | 'tab-module'
    | 'tab-module-item'
    | 'table'
    | 'form'
    | 'slot'
    | 'card' // 主要用在详情模式
    | 'form-slot-module' // 表单模块特有的组件
    | 'form-module-table'; // 表单模块特有的组件;
  // 每个组件的配置项
  params?: any;
  // 如果需要动态slot使用这个
  slotName?: string;
  // 子组件
  children?: ModuleItem[];
  // 当前组件的权限
  permissions?: Btns[];
  // 组件内部的slot配置 比如table的search区域可以自定义搜索
  slotParam?: {
    // slot 的位置。会将该组件插入到模块的指定位置
    name: string;
    // 在全局的slots中寻找都寻找不到的话就不进行渲染
    slotName: string;
  }[];
  // 模块配置
  moduleParams?: Record<string, unknown>;
}

export interface TagItem {
  // tag的label，一般是表单的label
  tagLabel: string;
  // tab的显示的值，是处理后显示给用户看的值
  tagValue: string;
  // 提交给后台的key
  key: string[];
  // key对应的值
  value: any[];
}
