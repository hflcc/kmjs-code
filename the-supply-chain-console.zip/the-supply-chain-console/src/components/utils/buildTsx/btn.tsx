import { Btns } from '@/components/utils/commonType';

const logicType = [
  'tableCreate',
  'tableDetail',
  'tableEdit',
  'tableBpm',
  'tableBpmStatic',
  'createBpm',
  'createForm',
  'location'
];

/**
 * 创建按钮组件
 * */
export function buildBtn(
  btnConfig: Btns,
  emit: (name: string, ...data: any[]) => void,
  type = 'default',
  size = 'medium',
  ...data: any[]
) {
  const btnType = logicType.includes(btnConfig.type ?? '') ? type : btnConfig.type ?? type;
  if (btnConfig.type === 'refresh') {
    return (
      <el-button
        class="el-button--refresh"
        type="default"
        icon="el-icon-refresh-right"
        size="mini"
        onClick={() => {
          emit('$refresh');
        }}
      />
    );
  } else if (logicType.includes(btnConfig.type ?? '')) {
    return (
      <el-button
        type={type !== 'default' ? type : 'primary'}
        size={size}
        onClick={() => {
          if (typeof emit === 'function') {
            emit(btnConfig.type as string, ...data, btnConfig);
          }
        }}
      >
        {btnConfig.label ? btnConfig.label : null}
      </el-button>
    );
  }
  return (
    <el-button
      type={btnType}
      size={size}
      onClick={() => {
        if (btnConfig.emit && typeof emit === 'function') {
          emit(btnConfig.emit, ...data, btnConfig);
        }
      }}
    >
      {btnConfig.label ? btnConfig.label : null}
    </el-button>
  );
}

/*
 * 按钮长度大于n的时候,需要切换成下拉菜单;
 * */
export function buildDropdown(
  lists: Array<{ btnConfig: Btns; emit: (name: string, ...data: any[]) => void; data: any } | null>
) {
  return (
    <el-dropdown
      v-slots={{
        dropdown: () => {
          return (
            <el-dropdown-menu>
              {lists.map((item) => {
                {
                  return item ? (
                    <el-dropdown-item
                      onClick={() => {
                        if (logicType.includes(item.btnConfig.type ?? '')) {
                          item.emit(item.btnConfig.type as string, item.data, item.btnConfig);
                          return;
                        }
                        if (item.btnConfig.emit && typeof item.emit === 'function') {
                          item.emit(item.btnConfig.emit, item.data, item.btnConfig);
                        }
                      }}
                    >
                      {item?.btnConfig?.label || ''}
                    </el-dropdown-item>
                  ) : (
                    ''
                  );
                }
              })}
            </el-dropdown-menu>
          );
        },
        default: () => {
          return (
            <span class="el-dropdown-link" style={{ lineHeight: '36px' }}>
              操作<i class="el-icon-arrow-down el-icon--right"></i>
            </span>
          );
        }
      }}
    />
  );
}

export function renderUnclickable(btnConfig: Btns) {
  return (
    <el-tooltip class="item" effect="dark" content={btnConfig.params?.tip} placement="top-start">
      <el-button type="text" style={{ color: '#999' }}>
        {btnConfig.label}
        <i class="el-icon-question el-icon--right"></i>
      </el-button>
    </el-tooltip>
  );
}
