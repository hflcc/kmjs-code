import { defineComponent, PropType, onMounted, ref } from 'vue';
import { BuildCellEvent } from '@/components/table/kmjsTableType';
import { checkPermission } from '@/utils/permission';
import './index.less';
import { formatterPrice } from '@/utils';
import { GoodsSkus } from '@/pages/shopManage/api';

const loadImg = () => {
  return (
    <svg
      class="icon"
      style="width: 30px;height: 30px;vertical-align: middle;fill: currentColor;overflow: hidden;"
      viewBox="0 0 1024 1024"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
      p-id="3228"
    >
      <path
        d="M512 768H128V576l192-192 192 192 128-128c68.288 48.448 110.912 69.76 128 64 46.656 0 90.368 12.48 128 34.24V192H64v640h448v-64z m448-169.344A256 256 0 1 1 546.24 896H0V128h960v470.656zM768 384a64 64 0 1 1 0-128 64 64 0 0 1 0 128z m0 576a192 192 0 1 0 0-384 192 192 0 0 0 0 384z m-32-288a32 32 0 1 1 64 0V768a32 32 0 1 1-64 0v-96zM768 896a32 32 0 1 1 0-64 32 32 0 0 1 0 64z"
        p-id="3229"
      ></path>
    </svg>
  );
};

const operactions = [
  // { name: '编辑', event: 'skuEdit' },
  // { name: '调价', event: 'skuAdjust' },
  { name: '移除', event: 'skuDelete' }
];

export default defineComponent({
  name: 'table-expand-goodsSku',
  props: {
    row: {
      type: Object as PropType<Record<string, string | any>>,
      required: true
    },
    column: {
      type: Object as PropType<Record<string, string>>,
      required: true
    },
    cellIndex: {
      type: Number as PropType<number>,
      required: true
    },
    event: {
      type: Object as PropType<BuildCellEvent>,
      required: true
    },
    localEmitFun: {
      type: Function as PropType<(name: string, ...args: any[]) => void>,
      required: true
    },
    permission: {
      type: Object as PropType<Record<string, string>>,
      required: true
    }
  },
  setup(props) {
    const skuList = ref<GoodsSkus[]>(props.row.skus || []);

    // if (skuList.value.length) {
    //   skuList.value.forEach((item) => {
    //     if (item.icon.includes('http')) {
    //       item.imageUrl = item.icon;
    //     } else {
    //       store.dispatch('source/getOssUrl', [item.icon]).then((res) => {
    //         if (res) {
    //           item.imageUrl = res[item.icon].url;
    //           item.checked = false;
    //         }
    //       });
    //     }
    //   });
    // }

    // 操作按钮
    function renderOperaction(index: number) {
      return operactions.map((item) => {
        // return checkPermission(item.event, props.permission) ? (
        return (
          <el-button
            type="text"
            size="medium"
            onClick={() =>
              props.localEmitFun(item.event, {
                sku: props.row.skus[index],
                shopGoodsState: props.row.shopGoodsState,
                shopName: props.row.shopName,
                index
              })
            }
          >
            {item.name}
          </el-button>
        );
        // ) : null;
      });
    }

    onMounted(() => {
      console.log('props', props.row);
    });

    return () => (
      <div class="goodsSku-container">
        {skuList.value.map((item, index: number) => {
          return (
            <div class="goodsSku__wrapper">
              <div class="goodsSku__item">
                <div class="goodsSku__item--name">{item.name}</div>
                <div class="goodsSku__item--block">型号：{item.model}</div>
                <div class="goodsSku__item--block">重量(kg)：{item.weight}</div>
                <div class="goodsSku__item--block">体积(cm)：{item.volume}</div>
                <div class="goodsSku__item--image">
                  {item.image ? <img class="img" src={item.image} /> : loadImg()}
                </div>
                <div class="goodsSku__item--block">库存：{item.stockCount}</div>
                <div class="goodsSku__item--price">
                  建议零售价(元)：{formatterPrice(item.retailPrice)}
                </div>
                <div class="goodsSku__item--price">零售价(元)：{formatterPrice(item.price)}</div>
                <div class="goodsSku__item--stepPrices">
                  <div class="label">阶梯价(元)：</div>
                  <div class="values">
                    {item.stepPrices
                      ? item.stepPrices.map((item) => {
                          return (
                            <>
                              <div class="step">
                                {item.min}-{item.max}{' '}
                                <span class="price">{formatterPrice(item.price)}</span>
                              </div>
                            </>
                          );
                        })
                      : null}
                  </div>
                </div>
                <div class="goodsSku__item--operation">{renderOperaction(index)}</div>
              </div>
            </div>
          );
        })}

        <div v-show={!skuList.value.length} class="goodsSku__empty">
          暂无sku信息
        </div>
      </div>
    );
  }
});
