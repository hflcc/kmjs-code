<template>
  <div class="kmjs-title-wrap">
    <!-- 返回区域  -->
    <div class="back">
      <div style="font-size: 16px; cursor: pointer" @click="back">
        <i class="el-icon-arrow-left"></i> {{ config.title }}
      </div>
      <div class="right">
        <slot name="actions"></slot>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { useRouter } from 'vue-router';

  interface PropsConfig {
    title: string;
    ctl: () => void;
  }

  export default defineComponent({
    name: 'kmjs-title',
    props: {
      config: Object as PropType<PropsConfig>,
      title: {
        type: String as PropType<string>,
        default: '返回'
      },
      backFun: {
        type: Function as PropType<() => void>
      }
    },
    setup(props) {
      const router = useRouter();
      const back = () => {
        if (typeof props.backFun === 'function') {
          props.backFun();
        } else {
          router.back();
        }
      };
      return {
        back
      };
    }
  });
</script>
<style lang="less">
  .kmjs-title-wrap {
    .back {
      display: flex;
      background: #fff;
      padding-top: 10px;
      padding-bottom: 10px;

      .right {
        margin-left: auto;
      }
    }
  }
</style>
