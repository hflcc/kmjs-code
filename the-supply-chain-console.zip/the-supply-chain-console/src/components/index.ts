/**
 * 以下的组件作为全局组件
 * */
import kmjsWrap from '@/components/wrap/index.vue';
import kmjsForm from '@/components/form/index.tsx';
import kmjsTable from '@/components/table/index.tsx';
import kmjsCard from '@/components/card/index.tsx';
import kmjsFormModule from '@/formModule';
import kmjsPreviewFile from '@/components/previewFile';
import { App } from '@vue/runtime-core';
import installFormModuleComponents from '@/formModule/businessFormDialog/index';
import installFormItemComponents from '@/formModule/formItems/index';
import installFormCustomItem from '@/formModule/customItem/index';
import createBpmBefore from '@/components/createBpmBefore';
import installTableCellItem from '@/components/tableCellItems';
import installTableExpandItem from '@/components/tableExpandItems';

const installComponents = (app: App): void => {
  app.component('kmjs-wrap', kmjsWrap);
  app.component('kmjs-form', kmjsForm);
  app.component('kmjs-table', kmjsTable);
  app.component('kmjs-card', kmjsCard);
  app.component('kmjs-create-bpm-before', createBpmBefore);
  app.component(kmjsFormModule.name, kmjsFormModule);
  app.component(kmjsPreviewFile.name, kmjsPreviewFile);
  installFormCustomItem(app);
  installFormModuleComponents(app);
  installFormItemComponents(app);
  installTableCellItem(app);
  installTableExpandItem(app);
};
export default installComponents;
