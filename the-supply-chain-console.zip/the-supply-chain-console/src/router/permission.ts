import router from '@/router/index';
import store from '@/store/index';
import type { LocationQueryValue, RouteRecordRaw } from 'vue-router';
import { postMenuHistory } from '@/utils/commApi';
import { formRouterBuild } from '@/pages/commonPage';
import { ElMessageBox } from 'element-plus';
import { openNewTap } from '@/utils';

/**
 * 解决动态加入路由时，刷新进入404的问题
 * */
const replace = {
  path: '',
  query: {},
  params: {},
  isComputed: false,
  add(
    path: string,
    query: Record<string, string | LocationQueryValue[] | null>,
    params: Record<string, string | string[]>
  ) {
    this.path = path;
    this.query = query;
    this.params = params;
  },
  replace() {
    router.replace({ path: this.path, query: this.query });
  }
};

router.beforeEach((to, form, next) => {
  if (store.getters['menu/tabMenus'].length >= 50) {
    next(false);
    ElMessageBox.alert('已达到最大可打开的页面，请关闭一个页面后重试');
    return;
  }
  if (to.name === '404') {
    const user = store.getters['user/userMsg'];
    if (Object.keys(user).length === 0) {
      return next({
        name: 'login',
        query: {
          r: to.fullPath
        }
      });
    }
    if (!replace.path && !replace.isComputed) {
      replace.add(to.path, to.query, to.params);
      return next();
    }
    // 动态表单模块。需要动态路由加入后进入
    if (to.path.substr(0, 3) === '/FM') {
      formRouterBuild(to, next);
      return next(false);
    }
    openNewTap(to);
    return next(false);
  }
  if (!to.path.includes('_') && to.meta.newTap && to.meta.once) {
    openNewTap(to);
    return next(false);
  }
  // 机构信息
  const organization = store.getters['organization/getActiveOrganSn'];
  store.commit('organization/UPDATE_MENUACTIVESN', [
    form.name,
    store.state.organization.activeChannelSn,
    store.state.organization.activeOrganization
  ]);
  const channelType =
    (to.meta as Record<string, Record<string, string>>).propertyList?.channel_type?.split(',') ??
    [];
  store.dispatch('organization/filterChannel', [to.name, channelType]);

  const { name, meta } = to;
  // 没登录,或没有机构不在白名单;
  if (!organization && name !== 'setOrganization' && name !== 'login') {
    store.commit('user/LOGOUT');
    return next({
      name: 'login',
      query: {
        r: to.fullPath
      }
    });
  }
  if ((meta.propertyList as { menu_record?: boolean })?.menu_record) {
    postMenuHistory(meta.sn as string).then();
  }
  next();
});
/**
 * ======================== 动态计算路由 =======================
 * 先获取routet/modules下的所有文件
 * 进行比对后，route.addRoute 加入已实例后的全局路由中
 */
const localRoute: RouteRecordRaw[] = [];
const req = require.context('@/router/modules', false, /\.ts$/);
req.keys().forEach((item) => {
  return localRoute.push(...req(item).default);
});

/**
 * 根据路由name对总体的路由进行合并比较
 * @param serverRouterData 服务器的路由数据
 * @param localRoute 当前本地已经配置好的路由
 * @return 本层次对比后的结果
 * */
const marge = (
  serverRouterData: ServerRouterData[],
  localRoute: RouteRecordRaw[]
): { route: RouteRecordRaw[]; menu: RouteRecordRaw[] } => {
  const route: RouteRecordRaw[] = [];
  const menu: RouteRecordRaw[] = [];
  const Slength = serverRouterData.length;
  for (let i = 0; i < Slength; i++) {
    const item = serverRouterData[i];
    let localData:
      | RouteRecordRaw
      | undefined
      | {
          path: string;
          name: string;
          meta: Record<string, any>;
          children: RouteRecordRaw[];
        };
    // 业务逻辑路由（即只是一个空层，主要是下面的子路由）
    if (item.value === '*') {
      localData = {
        path: '*' + item.sn,
        meta: {},
        name: item.sn,
        children: localRoute
      };
    } else {
      // 真实存在的路由
      localData = localRoute.find((s) => s.name === item.value) || undefined;
    }

    if (localData) {
      let margeChild: { route: RouteRecordRaw[]; menu: RouteRecordRaw[] } = { route: [], menu: [] };
      if (!localData.meta) {
        localData.meta = {};
      }
      localData.meta.title = item.title;
      localData.meta.sn = item.sn;
      localData.meta.propertyList = item.propertyList;
      localData.meta.childrenList = item.childrenList;
      localData.meta.icon = item.ico;
      // 先排除children，如果有必要对比children在对比加入
      const children = localData.children;
      Reflect.deleteProperty(localData, 'children');
      const menuCopy = { ...localData };
      if (children?.length && item.childrenList?.length) {
        margeChild = marge(item.childrenList, children);
      }
      if (margeChild?.route.length) {
        localData.children = margeChild.route;
      }
      if (margeChild?.menu.length) {
        menuCopy.children = margeChild.menu;
      }
      if (menuCopy.meta && !menuCopy.meta.hide) {
        Reflect.deleteProperty(menuCopy, 'component');
        menu.push(menuCopy as RouteRecordRaw);
      }
      // 这里排除不再路由系统中存在的业务逻辑路由（即只是一个空层，主要是下面的子路由）
      if (localData.path.charAt(0) === '*') {
        // 子路由中真实的路由加入
        if (Array.isArray(localData.children)) {
          localData.children.forEach((s) => {
            route.push(s as RouteRecordRaw);
          });
        }
      } else {
        route.push(localData as RouteRecordRaw);
      }
    }
  }
  return {
    route,
    menu
  };
};
/**
 * 根据后台返回的路由name对总体的路由进行合并比较
 * @param serverRouterData 当前路由名称的name
 * @return 对比后的所有结果
 * */
export const computed = (serverRouterData: ServerRouterData[]): RouteRecordRaw[] => {
  const data = marge(serverRouterData, localRoute);
  data.route.forEach((v) => router.addRoute('rootRoute', v));
  if (replace.path) replace.replace();
  replace.isComputed = true;
  // 本地开发时可以运行这个，所有页面都有权限
  if (process.env.VUE_APP_ENV === 'development') {
    localRoute.forEach((v) => router.addRoute('rootRoute', v));
  }
  return data.menu;
};
