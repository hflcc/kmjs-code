export default [
  {
    path: 'libraryOfGoodsIndex', // 注意不要加 /
    name: 'libraryOfGoodsIndex',
    component: () =>
      import(/* webpackChunkName: "orderManageIndex" */ '@/pages/libraryOfGoods/index.vue'),
    meta: {
      title: '商品库',
      keepName: 'libraryOfGoodsIndex',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  },
  {
    path: 'specSellingPrice', // 注意不要加 /
    name: 'specSellingPrice',
    component: () =>
      import(
        /* webpackChunkName: "orderManageDetail" */ '@/pages/libraryOfGoods/pages/specSellingPrice.vue'
      ),
    meta: {
      title: '规格及售价',
      keepName: '',
      icon: '',
      breadcrumb: false,
      hide: true
    }
  },
  {
    path: 'commodityEntryForm', // 注意不要加 /
    name: 'commodityEntryForm',
    component: () =>
      import(/* webpackChunkName: "commodityEntryForm" */ '@/pages/commodityEntryForm/index.vue'),
    meta: {
      keepName: 'commodityEntryForm', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
      title: '商品入驻单',
      breadcrumb: true,
      hide: false // 是否在菜单中不显示
    }
  },
  {
    path: 'commodityEntryPortal', // 注意不要加 /
    name: 'commodityEntryPortal',
    component: () =>
      import(/* webpackChunkName: "commodityEntryForm" */ '@/pages/commodityEntryForm/portal.vue'),
    meta: {
      keepName: 'commodityEntryPortal', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
      title: '商品入驻单',
      breadcrumb: true,
      hide: false // 是否在菜单中不显示
    }
  }
];
