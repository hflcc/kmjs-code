export default [
  {
    path: 'bankAccountManage',
    name: 'bankAccountManage',
    component: () =>
      import(/* webpackChunkName: "newGood" */ '@/pages/bankAccountManage/index.vue'),
    meta: {
      title: '银行账号管理',
      keepName: 'bankAccountManage',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  }
];
