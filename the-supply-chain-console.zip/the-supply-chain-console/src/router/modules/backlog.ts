export default [
  {
    path: 'backlog', // 注意不要加 /
    name: 'backlog',
    component: () => import(/* webpackChunkName: "backlogList" */ '@/pages/backlog/index.vue'),
    meta: {
      title: '待办',
      keepName: 'backlog-list',
      icon: 'circle-plus-outline'
    }
  },
  {
    path: 'todo', // 注意不要加 /
    name: 'backlog_detail',
    component: () => import(/* webpackChunkName: "backlogDetail" */ '@/pages/backlog/detail.vue'),
    meta: {
      title: '审核',
      keepName: 'backlog-detail',
      hide: true
    }
  },
  {
    path: 'subHistoryDetail', // 注意不要加 /
    name: 'subHistoryDetail',
    component: () =>
      import(
        /* webpackChunkName: "subHistoryDetail" */ '@/pages/backlog/subHistory/subHistoryDetail.vue'
      ),
    meta: {
      title: '提交历史详情',
      keepName: 'subHistoryDetail',
      hide: true
    }
  }
];
