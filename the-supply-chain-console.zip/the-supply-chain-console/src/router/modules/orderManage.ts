export default [
  {
    path: 'orderManageIndex', // 注意不要加 /
    name: 'orderManageIndex',
    component: () =>
      import(/* webpackChunkName: "orderManageIndex" */ '@/pages/orderManage/index.vue'),
    meta: {
      title: '订单管理',
      keepName: 'orderManageIndex',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  },
  {
    path: 'orderManageDetail', // 注意不要加 /
    name: 'orderManageDetail',
    component: () =>
      import(/* webpackChunkName: "orderManageDetail" */ '@/pages/orderManage/pages/detail.vue'),
    meta: {
      title: '订单详情',
      keepName: '',
      icon: '',
      breadcrumb: false,
      hide: true
    }
  },
  {
    path: 'orderManageDelivery', // 注意不要加 /
    name: 'orderManageDelivery',
    component: () =>
      import(
        /* webpackChunkName: "orderManageDelivery" */ '@/pages/orderManage/pages/delivery.vue'
      ),
    meta: {
      title: '订单发货',
      keepName: '',
      icon: '',
      breadcrumb: false,
      hide: true
    }
  }
];
