export default [
  {
    path: 'ditchGoodsIndex', // 注意不要加 /
    name: 'ditchGoodsIndex',
    component: () =>
      import(/* webpackChunkName: "orderManageIndex" */ '@/pages/ditchGoods/index.vue'),
    meta: {
      title: '渠道商品',
      keepName: 'ditchGoodsIndex',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  }
];
