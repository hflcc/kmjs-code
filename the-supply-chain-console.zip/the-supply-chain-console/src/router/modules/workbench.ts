export default [
  {
    path: 'workbench', // 注意不要加 /
    name: 'workbench',
    component: () => import(/* webpackChunkName: "workbench" */ '@/pages/workbench/index.vue'),
    meta: {
      title: '工作台',
      keepName: 'workbenchPage',
      icon: 'camera',
      breadcrumb: true,
      hide: false
    }
  }
];
