export default [
  {
    path: 'certificationOfSingle',
    name: 'certificationOfSingle',
    component: () =>
      import(/* webpackChunkName: "newGood" */ '@/pages/certificationOfSingle/index.vue'),
    meta: {
      title: '证件认证单',
      keepName: 'certificationOfSingle',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  }
];
