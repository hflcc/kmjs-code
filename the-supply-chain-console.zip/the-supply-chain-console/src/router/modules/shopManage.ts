export default [
  {
    path: 'shopManageIndex', // 注意不要加 /
    name: 'shopManageIndex',
    component: () =>
      import(/* webpackChunkName: "shopManageIndex" */ '@/pages/shopManage/index.vue'),
    meta: {
      title: '店铺管理',
      keepName: 'shopManageIndex',
      icon: '',
      hide: false
    }
  },
  {
    path: 'shopCommodity', // 注意不要加 /
    name: 'shopCommodity',
    component: () =>
      import(/* webpackChunkName: "shopCommodity" */ '@/pages/shopManage/pages/commodity.vue'),
    meta: {
      title: '商品管理',
      keepName: 'shopCommodity',
      icon: '',
      hide: true,
      newTap: true,
      once: 'shopSn'
    }
  },
  {
    path: 'shopPageSelection', // 注意不要加 /
    name: 'shopPageSelection',
    component: () =>
      import(
        /* webpackChunkName: "shopPageSelection" */ '@/pages/shopManage/pages/shopPageSelection.vue'
      ),
    meta: {
      title: '店铺装修-页面选择',
      keepName: 'shopPageSelection',
      icon: '',
      hide: true,
      newTap: true,
      once: 'shopSn'
    }
  },
  {
    path: 'commodityClassify', // 注意不要加 /
    name: 'commodityClassify',
    component: () =>
      import(
        /* webpackChunkName: "commodityClassify" */ '@/pages/shopManage/pages/commodityClassify.vue'
      ),
    meta: {
      title: '店铺装修-商品分类',
      keepName: 'commodityClassify',
      icon: '',
      hide: true
    }
  }
];
