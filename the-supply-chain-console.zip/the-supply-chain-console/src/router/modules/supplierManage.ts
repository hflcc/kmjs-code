export default [
  {
    path: 'supplierManageIndex', // 注意不要加 /
    name: 'supplierManageIndex',
    component: () =>
      import(/* webpackChunkName: "supplierManageIndex" */ '@/pages/supplierManage/index.vue'),
    meta: {
      title: '供应商管理',
      keepName: 'supplierManageIndex',
      icon: '',
      hide: false
    }
  }
];
