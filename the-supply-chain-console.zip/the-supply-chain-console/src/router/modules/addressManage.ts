export default [
  {
    path: 'addressManageIndex', // 注意不要加 /
    name: 'addressManageIndex',
    component: () =>
      import(/* webpackChunkName: "addressManageIndex" */ '@/pages/addressManage/index.vue'),
    meta: {
      title: '地址管理',
      keepName: 'addressManageIndex',
      icon: 'circle-plus-outline'
    }
  }
];
