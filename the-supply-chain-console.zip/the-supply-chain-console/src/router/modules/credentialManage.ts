export default [
  {
    path: 'credentialManage', // 注意不要加 /
    name: 'credentialManage',
    component: () =>
      import(/* webpackChunkName: "credentialManage" */ '@/pages/credentialManage/index.vue'),
    meta: {
      title: '证件管理',
      keepName: 'credentialManage',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  }
];
