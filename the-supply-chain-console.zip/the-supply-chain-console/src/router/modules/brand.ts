export default [
  {
    path: 'brandWarehouse', // 注意不要加 /
    name: 'brandWarehouse',
    component: () =>
      import(/* webpackChunkName: "brandWarehouse" */ '@/pages/brandWarehouse/index.vue'),
    meta: {
      title: '品牌库',
      keepName: 'brandWarehouse',
      icon: '',
      hide: false
    }
  },
  {
    path: 'brandEntryCentralize', // 注意不要加 /
    name: 'brandEntryCentralize',
    component: () =>
      import(
        /* webpackChunkName: "brandEntry-centralize" */ '@/pages/brandEntry-centralize/index.vue'
      ),
    meta: {
      title: '品牌入驻-集供',
      keepName: 'brandEntryCentralize',
      icon: '',
      hide: false
    }
  },
  {
    path: 'brandEntryPortal', // 注意不要加 /
    name: 'brandEntryPortal',
    component: () =>
      import(/* webpackChunkName: "brandEntry-portal" */ '@/pages/brandEntry-portal/index.vue'),
    meta: {
      title: '品牌入驻-门户',
      keepName: 'brandEntryPortal',
      icon: '',
      hide: false
    }
  },
  {
    path: 'channelBrand', // 注意不要加 /
    name: 'channelBrand',
    component: () =>
      import(/* webpackChunkName: "channelBrand" */ '@/pages/channelBrand/index.vue'),
    meta: {
      title: '渠道品牌',
      keepName: 'channelBrand',
      icon: '',
      hide: false
    }
  }
];
