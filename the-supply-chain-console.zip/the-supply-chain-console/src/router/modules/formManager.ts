import { RouteRecordRaw } from 'vue-router';

const formManager: RouteRecordRaw[] = [
  {
    path: 'form-manager', // 注意不要加 /
    name: 'formManager',
    component: () => import(/* webpackChunkName: "formManager" */ '@/pages/formManager/index.tsx'),
    meta: {
      keepName: 'form-manager-page', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
      title: '表单管理'
    }
  }
];

export default formManager;
