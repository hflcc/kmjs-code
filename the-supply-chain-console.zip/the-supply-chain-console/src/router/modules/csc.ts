import { RouteRecordRaw } from 'vue-router';
import layout from '@/layout/layout.vue';

const customerRoute: RouteRecordRaw[] = [
  {
    path: 'csc', // 二级路由的地址 注意不要加 /
    name: 'csc', // 路由名称，与后台对比使用这个字段
    component: layout, // 空路由页面
    meta: {
      title: '客服中心', // 面包屑展示和菜单栏展示的文字
      breadcrumb: true, // 是否在面包屑中展示这个
      hide: false // 是否在菜单中不显示
    },
    redirect: '/csc/index', // 空路由时默认进入的页面，需要全路径
    children: [
      {
        path: 'index', // 注意不要加 /
        name: 'cscIndex',
        component: () => import(/* webpackChunkName: "cscIndex" */ '@/pages/im/index.vue'),
        meta: {
          keepName: 'cscIndex', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
          title: '对话',
          breadcrumb: true,
          hide: false // 是否在菜单中不显示
        }
      },
      {
        path: 'service/manager', // 注意不要加 /
        name: 'cscServiceManager',
        component: () =>
          import(/* webpackChunkName: "cscServiceManager" */ '@/pages/csc/serviceManager.vue'),
        meta: {
          keepName: 'cscServiceManager', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
          title: '客服管理',
          breadcrumb: true,
          hide: false // 是否在菜单中不显示
        }
      },
      {
        path: 'service/center', // 注意不要加 /
        name: 'cscServiceCenter',
        component: () =>
          import(/* webpackChunkName: "cscServiceCenter" */ '@/pages/csc/serviceCenter.vue'),
        meta: {
          keepName: 'cscServiceCenter', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
          title: '客服中心',
          breadcrumb: true,
          hide: false // 是否在菜单中不显示
        }
      },
      {
        path: 'service/center/manage', // 注意不要加 /
        name: 'cscServiceCenterManage',
        component: () =>
          import(/* webpackChunkName: "newService" */ '@/pages/csc/pages/manageService.vue'),
        meta: {
          title: '客服管理',
          keepName: '',
          icon: '',
          hide: true,
          newTap: true,
          once: 'sn'
        }
      }
    ]
  }
];

export default customerRoute;
