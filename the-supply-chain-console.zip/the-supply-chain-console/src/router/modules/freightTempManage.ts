export default [
  {
    path: 'freightTempManage', // 注意不要加 /
    name: 'freightTempManage',
    component: () =>
      import(/* webpackChunkName: "freightTempManage" */ '@/pages/freightTempManage/index.vue'),
    meta: {
      title: '运费模板管理',
      keepName: 'freightTempManage',
      icon: 'circle-plus-outline'
    }
  }
];
