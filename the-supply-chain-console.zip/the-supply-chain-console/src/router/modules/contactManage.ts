export default [
  {
    path: 'contactManage',
    name: 'contactManage',
    component: () => import(/* webpackChunkName: "newGood" */ '@/pages/contactManage/index.vue'),
    meta: {
      title: '联系人管理',
      keepName: 'contactManage',
      icon: '',
      breadcrumb: true,
      hide: false
    }
  }
];
