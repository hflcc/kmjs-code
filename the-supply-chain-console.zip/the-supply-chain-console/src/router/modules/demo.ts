export default [
  {
    path: 'demo-module-code', // 注意不要加 /
    name: 'table',
    component: () => import(/* webpackChunkName: "moduleCode" */ '@/pages/demo/moduleCode.vue'),
    meta: {
      title: '表格测试',
      keepName: 'demo-module-code',
      propertyList: {
        channel_type:
          'hr,manager,channel,bpm,live,course,goods,supplier,goods_category,inst_goods_category,agent,agent_main'
      },
      icon: 'circle-plus-outline'
    }
  },
  {
    path: 'demo-module', // 注意不要加 /
    name: 'form',
    component: () => import(/* webpackChunkName: "module" */ '@/pages/demo/module.vue'),
    meta: {
      title: '模块测试',
      keepName: 'demo-module',
      icon: 'circle-plus-outline'
    }
  },
  {
    path: 'demo-form', // 注意不要加 /
    name: 'form',
    component: () => import(/* webpackChunkName: "moduleCode" */ '@/pages/demo/formModule.vue'),
    meta: {
      title: '表单测试',
      keepName: 'from-module-demo',
      icon: 'circle-plus-outline'
    }
  }
];
