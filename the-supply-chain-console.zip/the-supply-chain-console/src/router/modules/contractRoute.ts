import { RouteRecordRaw } from 'vue-router';

const contractRoute: RouteRecordRaw[] = [
  {
    path: 'contract', // 注意不要加 /
    name: 'contract',
    component: () =>
      import(/* webpackChunkName: "contract" */ '@/pages/businessManagement/contract/contract.vue'),
    meta: {
      keepName: 'contract', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
      title: '合同管理',
      breadcrumb: true,
      hide: false // 是否在菜单中不显示
    }
  },
  {
    path: 'location',
    name: 'location',
    component: () =>
      import(/* webpackChunkName: "location" */ '@/pages/businessManagement/location/location.vue'),
    meta: {
      keepName: 'locationIndex', // 控制是否显示在TAB菜单上， 同时页面被缓存，需要的请在将字段的值写为组件的name字段（defineComponent中的name字段）
      title: '定位',
      breadcrumb: true,
      hide: true // 是否在菜单中不显示
    }
  }
];

export default contractRoute;
