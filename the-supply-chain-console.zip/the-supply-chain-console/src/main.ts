import { createApp } from 'vue';
import 'core-js/stable';
// store
import store from './store';
// router
import router from './router';
// 初始化实例
import App from './App.vue';
// 初始化样式
import 'normalize.css';
// element-ui-plus
import 'element-plus/lib/theme-chalk/index.css';
import '@/style/elementTheme/index.css';
import ElementPlus from 'element-plus';
// 全局样式
import '@/style/init.less';
import '@/style/global.less';
import '@/style/element.less';
// 项目初始化
import directives from '@/directives';
import '@/router/permission';
import 'dayjs/locale/zh-cn';
import locale from 'element-plus/lib/locale/lang/zh-cn';
import installComponents from '@/components';
// 事件处理
import 'default-passive-events';

const init = async () => {
  // 获取系统信息
  await store.dispatch('systemInfo/getSystemData');
  // 获取用户信息
  await store.dispatch('user/getUserMessage');
  // 每次刷新时获取机构信息
  await store.dispatch('organization/getIns');
  // 菜单载入完后在进行渲染，防止出现404页面
  const app = createApp(App);
  directives(app);
  app.use(ElementPlus, { locale });
  installComponents(app);
  app.use(store);
  app.use(router);
  app.mount('#app');
};
init();
