import { getChainData } from '@/utils';
import { FormItem } from '@/components/form/type';
import { ElNotification } from 'element-plus';

/**
 * 将数据格式处理为渲染可用的数据
 * */
export const dataTransform = () => {
  // todo
};

/*
 * 检查依赖的key-value是否有值
 * */
export const checkRelyOnHasValue = (config: FormItem, formModuleEvents: FormModuleEvents) => {
  if (config.renderConfig?.params?.requestParams) {
    const obj = config.renderConfig.params.requestParams;
    const arr = Object.keys(obj);
    for (const s of arr) {
      const item = obj[s];
      if (item.type === 'mapping') {
        const [tag, key, ...other] = item.value.split('.');
        let value = formModuleEvents.getData(tag, key);
        value = getChainData(value, other.join('.'));
        if (!value && value !== 0) {
          ElNotification({
            type: 'error',
            title: '出错了',
            message: `请先选择 [${item.label}]`,
            duration: 4000
          });
          return false;
        }
      }
    }
  }
  return true;
};
