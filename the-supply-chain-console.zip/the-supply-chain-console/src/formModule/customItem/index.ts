import { App } from 'vue';

const installFormCustomItem = (app: App): void => {
  const req = require.context('@/formModule/customItem', true, /index.vue|index.tsx$/);
  req.keys().forEach((item) => {
    const com = req(item).default;
    app.component(com.name, com);
  });
};
export default installFormCustomItem;
