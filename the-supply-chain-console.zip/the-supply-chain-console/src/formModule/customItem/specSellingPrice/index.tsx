import { defineComponent, nextTick, PropType, ref, computed } from 'vue';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import kmjsTable, { useTable } from '@/components/table/code';
import newSpecification from '@/pages/libraryOfGoods/components/newSpecification.vue';
import compile from '@/pages/libraryOfGoods/components/compile.vue';
import tieredPricing from '@/pages/libraryOfGoods/components/tieredPricing.vue';
import { SpecsStore, StepPricesList, StepPricesStore } from '@/pages/libraryOfGoods/api';
import { useStore } from 'vuex';
import { ElMessage, ElMessageBox } from 'element-plus';
import './style.less';

export default defineComponent({
  name: 'form-module-item-spec_price',
  components: {
    kmjsTable,
    newSpecification,
    compile,
    tieredPricing
  },
  props: {
    config: {
      type: Object as PropType<ResSte>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      required: true
    }
  },
  emits: ['getCompile', 'getSpecification', 'getSubmitTiered'],
  setup(props) {
    const showNewProperty = ref(false);
    const showNewSpecification = ref(false);
    const showTieredPricing = ref(false);
    const store = useStore<RootState>();
    // 规格设置
    const specs = ref<SpecsStore[]>([]);
    // 规格选择当前数据
    const specificationData: any = ref({});
    // 是否子级新增和编辑 false:不是子级, true:是子级
    const superior = ref(false);
    // 是否是子级的编辑
    const superiorCompile = ref(false);
    // 当前规格的最上级
    const superiorData = ref<any>({});
    const clapList = ref<SpecsChilden[]>([]);
    // 阶梯价设置
    const ladder = ref<StepPricesList[]>([]);
    // 删除的阶梯价数据
    const lineisDelete = ref<StepPricesStore[]>([]);
    // 规格折叠展开
    const expand = ref(true);
    const refreshTable = ref(true);
    const titleResult = [];
    // sku数据回显
    const compileData = ref<StepList>({
      name: '',
      model: '',
      retailPrice: '',
      price: '',
      weight: '',
      volume: '',
      icon: '',
      stepPrices: [],
      specIndexes: ''
    });
    // 列表数据
    const skus = ref<StepList[]>([]);
    // 删除的表单数据
    const skusDelete = ref<StepList[]>([]);
    // 编辑or新增 false:新增 true：编辑
    const operation = ref(false);
    // 将数据更新到表格
    const getCompile = (data: StepList) => {
      const index = skus.value.findIndex((s) => s === compileData.value);
      if (operation.value) {
        skus.value[index] = data;
        nextTick(() => {
          setTableData();
        });
      } else {
        skus.value.push(data);
        nextTick(() => {
          setTableData();
        });
      }
    };
    // 确认规格操作
    const getSpecification = (data: any) => {
      // 是否子级新增
      const newChild: any = data;
      console.log(newChild, 'newChild');

      if (superior.value && !superiorCompile.value && specificationData.value) {
        if (!specificationData.value.children) {
          specificationData.value.children = [];
        }
        specificationData.value.children.push(newChild[0]);
        specs.value = [...specs.value];
        // 编辑子级
      } else if (superiorCompile.value && specificationData.value) {
        console.log(newChild, 'newChildnewChild');

        specificationData.value.name = newChild.name;
        specificationData.value.mixName = newChild.name;

        specs.value = [...specs.value];
      } else {
        specs.value.push(data);
      }
      store.commit('goods/SET_SPECS', specs.value);
    };

    const tableJSON = {
      tableDataUrl: '',
      items: [
        {
          type: 'title',
          title: 'SKU管理',
          actions: [
            {
              label: '阶梯设置',
              emit: 'stairSet'
            },
            {
              label: '新增sku',
              emit: 'newCompile'
            }
          ]
        },
        {
          type: 'table',
          tableHead: [
            {
              type: 'slot',
              label: '规格',
              key: 'name'
            },
            {
              label: '型号',
              key: 'model'
            },
            {
              label: '预览图',
              key: 'icon',
              type: 'image',
              width: 80
            },
            {
              label: '建议零售价(元)',
              key: 'retailPrice'
            },
            {
              label: '零售价(元)',
              key: 'price'
            },
            {
              label: '重量(kg)',
              key: 'weight'
            },
            {
              label: '体积(cm³)',
              key: 'volume'
            },
            {
              type: 'skuStepPriceInfo',
              label: '阶梯售价',
              key: 'stepPrices',
              width: 150
            },
            {
              type: 'handle',
              label: '操作',
              actions: [
                {
                  label: '编辑',
                  emit: 'supplierEdit'
                },
                {
                  label: '删除',
                  emit: 'supplierDel'
                },
                {
                  label: '上移',
                  emit: 'moveUp'
                },
                {
                  label: '下移',
                  emit: 'moveDown'
                }
              ]
            }
          ],
          slotParam: [
            {
              name: 'name',
              slotName: 'name'
            }
          ]
        }
      ]
    };

    const [tableCtl, tableMethods] = useTable({
      tableHandler: (name, data) => {
        const tieredList = ref<StepPricesList[]>([]);
        // 是否有阶梯设置
        if (store.state.goods.tiered.length) {
          store.state.goods.tiered.map((val) => {
            tieredList.value.push({
              min: val.min,
              max: val.max,
              price: ''
            });
          });
        }
        console.log(name, 'name');
        const index = skus.value.findIndex((s) => s === data[0].row);
        switch (name) {
          // 新增sku
          case 'titleNewCompile':
            if (!store.state.goods.specs.length) {
              ElMessageBox.alert('请先设置规格');
              return;
            }
            if (tieredList.value) {
              ladder.value = tieredList.value;
            }
            operation.value = false;
            showNewProperty.value = true;
            clapList.value = sp.value;
            break;
          // 阶梯设置
          case 'titleStairSet':
            if (store.state.goods.tiered.length) {
              ElMessageBox.confirm('修改之后将影响全局的阶梯价，确认修改吗？')
                .then(async () => {
                  showTieredPricing.value = true;
                })
                .catch((err) => {
                  console.log(err);
                });
            } else {
              showTieredPricing.value = true;
            }
            break;
          // 编辑
          case 'tableSupplierEdit':
            console.log(data, 'data');
            console.log(tieredList.value, 'tieredList.value');
            operation.value = true;
            ladder.value = data[0].row.stepPrices;
            compileData.value = data[0].row;
            showNewProperty.value = true;
            clapList.value = sp.value;
            break;
          // 删除
          case 'tableSupplierDel':
            ElMessageBox.confirm('确认删除吗？')
              .then(async () => {
                // 编辑已有数据，把删除的数据单独拿出来，提交的时候再合并一起给后端
                if (data[0].row.sn) {
                  data[0].row.isDelete = true;
                  skusDelete.value.push(data[0].row);
                }
                skus.value.splice(index, 1);
                ElMessage.success('删除成功');
                setTableData();
              })
              .catch((err) => {
                console.log(err);
              });
            break;
          // 上移
          case 'tableMoveUp':
            moveUpOrDown(data[0].row, -1);
            break;
          // 下移
          case 'tableMoveDown':
            moveUpOrDown(data[0].row, 1);
            break;
        }
      }
    });
    /**
     * @info 数据上移下移逻辑
     * @param list 列表数据
     * @param specs 规格数据
     * */
    const ctlFuns = {
      // 提交
      getData() {
        console.log(2, skus.value);
        // 删除的表格数据放到整体里面提交给后台
        if (skusDelete.value.length) {
          skus.value = skus.value.concat(skusDelete.value);
        }
        // 删除的阶梯价数据放到整体里面提交给后台
        if (lineisDelete.value.length) {
          skus.value.map((res: any) => {
            if (res.stepPrices) {
              res.stepPrices.push(lineisDelete.value[0]);
            }
          });
        }
        return {
          skus: skus.value,
          specs: specs.value
        };
      },
      getNoVerifyData() {
        console.log(3, skus.value);
        return {
          skus: skus.value,
          specs: specs.value
        };
      },
      setData(data: { skus: StepList[]; specs: SpecsStore[] }) {
        // 列表的数据
        let arrData: any[];
        // 规格数据
        let specsData: any[];
        // 阶梯价的数据
        const pricesList = ref<StepPricesStore[]>([]);
        if (typeof data.skus === 'string' && typeof data.specs === 'string') {
          try {
            arrData = JSON.parse(data.skus);
            specsData = JSON.parse(data.specs);
          } catch (e) {
            arrData = [];
            specsData = [];
          }
        } else {
          arrData = data.skus;
          specsData = data.specs;
        }
        if (Array.isArray(arrData)) {
          skus.value = [...arrData];
          specs.value = [...specsData];
          skus.value[0].stepPrices.map((val: any) => {
            pricesList.value.push({
              min: val.min,
              max: val.max,
              sn: val.sn
            });
          });
          store.commit('goods/SET_TIERED', pricesList.value);
          store.commit('goods/SET_SPECS', specs.value);
        } else {
          skus.value = [];
          specs.value = [];
        }
        setTableData();
      }
    };
    // 过滤没有被删除标记的数据，用以显示
    const setTableData = () => {
      tableMethods.setTableData(skus.value);
    };
    /**
     * @info 数据上移下移逻辑
     * @param data 当前需要移动的数据
     * @param flag 需要移动的方向 正1负1
     * */
    const moveUpOrDown = (data: StepList, flag = 1) => {
      const index = skus.value.findIndex((s) => s === data);
      const newIndex: number = index + flag;
      if (!skus.value[newIndex]) return;
      skus.value[index] = skus.value[newIndex];
      skus.value[newIndex] = data;

      setTableData();
    };

    /**
     * @info 规格管理模块
     * */

    // 全部折叠
    const allFolding = () => {
      refreshTable.value = false;
      expand.value = !expand.value;
      nextTick(() => {
        refreshTable.value = true;
      });
    };
    // 新增规格
    const newSpecification = () => {
      console.log(sp.value);
      superior.value = false;
      superiorCompile.value = false;
      showNewSpecification.value = true;
    };
    // 新增规格子级
    const supplierNew = (node: any, data: SpecsChilden) => {
      console.log(sp.value);
      // 是否子级新增和编辑
      node.level ? (superior.value = true) : (superior.value = false);
      // 当前全部父级数据
      superiorData.value = node;
      // 当前数据
      specificationData.value = data;
      // 是否编辑子级
      superiorCompile.value = false;
      // 打开弹窗
      showNewSpecification.value = true;
    };
    // 编辑规格子级
    const supplierCompile = (node: any, data: SpecsChilden) => {
      console.log(sp.value);
      // 是否子级新增和编辑
      node.level ? (superior.value = true) : (superior.value = false);
      // 当前全部父级数据
      superiorData.value = node;
      // 当前数据
      specificationData.value = data;
      // 是否编辑子级
      superiorCompile.value = true;
      // 打开弹窗
      showNewSpecification.value = true;
    };
    // 删除规格子级
    const supplierDel = (node: any, data: any) => {
      ElMessageBox.confirm('确认删除当前规格吗？')
        .then(async () => {
          const parent = node.parent;
          const children: SpecsChilden[] = parent.data.children || parent.data;
          const index = children.findIndex((d: any) => d.index === data.index);
          console.log(children[index], 'indexindexindexindexindex');
          if (children[index]?.sn) {
            children[index].isDelete = true;
            const flatten = (node: SpecsChilden) => {
              const child = node.children;
              if (child != undefined && child.length > 0) {
                child.forEach((ele) => {
                  ele.isDelete = true;
                  if (ele.children?.length) {
                    flatten(ele);
                  }
                });
              }
            };
            flatten(children[index]);
          } else {
            children.splice(index, 1);
          }
          specs.value = [...specs.value];
          ElMessage.success('删除成功');
          store.commit('goods/SET_SPECS', specs.value);
        })
        .catch((err) => {
          console.log(err);
        });
    };
    // 拍平数组
    const getNode = (node: SpecsStore) => {
      const result: any = [];

      const tmp = JSON.parse(JSON.stringify(node));
      console.log(tmp, 'confirm, sonFromNew.value)');

      delete tmp.children; //移除拍平数组的子元素,只保留节点相干元素
      titleResult.push(tmp);
      const flatten = (node: SpecsChilden) => {
        const child = node.children;
        if (child != undefined && child.length > 0) {
          child.forEach((ele) => {
            result.push(ele as SpecsChilden);
            if (ele.children?.length) {
              flatten(ele);
            }
          });
        }
      };
      flatten(node);
      return result;
    };
    // 计算拍平后列表
    const sp = computed(() => {
      const list: SpecsStore[] = [];
      specs.value.forEach((item) => {
        list.push(...getNode(item));
        console.log(titleResult.length, 'titleResult.length');

        store.commit('goods/SET_ISSPECSINDEX', list.length + titleResult.length);
      });
      return list;
    });
    const treeProps = {
      label: 'name',
      children: 'children'
    };
    // 阶梯价
    const getSubmitTiered = (val: StepPricesStore[]) => {
      const compileList = ref<StepPricesList[]>([]);
      // 删除的阶梯价
      if (val.length) {
        lineisDelete.value.concat(val);
      }
      // 是否有阶梯设置
      if (store.state.goods.tiered.length) {
        store.state.goods.tiered.map((val) => {
          compileList.value.push({
            min: val.min,
            max: val.max,
            price: ''
          });
        });
      }
      // 更新阶梯数据
      skus.value.map((data) => {
        if (compileList.value.length) {
          if (compileList.value.length == data.stepPrices.length) {
            compileList.value.map((item, index) => {
              data.stepPrices.map((itemTow: StepPricesList, indexTow: number) => {
                if (index == indexTow) {
                  itemTow.min = item.min;
                  itemTow.max = item.max;
                  itemTow.price = itemTow.price ? itemTow.price : item.price;
                }
              });
            });
          } else {
            compileList.value.map((item, index) => {
              data.stepPrices.map((itemTow: StepPricesList, indexTow: number) => {
                if (index == indexTow) {
                  item.price = itemTow.price ? itemTow.price : item.price;
                }
                data.stepPrices = compileList.value;
              });
            });
          }
        }
      });
      setTableData();
    };
    // 注册成module支持的组件
    resisterModule(props.moduleName, ctlFuns);
    return () => {
      return (
        <div class="page" style="padding-top: 20px;display: flex;justify-content: space-between;">
          <div style="width: 35%">
            <div style="display: flex;justify-content: space-between;">
              <h1 style="font-size: 16px;color: #333;">规格管理</h1>
              <div>
                <el-button size="medium" onClick={() => allFolding()}>
                  {expand.value ? '全部折叠' : '全部展开'}
                </el-button>

                <el-button size="medium" onClick={() => newSpecification()}>
                  新增规格
                </el-button>
              </div>
            </div>
            <div class="line"></div>
            <div>
              <div class="custom-tree-node tree-node-title">
                <span class="specification-title">规格</span>
                <span class="operate">操作</span>
              </div>
              <div class="tree-content">
                {refreshTable.value ? (
                  <el-tree
                    ref="elTreeElem"
                    data={specs.value}
                    node-key="index"
                    props={treeProps}
                    default-expand-all={expand.value}
                    expand-on-click-node={false}
                    v-slots={{
                      default: ({ node, data }: { node: any; data: any }) => {
                        return (
                          <div class="custom-tree-node">
                            {!data.isDelete ? (
                              <div>
                                <span>{data.mixName ? data.mixName : data.name}</span>
                                <span class="operate">
                                  {node.level < 3 ? (
                                    <a onClick={() => supplierNew(node, data)}> 新增 </a>
                                  ) : null}
                                  <a onClick={() => supplierCompile(node, data)}> 编辑 </a>
                                  <a onClick={() => supplierDel(node, data)}> 删除 </a>
                                </span>
                              </div>
                            ) : null}
                          </div>
                        );
                      }
                    }}
                  ></el-tree>
                ) : null}
              </div>
            </div>

            <new-specification
              v-model={showNewSpecification.value}
              onConfirm={getSpecification}
              specificationData={specificationData.value}
              superiorData={superiorData.value}
              superior={superior.value}
              superiorCompile={superiorCompile.value}
            />
          </div>
          <div style="width: 62%">
            <kmjsTable
              params={tableJSON}
              ctl={tableCtl}
              v-slots={{
                name: ({ row }: { row: StepList }) => {
                  return <div style="white-space: pre-wrap;">{row.name}</div>;
                }
              }}
            />
            <compile
              v-model={showNewProperty.value}
              ladder={ladder.value}
              compileData={compileData.value}
              onConfirm={getCompile}
              operation={operation.value}
              clapList={clapList.value}
            />
            <tieredPricing v-model={showTieredPricing.value} onSubmit={getSubmitTiered} />
          </div>
        </div>
      );
    };
  }
});
