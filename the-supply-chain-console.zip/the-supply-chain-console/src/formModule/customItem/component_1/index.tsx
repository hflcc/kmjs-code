import { defineComponent, PropType, ref } from 'vue';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';

export default defineComponent({
  name: 'form-module-item-component_1',
  props: {
    config: {
      type: Object as PropType<ResSte>,
      required: true
    },
    moduleName: {
      type: String as PropType<string>,
      required: true
    }
  },
  setup(props) {
    const a = ref('');
    const b = ref('');
    const c = ref('');
    // 对外暴露接口
    const ctlFuns = {
      getData() {
        return {
          a: a.value,
          b: b.value,
          c: c.value.split(',')
        };
      },
      getNoVerifyData() {
        return {
          a: a.value,
          b: b.value,
          c: c.value.split(',')
        };
      },
      setData(data: { a: string; b: string; c: string[] }) {
        const v: { a: string; b: string; c: string[] | string } = data;
        try {
          if (typeof v.c === 'string') {
            v.c = JSON.parse(v.c);
          }
        } catch (e) {
          // nothing
        }
        a.value = (v as { a: string; b: string; c: string[] }).a;
        b.value = (v as { a: string; b: string; c: string[] }).b;
        c.value = (v.c as string[]).join(',');
      }
    };
    // 注册成module支持的组件
    resisterModule(props.moduleName, ctlFuns);
    return () => {
      return (
        <div>
          <hr />
          <input type="text" v-model={a.value} />
          <hr />
          <input type="text" v-model={b.value} />
          <hr />
          <input type="text" v-model={c.value} />
          <hr />
        </div>
      );
    };
  }
});
