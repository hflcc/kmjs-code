/**
 * 主要是针对不同模式进行的逻辑扩展， 必须所有的模式都实现CallBackFun中的基本方法供外部进行调用
 * 比如说 引导模式 或者必须第一页进行提交
 * */
import { TabFuns } from '@/components/modules/components/tabs';
import {
  saveDataByDef,
  saveDataByInstance,
  saveDraftByDef,
  saveDraftByInstance,
  SaveRes
} from './api';
import { ElMessage, ElMessageBox } from 'element-plus';
import xss from 'xss';

type Formlogic = (methods: TabFuns, formMethods: CallBackFun) => CallBackFun;
const tabFuns = (methods: Record<string, () => any>): TabFuns => {
  // todo 这里处理是可以确认目前就这两种情况 后续有优雅的处理方法在进行处理
  let key: string;
  if (methods['/wrap/tab']) {
    key = '/wrap/tab';
  } else {
    key = '/tab';
  }
  return {
    getActive: methods[key + '/getActive'],
    next: methods[key + '/next'],
    sub: methods[key + '/sub'],
    changeActive: methods[key + '/changeActive'],
    changeDisabled: methods[key + '/changeDisabled'],
    changeAllDisabled: methods[key + '/changeAllDisabled'],
    getAllChild: methods[key + '/getAllChild']
  };
};

const toastErrMsg = (res: SaveRes) => {
  const messages = res.error
    ? Object.values(res.error).map((v) => {
        return `${v.step.name}/${v.title}: ${v.message}`;
      })
    : [xss(res.message)]; //[];
  ElMessageBox.alert(
    "<p style='white-space: break-spaces'>" + messages.join('\n') + '</p>',
    '数据错误，请完善',
    {
      dangerouslyUseHTMLString: true
    }
  );
};

/**
 * 处理表单中的逻辑
 * */
const only = (
  snConfig: {
    defSn: string;
    instanceSn: string;
  },
  getCurrentForm: () => CurrentForm[],
  handler: (name: string, data: Record<string, unknown>) => void,
  savaQuery: Record<string, any>,
  setQueryData?: () => Promise<Record<string, any>>,
  beforeSubmit?: (data: Record<string, unknown>) => Promise<boolean>,
  submitConfirm?: (mapData: Record<string, Record<string, unknown>>) => Promise<boolean>
): CallBackFun => {
  const getData = () => {
    const resObj: Record<string, Record<string, any> | string> = {};
    const currentForm = getCurrentForm();
    currentForm.forEach((v) => {
      const data = v.methods.saveDraft();
      // 表单系统需要字符串格式的数据
      let strArr;
      if (Array.isArray(data)) {
        strArr = JSON.stringify(data);
      } else {
        strArr = Object.entries(data).map((v: [string, string]) => {
          if (typeof v[1] === 'object') {
            v[1] = JSON.stringify(v[1]);
          } else {
            v[1] = v[1]?.toString() || '';
          }
          return v;
        });
      }
      resObj[v.name] =
        typeof strArr === 'object'
          ? Object.fromEntries(strArr)
          : {
              data: strArr
            };
    });
    return resObj;
  };

  const saveDraft = async () => {
    const resObj = getData();
    if (snConfig.instanceSn) {
      const res = await saveDraftByInstance(snConfig.instanceSn, resObj);
      if (!res) return;
    } else {
      const res = await saveDraftByDef(snConfig.defSn, resObj);
      if (!res) return;
      snConfig.instanceSn = res.sn;
    }
    ElMessage.success('保存草稿成功');
    return resObj;
  };

  const submitData = async () => {
    let submitFlag = true;
    const currentForm = getCurrentForm();
    const data = await Promise.allSettled(currentForm.map((s) => s.methods.submitData()));
    const reject: PromiseRejectedResult[] = data.filter(
      (s) => s.status === 'rejected'
    ) as PromiseRejectedResult[];
    if (reject.length > 0) {
      ElMessageBox.alert(reject.map((s: PromiseRejectedResult) => s.reason).join('<br/>'), '提示', {
        dangerouslyUseHTMLString: true
      });
      return null;
    }
    const mapData: Record<string, any> = {};
    const resData: Record<string, any> = {};
    (data as PromiseFulfilledResult<Record<string, any>>[]).forEach((s, i) => {
      const d = s.value;
      mapData[currentForm[i].name] = d;
      // 表单系统需要字符串格式的数据
      let strArr;
      if (Array.isArray(d)) {
        strArr = JSON.stringify(d);
      } else {
        strArr = Object.entries(d).map((v: [string, string]) => {
          if (typeof v[1] === 'object') {
            v[1] = JSON.stringify(v[1]);
          } else {
            v[1] = v[1]?.toString() ?? '';
          }
          return v;
        });
      }
      resData[currentForm[i].name] =
        typeof strArr === 'object'
          ? Object.fromEntries(strArr)
          : {
              data: strArr
            };
    });
    const queryData: Record<string, any> = savaQuery ?? {};
    if (typeof setQueryData === 'function') {
      const requestBody = await setQueryData();
      if (requestBody !== null) {
        Object.assign(queryData, requestBody);
      }
    }
    if (typeof submitConfirm === 'function') {
      const flag = await submitConfirm(mapData);
      if (!flag) return null;
    }
    if (typeof beforeSubmit === 'function') {
      submitFlag = await beforeSubmit(mapData);
    }
    if (!submitFlag) return null;
    let res;
    if (snConfig.instanceSn) {
      res = await saveDataByInstance(snConfig.instanceSn, resData, queryData);
      if (!res) return null;
      if (!res.success) {
        toastErrMsg(res);
        return null;
      }
    } else {
      res = await saveDataByDef(snConfig.defSn, resData, queryData);
      if (!res) return null;
      if (!res.success) {
        toastErrMsg(res);
        return null;
      }
      snConfig.instanceSn = res.sn as string;
    }
    const result = {
      mapData,
      response: res
    };
    handler('submitData', result);
    return result;
  };

  const setData = (data: Record<string, Record<string, unknown>>) => {
    const currentForm = getCurrentForm();
    Object.keys(data).forEach((s) => {
      const fns = currentForm.find((v) => v.name === s);
      fns?.methods.setData(data[s]);
    });
  };

  const clearValidate = (data: Record<string, Record<string, unknown>>) => {
    const currentForm = getCurrentForm();
    Object.keys(data).forEach((s) => {
      const fns = currentForm.find((v) => v.name === s);
      fns?.methods.clearValidate(data[s]);
    });
  };

  return {
    saveDraft,
    submitData,
    setData,
    clearValidate,
    getData
  };
};
/**
 * tab_step 注册模式，一般是第一步完成后，后面的步骤才可以自由进行编辑
 * 等待数据提交成功后进行tab的操作
 * 草稿提交数据不需要处理
 * */
const tab_step: Formlogic = (tabFun, formMethods) => {
  return {
    submitData: async () => {
      const data = await formMethods.submitData();
      // 等待数据提交成功后，判断当前是不是第一个tab，是的话，将所有的tab都放开
      if (tabFun?.getActive().index === 0) {
        tabFun?.changeAllDisabled(false);
      }
      return data;
    },
    saveDraft: formMethods.saveDraft,
    setData: formMethods.setData,
    clearValidate: formMethods.clearValidate,
    getData: formMethods.getData
  };
};

/**
 * tab_freedom 自由模式，所有的tab都可以进行编辑和提交。 不需要特殊处理直接返回表单的控制即可
 * 等待数据提交成功后进行tab的操作
 * 草稿提交数据不需要处理
 * */
const tab_freedom: Formlogic = (tabFun, formMethods) => formMethods;

/**
 * tab_freedom 向导模式，一般是同时只有一个tab可进行编辑
 * 等待数据提交成功后进行tab的操作
 * */
const guide: Formlogic = (tabFun, formMethods) => {
  return {
    submitData: async () => {
      // 等待数据提交成功后，判断当前是不是第一个tab，是的话，将所有的tab都放开
      const data = await formMethods.submitData();
      tabFun?.changeAllDisabled(false);
      const name = tabFun?.next();
      tabFun?.changeDisabled(name as string, false);
      return data;
    },
    saveDraft: formMethods.saveDraft,
    setData: formMethods.setData,
    clearValidate: formMethods.clearValidate,
    getData: formMethods.getData
  };
};

export const useFormLogic = (
  snConfig: {
    defSn: string;
    instanceSn: string;
  },
  type: string,
  getCurrentForm: () => CurrentForm[],
  methods: Record<string, () => any>,
  handler: (name: string, data: Record<string, unknown>) => void,
  savaQuery: Record<string, any>,
  setQueryData?: () => Promise<Record<string, any>>,
  beforeSubmit?: (data: Record<string, unknown>) => Promise<boolean>,
  submitConfirm?: (mapData: Record<string, Record<string, unknown>>) => Promise<boolean>
): CallBackFun => {
  const callFun: CallBackFun = only(
    snConfig,
    getCurrentForm,
    handler,
    savaQuery,
    setQueryData,
    beforeSubmit,
    submitConfirm
  );
  switch (type) {
    case 'tab_step':
      return tab_step(tabFuns(methods), callFun);
    case 'tab_freedom':
      return tab_freedom(tabFuns(methods), callFun);
    case 'guide':
      return guide(tabFuns(methods), callFun);
    default:
      return callFun;
  }
};
