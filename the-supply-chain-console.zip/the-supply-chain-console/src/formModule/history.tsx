import { defineComponent, PropType } from 'vue';
import { useDialog } from '@/utils';
import kmjsModuleCode, { useModule } from '@/components/modules/module/code';
import { ElMessage, ElMessageBox } from 'element-plus';
import { delDraft, getDraftBySnNew } from '@/formModule/api';

export default defineComponent({
  name: 'form-module-history-dialog',
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    defSn: {
      type: String as PropType<string>,
      default: ''
    }
  },
  components: {
    kmjsModuleCode
  },
  emits: ['closeDialog', 'setData', 'getPlaySn'],
  setup(props, { emit }) {
    const { showDialog, closeWindow } = useDialog(props, emit);
    // const delItem = async (item: Record<string, unknown>) => {
    //   await ElMessageBox.confirm('确认删除该数据？删除后不可恢复', '删除');
    //   const result = await delDraft(item.sn as string);
    //   if (result) {
    //     ElMessage.success('删除成功');
    //     methods['/wrap/table/refresh']();
    //     emit('getPlaySn', item.sn, false);
    //   }
    // };
    const playItem = async (item: Record<string, unknown>) => {
      await ElMessageBox.confirm('确认使用该数据？ 该操作会覆盖原数据', '使用草稿数据');
      const result = await getDraftBySnNew(item.sn as string);
      if (result) {
        emit('setData', result);
        emit('getPlaySn', item.sn, true);
      }
    };
    const [moduleCtl, methods] = useModule({
      config: [
        {
          type: 'wrap-module',
          name: 'wrap',
          params: {
            title: '',
            hideBack: true
          },
          children: [
            {
              type: 'table',
              name: 'table',
              params: {
                tableDataUrl: '/auth/md/form/instance/data/page/draft/{defSn}',
                items: [
                  {
                    type: 'table',
                    tableHead: [
                      {
                        label: '内容',
                        key: 'name'
                      },
                      {
                        label: '创建人',
                        key: 'createByName'
                      },
                      {
                        label: '创建时间',
                        key: 'createAt',
                        formatter: 'dateTime', // 对数据进行格式化
                        params: {
                          dataTimeType: 'YYYY-MM-DD HH:mm:ss'
                        }
                      },
                      {
                        type: 'handle',
                        label: '操作',
                        actions: [
                          {
                            label: '使用',
                            emit: 'play'
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            }
          ]
        }
      ],
      params: {
        '/wrap/table': {
          beforeRequest: (requestObj: { url: string; params: Record<string, unknown> }) => {
            requestObj.url = requestObj.url.replace('{defSn}', props.defSn);
            return Promise.resolve(requestObj);
          }
        }
      },
      handler(moduleName, name, data) {
        switch (moduleName + '/' + name) {
          // case '/wrap/table/tableDelete':
          //   delItem(data[0].row);
          //   break;
          case '/wrap/table/tablePlay':
            playItem(data[0].row);
            break;
        }
      }
    });
    return {
      showDialog,
      closeWindow,
      moduleCtl
    };
  },
  render() {
    const { showDialog, closeWindow, moduleCtl } = this;
    return (
      <el-dialog title="草稿" v-model={showDialog} onClose={closeWindow} destroy-on-close>
        <kmjsModuleCode style={{ height: '50vh' }} ctl={moduleCtl} />
      </el-dialog>
    );
  }
});
