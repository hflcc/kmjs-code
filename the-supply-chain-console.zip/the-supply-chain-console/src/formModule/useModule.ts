import { ModuleItem } from '@/components/utils/commonType';
import { WrapConfig } from '@/components/wrap/module';

export interface ModuleFromConfig {
  params: {
    defSn: string;
    instanceSn?: string;
    type: 'create' | 'edit' | 'detail';
    wrapConfig?: WrapConfig;
    hideWrap?: boolean;
    setQueryData?: () => Promise<Record<string, any>>;
    beforeSubmit?: (data: Record<string, unknown>) => Promise<boolean>;
  };
  handler?: (moduleName: string, name: string, data: any[]) => void;
  config?: ModuleItem[];
}

export type FormCtl = () => [ModuleFromConfig, FormModuleMethods];
export type FromConfig = ResConfig;
export const useModule = function (
  params: ModuleFromConfig
): [ctl: FormCtl, method: FormModuleMethods] {
  const method: FormModuleMethods = {} as FormModuleMethods;
  const ctl = (): [ModuleFromConfig, FormModuleMethods] => {
    return [params, method];
  };
  return [ctl, method];
};
