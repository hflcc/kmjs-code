import ajax from '@/utils/axios';

/**
 * 获取表单定义，渲染出空白表单
 * */
export const getDef = (sn: string): Promise<ResConfig> => {
  return ajax.get('/auth/md/form/def/' + sn, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 获取表单实例，渲染已经具有数据的表单
 * */
export const getInstance = (sn: string): Promise<ResConfig> => {
  return ajax.get('/auth/md/form/instance/sn' + sn, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 保存草稿，没有实例sn时调用这个会返回实例的SN
 * */
export const saveDraftByDef = (
  defSn: string,
  data: Record<string, unknown>
): Promise<{ sn: string }> => {
  return ajax.post(`/auth/md/form/def/uncheck/save/${defSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 保存草稿，直接保存到当前的实例中
 * */
export const saveDraftByInstance = (
  instanceSn: string,
  data: Record<string, unknown>
): Promise<{ sn: string }> => {
  return ajax.put(`/auth/md/form/instance/uncheck/save/${instanceSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

export interface SaveRes {
  success: boolean;
  message: string;
  sn?: string;
  error: Record<
    string,
    {
      success: boolean;
      name: string;
      message: string;
      title: string;
      step: {
        name: string;
        sn: string;
      };
    }
  >;
}

/**
 * 提交数据，没有实例sn时调用这个会返回实例的SN
 * */
export const saveDataByDef = (
  defSn: string,
  data: Record<string, unknown>,
  params: Record<string, any>
): Promise<SaveRes> => {
  return ajax.post(`/auth/md/form/def/submit/${defSn}`, data, {
    params: {
      $InstId: true,
      ...params
    }
  });
};

/**
 * 提交数据，直接保存到当前的实例中
 * */
export const saveDataByInstance = (
  instanceSn: string,
  data: Record<string, unknown>,
  params: Record<string, any>
): Promise<SaveRes> => {
  return ajax.put(`/auth/md/form/instance/submit/${instanceSn}`, data, {
    params: {
      $InstId: true,
      ...params
    }
  });
};

/**
 * 删除草稿数据
 * */
export const delDraft = (instanceSn: string) => {
  return ajax.delete(`/auth/md/form/instance/draft/${instanceSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 回去草稿对应的表单数据， 对数据进行设置
 * */
export const getDraftBySn = (
  instanceSn: string
): Promise<{ stepKey: string; data: Record<string, unknown> }[]> => {
  return ajax.get(`/auth/md/form/instance/draft/${instanceSn}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 回去草稿对应的表单数据， 对数据进行设置
 * */
export const getDraftBySnNew = (
  draftSn: string
): Promise<{ stepKey: string; data: Record<string, unknown> }[]> => {
  return ajax.get(`/auth/md/form/instance/data/draft/${draftSn}`, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 获取业务数据，用以编辑和详情模式
 * */
export const getBusinessData = (
  formSn: string,
  businessSn: string
): Promise<{ stepKey: string; data: Record<string, unknown> }[]> => {
  return ajax.get(`/auth/md/form/def/business/${formSn}/${businessSn}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 对新表单定义创建一个实例， 后续直接都走表单实例的逻辑
 * */
export const buildFormModuleInstance = (
  defSn: string,
  reqBody: Record<string, any> = {}
): Promise<{ sn: string }> => {
  return ajax.post(`/auth/md/form/instance/init/${defSn}`, reqBody, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 对表单进行重置，
 * 调用接口后，对组件进行重新渲染
 * */
export const formModuleRest = (
  instanceSn: string,
  reqBody: Record<string, any> = {}
): Promise<{ sn: string }> => {
  return ajax.put(`/auth/md/form/instance/reset/${instanceSn}`, reqBody, {
    params: {
      $InstId: true
    }
  });
};

export const getHistoryData = (defSn: string): Promise<{ content: { sn: string }[] }> => {
  return ajax.get(`/auth/md/form/instance/data/page/draft/${defSn}`, {
    params: {
      $noLoad: true,
      $InstId: true
    }
  });
};
