import { defineComponent, PropType, ref } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';

export default defineComponent({
  name: 'form-item-demo',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange, setValidRule } = useValid();
    // dmeo的逻辑
    const inputValue = ref('');
    const inputFun = (e: Event) => {
      inputValue.value = (e.target as HTMLInputElement).value;
    };
    /**
     * 提交数据到整体的表单中，并触发校验
     * */
    const changeFun = () => {
      // 这里必须先调用change方法后在触发校验
      // change是将指定的数据更新至表单的数据中
      props.change(inputValue.value);
      validChange(inputValue.value);
    };
    // 这里可以设置一个校验函数，在校验时会触发校验
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (value !== '123') {
          return callback(new Error('先不通过,123'));
        }
        return callback();
      });
    }
    return {
      inputValue,
      changeFun,
      inputFun
    };
  },
  render() {
    const { changeFun, inputValue, inputFun } = this;
    return (
      <el-space>
        <input value={inputValue} onChange={inputFun} type="text" placeholder="请输入内容" />
        <el-button onClick={changeFun} size="mini">
          提交
        </el-button>
        <p>点击提交后数据才进入表单中</p>
      </el-space>
    );
  }
});
