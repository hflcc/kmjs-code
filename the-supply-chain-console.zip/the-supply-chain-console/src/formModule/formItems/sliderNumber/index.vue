<template>
  <div class="sliderWarp">
    <el-slider
      v-model="priceSectionValue"
      range
      :format-tooltip="formatTooltip"
      @change="valueChange"
      :marks="priceSectionMarks"
    >
    </el-slider>
    <div class="gap-20"></div>
    <el-spaces>
      <el-button
        :type="activeItems === i ? 'primary' : 'default'"
        @click="clickPriceSectionBtn(i)"
        v-for="(v, i) in priceSectionList"
        :key="i"
        >{{ v.min }}万-{{ v.max }}万
      </el-button>
    </el-spaces>
  </div>
</template>
<script lang="ts">
  import { defineComponent, ref, PropType, watch } from 'vue';
  import { FormItem } from '@/components/form/type';

  export default defineComponent({
    name: 'form-item-sliderNumber',
    props: {
      modelValue: {
        // 这里修改为当前符合自己的数据类型
        type: String as PropType<string>,
        default: () => {
          return '';
        },
        required: true
      },
      // 当前表单项的配置信息
      config: {
        type: Object as PropType<FormItem>,
        required: true
      },
      // 更新数据到表单的整体数据中
      change: {
        type: Function as PropType<(data: string) => void>,
        required: true
      },
      linkPlay: {
        type: Function as PropType<(data: string) => void>,
        required: true
      },
      formData: {
        type: Object as PropType<Record<string, any>>,
        required: true
      }
    },
    setup(props) {
      // 滑块选中值
      const priceSectionValue = ref([0, 0]);
      // 监听值变化的时候 触发重置
      watch(
        () => props.modelValue,
        (newValue) => {
          if (!newValue) {
            resetField();
          }
        }
      );
      const priceSectionMarks = {
        0: '0万',
        5: '5万',
        15: '15万',
        30: '30万',
        50: '50万',
        100: '100万'
      };
      const priceSectionList = [
        { min: 0, max: 5 },
        { min: 5, max: 15 },
        { min: 15, max: 30 },
        { min: 30, max: 50 },
        { min: 50, max: 100 }
      ];
      // 滑块提示
      const formatTooltip = (v: string) => {
        return `${v}万`;
      };
      // 价格区间按钮选中值
      let activeItems = ref<number>(-1);
      // 价格区间按钮点击事件
      const clickPriceSectionBtn = (v: number) => {
        activeItems.value = v;
        priceSectionValue.value = [priceSectionList[v].min, priceSectionList[v].max];
        props.change([priceSectionList[v].min, priceSectionList[v].max].join(','));
      };
      // 滑块拖动事件
      const valueChange = (val: number[]) => {
        activeItems.value = -1;
        props.change(val.join(','));
      };
      // 重置
      function resetField() {
        activeItems.value = -1;
        priceSectionValue.value = [0, 0];
      }
      return {
        formatTooltip,
        priceSectionValue,
        priceSectionMarks,
        priceSectionList,
        activeItems,
        clickPriceSectionBtn,
        valueChange
      };
    }
  });
</script>
<style lang="less" scoped>
  .sliderWarp {
    margin-left: 10px;

    &:deep(.el-slider .el-slider__marks-text) {
      font-size: 12px !important;
      width: 35px;
    }
  }
</style>
