import { defineComponent, PropType, watch, ref, watchEffect } from 'vue';
import './style.less';
import { FormItem } from '@/components/form/type';

export default defineComponent({
  name: 'form-item-tags',
  props: {
    modelValue: {
      type: Array as PropType<{ name: string; value: string }[] | string>,
      default: () => {
        return [];
      },
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: { name: string }[]) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    const arr = ref<{ name: string }[]>([]);
    watchEffect(() => {
      if (typeof props.modelValue === 'string') {
        try {
          arr.value = JSON.parse(props.modelValue);
          props.change(arr.value);
        } catch (e) {
          arr.value = [];
        }
      } else {
        arr.value = props.modelValue;
      }
    });
    return () => {
      const tags = arr.value.map((v) => {
        return <el-tag type="info">{v.name || v}</el-tag>;
      });
      return (
        <div class="form-item-tags-wrap" {...props.config.attr}>
          <el-space wrap>{tags}</el-space>
        </div>
      );
    };
  }
});
