<template>
  <el-space>
    <el-input v-model="inputValue" :disabled="true" style="width: 500px"></el-input>
    <el-button @click="getNo" type="text">刷新</el-button>
  </el-space>
</template>

<script lang="ts">
  import { defineComponent, ref, PropType, watch } from 'vue';
  import { useValid } from '@/components/form';
  import { getIncrement } from './api';

  export default defineComponent({
    name: 'form-item-serialNumber',
    props: {
      modelValue: {
        type: String as PropType<string>,
        default: ''
      },
      config: {
        type: Object as PropType<Record<string, any>>
      },
      change: {
        type: Function as PropType<(data: string, change?: boolean) => void>,
        required: true
      },
      formData: {
        type: Object as PropType<Record<string, any>>
      }
    },
    setup(props) {
      const { validChange, setValidRule } = useValid();
      const inputValue = ref('');
      /**
       * 提交数据到整体的表单中，并触发校验
       * */
      const changeFun = () => {
        // 这里必须先调用change方法后在触发校验
        // change是将指定的数据更新至表单的数据中
        props.change(inputValue.value, true);
        validChange(inputValue.value);
      };
      // 这里可以设置一个校验函数，在校验时会触发校验
      if (typeof setValidRule === 'function') {
        setValidRule(props.config?.key, (rule, value, callback) => {
          if (value === '') {
            return callback(new Error('数据为空'));
          }
          return callback();
        });
      }
      const getNo = async () => {
        let res = await getIncrement(props.config?.renderConfig?.property?.incrementDefSn);
        if (!res) return;
        inputValue.value = res.sn;
        changeFun();
      };
      watch(
        () => props.modelValue,
        (nv) => {
          if (nv === '') {
            if (!inputValue.value) {
              getNo();
            } else {
              changeFun();
            }
            return;
          } else {
            inputValue.value = nv;
            changeFun();
          }
        },
        {
          immediate: true
        }
      );
      return {
        inputValue,
        getNo
      };
    }
  });
</script>

<style lang="less"></style>
