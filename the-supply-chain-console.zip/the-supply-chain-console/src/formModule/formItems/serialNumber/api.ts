import ajax from '@/utils/axios';

/* 取号
 * */
export const getIncrement = (sn: string): Promise<{ sn: string }> => {
  return ajax.post(
    `/auth/sys/increment/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
