import { defineComponent, PropType, ref, watch } from 'vue';
import { FormItem, FormItemFun } from '@/components/form/type';
import { useValid } from '@/components/form';
import { stepValidData } from '@/utils/commApi';

interface Params {
  min: number;
  max: number;
  step: number;
  play?: {
    // 加，减，乘，除
    type: 'add' | 'subtract' | 'multiply' | 'divide';
    // 需要哪些key进行操作，当前组件的值，使用 * 代替
    sourceKey: string[];
    // 修改哪个的值
    targetKey: string;
  }[];
}

export default defineComponent({
  name: 'form-item-numberInput',
  emits: ['update:modelValue', 'change'],
  props: {
    modelValue: {
      // 这里修改为当前符合自己的数据类型
      type: Number as PropType<number>,
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: number, change: boolean) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: number) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    const { setValidRule, validChange } = useValid();
    // stopValid();
    const value = ref(0);
    const valueChange = (v: number) => {
      if (!v) {
        v = 0;
      }
      value.value = v;
      props.change(v, true);
      validChange(v);
    };
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key as string, (rule, value, callback) => {
        let { max, min } = props.config.params || {};
        if (typeof min === 'undefined') {
          min = 0;
          // 解决eslint报错而已
          max = 2147483647;
        }
        if (typeof max === 'number' && value > max) {
          return callback(new Error('最大可输入' + max));
        }
        if (typeof min === 'number' && value < min) {
          return callback(new Error('最小可输入' + max));
        }
        if (props.config.renderConfig.checker) {
          stepValidData(
            props.config.renderConfig.checker,
            props.formData
            // Object.assign({}, props.formData, { sku_sn: '33109aad0ee04f518715e398d6977dac' })
          ).then((res) => {
            if (!res) {
              return callback(new Error('校验错误，请稍后重试'));
            }
            if (res.success) {
              return callback();
            } else {
              return callback(new Error(res.message || '校验错误，请稍后重试'));
            }
          });
        } else {
          callback();
        }
      });
    }
    watch(
      () => props.modelValue,
      (nv) => {
        if (nv === value.value) return;
        if (typeof nv === 'string') {
          valueChange(Number(nv) || 0);
        }
        value.value = nv;
      }
    );
    return () => (
      <el-input-number
        v-model={value.value}
        max={props.config.params?.max ?? Infinity}
        min={props.config.params?.min ?? 0}
        precision={props.config.params?.afterPoint ?? 0}
        step={props.config.params?.step ?? 1}
        onChange={valueChange}
        size="mini"
      />
    );
  }
});
