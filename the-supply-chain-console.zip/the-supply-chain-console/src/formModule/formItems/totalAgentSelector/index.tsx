import { defineComponent, PropType, ref, watch } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormItem } from '@/components/form/type';
import { useValid } from '@/components/form';
import { ElNotification } from 'element-plus';
import { checkRelyOnHasValue } from '@/formModule/utils';

interface BusindessData {
  createdAt: number;
  createByName: string;
  saleType: string;
  name: string;
  companyLegalName: string;
  id: number;
  sn: string;
  serialCode: string;
  companyLegalPhone: string;
  platformName: string;
  auditState: string;
}

export default defineComponent({
  name: 'form-item-totalAgentSelector',
  components: {
    businessDialogItem
  },
  props: {
    modelValue: {
      // 这里修改为当前符合自己的数据类型
      type: Object as PropType<{ name: string; sn: string } | ''>,
      required: true
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false,
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: { name: string; sn: string }) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: BusindessData) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    formModuleEvents: {
      type: Object as PropType<FormModuleEvents>,
      required: true
    }
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props) {
    const { setValidRule, validChange } = useValid();
    setValidRule?.(props.config.key, (rule, value, callback) => {
      if (props.config.validNames?.includes('required')) {
        if (value === '' || !value.name || !value.sn) {
          return callback(new Error('请选择总代'));
        }
      }
      return callback();
    });
    const showDialog = ref(false);
    const data = ref({
      name: '',
      sn: ''
    });
    watch(
      () => props.modelValue,
      (nv) => {
        if (JSON.stringify(nv) === JSON.stringify(data.value)) return;
        if (typeof nv === 'string') {
          if (!nv) {
            data.value = {
              name: '',
              sn: ''
            };
          } else {
            try {
              data.value = JSON.parse(nv);
            } catch (e) {
              data.value = {
                name: '',
                sn: ''
              };
            }
          }
        } else {
          data.value = nv;
        }
        props.change(data.value);
        if (nv !== '') validChange(data.value);
      },
      {
        immediate: true
      }
    );

    const requestData = ref<Record<string, any>>({});
    const getValue = (res: BusindessData[]) => {
      if (res.length === 0) {
        return ElNotification({
          type: 'error',
          title: '出错了',
          message: '至少选择一个总代',
          duration: 4000
        });
      }
      data.value = {
        name: res[0].name,
        sn: res[0].sn
      };
      showDialog.value = false;
      props.change(data.value);
      validChange(data.value);
      props.linkPlay(res[0]);
    };
    const showWindow = () => {
      if (!checkRelyOnHasValue(props.config, props.formModuleEvents)) {
        return;
      }
      if (props.config.renderConfig.params?.requestParams) {
        Object.entries(props.config.renderConfig.params?.requestParams).forEach(
          (
            s: [
              string,
              {
                type: 'base' | 'mapping';
                value: any;
              }
            ]
          ) => {
            if (s[1].type === 'mapping') {
              const [tabName, ...key] = s[1].value.split('.');
              requestData.value[s[0]] = props.formModuleEvents.getData(tabName, key.join('.'));
            } else {
              requestData.value[s[0]] = s[1].value;
            }
          }
        );
      }
      showDialog.value = true;
    };
    return () => {
      if (props.disabled) {
        return <p {...props.config.attr}>{data.value.name}</p>;
      }
      return (
        <>
          <div class={'form-item-selector-wrap'} {...props.config.attr}>
            <div class="content-area">{data.value.name}</div>
            <div class="btn-area" onClick={showWindow}>
              选择
            </div>
          </div>
          <form-module-business-totalAgentSelector
            v-model={showDialog.value}
            params={{
              name: props.config.renderConfig.title,
              params: {
                selectMode: 'single'
              }
            }}
            tableData={{
              snKey: 'sn',
              snArr: data.value.sn ? [data.value.sn] : [],
              tableData: [data.value],
              formToBusinessKeyMapping: { name: 'name' }
            }}
            renderData={{}}
            requestData={requestData.value}
            onCloseDialog={() => {
              showDialog.value = false;
            }}
            onGetValue={getValue}
          />
        </>
      );
    };
  }
});
