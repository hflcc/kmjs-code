import { defineComponent, PropType, ref, watch } from 'vue';
import { FormItem } from '@/components/form/type';
import { useValid } from '@/components/form';
import './style.less';
import { ElMessage } from 'element-plus';

interface StepPrice {
  start: string | number;
  end: string | number;
  price: string | number;
}

export default defineComponent({
  name: 'form-item-stepPrice',
  emits: ['update:modelValue', 'change'],
  props: {
    modelValue: {
      type: Array as PropType<StepPrice[] | string>,
      default: () => {
        return [];
      },
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: StepPrice[]) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: number) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    const { setValidRule, validChange } = useValid();
    // stopValid();
    const priceList = ref<StepPrice[]>([]);

    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key as string, (rule, value, callback) => {
        let error = '';
        const reg = /^[1-9]\d*$/;
        for (let i = 0; i < value.length; i++) {
          const item = value[i];
          if (!reg.test(item.start + '')) {
            error = '起始量请输入大于0的正整数';
          } else if (!reg.test(item.end + '')) {
            error = '结束量请输入大于0的正整数';
          } else if (!reg.test(item.price + '')) {
            error = '售价请输入大于0的正整数';
          } else if (Number(item.start) >= Number(item.end)) {
            error = '阶梯起始量不能大于或等于结束量';
          }
          if (i > 0 && Number(item.start) <= Number(value[i - 1].end)) {
            error = '阶梯起始量必须要大于上一个的结束量';
          }
          if (error) {
            return callback(new Error(error));
          }
        }
        if (error) {
          return callback(new Error(error));
        } else {
          callback();
        }
      });
    }

    watch(
      () => props.modelValue,
      (nv) => {
        if (nv === priceList.value) return;
        if (typeof nv === 'string') {
          try {
            priceList.value = (JSON.parse(nv) as StepPrice[]) ?? [];
            props.change(priceList.value);
          } catch (e) {
            priceList.value = [];
          }
        } else {
          priceList.value = nv;
        }
        if (priceList.value.length === 0) {
          addStepPrice();
        }
      }
    );

    // 校验数据
    const valueChange = () => {
      props.change(priceList.value);
      validChange(priceList.value);
    };

    // 添加一项
    const addStepPrice = () => {
      priceList.value.push({
        start: '',
        end: '',
        price: ''
      });
    };
    addStepPrice();

    // 删除一项
    const deleteStepPrice = (item: StepPrice) => {
      if (priceList.value.length === 1) {
        ElMessage.warning('至少需要保留一项');
        return;
      }
      const idx = priceList.value.indexOf(item);
      if (idx !== -1) priceList.value.splice(idx, 1);
      valueChange();
    };

    return () => (
      <div class="step-price-page el-textarea__inner">
        {priceList.value.map((item) => {
          return (
            <div class="inline">
              <div class="label">
                <span class="red">*</span>起始量
              </div>
              <input v-model={item.start} class="input" onBlur={valueChange} />
              <div class="label">
                <span class="red">*</span>结束量
              </div>
              <input v-model={item.end} class="input" onBlur={valueChange} />
              <div class="label">
                <span class="red">*</span>售价
              </div>
              <input v-model={item.price} class="input" onBlur={valueChange} />
              <i
                class="el-icon-circle-close delete"
                onClick={() => {
                  deleteStepPrice(item);
                }}
              />
            </div>
          );
        })}
        {priceList.value.length < 3 ? (
          <el-button type="primary" onClick={addStepPrice}>
            添加阶梯价
          </el-button>
        ) : (
          ''
        )}
      </div>
    );
  }
});
