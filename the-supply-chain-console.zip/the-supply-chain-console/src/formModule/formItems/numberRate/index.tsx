import { defineComponent, nextTick, PropType, reactive, ref, watch } from 'vue';
import { useValid } from '@/components/form';
import { formatterValueBeforeOrAfterPoint, math } from '@/utils';

interface Expansion {
  key: 'formula';
  type: 'mapping' | 'original';
  value: string;
}

export default defineComponent({
  name: 'form-item-numberRate',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: number) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { setValidRule, validChange } = useValid();
    // dmeo的逻辑
    const inputValue = reactive({
      value: 0, // 对应modelValue的值
      unit: '', // 显示的单位
      displayValue: '', // 显示的值
      min: '',
      max: ''
    });

    const formulaUnit = ref('');
    // 初始化值和设置单位
    const init = () => {
      if (formulaUnit.value) {
        return;
      }
      inputValue.value = Number(props.modelValue);
      inputValue.displayValue = props.modelValue;
      if (props.config?.renderConfig?.property?.expansions) {
        const list = props.config?.renderConfig?.property?.expansions as Expansion[];
        list.forEach((item) => {
          if (item.key === 'formula' && item.type === 'mapping') {
            try {
              const formula = props.formData[item.value.split('.')[1]] as string;
              if (formula === 'rate') {
                inputValue.unit = '%';
                inputValue.displayValue = math.accMul(props.modelValue, 100) + '';
              }
              formulaUnit.value = formula;
            } catch (e) {
              // e
            }
          }
        });
      }
      nextTick(() => {
        if (props.config.params) {
          const params = props.config.params;
          inputValue.max =
            params?.type === 'mapping'
              ? (props.formData[params?.max.split('.')[1]] as string)
              : params?.max;
          inputValue.min =
            params?.type === 'mapping'
              ? (props.formData[params?.min.split('.')[1]] as string)
              : params?.min;
          if (inputValue.unit === '%') {
            inputValue.max = math.accMul(inputValue.max, 100) + '%';
            inputValue.min = math.accMul(inputValue.min, 100) + '%';
          }
        }
      });
    };

    // 这里可以设置一个校验函数，在校验时会触发校验
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (props.config.validNames?.includes('required') && !value) {
          return callback(new Error(`请输入${props.config.label}`));
        }
        // 校验浮动范围的值
        if (props.config.params) {
          const params = props.config.params;
          const max =
            params?.type === 'mapping'
              ? (props.formData[params?.max.split('.')[1]] as string)
              : params?.max;
          const min =
            params?.type === 'mapping'
              ? (props.formData[params?.min.split('.')[1]] as string)
              : params?.min;
          if (inputValue.value > max || inputValue.value < min) {
            return callback(new Error('请输入在浮动范围内的值'));
          }
        }
        return callback();
      });
    }

    // 修改值后校验
    const changeFun = () => {
      const params = props.config.params;
      if (params) {
        inputValue.displayValue = formatterValueBeforeOrAfterPoint(
          inputValue.displayValue,
          params?.beforePoint,
          params?.afterPoint
        );
      }
      if (inputValue.unit === '%') {
        inputValue.value = Number(inputValue.displayValue) * 0.01;
      } else {
        inputValue.value = Number(inputValue.displayValue);
      }
      props.change(inputValue.value);
      validChange(inputValue.value);
    };
    watch(
      () => props.modelValue,
      (newValue) => {
        init();
      }
    );
    return {
      inputValue,
      changeFun,
      props
    };
  },
  render() {
    const { inputValue, changeFun, props } = this;
    if (props.disabled) {
      return (
        <p>
          {inputValue.displayValue}
          {inputValue.unit}
        </p>
      );
    }
    return (
      <>
        <el-space>
          <el-input
            {...props.config.attr}
            v-model={inputValue.displayValue}
            disabled={props.disabled}
            onBlur={changeFun}
            placeholder={`请输入 ${props.config.label}`}
          />
          <span>{inputValue.unit}</span>
        </el-space>
        <p style={{ color: '#999', whiteSpace: 'break-spaces' }}>
          * 金额/比例最大浮动范围：{inputValue.min}-{inputValue.max}
        </p>
      </>
    );
  }
});
