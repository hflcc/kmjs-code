import { defineComponent, PropType, ref, watch } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import { Category, getContractDef } from './api';

export default defineComponent({
  name: 'form-item-category',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Object as PropType<(data: { scopeSn: string; scopeName: string }) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange } = useValid();
    const { orgSn, sn } = props.config.params as { orgSn: string; sn: string };

    // 分类下拉的数据
    const categoryList = ref<{ [parentId: string]: Category[] }>({});
    const selectData = ref<{ name: string; id: string; sn: string }[]>([
      { name: '', sn: '', id: '' }
    ]);

    // 更新数据
    const updateData = () => {
      const sn = selectData.value[selectData.value.length - 1].sn;
      const name = selectData.value.map((k) => k.name).join('>');
      props.linkPlay({
        scopeSn: sn,
        scopeName: name
      });
      validChange({
        scopeSn: sn,
        scopeName: name
      });
      console.log(sn, name);
    };

    // 获取类目
    const changeParent = (level: number, parentId: number) => {
      // 根据选中层级，改变已选择的数据
      const oldData = selectData.value.slice(0, level - 1);

      // 处理选中数据的name
      if (oldData.length > 0) {
        const lastData = oldData[oldData.length - 1];
        const key = 'parentId' + (level - 2 === 0 ? '' : selectData.value[level - 3].id);
        const list = categoryList.value[key];
        const o = list.find((item) => item.orgTreeId === Number(lastData.id));
        lastData.name = o?.orgTreeName || '';
        lastData.sn = o?.orgTreeSn || '';
      }

      selectData.value = [...oldData];

      // 判断对应数据 是否已经存在
      if (
        parentId > 0 &&
        Object.prototype.hasOwnProperty.call(categoryList.value, `parentId${parentId}`)
      ) {
        if (categoryList.value[`parentId${parentId}`].length > 0) {
          selectData.value.push({ name: '', sn: '', id: '' });
        }
        updateData();
        return;
      }

      getContractDef(sn, orgSn, { level, parentId }).then((res) => {
        if (parentId === 0) {
          categoryList.value['parentId'] = res;
        } else {
          categoryList.value[`parentId${parentId}`] = res;
        }
        if (res.length > 0) {
          selectData.value.push({ name: '', sn: '', id: '' });
        }
        updateData();
      });
    };
    changeParent(1, 0);

    return {
      selectData,
      changeParent,
      categoryList
    };
  },
  render() {
    const { selectData, categoryList } = this;
    return (
      <el-space>
        <div>
          {selectData.map((item, idx) => {
            return (
              <el-select
                style={{ marginRight: '12px' }}
                v-model={item.id}
                placeholder="请选择类目"
                onChange={(val: number) => {
                  this.changeParent(idx + 2, val);
                }}
              >
                {categoryList['parentId' + (idx === 0 ? '' : selectData[idx - 1].id)]?.map((k) => {
                  return <el-option key={k.orgId} label={k.orgTreeName} value={k.orgTreeId} />;
                })}
              </el-select>
            );
          })}
        </div>
      </el-space>
    );
  }
});
