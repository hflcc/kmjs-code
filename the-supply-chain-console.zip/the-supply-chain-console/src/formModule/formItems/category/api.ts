import ajax from '@/utils/axios';

export interface Category {
  level: number;
  orgId: number;
  orgSn: string;
  orgTreeId: number;
  orgTreeName: string;
  orgTreeSn: string;
  parentId: number;
  parentSn: string;
  superId: number;
  superSn: string;
}

// 合同定义-经营类目-下拉列表
export const getContractDef = (
  sn: string,
  orgSn: string,
  query: { level?: number; parentId?: number }
): Promise<Category[]> => {
  return ajax.get<null, Category[]>(`/auth/md/contract/def/orgTree/${sn}/${orgSn}`, {
    params: {
      ...query,
      $InstId: true,
      $noLoad: true
    }
  });
};
