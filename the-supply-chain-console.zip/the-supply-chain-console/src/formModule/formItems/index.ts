import { App } from 'vue';

const installFormItemComponents = (app: App): void => {
  const req = require.context('@/formModule/formItems', true, /index.vue|index.tsx$/);
  req.keys().forEach((item) => {
    const com = req(item).default;
    app.component(com.name, com);
  });
};
export default installFormItemComponents;
