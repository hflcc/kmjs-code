import { FormItem } from '@/components/form/type';
import { defineComponent, PropType, ref, watch, computed } from 'vue';
import { useStore } from 'vuex';

interface TimeItem {
  timeList: {
    sn: string;
    endAt: string;
    startAt: string;
  }[];
  week: string;
  sn: string;
}

export default defineComponent({
  name: 'form-item-businessTime',
  props: {
    modelValue: {
      // 这里修改为当前符合自己的数据类型
      type: Array as PropType<TimeItem[]>,
      default: () => {
        return [];
      },
      required: true
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false,
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string, change?: boolean) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, unknown>>,
      required: true
    },
    formModuleEvents: {
      type: Object as PropType<FormModuleEvents>,
      required: true
    }
  },
  setup(props) {
    const store = useStore();
    store.dispatch('dictionaries/getData', ['week']).then();
    const weekMap = computed(() => {
      const data = store.getters['dictionaries/getDataToJson']('week');
      console.log(data);
      return data;
    });
    const data = ref<TimeItem[]>(props.modelValue ?? []);
    watch(
      () => props.modelValue,
      (nv) => {
        let newData: TimeItem[] = [];
        if (typeof nv === 'string') {
          try {
            newData = JSON.parse(nv);
            if (!Array.isArray(newData)) {
              throw new Error('');
            }
          } catch (e) {
            newData = [];
          }
        }
        data.value = newData;
      },
      {
        immediate: true
      }
    );

    return () => {
      const items = data.value?.map((s) => {
        return (
          <div>
            {weekMap.value[s.week] ?? s.week}
            {': '}
            {s.timeList.map((d) => (
              <span style="margin-left: 4px">
                {d.startAt} ~ {d.endAt};
              </span>
            ))}
          </div>
        );
      });
      return <div class="business-time-wrap">{items}</div>;
    };
  }
});
