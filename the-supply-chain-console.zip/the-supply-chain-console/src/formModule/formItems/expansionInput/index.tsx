import { defineComponent, ref, PropType, watch } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';

export default defineComponent({
  name: 'form-item-expansionInput',
  props: {
    modelValue: {
      // 这里修改为当前符合自己的数据类型
      type: Object as PropType<{ label: string; code: string }>,
      required: true
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false,
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: { label: string; code: string }, change?: boolean) => void>,
      required: true
    },
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    formModuleEvents: {
      type: Object as PropType<FormModuleEvents>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange, setValidRule } = useValid();
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (props.config.validNames?.includes('required')) {
          if (value === '' || !value.label || !value.code) {
            return callback(new Error('请输入' + props.config.label));
          } else {
            return callback();
          }
        }
        return callback();
      });
    }
    const value = ref({
      label: '',
      code: ''
    });
    const init = (nv: string | { label: string; code: string }, valid = true) => {
      if (typeof nv === 'string' || !nv) {
        try {
          nv = JSON.parse(nv) as { label: string; code: string };
        } catch (e) {
          nv = {
            label: '',
            code: ''
          };
        }
      }
      if (nv.label && nv.code) {
        if (nv.label === value.value.label && nv.code === value.value.code) {
          return;
        }
        value.value = nv;
      } else {
        value.value = {
          label: '',
          code: new Date().getTime().toString(16)
        };
      }
      value.value.label && change(valid);
    };
    const change = (valid = true) => {
      props.change(value.value, true);
      valid && validChange(value.value);
    };
    init(props.modelValue, false);

    watch(
      () => props.modelValue,
      (nv) => {
        init(nv);
      }
    );
    return () => {
      return (
        <el-input
          {...props.config.attr}
          v-model={value.value.label}
          placeholder={'请输入' + props.config.label}
          onChange={change}
        ></el-input>
      );
    };
  }
});
