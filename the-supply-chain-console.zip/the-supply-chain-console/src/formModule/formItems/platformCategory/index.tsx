import { defineComponent, PropType, ref } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import { InstId, instIdlist, Category, oneCategory, treeCategory } from './api';
export default defineComponent({
  name: 'form-item-platformCategory',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Object as PropType<(data: { scopeSn: string; scopeName: string }) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange } = useValid();
    // 平台list
    const platformList = ref<InstId[]>([]);
    // 分类下拉的数据
    const categoryList = ref<{ [parentId: string]: Category[] }>({});
    const selectData = ref<{ name: string; sn: string; id: any }[]>([{ name: '', id: '', sn: '' }]);
    // 获取平台的数据
    instIdlist().then((res) => {
      platformList.value = res;
    });
    // 更新数据
    const updateData = () => {
      const sn = selectData.value[selectData.value.length - 1].id;
      const name = selectData.value.map((k) => k.name).join('>');
      props.linkPlay({
        scopeSn: sn,
        scopeName: name
      });
      validChange({
        scopeSn: sn,
        scopeName: name
      });
      console.log(sn, name);
      props.change(sn);
    };
    // 点击平台拿到类目的值
    const changeParent = (idx: number, val: string) => {
      console.log(val, 'valvalvalvalvalval');

      // 根据选中层级，改变已选择的数据
      const oldData: any = selectData.value.slice(0, idx + 1);
      // 处理选中数据的name
      if (oldData.length > 0) {
        const lastData = oldData[oldData.length - 1];
        const key = 'parentId' + (idx === 1 ? '' : idx);
        const list: any = idx == 0 ? platformList.value : categoryList.value[key];
        const o = list.find((item: any) => {
          if (idx === 0) {
            return item.id == lastData.typeInstSn;
          } else {
            return item.sn == lastData.id;
          }
        });
        console.log(o, 'oldDataoldDataoldData');
        lastData.name = o?.name || o?.typeInstName || '';
        lastData.sn = o?.orgSn || o?.typeInstSn || '';

        console.log(lastData, 'o.value');
        console.log(oldData, 'o.value');
      }

      selectData.value = [...oldData];

      if (idx == 0) {
        oneCategory(val, 'inst_goods_category').then((res) => {
          isCategoryList(res.sn, '0', idx);
        });
      } else {
        isCategoryList(selectData.value[idx].sn, val, idx);
      }
    };
    const isCategoryList = (orgSn: string, parentSn: string, idx: number) => {
      treeCategory(orgSn, parentSn).then((res) => {
        if (idx == 0) {
          categoryList.value['parentId'] = res;
        } else {
          categoryList.value[`parentId${idx + 1}`] = res;
        }
        if (res.length > 0) {
          selectData.value.push({ name: '', id: '', sn: '' });
        }
        updateData();
      });
    };
    return {
      changeParent,
      platformList,
      selectData,
      categoryList
    };
  },
  render() {
    const { platformList, selectData, categoryList } = this;
    return (
      <el-space>
        {selectData.map((item, idx) => {
          return (
            <span>
              {idx == 0 ? (
                <el-select
                  style={{ marginRight: '12px' }}
                  v-model={item.id}
                  value-key={item.name}
                  placeholder="请选择平台"
                  onChange={(val: string) => {
                    this.changeParent(idx, val);
                  }}
                >
                  {platformList.map((res) => {
                    return <el-option label={res.typeInstName} value={res.typeInstSn} />;
                  })}
                </el-select>
              ) : (
                <el-select
                  style={{ marginRight: '12px' }}
                  v-model={item.id}
                  placeholder="请选择类目"
                  value-key={item.name}
                  onChange={(val: string) => {
                    this.changeParent(idx, val);
                  }}
                >
                  {categoryList['parentId' + (idx == 1 ? '' : idx)]?.map((k) => {
                    return <el-option label={k.name} value={k.sn} />;
                  })}
                </el-select>
              )}
            </span>
          );
        })}
      </el-space>
    );
  }
});
