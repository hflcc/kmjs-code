import ajax from '@/utils/axios';

// 平台字段
export interface InstId {
  bizMdInstName: string;
  bizMdInstSn: string;
  instInstSn: string;
  typeInstName: string;
  typeInstSn: string;
  state: string;
}

// 类目字段
export interface Category {
  name: string;
  sort: number;
  orgName: string;
  orgSn: string;
  instName: string;
  instSn: string;
  type: string;
  sn: string;
  id?: string;
}
// 查询关联机构平台列表
export const instIdlist = (): Promise<InstId[]> => {
  return ajax.get('/auth/md/inst/associate/inst_id/list', {
    params: {
      state: 'normal',
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 查询第一个类类目
 * instSn: 机构sn;
 * type: 组织类型 (inst_goods_category)写死;
 * **/
export const oneCategory = (instSn: string, type: string): Promise<Category> => {
  return ajax.get(`/auth/md/inst/org/search/${instSn}/${type}`, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 根据组织sn、父级sn获取下一级组织树
 * orgSn: 组织sn;
 * parentSn: 父级树sn;
 * **/
export const treeCategory = (orgSn: string, parentSn: string): Promise<Category[]> => {
  return ajax.get(`/auth/md/inst/org/tree/list/${orgSn}/${parentSn}`, {
    params: {
      $InstId: true
    }
  });
};
