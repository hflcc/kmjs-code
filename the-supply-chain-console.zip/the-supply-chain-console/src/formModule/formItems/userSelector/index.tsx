import { defineComponent, PropType, ref, watch } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import { ElMessage } from 'element-plus';
import './index.less';

interface User {
  username: string;
  sn: string;
}

import ChooseMember from '@/components/chooseMember/index.vue';
export default defineComponent({
  name: 'form-item-userSelector',
  components: {
    ChooseMember
  },
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    linkPlay: {
      type: Object as PropType<(data: { scopeSn: string; scopeName: string }) => void>,
      required: true
    }
  },
  setup(props) {
    // 处理与整体表单校验相关
    // validChange 当像表单中提交的数据发生变化时。调用触发校验（触发的时change的触发方式）
    // setValidRule 为当前表单在整体表单中注册一个校验函数，默认时change触发
    const { validChange } = useValid();

    const showChooseOrganization = ref(false);

    // 选择人员
    const selectUser = () => {
      showChooseOrganization.value = true;
    };

    const currentUser = ref<User>({
      username: '',
      sn: ''
    });

    // 调用重置后，清空数据。草稿的数据回显
    watch(
      () => props.modelValue,
      (val) => {
        if (!val) {
          currentUser.value = {
            username: '',
            sn: ''
          };
        } else {
          // console.log(props.formData);
          if (currentUser.value.sn !== props.formData['attendor_inst_user_sn']) {
            currentUser.value = {
              username: props.formData['attendor_name'],
              sn: props.formData['attendor_inst_user_sn']
            };
          }
        }
      }
    );

    const getChooseOrg = (data: any[]) => {
      // closeDialog();
      if (data.length > 1) {
        return ElMessage.error('只能选择一个');
      }
      // 当有组织，且组织下不为一个时
      // if (!data[0].isHuman) {
      //   return ElMessage.error('不能选择组织节点');
      // } else {
      currentUser.value = { username: data[0].scopeName, sn: data[0].scopeSn };
      // }
      props.change(currentUser.value.sn);
      props.change(currentUser.value.username);
      props.linkPlay({
        scopeSn: currentUser.value.sn,
        scopeName: currentUser.value.username
      });
      validChange({
        scopeSn: currentUser.value.sn,
        scopeName: currentUser.value.username
      });

      showChooseOrganization.value = false;
    };

    return {
      currentUser,
      selectUser,
      showChooseOrganization,
      getChooseOrg
    };
  },
  render() {
    const { currentUser, selectUser, getChooseOrg } = this;
    return (
      <el-space>
        {currentUser.sn && currentUser.sn !== '-1' ? (
          <div
            class="input-class"
            onClick={() => {
              selectUser();
            }}
          >
            {currentUser.username}
          </div>
        ) : (
          <div
            class="input-class placeholder"
            onClick={() => {
              selectUser();
            }}
          >
            点击选择人员
          </div>
        )}

        <choose-member
          v-model={this.showChooseOrganization}
          titleValue="请选择成员"
          onOnConfirm={(d: any[]) => {
            getChooseOrg(d);
          }}
        />
      </el-space>
    );
  }
});
