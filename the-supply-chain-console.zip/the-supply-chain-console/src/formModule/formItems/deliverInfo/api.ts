import ajax from '@/utils/axios';

export interface GetEcDeliverSearchResponse {
  // 快递单号
  billSn?: string;
  // 派件员
  courier?: string;
  // 派件员手机号
  courierPhone?: string;
  // 快递状态
  deliveryStatus?: string;
  // 快递公司名称
  expName?: string;
  // 快递公司名称
  expPhone?: string;
  // 快递公司logo
  logo?: string;
  // 是否成功
  success?: boolean;
  // 耗时
  takeTime?: string;
  // 快递流水
  statusList?: Array<{ status: string; time: string }>;
}
// 根据订单号获取物流信息
export const getEcDeliverSearch = (sn: string): Promise<GetEcDeliverSearchResponse> => {
  return ajax.get<null, GetEcDeliverSearchResponse>(`/auth/ec/deliver/search/${sn}`, {
    params: {
      $InstId: true
    }
  });
};
