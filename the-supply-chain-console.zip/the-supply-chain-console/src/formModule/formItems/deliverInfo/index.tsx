import { defineComponent, PropType, reactive, ref, watch } from 'vue';
import { FormItem } from '@/components/form/type';
import { getEcDeliverSearch, GetEcDeliverSearchResponse } from './api';

export interface DeliverInfoResponseData {
  orderSn: string;
  billSn: string;
}

export default defineComponent({
  name: 'form-item-deliverInfo',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: Object as PropType<DeliverInfoResponseData>,
      required: true
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    }
  },
  setup(props) {
    const data = reactive<GetEcDeliverSearchResponse>({});
    const hasDeliver = ref(false);
    /**
     * @method jsonParse
     * @desc json格式化
     * @param {string} JSON字符串
     * @return {T} 对应的泛型结果
     */
    function jsonParse<T>(str: string): T {
      let result = {};
      try {
        result = JSON.parse(str);
      } catch (error) {
        console.log(error);
      }
      return result as T;
    }
    watch(
      () => props.modelValue,
      (newValue: DeliverInfoResponseData) => {
        const result = jsonParse<DeliverInfoResponseData>(newValue as unknown as string);
        if (result.billSn) {
          hasDeliver.value = true;
          getEcDeliverSearch(result.orderSn).then((res) => {
            Object.assign(data, res);
          });
        }
      }
    );
    return {
      data,
      hasDeliver
    };
  },
  render() {
    const { data, hasDeliver } = this;
    return hasDeliver ? (
      <el-timeline>
        {data?.statusList?.map((item) => {
          return <el-timeline-item timestamp={item.time}>{item.status}</el-timeline-item>;
        })}
      </el-timeline>
    ) : (
      <div>--</div>
    );
  }
});
