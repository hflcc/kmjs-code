import { FormItem, FormItemFun } from '@/components/form/type';
import { defineComponent, PropType, ref, reactive, watch } from 'vue';
import { useValid } from '@/components/form/items/useValid';
import kmjsTable, { useTable } from '@/components/table/code';
export default defineComponent({
  name: 'form-item-costTable',
  components: {
    kmjsTable
  },
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: Object as PropType<{ scopeSn: string; scopeName: string }>,
      default: () => {
        return {};
      }
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Object as PropType<(data: { scopeSn: string; scopeName: string }) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props, { emit }) {
    const renderDetailData = ref('查询中。。。');
    const tableJSON = {
      tableDataUrl: '/auth/mk/csc/instance/plan/page',
      items: [
        {
          type: 'table',
          tableSelectMode: 'single',
          tableHead: [
            {
              label: '名称',
              key: 'name'
            },
            {
              label: '类目',
              key: 'category',
              width: 120
            },
            {
              label: '金额',
              key: 'amount'
            }
          ]
        }
      ]
    };
    const [tableCtl, tableMethods] = useTable({});
    watch(
      () => props.modelValue,
      (newValue) => {
        console.log('table', newValue);
      }
    );
    return {
      renderDetailData,
      tableCtl,
      tableJSON
    };
  },
  render() {
    const { disabled, renderDetailData, tableCtl, tableJSON } = this;
    if (disabled) {
      return <p style={{ whiteSpace: 'break-spaces' }}>{renderDetailData}</p>;
    }
    return (
      <div>
        <kmjsTable params={tableJSON} ctl={tableCtl}></kmjsTable>
      </div>
    );
  }
});
