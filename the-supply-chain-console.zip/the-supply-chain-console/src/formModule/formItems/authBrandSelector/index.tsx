import { computed, defineComponent, PropType, ref, watchEffect } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import './style.less';
import { getChainData } from '@/utils';

/**
 * 选择认证品牌
 */
export default defineComponent({
  name: 'form-item-authBrandSelector',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string | { name: string; sn: string }>,
      default: ''
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: { name: string; sn: string }) => void>,
      required: true
    },
    // // 处理需要业务数据的依赖
    // linkPlay: {
    //   type: Function as PropType<(data: string) => void>,
    //   required: true
    // },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    formModuleEvents: {
      type: Object as PropType<{
        // 子表单间互相修改指定tab下的表单内指定key的数据
        setData: (tabName: string, key: string, data: any) => void;
        //子表单间互相获取指定tab下的表单指定key的数据
        getData: (tabName: string, key: string) => any;
      }>
    }
  },
  setup(props) {
    const dialogRequestData = ref<Record<string, any>>({});
    const { validChange, setValidRule } = useValid();
    const showDialog = ref(false);
    const value = ref<{ name: string; sn: string }>({ name: '', sn: '' });
    const name = computed(() => {
      return value.value.name;
    });
    const getValue = (value: any) => {
      const obj = { name: value[0].name, sn: value[0].sn };
      value.value = obj;
      props.change(obj);
      validChange(obj);
      // props.linkPlay(obj);
      showDialog.value = false;
    };
    watchEffect(() => {
      if (typeof props.modelValue === 'string') {
        try {
          value.value = JSON.parse(props.modelValue);
        } catch (e) {
          value.value = { name: '', sn: '' };
        }
      } else {
        value.value = props.modelValue;
      }
    });

    // 这里可以设置一个校验函数，在校验时会触发校验
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (props.config.validNames?.includes('required')) {
          if (!value.sn) {
            return callback(new Error('请选择认证品牌'));
          }
        }
        callback();
      });
    }

    // 显示选择器
    const showWindow = () => {
      if (props.config.renderConfig?.params?.requestParams) {
        dialogRequestData.value = {};
        Object.keys(props.config.renderConfig?.params?.requestParams).forEach((s) => {
          const item = props.config.renderConfig?.params?.requestParams?.[s] ?? {};
          if (item.type === 'mapping') {
            const keys = item.value.split('.');
            const formData = props.formModuleEvents?.getData(keys[0], keys[1]);
            dialogRequestData.value[s] = getChainData(formData, keys.slice(2).join('.'));
          } else {
            dialogRequestData.value[s] = item.value;
          }
        });
      }
      showDialog.value = true;
    };

    return () => {
      if (props.disabled) {
        return <p>{name.value}</p>;
      }
      return (
        <>
          <div
            class="form-item-brandSelector"
            {...props.config.attr}
            onClick={() => {
              showWindow();
            }}
          >
            {value.value.name ? (
              <p>{value.value.name}</p>
            ) : (
              <p style={{ color: '#999' }}>请选择认证品牌</p>
            )}
            <div class="btn">选择</div>
          </div>
          <form-module-business-authBrandSelector
            v-model={showDialog.value}
            requestData={dialogRequestData.value}
            renderData={props.renderData}
            onGetValue={getValue}
            onCloseDialog={() => {
              showDialog.value = false;
            }}
            params={{
              name: props.config?.renderConfig?.title ?? '',
              params: {
                selectMode: 'single'
              }
            }}
            tableData={{
              snKey: 'sn',
              snArr: value.value.sn ? [value.value.sn] : [],
              tableData: [value.value],
              formToBusinessKeyMapping: { name: 'name' }
            }}
          />
        </>
      );
    };
  }
});
