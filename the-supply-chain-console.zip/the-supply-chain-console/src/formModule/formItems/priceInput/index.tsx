import { FormItem, FormItemFun } from '@/components/form/type';
import { defineComponent, PropType, ref, reactive, watch } from 'vue';
import './style.less';
import { useValid } from '@/components/form/items/useValid';
interface inputData {
  [key: string]: string;
  agencyFees: string;
  usageFee: string;
}
export default defineComponent({
  name: 'form-item-priceInput',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: Object as PropType<{ scopeSn: string; scopeName: string }>,
      default: () => {
        return {};
      }
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: inputData) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Object as PropType<(data: { scopeSn: string; scopeName: string }) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props, { emit }) {
    const { validChange, setValidRule } = useValid();
    // 详情模式时展示
    const renderDetailData = ref('查询中。。。');
    // const getData = async () => {
    //   const data = await store.dispatch('source/getAddressData');
    //   if (!data) return;
    //   treeData.value = data;
    //   selectChange();
    //   if (props.modelValue?.areaSn && props.modelValue?.areaSn !== area.value) {
    //     detailData(props.modelValue?.areaSn);
    //   }
    // };
    const data = reactive<inputData>({} as inputData);
    const changeData = () => {
      validChange(data);
      props.change(data);
    };
    const updateInput = (type: string, e: string) => {
      data[type] = e;
      changeData();
    };
    // 这里可以设置一个校验函数，在校验时会触发校验
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (props.config.validNames?.includes('required')) {
          if (!value.agencyFees) {
            return callback(new Error('请输入品牌代理费'));
          }
          if (!value.usageFee) {
            return callback(new Error('请输入品牌使用费'));
          }
        }
        callback();
      });
    }
    watch(
      () => props.modelValue,
      (newValue) => {
        console.log('priceInput', newValue);
      }
    );
    return {
      renderDetailData,
      updateInput,
      data,
      props
    };
  },
  render() {
    const { renderDetailData, updateInput, data, props } = this;
    if (props.disabled) {
      return <p>{renderDetailData}</p>;
    }
    return (
      <div>
        <el-form-item label="品牌代理费" prop="agencyFees" label-width="90px">
          <el-input
            modelValue={data.agencyFees}
            placeholder="请输入品牌代理费"
            onInput={(e: string) => updateInput('agencyFees', e)}
          ></el-input>
          <div class="desc">
            美容美体店采购/美容护理产品品牌代理商1000~3000元
            <el-popover
              placement="bottom"
              width="200"
              trigger="hover"
              content="品牌代理费：如代理商代理该品牌，品牌方将收取的代理费用"
              v-slots={{
                reference: () => <i class="icon el-icon-question"></i>
              }}
            ></el-popover>
          </div>
        </el-form-item>
        <el-form-item label="品牌使用费" label-width="90px">
          <el-input
            modelValue={data.usageFee}
            placeholder="请输入品牌使用费"
            onInput={(e: string) => updateInput('usageFee', e)}
          ></el-input>
          <div class="desc">
            美容美体店采购/美容护理产品品牌代理商1000~3000元
            <el-popover
              placement="bottom"
              width="200"
              trigger="hover"
              content="品牌使用费：如代理商代理该品牌，品牌方将收取的使用费用"
              v-slots={{
                reference: () => <i class="icon el-icon-question"></i>
              }}
            ></el-popover>
          </div>
        </el-form-item>
      </div>
    );
  }
});
