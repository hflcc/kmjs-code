import { computed, defineComponent, PropType, ref, watchEffect } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import './style.less';

/**
 * 选择认证品牌
 */
export default defineComponent({
  name: 'form-item-setOrgSelector',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string | { name: string; sn: string }>,
      default: ''
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: { name: string; sn: string }) => void>,
      required: true
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 处理需要业务数据的依赖
    // linkPlay: {
    //   type: Object as PropType<(data: { sn: string; name: string }) => void>,
    //   required: true
    // },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    formModuleEvents: {
      type: Object as PropType<{
        // 子表单间互相修改指定tab下的表单内指定key的数据
        setData: (tabName: string, key: string, data: any) => void;
        //子表单间互相获取指定tab下的表单指定key的数据
        getData: (tabName: string, key: string) => any;
      }>
    }
  },
  setup(props) {
    const { validChange, setValidRule } = useValid();
    const showDialog = ref(false);
    const value = ref<{ name: string; sn: string }>({ name: '', sn: '' });
    const name = computed(() => {
      return value.value.name;
    });
    // 这里可以设置一个校验函数，在校验时会触发校验
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (props.config.validNames?.includes('required')) {
          if (!value.sn) {
            return callback(new Error('请设置组织'));
          }
        }
        callback();
      });
    }
    watchEffect(() => {
      if (typeof props.modelValue === 'string') {
        try {
          value.value = JSON.parse(props.modelValue);
        } catch (e) {
          value.value = { name: '', sn: '' };
        }
      } else {
        value.value = props.modelValue;
      }
    });
    // 显示选择器
    const showWindow = () => {
      showDialog.value = true;
    };

    const getChooseOrg = (data: { orgTreeName: string; orgTreeSn: string }[]) => {
      showDialog.value = false;
      value.value.name = data.map((item) => item.orgTreeName).join(',');

      const obj = {
        name: data.map((item) => item.orgTreeName).join(','),
        sn: data.map((item) => item.orgTreeSn).join(',')
      };
      value.value = obj;
      props.change(obj);
      validChange(obj);
      // props.linkPlay(obj);
      showDialog.value = false;
    };

    return () => {
      if (props.disabled) {
        return <p>{name.value}</p>;
      }
      return (
        <>
          <div
            class="form-item-setOrgSelector"
            {...props.config.attr}
            onClick={() => {
              showWindow();
            }}
          >
            {value.value.name ? (
              <p>{value.value.name}</p>
            ) : (
              <p style={{ color: '#999' }}>请设置组织</p>
            )}
            <div class="btn">选择</div>
          </div>
          <form-module-business-orgTreeSelector
            v-model={showDialog.value}
            onGetValue={(d: any[]) => {
              getChooseOrg(d);
            }}
          />
        </>
      );
    };
  }
});
