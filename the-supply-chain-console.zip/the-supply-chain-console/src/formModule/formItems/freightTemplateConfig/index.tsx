import { defineComponent, onMounted, PropType, ref, watch } from 'vue';
import { useValid } from '@/components/form';
import { FormItem } from '@/components/form/type';
import './style.less';
import CityChoose from './components/cityChoose';
enum renderType {
  cityMultiple = 'cityMultiple',
  freightCalculation = 'freightCalculation',
  cityFreightTemplateList = 'cityFreightTemplateList'
}
interface TemplateData {
  renderList: any[];
  addAmount?: string;
  addNum?: string;
  areaSns?: string[];
  defaultAmount?: string;
  defaultNum?: string;
  id?: number;
  allSelectedAreaSns?: string[];
}
const freightUnitMapText: Record<string, string> = {
  piece: '件',
  weight: '公斤',
  volume: 'm³'
};
const buildDefault = () => {
  return {
    addAmount: undefined,
    addNum: undefined,
    defaultAmount: undefined,
    defaultNum: undefined,
    areaSns: [],
    allSelectedAreaSns: []
  };
};
let id = 0;
export default defineComponent({
  name: 'form-item-freightTemplateConfig',
  props: {
    // 当前表单中的默认数据。一般建议watch下，防止表单设置数据时更新不及时
    modelValue: {
      type: String as PropType<string>,
      default: ''
    },
    disabled: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 当前表单项的配置信息
    config: {
      type: Object as PropType<FormItem>,
      required: true
    },
    // 更新数据到表单的整体数据中
    change: {
      type: Function as PropType<(data: any) => void>,
      required: true
    },
    // 处理需要业务数据的依赖
    linkPlay: {
      type: Function as PropType<(data: string) => void>,
      required: true
    },
    // 表单内的数据
    formData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    }
  },
  setup(props) {
    const { validChange, setValidRule } = useValid();
    let data: any = '';
    const freightUnitText = ref(freightUnitMapText.piece);
    let renderList: any[] = [];
    const templateList = ref<TemplateData[]>([]);
    const allSelectedAreaSns = ref<string[]>([]);
    const expansions = props.config?.renderConfig?.property?.expansions || [];
    const renderNames = ref<string[]>([]);
    expansions.forEach((item) => {
      if (item.key === 'freightTemplate') {
        renderNames.value.push(item.value);
      }
    });
    const isList = renderNames.value.includes(renderType.cityFreightTemplateList);
    if (typeof setValidRule === 'function') {
      setValidRule(props.config?.key, (rule, value, callback) => {
        if (isList && value.length !== 0) {
          value.forEach((item: any) => {
            const flag = Object.keys(item).every((name) => {
              if (name === 'areaSns') {
                return item[name].length !== 0;
              }
              return item[name];
            });
            if (!flag) {
              return callback(new Error(`请完成${props.config.label}`));
            }
          });
        }
        if (props.config.validNames?.includes('required')) {
          if (!isList && renderNames.value.includes(renderType.freightCalculation)) {
            const flag = Object.keys(value).every((name) => {
              return value[name];
            });
            if (!flag) {
              return callback(new Error(`请完成${props.config.label}`));
            }
          }
          if (!isList && renderNames.value.includes(renderType.cityMultiple)) {
            if (value.length === 0) return callback(new Error(`请完成${props.config.label}`));
          }
        }
        return callback();
      });
    }
    const getFreightCalculation = (data: any) => {
      return {
        addAmount: data.addAmount,
        addNum: data.addNum,
        defaultAmount: data.defaultAmount,
        defaultNum: data.defaultNum
      };
    };
    /**
     * 提交数据到整体的表单中，并触发校验
     * */
    const changeFun = () => {
      // 这里必须先调用change方法后在触发校验
      // change是将指定的数据更新至表单的数据中
      if (renderNames.value.length === 1) {
        if (renderNames.value.includes(renderType.cityMultiple)) {
          //区域选择
          props.change(templateList.value[0].areaSns);
          validChange(templateList.value[0].areaSns);
        } else {
          //运费计算方式
          const data = templateList.value[0];
          props.change(getFreightCalculation(data));
          validChange(getFreightCalculation(data));
        }
        return;
      }
      const list = templateList.value.map((item) => {
        return {
          areaSns: JSON.parse(JSON.stringify(item.areaSns)),
          ...getFreightCalculation(item)
        };
      });
      props.change(list);
      validChange(list);
    };
    const onCityChoose = (selectedData: string[], index: number) => {
      templateList.value[index].areaSns = selectedData;
      const allAreaSns: string[] = [];
      templateList.value.forEach((item) => {
        item.areaSns?.forEach((sn) => allAreaSns.push(sn));
      });
      allSelectedAreaSns.value = [...allAreaSns];
      changeFun();
    };
    const onAddTemplate = () => {
      templateList.value.push({
        renderList: renderList,
        ...buildDefault(),
        allSelectedAreaSns: allSelectedAreaSns.value
      });
      changeFun();
    };
    const onDelete = (index: number) => {
      templateList.value.splice(index, 1);
      changeFun();
    };
    watch(
      () => props.formData.type,
      () => {
        freightUnitText.value = freightUnitMapText[props.formData.type];
      },
      {
        immediate: true
      }
    );
    const freightCalculation = (data: TemplateData, index: number) => {
      if (props.disabled) {
        return (
          <div>
            {data.defaultNum}
            {freightUnitText.value}内 {data.defaultAmount}元 每增加{data.addNum}
            {freightUnitText.value}，增加运费{data.addAmount}元
          </div>
        );
      }
      return (
        <div class="flex">
          <div class="flex">
            <el-input-number
              controls-position="right"
              v-model={data.defaultNum}
              min={1}
              precision={0}
              max={10000}
              class="input first-input"
              onChange={changeFun}
            ></el-input-number>
            {freightUnitText.value}内
            <el-input-number
              controls-position="right"
              v-model={data.defaultAmount}
              min={0.1}
              max={10000}
              precision={2}
              class="input"
              onChange={changeFun}
            ></el-input-number>
            元
          </div>
          <div class="flex add-freight">
            每增加
            <el-input-number
              controls-position="right"
              v-model={data.addNum}
              min={1}
              precision={0}
              max={10000}
              class="input"
              onChange={changeFun}
            ></el-input-number>
            {freightUnitText.value}，增加运费
            <el-input-number
              controls-position="right"
              v-model={data.addAmount}
              min={0.1}
              max={10000}
              precision={2}
              class="input"
              onChange={changeFun}
            ></el-input-number>
            元
          </div>
          {isList ? (
            <el-button
              type="danger"
              class="icon-delete"
              icon="el-icon-delete"
              circle
              onClick={() => onDelete(index)}
            ></el-button>
          ) : (
            ''
          )}
        </div>
      );
    };
    const cityChoose = (data: TemplateData, index: number) => {
      const params = {
        disabled: props.disabled,
        allSelectedAreaSns: allSelectedAreaSns.value,
        onConfirm: (selectedData: string[]) => onCityChoose(selectedData, index)
      };
      return <CityChoose v-model={data.areaSns} {...params}></CityChoose>;
    };
    const initData = () => {
      renderNames.value.forEach((name: string) => {
        if (name === renderType.cityMultiple) {
          renderList.push(cityChoose);
        } else if (name === renderType.freightCalculation) {
          renderList.push(freightCalculation);
        }
      });
      if (renderNames.value.length === 1) {
        if (renderNames.value.includes(renderType.cityMultiple)) {
          //城市选择数据格式
          templateList.value.push({
            renderList: renderList,
            id: ++id,
            areaSns: data || []
          });
        } else {
          templateList.value.push({
            renderList: renderList,
            id: ++id,
            ...data
          });
        }
      } else if (renderNames.value.length >= 2) {
        if (data) {
          const allAreaSns: string[] = [];
          data.forEach((item: any) => {
            allAreaSns.push(...item.areaSns);
            templateList.value.push({
              renderList: renderList,
              allSelectedAreaSns: [],
              id: ++id,
              ...(item as any)
            });
          });
          allSelectedAreaSns.value = allAreaSns;
        }
      }
    };
    watch(
      () => props.modelValue,
      (val) => {
        if (props.modelValue) {
          if (typeof val === 'string') {
            templateList.value = [];
            renderList = [];
            data = JSON.parse(val);
            props.change(data);
            initData();
          }
        } else {
          data = '';
          initData();
        }
      },
      {
        immediate: true
      }
    );
    return {
      freightCalculation,
      cityChoose,
      onAddTemplate,
      renderList,
      templateList,
      isList
    };
  },
  render() {
    const { $props, templateList, onAddTemplate, isList } = this;
    return (
      <div class="freight-template-warp">
        {templateList.map((item: TemplateData, index: number) => {
          return item.renderList.map((v, i) => {
            return <div key={item.id}>{v(item, index)}</div>;
          });
        })}
        {isList && !$props.disabled ? (
          <el-button class="add_btn" icon="el-icon-plus" onClick={onAddTemplate}>
            添加指定区域
          </el-button>
        ) : (
          ''
        )}
      </div>
    );
  }
});
