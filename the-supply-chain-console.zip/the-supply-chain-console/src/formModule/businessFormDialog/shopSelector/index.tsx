import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';
import { FormItem, InputType } from '@/components/form/type';

export default defineComponent({
  name: 'form-item-shopSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '编号',
        key: 'shopNo',
        type: InputType.text
      },
      {
        label: '名称',
        key: 'shopName',
        type: InputType.text
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/shop/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'shopNo'
            },
            {
              label: '名称',
              key: 'shopName'
            },
            {
              label: '类型',
              key: 'shopDefName'
            },
            {
              label: '经营状态',
              type: 'mapText',
              key: 'operateState',
              params: {
                type: 'local',
                localData: {
                  on: '经营',
                  off: '打烊'
                }
              }
            },
            {
              label: '创建时间',
              key: 'createdAt',
              formatter: FormatterType.dateTime,
              width: 180,
              params: {
                dataTimeType: 'YYYY-MM-DD hh:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
