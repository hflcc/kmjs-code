import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormItem, InputType } from '@/components/form/type';
import { TableConfig } from '@/components/table/kmjsTableType';

interface BusinessData {
  contractInstancePartnerResponses: { name: string }[];
}
export default defineComponent({
  name: 'form-module-business-contractSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs: FormItem[] = [
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '编号',
        key: 'serialCode',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '合同名称',
        key: 'name',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '合同类型',
        key: 'auditState',
        type: InputType.select,
        dictionaryName: 'supplier_audit_state'
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '参与方',
        key: 'state',
        type: InputType.text
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/contract/instance/page',
      items: [
        {
          type: 'search',
          inputs: inputs
        },
        {
          type: 'table',
          tableSelectMode: 'single',
          tableHead: [
            {
              label: '编号',
              key: 'serialCode'
            },
            {
              label: '合同名称',
              key: 'name'
            },
            {
              type: 'mapText',
              label: '审核状态',
              key: 'auditState',
              params: {
                type: 'dictionary',
                dictionaryName: 'contract_audit_state'
              }
            },

            {
              label: '参与方',
              key: 'partner'
            },
            {
              type: 'mapText',
              label: '合同类型',
              key: 'type',
              params: {
                type: 'dictionary',
                dictionaryName: 'contract_type'
              }
            },
            {
              label: '平台',
              key: 'bizMdTypeInstName'
            },
            {
              type: 'rangeText',
              label: '时间',
              key: 'createdAt',
              params: {
                startKey: 'startAt',
                endKey: 'endAt',
                formatter: 'dateTime'
              }
            }
          ]
        }
      ]
    };

    const dataFormatter = (tableData: BusinessData[]) => {
      return tableData.map((item) => {
        return {
          ...item,
          partner: item.contractInstancePartnerResponses.map((s) => s.name).join('\n')
        };
      });
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          dataFormatter={dataFormatter}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
