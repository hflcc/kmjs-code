import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';
import { FormItem, InputType } from '@/components/form/type';

export default defineComponent({
  name: 'form-module-business-customerServiceSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '客服中心',
        key: 'name',
        type: InputType.text
      },
      {
        label: 'ID',
        key: 'cscNo',
        type: InputType.text
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/mk/csc/def/backstage/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: 'ID',
              key: 'number'
            },
            {
              label: '头像',
              type: 'image',
              key: 'ossId',
              params: {
                width: '50px'
              }
            },
            {
              label: '客服中心',
              key: 'name'
            },
            {
              label: '客服数',
              key: 'serviceCount'
            },
            {
              label: '创建时间',
              key: 'createdAt',
              formatter: FormatterType.dateTime,
              params: {
                dataTimeType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
