/**
 * 选择认证品牌
 * */

import { defineComponent, ref } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem, { CommBusinessDialog } from '@/components/businessDialogItem';
import { ElMessage } from 'element-plus';
import { goToFormCreate } from '@/pages/commonPage';

export default defineComponent({
  name: 'form-module-business-authBrandSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '编号',
        key: 'brandPlatformNo',
        type: InputType.text
      },
      {
        label: '平台品牌名称',
        key: 'name',
        type: InputType.text
      },
      {
        label: '创建人',
        key: 'createdName',
        type: InputType.text
      },
      {
        label: '创建时间',
        key: 'createdAt',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'createdStartAt',
          endKey: 'createdEnAt'
        }
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/brand/platform/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'brandPlatformNo'
            },
            {
              label: '平台品牌名称',
              key: 'name'
            },
            {
              label: '创建人',
              key: 'createdName'
            },
            {
              type: 'formatter',
              label: '创建时间',
              key: 'createdAt',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            },
            {
              label: '备注',
              key: 'remark'
            }
          ],
          actions: []
        }
      ]
    };

    const dialog = ref<CommBusinessDialog | null>(null);
    const toAddBrand = () => {
      dialog.value?.closeWindow();
      goToFormCreate('ca4d2197f97b47bc811d7b524ef80ca2');
    };
    return () => {
      return (
        <business-dialog-item
          ref={dialog}
          {...attrs}
          tableConfig={tableConfig}
          nameKey="name"
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
          v-slots={{
            preButton: () => {
              return <el-button onClick={toAddBrand}>新增</el-button>;
            }
          }}
        />
      );
    };
  }
});
