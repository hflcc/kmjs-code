/**
 * 添加类目费用
 * */

import { defineComponent } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import businessDialogItem from '@/components/businessDialogItem';
import { TableConfig } from '@/components/table/kmjsTableType';

interface BizMdOrgCascade {
  orgTreeSn: string;
  orgTreeFrameworkResponses: Array<{ orgTreeName: string }>;
}
interface BizMdContractDefOrgDeductResponse {
  sn: string;
  downRange: number;
  initRateAmount: number;
  upRange: number;
  required: boolean;
  contractDeductDefResponse: {
    sn: string;
    name: string;
    serialCode: string;
    type: string;
    formula: string;
  };
}

interface BusinessData {
  bizMdOrgCascadeResponse: BizMdOrgCascade;
  bizMdContractDefOrgDeductResponse: BizMdContractDefOrgDeductResponse;
}

export default defineComponent({
  name: 'form-module-business-categoryDeductSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit, attrs }) {
    const dataFormatter = (tableData: BusinessData[]) => {
      return tableData.map((item) => {
        return {
          sn: item.bizMdContractDefOrgDeductResponse.contractDeductDefResponse.sn,
          relationSn: item.bizMdContractDefOrgDeductResponse.sn,
          initRateAmount: item.bizMdContractDefOrgDeductResponse.initRateAmount,
          upRange: item.bizMdContractDefOrgDeductResponse.upRange,
          downRange: item.bizMdContractDefOrgDeductResponse.downRange,
          serialCode: item.bizMdContractDefOrgDeductResponse.contractDeductDefResponse.serialCode,
          name: item.bizMdContractDefOrgDeductResponse.contractDeductDefResponse.name,
          type: item.bizMdContractDefOrgDeductResponse.contractDeductDefResponse.type,
          formula: item.bizMdContractDefOrgDeductResponse.contractDeductDefResponse.formula,
          orgTreeSn: item.bizMdOrgCascadeResponse.orgTreeSn,
          required: item.bizMdContractDefOrgDeductResponse.required,
          orgTreeName: item.bizMdOrgCascadeResponse.orgTreeFrameworkResponses
            .map((s) => s.orgTreeName)
            .join('>')
        };
      });
    };

    const inputs = [
      {
        label: '类目',
        key: 'orgTreeName',
        type: InputType.text
      }
    ];
    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/contract/def/flat/orgTree/page/deduct/{defSn}',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'serialCode'
            },
            {
              label: '名称',
              key: 'name'
            },
            {
              label: '类目',
              key: 'orgTreeName'
            },
            {
              label: '类型',
              key: 'type',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'deduct_def_type'
              }
            }
          ],
          actions: []
        }
      ]
    };

    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          dataFormatter={dataFormatter}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
