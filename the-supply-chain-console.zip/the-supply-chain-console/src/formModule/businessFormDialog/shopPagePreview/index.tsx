import { defineComponent, PropType, reactive, ref } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { useDialog } from '@/utils';
import PreviewCategory from '@/pages/shopManage/components/previewCategory.vue';

type PreviewType = 'INFO_FLOW' | 'GOODS_CATEGORY';
interface RenderData {
  pageType: PreviewType;
  pageValue: string;
}

export default defineComponent({
  name: 'form-module-business-shopPagePreview',
  components: {
    businessDialogItem,
    PreviewCategory
  },
  emits: ['closeDialog', 'update:modelValue'],
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<RenderData>,
      required: true
    }
  },
  setup(props, { emit }) {
    const showPreview = ref<boolean>(false);
    const pageValue = ref<string>('');
    
    const { showDialog, closeWindow } = useDialog(props, emit, (v) => {
      if (v) {
        if (props.renderData.pageType === 'INFO_FLOW') {
          closeWindow();
          window.open(`https://info-flow-dev.kmyun.cn/?infoFlowSn=${props.renderData.pageValue}`);
        } else if (props.renderData.pageType === 'GOODS_CATEGORY') {
          pageValue.value = props.renderData.pageValue;
          showPreview.value = showDialog.value;
        }
      }
    });

    return () => (
      // 预览店铺装修分类
      <preview-category v-model={showPreview.value} onHide={closeWindow} defSn={pageValue.value} />
    );
  }
});
