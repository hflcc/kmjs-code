import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { TableConfig } from '@/components/table/kmjsTableType';
import { FormItem, InputType } from '@/components/form/type';

export default defineComponent({
  name: 'form-module-business-supplierSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs: FormItem[] = [
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '编号',
        key: 'serialCode',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '供应商名称',
        key: 'name',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      // {
      //   label: '审核状态',
      //   key: 'auditState',
      //   type: InputType.select,
      //   dictionaryName: 'supplier_audit_state'
      // },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      // {
      //   label: '状态',
      //   key: 'state',
      //   type: InputType.select,
      //   dictionaryName: 'supplier_state'
      // },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      // {
      //   label: '销售方式',
      //   key: 'saleType',
      //   type: InputType.select,
      //   dictionaryName: 'sale_type'
      // },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '法定代表人/负责人',
        key: 'companyLegalName',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '创建人',
        key: 'createdByName',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '创建时间',
        key: 'daterange',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'startAt',
          endKey: 'endAt'
        }
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/supplier/instance/page?auditState=accept',
      items: [
        {
          type: 'search',
          inputs: inputs
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'serialCode',
              width: 150
            },
            {
              label: '供应商名称',
              key: 'name',
              width: 200
            },
            {
              label: '审核状态',
              key: 'auditState',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'supplier_audit_state'
              }
            },
            {
              label: '状态',
              key: 'state',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'supplier_state'
              }
            },
            {
              label: '销售方式',
              key: 'saleType',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'sale_type'
              }
            },
            {
              label: '法定代表人/负责人',
              key: 'companyLegalName'
            },
            {
              label: '联系电话',
              key: 'companyLegalPhone'
            },
            {
              label: '平台',
              key: 'bizMdTypeInstName'
            },
            {
              label: '创建人',
              key: 'createdByName'
            },
            {
              label: '创建时间',
              key: 'createdAt',
              type: 'formatter',
              params: {
                formatter: 'dateTime',
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
