import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';

export default defineComponent({
  name: 'form-module-business-totalAgentSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/agent/main/instance/page/{parentId}',
      items: [
        {
          type: 'table',
          tableSelectMode: 'single',
          tableHead: [
            {
              label: '总代名称',
              key: 'name'
            },
            {
              type: 'mapText',
              label: '审核状态',
              key: 'auditState',
              params: {
                type: 'dictionary',
                dictionaryName: 'audit_state'
              }
            },
            {
              type: 'mapText',
              label: '销售方式',
              key: 'saleType',
              params: {
                type: 'dictionary',
                dictionaryName: 'sale_type'
              }
            },
            {
              label: '法定代表人/负责人',
              key: 'companyLegalName'
            },
            {
              label: '联系电话',
              key: 'companyLegalPhone'
            },
            {
              label: '平台',
              key: 'bizMdTypeInstName'
            },
            {
              label: '创建人',
              key: 'createByName'
            },
            {
              type: 'formatter',
              label: '创建时间',
              key: 'createdAt',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
