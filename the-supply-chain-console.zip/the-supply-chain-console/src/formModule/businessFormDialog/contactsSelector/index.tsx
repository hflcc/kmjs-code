/**
 * 选择联系人
 * */

import { defineComponent } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem from '@/components/businessDialogItem';

export default defineComponent({
  name: 'form-module-business-contactsSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '姓名',
        key: 'name'
      },
      {
        label: '电话号码',
        key: 'phone'
      },
      {
        label: '职位',
        key: 'job',
        type: 'select',
        dictionaryName: 'contact_job'
      },
      {
        label: '创建人',
        key: 'createdByName'
      },
      {
        label: '创建时间',
        key: 'tempCreatedAt',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'startAt',
          endKey: 'endAt'
        }
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/person/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '姓名',
              key: 'name'
            },
            {
              label: '电话号码',
              key: 'phone'
            },
            {
              label: '职位',
              key: 'job',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'contact_job'
              }
            },
            {
              label: '创建人',
              key: 'createdByName'
            },
            {
              type: 'formatter',
              label: '创建时间',
              key: 'createdAt',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ],
          actions: []
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
