/**
 * 选择商品
 * */
import { defineComponent, PropType } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormItem, InputType } from '@/components/form/type';

export default defineComponent({
  // name: 'form-module-business-brandSupplierSelector',
  name: 'form-module-business-goodsSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const dataFormatter = (tableData: any[]) => {
      tableData.forEach((item) => {
        item.retailPrice = `${item.minRetailPrice.toFixed(2)} ~ ${item.maxRetailPrice.toFixed(2)}`;
        // item.mPrice = `${item.minPrice} ~ ${item.maxPrice}`;
        item.step_prices = item.mixStepPrices;
      });
      return tableData;
    };

    const inputs = [
      {
        label: '品牌',
        key: 'brand',
        type: InputType.text
      },
      {
        label: '商品名称',
        key: 'name',
        type: InputType.text
      }
    ];
    const tableConfig = {
      tableDataUrl: '/auth/md/goods/page/contract/${bizMdContractInstanceSn}',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '品牌',
              key: 'brandName'
            },
            {
              label: '商品名称',
              key: 'name'
            },
            {
              type: 'image',
              label: '图片',
              key: 'cover',
              width: 80,
              params: {
                width: '60px'
              }
            },
            {
              label: '建议零售价(元)',
              key: 'retailPrice',
              width: 150,
              align: 'right'
              // formatter: 'price'
            },
            {
              label: '零售价(元)',
              key: 'price',
              width: 150,
              align: 'right'
              // formatter: 'price'
            },
            {
              label: '面价(元)',
              key: 'price',
              width: 150,
              align: 'right'
              // formatter: 'price'
            },
            {
              label: '拿货价(元)',
              key: 'costPrice',
              width: 120,
              align: 'right',
              formatter: 'price'
            },
            {
              label: '服务结算价(元)',
              key: 'serviceFee',
              width: 120,
              align: 'right',
              formatter: 'price'
            },
            {
              label: '阶梯售价(元)',
              key: 'mixStepPrices',
              width: 200,
              type: 'skuStepPriceInfo'
            },
            {
              label: '备注',
              key: 'desc',
              width: 200
            }
          ],
          actions: []
        }
      ]
    };
    console.log(attrs);
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          dataFormatter={dataFormatter}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
