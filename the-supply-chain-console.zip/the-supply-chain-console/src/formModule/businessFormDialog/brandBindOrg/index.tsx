/**
 * 添加客服
 * */

import { defineComponent, PropType, ref } from 'vue';
import { TableConfig } from '@/components/table/kmjsTableType';
import { useDialog } from '@/utils';
import kmjsModule, { ModuleCtl, useModule } from '@/components/modules/module/code';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'form-module-business-brandBindOrg',
  components: {
    kmjsModule
  },
  props: {
    // 是否显示弹窗
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 配置项
    params: {
      type: Object as PropType<ResSteButtons>,
      required: true
    },
    // 外部表格数据的主key集合
    tableData: {
      type: Object as PropType<{
        snKey: string;
        snArr: string[];
        tableData: Array<Record<string, any>>;
        formToBusinessKeyMapping: Record<string, string>;
      }>,
      required: true
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 部分业务接口请求，根据不同的场景，有一个默认的入参数，在这里提供，需加入请求接口中
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    },
    // 表格的配置文件
    tableConfig: {
      type: Object as PropType<TableConfig>,
      required: true
    },
    // 显示已选中的name的业务数据key
    nameKey: {
      type: String as PropType<string>,
      default: 'name'
    }
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit }) {
    const store = useStore();
    // 渲染表单的配置
    const moduleCtl = ref<ModuleCtl | null>(null);
    const methods = ref<{ [moduleName: string]: (...argus: any) => any } | null>(null);
    // 每次展示的时候渲染表单
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        const [ctl, med] = useModule({
          config: [
            {
              type: 'form',
              name: 'brand-form',
              params: {
                parentConfig: {
                  labelWidth: '120px',
                  labelPosition: 'right',
                  showBtn: false
                },
                itemData: [
                  {
                    label: '编号',
                    type: 'text',
                    disabled: true,
                    validNames: ['required'],
                    key: 'brandNo'
                  },
                  {
                    label: '品牌名称',
                    type: 'text',
                    disabled: true,
                    validNames: ['required'],
                    key: 'brandName'
                  },
                  {
                    label: '认证品牌',
                    type: 'authBrandSelector',
                    key: 'brandSupplier',
                    defaultValue: '',
                    validNames: ['required'],
                    renderConfig: {
                      title: '认证品牌'
                    }
                  },
                  {
                    label: '设置组织',
                    type: 'setOrgSelector',
                    key: 'orgTree',
                    defaultValue: '',
                    validNames: ['required']
                  }
                ]
              }
            }
          ],
          handler: (moduleName, name, data) => {
            if (name === '$ready') {
              const data = props.renderData;
              med['/brand-form/setData']({
                brandSupplier: {
                  sn: data.brandPlatformSn,
                  name: data.brandPlatformName
                },
                orgTree: {
                  sn: data.orgTreeSns,
                  name: data.orgTreeNames
                },
                brandNo: data.brandNo,
                brandName: data.brandName
              });
            }
          }
        });
        moduleCtl.value = ctl;
        methods.value = med;
      } else {
        moduleCtl.value = null;
      }
    });

    const getData = async () => {
      const userMsg = store.getters['user/userMsg'];
      const organ = store.getters['organization/activeOrgan'];
      const data = await methods.value?.['/brand-form/getData']();
      const l = {
        brandNo: data.brandNo,
        brandName: data.brandName,
        brandPlatformSn: data['brandSupplier'].sn,
        brandPlatformName: data['brandSupplier'].name,
        orgTreeSns: data['orgTree'].sn,
        orgTreeNames: data['orgTree'].name,
        authenticate_name: userMsg.name, // 认证人
        instId: organ.id, // 认证人机构id
        authenticate_time: Math.round(new Date().getTime() / 1000), // 认证时间
        userId: userMsg.userId, // 分配用户userId
        assign_name: userMsg.name,
        assign_time: Math.round(new Date().getTime() / 1000)
      };
      emit('getValue', [l]);
      closeWindow();
    };
    return {
      showDialog,
      closeWindow,
      getData,
      moduleCtl
    };
  },
  render() {
    const { params, showDialog, closeWindow, getData, moduleCtl } = this;
    const formMdule = moduleCtl ? <kmjsModule ctl={moduleCtl}></kmjsModule> : null;
    return (
      <el-dialog
        width={'700px'}
        v-model={showDialog}
        onClose={closeWindow}
        title={params.name}
        top={'30vh'}
        v-slots={{
          footer: () => {
            return (
              <el-space>
                <el-button onClick={closeWindow}>取消</el-button>
                <el-button type={'primary'} onClick={getData}>
                  确认
                </el-button>
              </el-space>
            );
          }
        }}
      >
        <div>{formMdule}</div>
      </el-dialog>
    );
  }
});
