/**
 * 添加客服
 * */

import { defineComponent } from 'vue';
import { TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem from '@/components/businessDialogItem';

export default defineComponent({
  name: 'form-module-business-attendorSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/mk/csc/attendor/page',
      items: [
        {
          type: 'table',
          tableHead: [
            {
              label: '头像',
              type: 'image',
              key: 'avatar',
              width: 60
            },
            {
              label: '客服昵称',
              key: 'nickname'
            },
            {
              label: '用户名',
              key: 'name'
            },
            {
              label: '所在机构',
              key: 'bizMdInstUserInstName'
            }
          ],
          actions: []
        }
      ]
    };

    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
