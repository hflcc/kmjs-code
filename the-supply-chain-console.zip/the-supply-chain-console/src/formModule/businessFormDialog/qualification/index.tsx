/**
 * 选择证件
 * */

import { defineComponent, PropType } from 'vue';
import { TableConfig } from '@/components/table/kmjsTableType';
import { FormItem, InputType } from '@/components/form/type';
import businessDialogItem from '@/components/businessDialogItem';

export default defineComponent({
  name: 'form-module-business-qualificationSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  props: {
    // 请求接口所需要的数据
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    }
  },
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '编号',
        key: 'code',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '证件名称',
        key: 'qualificationDefName',
        type: InputType.text
      },
      {
        label: '证件编号',
        key: 'serialCode',
        type: InputType.text
      },
      {
        label: '创建人',
        key: 'createdByName'
      },
      {
        label: '创建时间',
        key: 'createdAt',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'startAt',
          endKey: 'endAt'
        }
      }
    ];
    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/qualification/instance/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              width: 100,
              key: 'code'
            },
            {
              label: '证件名称',
              key: 'qualificationDefName'
            },
            {
              label: '证件编号',
              key: 'serialCode'
            },
            {
              label: '审核状态',
              key: 'auditState',
              type: 'mapText',
              width: 80,
              params: {
                type: 'dictionary',
                dictionaryName: 'qualification_audit_state'
              }
            },
            {
              label: '状态',
              key: 'state',
              type: 'mapText',
              width: 80,
              params: {
                type: 'dictionary',
                dictionaryName: 'qualification_state'
              }
            },
            {
              label: '证件类型',
              key: 'category',
              type: 'mapText',
              width: 140,
              params: {
                type: 'dictionary',
                dictionaryName: 'qualification_instance_category'
              }
            },

            {
              type: 'fileListView',
              label: '附件',
              key: 'attaches'
            },
            {
              label: '创建人',
              key: 'createdByName'
            },
            {
              label: '创建时间',
              key: 'createdAt',
              type: 'formatter',
              params: {
                formatter: 'dateTime',
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          requestData={props.requestData}
          nameKey="qualificationDefName"
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
