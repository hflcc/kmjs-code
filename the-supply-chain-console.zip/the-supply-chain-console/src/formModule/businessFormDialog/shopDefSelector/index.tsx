/**
 * 选择店铺
 * */
import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';

interface BusinessData {
  bizMdShopDefResponse: {
    sn: string;
    name: string;
    description: string;
  };
  sn: string;
  bizMdShopDefSn: string;
  required: boolean;
}

export default defineComponent({
  name: 'form-module-business-shopDefSelector',
  components: {
    businessDialogItem
  },
  props: {},
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const dataFormatter = (tableData: BusinessData[]) => {
      return tableData.map((item) => {
        return {
          ...item.bizMdShopDefResponse,
          relationSn: item.sn,
          bizMdShopDefSn: item.bizMdShopDefSn,
          required: item.required
        };
      });
    };

    const tableConfig = {
      tableDataUrl: '/auth/md/contract/def/page/shopDef/{defSn}',
      items: [
        {
          type: 'table',
          tableHead: [
            {
              label: '类型',
              key: 'name'
            },
            {
              label: '店铺说明',
              key: 'description'
            }
          ],
          actions: []
        }
      ]
    };
    console.log(attrs);
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          dataFormatter={dataFormatter}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
