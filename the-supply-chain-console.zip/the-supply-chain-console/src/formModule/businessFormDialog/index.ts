import { App } from 'vue';

const installFormModuleComponents = (app: App): void => {
  const req = require.context('@/formModule/businessFormDialog', true, /index.vue|index.tsx$/);
  req.keys().forEach((item) => {
    const com = req(item).default;
    app.component(com.name, com);
  });
};
export default installFormModuleComponents;
