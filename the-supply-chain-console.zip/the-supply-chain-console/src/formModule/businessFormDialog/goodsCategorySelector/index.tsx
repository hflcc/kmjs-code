/**
 * 商品入驻单编辑
 * */
import { defineComponent, PropType, reactive, ref, toRefs, watch } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { useDialog } from '@/utils';
import type { ElForm } from 'element-plus';
import { Category, DeductDef, getContractDeduct } from '../brandCategoryPriceSelector/api';
// import './index.less';

interface PricingValue {
  sn: string;
  value: number | string;
}

interface SelectData {
  name: string;
  id: string;
  sn: string;
}

interface RenderDataCategory {
  name: string;
  sn: string;
  value: RenderDataCategory[];
}

export default defineComponent({
  // name: 'form-module-business-brandCategoryPriceSelector',
  name: 'form-module-business-goodsCategorySelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 请求接口所需要的数据
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    },
    renderData: {
      type: Object as PropType<{
        category: RenderDataCategory[];
        categorySn: string;
        contractDefSn: string;
        orgSn: string;
        pricingValue: PricingValue[];
      }>,
      required: true
    },
    // 外部表格数据
    tableData: {
      type: Object as PropType<{
        snKey: string;
        snArr: string[];
        tableData: Array<Record<string, any>>;
        formToBusinessKeyMapping: Record<string, string>;
      }>,
      required: true
    }
  },
  setup(props, { emit }) {
    const { closeWindow } = useDialog(props, emit);
    const costList = reactive<DeductDef[]>([]); //费用
    // const priceList = ref<DeductDef[]>([]); //定价
    const formRef = ref<InstanceType<typeof ElForm>>();
    const form = ref({
      instance_org_sn: '',
      remark: ''
    });
    const categorys = ref<any[]>([]);
    const rules = {
      instance_org_sn: { required: true, message: '请选择入驻类目', trigger: 'change' }
    };
    // let orgSn = '';
    let sn = '';
    // 分类下拉的数据
    const categoryList = ref<{ [parentId: string]: Category[] }>({});
    const selectData = ref<SelectData[]>([]);
    // const currentSelectCategoryIndex = ref(0);
    const confirm = () => {
      formRef.value?.validate((valid) => {
        if (valid) {
          // const pricing = '';
          let cost = '';
          // const pricingValue: PricingValue[] = [];
          // priceList.value.forEach((item) => {
          //   pricing += `${item.contractDeductDefResponse.name}：${item.initRateAmount}` + '\n';
          //   pricingValue.push({
          //     sn: item.sn,
          //     value: item.initRateAmount
          //   });
          // });
          costList.forEach((item) => {
            cost += `${item.contractDeductDefResponse.name}：${item.initRateAmount}` + '\n';
          });
          const selectData = categorys.value.filter((item) => item.selectData);
          emit('getValue', [
            {
              categoryName: selectData.map((item: any) => item.selectData.name).join('/'),
              categorySn: selectData[selectData.length - 1].selectData.sn, //最后一级类目sn
              // pricing_items: pricing,
              cost_items: cost,
              remark: form.value.remark,
              costValue: costList.map((item) => {
                return {
                  serialCode: item.contractDeductDefResponse.serialCode,
                  name: item.contractDeductDefResponse.name,
                  categoryName: item.categoryName,
                  fee: item.fee
                };
              })
              // pricingValue: pricingValue //定价列表
            }
          ]);
        } else {
          return false;
        }
      });
    };
    // 获取类目
    const changeParent = (
      data: RenderDataCategory,
      idx: number,
      defaultCategory?: RenderDataCategory[]
    ) => {
      if (!defaultCategory) getOtherInfo(data.sn);
      form.value.instance_org_sn = data.sn;
      if (idx >= 2) {
        return;
      }
      categorys.value.splice(idx + 1, idx === 0 ? 2 : 1);
      let list: RenderDataCategory[] = [];
      //获取下级类目
      if (props.renderData.category) {
        props.renderData.category.forEach((item) => {
          if (item.value[idx] && item.value[idx].sn === data.sn) {
            if (item.value.length > idx + 1) list.push(item.value[idx + 1]);
          }
        });
      }
      if (list.length === 0) return;
      //过滤重复类目
      list = list.reduce((item: any, next: any) => {
        typeof item.find((ele: any) => ele['sn'] === next['sn']) === 'undefined' && item.push(next);
        return item;
      }, []);
      if (categorys.value.length !== 0) {
        categorys.value[idx + 1] = {
          sn: '',
          value: list,
          selectData: defaultCategory ? defaultCategory[idx + 1] : undefined
        };
      } else {
        categorys.value.push({
          sn: '',
          value: list,
          selectData: defaultCategory ? defaultCategory[idx + 1] : undefined
        });
      }
    };
    // 获取其它信息
    const getOtherInfo = (orgTreeSn: string) => {
      getContractDeduct(sn, orgTreeSn).then((res) => {
        costList.length = 0;
        // priceList.value = [];
        const categoryName = categorys.value
          .filter((item) => item.selectData)
          .map((item) => item.selectData.name)
          .join('/');
        costList.push(
          ...res
            .filter(
              (item) =>
                item.contractDeductDefResponse.scope === 'sale_buy_goods_assigned' &&
                item.contractDeductDefResponse.type === 'cost'
            )
            .map((item) => {
              return {
                ...item,
                initRateAmount: `${item.initRateAmount}${
                  item.contractDeductDefResponse.formula === 'amount' ? '元' : '%'
                }`,
                fee: item.initRateAmount,
                categoryName
              };
            })
        );
        // console.log(costList);
      });
    };
    const initCategory = (index: number, defaultCategory?: RenderDataCategory[]) => {
      const list: RenderDataCategory[] = [
        {
          name: '',
          sn: '',
          value: []
        }
      ];
      props.renderData.category.forEach((item) => {
        list[0].value.push(item.value[index]);
      });
      // // 过滤相同sn的分类
      const categoryList: any = [];
      list.forEach((item) => {
        const result = item.value.reduce((item: any, next: any) => {
          typeof item.find((ele: any) => ele['sn'] === next['sn']) === 'undefined' &&
            item.push(next);
          return item;
        }, []);
        categoryList.push({
          sn: '',
          value: result,
          selectData: defaultCategory ? defaultCategory[index] : undefined
        });
      });
      return categoryList;
    };
    watch(
      () => props.modelValue,
      (val) => {
        categorys.value = [];
        if (val) {
          let defaultCategory: RenderDataCategory[] = []; //已保存的值
          if (props.renderData.category) {
            props.renderData.category.forEach((item) => {
              item.value.forEach((categoryItem, idx: number) => {
                if (categoryItem.sn === props.renderData.categorySn) {
                  defaultCategory = item.value.slice(0, idx + 1);
                }
              });
            });
          }
          // orgSn = props.renderData.orgSn;
          sn = props.renderData.contractDefSn;
          //再次编辑
          if (props.renderData.categorySn) {
            categorys.value.push(...initCategory(0, defaultCategory));
            defaultCategory.forEach((item, index) => {
              changeParent(item, index, defaultCategory);
              // categorys.value.push(...initCategory(index, defaultCategory));
            });
            getOtherInfo(props.renderData.categorySn);
          } else {
            categorys.value.push(...initCategory(0));
          }
        } else {
          categoryList.value = {};
          selectData.value = [];
          costList.length = 0;
          // priceList.value = [];
          form.value.instance_org_sn = '';
        }
      }
    );
    return {
      form,
      formRef,
      rules,
      selectData,
      categoryList,
      costList,
      categorys,
      closeWindow,
      confirm,
      changeParent
    };
  },
  render() {
    const { $props, confirm, form, closeWindow, changeParent, rules, costList, categorys } = this;
    return (
      <el-dialog
        v-model={$props.modelValue}
        title="设置"
        width="780px"
        onClosed={closeWindow}
        v-slots={{
          footer: () => (
            <span class="dialog-footer">
              <el-button onClick={closeWindow}>取消</el-button>
              <el-button type="primary" onClick={() => confirm()}>
                确认
              </el-button>
            </span>
          )
        }}
      >
        <el-form model={form} ref="formRef" rules={rules} label-width="90px" size="medium">
          <el-form-item label="入驻类目" prop="instance_org_sn">
            <div>
              {categorys.map((item: any, idx: number) => {
                return (
                  <div class="inline_block">
                    {
                      <el-select
                        style={{ marginRight: '12px' }}
                        placeholder="请选择类目"
                        v-model={item.selectData}
                        value-key="sn"
                        onChange={(val: RenderDataCategory) => {
                          changeParent(val, idx);
                        }}
                      >
                        {item.value.map((k: RenderDataCategory, i: number) => {
                          return <el-option key={k} label={k.name} value={k} />;
                        })}
                      </el-select>
                    }
                  </div>
                );
              })}
            </div>
          </el-form-item>
          <el-form-item label="费用">
            <el-table
              data={costList}
              header-cell-style={{ padding: '0px' }}
              style={{ border: '1px solid #dedede' }}
              height="200px"
            >
              <el-table-column type="index" label="序号" width="50" />
              <el-table-column prop="contractDeductDefResponse.name" label="名称" />
              <el-table-column prop="categoryName" label="类目" />
              <el-table-column prop="initRateAmount" label="金额(元)/比例(%)" />
            </el-table>
          </el-form-item>
          <el-form-item label="备注" prop="remark">
            <el-input type="textarea" rows={5} v-model={form.remark} />
          </el-form-item>
        </el-form>
      </el-dialog>
    );
  }
});
