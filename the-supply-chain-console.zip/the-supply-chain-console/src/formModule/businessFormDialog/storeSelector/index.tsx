/**
 * 选择门店
 * */
import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormatterType } from '@/components/table/kmjsTableType';
import { FormItem, InputType } from '@/components/form/type';

export default defineComponent({
  name: 'form-module-business-storeSelector',
  components: {
    businessDialogItem
  },
  props: {},
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs: FormItem[] = [
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '门店名称',
        key: 'qualificationDefName',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '联系电话',
        key: 'qualificationDefName',
        type: InputType.text
      }
    ];
    const tableConfig = {
      // TODO 接口地址，表格参数需要改
      tableDataUrl: '/auth/md/qualification/instance/page',
      items: [
        {
          type: 'search',
          inputs: inputs
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'qualificationDefName'
            },
            {
              label: '门店名称',
              key: 'serialCode'
            },
            {
              type: 'mapText',
              label: '审核状态',
              key: 'auditState',
              params: {
                type: 'dictionary',
                dictionaryName: 'audit_state'
              }
            },
            {
              label: '工商主体名称',
              key: 'serialCode'
            },
            {
              label: '老板名称',
              key: 'serialCode'
            },
            {
              label: '联系电话',
              key: 'companyLegalPhone'
            },
            {
              label: '平台',
              key: 'platformName'
            },
            {
              label: '创建人',
              key: 'createByName'
            },
            {
              type: 'formatter',
              label: '创建时间',
              key: 'createdAt',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ],
          actions: []
        }
      ]
    };
    console.log(attrs);
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
