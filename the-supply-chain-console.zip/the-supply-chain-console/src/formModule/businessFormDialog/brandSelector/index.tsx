import { defineComponent } from 'vue';
import businessDialogItem from '@/components/businessDialogItem';
import { FormItem, InputType } from '@/components/form/type';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';

export default defineComponent({
  name: 'form-module-business-brandSupplierSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs: FormItem[] = [
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '编号',
        key: 'brandOn',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '品牌名称',
        key: 'brandName',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '品牌类型',
        key: 'brandType',
        type: InputType.select,
        dictionaryName: 'brand_type'
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '创建人',
        key: 'createdName',
        type: InputType.text
      },
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '创建时间',
        key: 'daterange',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'startAt',
          endKey: 'endAt'
        }
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/brand/supplier/page',
      items: [
        {
          type: 'search',
          inputs: inputs
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'brandOn',
              width: 150
            },
            {
              label: '品牌名称',
              key: 'brandName'
            },
            {
              label: '品牌类型',
              key: 'brandType',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'brand_type'
              }
            },
            {
              label: '品牌商标',
              key: 'brandIoc',
              type: 'image',
              params: {
                width: '80px'
              }
            },
            {
              label: '有效时间',
              key: 'expiredType',
              type: 'expiredDate',
              width: 200,
              params: {
                startKey: 'expiredStartAt',
                endKey: 'expiredEndAt'
              }
            },
            {
              label: '供应商',
              key: 'bizMdSupplierName'
            },
            {
              label: '创建人',
              key: 'createdName'
            },
            {
              label: '创建时间',
              key: 'createdAt',
              type: 'formatter',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ]
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          nameKey="brandName"
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
