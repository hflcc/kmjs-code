/**
 * 选择银行账号
 * */

import { defineComponent } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import { FormatterType, TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem from '@/components/businessDialogItem';

export default defineComponent({
  name: 'form-module-business-openAccountSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const inputs = [
      {
        label: '编号',
        key: 'code',
        type: InputType.text
      },
      {
        label: '银行账户名称',
        key: 'accountName',
        type: InputType.text
      },
      {
        label: '公司银行帐号',
        key: 'accountCard',
        type: InputType.text
      },
      {
        label: '开户银行名',
        key: 'name',
        type: InputType.text
      },
      {
        label: '创建人',
        key: 'createdByName',
        type: InputType.text
      },
      {
        label: '创建时间',
        key: 'createdAt',
        type: InputType.daterange,
        dateConfig: {
          startKey: 'startAt',
          endKey: 'endAt'
        }
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/bank/page',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'code'
            },
            {
              label: '银行账户名称',
              key: 'accountName'
            },
            {
              label: '公司银行帐号',
              key: 'accountCard',
              width: 180
            },
            {
              label: '开户银行名',
              key: 'name'
            },
            {
              label: '账户类型',
              key: 'type',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'open_account_type'
              }
            },
            {
              label: '核准号',
              key: 'permitNumber',
              width: 180
            },
            {
              label: '开户行所在地',
              key: 'areaSn',
              type: 'area'
            },
            {
              label: '开户银行支行名称',
              key: 'branchName',
              width: 250
            },
            {
              label: '创建人',
              key: 'createdByName'
            },
            {
              type: 'formatter',
              label: '创建时间',
              key: 'createdAt',
              params: {
                formatter: FormatterType.dateTime,
                formatterType: 'YYYY-MM-DD HH:mm:ss'
              }
            }
          ],
          actions: []
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          nameKey="accountName"
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
