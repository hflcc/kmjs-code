import ajax from '@/utils/axios';

export interface Category {
  level: number;
  orgId: number;
  orgSn: string;
  orgTreeId: number;
  orgTreeName: string;
  orgTreeSn: string;
  parentId: number;
  parentSn: string;
  superId: number;
  superSn: string;
}

export interface DeductDef {
  sn: string;
  contractDeductDefResponse: {
    sn: string;
    name: string;
    cycle: 'once' | 'every' | 'week' | 'month' | 'quarter' | 'year' | 'custom';
    type: string;
    formula: 'rate' | 'amount'; // 百分比，金额
    serialCode: string;
  };
  initRateAmount: number;
  upRate: number;
  downRate: number;
  downRange: number;
  upRange: number;
  required: boolean;
  categoryName?: string;
}

export interface QualificationDef {
  sn: string;
  required: boolean;
  qualificationDefResponse: { sn: string; nameType: string; name: string; ossId: string };
}

// 合同定义-经营类目-下拉列表
export const getContractDef = (
  sn: string,
  orgSn: string,
  query: { level?: number; parentId?: number }
): Promise<Category[]> => {
  return ajax.get<null, Category[]>(`/auth/md/contract/def/orgTree/${sn}/${orgSn}`, {
    params: {
      ...query,
      $InstId: true,
      $noLoad: true
    }
  });
};
// 合同定义-经营类目-下拉列表-所需条款
export const getContractDeduct = (sn: string, orgTreeSn: string): Promise<DeductDef[]> => {
  return ajax.get<null, DeductDef[]>(`/auth/md/contract/def/org/deduct/${sn}/${orgTreeSn}`, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};
// 合同定义-经营类目-下拉列表-所需证件
export const getContractQualificationDef = (
  sn: string,
  orgTreeSn: string
): Promise<QualificationDef[]> => {
  return ajax.get<null, QualificationDef[]>(
    `/auth/md/contract/def/org/qualificationDef/${sn}/${orgTreeSn}`,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};
