/**
 * 添加类目
 * */

import { defineComponent, inject, PropType, reactive, ref, toRefs } from 'vue';
import { useDialog, useRequestParams } from '@/utils/hooks';
import kmjsModule from '@/components/modules/module/code';
import FormItemCategory from '@/formModule/formItems/category';
import './style.less';
import {
  Category,
  DeductDef,
  getContractDeduct,
  getContractDef,
  getContractQualificationDef,
  QualificationDef
} from './api';
import { ElMessage } from 'element-plus';
import { getCanPreview, math } from '@/utils';
import { getFileUrlBySeq } from '@/utils/commApi';

export default defineComponent({
  name: 'form-module-business-categorySelector',
  props: {
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    params: {
      //sn: 合同定义sn
      //orgSn: 组织sn经营类目sn
      type: Object as PropType<ResSteButtons>,
      required: true
    },
    // 外部表格数据的主key集合
    tableData: {
      type: Object as PropType<{
        snKey: string;
        snArr: string[];
        tableData: Array<Record<string, any>>;
        formToBusinessKeyMapping: Record<string, string>;
      }>,
      required: true
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<Record<string, any>>,
      required: true
    },
    // 部分业务接口请求，根据不同的场景，有一个默认的入参数，在这里提供，需加入请求接口中
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    }
  },
  components: {
    kmjsModule,
    FormItemCategory
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit }) {
    const requestData = ref<Record<string, string>>({});
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        // 初始化值
        deductDef.value = [];
        qualificationDef.value = [];
        selectData.value = [{ name: '', sn: '', id: '' }];
        requestData.value = props.requestData;
        changeParent(1, 0);
      }
    });
    const getData = () => {
      const list = selectData.value.filter((k) => k.sn);
      if (list.length === 0) {
        ElMessage.warning('请选择类目');
        return;
      }
      const qualifications = qualificationDef.value.map((item) => {
        return {
          sn: item.qualificationDefResponse.sn,
          relationSn: item.sn,
          name: item.qualificationDefResponse.name,
          required: item.required
        };
      });
      const deducts = deductDef.value.map((item) => {
        return {
          sn: item.contractDeductDefResponse.sn,
          relationSn: item.sn,
          name: item.contractDeductDefResponse.name,
          type: item.contractDeductDefResponse.type,
          serialCode: item.contractDeductDefResponse.serialCode,
          formula: item.contractDeductDefResponse.formula,
          initRateAmount: item.initRateAmount,
          upRange: item.upRange,
          downRange: item.downRange,
          required: item.required
        };
      });
      const data = {
        orgTreeName: list.map((k) => k.name).join('>'),
        orgTreeSn: list[list.length - 1]?.sn,
        qualifications: qualifications,
        deducts: deducts
      };

      emit('getValue', [data]);
      closeWindow();
    };

    // 收费标准
    const deductDef = ref<DeductDef[]>([]);
    // 经营资质要求
    const qualificationDef = ref<QualificationDef[]>([]);
    // 获取其它信息
    const getOtherInfo = (orgTreeSn: string) => {
      getContractDeduct(requestData.value['defSn'], orgTreeSn).then((r) => {
        deductDef.value = r;
      });
      getContractQualificationDef(requestData.value['defSn'], orgTreeSn).then((r) => {
        qualificationDef.value = r;
      });
    };

    const dict = {
      none: '',
      custom: '',
      once: '/首次',
      every: '/每次',
      week: '/周',
      month: '/月',
      quarter: '/季',
      year: '/年'
    };

    // 分类下拉的数据
    const categoryList = ref<{ [parentId: string]: Category[] }>({});
    const selectData = ref<{ name: string; id: string; sn: string }[]>([
      { name: '', sn: '', id: '' }
    ]);

    // 更新数据
    const updateData = () => {
      if (selectData.value.length > 0) {
        const sn = selectData.value[selectData.value.length - 1].sn;
        if (sn) {
          getOtherInfo(sn);
        }
      }
    };

    // 获取类目
    const changeParent = (level: number, parentId: number) => {
      // 根据选中层级，改变已选择的数据
      const oldData = selectData.value.slice(0, level - 1);

      // 处理选中数据的name
      if (oldData.length > 0) {
        const lastData = oldData[oldData.length - 1];
        const key = 'parentId' + (level - 2 === 0 ? '' : selectData.value[level - 3].id);
        const list = categoryList.value[key];
        const o = list.find((item) => item.orgTreeId === Number(lastData.id));
        lastData.name = o?.orgTreeName || '';
        lastData.sn = o?.orgTreeSn || '';
      }
      selectData.value = [...oldData];

      // 判断对应数据 是否已经存在
      if (
        parentId > 0 &&
        Object.prototype.hasOwnProperty.call(categoryList.value, `parentId${parentId}`)
      ) {
        updateData();
        if (categoryList.value[`parentId${parentId}`].length > 0) {
          selectData.value.push({ name: '', sn: '', id: '' });
        }
        return;
      }

      getContractDef(requestData.value['defSn'], requestData.value['orgSn'], {
        level,
        parentId
      }).then((res) => {
        if (parentId === 0) {
          categoryList.value['parentId'] = res;
        } else {
          categoryList.value[`parentId${parentId}`] = res;
        }
        updateData();
        if (res.length > 0) {
          selectData.value.push({ name: '', sn: '', id: '' });
        }
      });
    };

    const showPreviewFile = ref(false);
    const previewFileData = ref<{ type: string; url?: string }[]>([]);
    const previewFile = (ossId: string) => {
      if (!ossId) {
        return ElMessage.warning('无可用示例');
      }
      getFileUrlBySeq(ossId).then((res) => {
        previewFileData.value = [{ type: 'image', url: res[ossId].url }];
        showPreviewFile.value = true;
      });
    };

    return {
      showDialog,
      closeWindow,
      getData,
      deductDef,
      qualificationDef,
      dict,
      selectData,
      changeParent,
      categoryList,
      previewFile,
      showPreviewFile,
      previewFileData
    };
  },
  render() {
    const { showDialog, closeWindow, getData, selectData, categoryList, params } = this;
    return (
      <el-dialog
        width={'60vw'}
        v-model={showDialog}
        onClose={closeWindow}
        title={params.title}
        v-slots={{
          footer: () => {
            return (
              <el-space>
                <el-button onClick={closeWindow}>取消</el-button>
                <el-button type={'primary'} onClick={getData}>
                  确认
                </el-button>
              </el-space>
            );
          }
        }}
      >
        <div class="form-row">
          <div class="form-label">
            <span style="color:red">*</span>类目：
          </div>
          <div>
            {selectData.map((item, idx) => {
              return (
                <el-select
                  style={{ marginRight: '12px' }}
                  v-model={item.id}
                  placeholder="请选择类目"
                  onChange={(val: number) => {
                    this.changeParent(idx + 2, val);
                  }}
                >
                  {categoryList['parentId' + (idx === 0 ? '' : selectData[idx - 1].id)]?.map(
                    (k) => {
                      return <el-option key={k.orgId} label={k.orgTreeName} value={k.orgTreeId} />;
                    }
                  )}
                </el-select>
              );
            })}
          </div>
        </div>

        <div class="form-row">
          <div class="form-label">收费标准：</div>
          <div>
            <div class="form-row-th">
              <div>收费类目</div>
              <div>收费详情</div>
            </div>
            {this.deductDef.map((item) => {
              return (
                <div class="form-row-tr">
                  <div>{item.contractDeductDefResponse?.name}</div>
                  <div>
                    {item.contractDeductDefResponse?.formula === 'rate'
                      ? math.accMul(item.initRateAmount, 100) + '%'
                      : item.initRateAmount + '元'}
                    {this.dict[item.contractDeductDefResponse?.cycle]}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div class="form-row">
          <div class="form-label">经营资质要求：</div>
          <div>
            <div class="form-row-th">
              <div>经营资质要求</div>
              <div>示例</div>
            </div>
            {this.qualificationDef.map((item) => {
              return (
                <div class="form-row-tr">
                  <div>{item.qualificationDefResponse.name}</div>
                  <div
                    style={{ color: 'blue', cursor: 'pointer' }}
                    onClick={() => this.previewFile(item.qualificationDefResponse.ossId)}
                  >
                    查看示例
                  </div>
                </div>
              );
            })}
          </div>
          <kmjs-preview-file v-model={this.showPreviewFile} data={this.previewFileData} />
        </div>
      </el-dialog>
    );
  }
});
