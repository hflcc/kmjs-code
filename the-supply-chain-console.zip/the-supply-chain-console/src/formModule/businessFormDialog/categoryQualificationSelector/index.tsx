/**
 * 添加类目费用
 * */

import { defineComponent } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import { TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem from '@/components/businessDialogItem';

interface BizMdOrgCascade {
  orgTreeSn: string;
  orgTreeFrameworkResponses: Array<{ orgTreeName: string }>;
}
interface BizMdContractDefOrgQualification {
  sn: string;
  required: boolean;
  qualificationDefResponse: {
    sn: string;
    name: string;
  };
}

interface BusinessData {
  bizMdOrgCascadeResponse: BizMdOrgCascade;
  bizMdContractDefOrgQualificationResponse: BizMdContractDefOrgQualification;
}

export default defineComponent({
  name: 'form-module-business-categoryQualificationSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { emit, attrs }) {
    const dataFormatter = (tableData: BusinessData[]) => {
      return tableData.map((item) => {
        return {
          sn: item.bizMdContractDefOrgQualificationResponse.qualificationDefResponse.sn,
          relationSn: item.bizMdContractDefOrgQualificationResponse.sn,
          required: item.bizMdContractDefOrgQualificationResponse.required,
          name: item.bizMdContractDefOrgQualificationResponse.qualificationDefResponse.name,
          orgTreeName: item.bizMdOrgCascadeResponse.orgTreeFrameworkResponses
            .map((s) => s.orgTreeName)
            .join('>'),
          orgTreeSn: item.bizMdOrgCascadeResponse.orgTreeSn
        };
      });
    };
    const inputs = [
      {
        label: '类目',
        key: 'orgTreeName',
        type: InputType.text
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/contract/def/flat/orgTree/page/qualification/{defSn}',
      items: [
        {
          type: 'search',
          inputs: inputs as FormItem[]
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '名称',
              key: 'name'
            },
            {
              label: '类目',
              key: 'orgTreeName'
            }
          ],
          actions: []
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          dataFormatter={dataFormatter}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
