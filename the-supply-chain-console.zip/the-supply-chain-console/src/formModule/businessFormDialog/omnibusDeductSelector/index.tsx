/**
 * 添加综合费用
 * */

import { defineComponent } from 'vue';
import { FormItem, InputType } from '@/components/form/type';
import { TableConfig } from '@/components/table/kmjsTableType';
import businessDialogItem from '@/components/businessDialogItem';

interface ContractDeductDef {
  sn: string;
  name: string;
  serialCode: string;
  scope: string;
  formula: string;
  source: string;
  quantity: string;
  type: string;
  cycle: string;
}

interface BusinessData {
  sn: string;
  downRange: number;
  initRateAmount: number;
  upRange: number;
  required: boolean;
  contractDeductDefResponse: ContractDeductDef;
}

export default defineComponent({
  name: 'form-module-business-omnibusDeductSelector',
  components: {
    businessDialogItem
  },
  emits: ['closeDialog', 'update:modelValue', 'getValue'],
  setup(props, { attrs, emit }) {
    const dataFormatter = (tableData: BusinessData[]) => {
      return tableData.map((item) => {
        return {
          ...item.contractDeductDefResponse,
          relationSn: item.sn,
          initRateAmount: item.initRateAmount,
          upRange: item.upRange,
          downRange: item.downRange,
          required: item.required,
          category: '综合服务类'
        };
      });
    };
    const inputs: FormItem[] = [
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      {
        label: '名称',
        key: 'contractDeductDefName',
        type: InputType.text
      }
    ];

    const tableConfig: TableConfig = {
      tableDataUrl: '/auth/md/contract/def/flat/page/deduct/{defSn}',
      items: [
        {
          type: 'search',
          inputs: inputs
        },
        {
          type: 'table',
          tableHead: [
            {
              label: '编号',
              key: 'serialCode'
            },
            {
              label: '名称',
              key: 'name'
            },
            {
              label: '类目',
              key: 'category'
            },
            {
              label: '类型',
              key: 'type',
              type: 'mapText',
              params: {
                type: 'dictionary',
                dictionaryName: 'deduct_def_type'
              }
            }
          ],
          actions: []
        }
      ]
    };
    return () => {
      return (
        <business-dialog-item
          {...attrs}
          tableConfig={tableConfig}
          dataFormatter={dataFormatter}
          onCloseDialog={() => {
            emit('closeDialog');
          }}
          onGetValue={(data: any[]) => {
            emit('getValue', data);
          }}
        />
      );
    };
  }
});
