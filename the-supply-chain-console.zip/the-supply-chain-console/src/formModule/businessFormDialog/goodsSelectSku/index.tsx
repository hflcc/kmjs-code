import { computed, defineComponent, PropType, ref } from 'vue';
import { useDialog } from '@/utils';
import kmjsModule, { ModuleCtl, useModule } from '@/components/modules/module/code';
import activeGoodsTable from '@/formModule/businessFormDialog/goodsSelectSku/components/activeGoodsTable';
import { ElMessage } from 'element-plus';
import { multiply } from 'lodash';
import tableSearch from '@/formModule/businessFormDialog/goodsSelectSku/components/tableSearch';
import { TagItem } from '@/components/utils/commonType';
import { GoodsSkus, TableRow } from '@/pages/shopManage/api';
import store from '@/store';
import './index.less';
import { onMounted } from 'vue';

export interface GoodItem extends TableRow {
  _checked: boolean;
  _disabled: boolean;
  isDelete: boolean;
  totalRetailPrice: number;
  retailPrice: number;
  totalPrice: number;
  price: number;
}

export default defineComponent({
  name: 'form-module-business-goodsSkuSelector',
  props: {
    // 是否显示弹窗
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    // 配置项
    params: {
      type: Object as PropType<ResSteButtons>,
      required: true
    },
    // 外部表格数据
    tableData: {
      type: Object as PropType<{
        snKey: string;
        snArr: string[];
        tableData: Array<Record<string, any>>;
        formToBusinessKeyMapping: Record<string, string>;
      }>,
      required: true
    },
    // 渲染需要使用到的数据，一般是指来自别的表单项的数据
    renderData: {
      type: Object as PropType<{
        category: {
          name: string;
          value: {
            name: string;
            sn: string;
          }[];
        }[];
        brand: {
          name: string;
          value: {
            name: string;
            sn: string;
          };
        }[];
        filterGoodsShopSn: {
          name: string;
          value: string;
        };
      }>,
      required: true
    },
    // 请求接口所需要的数据
    requestData: {
      type: Object as PropType<Record<string, any>>,
      default: () => ({}),
      required: true
    }
  },
  components: {
    kmjsModule,
    activeGoodsTable,
    tableSearch
  },
  emits: ['closeDialog', 'getValue', 'update:modelValue'],
  setup(props, { emit }) {
    let currentTableData: GoodItem[] = [];
    const moduleCtl = ref<ModuleCtl | null>(null);
    let methods: { [moduleName: string]: (...argus: any) => any };
    const activeGoods = ref<GoodItem[]>([]);
    // 选中的sku商品
    const checkedSku = ref<GoodsSkus[]>([]);
    const getActiveGoods = computed(() => {
      const arr: GoodItem[] = [];
      activeGoods.value.forEach((s) => {
        if (s.skus) {
          s.skus = s.skus.filter((item) => item.checked);
        }
        arr.push(s);
      });
      return arr;
    });
    const showActiveTable = ref(false);
    const categorySns = () => {
      const arr: string[] = [];
      if (Array.isArray(props.renderData?.category)) {
        props.renderData.category?.forEach((s) => {
          // 取最后一个的SN
          s.value.length && arr.push(s.value.slice(-1)[0].sn);
        });
      }
      return arr.join(',');
    };

    /**
     * 表格数据选中或反选中时处理
     * */
    const changeCheckbox = (data: { data: TableRow; checked: boolean }) => {
      // console.log(data)
      if (data.checked) {
        buildData();
      } else {
        // 表格全选
        if (Object.prototype.toString.call(data.data) === '[object Array]') {
          currentTableData.forEach((item, index) => {
            let _has = true;
            item.skus &&
              item.skus.forEach((i) => {
                data.data.skus.forEach((element, idx) => {
                  if (i.sn === element.sn) {
                    i.checked = false;
                    activeGoods.value.splice(idx, 1);
                    _has = !!(item.skus && item.skus.findIndex((s) => s.sn === element.sn));
                  }
                });
              });
            if (!_has) {
              methods['/title/title-table/setCheckDisabled']?.(index, undefined, false);
            }
          });
        } else {
          const index = activeGoods.value.findIndex((s) => s.sn === data.data.sn);
          if (index > -1) {
            activeGoods.value.splice(index, 1);
          }
          // 存取选中的sku
          if (data.data.skus) {
            // 当前商品存在sku
            data.data.skus.forEach((element, idx) => {
              const index = checkedSku.value.findIndex((s) => s.sn === element.sn);
              if (index > -1) {
                checkedSku.value.splice(index, 1);
                element.checked = false;
              }
            });
          } else {
            // 已选 sku 删除
            const index = checkedSku.value.findIndex((s) => s.sn === data.data.sn);

            currentTableData.forEach((item, idx) => {
              item.skus &&
                item.skus.forEach((i) => {
                  if (i.sn === data.data.sn) {
                    i.checked = false;
                    checkedSku.value.splice(index, 1);
                  }
                });
              // 如果当前列数据里面没有sku选中，则清除这一列的选中
              const hasChecked = item.skus && item.skus.some((item) => item.checked);
              if (!hasChecked) {
                methods['/title/title-table/setCheckDisabled']?.(idx, undefined, false);
              }
            });
          }
        }
      }
    };
    /**
     * 表格内部修改数据时，部分字段响应丢失，在这里进行下同步更新
     * */
    const buildData = () => {
      setTimeout(() => {
        const data: GoodItem[] = methods['/title/title-table/getCheckData']();
        data.forEach((k) => {
          const index = activeGoods.value.findIndex((s) => s.sn === k.sn);
          if (index === -1) {
            activeGoods.value.push(k);
          }

          // 记录选中的sku
          k.skus &&
            k.skus.forEach((item) => {
              const index = checkedSku.value.findIndex((s) => s.sn === item.sn);
              if (item.checked && index === -1) {
                item.goodsName = k.name;
                checkedSku.value.push(item);
              } else if (!item.checked && index > -1) {
                checkedSku.value.splice(index, 1);
              }
            });
        });
      }, 1);
    };
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        activeGoods.value = [];
        checkedSku.value = [];
        const flag = ref<boolean>(false);
        const [ctl, med] = useModule({
          config: [
            {
              type: 'wrap-module',
              name: 'title',
              params: {
                hideBack: true,
                title: '选择商品',
                actions: [
                  {
                    type: 'refresh',
                    emit: 'refresh'
                  }
                ]
              },
              permissions: [],
              children: [
                {
                  type: 'table',
                  name: 'title-table',
                  params: {
                    tableDataUrl: '/auth/md/inst/goods/page',
                    items: [
                      {
                        type: 'search',
                        isSlot: true,
                        inputs: [
                          {
                            label: '商品名称',
                            key: 'name',
                            type: 'text'
                          }
                        ]
                      },
                      {
                        type: 'table',
                        tableConfig: {
                          // 是否启用扩展展示
                          isExpand: true,
                          // 扩展展示的组件
                          templateName: 'goodsSelectorSku'
                        },
                        tableHead: [
                          {
                            label: '商品名称',
                            key: 'name'
                          },
                          {
                            label: '品牌',
                            key: 'brand'
                          },
                          {
                            label: '类目',
                            key: 'category'
                          },
                          {
                            type: 'image',
                            label: '图片',
                            key: 'ossId',
                            params: {
                              width: '40px'
                            }
                          },
                          {
                            label: '库存',
                            key: 'saledCount'
                          },
                          {
                            type: 'rangeText',
                            label: '售价(元)',
                            key: 'price',
                            params: {
                              startKey: 'minPrice',
                              endKey: 'maxPrice',
                              formatter: 'price'
                            }
                          },
                          {
                            label: '备注',
                            key: 'remark',
                            width: 260
                          }
                        ]
                      }
                    ]
                  },
                  slotParam: [
                    {
                      name: 'search',
                      slotName: 'search'
                    }
                  ]
                }
              ]
            }
          ],
          params: {
            '/title/title-table': {
              beforeRequest: (requestObj: { url: string; params: any }) => {
                buildData();
                requestObj.params.categorySns = categorySns();
                requestObj.params.filterGoodsShopSn = props.renderData?.filterGoodsShopSn;
                requestObj.params['filterSns'] = props.tableData.snArr?.join(',') ?? '';
                return Promise.resolve(requestObj);
              },
              dataFormatter: (data: GoodItem[]) => {
                currentTableData = data;
                return data.map((s) => {
                  s.skus &&
                    s.skus.map((item) => {
                      item.checked = false;
                      if (item.icon.includes('http')) {
                        item.image = item.icon;
                      } else {
                        store.dispatch('source/getOssUrl', [item.icon]).then((res) => {
                          if (res) {
                            item.image = res[item.icon].url;
                            item.checked = false;
                          }
                        });
                      }
                    });

                  // 翻页时选中数据
                  const index = activeGoods.value.findIndex((k) => k.sn === s.sn);
                  if (index > -1) {
                    s._checked = true;
                  }
                  return s;
                });
              }
            }
          },
          handler: (moduleName, name, data) => {
            console.log(moduleName, name, data);

            let rowData = {} as TableRow;
            let isChecked = false;
            if (name.includes('Sku')) {
              // data是sku复选框的选择结果
              rowData = (data.length && data[0].sku) || (data.length && data[0].data) || {};
            } else {
              // data是外层table复选框的选择结果
              rowData = (data.length && data[0].row) || (data.length && data[0].data) || {};
              isChecked = (data.length && data[0].checked) || false;
            }

            let allData: Array<{ data: TableRow; checked: boolean }> = [];
            if (name === 'tableTriggerCheckAll') {
              allData = data[0];
            }

            switch (moduleName + '_' + name) {
              case '/title/title-table_tableSkuChange': // sku 复选框选择
                flag.value = true;
                flag.value && changeCheckbox(rowData as any);
                methods['/title/title-table/setCheckDisabled']?.(
                  rowData.index,
                  undefined,
                  rowData.checked
                );
                flag.value = false;
                break;
              case '/title/title-table_tableCheckboxChange': // 表格数据复选框选择
                changeCheckbox(data[0]);
                if (!flag.value) {
                  rowData.skus &&
                    rowData.skus.forEach((item) => {
                      // 外层数据是否全选
                      if (isChecked) {
                        item.checked = true;
                      } else {
                        item.checked = false;
                      }
                    });
                }
                break;
              case '/title/title-table_tableTriggerCheckAll': // 表格全选
                allData.length &&
                  allData.forEach((item) => {
                    changeCheckbox(item as any);
                    item.data.skus &&
                      item.data.skus.forEach((element) => {
                        element.checked = item.checked;
                      });
                  });
                break;
            }
          }
        });
        moduleCtl.value = ctl;
        methods = med;
      } else {
        moduleCtl.value = null;
      }
    });
    /*
     * 删除item之后调用,清除外层列表的数据
     * */
    const removeItemCallback = () => {
      const data = methods['/title/title-table/getTableData']() as GoodItem[];
      const skuList = activeGoods.value.map((itemChild) => itemChild.sn);
      data.forEach((item, index) => {
        if (!skuList.includes(item.sn)) {
          // item.quantity = 0;
        }
      });
      // methods['/title/title-table/setTableData'](data);
    };
    /**
     * 返回用户已经选择的数据
     * */
    const getData = async () => {
      if (activeGoods.value.length > 100) {
        ElMessage.error('最多仅可选择100个商品');
        return;
      }
      emit('getValue', getActiveGoods.value);
    };
    return () => {
      const formModule = moduleCtl.value ? (
        <kmjsModule
          ctl={moduleCtl.value}
          v-slots={{
            search: ({ submitData }: { submitData: (tags: TagItem[]) => void }) => {
              return <tableSearch data={props.renderData} change={submitData}></tableSearch>;
            }
          }}
        />
      ) : null;
      return (
        <el-dialog
          width="80vw"
          top="1vh"
          v-model={showDialog.value}
          onClosed={closeWindow}
          destroy-on-close
          v-slots={{
            footer: () => {
              return (
                <el-space>
                  <el-button onClick={closeWindow}>取消</el-button>
                  <el-button
                    type={'primary'}
                    onClick={() => {
                      // 解决用户在步进器中输入后直接点击提交按钮是，数量获取失败的问题
                      setTimeout(() => {
                        getData();
                      }, 100);
                    }}
                  >
                    确认
                  </el-button>
                </el-space>
              );
            }
          }}
        >
          <div class="goods-sku-selector" style={{ height: '75vh', width: '100%' }}>
            {formModule}
            <el-popover
              placement="top"
              width={650}
              trigger="click"
              auto-close={0}
              onHide={() => {
                removeItemCallback();
              }}
              onShow={() => {
                // buildActiveData();
                showActiveTable.value = true;
              }}
              onAfterLeave={() => {
                showActiveTable.value = false;
              }}
              v-slots={{
                reference: () => (
                  <el-button
                    style={{ width: '130px' }}
                    type={checkedSku.value.length <= 100 ? 'primary' : 'danger'}
                    size="mini"
                  >
                    {showActiveTable.value
                      ? '收起'
                      : '已选商品(' + checkedSku.value.length + '/100)'}
                  </el-button>
                )
              }}
            >
              {showActiveTable.value ? (
                <activeGoodsTable
                  data={checkedSku.value}
                  delOne={changeCheckbox}
                  delAll={(arr: GoodItem[]) => {
                    arr.forEach((s) => {
                      changeCheckbox({
                        data: s,
                        checked: false
                      });
                    });
                  }}
                />
              ) : null}
            </el-popover>
          </div>
        </el-dialog>
      );
    };
  }
});
