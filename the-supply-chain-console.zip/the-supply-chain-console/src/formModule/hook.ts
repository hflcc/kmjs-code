import { configTransform } from '@/formModule/configTransform';
import { ModuleConfig, useModule } from '@/components/modules/module/useModule';
import { useFormLogic } from '@/formModule/formlogic';
import { nextTick, onBeforeUnmount, provide, reactive, ref } from 'vue';
import {
  buildFormModuleInstance,
  formModuleRest,
  getDef,
  getDraftBySn,
  getDraftBySnNew,
  getHistoryData
} from './api';
import { ModuleItem } from '@/components/utils/commonType';
import { FormCtl, ModuleFromConfig } from '@/formModule/useModule';
import { Btns } from '@/components/utils/commonType';
import { TabItem } from '@/components/modules/components/tabs';
import { ElMessage, ElMessageBox, ElNotification } from 'element-plus';
import { formatterStrByObj } from '@/utils';

/**
 * 创建表单实例
 * */
const initFormInstance = async (
  defSn: string,
  sn = '',
  configDataMap = {},
  initDataMap = {}
): Promise<string> => {
  const instance = await buildFormModuleInstance(defSn as string, {
    sn,
    configDataMap,
    initDataMap
  });
  if (instance) {
    return instance.sn;
  } else {
    return '';
  }
};

/**
 * 控制草稿弹窗的逻辑
 * */
export const historyLogic = () => {
  const showHistory = ref(false);
  const showHistoryFun = () => {
    showHistory.value = true;
  };
  const hideHistoryFun = () => {
    showHistory.value = false;
  };
  return {
    showHistory,
    showHistoryFun,
    hideHistoryFun
  };
};

/**
 * 根据实例SN获取数据，并设置表单中的数据
 * */
const setDataByInstanceSn = async (
  sn: string,
  setData: (data: Record<string, any>) => void,
  showToast = false,
  toastMsg = '恢复成功',
  isHistory = false
): Promise<Record<string, any>> => {
  const ajaxFun = isHistory ? getDraftBySnNew : getDraftBySn;
  const result = await ajaxFun(sn);
  if (!result) return {};
  // 这里草稿返回的是sn， 而不是分步对应的key， 需要转一下
  const obj: Record<string, Record<string, unknown>> = {};
  result.forEach((v) => {
    obj[v.stepKey] = v.data;
  });
  setData(obj);
  if (showToast) {
    ElMessage.success(toastMsg);
  }
  return obj;
};

/**
 * 初始化表单控件
 * */
export const initForm = (
  snConfig: {
    defSn: string;
    instanceSn: string;
  },
  config: ResConfig,
  handler: (name: string, data: Record<string, unknown> | Record<string, unknown>[]) => void,
  showHistoryFun: () => void,
  options: ModuleFromConfig
) => {
  const hasWrap = typeof options.params.hideWrap === 'undefined' || !options.params.hideWrap;
  let wrapActions: Btns[];
  switch (options.params.type) {
    case 'create':
      wrapActions = [
        {
          type: 'default',
          label: '重置',
          emit: 'reload'
        },
        {
          type: 'default',
          label: '草稿',
          emit: 'history'
        },
        {
          type: 'default',
          label: '保存',
          emit: 'saveDraft'
        },
        {
          type: 'primary',
          label: '提交',
          emit: 'submitData'
        }
      ];
      break;
    case 'detail':
      wrapActions = [];
      break;
    case 'edit':
      wrapActions = [
        {
          type: 'primary',
          label: '提交',
          emit: 'submitData'
        }
      ];
      break;
  }
  // 对配置进行本地化处理
  const moduleConfig = configTransform(
    config,
    hasWrap,
    {
      hideBack: options.params.wrapConfig?.hideBack ?? true,
      title: options.params.wrapConfig?.title ?? config.def.name,
      actions: wrapActions.concat(options.params.wrapConfig?.actions ?? [])
    },
    options.params.type === 'detail'
  );
  /**
   * 获取处于tab下的表单, 排除那些 tab是disabled的
   * */
  const getCurrentForm = (): CurrentForm[] => {
    let key = '';
    let parentName = '';
    const forms: CurrentForm[] = [];
    const tab = methodsFun['/wrap/tab/getActive'] || methodsFun['/tab/getActive'];
    const getAllTab = methodsFun['/wrap/tab/getAllChild'] || methodsFun['/tab/getAllChild'];
    const moduleName = methodsFun['/wrap/tab/getName'] || methodsFun['/tab/getName'];
    if (typeof getAllTab === 'function') {
      // 排除那些 tab是disabled的
      const tabs = getAllTab((v: TabItem) => !v.disable);
      parentName = moduleName();
      key = tab().name;
      tabs.forEach((v: string) => {
        // 当前激活的放在第一个
        if (key === v) return;
        forms.push({
          name: v,
          methods: {
            saveDraft: () => {
              return methodsFun[parentName + '/' + v + '/form/getNoVerifyData']();
            },
            submitData: () => {
              return methodsFun[parentName + '/' + v + '/form/getData']();
            },
            setData: (data) => {
              return methodsFun[parentName + '/' + v + '/form/setData'](data);
            },
            clearValidate: (data) => {
              return methodsFun[parentName + '/' + v + '/form/clearValidate']?.(data);
            }
          }
        });
      });
      forms.unshift({
        name: key,
        methods: {
          saveDraft: () => {
            return methodsFun[parentName + '/' + key + '/form/getNoVerifyData']();
          },
          submitData: () => {
            return methodsFun[parentName + '/' + key + '/form/getData']();
          },
          setData: (data) => {
            return methodsFun[parentName + '/' + key + '/form/setData'](data);
          },
          clearValidate: (data) => {
            return methodsFun[parentName + '/' + key + '/form/clearValidate']?.(data);
          }
        }
      });
    } else {
      key = moduleConfig.tabKeys[0];
      forms.push({
        name: key,
        methods: {
          saveDraft: () => {
            const fun =
              methodsFun['/wrap/' + key + '/form/getNoVerifyData'] ??
              methodsFun['/' + key + '/form/getNoVerifyData'];
            return fun();
          },
          submitData: () => {
            const fun =
              methodsFun['/wrap/' + key + '/form/getData'] ??
              methodsFun['/' + key + '/form/getData'];
            return fun();
          },
          setData: (data) => {
            const setData =
              methodsFun['/wrap/' + key + '/form/setData'] ??
              methodsFun['/' + key + '/form/setData'];
            return setData(data);
          },
          clearValidate: (data) => {
            const clearValidate =
              methodsFun['/wrap/' + key + '/form/clearValidate'] ??
              methodsFun['/' + key + '/form/clearValidate'];
            return clearValidate?.(data);
          }
        }
      });
    }
    return forms;
  };

  /**
   * 获取详情下的表单，主要是异步设置值时用到
   * */
  const getDetailFrom = (): CurrentForm[] => {
    const forms: CurrentForm[] = [];
    moduleConfig.tabKeys.forEach((v) => {
      forms.push({
        name: v,
        methods: {
          saveDraft: () => {
            const fun =
              methodsFun['/wrap/' + v + '/form/getNoVerifyData'] ??
              methodsFun['/' + v + '/form/getNoVerifyData'];
            return fun();
          },
          submitData: () => {
            const fun =
              methodsFun['/wrap/' + v + '/form/getData'] ?? methodsFun['/' + v + '/form/getData'];
            return fun();
          },
          setData: (data) => {
            const setData =
              methodsFun['/wrap/' + v + '/form/setData'] ?? methodsFun['/' + v + '/form/setData'];
            return setData(data);
          },
          clearValidate: (data) => {
            const clearValidate =
              methodsFun['/wrap/' + v + '/form/clearValidate'] ??
              methodsFun['/' + v + '/form/clearValidate'];
            return clearValidate(data);
          }
        }
      });
    });
    return forms;
  };
  /**
   * 注册模块
   * */
  const [moduleCtl, methodsFun] = useModule({
    config: moduleConfig.moduleConfig,
    handler: (moduleName, name, data) => {
      switch (moduleName + '/' + name) {
        case '/wrap/reload':
          ElMessageBox.confirm('重置将清除所有已填写的内容， 确定要重置吗？', '提示').then(
            async () => {
              let requestBody = { sn: '', configDataMap: {} };
              if (typeof options.params.setQueryData === 'function') {
                requestBody = (await options.params.setQueryData()) as {
                  sn: '';
                  configDataMap: Record<string, unknown>;
                };
              }
              const res = await formModuleRest(snConfig.instanceSn, requestBody);
              if (res) {
                const data = await setDataByInstanceSn(
                  snConfig.instanceSn,
                  setData,
                  true,
                  '重置成功'
                );
                await clearValidateByInstanceSn(data, clearValidate);
              }
            }
          );
          break;
        case '/wrap/history':
          showHistoryFun();
          break;
        case '/wrap/saveDraft':
          saveDraft();
          break;
        case '/wrap/submitData':
          submitData();
          break;
        default:
          handler(name, data);
          break;
      }
    }
  });
  /**
   * 提交表单前的动作，一般是弹窗让用户二次确认
   * */
  const submitConfirm = async (mapData: Record<string, Record<string, unknown>>) => {
    if (!moduleConfig.submitConfirms.length) return true;
    const forms = getCurrentForm();
    let config: SubmitBeforeConfig | null;
    // 说明同时可以提交多个表单，直接使用第一个tab的beforeConfig的配置即可
    if (forms.length > 1) {
      config = moduleConfig.submitConfirms[0].config;
    } else {
      config = moduleConfig.submitConfirms.find((s) => s.name === forms[0].name)?.config ?? null;
    }
    if (!config) return true;
    if (config.dialog) {
      const flag = await ElMessageBox.confirm(
        formatterStrByObj(config.dialog, mapData),
        '提示信息'
      );
      if (flag) {
        return true;
      } else {
        return false;
      }
    }
    return true;
  };

  const { submitData, saveDraft, setData, clearValidate, getData } = useFormLogic(
    snConfig,
    config.steps.length === 1 ? 'only' : config.def.stepType,
    options.params.type === 'detail' ? getDetailFrom : getCurrentForm,
    methodsFun,
    handler,
    moduleConfig.saveQuery,
    options.params.setQueryData,
    options.params.beforeSubmit,
    submitConfirm
  );
  return {
    getCurrentForm: options.params.type === 'detail' ? getDetailFrom : getCurrentForm,
    moduleCtl,
    methodsFun,
    submitData,
    saveDraft,
    setData,
    getData
  };
};

/**
 * 根据实例SN获取数据，并设置表单中的数据
 * */
const clearValidateByInstanceSn = async (
  data: Record<string, any>,
  clearValidate: (data: Record<string, any>) => void | undefined
) => {
  clearValidate(data);
};

/**
 * 组件的主要逻辑
 * */
export const mainLogic = (props: { ctl: FormCtl }) => {
  let requestBody = { sn: '', configDataMap: {} };
  const isSubmit = ref(false);
  const className = ref('');
  // 主动根据实例SN获取
  let mustSetData = false;
  let getCrFr: () => CurrentForm[];
  const loadingFrom = ref(true);
  const loadingText = ref('');
  const { showHistory, showHistoryFun, hideHistoryFun } = historyLogic();
  // 记录当前表单模块的sn， 分为定义sn 和实例sn
  const snConfig = reactive({
    defSn: '',
    instanceSn: ''
  });
  // 渲染表单
  const moduleCtl = ref<
    null | (() => [ModuleConfig, { [moduleName: string]: () => void }, ModuleItem[] | undefined])
  >(null);
  /**
   * 对外暴露方法
   * */
  const [options, methods] = props.ctl();
  // 对外的钩子方法触发
  const handler = (name: string, ...data: any[]) => {
    if (name === 'submitData') {
      isSubmit.value = true;
    }
    options.handler?.('', name, data);
  };
  // 仅用了做占位
  const useHistoryData = ref((data: { stepKey: string; data: Record<string, unknown> }[]) => {
    // no logic
  });
  // 设置tab是否渲染表格
  const tabGridDetail = reactive<Record<string, FormatTabGridDetail>>({});
  provide('tabGridDetail', tabGridDetail);
  // 根据定义获取渲染表单数据
  const getDefData = async () => {
    const res = await getDef(options.params.defSn as string);
    if (!res) {
      loadingText.value = '表单载入失败。请稍后重试';
      return;
    }
    if (typeof options.params.setQueryData === 'function') {
      requestBody = (await options.params.setQueryData()) as {
        sn: '';
        configDataMap: Record<string, unknown>;
      };
    }
    res.steps.forEach((item) => {
      const { key, formType, property } = item.step;
      const obj: Record<string, { isGrid: boolean; unionKey: string }> = {};
      obj[key] = {
        isGrid: formType === 'grid',
        unionKey: property?.unionKey || ''
      };
      Object.assign(tabGridDetail, obj);
    });
    // 新增模式需要先创建表单实例
    if (options.params.type === 'create') {
      if (!snConfig.instanceSn) {
        const instance = await initFormInstance(
          options.params.defSn as string,
          requestBody?.sn,
          requestBody.configDataMap
        );
        if (instance) {
          snConfig.instanceSn = instance;
          mustSetData = true;
        }
      }
      // 新建模式下，查询到上次草稿时，询问是否使用上次的草稿
      getHistoryData(options.params.defSn).then((res) => {
        if (res && res.content && res.content.length) {
          const sn = res.content[0].sn;
          ElNotification({
            offset: 180,
            title: '恢复内容？',
            duration: 10000,
            dangerouslyUseHTMLString: true,
            message:
              '<p>是否从草稿箱恢复上一次的编辑内容？ <button id="btn' +
              sn +
              '" class="el-button el-button--primary el-button--mini" type="button" onclick=""><span>恢复</span></button></p>',
            type: 'info'
          });
          document.getElementById('btn' + sn)?.addEventListener('click', function recover() {
            setDataByInstanceSn(sn, setData, true, undefined, true);
            ElNotification.closeAll();
            this.removeEventListener('click', recover);
          });
        }
      });
    }
    const {
      getCurrentForm,
      moduleCtl: moduleCtlConfig,
      submitData,
      saveDraft,
      setData,
      getData
    } = initForm(snConfig, res, handler, showHistoryFun, options);
    moduleCtl.value = moduleCtlConfig;
    getCrFr = getCurrentForm;
    methods['submitData'] = submitData;
    methods['saveDraft'] = saveDraft;
    methods['setData'] = setData;
    methods['getData'] = getData;
    methods['getInstanceSn'] = () => {
      return snConfig.instanceSn;
    };
    methods['getCanEdit'] = () => {
      return Boolean(res.steps.find((v) => v.step.property?.canEdit ?? 1));
    };
    methods['getResConfig'] = () => {
      return res;
    };
    useHistoryData.value = (data) => {
      // 这里草稿返回的是sn， 而不是分步对应的key， 需要转一下
      const obj: Record<string, Record<string, unknown>> = {};
      data.forEach((v) => {
        obj[v.stepKey] = v.data;
      });
      setData(obj);
      nextTick(() => {
        ElMessage.success('应用成功');
        hideHistoryFun();
      });
    };
    loadingFrom.value = false;
    nextTick(() => {
      if (mustSetData) {
        setDataByInstanceSn(snConfig.instanceSn, setData).then((data) => {
          if (res.def.title) {
            res.def.title = formatterStrByObj(res.def.title, data);
          }
          handler('ready');
        });
      } else {
        handler('ready');
      }
    });
  };
  // /**
  //  * 获取删除/使用的实例sn
  //  * 如果是删除，并且删除的当前的实例sn时，将当前表单作为一个没有实例的表单
  //  * 如果是使用。直接改变当前表单的实例sn
  //  * */
  // const getInstanceSn = (sn: string, isEdit: boolean) => {
  //   if (isEdit) {
  //     snConfig.instanceSn = sn;
  //   } else if (snConfig.instanceSn === sn) {
  //     snConfig.instanceSn = '';
  //   }
  // };
  const changeCallbacks: {
    tabName: string;
    fn: (tabName: string, key: string, data: any) => void;
  }[] = [];
  provide<FormModuleEvents>('formModuleEvents', {
    onChange: (tabName, callBack) => {
      // 收集依赖
      changeCallbacks.push({
        tabName,
        fn: callBack
      });
    },
    change: (tabName, key, data) => {
      changeCallbacks.forEach((v) => {
        if (v.tabName === tabName) return;
        v.fn(tabName, key, data);
      });
    },
    getData: (tabName, key) => {
      const allForm = getCrFr?.() ?? ([] as CurrentForm[]);
      const form = allForm.find((s: CurrentForm) => s.name === tabName);
      const allData = form?.methods?.saveDraft();
      if (Array.isArray(allData) && key) {
        return allData
          .filter((s) => !s.isDelete)
          .map((s) => {
            return s[key];
          })
          .filter((s) => s);
      }
      return key ? allData?.[key] : allData;
    },
    setData: (tabName, key, data) => {
      const allForm = getCrFr?.() ?? ([] as CurrentForm[]);
      const form = allForm.find((s: CurrentForm) => s.name === tabName);
      form?.methods.setData({
        [key]: data
      });
    },
    reloadForm: async (data: Record<string, any>) => {
      const instance = await initFormInstance(
        options.params.defSn as string,
        requestBody?.sn,
        requestBody.configDataMap,
        data
      );
      if (instance) {
        setDataByInstanceSn(instance, methods['setData']);
      }
    }
  });
  className.value = 'form-module-is-' + options.params.type;
  getDefData();
  snConfig.defSn = options.params.defSn;
  if (options.params.instanceSn) {
    snConfig.instanceSn = options.params.instanceSn;
  }
  onBeforeUnmount(() => {
    ElNotification.closeAll();
  });
  return {
    isSubmit,
    type: options.params.type,
    // getInstanceSn,
    loadingFrom,
    loadingText,
    snConfig,
    moduleCtl,
    showHistory,
    hideHistoryFun,
    useHistoryData,
    className
  };
};
