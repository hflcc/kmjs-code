import kmjsModule from './code';
import { defineComponent, onBeforeUnmount, onMounted, PropType } from 'vue';
import './style.less';
import { mainLogic } from '@/formModule/hook';
import historyDialog from '@/formModule/history';
import { FormCtl } from '@/formModule/useModule';
import empty from '@/assets/empty.svg';

export { getBusinessData } from '@/formModule/api';
export * from './useModule';
export default defineComponent({
  name: 'kmjs-form-module',
  props: {
    ctl: {
      type: Function as PropType<FormCtl>,
      required: true
    }
  },
  components: {
    kmjsModule,
    historyDialog
  },
  setup(props) {
    const {
      isSubmit,
      type,
      loadingText,
      loadingFrom,
      moduleCtl,
      showHistory,
      snConfig,
      hideHistoryFun,
      useHistoryData,
      // getInstanceSn,
      className
    } = mainLogic(props);
    const reload = (event: BeforeUnloadEvent) => {
      if (type !== 'detail' && !isSubmit.value) {
        event.preventDefault();
        event.returnValue = '确认离开， 页面将不会保留您的数据';
      } else {
        event.returnValue = '';
      }
    };
    onMounted(() => {
      window.addEventListener('beforeunload', reload);
    });
    onBeforeUnmount(() => {
      window.removeEventListener('beforeunload', reload);
    });
    return {
      // getInstanceSn,
      loadingText,
      loadingFrom,
      snConfig,
      moduleCtl,
      showHistory,
      hideHistoryFun,
      useHistoryData,
      className
    };
  },
  render() {
    const {
      loadingText,
      loadingFrom,
      moduleCtl,
      showHistory,
      snConfig,
      hideHistoryFun,
      useHistoryData,
      // getInstanceSn,
      className
    } = this;
    if (moduleCtl && !loadingFrom) {
      return (
        <>
          <historyDialog
            v-model={showHistory}
            onCloseDialog={hideHistoryFun}
            onSetData={useHistoryData}
            def-sn={snConfig.defSn}
            // onGetPlaySn={getInstanceSn}
          />
          <kmjsModule
            class={'form-module-wrap ' + className}
            ctl={moduleCtl}
            v-slots={this.$slots}
          />
        </>
      );
    } else {
      if (loadingText) {
        return (
          <el-empty
            description={loadingText}
            v-slots={{
              image: () => {
                return <img src={empty} />;
              }
            }}
          ></el-empty>
        );
      } else {
        return (
          <div
            style={{ width: '100%', height: '300px' }}
            v-loading="loading"
            element-loading-text={loadingText}
          ></div>
        );
      }
    }
  }
});
