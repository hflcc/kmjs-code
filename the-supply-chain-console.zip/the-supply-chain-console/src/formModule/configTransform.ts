/**
 * 配置数据修改为本地组件的数据格式
 * 分为几种类型
 * 1。 普通表单
 * 2。 带有tab切换的表单
 * 3。 带有tab切换，但是有些tab是要等前面的表单完成后才可以进行编辑的tab
 * 4。 带有表格的多个数据录入的表单
 * 5。 详情模式
 * */
import { FormItem, InputType, LinkageConfig, ShowRule, UploadConfig } from '@/components/form/type';
import { BtnShowRule, TableCell, TableColumn } from '@/components/table/kmjsTableType';
import { Btns, ModuleItem } from '@/components/utils/commonType';
import { WrapConfig } from '@/components/wrap/module';

const formModuleItemType: Record<string, InputType> = {
  text: InputType.text,
  email: InputType.text,
  idCard: InputType.text,
  phone: InputType.text,
  number: InputType.text,
  integer: InputType.text,
  textarea: InputType.textArea,
  switches: InputType.switch,
  select: InputType.select,
  multiple: InputType.checkbox,
  single: InputType.radio,
  dateRange: InputType.daterange,
  imagesUpload: InputType.uploadImg,
  filesUpload: InputType.uploadFile,
  date: InputType.date,
  area: InputType.area,
  address: InputType.address,
  hide: InputType.hide,
  dictionary: InputType.select,
  qualificationDef: InputType.qualificationDef,
  expiredDate: InputType.expiredDate
};

const formModuleTableType: Record<string, TableCell> = {
  text: 'text',
  email: 'text',
  idCard: 'text',
  phone: 'text',
  number: 'formatter',
  integer: 'text',
  textarea: 'text',
  switches: 'mapText',
  select: 'mapText',
  multiple: 'mapText',
  single: 'mapText',
  imagesUpload: 'image',
  dateRange: 'rangeText',
  date: 'formatter',
  address: 'address',
  filesUpload: 'fileListView',
  dictionary: 'mapText',
  qualificationDef: 'text',
  expiredDate: 'expiredDate',
  expansionInput: 'expansion'
};

/**
 * 处理单独的表单项
 * */
const transformFormConfig = (item: ResItems[], canEdit = true, tabName = ''): ModuleItem => {
  const dictionaryNames: string[] = [];
  const itemData = item.map((v): FormItem => {
    const { item, option } = v;
    const rules: ShowRule[] = [];
    const uploadConfig: UploadConfig = {
      tip: []
    };
    if (item.sourceType === 'dictionary') {
      dictionaryNames.push(item.sourceValue);
    }
    if (item.type === 'filesUpload' || item.type === 'imagesUpload') {
      uploadConfig.limit = item.property?.limitCount;
      uploadConfig.size =
        (item.property?.limitSize && item.property.limitSize > 0 && item.property.limitSize) || 0;
    }
    // if (item.type === )
    const linkageConfig: LinkageConfig = {
      sourceType: 'none',
      _isLoading: false,
      playAnyTime: item.property?.callbackAnytime ?? false,
      source: [],
      play: {},
      action: 'play'
    };
    // 是否依赖某些值的变化在发起请求，如果没有sourceKey 是 '*'
    if (item.params?.requestParams) {
      // 后台发起请求时，需要用到的参数的映射
      Object.keys(item.params.requestParams).forEach((v) => {
        const s = item.params?.requestParams?.[v];
        if (s.type === 'original') {
          linkageConfig.source?.push({
            key: '*',
            value: [s.value],
            businessKey: v
          });
        } else {
          linkageConfig.source?.push({
            key: s.value,
            value: [],
            businessKey: v
          });
        }
      });
    }
    // 数据来自业务数据
    if (
      item.sourceType === 'business' ||
      item.sourceType === 'mapping' ||
      item.sourceType === 'selector'
    ) {
      linkageConfig.sourceType = item.sourceType;
      linkageConfig.serverUrl = item.sourceValue;
      // 设置code和label分别取自哪个数据字段
      linkageConfig.businessKeyMap = {
        label: item.params?.responseMapping?.label ?? '',
        value: item.params?.responseMapping?.code ?? ''
      };
      // 没有依赖项，但是数据还是来自于后台时，默认认为不需要依赖项目
      if (
        !item.params?.requestParams ||
        (item.params?.requestParams && Object.keys(item.params?.requestParams).length === 0)
      ) {
        linkageConfig.source?.push({
          key: '*',
          value: [''],
          businessKey: ''
        });
      }
    }
    // 值改变后对表单内某些值的影响
    if ((item.params?.selectAction === 'callback' || !item.params?.selectAction) && item.callback) {
      linkageConfig.action = 'play';
      Object.keys(item.callback).forEach((v) => {
        const s = item.callback[v];
        if (linkageConfig.play) {
          const arr: {
            // 对应表单内的key
            sourceFormKey: string;
            // 业务数据的key | 表单字段Key： 业务字段Key的对应
            businessFormKey: string | Record<string, string>;
          }[] = [];
          if (typeof s === 'object' && s !== null) {
            Object.keys(s).forEach((d) => {
              arr.push({
                sourceFormKey: d,
                businessFormKey: s[d]
              });
            });
          } else if (typeof s === 'string') {
            arr.push({
              sourceFormKey: v,
              businessFormKey: s
            });
          }
          linkageConfig.play[v] = arr;
        }
      });
    }
    // 值改变后
    if (item.params?.selectAction === 'init') {
      linkageConfig.action = 'init';
    }
    // 依赖关系，进行数学计算的逻辑
    if (item.property?.valueRely && item.property?.valueRely.length) {
      item.property?.valueRely.forEach((s) => {
        s.params.forEach((k) => {
          rules.push({
            ruleType: 'mathComputed',
            mathType: s.method,
            sourceValue: s.params,
            sourceKey: k
          });
        });
      });
    }
    // 具有disable的依赖关系的收集
    if (item.property?.disabledRely) {
      const s = item.property.disabledRely;
      rules.push({
        ruleType: 'disable',
        sourceKey: s.relyItem,
        sourceValue: s.relyValue ? (Array.isArray(s.relyValue) ? s.relyValue : [s.relyValue]) : [],
        disable: s.isDisabled || false
      });
    }
    // 依赖关系的显示
    if (item.property?.relyOn) {
      rules.push({
        sourceKey: item.property?.relyOn.relyItem,
        sourceValue: Array.isArray(item.property?.relyOn.relyValue)
          ? item.property?.relyOn.relyValue
          : [item.property?.relyOn.relyValue],
        ruleType: 'show'
      });
    }
    // 依赖隐藏的关系
    if (item.property?.hideRely) {
      rules.push({
        sourceKey: item.property?.hideRely.relyItem,
        sourceValue: Array.isArray(item.property?.hideRely.relyValue)
          ? item.property?.hideRely.relyValue
          : [item.property?.hideRely.relyValue],
        ruleType: 'hide'
      });
    }
    return {
      type: item.property?.isHide
        ? formModuleItemType['hide']
        : formModuleItemType[item.type] || item.type,
      label: item.title,
      key: item.name,
      validNames: [!item.property?.isHide && item.required ? 'required' : '', item.type],
      options:
        option?.map((v) => {
          return {
            value: v.value,
            label: v.title
          };
        }) ?? [],
      defaultValue: item.initial || '',
      disabled: item.property?.isHide || !canEdit || item.property?.useDefault || false,
      placeholder: item.property?.placeholder || undefined,
      dateConfig: {
        canChoose:
          item.property?.dateRangers?.map((s) => ({
            dateBefore: s.dateBefore,
            dateAfter: s.dateAfter,
            canPlay: s.canPlay || true,
            dateRanger: s.dateRanger
          })) ?? [],
        endKey: 'endKey',
        startKey: 'startKey'
      },
      dictionaryName: item.sourceValue ?? undefined,
      renderConfig: item,
      attr: {
        maxLength: item.length ?? ''
      },
      params: {
        unit: item.unit === 'none' ? '' : item.unit,
        option: item.params,
        formatter: item.property?.dateFormat,
        max: item.property?.numberRanger?.max,
        min: item.property?.numberRanger?.min,
        type: item.property?.numberRanger?.type,
        beforePoint: item.property?.numberRanger?.beforePoint,
        afterPoint: item.property?.numberRanger?.afterPoint
      },
      rules,
      tip: item.tip,
      uploadConfig,
      linkageConfig,
      actions:
        item.actions?.map((s) => {
          return {
            label: s.name,
            type: s.type,
            value: s.value
          };
        }) ?? []
    };
  });
  return {
    name: tabName ? tabName + '/form' : 'form',
    type: 'form',
    params: {
      parentConfig: {
        disabled: !canEdit,
        labelWidth: '180px',
        inline: false,
        labelPosition: 'right',
        showBtn: false,
        dictionary: dictionaryNames
      },
      itemData
    }
  };
};

/**
 * 将表单项处理成表格的配置
 * */
const transformTableConfig = (step: ResSte, item: ResItems[], canEdit = true): ModuleItem => {
  const tableHead: TableColumn[] = [];
  const tablePaginationAction: Btns[] = [];
  item.forEach((v) => {
    const { item, option } = v;
    if (item.property?.isHide || item.property?.tableHide) {
      tableHead.push({
        type: 'hide',
        key: item.name,
        label: item.title,
        params: {
          renderParams: item
        }
      });
      return;
    }
    let type = formModuleTableType[item.type] || item.type;
    const params: any = {
      renderParams: item
    };
    if (item.sourceType === 'mapping') {
      type = 'expansion';
      params.mapping = item.params?.responseMapping ?? null;
      params.sourceValue = item.sourceValue;
    }
    if (type === 'mapText') {
      if (item.sourceType === 'dictionary') {
        Object.assign(params, {
          type: 'dictionary',
          dictionaryName: item.sourceValue
        });
      }
      if (item.sourceType === 'option') {
        Object.assign(params, {
          type: 'local',
          localData: {}
        });
        option?.forEach((v) => {
          params.localData[v.value] = v.title;
        });
      }
      if (item.sourceType === 'business') {
        Object.assign(params, {
          type: 'business',
          sn: item.sourceValue,
          responseMapping: {
            label: item.params?.responseMapping?.label ?? '',
            value: item.params?.responseMapping?.code ?? ''
          },
          requestParams: item.params?.requestParams
        });
      }
      if (item.type === 'switches') {
        Object.assign(params, {
          type: 'local',
          localData: {
            true: '是',
            false: '否'
          }
        });
      }
    }
    if (type === 'rangeText' && item.type === 'dateRange') {
      Object.assign(params, {
        startKey: 'startKey',
        endKey: 'endKey',
        formatter: 'dateTime'
      });
    }
    if (type === 'formatter' && item.type === 'date') {
      Object.assign(params, {
        formatter: 'dateTime',
        formatterType: 'YYYY-MM-DD HH:mm:ss'
      });
    }
    if (type === 'formatter' && item.type === 'number') {
      Object.assign(params, {
        formatter: 'price'
      });
    }
    let width;
    if (item.property && item.property.gridWidth) {
      width = item.property.gridWidth;
    } else if (type === 'image') {
      width = 150;
    }
    if (type === 'image') {
      params.width = '50px';
      params.height = '50px';
    }
    tableHead.push({
      type,
      align: item.type === 'number' ? 'right' : 'left',
      key: item.name,
      label: item.title,
      params,
      width
    });
  });
  const businessDialog: Array<GridButton | ResSteAction> = [];
  if (step.property?.gridButtons) {
    const actions: Btns[] = [];
    if (canEdit) {
      step.property?.gridButtons.forEach((v) => {
        // 根据后台表单配置的规则，是否需要展示.优先级高于show
        const attr: { show?: 'always' | 'rule'; rules?: BtnShowRule[] } = {};
        if (v?.showRely) {
          attr['show'] = 'rule';
          attr['rules'] = [
            {
              // 表格中控制按钮展示的key
              columnKey: v.showRely.relyItem.split('.')[1],
              // 表格中控制按钮展示的key对应的值， 就是说某个key的值是这个时，按钮展示
              columnValue: v.showRely.relyValue.join('|')
            }
          ];
        }
        switch (v.type) {
          case 'info':
            actions.push({
              label: v.name,
              emit: 'detail',
              btnConfig: v,
              ...attr
            });
            break;
          case 'delete':
            tablePaginationAction.push({
              label: '删除',
              emit: 'delete',
              type: 'danger',
              params: {
                tip: v.tip
              },
              btnConfig: v,
              ...attr
            });
            actions.push({
              label: v.name,
              emit: 'deleteItem',
              params: {
                tip: v.tip
              },
              btnConfig: v,
              ...attr
            });
            break;
          case 'edit':
            if (v.formDefSn && v.businessSnMapping) {
              actions.push({
                type: 'tableEdit',
                label: v.name,
                emit: 'edit',
                params: {
                  defSn: v.formDefSn,
                  dataSnKey: v.businessSnMapping
                },
                btnConfig: v
              });
            } else {
              actions.push({
                label: v.name,
                emit: 'edit',
                btnConfig: v
              });
            }
            break;
          case 'custom':
            actions.push({
              label: v.name,
              emit: 'custom',
              params: {
                tip: v.tip
              },
              btnConfig: v,
              ...attr
            });
            businessDialog.push(v);
            break;
          case 'sort':
            actions.push({
              label: '上移',
              emit: 'moveUp'
            });
            actions.push({
              label: '下移',
              emit: 'moveDown'
            });
            break;
        }
      });
    } else {
      const infoBtn = step.property?.gridButtons.filter((s) => s.type === 'info');
      infoBtn.forEach((v) => {
        const attr: { show?: 'always' | 'rule'; rules?: BtnShowRule[] } = {};
        if (v?.showRely) {
          attr['show'] = 'rule';
          attr['rules'] = [
            {
              // 表格中控制按钮展示的key
              columnKey: v.showRely.relyItem.split('.')[1],
              // 表格中控制按钮展示的key对应的值， 就是说某个key的值是这个时，按钮展示
              columnValue: v.showRely.relyValue.join('|')
            }
          ];
        }
        actions.push({
          label: v.name,
          emit: 'detail',
          btnConfig: v,
          ...attr
        });
      });
    }
    tableHead.push({
      type: 'handle',
      label: '操作',
      actions,
      params: {}
    });
  }
  if (step.actions?.length) {
    step.actions.forEach((s) => {
      if (s.type === 'select') {
        businessDialog.push(s);
      }
    });
  }
  return {
    type: 'form-module-table',
    name: 'form',
    params: {
      def: step,
      tip: [step.property?.tip],
      canEdit: canEdit,
      table: {
        items: [
          {
            type: 'table',
            tableConfig: {
              summary: Boolean(step.property?.gridTotalKeys?.length ?? 0),
              summaryShowKeys: step.property?.gridTotalKeys ?? [],
              // 是否启用扩展展示
              isExpand: step.property?.gridCanSpread ?? false,
              // 扩展展示的组件
              templateName: step.property?.gridSpreadConfig?.component ?? ''
            },
            tableHead,
            actions: tablePaginationAction
          }
        ]
      },
      config: {
        isExpand: step.property?.gridCanSpread ?? false,
        spreadKey: step.property?.gridSpreadConfig?.unionKey
      },
      actions: step.actions ?? [],
      form: transformFormConfig(item).params,
      businessDialog,
      requiredLength: step.property?.gridAtLeastCount ?? 0
    }
  };
};

/**
 * 处理插槽的配置
 * */
const transformSlotConfig = ({ step }: ResStep): ModuleItem => {
  return {
    name: 'form',
    type: 'form-slot-module',
    params: {
      componentName: step.property?.component,
      config: step
    }
  };
};

/**
 * 生成详情模式。显示成一列，而不是tab
 * */
const buildDetail = (item: ResStep): ModuleItem => {
  let children: ModuleItem;
  switch (item.step.formType) {
    case 'custom':
      children = transformSlotConfig(item);
      break;
    case 'grid':
      children = transformTableConfig(item.step, item.items, false);
      break;
    case 'form':
      children = transformFormConfig(item.items, false);
      break;
  }
  return {
    type: 'card',
    name: item.step.key,
    params: {
      title: item.step.name
    },
    children: [children]
  };
};

/**
 * 对表单项进行排序
 * */
const sortItem = (items: ResItems[]): void => {
  items.sort((a, b) => a.item.sort - b.item.sort);
};

/**
 * 对表单项进行排序
 * */
const sortStep = (items: ResStep[]): void => {
  items.sort((a, b) => a.step.sort - b.step.sort);
};

/**
 * 对tabs进行处理，并顺便处理tabs下的表单区域
 * */
const buildTab = (item: ResStep, index: number, type: TabType): ModuleItem => {
  let children: ModuleItem[] | null = null;
  // 先对组件内的item进行排序如果有item的话
  if (Array.isArray(item.items) && item.items.length > 0) {
    sortItem(item.items);
  }
  switch (item.step.formType) {
    case 'custom':
      children = [transformSlotConfig(item)];
      break;
    case 'grid':
      children = [transformTableConfig(item.step, item.items, item.step.property?.canEdit)];
      break;
    case 'form':
      children = [transformFormConfig(item.items, item.step.property?.canEdit)];
      break;
  }

  const tabItem: ModuleItem = {
    type: 'tab-module-item',
    name: item.step.key,
    params: {
      title: item.step.name,
      value: item.step.key,
      disable: index > 0 && (type === 'tab_step' || type === 'guide'),
      isHide: item.step.property?.isHide ?? false
    },
    children: children ? children : undefined
  };
  return tabItem;
};

/**
 * 切换配置数据
 * */
export const configTransform = (
  config: ResConfig,
  hasWrap = false,
  wrapConfig: WrapConfig,
  isDetail = false
): {
  moduleConfig: ModuleItem[];
  tabKeys: string[];
  saveQuery: Record<string, any>;
  submitConfirms: { name: string; config: SubmitBeforeConfig }[];
} => {
  let result: ModuleItem[];
  const tabKeys: string[] = [];
  const submitConfirms: { name: string; config: SubmitBeforeConfig }[] = [];
  const { def, steps } = config;
  const saveQuery: Record<string, any> = {};
  if (isDetail) {
    sortStep(steps);
    result = steps
      .filter((s) => !s.step.property?.isHide)
      .map((v, i) => {
        tabKeys.push(v.step.key);
        return buildDetail(v);
      });
  } else {
    const defaultKey = steps.filter((s) => !s.step.property?.isHide);
    sortStep(steps);
    result = [
      {
        type: 'tab-module',
        name: 'tab',
        params: {
          defaultActive: defaultKey[0].step.key
        },
        children: steps.map((v, i) => {
          if (v.step.property?.beforeConfig) {
            submitConfirms.push({
              name: v.step.key,
              config: v.step.property.beforeConfig
            });
          }
          tabKeys.push(v.step.key);
          return buildTab(v, i, def.stepType);
        })
      }
    ];
  }
  if (hasWrap) {
    result = [
      {
        name: 'wrap',
        type: 'wrap-module',
        params: wrapConfig,
        children: result
      }
    ];
  }
  if (def.params?.requestParams) {
    Object.keys(def.params?.requestParams).forEach((v) => {
      const item = def.params?.requestParams?.[v];
      if (item.type === 'original') {
        saveQuery[v] = item.value;
      }
    });
  }
  return {
    moduleConfig: result,
    tabKeys,
    saveQuery,
    submitConfirms
  };
};
