import {
  defineComponent,
  ref,
  PropType,
  nextTick,
  h,
  resolveComponent,
  readonly,
  inject
} from 'vue';
import kmjsTable, { useTable } from '@/components/table/code';
import { CtlFun } from '@/components/form';
import kmjsWrap from '@/components/wrap/index.vue';
import { buildBtn } from '@/components/utils/buildTsx/btn';
import { ElMessageBox } from 'element-plus';
import { resisterModule } from '@/components/modules/hooks/moduleRegister';
import { Btns } from '@/components/utils/commonType';
import addFormDialog from '@/formModule/components/table/addFormDialog';
import { TableColumn } from '@/components/table/kmjsTableType';
import { useRouter } from 'vue-router';
import { goToFormCreate, goToFormDetail } from '@/pages/commonPage/index';
import { formatterStrArrByObj, formatterStrByObj, getChainData } from '@/utils';
import { add, subtract, multiply, divide, isObject, isString } from 'lodash';

export default defineComponent({
  name: 'form-module-table',
  props: {
    params: {
      type: Object as PropType<RenderTableConfig>,
      default: () => {
        return {};
      }
    },
    moduleName: {
      type: String as PropType<string>,
      default: ''
    }
  },
  components: {
    kmjsWrap,
    kmjsTable,
    addFormDialog
  },
  setup(props) {
    const tabKey = inject<string>('tabKey', '');
    const tabGridDetail = inject<Record<string, FormatTabGridDetail>>('tabGridDetail', {});
    const router = useRouter();
    let editCurrent: Record<string, any> | null = null;
    let formCtl: CtlFun;
    // 弹窗渲染依赖的部分数据
    const dialogRenderData = ref<Record<string, any>>({});
    const dialogRequestData = ref<Record<string, any>>({});
    const dialogTableData = ref<Record<string, any>>({});
    // 记录当前用户点击的按钮配置
    const activeBtn = ref<ResSteButtons | null>(null);
    // 获取表单控件的配置项
    const getFormCtl = (ctl: CtlFun) => {
      formCtl = ctl;
    };
    /**
     * 计算表格数据的json，用以后续的列表填入逻辑
     * */
    const tableHeadKeys = () => {
      const data: string[] = [];
      props.params.table.items[0].tableHead.forEach((s: TableColumn) => {
        if (s.key) {
          data.push(s.key);
        }
      });
      if (props.params.table.items?.[0]?.tableConfig.isExpand) {
        data.push('childrenData');
      }
      return data;
    };
    // 显示普通的新增表单弹窗
    const showAddModel = ref(false);
    // 显示走表单系统的表单弹窗
    const showAddFromModel = ref(false);
    // 显示选择列表的弹窗
    const showAddListModel = ref<Record<string, boolean>>({});
    // 表格的数据
    const tableData = ref<Record<string, unknown>[]>([]);
    /**
     * @info 数据上移下移逻辑
     * @param data 当前需要移动的数据
     * @param flag 需要移动的方向 正1负1
     * */
    const moveUpOrDown = (data: Record<string, any>, flag = 1) => {
      const index = tableData.value.findIndex((s) => s === data);
      let newIndex = index + flag;
      if (!tableData.value[newIndex]) return;
      while (tableData.value[newIndex]?.isDelete) {
        newIndex += flag;
      }
      tableData.value[index] = tableData.value[newIndex];
      tableData.value[newIndex] = data;
      setTableData();
    };
    /**
     * 表格显示的控制
     * */
    const [tableCtl, tableMethods] = useTable({
      tableHandler: (name, data) => {
        switch (name) {
          case 'tableDelete':
            if (Array.isArray(data[0]) && data[0].length === 0) {
              return;
            }
            ElMessageBox.confirm(
              data[1].params?.tip
                ? formatterStrArrByObj(data[1].params?.tip, data[0])
                : '删除后无法恢复',
              '确认删除？'
            ).then(() => {
              let rules: { key: string; values: string[] }[] = [];
              // 增加规则校验，是否可以删除，这里获取删除的规则
              if (data[1]?.show === 'rule') {
                if (data[1].rules && Array.isArray(data[1].rules)) {
                  rules = data[1].rules.map((r: { columnValue: string; columnKey: string }) => {
                    const values = r.columnValue.split('|');
                    return { key: r.columnKey, values: values };
                  });
                }
              }
              data[0].forEach((v: Record<string, string>) => {
                // 判断是否可以被删除,没有rules可以删除
                const isCanDelete =
                  rules.length === 0
                    ? true
                    : rules.some((item) => {
                        return item.values.indexOf(v[item.key]?.toString()) > -1;
                      });
                if (isCanDelete) {
                  const index = tableData.value.findIndex((s: unknown) => s === v);
                  tableData.value[index].isDelete = true;
                }
              });
              if (data[1] && data[1].btnConfig) {
                activeBtn.value = data[1].btnConfig;
              }
              setTableData();
              if (data[1] && data[1].btnConfig) {
                activeBtn.value = null;
              }
            });
            break;
          case 'tableDeleteItem':
            ElMessageBox.confirm(
              data[1].params?.tip
                ? formatterStrByObj(data[1].params?.tip, data[0].row)
                : '删除后无法恢复',
              '确认删除？'
            ).then(() => {
              data[0].row.isDelete = true;
              if (data[0] && data[0].btnConfig && data[0].btnConfig.btnConfig) {
                activeBtn.value = data[0].btnConfig.btnConfig;
              }
              setTableData();
              if (data[0] && data[0].btnConfig.btnConfig) {
                activeBtn.value = null;
              }
            });
            break;
          case 'tableDetail':
            goToFormDetail(
              data[1].btnConfig.value.split('|')[0],
              getChainData(data[0].row, data[1].btnConfig.value.split('|')[1])
            );
            break;
          case 'tableEdit':
            editCurrent = data[0].row;
            showAddWindow(data[1].label);
            nextTick().then(() => {
              formCtl?.setData({ ...data[0].row });
            });
            break;
          case 'tableCustom':
            editCurrent = data[0].row;
            data[1].btnConfig.params = data[1].btnConfig;
            handler('custom', {
              label: '',
              params: data[1].btnConfig,
              type: 'text',
              emit: ''
            });
            break;
          case 'tableMoveUp':
            console.log('tableMoveUp');
            moveUpOrDown(data[0].row, -1);
            break;
          case 'tableMoveDown':
            console.log('tableMoveDown');
            moveUpOrDown(data[0].row, 1);
            break;
        }
      }
    });
    // 过滤没有被删除标记的数据，用以显示
    const setTableData = () => {
      const data = tableData.value.filter((s) => !s.isDelete);
      // 设置值的时候,触发其他副作用更新;
      effectFormTableData(data);
      tableMethods.setTableData(data);
      formModuleEvents?.change(tabKey, '', data);
    };

    // 触发影响其他tab的逻辑
    function effectFormTableData(data: Array<any>) {
      // 计算当前数据修改时,会影响的其他数据;
      const keyMapping = activeBtn.value?.callback;
      const keyMappings = Object.keys(keyMapping || {});
      keyMappings.forEach((key) => {
        if (tabGridDetail[key]?.isGrid === true && tabKey !== key) {
          // 非当前tab && 表格;合同管理时需要,所以先实现
          const v = keyMapping?.[key];
          const lists = JSON.parse(JSON.stringify(data));
          const unionKey = tabGridDetail[key]?.unionKey;
          // 有其他tab的联系;
          if (v && typeof v !== 'string') {
            const setData: Array<Record<string, any>> = [];
            const oldData = formModuleEvents?.getData(key, '');
            const format: Array<{ sourceFormKey: string; businessFormKey: string }> = Object.keys(
              v
            ).map((key) => {
              return {
                sourceFormKey: key,
                businessFormKey: (v?.[key] || '') as string
              };
            });
            let tableKey = '';
            // 计算表格字段放在业务数据的那里
            format.forEach((item) => {
              if (
                typeof item.businessFormKey === 'string' &&
                item.businessFormKey.indexOf('.') !== -1
              ) {
                const strList = item.businessFormKey.split('.');
                tableKey = strList[0];
              }
            });
            lists.forEach((businessData: Record<string, any>) => {
              if (tableKey && Array.isArray(businessData[tableKey])) {
                setData.push(
                  ...businessData[tableKey].map((dataItem: any) => {
                    format.forEach((mapItem) => {
                      // 与业务数据映射
                      if (
                        typeof mapItem.businessFormKey === 'string' &&
                        mapItem.businessFormKey.indexOf('.') !== -1
                      ) {
                        const key = (mapItem.businessFormKey as string)
                          .split('.')
                          .slice(1)
                          .join('.');
                        dataItem[mapItem.sourceFormKey] = getChainData(dataItem, key);
                      } else {
                        dataItem[mapItem.sourceFormKey] = getChainData(
                          businessData,
                          mapItem.businessFormKey as string
                        );
                      }
                    });
                    return dataItem;
                  })
                );
              }
            });
            setData.forEach((newItem) => {
              oldData.forEach((oldItem: any) => {
                if (newItem[unionKey] === oldItem[unionKey]) {
                  Object.assign(newItem, oldItem);
                }
              });
            });
            if (JSON.stringify(oldData) === JSON.stringify(setData)) return;
            formModuleEvents?.setData(key, 'data', setData);
          }
        }
      });
    }

    /**
     * 获取列表弹窗中选中的数据 过滤已经在表格中存在的数据后，加入表格
     * @param list 选中的表格数据，由于业务表格中的字段和表单系统中的可能不一致，需要转换一下
     * */
    const getListValue = (list: any[]) => {
      const keyMapping = activeBtn.value?.callback;
      const keyMappings = Object.keys(keyMapping || {});
      const keyAction = activeBtn.value?.callbackAction ?? {};
      const filterKey = activeBtn.value?.params?.unionKey ?? 'sn';
      keyMappings.forEach((key) => {
        // 依赖类型是tab类型时;
        if (typeof tabGridDetail[key]?.isGrid === 'boolean') {
          // 是否当前tab,当前tab拍平就好;
          if (key === tabKey) {
            Object.assign(keyMapping, keyMapping?.[key] || {});
            delete keyMapping?.[key];
          }
        }
      });

      let bsKey = filterKey;
      if (keyMapping) {
        bsKey = (keyMapping?.[filterKey] as string) ?? 'sn';
      }
      list.forEach((v) => {
        // 先判断当前数据是否已经存在
        const index = tableData.value.findIndex((s) => !s.isDelete && s[filterKey] === v[bsKey]);
        // 处理后的值，添加到表格中
        const data: Record<string, any> = Object.assign({}, v);
        // 将业务数据的KEY和表单数据的KEY进行转换
        const item = index > -1 ? tableData.value[index] : null;
        tableHeadKeys().forEach((s) => {
          const actionType = keyAction[s];
          // 这里是表头的key
          let key: string | Record<string, string> | Record<string, string>[] = s;
          // 处理转换的值
          if (keyMapping) {
            // 这里转换成了业务数据的key
            key = keyMapping[s];
            // 处理映射关系是数组的时候，一般是业务数据是单独的字符串，但是表格需要一个数组格式
            // 比如说业务数据图片的数据结构是 image：'图片的url'
            // 而表单系统的数据结构是 image: [{ossId: '图片的url'}]
            // 对于以上的关系进行转换
            if (Array.isArray(key) && key.length) {
              // 结果转换成数组
              data[s] = [];
              const obj: Record<string, string> = {};
              // 数组的话，先考虑肯定只会有一个对象，里面是 表单key：业务数据key 对应关系
              Object.keys(key[0]).forEach((k: string) => {
                // 如果是字符串按照格式包裹一下
                const result: string = getChainData(
                  v,
                  (key as Record<string, string>[])[0][k]
                ) as string;
                obj[k] = result;
              });
              data[s].push(obj);
              return;
            }
            // 处理映射关系是对象的时候 一般是业务数据中多个字段是摊开的，但是表单需要聚合成一个对象
            // 比如说业务数据中时间期限是 start： 'xxx', end: 'xxxx', type: 'tiem' 等三个字段
            // 而表单系统的入参是 time: {start： 'xxx', end: 'xxxx', type: 'tiem}
            // 对于以上的关系进行转换
            if (typeof key === 'object' && Object.keys(key).length) {
              data[s] = {} as Record<string, any>;
              Object.keys(key).forEach((k) => {
                data[s][k] = getChainData(v, (key as Record<string, string>)[k]);
              });
              return;
            }
            if (key) {
              // todo 先处理简单的合并
              let bdata = getChainData(v, key as string);

              // 删除的值使用最新的
              const oldData = item?.isDelete ? '' : item?.[s] ?? '';
              let ndata;
              const acType = actionType?.type ?? 'cover';

              // 判断是否需要数学计算
              const math = ['add', 'subtract', 'divide', 'multiply'];
              if (math.includes(acType) && typeof bdata === 'string') {
                bdata = bdata.replace(/,/g, '');
              }
              switch (acType) {
                case 'add':
                  ndata = add(Number(bdata) || 0, Number(oldData) || 0);
                  break;
                case 'subtract':
                  ndata = subtract(Number(bdata) || 0, Number(oldData) || 0);
                  break;
                case 'divide':
                  ndata = divide(Number(bdata) || 0, Number(oldData) || 0);
                  break;
                case 'multiply':
                  ndata = multiply(Number(bdata) || 0, Number(oldData) || 0);
                  break;
                default:
                  // 展开的数据进行合并, 一般是数组时才处理
                  if (props.params.config.isExpand && s === 'children' && Array.isArray(bdata[s])) {
                    ndata = [];
                    (oldData as Record<string, any>)[s].forEach((ie: Record<string, unknown>) => {
                      const key = props.params.config.spreadKey;
                      const item = bdata[s].filter(
                        (v: Record<string, unknown>) => v[key] === ie[key]
                      );
                      if (item) {
                        ndata.push(item);
                      } else {
                        ndata.push(ie);
                      }
                    });
                  }
                  ndata = bdata;
                  break;
              }
              data[s] = ndata;
            }
          }
        });
        if (editCurrent) {
          Object.assign(editCurrent, data);
          return;
        }
        if (index > -1) {
          tableData.value.splice(index, 1, data);
        } else {
          tableData.value.push(data);
        }
      });
      setTableData();
      closeDialog();
      if (editCurrent) {
        editCurrent = null;
      }
    };
    // 递归获取业务数据对应的表单数据的key
    const recursionFindKey = (
      target: Record<string, any>,
      source: Record<string, any>,
      ctx = ''
    ) => {
      for (const targetKey in target) {
        if (isObject(target[targetKey])) {
          recursionFindKey(target[targetKey], source, `${ctx}${targetKey}.`);
        } else if (isString(target[targetKey])) {
          source[target[targetKey]] = `${ctx}${targetKey}`;
        }
      }
    };
    /**
     * 将表单中的数据中用以去重的组键整理出来， 用以选择器后续的反选择处理
     * */
    const buildSnKeyData = (): {
      snKey: string;
      snArr: string[];
      tableData: Array<Record<string, any>>;
      formToBusinessKeyMapping: Record<string, string>;
    } => {
      const keyMapping = activeBtn.value?.callback;
      const keyMappings = Object.keys(keyMapping || {});
      keyMappings.forEach((key) => {
        // 依赖类型是tab类型时;
        if (typeof tabGridDetail[key]?.isGrid === 'boolean') {
          // 是否当前tab,当前tab拍平就好;
          if (key === tabKey) {
            Object.assign(keyMapping, keyMapping?.[key] || {});
            delete keyMapping?.[key];
          }
        }
      });
      const formToBusinessKeyMapping: Record<string, string> = {};
      const filterKey = activeBtn.value?.params?.unionKey ?? 'sn';
      let bsKey = filterKey;
      if (keyMapping) {
        bsKey = (keyMapping?.[filterKey] as string) ?? 'sn';
        recursionFindKey(keyMapping, formToBusinessKeyMapping);
      }
      let snArr;
      if (props.params.table.items?.[0]?.tableConfig.isExpand) {
        snArr = tableData.value
          .filter((s) => !s.isDelete)
          .map((fData): string[] => {
            return (
              (fData['childrenData'] as Record<string, unknown>[])
                ?.filter((s) => !s.isDelete)
                ?.map((cData) => {
                  return cData[filterKey] as string;
                }) ?? []
            );
          })
          .flat();
      } else {
        snArr = tableData.value
          .filter((s) => !s.isDelete)
          .map((fData): string => {
            return fData[filterKey] as string;
          });
      }
      return {
        snKey: bsKey,
        snArr,
        tableData: tableData.value.filter((s) => !s.isDelete),
        formToBusinessKeyMapping
      };
    };
    /**
     * 清洗表格中的每一条数据，清除那些不再表格表头中包含的字段
     * */
    const clearTableData = (): Record<string, unknown>[] => {
      const tableKeys = tableHeadKeys();
      const data = tableData.value.map((s) => {
        const obj: Record<string, unknown> = {};
        tableKeys.forEach((k) => {
          obj.isDelete = s.isDelete ?? false;
          obj.sort = s.sort ?? null;
          obj[k] = s[k];
        });
        return obj;
      });
      return data;
    };
    // 对外暴露接口
    const ctlFuns = {
      getData() {
        const arr = clearTableData().filter((s) => !s.isDelete);
        if (arr.length < props.params.requiredLength) {
          return Promise.reject(`[${props.params.def.name}] 数据有误，请完善`);
        }
        arr.forEach((s, i) => {
          s.sort = i;
        });
        return Promise.resolve([...arr]);
      },
      getNoVerifyData() {
        return clearTableData();
      },
      setData(data: { data: string | any[] }) {
        let arrData: any[];
        if (typeof data.data === 'string') {
          try {
            arrData = JSON.parse(data.data);
          } catch (e) {
            arrData = [];
          }
        } else {
          arrData = data.data;
        }
        if (Array.isArray(arrData)) {
          tableData.value = [...arrData];
        } else {
          tableData.value = [];
        }
        setTableData();
      }
    };
    // 注册成module支持的组件
    const { formModuleEvents } = resisterModule(props.moduleName, ctlFuns);
    /**
     * 显示新增表单弹窗
     * */
    const showAddWindow = (title: string) => {
      if (!activeBtn.value) {
        activeBtn.value = {
          name: '',
          title: '',
          params: {
            renderParams: {},
            requestParams: {},
            selectMode: 'single',
            unionKey: ''
          },
          type: 'normalInsert',
          value: ''
        };
      }
      activeBtn.value.title = title;
      showAddModel.value = true;
    };
    /**
     * 隐藏隐藏表单弹窗
     * */
    const hideAddModel = () => {
      activeBtn.value = null;
      editCurrent = null;
      formCtl?.reset();
      nextTick(() => {
        showAddModel.value = false;
      });
    };
    /**
     * 获取表单输入的值
     * */
    const confirmModel = async () => {
      const data = await formCtl?.getData();
      if (!data) return;
      if (editCurrent) {
        Object.assign(editCurrent, { ...data });
      } else {
        tableData.value.push({ ...data });
      }
      setTableData();
      hideAddModel();
    };
    // 监听按钮点击触发对应的逻辑
    const handler = (type: string, config: Btns) => {
      activeBtn.value = config.params as ResSteButtons;
      if (activeBtn.value?.params?.renderParams) {
        dialogRenderData.value = {};
        Object.keys(activeBtn.value.params.renderParams).forEach((s) => {
          const item = activeBtn?.value?.params?.renderParams[s];
          if (item.type === 'mapping') {
            const keys = item.value.split('.');
            const formData = formModuleEvents?.getData(keys[0], keys[1]);
            dialogRenderData.value[s] = getChainData(formData, keys.slice(2).join('.'));
          } else if (item.type === 'gridRow') {
            const [tabKey, ...keys] = item.value.split('.');
            dialogRenderData.value[s] = getChainData(editCurrent, keys.join('.'));
          } else {
            dialogRenderData.value[s] = item.value;
          }
        });
      }
      if (activeBtn.value?.params?.requestParams) {
        dialogRequestData.value = {};
        Object.keys(activeBtn.value.params.requestParams).forEach((s) => {
          const item = activeBtn?.value?.params?.requestParams[s];
          if (item.type === 'mapping') {
            const keys = item.value.split('.');
            let value = '';
            const formData = formModuleEvents?.getData(keys[0], keys[1]);
            // 判断是否是表格的
            if (Array.isArray(formData)) {
              value = formData
                .map((s: Record<string, any>) => {
                  return getChainData(s, keys.slice(2).join('.'));
                })
                .join(',');
            } else {
              value = getChainData(formData, keys.slice(2).join('.'));
            }
            // 过滤没有值的参数
            if (value) dialogRequestData.value[s] = value;
          } else {
            dialogRequestData.value[s] = item.value;
          }
        });
      }
      dialogTableData.value = buildSnKeyData();
      switch (type) {
        case 'normalInsert':
          // 基本表单添加
          showAddWindow(activeBtn.value.title);
          break;
        case 'navigate':
          if (activeBtn.value.value === 'formCreate') {
            return goToFormCreate(activeBtn.value.params?.requestParams.defSn.value);
          }
          // 跳转新的页面进行添加
          router.push({
            name: activeBtn.value.value,
            query: activeBtn.value.params?.requestParams
          });
          break;
        case 'select':
          showAddListModel.value[activeBtn.value.value] = true;
          break;
        case 'custom':
          showAddListModel.value[activeBtn.value.value] = true;
          break;
      }
    };
    // 关闭所有的弹窗
    const closeDialog = () => {
      showAddFromModel.value = false;
      showAddModel.value = false;
      Object.keys(showAddListModel.value).forEach((s) => {
        showAddListModel.value[s] = false;
      });
    };

    return () => {
      // 对列表选择器进行引入
      const dialogList = props.params.businessDialog.map((s) => {
        if (typeof showAddListModel.value[s.value] === 'undefined') {
          showAddListModel.value[s.value] = false;
        }
        const component = resolveComponent('form-module-business-' + s.value);
        if (typeof component === 'string') {
          return null;
        }
        return h(
          // eslint-disable-next-line
          // @ts-ignore
          component,
          {
            params: s,
            modelValue: showAddListModel.value[s.value],
            tableData: readonly(dialogTableData.value),
            renderData: readonly(dialogRenderData.value),
            requestData: readonly(dialogRequestData.value),
            onCloseDialog: closeDialog,
            onGetValue: getListValue
          }
        );
      });
      const tips = props.params.tip.map((s) => {
        if (!s) return null;
        return (
          <el-alert title={s.title} type={s.type || 'info'} show-icon closable={false}></el-alert>
        );
      });
      return (
        <kmjsWrap
          params={{
            hideBack: true,
            title: ''
          }}
          v-slots={{
            actions: () => {
              if (props.params.canEdit) {
                return props.params.actions.map((v: ResSteButtons) =>
                  buildBtn(
                    {
                      label: v.name,
                      emit: v.type,
                      params: v as unknown as Record<string, unknown>
                    },
                    handler,
                    undefined,
                    'mini'
                  )
                );
              }
            }
          }}
        >
          <div class="form-module-table-area">
            <div class="tips-wrap">{tips}</div>
            <div class="form-module-table-wrap">
              <kmjs-table ctl={tableCtl} params={props.params.table} />
            </div>
          </div>
          <el-dialog
            title={activeBtn.value?.title ?? ''}
            v-model={showAddModel.value}
            onClose={hideAddModel}
            destroy-on-close
            custom-class="module-dialog-wrap"
            v-slots={{
              footer: () => {
                return (
                  <el-space>
                    <el-button onClick={hideAddModel}>取消</el-button>
                    <el-button type={'primary'} onClick={confirmModel}>
                      确认
                    </el-button>
                  </el-space>
                );
              }
            }}
          >
            <kmjs-form params={props.params.form} getCtlFun={getFormCtl}></kmjs-form>
          </el-dialog>
          {dialogList}
        </kmjsWrap>
      );
    };
  }
});
