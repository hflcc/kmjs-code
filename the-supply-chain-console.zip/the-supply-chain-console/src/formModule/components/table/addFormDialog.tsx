/**
 * 直接调用新增加表单， 本质上直接使用表单模块
 * */

import { defineComponent, PropType, ref } from 'vue';
import { useDialog } from '@/utils';
import FormModule, { FormCtl, useModule } from '@/formModule';

export default defineComponent({
  name: 'form-module-table-form-dialog',
  props: {
    title: {
      type: String as PropType<string>,
      default: ''
    },
    modelValue: {
      type: Boolean as PropType<boolean>,
      default: false
    },
    sn: {
      type: String as PropType<string>,
      default: ''
    }
  },
  emits: ['closeDialog', 'update:modelValue'],
  setup(props, { emit }) {
    const formCtl = ref<null | FormCtl>(null);
    let methods: FormModuleMethods;
    const { showDialog, closeWindow } = useDialog(props, emit, (v: boolean) => {
      if (v) {
        const [ctl, med] = useModule({
          params: {
            defSn: props.sn,
            type: 'create',
            hideWrap: true
          }
        });
        formCtl.value = ctl;
        methods = med;
      } else {
        formCtl.value = null;
      }
    });
    const getData = async () => {
      const data = await methods?.submitData();
      console.log(data);
    };
    return {
      formCtl,
      showDialog,
      closeWindow,
      getData
    };
  },
  render() {
    const { formCtl, title, showDialog, closeWindow, getData } = this;
    const formMdule = formCtl ? <FormModule ctl={formCtl}></FormModule> : null;
    return (
      <el-dialog
        title={title}
        v-model={showDialog}
        onClose={closeWindow}
        v-slots={{
          footer: () => {
            return (
              <el-space>
                <el-button onClick={closeWindow}>取消</el-button>
                <el-button type={'primary'} onClick={getData}>
                  确认
                </el-button>
              </el-space>
            );
          }
        }}
      >
        {formMdule}
      </el-dialog>
    );
  }
});
