import { defineComponent, PropType, h, resolveComponent } from 'vue';

export default defineComponent({
  name: 'form-slot-module',
  props: {
    moduleName: {
      type: String as PropType<string>,
      default: ''
    },
    params: {
      type: Object as PropType<{ componentName: string; config: ResSte }>,
      required: true
    }
  },
  setup(props) {
    return () => {
      const formModuleItem = resolveComponent('form-module-item-' + props.params.componentName);
      if (typeof formModuleItem === 'string') return null;
      return h(formModuleItem, {
        config: props.params.config,
        moduleName: props.moduleName
      });
    };
  }
});
