import { ModuleItem } from '@/components/utils/commonType';
import { h, VNode, resolveComponent } from 'vue';
import { Slot } from '@vue/runtime-core';

export default function loopBuild(
  moduleItem: ModuleItem,
  parentName = '',
  slots: { [name: string]: Slot | undefined }
): VNode[] | VNode {
  const slot: { [l: string]: (config: any) => VNode[] } = {};
  let children: (VNode | VNode[])[] = [];
  // 处理节点是slot的
  if (moduleItem.type === 'slot' && moduleItem.slotName) {
    children = slots[moduleItem.slotName]?.() || ([] as VNode[]);
    return children as VNode[];
  } else {
    // 如果存在子节点，先搞子节点
    if (Array.isArray(moduleItem.children)) {
      children = moduleItem.children.map((v: ModuleItem) =>
        loopBuild(v, parentName + '/' + moduleItem.name, slots)
      );
      children = children.flat(1);
    }
  }
  // 处理组件下的具名插槽
  if (Array.isArray(moduleItem.slotParam)) {
    moduleItem.slotParam.forEach((v: { name: string; slotName: string }) => {
      const slotVnode = slots[v.slotName];
      if (slotVnode) {
        slot[v.name] = slotVnode;
      }
    });
  }
  return h(
    // eslint-disable-next-line
    // @ts-ignore
    resolveComponent('kmjs-' + moduleItem.type),
    {
      moduleItem,
      params: moduleItem.params,
      actions: moduleItem.permissions,
      moduleName: (parentName ? parentName + '/' : '/') + moduleItem.name
    },
    {
      default: () => children,
      ...slot
    }
  );
}
