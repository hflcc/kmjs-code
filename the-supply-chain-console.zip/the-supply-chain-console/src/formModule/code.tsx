/**
 * 本地模式模块配置
 * */
import { defineComponent, PropType, provide, ref } from 'vue';
import { ModuleItem } from '@/components/utils/commonType';
import loopBuild from './loopBuild';
import tab from '@/components/modules/components/tabs';
import kmjsWrapModule from '@/components/wrap/module';
import { ModuleConfig } from '@/components/modules/module/useModule';
import { useModuleParent } from '@/components/modules/hooks/moduleRegister';
import kmjsFormModuleTable from './components/table';
import kmjsSlotModule from './components/slot';

export * from '@/components/modules/module/useModule';
export default defineComponent({
  name: 'module-table',
  props: {
    ctl: {
      type: Function as PropType<
        () => [ModuleConfig, { [moduleMethodName: string]: () => void }, ModuleItem[]]
      >,
      required: true
    }
  },
  components: {
    'kmjs-form-slot-module': kmjsSlotModule,
    'kmjs-tab-module': tab,
    'kmjs-tab-module-item': tab.Item,
    'kmjs-wrap-module': kmjsWrapModule,
    'kmjs-form-module-table': kmjsFormModuleTable
  },
  setup(props) {
    // 整个模块的配置项
    const config = ref<ModuleItem[]>([]);
    // 记录所有组件的对外方法，供外部调用
    let methods: { [moduleMethodName: string]: () => void } = {};
    let options: ModuleConfig = {};
    if (typeof props.ctl === 'function') {
      [options, methods, config.value] = props.ctl();
    }
    useModuleParent(methods, options.handler, options.params);
    provide('permission', null);
    return { config };
  },
  render() {
    const { config } = this;
    return (
      <div class="module-table-wrap page">
        {config.map((v) => {
          return loopBuild(v, '', this.$slots);
        })}
      </div>
    );
  }
});
