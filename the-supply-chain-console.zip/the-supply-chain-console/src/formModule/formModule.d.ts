type TabType = 'tab_freedom' | 'tab_step' | 'guide' | 'block';

interface SubmitBeforeConfig {
  dialog: string;
}

interface ResDef {
  // 表单定义sn
  sn: string;
  // 表单定义名称
  name: string;
  // tab_freedom自由Tab，tab_step步骤Tab，guide向导，block块状
  stepType: TabType;
  title: string;
  titleMapping: string;
  params?: {
    requestParams?: Record<string, any>;
  };
}

interface GridButton {
  name: string;
  type: string;
  value: string;
  formDefSn: string;
  businessSnMapping: string;
  tip?: string;
  showRely?: {
    relyItem: string;
    relyValue: string[];
  };
  callback: Record<string, any>;
}

interface ResProperty {
  // 针对表格和定制型：cert_info证件信息，open_account_info开户信息，contacts联系人，goods_property产品属性，goods_spec商品规格
  businessType: string;
  // 组件名 定制表单类型指定的组件名（slot的name）
  component: string;
  // 是否需要提交
  needSubmit: boolean;
  // 提交返回的sn
  resultSn: string;
  // 是否允许编辑 不允许直接进入详情模式
  canEdit: boolean;
  keyMapping?: string;
  buttons?: ResSteButtons[];
  tip: {
    title: string;
    type: string;
  };
  gridButtons?: GridButton[];
  gridTotalKeys?: string[];
  gridAtLeastCount?: number;
  // 表格状态唯一索引;
  unionKey: string;
  isHide?: boolean;
  gridCanSpread: boolean;
  gridSpreadConfig: {
    component: string;
    unionKey: string;
  };
  beforeConfig?: SubmitBeforeConfig;
}

/*
 * 格式化之后,form的表格展示状态的详细信息;
 * isGrid: 是否表格
 * unionKey: 表格的唯一索引
 * */
interface FormatTabGridDetail {
  isGrid: boolean;
  unionKey: string;
}

interface ResSteButtons {
  callback?: Record<string, string | Record<string, string>>;
  callbackAction?: Record<
    string,
    {
      // cover("覆盖"), add("加法"), subtract("减法"), multiply("乘法"), divide("除法")
      type: 'cover' | 'add' | 'subtract' | 'multiply' | 'divide';
      value: string;
    }
  >;
  name: string;
  title: string;
  params?: {
    requestParams: Record<string, any>;
    renderParams: Record<string, any>;
    selectMode: 'multiple' | 'single';
    unionKey: string;
  };
  // normalInsert 普通新增，navigate 跳转页面新增，select 列表选择
  type: 'normalInsert' | 'navigate' | 'select';
  value: string;
}

interface ResSteAction {
  name: string;
  type: 'navigate' | 'select' | 'normalInsert';
  value: string;
  params: {
    selectMode: 'single' | 'multiple';
    requestParams: Record<string, any>;
  };
  callback: Record<string, string>;
}

interface ResSte {
  // 表单定义步骤sn
  sn: string;
  // 名称
  name: string;
  // 备注说明
  descr: string;
  // 类型 web app web+app
  type: string; // 'web' | 'app' | 'web+app';
  webUrl: string;
  // 排序
  sort: number;
  // form表单，grid表格，custom定制(slot)
  formType: 'form' | 'grid' | 'custom';
  // 步骤key
  key: string;
  // 步骤属性
  property?: ResProperty;
  actions?: ResSteAction[];
}

interface ExpansionsItem {
  key: string;
  value: string;
  type: string;
}

interface ResSubProperty {
  // 是否使用默认值 使用默认值（不可修改）有的话直接disable
  useDefault: boolean;
  // 样式属性  比如表格类型，列上展示的样式（需要前端确认）
  style: string;
  dateBefore?: number;
  dateAfter?: number;
  canPlay?: boolean;
  dateRangers?: {
    canPlay?: boolean;
    dateAfter?: number;
    dateBefore?: number;
    dateRanger?: string;
  }[];
  dateFormat?: string;
  isHide?: boolean;
  keyMapping?: string;
  limitCount?: number;
  relyOn?: {
    relyItem: string;
    relyValue: string[];
  };
  hideRely?: {
    relyItem: string;
    relyValue: string[];
  };
  disabledRely: {
    relyItem: string;
    relyValue?: string[];
    isDisabled?: boolean;
  };
  valueRely?: {
    method: 'add' | 'subtract' | 'multiply' | 'divide';
    params: string[];
  }[];
  callbackAnytime?: boolean;
  numberRanger?: {
    afterPoint?: number;
    beforePoint?: number;
    type: 'mapping';
    max: number | string;
    min: number | string;
  };
  gridWidth?: number;
  placeholder?: string;
  tableHide?: boolean;
  expansions: ExpansionsItem[];
  limitSize: number;
}

interface ResItem {
  sn: string;
  templateOssId: string | null;
  title: string;
  unit: string;
  name: string;
  type: EFromModuleItemType;
  // 如果属性设置使用默认值，则保存时取默认值
  initial: any;
  required: boolean;
  sort: number;
  property?: ResSubProperty;
  sourceType: 'none' | 'option' | 'dictionary' | 'business' | 'mapping' | 'selector';
  sourceValue: string;
  callback: Record<string, Record<string, string>>;
  checker?: string;
  tip: string;
  length?: number;
  params?: {
    selectMode: 'single' | 'multiple';
    selectAction?: 'init' | 'callback';
    requestParams?: Record<string, any>;
    responseMapping?: Record<string, string>;
  };
  actions?: {
    name: string;
    type: 'navigate' | 'refresh';
    value: string;
  }[];
}

interface ResOption {
  title: string;
  value: string;
}

interface ResItems {
  instance?: {
    sn: string;
    data: Record<string, unknown>;
  };
  item: ResItem;
  option: ResOption[] | null;
}

interface ResStep {
  step: ResSte;
  items: ResItems[];
}

interface ResConfig {
  def: ResDef;
  steps: ResStep[];
}

interface RenderTableConfig {
  def: ResSte;
  tip: {
    title: string;
    type: string;
  }[];
  businessDialog: Array<GridButton | ResSteAction>;
  canEdit: canEdit;
  table: TableConfig;
  actions: ResSteButtons[];
  form: { parentConfig: ParentConfig; itemData: FormItem[] };
  requiredLength: number;
  config: {
    spreadKey: string;
    isExpand: boolean;
  };
}

interface CallBackFun {
  // 不进行校验，直接返回表单数据
  saveDraft: () => Record<string, any>;
  // 校验后返回数据
  submitData: () => Promise<Record<string, any> | null>;
  setData: (data: Record<string, any>) => void;
  clearValidate: (data: Record<string, any>) => void;
  getData?: () => Record<string, any>;
}

interface FormModuleMethods extends CallBackFun {
  getInstanceSn: () => string;
  getCanEdit: () => boolean;
  getResConfig: () => ResConfig;
}

interface CurrentForm {
  name: string;
  methods: CallBackFun;
}

interface FormModuleEvents {
  // 监听变化
  onChange: (tabName: string, callBack: (tabName: string, key: string, data: any) => void) => void;
  // 子表单有值变化时主动触发
  change: (tabName: string, key: string, data: any) => void;
  // 子表单间互相修改指定tab下的表单内指定key的数据
  setData: (tabName: string, key: string, data: any) => void;
  //子表单间互相获取指定tab下的表单指定key的数据
  getData: (tabName: string, key: string) => any;
  // 刷新整个表单
  reloadForm: (data: Record<string, any>) => Promise<void>;
}
