<script lang="tsx">
  import { defineComponent, provide } from 'vue';
  import setPwd from '@/layout/components/setPassword/index';
  import zhCn from 'element-plus/lib/locale/lang/zh-cn';
  import emitt from 'emitt';

  export default defineComponent({
    components: {
      setPwd
    },
    setup() {
      /* 全局事件流 */
      const emitter = emitt();
      provide('eventOn', emitter.on);
      provide('eventEmit', emitter.emit);
      provide('eventOff', emitter.off);
      return () => {
        return (
          <el-config-provider locale={zhCn}>
            <router-view />
            <setPwd />
          </el-config-provider>
        );
      };
    }
  });
</script>
