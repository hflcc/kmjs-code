import 'dayjs/locale/zh-cn';
import dayjs from 'dayjs';
import { getChainData } from '@/utils/index';

dayjs.locale('zh-cn');

/**
 * 时间格式化 格式化成 指定的格式
 * @param value 需要格式化的时间
 * @param formatType 格式化规则 类似YYYY-MM-DD
 * */
export function formatterTimer(value: Date, formatType = 'YYYY-MM-DD'): string {
  return dayjs(value).format(formatType);
}

/**
 * 格式化时间，在本年内，显示 月-日 时:分:秒
 * 不在本年内显示 年-月-日 时:分:秒
 * */
export function formatterTime(value: Date): string {
  if (value.getFullYear() === new Date().getFullYear()) {
    return dayjs(value).format('MM-DD HH:mm:ss');
  } else {
    return dayjs(value).format('YYYY-MM-DD HH:mm:ss');
  }
}

/**
 * 格式化数学单位 10000 -> 1万
 * @param num 需要转换的数字
 * @return {string} 转换的字符串
 * */
export function formatterUnit(num: number): string {
  const units = ['亿', '万', '千'];
  const unitNum = [100000000, 10000, 1000];
  for (let i = 0; i < unitNum.length; i++) {
    if (num / unitNum[i] >= 1) {
      return num / unitNum[i] + units[i];
    }
  }
  return num.toString();
}

/**
 * 计算指定两个时间之间的时间差并格式化为对于的汉字时间 多少年 多少月 多少日 多少小时 多少分钟 多少秒
 * */
export function relativeTimeStr(startData: string | number, endDate: string | number) {
  let runTime = Math.floor((new Date(endDate).getTime() - new Date(startData).getTime()) / 1000);
  if (runTime < 0) return '--';
  const value: string[] = [];
  const year = Math.floor(runTime / 86400 / 365);
  if (year > 0) {
    value.push(year + '年 ');
  }
  runTime = runTime % (86400 * 365);
  const month = Math.floor(runTime / 86400 / 30);
  if (month > 0) {
    value.push(month + '月 ');
  }
  runTime = runTime % (86400 * 30);
  const day = Math.floor(runTime / 86400);
  runTime = runTime % 86400;
  if (day > 0) {
    value.push(day + '天 ');
  }
  const hour = Math.floor(runTime / 3600);
  runTime = runTime % 3600;
  if (hour > 0) {
    value.push((hour < 10 ? '0' + hour : hour) + ':');
  } else {
    value.push('00:');
  }
  const minute = Math.floor(runTime / 60);
  runTime = runTime % 60;
  if (minute > 0) {
    value.push((minute < 10 ? '0' + minute : minute) + ':');
  } else {
    value.push('00:');
  }
  const seconds = runTime;
  if (seconds > 0) {
    value.push((seconds < 10 ? '0' + seconds : seconds).toString());
  } else {
    value.push('00');
  }
  return value.join('');
}

/**
 * 将{code}类型从字符串中截取出来，并替换成code为真正的数据，目前是从默认从对象中取值
 * @param str 需要替换的字符串
 * @param object 需要提取数据的对象
 * */
export function formatterStrByObj(str: string, object: Record<string, any>): string {
  if (Object.keys(object).length === 0) return str;
  str = str.replaceAll('${', '{');
  // 先提取出来str中的{code}
  const codeArr = str.match(new RegExp('{.*?(?<=})', 'gi'));
  if (codeArr && codeArr.length) {
    let result = str;
    codeArr.forEach((v) => {
      const data = getChainData(object, v.replace('{', '').replace('}', ''));
      if (typeof data !== 'undefined') {
        result = result.replace(v, data.toString());
      }
    });
    return result;
  } else {
    return str;
  }
}

/**
 * 将{code}类型从字符串中截取出来，并替换成code为真正的数据[数据是一个数组]，目前是从默认从对象中取值
 * @param str 需要替换的字符串
 * @param object[] 需要提取数据的对象
 * */
export function formatterStrArrByObj(str: string, array: Record<string, any>[] = []): string {
  if (array.length === 0) return str;
  str = str.replaceAll('${', '{');
  // 先提取出来str中的{code}
  const codeArr = str.match(new RegExp('{.*?(?<=})', 'gi'));
  if (codeArr && codeArr.length) {
    let result = str;
    codeArr.forEach((v) => {
      const datas: string[] = [];
      array.forEach((s) => {
        const data = getChainData<string>(s, v.replace('{', '').replace('}', ''));
        datas.push(data);
      });
      result = result.replace(v, datas.join('、'));
    });
    return result;
  } else {
    return str;
  }
}

/**
 * 将数值四舍五入(保留2位小数)后格式化成金额形式
 * @param num 数值(Number或者String)
 * @return 金额格式的字符串,如'1,234,567.45'
 * */
export function formatterPrice(n: number) {
  if (!n || isNaN(n)) {
    return '0.00';
  }
  let num: string | number = n;
  // const sign = num === num = Math.abs(num);
  num = Math.floor(num * 100 + 0.50000000001);
  let cents: number | string = num % 100;
  num = Math.floor(num / 100).toString();
  if (cents < 10) cents = '0' + cents;
  for (let i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
    num =
      num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
  }
  return num + '.' + cents;
}

/**
 * 将数值四舍五入(保留n位小数)后格式化成金额形式
 * @param value 数值
 * @param suffix 后缀数
 * @return string
 * */
export function formatterNumber(value: number, suffix: number) {
  return suffix === 2 ? formatterPrice(value) : value.toFixed(suffix);
}

/**
 * 格式化数据前后保留 X 位数
 * @param {value} number 格式化的值
 * @param {beforePoint} number 前面几位
 * @param {afterPoint} number 后面几位
 * @return {number} 格式化后的值
 */
export function formatterValueBeforeOrAfterPoint(
  value: string,
  beforePoint: number | undefined,
  afterPoint: number | undefined
): string {
  // 转成字符串数据 => 1.1 => [1,1]
  const valueStringArray = value.split('.');
  // 前面的从后往前算
  if (typeof beforePoint === 'number' && valueStringArray[0]) {
    valueStringArray[0] = valueStringArray[0].slice(beforePoint * -1);
  }
  // 后面的从前往后算
  if (typeof afterPoint === 'number' && valueStringArray[1]) {
    valueStringArray[1] = valueStringArray[1].slice(0, afterPoint);
  }
  if (!valueStringArray[1]) {
    valueStringArray.splice(1, 1);
  }
  return valueStringArray.join('.');
}

/**
 * 格式化，最大值 最小值
 */
export function formatterValueMaxOrMin(
  value: string,
  max: number | undefined,
  min: number | undefined
): string {
  // 如果非数字，不处理[会被正则校验整数处理]
  if (isNaN(Number(value))) {
    return value;
  }
  if (!max) {
    max = 2147483647;
  }
  if (!min) {
    min = 0;
  }

  if (Number(value) > max) {
    return max + '';
  }
  if (Number(value) < min) {
    return min + '';
  }
  return value;
}

// 处理转义字段，转成空的
export function formatterEmptyUrl(url: string): string {
  const reg = /\${(.+?)}/g;
  let result = null;
  do {
    result = reg.exec(url);
    // console.log(result);
    if (result) url = url.replace(result[0], '');
  } while (result);
  return url;
}
