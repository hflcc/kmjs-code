import {
  computed,
  defineComponent,
  getCurrentInstance,
  inject,
  reactive,
  ref,
  watch,
  watchEffect,
  h,
  resolveComponent
} from 'vue';
import store from '@/store';
import { uploadFile as uploadAjax } from '@/utils/commApi';
import { ElForm, ElMessage } from 'element-plus';
import { RouteLocationNormalized, useRoute, useRouter } from 'vue-router';
import { getChainData } from '@/utils/index';
import router from '@/router';
import { Component, ConcreteComponent } from '@vue/runtime-core';

interface FileListItem {
  file?: File;
  seq?: string;
  type?: string;
}

export const useUploadFile = function (): {
  uploadFile: () => void;
  fileData: FileListItem;
} {
  const files = reactive<FileListItem>({ type: 'upload' });
  const uploadFile = () => {
    const aElem: HTMLInputElement = document.createElement('input');
    aElem.type = 'file';
    aElem.addEventListener('change', async function () {
      if (aElem.files && aElem.files[0]) {
        files.file = aElem.files[0];
        const res = await uploadAjax(aElem.files[0]);
        if (res) {
          files.seq = res.seq;
          files.type = 'done';
        }
      }
    });
    document.body.append(aElem);
    aElem.click();
    setTimeout(() => {
      document.body.removeChild(aElem);
    }, 400);
  };
  return {
    uploadFile,
    fileData: files
  };
};

// 处理弹窗展示与关闭
export const useDialog = (
  props: any,
  emit: (name: any, data: boolean) => void,
  callback?: (d: boolean) => void
) => {
  const showDialog = ref(props.modelValue);
  const closeWindow = () => {
    emit('update:modelValue', false);
    emit('closeDialog', false);
  };
  watch(
    () => props.modelValue,
    (v: boolean) => {
      showDialog.value = v;
      callback?.(v);
    },
    {
      immediate: true
    }
  );
  return {
    showDialog,
    closeWindow
  };
};

// 获取form的表单实例
export const useForm = () => {
  const formElem = ref<InstanceType<typeof ElForm> | null>(null);
  return {
    formElem
  };
};

/**
 * 处理列表页的数据和详情页面的数据的联动 配合上一个下一个
 * */
export const useListToDetail = (name: string) => {
  const setData = (data: any) => {
    store.commit('listToDetailModule/setListData', {
      name: name,
      data
    });
  };
  const listData = computed(() => store.getters['listToDetailModule/listData'](name));
  return {
    setData,
    listData
  };
};

export const useReload = (tabName?: string) => {
  const name = tabName ?? getCurrentInstance()?.type.name;
  const rd = inject<(name?: string) => void>('reload');
  return {
    reload() {
      rd?.(name);
    }
  };
};

/**
 * 处理上一个下一个切换逻辑
 * */
export const useSelect = (name: string) => {
  const route = useRoute();
  const router = useRouter();
  const { reload } = useReload();
  const { sn } = route.params;
  const { listData } = useListToDetail(name);
  const selectOption = computed(
    () =>
      listData.value?.map((v: string, i: number, array: string[]) => {
        return {
          value: v,
          label: `${i + 1}/${array.length}`
        };
      }) ?? [
        {
          value: sn,
          label: '1/1'
        }
      ]
  );
  /**
   * 处理上一个下一个
   * */
  const selectValue = ref(sn);
  /*
   * 获取到select选中的值
   * */
  const selectChange = (sn: string) => {
    router.replace({ name: route.name as string, params: Object.assign({}, route.params, { sn }) });
  };
  /*
   * 修改上一个或下一个的select的值
   * */
  const changeSelect = (step: number) => {
    const list = selectOption.value;
    if (list.length === 1) {
      ElMessage.info('没有啦');
      return;
    }
    const index = list.findIndex((s: { value: string }) => s.value === selectValue.value);
    const newSn = list[index + step];
    if (!newSn) {
      return ElMessage.info('没有啦');
    } else {
      router.replace({
        name: route.name as string,
        params: Object.assign({}, route.params, { sn: newSn.value })
      });
    }
  };
  watchEffect(() => {
    if (route.params.sn !== sn) {
      reload?.();
    }
  });
  return {
    sn,
    selectValue,
    selectOption,
    changeSelect,
    selectChange
  };
};

/**
 * 监听表单页面返回数据列表页面的刷新
 * */
export const useDEToLRefresh = () => {
  const route = useRoute();
  const eventOn = inject<((name: string, fn: () => void) => void) | null>('eventOn', null);
  const eventOff = inject<((name: string, fn: () => void) => void) | null>('eventOff', null);
  const setCallBack = (callBack: () => void): { b: string; c: string } => {
    const name = new Date().getTime().toString(16);
    const cf = () => {
      callBack();
      eventOff?.(name, cf);
    };
    eventOn?.(name, cf);
    return {
      b: route.name as string,
      c: name
    };
  };
  return {
    setCallBack
  };
};

// 参数转换
export const useRequestParams = (
  params: Record<string, any>,
  event: FormModuleEvents,
  tabGridDetail?: Record<string, FormatTabGridDetail>
): Record<string, any> => {
  const requestData: Record<string, any> = {};
  Object.entries(params).forEach(
    (
      s: [
        string,
        {
          type: 'base' | 'mapping';
          value: any;
        }
      ]
    ) => {
      if (s[1].type === 'mapping') {
        const [tabName, ...key] = s[1].value.split('.');
        if (tabGridDetail && tabGridDetail[tabName]?.isGrid) {
          const list = event.getData(tabName, '');
          // 已删除的过滤掉
          requestData[s[0]] = list
            .filter((d: { isDelete?: boolean }) => d.isDelete !== true)
            .map((item: Record<string, any>) => {
              return getChainData(item, key.join('.'));
            })
            .join(',');
        } else {
          requestData[s[0]] = event.getData(tabName, key.join('.'));
        }
      } else {
        requestData[s[0]] = s[1].value;
      }
    }
  );
  return requestData;
};

export const openNewTap = async (route: RouteLocationNormalized) => {
  const routeName = route.path.includes('_') ? route.path.split('_')[0].substr(1) : route.name;
  const currentRoute = router.getRoutes().find((s) => s.name === routeName);
  if (!currentRoute || (!currentRoute.meta.newTap && !currentRoute.meta.once)) {
    return router.replace({ name: 'noFind' });
  }
  const name = (routeName as string) + route.query[currentRoute?.meta.once as string];
  const item = router.getRoutes().find((s) => s.name === name);
  if (item) {
    router.push({ name, query: route.query });
    return name;
  }
  const components = currentRoute?.components;
  if (!components) return router.replace({ name: 'noFind' });
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  const com: { default: Component } = await components.default();
  const path = (routeName as string) + '_' + route.query[currentRoute?.meta.once as string];
  const component = defineComponent({
    name: name,
    components: {
      childComponent: com.default
    },
    render() {
      const cc = resolveComponent('childComponent');
      return h(cc);
    }
  });
  router.addRoute('rootRoute', {
    path: '/' + path,
    name: name,
    component: component,
    meta: {
      ...currentRoute?.meta,
      keepName: name
    }
  });
  router.push({ name, query: route.query });
  return name;
};
