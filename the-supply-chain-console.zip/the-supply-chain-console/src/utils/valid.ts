// 账号验证
export function validAccount(value: string): true | string {
  value = value.trim();
  if (value.length < 5) {
    return '账号长度需要大于五位';
  }
  return true;
}
// 密码验证
export function validPassword(value: string): true | string {
  value = value.trim();
  if (value.length < 5) {
    return '密码长度需要大于五位';
  }
  return true;
}

// 密码验证
export function validMessageCode(value: string): true | string {
  value = value.trim();
  if (value.length < 6) {
    return '请输入六位验证码';
  }
  if (Number.isNaN(Number(value))) {
    return '请输入六位数字验证码';
  }
  return true;
}

/**
 * 目标变量是否为空
 * @param val 目标值
 */
export function isEmpty(val: unknown): boolean {
  if (typeof val === 'boolean') {
    return false;
  }
  if (Object.prototype.toString.call(val) === '[object Array]') {
    if ((val as Array<unknown>).length === 0) {
      return true;
    }
  } else if (val instanceof Object) {
    if (JSON.stringify(val) === '{}') {
      return true;
    }
  } else {
    if (val === 'null' || val == null || val === 'undefined' || val === undefined || val === '') {
      return true;
    }
    return false;
  }
  return false;
}
