import { getFileUrlBySeq } from '@/utils/commApi';
import TIM from 'tim-js-sdk';
import store from '@/store';

// 格式化用户
// export function formatterUser(lists: Array<ImUserInfo>): Promise<Array<ImUserInfo>> {
//   return new Promise((resolve) => {
//     const avatarList = lists.map((item) => item.avatar);
//     getFileUrlBySeq(avatarList.join(',')).then((res) => {
//       lists = lists.map((item) => {
//         return {
//           ...item,
//           faceUrl: res[item.avatar]?.url || ''
//         };
//       });
//       resolve(lists);
//     });
//   });
// }

//#region 格式化聊天记录
// 格式化服务器端聊天记录
export function formatterServiceChattingMessage(
  groupSn: string,
  lists: Array<ServiceRecordRes>
): Promise<GroupSnAndDataList<ImChattingRecord>> {
  return new Promise((resolve) => {
    // (图片|文件)seq列表
    const seqList: Array<string> = [];
    const member = store.state.im.groupMemberMap[groupSn] || {};
    const result: GroupSnAndDataList<ImChattingRecord> = {
      sn: groupSn,
      from: 'SERVICE',
      lists: lists.map((item) => {
        const basic = {
          // 消息sn
          sn: item.sn,
          // 消息的流向;in 为收到的消息,out 为发出的消息
          flow: member[item.from].type === 'attendor' ? 'out' : 'in',
          // 消息类型
          messageType: item.messageType,
          // 消息体
          messageBody: {},
          // 消息发送者
          from: member[item.from],
          // 消息状态
          status: item.status,
          // 是否撤回
          isRevoked: item.revoked,
          // 是否已读
          isPeerRead: item.peerRead,
          // 发送时间
          time: item.createdAt * 1000,
          // 消息Key
          messageKey: item.messageKey
        };

        switch (item.messageType) {
          case TIM.TYPES.MSG_TEXT:
            // 文本消息
            return {
              ...basic,
              // 消息体
              messageBody: {
                text: (item as ServiceRecordText).messageBody.Text
              }
            } as ImChattingRecord;
          case TIM.TYPES.MSG_CUSTOM:
            // 解析自定义类型
            return {
              ...basic,
              // 消息体
              messageBody: {
                // 自定义消息内容
                data: (item as SendCustomMessage).messageBody.Data,
                // 自定义消息类型
                desc: (item as SendCustomMessage).messageBody.Desc
              }
            } as ImChattingRecord;
          case TIM.TYPES.MSG_IMAGE: {
            // 解析图片类型
            const seq = (item as SendImageMessage).messageBody.ImageInfoArray[0]?.URL || '';
            // 批量处理图片
            if (seq) {
              seqList.push(seq);
            }
            return {
              ...basic,
              // 消息体
              messageBody: {
                // 图片地址
                url: seq
              }
            } as ImChattingRecord;
          }
          // 解析文件类型
          case TIM.TYPES.MSG_FILE: {
            const seq = (item as SendFileMessage)?.messageBody || {};
            // 批量处理文件
            if (seq) {
              seqList.push(seq.Url);
            }
            // 解析自定义类型
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 文件地址
                fileName: seq.FileName,
                // 文件地址
                fileUrl: seq.Url,
                // 文件大小
                fileSize: seq.FileSize
              }
            } as ImChattingRecord;
          }
          case TIM.TYPES.MSG_VIDEO: {
            const seq = (item as SendVideoMessage)?.messageBody || {};
            // 批量处理文件
            if (seq) {
              seqList.push(seq.VideoUrl);
              seqList.push(seq.ThumbUrl);
            }
            // 解析自定义类型
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 文件地址
                videoUrl: seq.VideoUrl,
                // 文件地址
                videoSecond: seq.VideoSecond,
                // 文件大小
                videoSize: seq.VideoSize,
                thumbUrl: seq.ThumbUrl
              }
            } as ImChattingRecord;
          }
          default:
            return {} as ImChattingRecord;
        }
      })
    };
    // 批量获取文件|图片
    if (seqList.length === 0) {
      return resolve(result);
    }
    getFileUrlBySeq(seqList.join(',')).then((res) => {
      result.lists.map((item) => {
        return handlerFile(item, res);
      });
      resolve(result);
    });
  });
}

// 格式化腾讯云端聊天记录
export async function formatterTIMChattingMessage(
  lists: Array<TIMReceptionMessageType>
): Promise<{ [key: string]: GroupSnAndDataList<ImChattingRecord> }> {
  return new Promise((resolve) => {
    // 群组sn: { sn: 群组sn, form: 'TIM' | 'SERVICE', lists: Array<FormatRecord> }
    const result: { [key: string]: GroupSnAndDataList<ImChattingRecord> } = {};
    // (图片|文件)seq列表
    const seqList: Array<string> = [];
    const groupMappingDialog = store.state.im.groupMappingDialog;
    // 遍历聊天信息
    lists.forEach((item) => {
      const groupSn = groupMappingDialog[item.to] as string;
      const memberMap = store.state.im.groupMemberMap[groupSn] || {};
      if (!result[groupSn]) {
        result[groupSn] = {
          sn: groupSn,
          from: 'TIM',
          lists: []
        };
      }
      const basic = {
        // 消息sn
        sn: item.ID,
        // 消息的流向;in 为收到的消息,out 为发出的消息
        flow: item.flow,
        // 消息类型
        messageType: item.type,
        // 消息体
        messageBody: {},
        // 消息发送者
        from: memberMap[item.from],
        // 消息状态
        status: item.status,
        // 是否撤回
        isRevoked: item.isRevoked,
        // 是否已读
        isPeerRead: item.isPeerRead,
        // 发送时间
        time: item.time * 1000,

        messageKey: item.sequence + ''
      };
      // 格式化后消息的基础配置
      // 处理消息
      switch (item.type) {
        // 解析文本消息
        case TIM.TYPES.MSG_TEXT: {
          result[groupSn].lists.push({
            // 基础信息
            ...basic,
            messageBody: {
              // 发送的文字
              text: (item as TIMReceptionMessage<TIMReceptionPayloadText>).payload.text || '',
              // @的人员
              atUserList: item.atUserList
            }
          } as ImChattingRecord);
          break;
        }
        // 解析自定义类型
        case TIM.TYPES.MSG_CUSTOM: {
          result[groupSn].lists.push({
            // 基础信息
            ...basic,
            messageBody: {
              // 自定义消息内容
              data: (item as TIMReceptionMessage<TIMReceptionPayloadCustom>).payload.data,
              // 自定义消息类型
              desc: (item as TIMReceptionMessage<TIMReceptionPayloadCustom>).payload.description
            }
          } as ImChattingRecord);
          break;
        }
        // 解析图片类型
        case TIM.TYPES.MSG_IMAGE: {
          const seq =
            (item as TIMReceptionMessage<TIMReceptionPayloadImage>)?.payload?.imageInfoArray[0]
              ?.url || '';
          // 批量处理图片
          if (seq) {
            seqList.push(seq);
          }
          // 解析自定义类型
          result[groupSn].lists.push({
            // 基础信息
            ...basic,
            messageBody: {
              // 图片地址
              url: seq
            }
          } as ImChattingRecord);
          break;
        }
        // 解析文件类型
        case TIM.TYPES.MSG_FILE: {
          const seq = (item as TIMReceptionMessage<TIMReceptionPayloadFile>)?.payload || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.fileUrl);
          }
          // 解析自定义类型
          result[groupSn].lists.push({
            // 基础信息
            ...basic,
            messageBody: {
              // 文件地址
              fileName: seq.fileName,
              // 文件地址
              fileUrl: seq.fileUrl,
              // 文件大小
              fileSize: seq.fileSize
            }
          } as ImChattingRecord);
          break;
        }
        case TIM.TYPES.MSG_VIDEO: {
          const seq = (item as TIMReceptionMessage<TIMReceptionPayloadVideo>)?.payload || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.videoUrl);
            seqList.push(seq.thumbUrl);
          }
          // 解析自定义类型
          result[groupSn].lists.push({
            // 基础信息
            ...basic,
            messageBody: {
              // 文件地址
              videoUrl: seq.videoUrl,
              // 文件地址
              videoSecond: seq.videoSecond,
              // 文件大小
              videoSize: seq.videoSize,
              thumbUrl: seq.thumbUrl
            }
          } as ImChattingRecord);
          break;
        }
        default:
          console.log('无法处理数据');
      }
    });
    // 批量获取文件|图片
    if (seqList.length === 0) {
      return resolve(result);
    }
    getFileUrlBySeq(seqList.join(',')).then((res) => {
      for (const resultKey in result) {
        result[resultKey].lists = result[resultKey].lists.map((item) => {
          return handlerFile(item, res);
        });
      }
      resolve(result);
    });
  });
}

//#endregion
/**
 * 处理文件/图片
 * @param item
 * @param res
 */
function handlerFile(item: ImChattingRecord, res: CommonOssCommonListSeqs): ImChattingRecord {
  if (
    item.messageType === TIM.TYPES.MSG_IMAGE ||
    item.messageType === TIM.TYPES.MSG_FILE ||
    item.messageType === TIM.TYPES.MSG_VIDEO
  ) {
    if (item.messageType === TIM.TYPES.MSG_IMAGE) {
      (item.messageBody as ImFormatRecordImage).url = formatUrl(
        res[(item.messageBody as ImFormatRecordImage).url]?.url?.replace(/Expires=[^&]*&?/g, '')
      );
    } else if (item.messageType === TIM.TYPES.MSG_VIDEO) {
      (item.messageBody as ImFormatRecordVideo).videoUrl = formatUrl(
        res[(item.messageBody as ImFormatRecordVideo).videoUrl]?.url?.replace(
          /Expires=[^&]*&?/g,
          ''
        )
      );
      (item.messageBody as ImFormatRecordVideo).thumbUrl = formatUrl(
        res[(item.messageBody as ImFormatRecordVideo).thumbUrl]?.url?.replace(
          /Expires=[^&]*&?/g,
          ''
        )
      );
    } else {
      (item.messageBody as ImFormatRecordFile).fileUrl = formatUrl(
        res[(item.messageBody as ImFormatRecordFile).fileUrl]?.url?.replace(/Expires=[^&]*&?/g, '')
      );
    }
  }
  return item;
}

function formatUrl(url: string) {
  if (!url) {
    return '';
  }
  if (url.indexOf('?') !== -1) {
    return url.replace(/([?#])[^'"]*/, '');
  }
  return url;
}
