import { ImGroupMessageSend } from '@/utils/im/api';
import TIM from 'tim-js-sdk';
import { uploadFile } from '@/utils/commApi';

// 发送消息
export function sendMessage(groupSn: string, data: ImSendMessage): Promise<SendResultData> {
  return new Promise((resolve) => {
    if (!groupSn) {
      return resolve({ success: false, hint: '群组不能为空' });
    }
    ImGroupMessageSend(groupSn, data)
      .then(() => {
        return resolve({ success: true, hint: '' });
      })
      .catch(() => {
        return resolve({ success: false, hint: '发送失败' });
      });
  });
}

export function showNotification(title: string, text: ImSendMessage) {
  const PERMISSON_GRANTED = 'granted';
  // const PERMISSON_DENIED = 'denied';
  // const PERMISSON_DEFAULT = 'default';
  const options = {
    body: messageFormat(text)
  };
  if (Notification.permission === PERMISSON_GRANTED) {
    notify(title, options);
  } else {
    Notification.requestPermission(function (res) {
      if (res === PERMISSON_GRANTED) {
        notify(title, options);
      }
    }).catch((e) => {
      console.error(e);
    });
  }
}

export function messageFormat(info: ImSendMessage | undefined): string {
  if (!info) {
    return '';
  }
  if (info.messageType === 'TIMTextElem') {
    // eslint-disable-next-line no-undef
    return (info as SendTextMessage).messageBody.Text;
  } else if (info.messageType === 'TIMImageElem') {
    // eslint-disable-next-line no-undef
    return '[图片]';
  } else if (info.messageType === 'TIMFileElem') {
    // eslint-disable-next-line no-undef
    return '[文件]';
  } else if (info.messageType === 'TIMVideoFileElem') {
    // eslint-disable-next-line no-undef
    return '[视频]';
  } else if (
    info.messageType === 'TIMCustomElem' &&
    // eslint-disable-next-line no-undef
    (info as SendCustomMessage).messageBody.Desc === 'ORDER'
  ) {
    // eslint-disable-next-line no-undef
    return '[订单信息]';
  } else if (
    info.messageType === 'TIMCustomElem' &&
    // eslint-disable-next-line no-undef
    (info as SendCustomMessage).messageBody.Desc === 'SHOP'
  ) {
    // eslint-disable-next-line no-undef
    return '[商品信息]';
  } else return '';
}

function notify($title: string, $options: NotificationOptions) {
  const notification = new Notification($title, $options);
  console.log(notification);
  notification.onshow = function (event) {
    console.log('show : ', event);
  };
  notification.onclose = function (event) {
    console.log('close : ', event);
  };
  notification.onclick = function (event) {
    console.log('click : ', event);
    notification.close();
  };
}

//#region 创建发送消息
// 创建文本消息
export function createTextMessage(Text: string): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    if (!Text) {
      return resolve({
        success: false,
        data: '消息不能为空'
      });
    }
    return resolve({
      success: true,
      data: {
        messageType: TIM.TYPES.MSG_TEXT,
        messageBody: {
          Text
        }
      }
    });
  });
}

// 创建@文本消息
export function createAtTextMessage(
  Text: string,
  allOrPart: Array<string> | 1
): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    if (!Text) {
      return resolve({
        success: false,
        data: '消息不能为空'
      });
    }
    // 创建基础的 @ 消息
    const result: SendAtTextMessage = {
      messageBody: {
        Text
      },
      messageType: TIM.TYPES.MSG_TEXT,
      atAccounts: []
    };
    // 是否 @ 所有人?
    if (allOrPart === 1) {
      result.atAccounts.push({
        atAllFlag: 1,
        atAccount: ''
      });
    } else {
      allOrPart.forEach((item) => {
        result.atAccounts.push({
          atAllFlag: 0,
          atAccount: item
        });
      });
    }
    return resolve({
      success: true,
      data: result
    });
  });
}

// 创建图像消息
export function createImageMessage(file: File): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    if (file.size > 10 * 1024 * 1024) {
      resolve({
        success: false,
        data: '文件请限制在10M以内'
      });
      return;
    }
    uploadFile(file)
      .then((res) => {
        if (!res.seq) {
          resolve({
            success: false,
            data: ''
          });
          return;
        }
        // 发送图片的模板
        const result: SendImageMessage = {
          messageType: TIM.TYPES.MSG_IMAGE,
          messageBody: {
            UUID: new Date().getTime() + '',
            ImageFormat: 255,
            ImageInfoArray: [
              {
                Type: 1,
                Size: 0,
                Width: 0,
                Height: 0,
                URL: res.seq
              }
            ]
          }
        };
        return resolve({
          success: true,
          data: result
        });
      })
      .catch(() => {
        return resolve({
          success: false,
          data: '上传文件失败'
        });
      });
  });
}

// 创建文件
export function createFileMessage(file: File): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    if (file.size === 0) {
      resolve({
        success: false,
        data: '发送失败，文件为空文件'
      });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      resolve({
        success: false,
        data: '文件请限制在10M以内'
      });
      return;
    }
    uploadFile(file)
      .then((res) => {
        if (!res.seq) {
          resolve({
            success: false,
            data: ''
          });
          return;
        }
        const result: SendFileMessage = {
          messageType: TIM.TYPES.MSG_FILE,
          messageBody: {
            Url: res.seq,
            FileSize: file.size,
            FileName: file.name
          }
        };
        return resolve({
          success: true,
          data: result
        });
      })
      .catch(() => {
        return resolve({
          success: false,
          data: '上传文件失败'
        });
      });
    // uploadFile
  });
}

/* 将base64转换为file类型 */
function getFileFromBase64(base64URL: string, filename: string) {
  const arr = base64URL.split(','),
    // mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  // alert(mime)
  return new File([u8arr], filename, { type: 'image/png' });
}

// 创建视频
export function createVideoMessage(file: File): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    if (file.size > 10 * 1024 * 1024) {
      resolve({
        success: false,
        data: '文件请限制在10M以内'
      });
      return;
    }
    const video = document.getElementById('video') as HTMLVideoElement;
    const videoURL = URL.createObjectURL(file);
    video.setAttribute('src', videoURL);
    video.load();
    video.addEventListener('loadeddata', async (e) => {
      const canvas = document.createElement('canvas');
      const scale = 0.35;
      canvas.width = video.videoWidth * scale;
      canvas.height = video.videoHeight * scale;
      let flag = true;
      while (flag) {
        if (canvas.width > 400) {
          canvas.width *= 0.9;
          canvas.height *= 0.9;
        } else {
          flag = false;
        }
      }
      canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imagebase64 = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
      const imgURL = getFileFromBase64(imagebase64, new Date().getTime() + '.png');

      // 视频上传
      const f = await uploadFile(file);
      if (!f?.seq) {
        video.src = '';
        return resolve({
          success: false,
          data: '上传文件失败'
        });
      }
      const i = await uploadFile(imgURL);
      if (!i?.seq) {
        video.src = '';
        return resolve({
          success: false,
          data: '上传文件失败'
        });
      }
      const result: SendVideoMessage = {
        messageType: 'TIMVideoFileElem',
        messageBody: {
          VideoUrl: f.seq,
          VideoSize: file.size,
          VideoSecond: video.duration || 0,
          ThumbUrl: i.seq
        }
      };
      video.src = '';
      return resolve({
        success: true,
        data: result
      });
    });
  });
}

// 创建自定义消息
export function createCustomMessage(
  Data: string,
  Desc: SendCustomMessageDesc
): Promise<CreateMessageResult> {
  return new Promise((resolve) => {
    const result: SendCustomMessage = {
      messageType: TIM.TYPES.MSG_CUSTOM,
      messageBody: {
        Data,
        Desc
      }
    };
    resolve({ success: true, data: result });
  });
}

//#endregion
