import ajax from '@/utils/axios';

//#region 当前登录用户根据群组sn发送消息
// 发送的消息类型
export const ImGroupMessageSend = (groupSn: string, data: ImSendMessage): Promise<undefined> => {
  return ajax.post<null, undefined>('/auth/im/group/message/send/' + groupSn, data, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};
//#endregion

//#region 获取IM的用户体系
// 获取客户的信息
export const getImInfo = (): Promise<ImUserInfo> => {
  return ajax.get<null, ImUserInfo>('/auth/mk/csc/attendor/current', {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};
//#endregion

//#region 客服中心接口
// 获取客服中心定义列表
export const getMkCscDefList = () => {
  return ajax.get<null, Array<GetMkCscDefListRes>>('/auth/mk/csc/def/list', {
    params: {
      $InstId: true
    }
  });
};

// 获取客服群组列表
export const getMkCscInstanceDialogServicelist = (sn: string, state: string) => {
  return ajax.get<null, Array<GetMkCscInstanceDialogServiceList>>(
    `/auth/mk/csc/instance/dialog/service/list/${sn}/${state}`,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};
//#endregion

// 切换客服的状态 // 状态 ON 在线 OFF 离线 BUSY 繁忙
export const changeMkCscState = (sn: string, state: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/mk/csc/attendor/state/${state}/${sn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
//#region 备注信息接口
// 获取备注信息列表
export const getMkRemarkList = (dialogSn: string) => {
  return ajax.get<null, Paging<ImRemarkMessage>>(
    `/auth/mk/csc/instance/dialog/remark/page/${dialogSn}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 添加备注信息
export const addMkRemark = (dialogSn: string, data: { content: string; tags: string }) => {
  return ajax.post<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/remark/${dialogSn}`,
    data,
    {
      params: {
        $InstId: true
      }
    }
  );
};
//#endregion

//#region 联系计划接口
// 添加联系计划
export const addMkPlan = (
  dialogSn: string,
  data: { attendorSn: string; contactContent: string; planContactTime: number }
) => {
  return ajax.post<null, { success: boolean }>(`/auth/mk/csc/instance/plan/${dialogSn}`, data, {
    params: {
      $InstId: true
    }
  });
};

// 分页查询总览联系计划
export const getMkPlanList = (data: {
  dialogSn?: string;
  page: number;
  size: number;
  customName?: string;
  content?: string;
  cscDefSn?: string;
}) => {
  return ajax.get<null, Paging<ImContactPlan>>(
    `/auth/mk/csc/instance/plan/page?page=${data.page}&size=${data.size}&dialogSn=${
      data.dialogSn || ''
    }&cscDefSn=${data.cscDefSn || ''}&customName=${data.customName || ''}&content=${
      data.content || ''
    }`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 联系计划完成
export const finishedMkPlan = (
  sn: string,
  data: {
    remark: string;
  }
) => {
  return ajax.put<null, { success: boolean }>(`/auth/mk/csc/instance/plan/finished/${sn}`, data, {
    params: {
      $InstId: true
    }
  });
};

// 取消联系计划
export const cancelMkPlan = (planSn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/mk/csc/instance/plan/cancel/${planSn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
//#endregion

// 根据客服中心查客服列表
export const getMkCscServiceList = (cscDefSn: string) => {
  return ajax.get<null, Paging<ImCscService>>(
    '/auth/mk/csc/attendor/relation/page?cscDefSn=' + cscDefSn,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};

// 置顶聊天
export const putMkTopDialog = (dialogSn: string, query = '') => {
  return ajax.put<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/top/${dialogSn}?type=${query}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
// 结束聊天
export const putMkFinishDialog = (dialogSn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/finished/${dialogSn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
// 转接客服
export const putMkTransferDialog = (dialogSn: string, attendorSn: string) => {
  return ajax.put<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/transfer/${dialogSn}/${attendorSn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};
// 获取群成员列表
export const getMkDialogMember = (dialogSn: string) => {
  return ajax.get<null, ImUserInfo[]>(`/auth/mk/csc/instance/dialog/member/${dialogSn}`, {
    params: {
      $InstId: true
    }
  });
};

// 分页获取聊天记录
export const getMkDialogMessage = (dialogSn: string, lastMessageSn = '') => {
  return ajax.get<null, Paging<ServiceRecordRes>>(
    `/auth/mk/csc/instance/dialog/message/${dialogSn}?page=0&size=30&lastMessageSn=${lastMessageSn}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// IM的发送消息
export const sendMkMessage = (dialogSn: string, data: ImSendMessage) => {
  return ajax.post<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/send/${dialogSn}`,
    data,
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};

// 根据群组sn获取群组信息
export const getMkGroupInfoForGroupSn = (groupSn: string) => {
  if (!groupSn) {
    return Promise.resolve({ csdDefSn: '' });
  }
  return ajax.get<null, { csdDefSn: string }>(`/auth/mk/csc/group/${groupSn}`, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

// 创建一个群组
export const createMkGroup = (cscDefSn: string) => {
  return ajax.post<null, { sn: string; success: boolean }>(
    `/auth/mk/csc/instance/dialog/${cscDefSn}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 获取对话框用户信息
export const getDialogCustomerInfo = (sn: string) => {
  return ajax.get<null, CustomerInfo>(`/auth/mk/csc/instance/dialog/${sn}`, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

// 设置消息已读
export const clearMkMessage = (dialogSn: string) => {
  return ajax.put<null, CustomerInfo>(
    `/auth/mk/csc/instance/dialog/clear/${dialogSn}`,
    {},
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};

// 后台客服中心列表
export const cscBackList = (): Promise<
  Paging<{
    sn: string;
    count: number;
    name: string;
  }>
> => {
  return ajax.get<
    null,
    Paging<{
      sn: string;
      count: number;
      name: string;
    }>
  >('/auth/mk/csc/def/backstage/page', {
    params: {
      $InstId: true
    }
  });
};

// 消息撤回
export const revokeMessage = (dialogSn: string, msgKey: string): Promise<{ success: boolean }> => {
  return ajax.post<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/message/recall/${dialogSn}/${msgKey}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 删除消息
export const removeMkMessage = (
  dialogSn: string,
  msgKey: string
): Promise<{ success: boolean }> => {
  return ajax.post<null, { success: boolean }>(
    `/auth/mk/csc/instance/dialog/message/delete/${dialogSn}/${msgKey}`,
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

// 登录的时候调用一下，让后台能识别客服的状态
export const cscLogin = (): Promise<{ success: boolean }> => {
  return ajax.post<null, { success: boolean }>(
    '/auth/mk/csc/attendor/login',
    {},
    {
      params: {
        $InstId: true
      }
    }
  );
};

export const checkOnLine = (): Promise<{ success: boolean }> => {
  return ajax.post<null, { success: boolean }>(
    '/auth/mk/csc/attendor/check',
    {},
    {
      params: {
        $InstId: true,
        $noLoad: true
      }
    }
  );
};

// im的初始化信息获取
export const getImLoginInfo = () => {
  return ajax.get<null, ImUserInfo>('/auth/bpm/im/member', {
    params: {
      $InstId: true
    }
  });
};

// im分页查询成员列表 owner normal
export const getImMemberList = (groupSn: string) => {
  return ajax.get<null, Paging<ImUserInfo>>(`/auth/bpm/im/member/page/${groupSn}?size=200`, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

// 获取聊天记录
export const getImMessage = (groupSn: string, lastMessageSn = '') => {
  return ajax.get<null, Paging<ServiceRecordRes>>(
    `/auth/im/group/message/record/${groupSn}?page=0&size=30&lastSn=${lastMessageSn}`,
    {
      params: {
        $InstId: true
      }
    }
  );
};

// IM的发送消息
export const sendImMessage = (groupSn: string, data: ImSendMessage) => {
  return ajax.post<null, { success: boolean }>(`/auth/im/group/message/send/${groupSn}`, data, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};
