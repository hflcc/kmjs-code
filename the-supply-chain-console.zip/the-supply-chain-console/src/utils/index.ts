export * from './valid';
export * from './formatter';
export * from './setup';
export * from './components';
export * from './file';
export * from './hooks';
export * from './downloadFile';
export * from './math';
/**
 * 循环便利从对象中读取指定索引路径的数据
 * 比如从 {a: {b: 1}} 中读取 'a.b'
 * @param data 指定的对象
 * @param key 指定的索引路径
 * */
export const getChainData = <T>(data: Record<string, any> | T, key: string): T => {
  let currentData: Record<string, any> | string = data;
  if (!key) return data as T;
  key.split('.').forEach((v, i, arr) => {
    currentData = (currentData as Record<string, any>)?.[v];
    // 尝试转换成对象试一下
    if (typeof currentData === 'string' && i < arr.length) {
      try {
        currentData = JSON.parse(currentData);
        if (typeof currentData === 'number') {
          currentData = currentData + '';
        }
      } catch (e) {
        // nothing
      }
    }
  });
  return currentData as T;
};

/**
 * 循环便利将数据设置到指定的路径下
 * 比如将数据 1 设置到对象 obj: {} 的 'a.b.c'下， 设置后的obj: {a: {b: { c:1 }}}
 * @param data 指定的对象
 * @param key 指定的索引路径
 * @param setData 需要设置的值
 * */
export const setChainData = (data: Record<string, any>, key: string, setData: any) => {
  let currentData: Record<string, any> = data;
  if (!key) return;
  key.split('.').forEach((v, i, arr) => {
    if (!currentData[v]) {
      if (i === arr.length - 1) {
        currentData[v] = setData;
      } else {
        currentData[v] = {};
      }
    } else {
      currentData = currentData[v];
    }
  });
};
