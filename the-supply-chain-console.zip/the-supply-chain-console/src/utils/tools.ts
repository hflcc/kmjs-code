interface FileHeader {
  'content-disposition': string;
  [index: string]: any;
}
export type File = {
  headers: FileHeader;
  data: Blob;
};

export const downloadBufferFile = function (res: File): void {
  // 取出返回头中的文件名称
  const fileNameStr = res.headers['content-disposition'] || '';
  const matchStr = fileNameStr?.match(/filename=.+/) ?? [];
  const fileName = matchStr[0]?.replace('filename=', '') || 'excel.xlsx';
  const url = window.URL.createObjectURL(
    new Blob([res.data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    })
  );
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = url;
  link.setAttribute('download', decodeURIComponent(fileName));
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
