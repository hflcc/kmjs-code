/**
 * 校验当前用户的权限是否符合某个元素所需要的权限
 * @param actionEmit 当前元素需要的权限
 * @param permissions 当前页面所有的权限
 * @return boolean 校验的结果，符合返回true 不符合返回false
 * */
export const checkPermission = (
  actionEmit: string,
  permissions?: { [key: string]: string }
): boolean => {
  // 本地开发时所有页面都有权限
  if (process.env.VUE_APP_ENV === 'development') {
    return true;
  }
  if (!actionEmit || !permissions) return true;
  return Boolean(permissions[actionEmit]);
};
