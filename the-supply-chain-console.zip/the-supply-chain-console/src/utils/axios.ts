import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import store from '@/store';
import { ElNotification, ElLoading } from 'element-plus';
import router from '@/router';
import { ILoadingInstance } from 'element-plus/es/el-loading/src/loading.type';

let loading: ILoadingInstance | null;
let loadNum = 0;
/**
 * 关闭loading
 * */
const loadClose = () => {
  loadNum--;
  if (loadNum <= 0) {
    setTimeout(() => {
      loading?.close();
      loading = null;
    }, 200);
  }
};
/**
 * 显示loading
 * */
const showLoad = () => {
  loadNum++;
  if (loading) return;
  loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    spinner: 'el-icon-loading',
    background: 'rgba(0, 0, 0, 0.5)'
  });
};

export interface Res<T> {
  code: number;
  msg: string;
  data: T;
}

const CancelToken = axios.CancelToken;
let requestQueue: {
  url: string;
  data: string;
  params: string;
  method: string;
}[] = [];

/**
 * 重复请求拦截 开始
 * */
// 请求拦截调用
function handleRequest({ config }: { config: any }) {
  // 提取四个参数用于区分相同的请求
  const { url, method, data = {}, params = {} } = config;
  const jData = JSON.stringify(data),
    jParams = JSON.stringify(params);

  const panding = requestQueue.filter((item) => {
    return (
      item.url === url && item.method === method && item.data === jData && item.params === jParams
    );
  });
  if (panding.length) {
    // 这里是重点，实例化CancelToken时，对参数 c 进行立即调用，即可立即取消当前请求
    config.cancelToken = new CancelToken((c) => {
      c(`重复的请求被主动拦截: ${url} + ${jData} + ${jParams}`);
    });
    return false;
  } else {
    // 如果请求不存在，将数据转为JSON字符串格式，后面比较好对比
    requestQueue.push({
      url,
      data: jData,
      params: jParams,
      method
    });
    return true;
  }
}

// 响应拦截调用
function handleResponse({ config }: { config: any }) {
  const { url, method, data = JSON.stringify({}), params = JSON.stringify({}) } = config;
  let key;
  if (method === 'get' || method === 'delete') {
    key = [url, JSON.stringify({ params })].join(',');
  } else {
    key = [url, data, JSON.stringify({ params })].join(',');
  }
  if (ajaxObj[key]) {
    Reflect.deleteProperty(ajaxObj, key);
  }
  const reqQueue = requestQueue.filter((item) => {
    return item.url !== url && item.data !== data && item.params !== params;
  });
  requestQueue = reqQueue;
}

/**
 * 重复请求拦截 结束
 * */
// 创建axios实例
const serveice = axios.create({
  withCredentials: true,
  timeout: 60000
});
// 请求文件的实例
const fileServeice = axios.create({
  withCredentials: true,
  timeout: 60000
});
const reLogin = (code: number) => {
  if (code === 401) {
    if (window.location.pathname === '/login') {
      return true;
    }
    store.dispatch('user/logOut');
    router.push({
      name: 'login',
      query: {
        p: window.location.pathname,
        q: window.location.search
      }
    });
    return true;
  }
  return false;
};

const beforeRequest = () => {
  return (config: AxiosRequestConfig) => {
    if (!handleRequest({ config })) return config;
    // 取出所有的$开头的配置项
    if (config.params) {
      const con: { [l: string]: boolean } = {};
      Object.keys(config.params)
        .filter((s) => s.charAt(0) === '$')
        .forEach((s) => {
          con[s] = config.params[s];
          Reflect.deleteProperty(config.params, s);
        });
      if (con.$noLoad !== true) {
        showLoad();
      }
      if (con.$InstId && !config.headers['InstId']) {
        const activeInst = store.getters['organization/activeOrgan'];
        if (activeInst) config.headers['InstId'] = activeInst.id;
      }
      if (!con.$noBase) {
        config.url = `${process.env.VUE_APP_AXIOS_BASE_URL}${config.url}`;
      }
    } else {
      config.url = `${process.env.VUE_APP_AXIOS_BASE_URL}${config.url}`;
      showLoad();
    }
    config.params &&
      Object.keys(config.params).forEach((s) => {
        if (typeof config.params[s] === 'string') {
          config.params[s] = config.params[s].trim();
        }
      });
    config.data &&
      Object.keys(config.data).forEach((s) => {
        if (typeof config.data[s] === 'string') {
          config.data[s] = config.data[s].trim();
        }
      });
    return config;
  };
};

const beforResponse = (backAll = false) => {
  return (response: AxiosResponse) => {
    handleResponse({ config: response.config });
    loadClose();
    const data = response.data;
    if (data.nodeCode) {
      if (reLogin(data.nodeCode)) {
        return false;
      }
      ElNotification({
        title: '提示信息',
        message: data.nodeInfo?.message || '请求错误， 请稍后再试',
        duration: 4000
      });
      return false;
    }
    if (backAll) {
      return response;
    }
    return response.data || {};
  };
};

const beforResponseError = (error: any) => {
  loadClose();
  error.response && handleResponse({ config: error.response.config });
  if (error instanceof axios.Cancel) {
    console.log(error.message);
    return;
  }
  if (error.message.includes('timeout')) {
    ElNotification({
      title: '提示信息',
      message: error.response?.data?.message || '请求错误， 请稍后再试',
      duration: 4000
    });
    return Promise.resolve(false);
  }
  if (reLogin(error.response?.status)) return Promise.resolve(false);
  ElNotification({
    title: '提示信息',
    message: error.response?.data?.message ?? '请求错误， 请稍后再试',
    duration: 4000
  });
  return Promise.resolve(false);
};

// 请求拦截
serveice.interceptors.request.use(beforeRequest(), (err) => {
  console.log(err);
});

// 响应拦截
serveice.interceptors.response.use(beforResponse(), beforResponseError);

// 请求拦截
fileServeice.interceptors.request.use(beforeRequest(), (err) => {
  console.log(err);
});

// 响应拦截
fileServeice.interceptors.response.use(beforResponse(true), beforResponseError);

export const file = (url: string, config?: AxiosRequestConfig) => {
  return fileServeice.get(url, config);
};

/**
 * 重复的请求记录起来在这里存储。后续同时进来的请求，都使用第一次的promise
 * */
const ajaxObj: Record<string, Promise<any>> = {};

const proxyHandler = {
  apply: function (target: AxiosInstance, thisArg: any, argArray?: any) {
    // 上传文件特殊处理
    if (argArray[0].includes('/auth/oss/upload/file')) {
      return Reflect.apply(target, thisArg, argArray);
    }
    const key =
      process.env.VUE_APP_AXIOS_BASE_URL +
        argArray
          ?.map((s: string | { params: Record<string, string> }) => {
            /**
             * 排除$开头的配置文件，方便后续清楚的key生成
             * */
            if (typeof s === 'object' && s.params) {
              const newObj = Object.assign({}, s.params);
              const ks = Object.keys(newObj).filter((s) => s.charAt(0) === '$');
              ks.forEach((s) => {
                Reflect.deleteProperty(newObj, s);
              });
              return JSON.stringify({ params: newObj });
            }
            if (typeof s === 'string') return s;
            if (typeof s === 'undefined') {
              return '{}';
            }
            return JSON.stringify(s);
          })
          .join(',') ?? '';
    let ajaxFun = null;
    if (ajaxObj[key]) {
      ajaxFun = ajaxObj[key];
    } else {
      ajaxFun = Reflect.apply(target, thisArg, argArray);
      ajaxObj[key] = ajaxFun;
    }
    return ajaxFun;
  }
};

/**
 * 使用代理对方法进行拦截
 * */

const serveiceProxy = {
  get: new Proxy(serveice.get, proxyHandler),
  post: new Proxy(serveice.post, proxyHandler),
  put: new Proxy(serveice.put, proxyHandler),
  delete: new Proxy(serveice.delete, proxyHandler)
};

export default serveiceProxy;
