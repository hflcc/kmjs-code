export const getCanPreview = (type?: string, url?: string): boolean => {
  if (type) {
    return Boolean(type.indexOf('image/') === 0 || type === 'application/pdf');
  }
  if (url) {
    const canPerviewSuffix = ['.pdf', '.jpeg', '.png', '.jpg', '.webp', '.jfif', '.gif'];
    let suffix = url?.substr(url?.lastIndexOf('.')) ?? '';
    suffix = suffix.substr(0, suffix.indexOf('?'));
    return canPerviewSuffix.includes(suffix.toLocaleLowerCase());
  }
  return false;
};
export const getItemType = (item: { file?: File; url?: string }): string => {
  if (item.file) {
    if (item.file.type === 'application/pdf') {
      return 'pdf';
    }
    if (item.file.type.indexOf('image/') === 0) {
      return 'image';
    }
  } else {
    const canPerviewSuffix = ['.jpeg', '.png', '.jpg', '.webp', '.jfif', '.gif'];
    let suffix = item.url?.substr(item.url?.lastIndexOf('.')) ?? '';
    suffix = suffix.substr(0, suffix.indexOf('?'));
    if (suffix === '.pdf') {
      return 'pdf';
    }
    if (canPerviewSuffix.includes(suffix.toLocaleLowerCase())) {
      return 'image';
    }
  }
  return '';
};
