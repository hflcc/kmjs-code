/**
 * 字符串首字母大写
 * @param str 字符串
 * @return {string} 大写后的字符串
 * */
export function firstUpperCase(str: string) {
  const strs: string[] = str.split('');
  strs[0] = strs[0].toUpperCase();
  return strs.join('');
}
