import TIM from 'tim-js-sdk';
import TIMUploadPlugin from 'tim-upload-plugin';
import store from '@/store';

// 创建实例
const instance = TIM.create({
  SDKAppID: parseInt(process.env.VUE_APP_TIM_SDK_APPID)
});
// 上传插件
instance.registerPlugin({ 'tim-upload-plugin': TIMUploadPlugin });
// sdk初始化成功
instance.on(TIM.EVENT.SDK_READY, () => {
  store.commit('im/SET_SDK_STATE', true);
});

// 消息推送
instance.on(TIM.EVENT.MESSAGE_RECEIVED, (event: TIMCallbackEvent) => {
  store.dispatch('im/getTIMChattingRecord', event.data);
});

instance.on(TIM.EVENT.MESSAGE_REVOKED, (event: TIMCallbackEvent) => {
  store.dispatch('im/onMessageRevoked', event.data);
});

// 被踢下线时触发
instance.on(TIM.EVENT.KICKED_OUT, () => {
  console.info('被踢下线了');
  // store.dispatch('im/onMessageKicked', {});
  store.commit('im/UPDATE_IM_STATE', false);
});

const onError = function (event: TIMCallbackEvent) {
  console.error('IM错误:', event.data);
  // event.data.code - 错误码
  // event.data.message - 错误信息
};

instance.on(TIM.EVENT.ERROR, onError);

// 设置日志等级
instance.setLogLevel(process.env.NODE_ENV === 'development' ? 0 : 1);
// instance.setLogLevel(4);

export default instance;
