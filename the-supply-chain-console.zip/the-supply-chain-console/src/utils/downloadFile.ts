export const downloadFile = (url: string, name: string) => {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.responseType = 'blob';
  xhr.onload = function () {
    // 请求完成
    if (this.status === 200) {
      // 返回200
      // const blob = this.response;
      // const reader = new FileReader();
      // reader.readAsDataURL(blob);
      // // 转换为base64，可以直接放入a的href
      // reader.onload = function (e) {
      // 转换完成，创建一个a标签用于下载
      const a = document.createElement('a');
      a.download = name;
      a.href = URL.createObjectURL(this.response);
      // a.href = e.target?.result as string;
      document.body.appendChild(a);
      // 修复firefox中无法触发click
      a.click();
      document.body.removeChild(a);
      // };
    }
  };
  // 发送ajax请求
  xhr.send();
};
