import { add, divide, multiply, subtract } from 'lodash';

export const math = {
  divide: (n: number[]) => {
    return n.reduce(divide);
  },
  add: (n: number[]) => {
    return n.reduce(add);
  },
  subtract: (n: number[]) => {
    return n.reduce(subtract);
  },
  multiply: (n: number[]) => {
    return n.reduce(multiply);
  },
  //乘法
  accMul(arg1: number | string, arg2: number | string): number {
    let m = 0;
    const s1 = arg1.toString();
    const s2 = arg2.toString();
    try {
      m += s1.split('.')[1].length;
    } catch (e) {
      // no
    }
    try {
      m += s2.split('.')[1].length;
    } catch (e) {
      // no
    }
    return (Number(s1.replace('.', '')) * Number(s2.replace('.', ''))) / Math.pow(10, m);
  }
};
