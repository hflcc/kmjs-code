import ajax, { Res } from '@/utils/axios';
import md5 from 'js-md5';

export interface GetToken {
  access_token: string;
  token_type: string;
  refresh_token: string;
  expires_in: number;
  scope: string;
}

/**
 * 获取系统信息
 * */
export const getSystemInfo = (): Promise<{
  nav_menu: string;
  aside_menu: string;
  sys_name: string;
  sys_logo: string;
  login_banner: string;
  login_descr: string;
  theme: string;
}> => {
  return ajax.get('/api/md/common/inst/app/config/property', {
    params: {
      $noLoad: true
    }
  });
};

/**
 * 发送短信
 * */
export const sendMsg = (
  phoneNum: string
): Promise<{
  success: boolean;
  message: string;
}> => {
  return ajax.post<
    null,
    {
      success: boolean;
      message: string;
    }
  >(
    '/api/sys/common/sms/verify/code/send',
    {},
    {
      params: {
        sn: 'a8b061e9da4611eba2b50c42a1da1656',
        phoneNum
      }
    }
  );
};
/**
 * 获取当前用户的机构列表
 * */
export const getUserInstList = (): Promise<InstItem[]> => {
  return ajax.get<null, InstItem[]>('/auth/md/inst/list/project', {
    params: {
      $noLoad: true
    }
  });
};

/**
 * 获取当前用户的渠道数据
 * @param InstId {string} 机构ID
 * */
export const getUserChannelData = async (InstId: string): Promise<ChannelItem[] | false> => {
  const res = await ajax.get<null, ChannelItem[]>('/auth/md/inst/org/user', {
    headers: {
      InstId
    },
    params: {
      $noLoad: true
    }
  });
  if (res) {
    return res;
  } else {
    return false;
  }
};

/**
 * 获取用户组织信息
 * */
export const getUserOrganizationData = async (channelSn: string): Promise<OrganizationItem[]> => {
  return await ajax.get<null, OrganizationItem[]>('/auth/md/inst/org/tree/user/' + channelSn, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 账号密码登陆
 * */
export const loginByPwd = (username: string, password: string): Promise<GetToken> => {
  return ajax.get<
    {
      username: string;
      password: string;
      grant_type: string;
      scope: string;
    },
    GetToken
  >('/login/by/password', {
    params: {
      username,
      password
    }
  });
};

/**
 * 验证码登陆
 * @param phonenum {string} 手机号
 * @param messageCode {string} 验证码
 * @return Promise<Res<LoginData>>
 * */
export const loginByMsg = (phonenum: string, messageCode: string): Promise<GetToken> => {
  return ajax.get<
    {
      phonenum: string;
      smscode: string;
      grant_type: string;
      scope: string;
    },
    GetToken
  >('/login/by/smsCode', {
    params: {
      phonenum,
      smscode: messageCode
    }
  });
};

/**
 * 登出
 * */
export const logout = (): Promise<Res<undefined>> => {
  return ajax.get('/logout');
};

/**
 * 获取菜单数据
 * */
export const getMenu = (menuDefSn: string): Promise<ServerRouterData[]> => {
  return ajax.get('/auth/md/inst/menu/instance/tree/' + menuDefSn, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 获取用户信息
 * */
export const getUserMsg = (): Promise<UserMsg> => {
  return ajax.get<null, UserMsg>('/auth/sys/user/current/check/integrity', {
    params: {
      $noLoad: true
    }
  });
};

/**
 * 查询字典
 * @param types {string} 查询字典需要用的key
 * */
export const dictionary = (types: string[]): Promise<DictionariesItem[]> => {
  return ajax.get<{ types: string }, DictionariesItem[]>('/auth/md/dictionary/list/types', {
    params: {
      types: types.join(','),
      $noLoad: true
    }
  });
};
/**
 * 上传主图
 * @param file 文件
 * */
export const uploadFile = (file: File, path = 'kmjs'): Promise<{ seq: string }> => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('dirName', path);
  // 重复上传会被拦截，导致失败，故此加随机数
  return ajax.post<FormData, { seq: string }>(
    '/auth/oss/upload/file?t=' + Math.random().toString(36).slice(-6),
    formData,
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }
  );
};
/**
 * 根据seq换取文件的地址
 * */
export const getFileUrlBySeq = (seqs: string): Promise<CommonOssCommonListSeqs> => {
  if (!seqs || seqs.trim().length === 0) {
    return Promise.resolve({});
  }
  return ajax.get('/api/oss/common/list/seqs', {
    params: {
      seqs,
      $noLoad: true
    }
  });
};

/**
 * 忘记密码/更新密码
 * */
export const updatePwd = (data: { newPassword: string; smsCode: string }): Promise<any> => {
  const pwd = md5(data.newPassword);
  return ajax.post('/api/sys/user/change/password', {
    newPassword: pwd,
    confirmPassword: pwd,
    smsCode: data.smsCode
  });
};

/**
 * 获取模版的配置通过SN
 * */
export const getModuleJSON = (
  sn: string
): Promise<{ configJson: string; actionList: { [l: string]: string } }> => {
  return ajax.get('/auth/md/inst/user/module/instance/' + sn, {
    params: {
      $InstId: true
    }
  });
};
/**
 * 上传用户点击菜单的记录
 * */
export const postMenuHistory = (menuSn: string) => {
  return ajax.post(`/auth/md/inst/menu/browse/${menuSn}`, undefined, {
    params: {
      $InstId: true,
      $noLoad: true
    }
  });
};

/**
 * 获得位置信息的树形结构的数据
 * */
export const getAddressTree = (sn = 'CHINA_001'): Promise<AreaItem[]> => {
  return ajax.get(`/auth/md/area/def/item/tree/${sn}/3`, {
    params: {
      $noLoad: true
    }
  });
};

/**
 * 表单模块内部组件获取业务数据接口，
 * 由表单系统提供统接口，取分发请求不同的业务数据接口
 * @param serverSn 业务接口对应的SN
 * @param query 接口对应的入参数据
 */
export const getBusinessDataByForm = (
  serverSn: string,
  query: Record<string, any>
): Promise<Record<string, any>[]> => {
  if (!serverSn) {
    return Promise.resolve([]);
  }
  return ajax.get(`/auth/md/form/def/step/item/business/${serverSn}`, {
    params: {
      $InstId: true,
      $noLoad: true,
      requestParams: JSON.stringify(query)
    }
  });
};

/**
 * 表格模块步进器校验
 * */
export const stepValidData = (
  validTypeSn: string,
  data: Record<string, any> = {}
): Promise<{ message: string; success: boolean }> => {
  return ajax.post(`/auth/md/form/def/valid/${validTypeSn}`, data, {
    params: {
      $noLoad: true,
      $InstId: true
    }
  });
};

/**
 * 根据商品sku和数量校验是否符合库存
 * */
export const validGoodsNumber = (
  goodsSn: string,
  goodsSkuSn: string,
  goodsNum: number
): Promise<{ success: boolean; message: string }> => {
  return ajax.get(`/auth//ec/goods/stock/summary/${goodsSn}/${goodsSkuSn}/${goodsNum}`, {
    params: {
      $noLoad: true,
      $InstId: true
    }
  });
};

/**
 * 根据流程定义发起流程
 * */
export const createBpmByDefSn = (
  defSn: string,
  data: {
    bizSn: string;
    jsonFormData?: string;
    createdOrgTreeSn: string;
    createdOrgTreeName: string;
  }
): Promise<{
  success: boolean;
  title: string;
  subTitle?: string;
  data: { label: string; value: string }[];
}> => {
  const requestId = new Date().getTime().toString(16);
  return ajax.post(`/auth/bpm/instance/${defSn}/${requestId}`, data, {
    params: {
      $InstId: true
    }
  });
};

/**
 * 流程预发起接口，主要是查询二次让用户确认的信息
 * */
export const getBpmAlertMsg = (
  defSn: string,
  bizSn?: string,
  busData?: string
): Promise<{ success: boolean; title: string }> => {
  return ajax.post(
    `/auth/bpm/instance/pre_start/${defSn}`,
    {
      bizSn,
      jsonFormData: busData
    },
    {
      params: {
        $InstId: true
      }
    }
  );
};
