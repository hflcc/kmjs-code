<template>
  <div class="hw100 index">
    <div class="header">
      <kmjs-header />
    </div>
    <div class="container">
      <kmjs-sidebar />
      <div class="main-wrap">
        <kmjsTabMenu />
        <div class="main">
          <router-view v-slot="{ Component, route }">
            <keep-alive :include="keepAlive">
              <component v-if="reloadCtl" :is="Component" :key="route.name" />
            </keep-alive>
          </router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, getCurrentInstance, nextTick, provide, ref } from 'vue';
  import kmjsHeader from '@/layout/components/header/index.vue';
  import kmjsSidebar from '@/layout/components/sidebar/index.vue';
  import kmjsTabMenu from '@/layout/components/tabsMenu/index.tsx';
  import kmjsBreadcrumb from '@/layout/components/breadcrumb/index.vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'index',
    components: {
      kmjsHeader,
      kmjsSidebar,
      kmjsTabMenu,
      kmjsBreadcrumb
    },
    setup() {
      const store = useStore();
      const reloadCtl = ref(true);
      const myReload = (name: string) => {
        if (name) {
          store.commit('menu/REMOVE_KEEP_ALIVE', name);
          reloadCtl.value = false;
        }
        nextTick(() => {
          store.commit('menu/ADD_KEEP_ALIVE', name);
          reloadCtl.value = true;
        });
      };
      provide('reload', myReload);

      const keepAlive = computed(() => {
        return store.getters['menu/keepAlive'];
      });
      return {
        reloadCtl,
        keepAlive
      };
    }
  });
</script>

<style lang="less" scoped>
  .index {
    display: flex;
    flex-direction: column;

    .container {
      display: flex;
      flex: 1;
      overflow: hidden;

      .sidebar {
        height: 100%;
        overflow-y: auto;
        overflow-x: hidden;
        background: rgb(48, 65, 86);
      }

      .main-wrap {
        display: flex;
        flex-direction: column;
        flex: 1;
        overflow: hidden;
      }

      .main {
        flex: 1;
        padding: 0 20px;
        overflow: auto;
      }
    }
  }
</style>
