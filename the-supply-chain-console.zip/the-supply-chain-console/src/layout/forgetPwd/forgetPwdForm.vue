<template>
  <el-form label-position="right" ref="form" :model="loginForm" :rules="loginRules">
    <el-form-item label="手机号" prop="account" label-width="80px">
      <el-input
        placeholder="请输入手机号"
        maxlength="11"
        v-model="loginForm.account"
        clearable
      ></el-input>
    </el-form-item>
    <el-form-item label="验证码" prop="messageCode" label-width="80px">
      <el-input
        placeholder="请输入验证码"
        maxlength="6"
        clearable
        type="text"
        v-model="loginForm.messageCode"
      >
      </el-input>
      <el-button @click="changeBtn" type="text" :disabled="btnDisable"
        >{{ messageContent }}
      </el-button>
    </el-form-item>
    <el-form-item label="新密码" prop="password" label-width="80px">
      <el-input
        placeholder="请输入新密码"
        type="text"
        show-password
        clearable
        v-model="loginForm.password"
      ></el-input>
    </el-form-item>
    <el-form-item label="确认密码" prop="confirmPassword" label-width="80px">
      <el-input
        placeholder="请输入确认密码"
        clearable
        type="text"
        show-password
        v-model="loginForm.confirmPassword"
      >
      </el-input>
    </el-form-item>
    <el-form-item>
      <el-button style="width: 100%" type="primary" block @click="login">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import useMessageTimeout from '@/layout/login/components/useMessageTimeout';
  import useLogin from '@/layout/forgetPwd/useLogin';
  import { sendMsg } from '@/utils/commApi';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'forget-pwd-page',
    setup() {
      const { btnDisable, messageContent, changeType } = useMessageTimeout();
      const { loginRules, login, loginForm, form } = useLogin();
      /**
       * 发送验证码
       * 先检验手机号是否符合规则。符合后，请求发送短信， 请求成功后。开始倒计时
       * */
      const changeBtn = () => {
        if (btnDisable.value) return;
        form.value?.validateField('account', async (r?: boolean) => {
          if (!r) {
            const res = await sendMsg(loginForm.account);
            if (!res) return;
            ElMessage.success(res.message);
            changeType();
          }
        });
      };

      return { loginRules, login, loginForm, form, messageContent, btnDisable, changeBtn };
    }
  });
</script>
<style lang="less"></style>
