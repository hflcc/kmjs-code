<template>
  <div class="forget-pwd-page page">
    <div class="content">
      <h4>修改密码</h4>
      <forgetPwdForm @on-success="success"></forgetPwdForm>
    </div>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import forgetPwdForm from '@/layout/forgetPwd/forgetPwdForm.vue';

  export default defineComponent({
    name: 'forget-pwd',
    components: {
      forgetPwdForm
    },
    methods: {
      success() {
        this.$router.push({ name: 'login' });
      }
    }
  });
</script>
<style lang="less">
  .forget-pwd-page .content {
    width: 60%;
    max-width: 500px;
    margin: 30vh auto;
  }
</style>
