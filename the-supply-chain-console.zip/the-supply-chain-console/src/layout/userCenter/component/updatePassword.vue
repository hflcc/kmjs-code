<template>
  <el-dialog title="修改密码" v-model="showDialog" @close="closeWindow"> </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { useDialog, useForm } from '@/utils';

  export default defineComponent({
    name: 'UC-update-pwd-dialog',
    props: {
      modelValue: {
        type: Boolean as PropType<boolean>,
        default: false
      }
    },
    setup(props, { emit }) {
      const { showDialog, closeWindow } = useDialog(props, emit);
      const { formElem } = useForm();
      return {
        formElem,
        showDialog,
        closeWindow
      };
    }
  });
</script>
<style lang="less"></style>
