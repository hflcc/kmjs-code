<!-- 个人中心 -->
<template>
  <div class="user-center-wrap page">
    <el-form :model="userMsg" label-width="80px">
      <el-form-item label="用户名">
        <el-input v-model="userMsg.name" disabled></el-input>
      </el-form-item>
      <el-form-item label="密码">
        <el-button type="text" v-if="!userMsg.password" @click="setPwd">设置登陆密码</el-button>
        <el-button type="text" v-else>修改密码</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'user-center',
    setup() {
      const store = useStore();
      const userMsg = computed(() => store.getters['user/userMsg']);
      const setPwd = () => {
        store.commit('user/SET_PWD_MODEL', true);
      };
      return {
        userMsg,
        setPwd
      };
    }
  });
</script>
<style lang="less">
  .user-center-wrap {
  }
</style>
