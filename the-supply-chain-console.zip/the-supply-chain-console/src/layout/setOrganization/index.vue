<template>
  <div class="set-organization-wrap page">
    <div class="kmjs-card choose-area">
      <div class="title">请选择机构</div>
      <div class="content">
        <el-card
          v-for="item in listData"
          :value="item.sn"
          :key="item.id"
          :label="item.name"
          @click="chooseItem(item.sn)"
          >{{ item.name }}
        </el-card>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, ref, onMounted } from 'vue';
  import { useStore } from 'vuex';
  import { useRouter, useRoute } from 'vue-router';

  interface InstItem {
    localId: string;
    id: number;
    sn: string;
    name: string;
    simpleName: string;
    roleId: number;
    operation: boolean;
  }

  export default defineComponent({
    name: 'set_organization',
    components: {},
    setup() {
      const route = useRoute();
      const store = useStore();
      const router = useRouter();
      const chooseInst = ref('');
      const listData = computed(() => store.getters['organization/organ']);
      const chooseItem = async (itemSn: string) => {
        await store.dispatch('organization/setActiveOrgan', itemSn);
        const p = (route.query.p as string) || '/';
        const q = (route.query.q as string) || '';
        await router.replace({ path: p, query: Object.fromEntries(new URLSearchParams(q)) });
      };
      onMounted(async () => {
        if (listData.value.length === 0) {
          await store.dispatch('organization/getIns');
        }
      });
      return { chooseInst, listData, chooseItem };
    }
  });
</script>

<style lang="less">
  .set-organization-wrap {
    text-align: center;
    background: #eee;
    overflow: auto;

    .choose-area {
      display: inline-block;
      width: 600px;
      margin: 20px;
      text-align: left;
      .el-card {
        margin-top: 10px;
        cursor: pointer;
        transform: scale(1);
        transform-origin: 50% 50% 0;

        &:hover {
          transform: scale(1.1);
        }
      }
    }
  }
</style>
