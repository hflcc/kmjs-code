import { reactive, ref } from 'vue';
import { ElForm } from 'element-plus';
import { validAccount, validMessageCode, validPassword } from '@/utils';
import { useRouter, useRoute } from 'vue-router';
import { useStore } from 'vuex';

export default function () {
  const route = useRoute();
  const router = useRouter();
  const store = useStore();
  // form 实例
  const form = ref<InstanceType<typeof ElForm>>();
  // 登录表单
  const loginForm = reactive({
    account: '',
    password: '',
    messageCode: ''
  });

  // 登录方法
  function login() {
    form.value?.validate().then((result: boolean) => {
      if (result) {
        // console.log('调用登录');
        store
          .dispatch('user/login', {
            username: loginForm.account.trim(),
            pwd: loginForm.password,
            messageCode: loginForm.messageCode
          })
          .then((res) => {
            if (res) {
              const organization = store.getters['organization/activeOrgan'];
              if (organization === null) {
                router.replace({ name: 'setOrganization', query: route.query });
              } else {
                const p = (route.query.p as string) || '/';
                const q = (route.query.q as string) || '';
                router.replace({ path: p, query: Object.fromEntries(new URLSearchParams(q)) });
              }
            }
          });
      }
    });
  }

  // 验证账号
  const validateAccount = (rule: unknown, value: string, callback: (value?: Error) => void) => {
    const result = validAccount(value);
    if (result === true) {
      callback();
    } else {
      callback(new Error(result));
    }
  };
  // 验证密码
  const validatePassword = (rule: unknown, value: string, callback: (value?: Error) => void) => {
    const result = validPassword(value);
    if (result === true) {
      callback();
    } else {
      callback(new Error(result));
    }
  };
  const validateMessageCode = (rule: unknown, value: string, callback: (value?: Error) => void) => {
    const result = validMessageCode(value);
    if (result === true) {
      callback();
    } else {
      callback(new Error(result));
    }
  };
  // 表单验证规则
  const loginRules = {
    account: [{ required: true, trigger: 'blur', validator: validateAccount }],
    password: [{ required: true, trigger: 'blur', validator: validatePassword }],
    messageCode: [{ required: true, trigger: 'blur', validator: validateMessageCode }]
  };
  return {
    loginRules,
    login,
    loginForm,
    form
  };
}
