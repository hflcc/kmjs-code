<template>
  <div class="login-page hw100 center_box">
    <div class="box-main">
      <div class="swiper-area">
        <div class="system-title-area">
          <!--          <h1 class="system-title">康美集势 <span class="line">|</span> 环销后台管理系统</h1>-->
          <h1 class="system-title">康美集势 <span class="line">|</span> {{ renderMsg.sysName }}</h1>
          <!--          <p class="system-info">产业门户+集供中心</p>-->
          <!--          <p class="system-info">助推美丽大健康产业互联网升级</p>-->
          <p class="system-info">{{ renderMsg.loginDescr }}</p>
        </div>
        <div class="swiper-wrap">
          <el-carousel height="250px" arrow="never" :interval="10000" trigger="click">
            <el-carousel-item v-for="item in swiperItem" :key="item">
              <img :src="item" alt="" style="width: 100%" />
            </el-carousel-item>
          </el-carousel>
        </div>
      </div>
      <div class="form-area">
        <div class="tab-bar">
          <div class="tab-item" @click="changeType('pwd')">密码登录</div>
          <div class="tab-item" @click="changeType('message')">验证码登录</div>
          <div class="line" :class="linePosition ? '' : 'right'"></div>
        </div>
        <div class="form-wrap">
          <pwdLogin v-if="type === 'pwd'" />
          <messageLogin v-else />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, reactive, ref } from 'vue';
  import pwdLogin from '@/layout/login/components/pwd.vue';
  import messageLogin from '@/layout/login/components/message.vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'login',
    components: {
      pwdLogin,
      messageLogin
    },
    setup() {
      const store = useStore();
      store.commit('user/SET_PWD_MODEL', false);
      // 表单的类型。pwd 密码 message 验证码
      const type = ref('pwd');
      const linePosition = computed(() => type.value === 'pwd');
      const changeType = (tp: string) => {
        type.value = tp;
      };

      const swiperItem = reactive([
        'https://kmjs.oss-cn-shenzhen.aliyuncs.com/kmjs/b28bae17470d4361a1391c1da4dfac88.png'
      ]);
      const renderMsg = computed(() => store.getters['systemInfo/loginData']);
      return {
        renderMsg,
        changeType,
        linePosition,
        type,
        swiperItem
      };
    }
  });
</script>

<style lang="less">
  .login-page {
    position: relative;
    background: #eee;

    .box-main {
      display: flex;
      width: 800px;
      height: 400px;
      background: #fff;
      border-radius: 4px;
      overflow: hidden;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate3d(-50%, -50%, 0);

      .swiper-area {
        flex: 1;
        height: 100%;
        background: @primary;
        padding: 10px;

        .line {
          font-weight: normal;
        }

        .system-title-area {
          color: #fff;

          .system-title {
            font-weight: bolder;
            font-size: 28px;
            margin-bottom: 10px;
            padding-top: 20px;
          }

          .system-info {
            margin-bottom: 10px;
            font-size: 12px;
            line-height: 1.3em;
            white-space: break-spaces;
          }
        }
      }

      .form-area {
        padding-top: 30px;
        flex: 1;
      }

      .tab-bar {
        width: 100%;
        text-align: center;
        position: relative;
        padding-bottom: 10px;

        .tab-item {
          display: inline-block;

          & + .tab-item {
            margin-left: 50px;
          }
        }

        .line {
          position: absolute;
          left: 50%;
          bottom: 0;
          transition: transform 180ms linear;
          transform: translate3d(-90px, 0, 0);
          width: 50px;
          height: 3px;
          background: @primary;
          margin: 0;

          &.right {
            transform: translate3d(35px, 0, 0);
          }
        }
      }

      .form-wrap {
        margin-top: 30px;
        height: 300px;
        padding: 0 20px;
      }
    }

    .el-carousel__button {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #fff;
      opacity: 1;
    }

    .el-carousel__indicator.is-active button {
      width: 20px;
      border-radius: 10px;
    }
  }
</style>
