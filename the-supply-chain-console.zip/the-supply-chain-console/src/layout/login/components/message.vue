<template>
  <el-form
    label-position="right"
    ref="form"
    :model="loginForm"
    :rules="loginRules"
    @submit.prevent="login"
  >
    <el-form-item label="手机号" prop="account" label-width="80px">
      <el-input placeholder="请输入手机号" v-model="loginForm.account"></el-input>
    </el-form-item>
    <el-form-item label="验证码" prop="messageCode" label-width="80px">
      <el-input
        placeholder="请输入验证码"
        maxlength="6"
        clearable
        type="text"
        v-model="loginForm.messageCode"
      >
      </el-input>
      <el-button @click="changeBtn" type="text" :disabled="btnDisable"
        >{{ messageContent }}
      </el-button>
    </el-form-item>
    <el-form-item>
      <el-button style="width: 100%" type="primary" block native-type="submit">登录</el-button>
    </el-form-item>
  </el-form>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import useLogin from '@/layout/login/useLogin';
  import useMessageTimeout from '@/layout/login/components/useMessageTimeout';
  import { sendMsg } from '@/utils/commApi';
  import { ElMessage } from 'element-plus';

  export default defineComponent({
    name: 'message-login',
    setup() {
      const { btnDisable, messageContent, changeType } = useMessageTimeout();
      const { loginRules, login, loginForm, form } = useLogin();
      /**
       * 发送验证码
       * 先检验手机号是否符合规则。符合后，请求发送短信， 请求成功后。开始倒计时
       * */
      const changeBtn = () => {
        if (btnDisable.value) return;
        form.value?.validateField('account', async (r?: boolean) => {
          if (!r) {
            const res = await sendMsg(loginForm.account);
            if (!res) return;
            ElMessage.success(res.message);
            changeType();
          }
        });
      };

      return { loginRules, login, loginForm, form, messageContent, btnDisable, changeBtn };
    }
  });
</script>
