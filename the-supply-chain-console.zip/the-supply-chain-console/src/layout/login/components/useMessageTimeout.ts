import { computed, ref, onUnmounted } from 'vue';

export default () => {
  // 这里setInterval类型真的不知道是啥
  // eslint-disable-next-line
  // @ts-ignore-next-line
  let timeout: null | NodeJS.Timeout = null;
  const messageTime = 120;
  // 按钮类型，button 显示发送验证码， time 显示倒计时
  const messageType = ref('button');
  // 计算倒计时
  const time = ref(messageTime);
  // 按钮内容
  const messageContent = computed(() => {
    if (messageType.value === 'button') {
      return '发送验证码';
    } else {
      return `${time.value}秒后重新发送`;
    }
  });
  // 是否可点击
  const btnDisable = computed(() => messageType.value === 'time');
  const changeType = () => {
    messageType.value = 'time';
    timeout = setInterval(() => {
      time.value--;
      if (time.value <= 0) {
        timeout && clearInterval(timeout);
        messageType.value = 'button';
        time.value = messageTime;
      }
    }, 1000);
  };
  onUnmounted(() => {
    timeout && clearInterval(timeout);
  });
  return {
    btnDisable,
    messageContent,
    changeType
  };
};
