<template>
  <el-form
    label-position="right"
    ref="form"
    label-width="80px"
    :model="loginForm"
    :rules="loginRules"
    @submit.prevent="login"
  >
    <el-form-item label="账户" prop="account">
      <el-input placeholder="请输入账号" v-model="loginForm.account"></el-input>
    </el-form-item>
    <el-form-item label="密码" prop="password">
      <el-input placeholder="请输入密码" v-model="loginForm.password" show-password></el-input>
    </el-form-item>
    <el-form-item>
      <el-button style="width: 100%" type="primary" block native-type="submit">登录</el-button>
    </el-form-item>
  </el-form>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  import useLogin from '@/layout/login/useLogin';

  export default defineComponent({
    name: 'pwd-login',
    setup() {
      const { loginRules, login, loginForm, form } = useLogin();
      return { loginRules, login, loginForm, form };
    }
  });
</script>
