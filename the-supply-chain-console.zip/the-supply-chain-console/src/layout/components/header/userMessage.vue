<template>
  <div class="user-area">
    <el-dropdown @command="handleCommand" style="height: 100%">
      <div class="user-wrap">
        <!--        <div class="header-img"></div>-->
        <div class="msg">
          <div class="name item">
            {{ userMsg && userMsg.name }} <i class="el-icon-arrow-down"></i>
          </div>
        </div>
      </div>
      <template #dropdown>
        <el-dropdown-menu>
          <!--          <el-dropdown-item command="userCenter">个人中心</el-dropdown-item>-->
          <el-dropdown-item command="logout">登出</el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script lang="ts">
  import { useStore } from 'vuex';
  import { useRouter } from 'vue-router';
  import { defineComponent, computed } from 'vue';
  import { ElMessageBox } from 'element-plus';

  export default defineComponent({
    name: 'userMsg',
    setup() {
      const store = useStore();
      const router = useRouter();
      const userMsg = computed(() => store.getters['user/userMsg']);
      const logout = () => {
        ElMessageBox.confirm('确认退出？', '退出').then(() => {
          store.dispatch('user/logOut').then((res) => {
            if (res) {
              router.push({ path: '/login' }).then(() => {
                window.location.reload();
              });
            }
          });
        });
      };
      const routerTo = (name: string) => {
        router.push({ name });
      };
      const handleCommand = (name: string) => {
        if (name === 'logout') {
          logout();
        } else {
          router.push({ name });
        }
      };
      return {
        handleCommand,
        routerTo,
        userMsg,
        logout
      };
    }
  });
</script>
