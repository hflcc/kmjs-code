<!-- 组织架构 -->
<template>
  <div class="organization-wrap">
    <el-row align="middle" v-if="showChannel">
      <el-col :span="7">
        <el-select
          :model-value="activeOrgan"
          @change="(v) => change('setActiveOrgan', v)"
          placeholder="请选择机构"
        >
          <el-option
            v-for="item in organ"
            :key="item.sn"
            :value="item.sn"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>
      <el-col :span="1" style="display: flex; align-items: center">
        <div class="line"></div>
      </el-col>
      <el-col :span="7">
        <el-select
          :model-value="activeChannel"
          @change="(v) => change('setActiveChannel', v)"
          placeholder="请选择渠道"
        >
          <el-option
            v-for="item in channel"
            :key="item.sn"
            :value="item.sn"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>
      <el-col :span="1" style="display: flex; align-items: center">
        <div class="line"></div>
      </el-col>
      <el-col :span="7">
        <el-select
          :model-value="activeOrganization"
          @change="(v) => change('setOrganization', v)"
          placeholder="请选择组织"
        >
          <el-option
            v-for="item in organization"
            :key="item.sn"
            :value="item.sn"
            :label="item.name"
          ></el-option>
        </el-select>
      </el-col>
    </el-row>
    <el-select
      v-else
      :model-value="activeOrgan"
      @change="(v) => change('setActiveOrgan', v)"
      placeholder="请选择机构"
    >
      <el-option
        v-for="item in organ"
        :key="item.sn"
        :value="item.sn"
        :label="item.name"
      ></el-option>
    </el-select>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'organization-component',
    setup() {
      const store = useStore();
      const organ = computed(() => store.getters['organization/organ']);
      const showChannel = computed(() => store.getters['organization/showChannel']);
      const activeOrgan = computed(() => {
        const data = store.getters['organization/activeOrgan'];
        return data?.sn || '';
      });
      const organization = computed(() => store.getters['organization/organization']);
      const activeOrganization = computed(() => {
        const data = store.getters['organization/activeOrganization'];
        return data?.sn || '';
      });
      const channel = computed(() => store.getters['organization/channel']);
      const activeChannel = computed(() => {
        const data = store.getters['organization/activeChannel'];
        return data?.sn || '';
      });
      const change = (name: string, value: string) => {
        store.dispatch('organization/' + name, value);
      };
      return {
        showChannel,
        change,
        organ,
        activeOrgan,
        organization,
        activeOrganization,
        channel,
        activeChannel
      };
    }
  });
</script>
