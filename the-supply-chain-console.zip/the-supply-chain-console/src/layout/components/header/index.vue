<template>
  <header class="header-wrap">
    <div class="logo-area">
      <div class="logo-wrap">
        <img
          src="https://kmjs.oss-cn-shenzhen.aliyuncs.com/kmjs/5ae8b4a2750e47589409d6686c9645ef.png"
          alt=""
        />
      </div>
      <h1 class="logo-title">{{ renderMsg.sysName }}</h1>
    </div>
    <!--
      <div class="menu-icon-trigger" @click="triggerMenu">
          <i class="el-icon-s-unfold" v-if="sideBarStats"></i>
          <i class="el-icon-s-fold" v-else></i>
       </div>
       -->
    <organization />
    <UserMessage />
  </header>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import UserMessage from '@/layout/components/header/userMessage.vue';
  import organization from '@/layout/components/header/organization.vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'xHeader',
    components: {
      UserMessage,
      organization
    },
    setup() {
      const store = useStore();
      const sideBarStats = computed(() => store.getters['menu/iconMenu']);
      const triggerMenu = () => {
        store.commit('menu/UPDATE_ICON_MENU', !sideBarStats.value);
      };
      const renderMsg = computed(() => store.getters['systemInfo/loginData']);
      return { sideBarStats, triggerMenu, renderMsg };
    }
  });
</script>

<style lang="less">
  @import './header.less';
</style>
