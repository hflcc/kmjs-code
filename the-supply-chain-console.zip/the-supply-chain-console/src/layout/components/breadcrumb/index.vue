<template>
  <div class="breadcrumb-wrap">
    <el-breadcrumb>
      <transition-group name="breadcrumb">
        <el-breadcrumb-item
          :to="{ path: item.path }"
          v-for="item in breadcrumbData"
          :key="item.name"
          >{{ item.meta.title }}
        </el-breadcrumb-item>
      </transition-group>
    </el-breadcrumb>
  </div>
</template>

<script lang="ts">
  import { useRoute } from 'vue-router';
  import { defineComponent, computed } from 'vue';

  export default defineComponent({
    name: 'breadcrumb',
    setup() {
      const route = useRoute();
      const breadcrumbData = computed(() => {
        let matched = route.matched.filter((item) => item.meta && item.meta.title);

        return matched.filter((item) => {
          if (item.name !== 'rootRoute')
            return item.meta && item.meta.title && item.meta.breadcrumb !== false;
        });
      });
      return {
        breadcrumbData
      };
    }
  });
</script>

<style lang="less">
  .breadcrumb-wrap {
    padding: 10px 40px;
  }

  /* breadcrumb transition */
  .breadcrumb-enter-active,
  .breadcrumb-leave-active {
    transition: all 0.5s;
  }

  .breadcrumb-enter,
  .breadcrumb-leave-active {
    opacity: 0;
    transform: translateX(20px);
  }

  .breadcrumb-move {
    transition: all 0.5s;
  }

  .breadcrumb-leave-active {
    position: absolute;
  }
</style>
