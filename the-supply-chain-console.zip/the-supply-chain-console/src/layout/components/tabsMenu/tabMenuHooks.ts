import { computed, inject, nextTick } from 'vue';
import { useStore } from 'vuex';
import { useRoute, useRouter } from 'vue-router';
import { ElMessageBox } from 'element-plus';

export default function () {
  const store = useStore();
  const router = useRouter();
  const route = useRoute();
  const activeRoute = computed(() => store.getters['menu/activeRoute']);
  const routes = computed(() => store.getters['menu/tabMenus']);
  const routeName = route.name as string;
  /**
   * 切换选中的tab
   * */
  const changeTab = (item: TabMenuItem) => {
    if (item.fullPath === activeRoute.value) return;
    store.commit('menu/CHANGE_ACTIVE_MENU', item.path);
    router.push({ path: item.path, query: item.query, params: item.params });
  };
  /**
   * 删除一个Tab，如果是当前选中的tab就自动切换到前一个Tab
   * */
  const deleteTab = (item: TabMenuItem) => {
    const routeIndex = routes.value.indexOf(item);
    if (routeIndex > -1) {
      if (activeRoute.value === item.path) {
        changeTab(routes.value[routeIndex - 1]);
        nextTick(() => {
          store.commit('menu/DEL_TAB_MENUS', item);
        });
      } else {
        store.commit('menu/DEL_TAB_MENUS', item);
      }
      if (item.path.substr(0, 3) === '/FM') {
        router.removeRoute(item.name as string);
      }
    }
    store.commit('menu/REMOVE_KEEP_ALIVE', item.keepName);
  };

  const closeTab = (item: TabMenuItem) => {
    if (typeof item.beforeClose === 'function') {
      item.beforeClose((flag) => {
        if (flag) {
          deleteTab(item);
        }
      });
    } else {
      deleteTab(item);
    }
  };

  const closeWindow = () => {
    const item = routes.value.find((s: TabMenuItem) => routeName === s.name);
    if (item) {
      deleteTab(item);
    }
  };

  const beforeCloseTab = (handler: (next: (flag: boolean) => void) => void) => {
    store.commit('menu/SET_TAB_BEFORE_CLOSE', {
      name: route.name,
      handler
    });
  };

  const closeAllTab = () => {
    ElMessageBox.confirm('确认关闭所有页面吗？', '提示').then(() => {
      store.commit('menu/CLEAR_TABS');
      router.push({ name: 'home' }).then();
      router.getRoutes().forEach((s) => {
        if (s.path.substr(0, 3) === '/FM') {
          router.removeRoute(s.name as string);
        }
      });
    });
  };
  return {
    routes,
    activeRoute,
    closeTab,
    changeTab,
    closeWindow,
    beforeCloseTab,
    closeAllTab
  };
}
