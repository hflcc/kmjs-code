import { defineComponent, watchEffect, computed } from 'vue';
import { useRoute } from 'vue-router';
import useTabsMenuHooks from './tabMenuHooks';
import { useStore } from 'vuex';

import './style.less';

export default defineComponent({
  name: 'tabs-menu',
  setup() {
    const store = useStore();
    const route = useRoute();
    let nextPath = '';
    const { routes, activeRoute, changeTab, closeTab, closeAllTab } = useTabsMenuHooks();
    /**
     * 这里不可以使用watch， watch监听route时，默认会进行深度监听。导致页面切换卡顿
     * */
    watchEffect(() => {
      // 这一步是因为watchEffect会在删除tab后在触发一次，导致重复添加
      if (nextPath === route.path) return;
      nextPath = route.path;
      if (route.meta.keepName) {
        const item = routes.value.find((v: TabMenuItem) => v.path === route.path) || null;
        if (!item) {
          store.commit('menu/ADD_TAB_MENUS', {
            title: route.meta.title as string,
            name: route.name as string,
            path: route.path,
            query: route.query,
            params: route.params,
            fullPath: route.fullPath,
            keepName: route.meta.keepName as string,
            isNewTap: route.meta.newTap && route.meta.once
          });
          if (route.meta.keepName) {
            store.commit('menu/ADD_KEEP_ALIVE', route.meta.keepName);
          }
        }
        store.commit('menu/CHANGE_ACTIVE_MENU', route.path as string);
      }
    });
    const sideBarStats = computed(() => store.getters['menu/iconMenu']);
    const triggerMenu = () => {
      store.commit('menu/UPDATE_ICON_MENU', !sideBarStats.value);
    };
    return {
      sideBarStats,
      triggerMenu,
      activeRoute,
      routes,
      changeTab,
      closeTab,
      closeAllTab
    };
  },
  render() {
    const iconType: Record<string, string> = {
      create: 'circle-plus-outline',
      detail: 'document',
      edit: 'edit-outline'
    };
    const { sideBarStats, triggerMenu, closeAllTab, activeRoute, routes, changeTab, closeTab } =
      this;
    const items = routes.map((v: TabMenuItem) => {
      if (v.title.length > 7) {
        return (
          <el-tooltip content={v.title} placement="bottom">
            <div
              onClick={() => changeTab(v)}
              class={['tab-item', v.path === activeRoute ? 'active' : ''].join(' ')}
            >
              {/*{iconType[v.type] ? <i class={{ ['el-icon-' + iconType[v.type]]: true }} /> : null}*/}
              {v.title}
              {v.name === 'home' ? null : (
                <i
                  class="close-icon el-icon-close"
                  onClick={(e) => {
                    e.stopPropagation();
                    closeTab(v);
                  }}
                />
              )}
            </div>
          </el-tooltip>
        );
      }
      return (
        <div
          onClick={() => changeTab(v)}
          class={['tab-item', v.path === activeRoute ? 'active' : ''].join(' ')}
        >
          {iconType[v.type] ? <i class={{ ['el-icon-' + iconType[v.type]]: true }} /> : null}
          {v.title}
          {v.name === 'home' ? null : (
            <i
              class="close-icon el-icon-close"
              onClick={(e) => {
                e.stopPropagation();
                closeTab(v);
              }}
            />
          )}
        </div>
      );
    });
    return (
      <div class="tab-menu-wrap">
        <div class="menu-icon-trigger" onClick={triggerMenu}>
          {sideBarStats ? <i class="el-icon-s-unfold"></i> : <i class="el-icon-s-fold"></i>}
        </div>
        <div class="tab-menu-items">{items}</div>
        <div class="icon-area">
          <el-tooltip effect="dark" content="关闭全部" placement="bottom">
            <i class="icon el-icon el-icon-circle-close" onClick={closeAllTab}></i>
          </el-tooltip>
        </div>
      </div>
    );
  }
});
