<template>
  <div class="sidebar">
    <el-menu
      :default-active="activeMenu"
      class="menu"
      @select="selectMenu"
      :collapse="iconMenu"
      background-color="#304156"
      text-color="#bfcbd9"
      active-text-color="#fff"
    >
      <kmjs-sidebar-item v-for="(item, index) in menu" :data="item" :key="index" />
    </el-menu>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import kmjsSidebarItem from '@/layout/components/sidebar/item.vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'sidebar',
    components: {
      kmjsSidebarItem
    },
    setup() {
      const store = useStore();
      const route = useRoute();
      const router = useRouter();
      const selectMenu = (data: string) => {
        router.push({ name: data });
      };
      const iconMenu = computed(() => store.getters['menu/iconMenu']);
      const menu = computed(() => {
        return store.getters['user/menus'];
      });
      const activeMenu = computed(() => {
        // const paths = route.path.split('/');
        // return paths.slice(paths.length - 1)[0];
        return route.name;
      });
      return {
        menu,
        selectMenu,
        iconMenu,
        activeMenu
      };
    }
  });
</script>

<style lang="less">
  .sidebar {
    .menu {
      height: 100%;

      &:not(.el-menu--collapse) {
        width: 150px;
      }
    }

    .el-menu--collapse .title {
      display: none;
    }
    .el-menu-item.is-active {
      background: #263445 !important;
    }
  }
</style>
