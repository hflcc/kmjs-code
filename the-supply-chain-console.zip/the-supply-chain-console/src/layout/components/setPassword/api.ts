import ajax from '@/utils/axios';
import md5 from 'js-md5';

export const setPwd = (
  pwd: string
): Promise<{
  success: string;
  message: string;
}> => {
  return ajax.post<
    {
      password: string;
      authType: string;
    },
    {
      success: string;
      message: string;
    }
  >('/auth/sys/user/current/password/integrity', {
    password: md5(pwd),
    confirmPassword: md5(pwd),
    authType: 'password'
  });
};
