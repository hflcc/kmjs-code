import { computed, defineComponent, reactive, ref } from 'vue';
import { ElForm } from 'element-plus';
import { setPwd } from '@/layout/components/setPassword/api';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'setPwd',
  setup() {
    const store = useStore();
    const showModel = computed(() => store.state.user.showSetPwd);
    const setPwdData = reactive({
      pwd: '',
      setPwd: ''
    });
    const validRules = reactive({
      pwd: [
        {
          required: true,
          message: '请输入新密码',
          trigger: 'blur'
        },
        {
          validator: (rule: unknown, value: string, callback: (value?: Error) => void) => {
            const re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[~@#$%*+=]).{6,16}$/;
            if (!re.test(value)) {
              callback(new Error('请输入6～16位数字、字母或字符组成的密码'));
            } else {
              callback();
            }
          }
        }
      ],
      setPwd: [
        {
          required: true,
          message: '请确认新密码',
          trigger: 'blur'
        },
        {
          validator: (rule: unknown, value: string, callback: (value?: Error) => void) => {
            if (value !== setPwdData.pwd) {
              callback(new Error('两次输入的密码不一致'));
            } else {
              callback();
            }
          }
        }
      ]
    });
    // form 实例
    const form = ref<InstanceType<typeof ElForm>>();
    const getValue = () => {
      form.value?.validate((res) => {
        setPwd(setPwdData.pwd).then((res) => {
          if (res) {
            store.commit('user/SET_PWD_MODEL', false);
          }
        });
      });
    };
    return {
      setPwdData,
      showModel,
      form,
      validRules,
      getValue
    };
  },
  render() {
    const { setPwdData, showModel, getValue, validRules } = this;
    return (
      <el-dialog
        v-model={showModel}
        title="请设置您的密码"
        show-close={false}
        close-on-click-modal={false}
        close-on-press-escape={false}
      >
        <p style={{ color: '#999', marginLeft: '10px', marginBottom: '10px' }}>
          * 请输入6～16位数字、字母或字符组成的密码
        </p>
        <el-form ref="form" rules={validRules} model={setPwdData} label-width="80px">
          <el-form-item label="新密码" prop="pwd">
            <el-input v-model={setPwdData.pwd} show-password></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="setPwd">
            <el-input v-model={setPwdData.setPwd} show-password></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" onClick={getValue}>
              提交
            </el-button>
          </el-form-item>
        </el-form>
      </el-dialog>
    );
  }
});
