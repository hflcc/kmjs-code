<template>
  <router-view v-slot="{ Component }">
    <keep-alive :include="keepAlive">
      <component :is="Component"></component>
    </keep-alive>
  </router-view>
</template>
<script lang="ts">
  import { defineComponent, computed } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'layoutView',
    setup() {
      const store = useStore();
      const keepAlive = computed(() => store.getters['menu/keepAlive']);
      return {
        keepAlive
      };
    }
  });
</script>
