import { createStore } from 'vuex';
import createPersistedState from 'vuex-persistedstate';
import im from './commModules/im';
import user from './commModules/user';
import menu from './commModules/menu';
import dictionaries from './commModules/dictionaries';
import organization from './commModules/organization/index';
import systemInfo from './commModules/system';
import goods from './commModules/libraryOfGoods';
import businessModule from './businessModule/index';
import listToDetailModule from './commModules/listToDetail';
import sourceModule from '@/store/commModules/source.ts';

const store = createStore<RootState>({
  modules: {
    im,
    user,
    menu,
    dictionaries,
    organization,
    systemInfo,
    goods,
    listToDetailModule,
    source: sourceModule,
    ...businessModule
  },
  plugins: [
    createPersistedState({
      key: 'vuex',
      storage: window.sessionStorage,
      // 缓存哪些字段
      paths: [
        'organization.activeOrganizationSn',
        'organization.activeChannelSn',
        'organization.activeOrganSn'
      ]
    })
  ]
});
export default store;
