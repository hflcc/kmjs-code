import demoModule from '@/store/businessModule/demoModule';

export default {
  demoModule
};
