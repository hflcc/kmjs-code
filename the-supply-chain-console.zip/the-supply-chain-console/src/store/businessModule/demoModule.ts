import { Module } from 'vuex';

interface DemoModule {
  demo: 'ss';
}

/* 菜单 */
const demoModule: Module<DemoModule, RootState> = {
  namespaced: true,
  state: {
    demo: 'ss'
  },
  mutations: {},
  getters: {},
  actions: {}
};

export default demoModule;
