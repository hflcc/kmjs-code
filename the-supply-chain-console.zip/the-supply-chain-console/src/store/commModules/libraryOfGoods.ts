import { Module } from 'vuex';
// 规格信息
const goodsStore: Module<GoodsStore, RootState> = {
  namespaced: true,
  state: {
    specs: [],
    tiered: [],
    isSpecsIndex: 0
  },
  mutations: {
    SET_SPECS(state: GoodsStore, data: SpecsStore[]) {
      state.specs = data;
    },
    SET_TIERED(state: GoodsStore, data: StepPricesStore[]) {
      state.tiered = data;
    },
    SET_ISSPECSINDEX(state: GoodsStore, data: number) {
      state.isSpecsIndex = data;
    }
  }
};
export default goodsStore;
