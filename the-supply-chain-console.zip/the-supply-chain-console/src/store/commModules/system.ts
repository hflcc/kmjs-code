import { Module } from 'vuex';
import { getSystemInfo, getFileUrlBySeq } from '@/utils/commApi';
/* 菜单 */
const systemModule: Module<SystemStore, RootState> = {
  namespaced: true,
  state: {
    navMenu: '',
    asideMenu: '',
    sysName: '',
    sysLogo: '',
    loginDescr: '',
    loginBanner: [],
    theme: ''
  },
  mutations: {
    UPDATA_SYSTEM(state, value) {
      Object.assign(state, value);
    }
  },
  getters: {
    loginData: (state) => {
      return {
        sysName: state.sysName,
        loginDescr: state.loginDescr,
        loginBanner: state.loginBanner
      };
    },
    asideMenu: (state) => state.asideMenu
  },
  actions: {
    async getSystemData({ commit, state }) {
      const data: SystemStore = {} as SystemStore;
      const res = await getSystemInfo();
      if (res) {
        if (res.login_banner) {
          const imgUrls = await getFileUrlBySeq(res.login_banner);
          if (imgUrls) {
            data.loginBanner = res.login_banner.split(',').map((v) => {
              return imgUrls[v]?.url;
            });
          }
        }
        data.asideMenu = res.aside_menu;
        data.loginDescr = res.login_descr;
        document.title = res.sys_name;
        data.sysName = res.sys_name;
        data.sysLogo = res.sys_logo;
        commit('UPDATA_SYSTEM', data);
      }
    }
  }
};

export default systemModule;
