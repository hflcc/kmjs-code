import { Module } from 'vuex';
import tim from '@/utils/tim';
/* 菜单 */
const menuModule: Module<MenuInfo, RootState> = {
  namespaced: true,
  state: {
    // 菜单是不是只显示为ICON
    iconMenu: false,
    // 需要被keep-alive缓存的页面组件
    keepAlive: ['home', 'layoutView'],
    // tabs菜单
    activeRoute: '/home',
    // 被加入tabs中的菜单项
    tabMenus: [
      {
        title: '首页',
        name: 'home',
        path: '/home',
        keepName: 'home',
        fullPath: '',
        query: {},
        params: {},
        type: '',
        isNewTap: false
      }
    ]
  },
  mutations: {
    UPDATE_ICON_MENU(state: MenuInfo, data: boolean) {
      state.iconMenu = data;
    },
    ADD_KEEP_ALIVE(state: MenuInfo, name: string) {
      if (state.keepAlive.indexOf(name) === -1) {
        state.keepAlive.push(name);
      }
    },
    REMOVE_KEEP_ALIVE(state: MenuInfo, name: string) {
      const index = state.keepAlive.indexOf(name);
      if (index > -1) {
        state.keepAlive.splice(index, 1);
      }
    },
    CHANGE_ACTIVE_MENU(state: MenuInfo, name: string) {
      state.activeRoute = name;
    },
    ADD_TAB_MENUS(state: MenuInfo, data: TabMenuItem) {
      state.tabMenus.push(data);
    },
    DEL_TAB_MENUS_BYPATH(state: MenuInfo, path: string) {
      const index = state.tabMenus.findIndex((s) => s.path === path);
      if (index > -1) {
        state.tabMenus.splice(index, 1);
      }
    },
    DEL_TAB_MENUS(state: MenuInfo, data: TabMenuItem) {
      const index = state.tabMenus.indexOf(data);
      if (index > -1) {
        state.tabMenus.splice(index, 1);
      }
    },
    SET_TAB_TITLE(state: MenuInfo, data: { name: string; title: string; type: string }) {
      const item = state.tabMenus.find((s) => s.name === data.name);
      if (item) {
        item.title = data.title;
        item.type = (data.type as '') || '';
      }
    },
    SET_TAB_BEFORE_CLOSE(
      state: MenuInfo,
      data: { name: string; handler: (next: (flag: boolean) => void) => void }
    ) {
      const item = state.tabMenus.find((s) => s.name === data.name);
      if (item) {
        item.beforeClose = data.handler;
      }
    },
    CLEAR_TABS(state: MenuInfo) {
      state.tabMenus = [
        {
          title: '首页',
          name: 'home',
          path: '/home',
          keepName: 'home',
          fullPath: '',
          query: {},
          params: {},
          type: '',
          isNewTap: false
        }
      ];
      state.keepAlive = ['home', 'layoutView'];
      state.activeRoute = '/home';
    }
  },
  getters: {
    iconMenu(state: MenuInfo): boolean {
      return state.iconMenu;
    },
    keepAlive(state: MenuInfo): string[] {
      return Array.from(state.keepAlive);
    },
    tabMenus(state: MenuInfo): TabMenuItem[] {
      return [...state.tabMenus];
    },
    activeRoute(state: MenuInfo): string {
      return state.activeRoute;
    }
  }
};

export default menuModule;
