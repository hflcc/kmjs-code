import { ActionContext, Module } from 'vuex';
import { getAddressTree, getFileUrlBySeq } from '@/utils/commApi';

const ajax: Record<string, Promise<CommonOssCommonListSeqs>> = {};
/* 公共资源缓存 */
const sourceModule: Module<SourceStore, RootState> = {
  namespaced: true,
  state: {
    ossUrl: {},
    addressData: null
  },
  mutations: {
    SET_ADDRESS_DATA(state, data) {
      state.addressData = data;
    },
    SET_OSS_URL_DATA(state, data) {
      state.ossUrl = Object.assign(state.ossUrl, data);
    }
  },
  actions: {
    async getAddressData({ state, commit }: ActionContext<SourceStore, RootState>) {
      if (state.addressData) {
        return state.addressData;
      }
      const data = await getAddressTree();
      commit('SET_ADDRESS_DATA', data);
      return data;
    },
    async getOssUrl({ state, commit }: ActionContext<SourceStore, RootState>, seqs: string[]) {
      const objData: Record<string, { url: string; seq: string }> = {};
      // 提取文件的过期时间
      const reg = new RegExp('Expires=([^&]*)(&|$)');
      for (let i = 0; i < seqs.length; i++) {
        const s = seqs[i];
        if (state.ossUrl[s]) {
          const url = state.ossUrl[s].url;
          const r = url.match(reg);
          if (r != null && /^\d+$/.test(r[1])) {
            // 预留三分钟过期时间，重新请求
            if (new Date().getTime() > Number(r[1]) * 1000 - 60 * 1000 * 3) {
              // 文件过期
              if (ajax[s]) {
                delete ajax[s];
              }
            } else {
              // 没有过期，复用
              objData[s] = {
                url: state.ossUrl[s].url,
                seq: s
              };
              seqs.splice(i, 1);
              i--;
            }
          } else {
            // 找不到过期时间，直接复用
            objData[s] = {
              url: state.ossUrl[s].url,
              seq: s
            };
            seqs.splice(i, 1);
            i--;
          }
        }
      }
      if (seqs.length) {
        const key = seqs.join(',');
        let ajaxFun = null;
        if (ajax[key]) {
          ajaxFun = ajax[key];
        } else {
          ajaxFun = getFileUrlBySeq(seqs.join(','));
          ajax[key] = ajaxFun;
        }
        const res = await ajaxFun;
        if (!res) {
          return objData;
        }
        for (let i = 0; i < seqs.length; i++) {
          const s = seqs[i];
          if (res[s]) {
            objData[s] = {
              url: res[s].url,
              seq: s
            };
            seqs.splice(i, 1);
            i--;
          }
        }
        commit('SET_OSS_URL_DATA', res);
      }
      return objData;
    }
  }
};

export default sourceModule;
