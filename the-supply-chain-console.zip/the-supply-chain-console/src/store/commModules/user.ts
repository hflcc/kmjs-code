import { ActionContext, Module } from 'vuex';
import { computed } from '@/router/permission';
import { RouteRecordRaw } from 'vue-router';
import { getMenu, getUserMsg, loginByMsg, loginByPwd, logout } from '@/utils/commApi';
import md5 from 'js-md5';
/* 用户信息 */
const user: Module<UserInfo, RootState> = {
  namespaced: true,
  state: {
    // 显示设置密码弹窗， 只在用户没有设置密码时弹出
    showSetPwd: false,
    insts: [],
    // 用户菜单权限
    menus: [],
    // 用户名
    userName: '',
    userMsg: null,
    // 权限
    permissions: ['aaaaaaaas', 'ssss', 'dddd']
  },
  mutations: {
    SET_PWD_MODEL(state: UserInfo, value: boolean) {
      state.showSetPwd = value;
    },
    UPDATE_MENU(state: UserInfo, data: RouteRecordRaw[]) {
      state.menus = [...data];
    },
    SETUSER(state: UserInfo, options: UserMsg) {
      state.userName = options.name;
      state.userMsg = { ...options };
    },
    SETINSTS(state, data: InstItem[]) {
      state.insts = [...data];
    },
    LOGOUT(state: UserInfo) {
      state.userName = '';
      state.userMsg = null;
    }
  },
  getters: {
    // 获取全部菜单
    menus: (state: UserInfo) => {
      return state.menus;
    },
    // 用户信息
    userMsg(state: UserInfo): UserMsg {
      return <UserMsg>state.userMsg || {};
    },
    // 权限
    permissions(state: UserInfo): string[] {
      return state.permissions;
    }
  },
  actions: {
    async getUserMenu({
      commit,
      rootGetters
    }: ActionContext<UserInfo, RootState>): Promise<boolean> {
      const res = await getMenu(rootGetters['systemInfo/asideMenu']);
      if (res) {
        const computedMenu = computed(res);
        commit('UPDATE_MENU', computedMenu);
        return true;
      }
      return false;
    },
    async login(
      { dispatch }: ActionContext<UserInfo, RootState>,
      data: { username: string; pwd: string; messageCode: string }
    ): Promise<boolean> {
      let res;
      if (data.messageCode) {
        res = await loginByMsg(data.username, data.messageCode);
      } else {
        res = await loginByPwd(data.username, md5(data.pwd));
      }
      if (res) {
        return await dispatch('getUserMessage');
      }
      return false;
    },
    async getUserMessage({ commit }: ActionContext<UserInfo, RootState>): Promise<boolean> {
      const res = await getUserMsg();
      if (res) {
        if (!res.password) {
          commit('SET_PWD_MODEL', true);
        }
        commit('SETUSER', res);
        return true;
      }
      return false;
    },
    async logOut({ commit, dispatch }: ActionContext<UserInfo, RootState>) {
      logout();
      dispatch('organization/clearAll', {}, { root: true });
      commit('menu/CLEAR_TABS', {}, { root: true });
      commit('LOGOUT');
      return true;
    }
  }
};
export default user;
