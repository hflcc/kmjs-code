import { Module } from 'vuex';

const listToDetailModule: Module<ListToDetailStore, RootState> = {
  namespaced: true,
  state: {
    data: {}
  },
  mutations: {
    setListData: (state, data: { name: string; data: any }) => {
      state.data[data.name] = data.data;
    }
  },
  getters: {
    listData: (state) => (name: string) => {
      return state.data[name];
    }
  }
};

export default listToDetailModule;
