import { ActionContext, Module } from 'vuex';
import { dictionary, getBusinessDataByForm } from '@/utils/commApi';

/**
 * 由于存在同时存在多个重复请求，因此将重复请求存储起来，后续都读取该请求即可
 * */
const ajaxObj: Record<string, Promise<DictionariesItem[]>> = {};
const busAjaxObj: Record<string, Promise<Record<string, any>[]>> = {};
/* 字典 */
const dictionariesModule: Module<DictionariesStore, RootState> = {
  namespaced: true,
  state: {
    dictionaries: {},
    businessData: {}
  },
  mutations: {
    SETDICTIONARIES(state, data: [string, DictionariesItem[]][]) {
      data.forEach((v) => {
        state.dictionaries[v[0]] = [...v[1]];
      });
    },
    SETBUSDICTIONARIES(state, data: { key: string; res: Record<string, any>[] }) {
      state.businessData[data.key] = data.res;
    }
  },
  getters: {
    getDataToJson: (state) => (name: string) => {
      const data: { [l: string]: string } = {};
      state.dictionaries[name]?.forEach((v: { code: string; name: string }) => {
        data[v.code] = v.name;
      });
      return data;
    }
  },
  actions: {
    async getBusiness(
      { state, commit }: ActionContext<DictionariesStore, RootState>,
      req: {
        serverSn: string;
        query: Record<string, any>;
      }
    ): Promise<Record<string, any>[]> {
      const key = JSON.stringify(req);
      if (state.businessData[key]) {
        return state.businessData[key];
      } else {
        let ajaxFun = null;
        if (busAjaxObj[key]) {
          ajaxFun = busAjaxObj[key];
        } else {
          ajaxFun = getBusinessDataByForm(req.serverSn, req.query);
          busAjaxObj[key] = ajaxFun;
        }
        const res: Record<string, any>[] = await ajaxFun;
        if (!res) return [];
        commit('SETBUSDICTIONARIES', { key, res });
        return res;
      }
    },
    async getData(
      { state, commit }: ActionContext<DictionariesStore, RootState>,
      defSns: []
    ): Promise<{ [l: string]: DictionariesItem[] } | null> {
      if (!defSns) return null;
      const data: { [l: string]: any[] } = {};
      const dirSns: string[] = [];
      defSns.forEach((v) => {
        const dirs = state.dictionaries[v];
        if (dirs) {
          data[v] = [...dirs];
        } else {
          !dirSns.includes(v) && dirSns.push(v);
        }
      });
      if (dirSns.length > 0) {
        const key = dirSns.join('');
        let ajaxFun = null;
        if (ajaxObj[key]) {
          ajaxFun = ajaxObj[key];
        } else {
          ajaxFun = dictionary(dirSns);
          ajaxObj[key] = ajaxFun;
        }
        const res: DictionariesItem[] = await ajaxFun;
        if (res) {
          const dirTypes: { [l: string]: DictionariesItem[] } = {};
          res.forEach((v) => {
            if (!dirTypes[v.type]) {
              dirTypes[v.type] = [] as DictionariesItem[];
            }
            if (!data[v.type]) {
              data[v.type] = [] as DictionariesItem[];
            }
            dirTypes[v.type].push(v);
            data[v.type].push(v);
          });
          commit('SETDICTIONARIES', Object.entries(dirTypes));
        }
      }
      return data;
    }
  }
};

export default dictionariesModule;
