import { ActionContext, Module } from 'vuex';
import { getFileUrlBySeq } from '@/utils/commApi';
import tim from '@/utils/tim';
import TIM from 'tim-js-sdk';
import {
  changeMkCscState,
  clearMkMessage,
  cscLogin,
  getImInfo,
  getImLoginInfo,
  getImMemberList,
  getImMessage,
  getMkCscDefList,
  getMkCscInstanceDialogServicelist,
  getMkCscServiceList,
  getMkDialogMember,
  getMkDialogMessage,
  getMkGroupInfoForGroupSn,
  getMkPlanList,
  getMkRemarkList
} from '@/utils/im/api';
import { formatterServiceChattingMessage, formatterTIMChattingMessage } from '@/utils/im/formatter';
import { showNotification } from '@/utils/im/utils';
import { clearImUnreadCount } from '@/pages/backlog/api';
import store from '@/store';

const imStore: Module<ImInfo, RootState> = {
  namespaced: true,
  state: {
    // sdk是否链接完毕
    imSdkIsReady: false,
    imInfoIsReady: false,
    isImOnline: false,
    // 当前选中的客服中心
    currentServiceSn: '',
    // 当前选中的群组
    currentGroupSn: '',
    isNotification: false,
    // 当前群组状态
    currentGroupState: '',
    // 客服中心数据对象; { [客服中心sn: string]: ImServiceInfo }
    serviceDataMap: {},
    // 群组列表;{ [客服中心sn: string]: Array<ImGroupInfo> }
    groupList: {},
    // { [群组sn: string]: boolean }
    groupFinishedState: {},
    // 聊天记录;{ [群组sn: string]: Array<ImChattingRecord> }
    chattingRecordMap: {},
    // 群组成员;{[群组sn: string]: {[accountSn: string]: ImUserInfo}}
    groupMemberMap: {},
    // 用户IM系统的状态
    userInfo: {
      sn: '',
      // im 系统的token
      accountSn: '',
      // im 系统的昵称
      nickname: '',
      // im是否在线
      online: '',

      state: '',
      // im 头像的seq
      avatar: '',
      // 用户签名
      accountSign: '',
      exist: false,
      type: 'attendor',
      // 重连次数
      reconnectionTimes: 0
    },
    // 腾讯的sn映射对话框sn
    groupMappingDialog: {},
    // IM的群组列表
    imGroupMap: {}
  },
  getters: {
    // 服务中心的列表
    getServiceList: (state) => {
      return Object.keys(state.serviceDataMap).map((key) => {
        return state.serviceDataMap[key];
      });
    },
    // 服务中心的客服列表
    getServiceCsList: (state) => {
      const map = state.serviceDataMap[state.currentServiceSn].serviceMap;
      return Object.keys(map).map((key) => {
        return map[key];
      });
    },
    // 群组列表
    getGroupList: (state) => {
      return state.groupList[state.currentServiceSn] || [];
    },
    // 群成员列表
    getMemberList: (state) => {
      return state.groupMemberMap[state.currentGroupSn] || {};
    },
    // 当前选中的服务中心信息
    getCurrentServiceInfo: (state) => {
      return state.serviceDataMap[state.currentServiceSn];
    },
    // 当前选中的群组信息
    getCurrentGroupInfo: (state) => {
      const groupInfoList = state.groupList[state.currentServiceSn] || [];
      return (
        groupInfoList.find((item: ImGroupInfo) => item.sn === state.currentGroupSn) || {
          avatar: '',
          banSpeak: 0,
          groupState: 'process',
          sn: '',
          name: '',
          serviceSn: '',
          groupSn: '',
          messageAt: 0,
          messageState: 'custom',
          msgCount: 0,
          remarkMessage: [],
          contactPlan: [],
          top: false,
          isExtend: false
        }
      );
    },
    // 聊天记录
    getChattingRecord: (state) => {
      return state.chattingRecordMap[state.currentGroupSn] || [];
    }
  },
  mutations: {
    UPDATE_IM_STATE(state: ImInfo, payload: boolean) {
      state.isImOnline = payload;
    },
    // 清理IM数据
    CLEAR_ALL(state: ImInfo) {
      state.imInfoIsReady = false;
      state.currentGroupSn = '';
      state.currentServiceSn = '';
      state.serviceDataMap = {};
      state.groupList = {};
      state.chattingRecordMap = {};
      state.groupFinishedState = {};
      state.chattingRecordMap = {};
      state.groupMemberMap = {};
    },
    // 设置选中的客服中心
    SET_CURRENT_SERVICE_SN(state: ImInfo, payload: string) {
      state.currentServiceSn = payload;
      state.currentGroupSn = '';
    },
    // 设置选中的群组
    SET_CURRENT_GROUP_SN(state: ImInfo, payload: string) {
      state.currentGroupSn = payload;
    },
    // 设置查看的群组状态
    SET_CURRENT_GROUP_STATE(state: ImInfo, payload: string) {
      state.currentGroupState = payload;
    },
    // 设置IM信息
    SET_IM_INFO(state: ImInfo, payload: ImUserInfo) {
      state.userInfo = Object.assign(state.userInfo, payload);
      state.userInfo.reconnectionTimes = 0;
      state.imInfoIsReady = true;
    },
    // 设置IM信息
    UPDATE_IM_INFO(state: ImInfo, payload: ImUserInfo) {
      state.userInfo.accountSn = payload.accountSn;
      state.userInfo.accountSign = payload.accountSign;
      state.userInfo.reconnectionTimes = 0;
      state.imInfoIsReady = true;
    },
    // sdk是否已经准备好了
    SET_SDK_STATE(state: ImInfo, payload: boolean) {
      state.imSdkIsReady = payload;
    },
    // 设置客服中心数据
    SET_SERVICE_DATA_MAP(state: ImInfo, payload: ImServiceDataMap) {
      state.serviceDataMap = payload;
      // 如果当前已经有选中的客服中心,且客服中心不在了
      if (state.currentServiceSn && !payload[state.currentServiceSn]) {
        state.currentServiceSn = '';
        state.currentGroupSn = '';
      }
    },
    // 设置客服中心客服数据
    SET_SERVICE_DATA_MAP_CUSTOMER(state: ImInfo, payload: { sn: string; list: ImCscService[] }) {
      const memberObj: { [attendorSn: string]: ImCscService } = {};
      payload.list.forEach((item) => {
        memberObj[item.attendorSn] = item;
      });
      state.serviceDataMap[payload.sn].serviceMap = memberObj;
    },
    // 设置群组列表数据
    SET_GROUP_LIST_FOR_SN(
      state: ImInfo,
      payload: { serviceSn: string; list: Array<ImGroupInfo>; state: string }
    ) {
      payload.list.forEach((item) => {
        state.groupMappingDialog[item.groupSn] = item.sn;
      });

      if (payload.state === 'finished') {
        state.groupList[payload.serviceSn] = state.groupList[payload.serviceSn].concat(
          payload.list
        );
        state.groupFinishedState[payload.serviceSn] = true;
      } else {
        let groupList = payload.list;
        // 如果有旧的已结束数据，同步回去
        if (state.groupFinishedState[payload.serviceSn] && state.groupList[payload.serviceSn]) {
          groupList = state.groupList[payload.serviceSn]
            .filter((item) => item.groupState === 'finished')
            .concat(groupList);
        }
        state.groupList[payload.serviceSn] = groupList;
      }
      const list = state.groupList[payload.serviceSn].filter(
        (item) => item.groupState === 'process' && item.msgCount > 0
      );
      if (state.serviceDataMap[payload.serviceSn]) {
        state.serviceDataMap[payload.serviceSn].count =
          list.length > 0
            ? list.map((item) => item.msgCount).reduce((total, num) => total + num)
            : 0;
      }
    },
    // 设置群组信息
    UPDATE_GROUP_INFO(state: ImInfo, payload: ImGroupInfo) {
      const groupInfoList = state.groupList[state.currentServiceSn] || [];

      const idx = groupInfoList.findIndex((item: ImGroupInfo) => item.sn === payload.sn);
      groupInfoList[idx] = payload;
      state.groupList[state.currentServiceSn] = groupInfoList;
    },
    // 设置群组成员的map列表
    SET_GROUP_MEMBER(state: ImInfo, payload: { groupSn: string; list: Array<ImUserInfo> }) {
      const memberObj: { [accountSn: string]: ImUserInfo } = {};
      payload.list.forEach((item) => {
        memberObj[item.accountSn] = item;
      });
      state.groupMemberMap[payload.groupSn] = memberObj;
    },
    // 清空指定群的聊天记录
    CLEAR_GROUP_CHATTING_RECORD(state: ImInfo, payload: string) {
      state.chattingRecordMap[payload] = [];
    },
    // 设置聊天记录
    SET_GROUP_CHATTING_RECORD(state: ImInfo, payload: GroupSnAndDataList<ImChattingRecord>) {
      const oldData = state.chattingRecordMap[payload.sn];
      const from = payload.from;
      const lists = payload.lists.reverse();
      // 这是来自腾讯的推送记录
      if (from === 'TIM') {
        let groupInfoList: ImGroupInfo[] = [];
        let groupInfo: ImGroupInfo | undefined;

        // 查找所有的客服中心下的群组，找到是哪个群组的
        Object.keys(state.serviceDataMap).forEach((key) => {
          if (!groupInfo) {
            groupInfoList = state.groupList[key] || [];
            // 处理对应群组最新消息
            groupInfo = groupInfoList.find((item: ImGroupInfo) => item.sn === payload.sn);
          }
        });

        if (groupInfo) {
          const lastMsg = lists[lists.length - 1];
          // 如果是自定义消息
          if (lastMsg.messageType === TIM.TYPES.MSG_CUSTOM) {
            const body = lastMsg.messageBody as ImFormatRecordCustom;
            // 如果是切换消息,对应状态切换为服务中
            if (body.desc === 'SWITCH' && body.data === state.userInfo.accountSn) {
              groupInfo.groupState = 'process';
              // 需要重新加载聊天记录
            }
            // 切换 结束，已读消息直接舍弃消息
            if (body.desc === 'SWITCH' || body.desc === 'FINISH' || body.desc === 'READ') {
              return;
            }
          }
          // 如果是已结束的消息，则直接不加入。不处理
          // if (groupInfo.groupState === 'finished') {
          //   return;
          // }

          groupInfo.message = {
            messageBody: {
              // 消息内容
              Text: (lastMsg.messageBody as ImFormatRecordText)?.text,
              Desc: (lastMsg.messageBody as ImFormatRecordCustom)?.desc
            },
            messageType: lastMsg.messageType
          };

          groupInfo.messageAt = lastMsg.time;
          groupInfo.messageState = lastMsg.flow === 'in' ? 'custom' : 'attendor';
          // 已结束的会重新变为服务中
          // groupInfo.groupState = 'process';

          // 如果是服务中
          if (groupInfo.groupState === 'process') {
            // 服务中
            if (state.isNotification && lastMsg.flow === 'in' && !groupInfo.bpmSn) {
              try {
                showNotification('消息通知', groupInfo.message as ImSendMessage);
              } catch (e) {
                console.error(e);
              }
            }
            // 如果不是当前群组，给消息数加数量
            if (payload.sn !== state.currentGroupSn) {
              groupInfo.msgCount += lists.length;
              // 给客服中心消息数增加
              state.serviceDataMap[groupInfo.serviceSn].count += lists.length;
            }
          }

          // 消息加入聊天记录中
          if (oldData && oldData.length > 0) {
            state.chattingRecordMap[payload.sn].push(...lists);
          } else {
            lists[0].isFirst = true;
            state.chattingRecordMap[payload.sn] = lists;
          }

          // 需要给群组重新排个序
          groupInfoList.sort((a: ImGroupInfo, b: ImGroupInfo) => {
            // 两个都是置顶 亦或者两个都不是置顶，比较时间
            if ((a.top && b.top) || (!a.top && !b.top)) {
              return b.messageAt - a.messageAt;
            } else if (a.top) {
              return -1;
            } else if (b.top) {
              return 1;
            }
            return 0;
          });
        }
      } else if (from === 'SERVICE') {
        // 后台请求接口的记录
        if (oldData && oldData.length > 0) {
          state.chattingRecordMap[payload.sn].push(...lists);
        } else {
          lists[0].isFirst = true;
          state.chattingRecordMap[payload.sn] = lists;
        }
      }
    },
    // 修改通知状态
    UPDATE_NOTIFICATION(state: ImInfo, payload: boolean) {
      state.isNotification = payload;
    },
    // 设置群组列表
    SET_IM_GROUP_LIST_FOR_SN(state: ImInfo, payload: ImGroupInfo) {
      state.imGroupMap[payload.sn] = payload;
      state.groupMappingDialog[payload.groupSn] = payload.sn;
    },
    // 更新群组消息数
    SET_IM_GROUP_INFO(state: ImInfo, payload: ImGroupInfo) {
      state.imGroupMap[payload.sn] = payload;
    },
    // 是否IM的显示在前台。主要用于是否需要消息数增加和设置已读
    UPDATE_IM_SHOW(state: ImInfo, payload: { sn: string; isShow: boolean }) {
      const groupInfo = state.imGroupMap[payload.sn];
      groupInfo.isShow = payload.isShow;
    },
    // 更新IM中的聊天记录
    UPDATE_IM_CHATTING_RECORD(state: ImInfo, payload: GroupSnAndDataList<ImChattingRecord>) {
      const oldData = state.chattingRecordMap[payload.sn];
      const lists = payload.lists.reverse();
      // 消息加入聊天记录中
      if (oldData && oldData.length > 0) {
        state.chattingRecordMap[payload.sn].push(...lists);
      } else {
        lists[0].isFirst = true;
        state.chattingRecordMap[payload.sn] = lists;
      }
      const groupInfo = state.imGroupMap[payload.sn];
      if (groupInfo?.isShow === false) {
        groupInfo.msgCount += 1;
      }
    }
  },
  actions: {
    /*
     * 1.初始化SDK;
     * 2.获取当前登录用户的IM信息
     * */
    initSdk({ commit }: ActionContext<ImInfo, RootState>): Promise<undefined> {
      return new Promise((resolve) => {
        commit('CLEAR_ALL');
        cscLogin().then();
        Promise.all([getImInfo()]).then(async ([data]) => {
          if (!data) {
            return;
          }
          // 头像数据
          const { avatar, accountSign } = data;
          if (!data.exist) {
            return;
          }
          if (avatar) {
            const faceUrlResponse = await getFileUrlBySeq(avatar);
            if (faceUrlResponse) {
              data.avatar = faceUrlResponse[avatar]?.url?.replace(/Expires=[^&]*&?/g, '');
            }
          }
          // im签名数据
          if (accountSign) {
            // 登录im
            await tim.login({ userID: data.accountSn || '', userSig: data.accountSign || '' });
            commit('UPDATE_IM_STATE', true);
          }
          commit('SET_IM_INFO', data);
          // dispatch('changeImUserState', 'ON').then();
          resolve(void 0);
        });
      });
    },
    // 初始化IM
    initIm({ commit, dispatch, state }): Promise<boolean> {
      if (!state.userInfo.sn) {
        cscLogin().then();
        getImInfo().then(async (data) => {
          if (!data || !data.exist) {
            return;
          }
          if (data.avatar) {
            const faceUrlResponse = await getFileUrlBySeq(data.avatar);
            if (faceUrlResponse) {
              data.avatar = faceUrlResponse[data.avatar]?.url?.replace(/Expires=[^&]*&?/g, '');
            }
          }
          commit('SET_IM_INFO', data);
        });
      }
      return new Promise((resolve) => {
        // 客服中心分组
        getMkCscDefList().then((res) => {
          if (Array.isArray(res)) {
            const result: ImServiceDataMap = {};
            res.forEach((item) => {
              result[item.sn] = {
                sn: item.sn,
                name: item.name,
                count: item.count,
                serviceMap: {}
              };
              if (!state.groupList[item.sn] || item.sn === state.currentServiceSn) {
                dispatch('initGroupList', { sn: item.sn, state: 'process' });
              }
            });

            commit('SET_SERVICE_DATA_MAP', result);
            return resolve(true);
          }
          // commit('UPDATE_NEED_READ', true);
          return resolve(false);
        });
      });
    },
    // 初始化群组列表
    initGroupList({ commit }, data: { sn: string; state: 'process' | 'finished' }) {
      getMkCscInstanceDialogServicelist(data.sn, data.state).then((response) => {
        if (!response) {
          return;
        }
        const result: Array<ImGroupInfo> = [];
        const avatarList = response.map((item) => {
          result.push({
            avatar: item.avatar,
            banSpeak: item.banSpeak,
            groupState: item.state,
            sn: item.dialogSn,
            name: item.groupName,
            serviceSn: data.sn,
            message: item.message,
            messageAt: item.messageAt,
            messageState: item.messageBy,
            msgCount: item.msgCount,
            remarkMessage: [],
            contactPlan: [],
            groupSn: item.groupSn,
            top: item.top || false,
            isExtend: false,
            from: item.from
          });
          return item.avatar;
        });
        getFileUrlBySeq(avatarList.join(',')).then((res) => {
          result.forEach((item) => {
            item.avatar = res[item.avatar].url.replace(/Expires=[^&]*&?/g, '');
          });
          commit('SET_GROUP_LIST_FOR_SN', { serviceSn: data.sn, list: result, state: data.state });
          // if (state.currentGroupSn) {
          //   dispatch('changeIMGroup', state.currentGroupSn);
          // }
        });
      });
    },
    // 切换客服中心
    changeCurrentServiceSn({ commit, dispatch }, sn: string) {
      return new Promise(() => {
        commit('SET_CURRENT_SERVICE_SN', sn);
        getMkCscServiceList(sn).then((res) => {
          commit('SET_SERVICE_DATA_MAP_CUSTOMER', { sn: sn, list: res.content });
        });
        dispatch('initGroupList', { sn: sn, state: 'process' });
      });
    },
    // 消息撤回
    onMessageRevoked(
      { state }: ActionContext<ImInfo, RootState>,
      lists: Array<TIMReceptionMessageType>
    ) {
      // 群组回话
      const filterGroup = lists.filter((item) => {
        return item.conversationType === TIM.TYPES.CONV_GROUP;
      });
      if (filterGroup.length > 0) {
        const msg = filterGroup[0];
        const groupMappingDialog = state.groupMappingDialog;
        const currentGroupSn = groupMappingDialog[msg.to] as string;
        const chatting = state.chattingRecordMap[currentGroupSn];
        const findIdx = chatting.findIndex((item) => item.messageKey === msg.sequence + '');
        if (findIdx >= 0) {
          chatting[findIdx].isRevoked = true;
          // 如果是最新的一条消息
          if (findIdx === chatting.length - 1) {
            getMkGroupInfoForGroupSn(filterGroup[0].to).then((res) => {
              if (!res.csdDefSn) {
                return;
              }
              const groupInfoList = state.groupList[res.csdDefSn];
              const groupInfo = groupInfoList.find((item) => item.sn === currentGroupSn);
              if (groupInfo) {
                groupInfo.message = {
                  messageBody: {
                    // 消息内容
                    Text: state.groupMemberMap[groupInfo.sn][msg.from].nickname + '撤回了一条消息'
                  },
                  messageType: 'TIMTextElem'
                };
              }
            });
          }
        }
      }
    },
    // 重新登录
    async reConnect({ state, commit }: ActionContext<ImInfo, RootState>) {
      const data = state.userInfo;
      //   // 尝试重新登录，看看有没有登录失效
      await getImInfo().then();
      // 登录im
      tim.login({ userID: data.accountSn || '', userSig: data.accountSign || '' }).then(() => {
        commit('SET_IM_INFO', data);
        commit('UPDATE_IM_STATE', true);
      });
    },
    // 腾讯推送
    async getTIMChattingRecord(
      { commit, dispatch, state, getters }: ActionContext<ImInfo, RootState>,
      lists: Array<TIMReceptionMessageType>
    ) {
      // 群组回话
      const filterGroup = lists.filter((item) => {
        // 群提示消息--直接忽略
        return (
          item.conversationType === TIM.TYPES.CONV_GROUP && item.type !== TIM.TYPES.MSG_GRP_TIP
        );
      });
      if (filterGroup.length > 0) {
        console.info('收到消息：', JSON.stringify(lists[0].payload));
        const groupMappingDialog = state.groupMappingDialog;
        const currentGroupSn = groupMappingDialog[filterGroup[0].to] as string;
        if (filterGroup[0].to === currentGroupSn) {
          await dispatch('handlerImChatting', filterGroup);
          return;
        }

        const groupInfoList = getters.getGroupList;
        const groupInfo: ImGroupInfo = groupInfoList.find(
          (item: ImGroupInfo) => item.sn === currentGroupSn
        );
        // 切换过来的客服 已读消息的设置
        if (filterGroup[0].type === TIM.TYPES.MSG_CUSTOM) {
          const body = filterGroup[0].payload as TIMReceptionPayloadCustom;
          // 群组转接，新接入
          if (body.description === 'SWITCH') {
            if (body.data === state.userInfo.accountSn) {
              if (groupInfo) {
                // 需要更新数据
                groupInfo.isExtend = false;
                groupInfo.groupState = 'process';
                if (state.currentGroupSn === currentGroupSn) {
                  await dispatch('changeIMGroup', state.currentGroupSn);
                } else {
                  const r = await getMkGroupInfoForGroupSn(filterGroup[0].to);
                  if (r.csdDefSn) {
                    await dispatch('initGroupList', { sn: r.csdDefSn, state: 'process' });
                    return;
                  }
                }
              } else {
                await dispatch('updateGroupList', filterGroup[0]);
              }
            }
            return;
          }

          if (body.description === 'READ') {
            const d = JSON.parse(body.data) as { type: string; dialogSn: string };
            // 客户发的，给消息置为已读
            if (d.type === 'custom') {
              state.chattingRecordMap[d.dialogSn]?.forEach((item) => {
                item.isPeerRead = true;
              });
            }
            return;
          }

          if (body.description === 'FINISH') {
            if (groupInfo.groupState === 'finished') {
              return;
            }
            if (state.currentGroupSn === currentGroupSn) {
              state.currentGroupSn = '';
            }
            // 接收到结束消息.加载过已结束，则把状态直接改
            if (state.groupFinishedState[groupInfo.serviceSn]) {
              groupInfo.groupState = 'finished';
              // 消息数 需要减去
              state.serviceDataMap[groupInfo.serviceSn].count -= groupInfo.msgCount;
            } else {
              // 没有加载过已结束，则删除这一条
              state.groupList[groupInfo.serviceSn].splice(
                state.groupList[groupInfo.serviceSn].indexOf(groupInfo),
                1
              );
            }
            return;
          }
        }
        // const currentGroupSn = state.groupMappingDialog[filterGroup[0].to] as string;
        // 收到对面的消息,且当前打开的消息框，直接把消息设置为已读
        if (filterGroup[0].flow === 'in' && state.currentGroupSn === currentGroupSn) {
          if (state.currentGroupSn && groupInfo.groupState === 'process') {
            // console.log('aaaa');
            clearMkMessage(state.currentGroupSn).then();
          }
        }

        formatterTIMChattingMessage(filterGroup).then((lists) => {
          for (const listsKey in lists) {
            commit('SET_GROUP_CHATTING_RECORD', lists[listsKey]);
          }
        });
      }
      // 系统会话
      const filterSys = lists.filter((item) => {
        return (
          // 新群系统通知
          (item.conversationType === TIM.TYPES.CONV_SYSTEM &&
            item.type === TIM.TYPES.MSG_GRP_SYS_NOTICE) ||
          // 有成员进群
          (item.conversationType === TIM.TYPES.CONV_GROUP &&
            item.type !== TIM.TYPES.MSG_GRP_TIP &&
            (item.payload as TIMReceptionPayloadGroupTip).operationType ===
              TIM.TYPES.GRP_TIP_MBR_JOIN)
        );
      });
      if (filterSys.length > 0) {
        console.info('收到消息：', JSON.stringify(filterSys[0]));
        // await dispatch('updateGroupList', filterSys[0]);
        setTimeout(() => {
          getMkGroupInfoForGroupSn(filterSys[0].to).then((r) => {
            if (r.csdDefSn) {
              dispatch('initGroupList', { sn: r.csdDefSn, state: 'process' });
            }
          });
        }, 3000);
      }
    },
    updateGroupList({ dispatch }: ActionContext<ImInfo, RootState>, data: TIMReceptionMessageType) {
      // 第一次先3秒后执行，如果获取不到，5S执行一次，执行十次
      setTimeout(async () => {
        const r = await getMkGroupInfoForGroupSn(data.to);
        if (r.csdDefSn) {
          await dispatch('initGroupList', { sn: r.csdDefSn, state: 'process' });
          return;
        }

        // 这里延迟一下，可能后台还没有加进去，会找不到
        let i = 0;
        const interval = setInterval(() => {
          getMkGroupInfoForGroupSn(data.to).then((res) => {
            if (res.csdDefSn) {
              clearInterval(interval);
              dispatch('initGroupList', { sn: res.csdDefSn, state: 'process' });
              return;
            }
            i++;
            if (i > 3) {
              clearInterval(interval);
            }
          });
        }, 5000);
      }, 3000);
    },
    // 获取服务器中的聊天记录
    async getServiceRecord(
      { commit, state }: ActionContext<ImInfo, RootState>,
      data: { groupSn?: string; lastSn?: string; isIm?: boolean }
    ) {
      // 获取聊天记录列表
      const messageRes = data.isIm
        ? await getImMessage(data.groupSn || state.currentGroupSn, data.lastSn || '')
        : await getMkDialogMessage(data.groupSn || state.currentGroupSn, data.lastSn || '');
      const messageData = await formatterServiceChattingMessage(
        data.groupSn || state.currentGroupSn,
        messageRes.content
      );
      if (messageData.lists.length === 0) {
        return;
      }
      if (messageRes.last && messageData.lists.length > 0) {
        const list = messageData.lists.filter((item: ImChattingRecord) => {
          if (item.messageType !== TIM.TYPES.MSG_CUSTOM) {
            return true;
          }
          // eslint-disable-next-line no-undef
          const body = item.messageBody as ImFormatRecordCustom;
          return body.desc === 'ORDER' || body.desc === 'SHOP';
        });
        list[list.length - 1].isFirst = true;
      }
      commit('SET_GROUP_CHATTING_RECORD', messageData);
    },
    // 删除一条消息记录
    deleteRecord({ state, getters }: ActionContext<ImInfo, RootState>, msgKey: string) {
      const list = state.chattingRecordMap[state.currentGroupSn];
      const idx = list.findIndex((item) => item.messageKey === msgKey);
      if (idx >= 0) {
        // 是最后一条消息
        if (idx === list.length - 1) {
          // 清空消息那的
          getters.getCurrentGroupInfo.message = {
            messageBody: {
              // 消息内容
              Text: ''
            },
            messageType: TIM.TYPES.MSG_TEXT
          };
        }
        list.splice(idx, 1);
      }
    },
    // 切换客服的状态
    changeImUserState({ commit, state }: ActionContext<ImInfo, RootState>, status: string) {
      const d = state.userInfo;
      return new Promise((resolve) => {
        changeMkCscState(d.sn, status).then((res) => {
          if (res.success) {
            d.state = status;
            commit('SET_IM_INFO', d);
          }
          return resolve(res.success);
        });
      });
    },
    // 切换选中的群组
    async changeIMGroup({ commit, state, getters, dispatch }, currentGroupSn: string) {
      // if (state.currentGroupSn === currentGroupSn) {
      //   return;
      // }
      const groupInfoList = getters.getGroupList;
      const groupInfo: ImGroupInfo = groupInfoList.find(
        (item: ImGroupInfo) => item.sn === currentGroupSn
      );

      if (groupInfo.groupState === 'process') {
        // if (groupInfo.msgCount > 0) {
        // 客服中心已读数减掉
        state.serviceDataMap[groupInfo.serviceSn].count -= groupInfo.msgCount;
        // 消息全都已读
        groupInfo.msgCount = 0;
        // console.log('bbbbb');
        // 设置消息为已读
        if (currentGroupSn) {
          clearMkMessage(currentGroupSn).then();
        }
        // }
      }

      // 获取群成员
      if (!state.groupMemberMap[currentGroupSn] || !groupInfo.isExtend) {
        await dispatch('getMemberList', { groupSn: currentGroupSn });

        // 如果已经有聊天记录，先清除掉
        if (state.chattingRecordMap[currentGroupSn]) {
          commit('CLEAR_GROUP_CHATTING_RECORD', currentGroupSn);
        }

        await dispatch('getServiceRecord', { groupSn: currentGroupSn });
      }

      // 设置当前群组
      commit('SET_CURRENT_GROUP_SN', currentGroupSn);

      // 获取右侧面板信息，缓存是否请求过
      if (!groupInfo.isExtend) {
        // 获取备注信息
        const remarkRes = await getMkRemarkList(currentGroupSn);
        groupInfo.remarkMessage = remarkRes?.content || [];

        // 获取联系计划
        const planRes = await getMkPlanList({ dialogSn: currentGroupSn, page: 0, size: 50 });
        groupInfo.contactPlan = planRes.content || [];

        // 获取访问信息
        groupInfo.isExtend = true;
      }
    },
    initImSdk({ commit }) {
      return new Promise((resolve) => {
        getImLoginInfo().then((res) => {
          // im签名数据
          if (res.accountSign) {
            // 登录im
            tim.login({ userID: res.accountSn || '', userSig: res.accountSign || '' }).then(() => {
              commit('UPDATE_IM_INFO', res);
              commit('UPDATE_IM_STATE', true);
              resolve(0);
            });
          }
        });
      });
    },
    // 初始化单个聊天的
    async initTalking({ state, commit }, data: { bpmSn: string; groupSn: string }) {
      const groupSn = data.groupSn;
      if (state.imGroupMap[groupSn]) {
        return;
      }
      commit('SET_IM_GROUP_LIST_FOR_SN', {
        sn: groupSn,
        groupState: 'process',
        serviceSn: groupSn,
        // 腾讯那边的id
        groupSn: groupSn,
        msgCount: 0,
        bpmSn: data.bpmSn,
        isShow: false
      });
    },
    // 初始化IM的信息
    async initImInfo({ state, commit, dispatch }, groupSn: string) {
      // 消息数修改为0
      const groupInfo = state.imGroupMap[groupSn];
      groupInfo.msgCount = 0;
      commit('SET_IM_GROUP_INFO', groupInfo);

      if (state.groupMemberMap[groupSn]) {
        // await dispatch('getMemberList', { groupSn: groupSn, isIm: true });
        return;
      }

      await dispatch('getMemberList', { groupSn: groupSn, isIm: true });
      // 如果已经有聊天记录，先清除掉
      if (state.chattingRecordMap[groupSn]) {
        commit('CLEAR_GROUP_CHATTING_RECORD', groupSn);
      }
      // 获取聊天记录
      await dispatch('getServiceRecord', { groupSn: groupSn, isIm: true });
    },
    // 获取群成员列表
    async getMemberList({ commit, state }, data: { groupSn: string; isIm?: boolean }) {
      const memberList = data.isIm
        ? (await getImMemberList(data.groupSn))?.content ?? []
        : await getMkDialogMember(data.groupSn);
      const avatarList = memberList.map((item) => item.avatar);
      const imgs = await getFileUrlBySeq(avatarList.join(','));
      const accountSn = state.userInfo.accountSn;
      memberList.forEach((item) => {
        item.avatar = imgs[item.avatar]?.url?.replace(/Expires=[^&]*&?/g, '') ?? '';
        item.type = item.accountSn === accountSn ? 'attendor' : 'custom';
      });
      commit('SET_GROUP_MEMBER', { groupSn: data.groupSn, list: memberList });
    },
    // 处理IM的聊天记录
    async handlerImChatting({ commit, state, dispatch }, data: TIMReceptionMessageType[]) {
      if (data.length === 0) {
        return;
      }
      // 自定义消息
      if (data[0].type === TIM.TYPES.MSG_CUSTOM) {
        const body = data[0].payload as TIMReceptionPayloadCustom;
        if (
          body.description === 'SWITCH' ||
          body.description === 'READ' ||
          body.description === 'FINISH'
        ) {
          return;
        }
      }
      const groupSn = data[0].to;
      const groupInfo = state.imGroupMap[groupSn];
      if (!groupInfo?.bpmSn) {
        return;
      }
      // 在前台显示中，则设置消息为已读
      if (groupInfo.isShow) {
        // 设置消息为已读
        clearImUnreadCount(groupInfo?.bpmSn).then();
      }

      if (data[0].flow === 'in') {
        // 可能会突然多个成员（被别人领了任务后）
        const member = state.groupMemberMap[groupSn];
        if (!member[data[0].from]) {
          // 在找不到人的情况下，重新刷新下成员列表
          await dispatch('getMemberList', { groupSn: groupSn, isIm: true });
        }
      }
      formatterTIMChattingMessage(data).then((lists) => {
        for (const listsKey in lists) {
          commit('UPDATE_IM_CHATTING_RECORD', lists[listsKey]);
        }
      });
    }
  }
};

export default imStore;
