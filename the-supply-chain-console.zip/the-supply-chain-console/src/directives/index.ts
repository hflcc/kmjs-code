import { App } from '@vue/runtime-core';

export default (app: App): void => {
  app.directive('formFocus', {
    mounted(el) {
      setTimeout(() => {
        el.focus();
      }, 0);
    }
  });
};
