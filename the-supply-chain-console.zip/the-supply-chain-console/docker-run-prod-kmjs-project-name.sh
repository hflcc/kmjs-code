#!/bin/bash
docker rm -f `docker ps -a | grep -w kmjs-the-supply-chain-console | awk '{print $1}'`;
docker rmi --force `docker images | grep -w 172.18.88.211:7080/library/kmjs-the-supply-chain-console:latest | awk '{print $3}'`;
docker pull 172.18.88.211:7080/library/kmjs-the-supply-chain-console:latest
docker run --name=kmjs-the-supply-chain-console -d -e "action=prod" -v /etc/hosts:/etc/hosts -p 16001:16001 172.18.88.211:7080/library/kmjs-the-supply-chain-console:latest
