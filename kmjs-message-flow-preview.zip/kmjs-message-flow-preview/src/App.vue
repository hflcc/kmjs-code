<script lang="ts">
import { defineComponent, nextTick, ref } from "vue";
import MessageFlow from "./components/MessageFlow";
export default defineComponent({
  components: {
    MessageFlow,
  },
  setup() {
    const change = ref(true);
    // 允许的域名 信息流编辑平台 开发/生产环境
    const allowOrigin = ['http://localhost:8081', 'https://info-flow-admin-dev.kmyun.cn', 'https://info-flow-admin.kmyun.cn']
    function receiveMessage(event: MessageEvent) {
      const origin = event.origin;
      if (allowOrigin.includes(origin) && event.data === 'onRefresh') {
        change.value = false;
        nextTick(() => {
          change.value = true;
        });
      }
    }
    window.addEventListener("message", receiveMessage, false);

    return {
      change,
    };
  },
});
</script>

<template>
  <router-view v-if="change"/>
</template>
