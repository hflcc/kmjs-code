import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    path: "/",
    name: "previewIndex",
    component: () => import('../components/MessageFlow/index')
  },
];

export default createRouter({
  history: createWebHistory(),
  routes
});
