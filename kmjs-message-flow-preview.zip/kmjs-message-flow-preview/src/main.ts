import { createApp } from "vue";
import App from "./App.vue";
import Vant from "vant";
import "vant/lib/index.css";
import './style/init.less'
import "./common/rem";
import router from './router/index';
// import VConsole from 'vconsole';
//
// const env = import.meta.env.MODE
// if (env === 'development') {
//   new VConsole()
// }

const app = createApp(App)

app.use(router).use(Vant)
app.mount("#app");
