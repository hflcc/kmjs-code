// 容器类型
type MessageFlowContainerName =
  | "category"
  | "grid_1_1"
  | "grid_1_2"
  | "grid_1_3"
  | "grid_1_4"
  | "grid_1_5"
  | "grid_1_n"
  | "grid_2_2"
  | "grid_2_3"
  | "grid_2_4"
  | "grid_2_5"
  | "grid_3_3"
  | "shape_l"
  | "shape_y"
  | "side_frame";

// 项目类型
type MessageFlowItemName =
  | "advert"
  | "banner"
  | "table"
  | "goods1"
  | "goods2"
  | "shop1"
  | "shop2"
  | "article1"
  | "activity1"
  | "activity2"
  | "ticket4"
  | "ticket5"
  | "society1"
  | "image_text1";

// 行为类型
type MessageFlowActionType =
  | "goods"
  | "shop"
  | "article"
  | "society"
  | "activity"
  | "ticket"
  | "link"
  | "info_flow"
  | "page_guide"
  | "applet"
  | "app";

// 行为的描述
interface MessageFlowAction {
  // 行为类型
  type: MessageFlowActionType;
  // 行为值
  value: string;
}

// 容器盒子描述
interface MessageFlowContainerBox {
  // 盒子文字
  name: string;
  // 盒子颜色
  color: string;
}

// 容器背景的描述
interface MessageFlowContainerBackground {
  // 背景图seq
  image: string;
  // 背景颜色
  color: string;
}

// 容器内边距的描述
interface MessageFlowContainerPadding {
  // 上边距
  top: number;
  // 右边距
  right: number;
  // 下边距
  bottom: number;
  // 左边距
  left: number;
}

// 容器外边距的描述
interface MessageFlowContainerMargin {
  // 上边距
  top: number;
  // 右边距
  right: number;
  // 下边距
  bottom: number;
  // 左边距
  left: number;
}

// 图片信息
interface MessageFlowCoverImages {
  ossId: string;
}

// container 容器
interface MessageFlowContainer {
  type: "container";
  // 容器sn
  sn: string;
  // 容器父级sn
  parentSn: string | null;
  // 容器类型
  name: MessageFlowContainerName;
  // 容器标题
  title?: MessageFlowContainerBox;
  // 容器描述
  descr?: MessageFlowContainerBox;
  // 底部容器标题
  bottomTitle?: MessageFlowContainerBox;
  // 底部容器描述
  bottomDescr?: MessageFlowContainerBox;
  // 容器背景
  background?: MessageFlowContainerBackground;
  // 容器行为
  action?: MessageFlowAction;
  // 容器内边距
  padding?: MessageFlowContainerPadding;
  // 容器外边距
  margin?: MessageFlowContainerMargin;
  // 容器内部item的间距
  gridPadding?: {
    // 纵向间隙
    col: number;
    // 横向间隙
    row: number;
  };
  // 圆角角度
  borderRadius?: number;
  // 容器子集
  child: Array<MessageFlowContainer | MessageFlowItem>;
  // 分类组容器才有的属性
  categoryProp?: Record<'highlightColor' | 'defaultColor', string>
}

// item 项目
interface MessageFlowItem {
  type: "item";
  // 项目sn
  sn: string;
  // 项目类型
  name: MessageFlowItemName;
  // 项目圆角
  borderRadius?: number;
  // 项目行为
  action?: MessageFlowAction;
  // 项目内容数据
  biz?: { type: string; value: string };
  // 数据
  data?: { itemList?: Array<{ image: string; action: MessageFlowAction }> };
  // 图片信息
  coverImages?: Array<MessageFlowCoverImages>;
  // 分类组特殊字段
  child?: Array<MessageFlowContainer | MessageFlowItem>;
  // item标题
  title?: MessageFlowContainerBox;
  // item描述
  descr?: MessageFlowContainerBox;
  // 高度
  height?: number;
  // 宽度
  width?: number;
}
