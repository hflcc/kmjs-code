// 字符串作为key,传入泛型作为value
type StringKeyOfGenericity<T> = { [key: string]: T };

// 要单独请求详情的集合
type MessageFlowWaitRequestSnsMap = {
  goods: Array<string>;
  shop: Array<string>;
  article: Array<string>;
  society: Array<string>;
  activity: Array<string>;
  ticket: Array<string>;
};

type KeyOfMessageFlowWaitRequestSnsMap = keyof MessageFlowWaitRequestSnsMap;

// 图片待请求类型
type MessageFlowWaitRequestImages = Array<string>;

// sn对应的数据,通过key直接获取数据
type MessageFlowSnToItemData = StringKeyOfGenericity<
  | MessageFlowGoodsDetail
  | MessageFlowShopDetail
  | MessageFlowArticleDetail
  | MessageFlowActivityDetail
  | MessageFlowSocietyDetail
  | MessageFlowTicketDetail
>;

// sn对应的图片
type MessageFlowSnToImages = StringKeyOfGenericity<string>;

// 格式化后响应数据
interface FormatterMessageFlowDataInterface {
  // 信息流数据
  messageFlow: Array<MessageFlowContainer | MessageFlowItem>;
  // 图片sn: 图片链接
  imageMap: MessageFlowSnToImages;
  // itemSn: item的数据
  dataMap: MessageFlowSnToItemData;
}

// 信息流响应
interface MessageFlowResponse {
  // 信息流状态
  state?: string;
  // 信息流sn
  sn?: string;
  // 信息流名称
  name?: string;
  // 拒绝原因
  rejectReason?: string;
  // 关系类型
  relationType?: string;
  // 关联关系
  relationValue?: string;
  // 信息流数据
  data?: StringKeyOfGenericity<Array<MessageFlowContainer | MessageFlowItem>>;
  // 信息流外层属性配置
  property?: {
    padding: Record<'top' | 'right' | 'bottom' | 'left', number>;
    background: Record<'image' | 'color', string>
  }
}

// 信息流详情响应
interface MessageFlowTypeDetailResponse {
  // json字符串
  data: string;
  // 具体类型的sn
  sn: string;
  // 类型
  type: string;
  value: string;
}

// 图片详情响应
interface MessageFlowOssCommonListSeqsResponse {
  url: string;
}

// 商品详情的数据
interface MessageFlowGoodsDetail {
  browseCount: number;
  maxNum: number;
  maxPrice: number;
  minNum: number;
  minPrice: number;
  saledCount: number;
  shopName: string;
  shopSn: string;
  sn: string;
  state: string;
  title: string;
  coverImages: Array<MessageFlowCoverImages>;
  type: "goods";
}

// 店铺详情的数据
interface MessageFlowShopDetail {
  coverImages: Array<MessageFlowCoverImages>;
  mainBiz: {
    content: string;
    contentType: string;
    type: string;
  };
  name: string;
  realName: string;
  sn: string;
  state: string;
  tags: Array<string>;
  type: "shop";
}

// 文章详情的数据
interface MessageFlowArticleDetail {
  contentImageIdList: Array<string>;
  createdAt: number;
  id: number;
  sn: string;
  societyName: string;
  title: string;
  browseCount: number;
  tags: Array<string>;
  type: "article";
}

// 活动详情数据
interface MessageFlowActivityDetail {
  browseCount: number;
  city: string;
  contentImageIdList: Array<string>;
  cover: string;
  createdAt: number;
  date: number;
  endDate: number;
  id: number;
  main: { sn: string; name: string; cover: string };
  priceSection: string;
  processState: string;
  province: string;
  sn: string;
  societyName: string;
  tags: Array<string>;
  title: string;
  type: "activity";
}

// 协会详情数据
interface MessageFlowSocietyDetail {
  content: string;
  contentImageIdList: Array<string>;
  createdAt: number;
  id: number;
  industry: string;
  join: boolean;
  level: string;
  sn: string;
  title: string;
  type: "society";
}
// 优惠券详情数据
interface MessageFlowTicketDetail {
  amount: number;
  beAdd: boolean;
  endAt: number;
  icon: string;
  name: string;
  received: boolean;
  ruleDesc: string;
  scopeType: string;
  scopeValues: Array<string>;
  startAt: number;
  surplusNum: number;
  takeNum: number;
  takeType: string;
  ticketId: number;
  ticketSn: string;
  ticketType: string;
  title: string;
  totalNum: number;
  useBaseAmount: number;
  usePrice: string;
  useTimes: string;
  useType: string;
  type: "ticket";
}

/*
// shop eb0dc0268ca543199cd81ef29c2bf6db
// article 663257285ae746e5ba48d37d819a6b8d
// society gdgkjcysh
// goods ce2acef3772446a2a67e7436f3d93563
// activity 9251b3abd83245e0abd1d1c79d6bdaee
*/
