import { defineComponent, PropType } from "vue";
// item
import Advert from "./item/advert";
import Article1 from "./item/article1";
import Banner from "./item/banner";
import Goods1 from "./item/goods1";
import Goods2 from "./item/goods2";
import Shop1 from "./item/shop1";
import Shop2 from "./item/shop2";
import Activity1 from "./item/activity1";
import Activity2 from "./item/activity2";
import Ticket4 from "./item/ticket4";
import Ticket5 from "./item/ticket5";
import Society1 from "./item/society1";
import Table1 from "./item/table";
import Image_text1 from "./item/image_text1";
// container
import Category from "./container/category";
import Grid_1_1 from "./container/grid_1_1";
import Grid_1_2 from "./container/grid_1_2";
import Grid_1_3 from "./container/grid_1_3";
import Grid_1_4 from "./container/grid_1_4";
import Grid_1_5 from "./container/grid_1_5";
import Grid_1_n from "./container/grid_1_n";
import Grid_2_2 from "./container/grid_2_2";
import Grid_2_3 from "./container/grid_2_3";
import Grid_2_4 from "./container/grid_2_4";
import Grid_2_5 from "./container/grid_2_5";
import Grid_3_3 from "./container/grid_3_3";
import Shape_l from "./container/shape_l";
import Shape_y from "./container/shape_y";
import Side_frame from "./container/side_frame";

export default defineComponent({
  name: "renderCore",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer | MessageFlowItem>,
      required: true
    },
  },
  setup(props) {
    const renderFn = () => {
      const { data } = props;
      if (!data) {
        return <div/>;
      }
      switch (data.name) {
        // item 模块
        case "advert":
          return <Advert data={data}/>;
        case "image_text1":
          return <Image_text1 data={data}/>;
        case "article1":
          return <Article1 data={data}/>;
        case "banner":
          return <Banner data={data}/>;
        case "goods1":
          return <Goods1 data={data}/>;
        case "goods2":
          return <Goods2 data={data}/>;
        case "shop1":
          return <Shop1 data={data}/>;
        case "shop2":
          return <Shop2 data={data}/>;
        case "activity1":
          return <Activity1 data={data}/>;
        case "activity2":
          return <Activity2 data={data}/>;
        case "ticket5":
          return <Ticket5 data={data}/>;
        case "ticket4":
          return <Ticket4 data={data}/>;
        case "society1":
          return <Society1 data={data}/>;
        case "table":
          return <Table1 data={data}/>;
        // 容器
        case "category":
          return <Category data={data}/>;
        case "grid_1_1":
          return <Grid_1_1 data={data}/>;
        case "grid_1_2":
          return <Grid_1_2 data={data}/>;
        case "grid_1_3":
          return <Grid_1_3 data={data}/>;
        case "grid_1_4":
          return <Grid_1_4 data={data}/>;
        case "grid_1_5":
          return <Grid_1_5 data={data}/>;
        case "grid_1_n":
          return <Grid_1_n data={data}/>;
        case "grid_2_2":
          return <Grid_2_2 data={data}/>;
        case "grid_2_3":
          return <Grid_2_3 data={data}/>;
        case "grid_2_4":
          return <Grid_2_4 data={data}/>;
        case "grid_2_5":
          return <Grid_2_5 data={data}/>;
        case "grid_3_3":
          return <Grid_3_3 data={data}/>;
        case "shape_l":
          return <Shape_l data={data}/>;
        case "shape_y":
          return <Shape_y data={data}/>;
        case "side_frame":
          return <Side_frame data={data}/>;
        default:
          return <div>没有匹配的{name}</div>;
      }
    }
    return () => renderFn()
  }
});
