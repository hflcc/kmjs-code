import { PropType, defineComponent, computed, ref, onBeforeUnmount } from "vue";
import { useGetMethods } from "../utils/mixins";
import RenderCore from "../RenderCore";

export default defineComponent({
  name: "Side_frame",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { getContainerStyleMapFn } = useGetMethods();

    const open = ref(false);

    function changeOpen() {
      open.value = !open.value;
    }

    function bodyTouchStart(e: HTMLElementEventMap["touchstart"]) {
      const classList = e.composedPath().map((item) => {
        return (item as Element).className;
      });
      if (!classList.includes("side_frame") && open.value) {
        open.value = false;
      }
    }

    document.body.addEventListener("touchstart", bodyTouchStart, {
      capture: true,
    });

    onBeforeUnmount(() => {
      document.body.removeEventListener("touchstart", bodyTouchStart);
    });

    function clickItem(source: MessageFlowContainer | MessageFlowItem) {
      console.log("clickItem", source);
      changeOpen();
    }

    const child = computed(() => {
      return props.data.child.slice(0, 5);
    });
    const { containerStyle } = getContainerStyleMapFn(props.data);
    return {
      child,
      containerStyle,
      open,
      changeOpen,
      clickItem,
    };
  },
  render() {
    const { child, containerStyle, open, changeOpen, clickItem } = this;
    return (
      <div class="side_frame">
        <div
          class="container"
          style={containerStyle}
          onClick={() => {
            changeOpen();
          }}
        ></div>
        {child.map((item, index) => {
          return (
            <div
              class={`side_frame_item side_frame_${index} ${
                open ? `side_frame_active side_frame_${index}_active` : ""
              }`}
              onClick={() => {
                clickItem(item);
              }}
            >
              <RenderCore data={item}></RenderCore>
            </div>
          );
        })}
      </div>
    );
  },
});
