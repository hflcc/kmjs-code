import { PropType, defineComponent, computed } from "vue";
import RenderCore from "../RenderCore";
import { useGetMethods } from "../utils/mixins";
import TopTitleOrDesc from "../commonComponents/topTitleOrDesc";
import BottomTitleOrDesc from "../commonComponents/bottomTitleOrDesc";
export default defineComponent({
  name: "Grid_2_2",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { getContainerStyleMapFn } = useGetMethods();

    const child = computed(() => {
      return props.data.child.slice(0, 4);
    });
    const { gridStyle, containerStyle } = getContainerStyleMapFn(props.data);
    return {
      child,
      gridStyle,
      containerStyle,
    };
  },
  render() {
    const { child, gridStyle, containerStyle, data } = this;
    return (
      <div class="Grid_2_2" style={containerStyle}>
        <TopTitleOrDesc data={data} />
        <div class="container" style={gridStyle}>
          {child?.map((item) => {
            return (
              <div class="Grid_2_2_item">
                <RenderCore data={item}></RenderCore>
              </div>
            );
          })}
        </div>
        <BottomTitleOrDesc data={data} />
      </div>
    );
  },
});
