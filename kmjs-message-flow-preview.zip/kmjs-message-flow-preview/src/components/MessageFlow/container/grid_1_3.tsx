import { PropType, defineComponent, computed } from "vue";
import RenderCore from "../RenderCore";
import { useGetMethods } from "../utils/mixins";
import TopTitleOrDesc from "../commonComponents/topTitleOrDesc";
import BottomTitleOrDesc from "../commonComponents/bottomTitleOrDesc";
export default defineComponent({
  name: "Grid_1_3",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { getContainerStyleMapFn } = useGetMethods();

    const child = computed(() => {
      return props.data.child.slice(0, 3);
    });
    const { gridStyle, containerStyle } = getContainerStyleMapFn(props.data);
    return {
      child,
      gridStyle,
      containerStyle,
    };
  },
  render() {
    const { child, data, gridStyle, containerStyle } = this;
    return (
      <div class="Grid_1_3" style={containerStyle}>
        <TopTitleOrDesc data={data} />
        <div class="container" style={gridStyle}>
          {child.map((item) => {
            return (
              <div class="Grid_1_3_item">
                <RenderCore data={item}></RenderCore>
              </div>
            );
          })}
        </div>
        <BottomTitleOrDesc data={data} />
      </div>
    );
  },
});
