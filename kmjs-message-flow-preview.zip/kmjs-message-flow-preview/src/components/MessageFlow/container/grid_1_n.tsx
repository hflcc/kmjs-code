import {
  PropType,
  defineComponent,
  computed,
  onMounted,
  ref,
  ComponentPublicInstance,
} from "vue";
import RenderCore from "../RenderCore";
import { useGetMethods } from "../utils/mixins";
import TopTitleOrDesc from "../commonComponents/topTitleOrDesc";
import BottomTitleOrDesc from "../commonComponents/bottomTitleOrDesc";
import BScroll from "@better-scroll/core";
export default defineComponent({
  name: "Grid_1_n",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { getContainerStyleMapFn, getContainerItemWrapStyle } =
      useGetMethods();

    const child = computed(() => {
      return props.data.child;
    });
    const { containerStyle } = getContainerStyleMapFn(props.data);
    const Grid_1_n = ref<null | HTMLElement>(null);

    onMounted(() => {
      if (Grid_1_n.value) {
        const bs = new BScroll(Grid_1_n.value, {
          scrollX: true,
          scrollY: false,
        });
        bs.refresh();
      }
    });

    return {
      child,
      containerStyle,
      Grid_1_n,
      getContainerItemWrapStyle,
    };
  },
  render() {
    const { child, containerStyle, getContainerItemWrapStyle, data, Grid_1_n } =
      this;
    return (
      <div class="Grid_1_n" style={containerStyle}>
        <TopTitleOrDesc data={data} />
        <div class="container" ref="Grid_1_n">
          <div class="scroll_bar">
            {child?.map((item, index) => {
              return (
                <div
                  class="Grid_1_n_item"
                  style={getContainerItemWrapStyle(
                    data,
                    index === child.length - 1
                  )}
                >
                  <RenderCore data={item}></RenderCore>
                </div>
              );
            })}
          </div>
        </div>
        <BottomTitleOrDesc data={data} />
      </div>
    );
  },
});
