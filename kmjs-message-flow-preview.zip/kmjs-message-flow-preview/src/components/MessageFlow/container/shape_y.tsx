import { PropType, defineComponent, computed } from "vue";
import { useGetMethods } from "../utils/mixins";
import RenderCore from "../RenderCore";
import TopTitleOrDesc from "../commonComponents/topTitleOrDesc";
import BottomTitleOrDesc from "../commonComponents/bottomTitleOrDesc";

export default defineComponent({
  name: "Shape_y",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { getContainerStyleMapFn } = useGetMethods();

    const child = computed(() => {
      return props.data.child.slice(0, 3);
    });
    const { gridStyle, containerStyle, differentGridStyle } =
      getContainerStyleMapFn(props.data);
    return {
      child,
      gridStyle,
      containerStyle,
      differentGridStyle,
    };
  },
  render() {
    const { child, gridStyle, containerStyle, differentGridStyle, data } = this;
    return (
      <div class="Shape_y" style={containerStyle}>
        <TopTitleOrDesc data={data} />
        <div class="container">
          <div class="top" style={differentGridStyle}>
            <div class="Shape_y_item">
              <RenderCore data={child[0]}></RenderCore>
            </div>
          </div>
          <div class="bottom" style={gridStyle}>
            {child.map((item, index) => {
              return index === 0 ? undefined : (
                <div class="Shape_y_item">
                  <RenderCore data={item}></RenderCore>
                </div>
              );
            })}
          </div>
        </div>
        <BottomTitleOrDesc data={data} />
      </div>
    );
  },
});
