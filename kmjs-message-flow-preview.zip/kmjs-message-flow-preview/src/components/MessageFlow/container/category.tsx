import {defineComponent, ref, KeepAlive, onBeforeUpdate, onMounted, onUnmounted} from "vue";
import type { PropType, FunctionalComponent } from 'vue';
import {useGetMethods} from "../utils/mixins";
import Table from '../item/table'
import flowTabsList from "../commonComponents/flowTabsList";
import {debounce} from '../utils'

interface TabListItemComp extends FunctionalComponent {
  loadMore: () => void;
}

interface tabScrollObj {
  isFixed: boolean;
  scrollTop: number;
}

export default defineComponent({
  name: "Category",
  components: {
    flowTabsList
  },
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const {getContainerStyleMapFn} = useGetMethods();
    const defProp = { highlightColor: '#ff3721', defaultColor: '#666666' }
    const itemRefs = ref<TabListItemComp[]>([])
    const tabBg = ref('')
    let {containerStyle} = getContainerStyleMapFn(props.data);
    let activeIndex = ref(0)


    const categoryProp = props.data?.categoryProp ?? defProp
    // 针对分类组容器添加滑块颜色样式
    containerStyle += `--van-tabs-bottom-bar-color: ${categoryProp.highlightColor || defProp.highlightColor};`

    const setItemRefs = (el: TabListItemComp, i: number) => {
      itemRefs.value[i] = el
    }

    const handleVanTabScroll = (res: tabScrollObj) => {
      if (res.isFixed && !tabBg.value) {
        tabBg.value = '#ffffff'
      } else if (!res.isFixed && tabBg.value) {
        tabBg.value = ''
      }
    }

    onBeforeUpdate(() => {
      itemRefs.value = []
    })

    onMounted(() => {
      const flowWrapElem: HTMLElement | null = document.getElementById('messageFlowWrapElem')
      const flowScrollElem: HTMLElement | null = document.getElementById('messageFlowScrollElem')
      const flowWrapHeight = flowWrapElem?.offsetHeight || 0

      const listener = debounce(function (e: Event){
        const scrollHeight = flowScrollElem?.offsetHeight || 0
        const scrollTop = (e.target as HTMLDivElement).scrollTop || 0
        if (scrollTop + flowWrapHeight >= scrollHeight) {
          (itemRefs.value[activeIndex.value] as TabListItemComp)?.loadMore()
        }
      })
      flowWrapElem?.addEventListener('scroll', listener as EventListener)

      onUnmounted(() => {
        flowWrapElem?.removeEventListener('scroll', listener as EventListener)
      })
    })

    return {
      activeIndex,
      categoryProp,
      containerStyle,
      tabBg,
      setItemRefs,
      handleVanTabScroll
    }
  },
  render() {
    const {containerStyle, categoryProp, setItemRefs, handleVanTabScroll, tabBg} = this

    return (
        <div style={containerStyle}>
          <van-tabs onScroll={handleVanTabScroll} background={tabBg} sticky swipeable v-model={[this.activeIndex, 'active']}>
            {this.data.child.map((obj, i) => {
              return (
                  <van-tab v-slots={{
                    title: () => <Table activeIndex={this.activeIndex} tabIndex={i} data={obj}
                                        categoryProp={categoryProp}/>
                  }}>
                    <KeepAlive>
                      {this.activeIndex === i &&
                      <flowTabsList ref={(el: TabListItemComp) => setItemRefs(el, i)} active={this.activeIndex === i}
                                    datas={obj}/>}
                    </KeepAlive>
                  </van-tab>
              );
            })}
          </van-tabs>
        </div>
    )
  }
});
