import { defineComponent, h, PropType } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "top_title_or_desc",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    const { callActionFn } = useGetMethods();
    function renderFn() {
      const { title, descr, action } = props.data;
      let element = [];
      if (title && title.name) {
        const style = `color: ${title.color};`;
        element.push(
          <div class="title van-ellipsis" style={style}>
            {title.name}
          </div>
        );
      }
      if (descr && descr.name) {
        const style = `color: ${descr.color};--blcolor: ${descr.color}`;
        element.push(
          <div class="desc" style={style}>
            <span class="text van-ellipsis">{descr.name}</span>
          </div>
        );
      }
      if (action && action.value) {
        element.push(
          <div
            class="has_more van-ellipsis"
            onClick={() => {
              callActionFn(action);
            }}
          >
            <span class="text">更多</span> <van-icon class="icon" color="#666" name="arrow" />
          </div>
        );
      }
      return element.length > 0
        ? h(
            "div",
            {
              className: "top_title_or_desc",
            },
            element
          )
        : h("div");
    }
    return {
      renderFn,
    };
  },
  render() {
    const { renderFn } = this;
    return renderFn();
  },
});
