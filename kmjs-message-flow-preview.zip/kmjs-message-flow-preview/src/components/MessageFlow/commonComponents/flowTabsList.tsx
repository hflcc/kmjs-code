import {defineComponent, toRefs, inject, PropType, reactive, onMounted} from "vue";
import RenderCore from "../RenderCore";
import { Toast } from 'vant';

interface TabListState {
  pageSize: number;
  pageNo: number;
  totalPage: number;
  split2wList: Array<MessageFlowContainer[]>;
  renderList: Array<MessageFlowContainer>;
}

export default defineComponent({
  name: 'FlowTabsList',
  props: {
    datas: {
      type: Object as PropType<MessageFlowContainer>,
      default: () => []
    },
    active: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const isMobile = inject('isMobile')
    const state = reactive<TabListState>({
      pageSize: 10,
      pageNo: 0,
      totalPage: 0,
      split2wList: [], // 切割好的二维数据
      renderList: [],
    })

    /*
    * @info 前端分页, 将分类组数据分为二维数组
    * */
    const split2wListFn = () => {
      let start = 0
      let num = 1
      const arr = props.datas.child
      const pages = Math.ceil(arr?.length / state.pageSize)
      while (state.split2wList.length < pages) {
        state.split2wList.push(arr.slice(start, state.pageSize * num)  as Array<MessageFlowContainer>)
        start += state.pageSize
        num++
      }
      state.totalPage = state.split2wList.length
    }

    const render = () => {
      if (state.split2wList[state.pageNo]) {
        state.renderList.push(...state.split2wList[state.pageNo])
      }
      setTimeout(() => {
        Toast.clear()
      }, 500)
    }

    const loadMore = () => {
      if (props.active && state.pageNo < state.totalPage - 1) {
        Toast.loading({
          message: '加载中...',
          forbidClick: true,
          loadingType: 'spinner',
        });
        state.pageNo++
        render()
      }
    }

    onMounted(() => {
      split2wListFn()
      render()
    })


    return {
      ...toRefs(state),
      loadMore,
      isMobile
    }
  },
  render() {
    const { renderList, isMobile, datas } = this

    return (
        <div>
          {renderList?.map((item, j) => {
            return <div style="position: relative;">
              {!isMobile && <div class="mark-label-1">
                <p class="text">#{j + 1}</p>
              </div>}
              <RenderCore data={item} />
            </div>
          })}
          { renderList?.length === datas.child?.length && <div class="no-more-text">没有更多了</div> }
        </div>
    )
  }
})
