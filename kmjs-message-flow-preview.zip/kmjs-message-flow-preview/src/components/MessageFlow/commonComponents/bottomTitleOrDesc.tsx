import { defineComponent, h, PropType } from "vue";

export default defineComponent({
  name: "bottom_title_or_desc",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer>,
      required: true,
    },
  },
  setup(props) {
    function renderFn() {
      const { bottomTitle, bottomDescr } = props.data;
      let element = [];
      if (bottomTitle && bottomTitle.name) {
        const style = `color: ${bottomTitle.color};`;
        element.push(
          <div class="title van-ellipsis" style={style}>
            {bottomTitle.name}
          </div>
        );
      }
      if (bottomDescr && bottomDescr.name) {
        const style = `color: ${bottomDescr.color};`;
        element.push(
          <div class="desc van-ellipsis" style={style}>
            {bottomDescr.name}
          </div>
        );
      }
      return element.length > 0
        ? h(
            "div",
            {
              className: "bottom_title_or_desc",
            },
            element
          )
        : h("div");
    }
    return {
      renderFn,
    };
  },
  render() {
    const { renderFn } = this;
    return renderFn();
  },
});
