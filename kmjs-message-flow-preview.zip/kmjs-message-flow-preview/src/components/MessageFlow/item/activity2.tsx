import { PropType, defineComponent } from "vue";
import { formatTime } from "../utils/format";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Activity1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowActivityDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    // 活动图片
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    return {
      result,
      itemStyle,
      image,
      callActionFn,
    };
  },
  render() {
    const { result, image, itemStyle, callActionFn } = this;
    if (result) {
      return (
        <div class="activity2" style={itemStyle}>
          <div class="image">
            <img class="img" src={image} alt="activity image" />
          </div>
          <div class="msg">
            <div class="name van-multi-ellipsis--l2">
              {result.tags.map((item) => (
                <div class="tag">{item}</div>
              ))}
              {result.title}
            </div>
            <div class="detail">
              <div class="basic_msg">
                <div class="owner_name van-ellipsis">{result.societyName}</div>
                <div class="time_location">
                  <div class="time van-ellipsis">
                    {formatTime(result.createdAt * 1000, "MM月DD日 dddd")}
                  </div>
                  <div class="location van-ellipsis">
                    {result.province + " " + result.city}
                  </div>
                </div>
                <div class="owner">
                  <div class="activity_price van-ellipsis">
                    {result.priceSection === "免费" ? undefined : (
                      <span class="icon">￥</span>
                    )}
                    {result.priceSection}
                  </div>
                </div>
              </div>
              <div class="btn_wrap">
                <div class="btn">立即报名</div>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
