import { PropType, defineComponent } from "vue";
import { formatTime } from "../utils/format";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Activity1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowActivityDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "",
      societyImage = "";
    // 活动图片
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    // 主办方图片
    if (result && result.main && result.main.cover) {
      societyImage = getImageUrl(result.main.cover);
    }
    return {
      result,
      itemStyle,
      image,
      societyImage,
      callActionFn,
    };
  },
  render() {
    const { result, image, societyImage, itemStyle, callActionFn } = this;
    if (result) {
      return (
        <div class="activity1" style={itemStyle}>
          <div class="img_wrap">
            <img class="img" src={image} alt="activity image" />
          </div>
          <div class="msg">
            <div class="name van-multi-ellipsis--l2">{result.title}</div>
            <div class="time_location">
              <div class="time van-ellipsis">
                {formatTime(result.createdAt * 1000, "MM月DD日 dddd")}
              </div>
              <div class="location van-ellipsis">
                {" "}
                {result.province + " " + result.city}
              </div>
            </div>
            <div class="tags">
              <div class="tag van-ellipsis">#{ result.tags?.join('#') }</div>
            </div>
            <div class="owner">
              <div class="owner_image">
                <img src={societyImage} alt="activity1 image" />
              </div>
              <div class="owner_name van-ellipsis">{result.societyName}</div>
              <div class="activity_price van-ellipsis">
                {result.priceSection === "免费" ? undefined : (
                  <span class="icon">￥</span>
                )}
                {result.priceSection}
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
