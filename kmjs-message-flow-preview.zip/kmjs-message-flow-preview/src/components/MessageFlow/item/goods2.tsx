import { PropType, defineComponent, computed } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Goods2",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowGoodsDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    const pricetext = computed(() => {
      if (result) {
        if (result.minPrice === result.maxPrice) {
          return result.minPrice;
        }
        return `${result.minPrice}~${result.maxPrice}`;
      }
      return "";
    });
    return {
      result,
      itemStyle,
      image,
      callActionFn,
      pricetext,
    };
  },
  render() {
    const { result, image, itemStyle, callActionFn, data, pricetext } = this;
    if (result) {
      return (
        <div
          class="goods2"
          style={itemStyle}
          onClick={() => {
            callActionFn(data.action);
          }}
        >
          <div class="goods_img">
            <img src={image} class="full_width" />
          </div>
          <div class="goods_msg">
            <div class="goods_name van-multi-ellipsis--l2">{result.title}</div>
            <div class="goods_msg-bottom">
              <div class="goods_price van-ellipsis">
                <span class="icon">￥</span>
                {pricetext}
              </div>
              <div class="goods_start_count van-ellipsis">
                <span class="text">{result.browseCount}人浏览</span>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
