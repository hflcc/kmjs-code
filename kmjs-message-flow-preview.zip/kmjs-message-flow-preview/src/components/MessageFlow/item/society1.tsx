import { PropType, defineComponent, h } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Society1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowSocietyDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    return {
      result,
      itemStyle,
      image,
      callActionFn,
    };
  },
  render() {
    const { result, image, itemStyle, callActionFn, data } = this;
    if (result) {
      return (
        <div class="society1" style={itemStyle}>
          <div class="image">
            <img class="img" src={image} alt="society image" />
          </div>
          <div class="msg">
            <div class="name van-multi-ellipsis--l2">{result.title}</div>
            <div class="desc van-multi-ellipsis--l2">{result.content}</div>
            <div class="detail">
              <div class="basic_msg">
                <div class="line van-ellipsis">
                  <span class="title">行业:</span>
                  <span class="value"> {result.industry || "-"}</span>
                </div>
                <div class="line van-ellipsis">
                  <span class="title">等级:</span>
                  <span class="value"> {result.level || "-"}</span>
                </div>
              </div>
              <div class="btn_wrap">
                <div class="btn">进入主页</div>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
