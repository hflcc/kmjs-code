import { PropType, defineComponent } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "shop1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowShopDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data.coverImages[0].ossId);
    }
    return {
      itemStyle,
      image,
      result,
    };
  },
  render() {
    const { itemStyle, image, result } = this;
    if (result) {
      return (
        <div class="shop1" style={itemStyle}>
          <img class="img" src={image} alt="shop1 图片" />
        </div>
      );
    }
    return undefined;
  },
});
