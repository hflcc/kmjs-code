import { PropType, defineComponent, ref } from "vue";
import { formatTime } from "../utils/format";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Ticket4",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowTicketDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    return {
      result,
      itemStyle,
      callActionFn,
    };
  },
  render() {
    const { result, itemStyle, callActionFn } = this;
    if (result) {
      return (
        <div class="ticket5" style={itemStyle}>
          <div class="left">
            <div class="price van-ellipsis">
              <span class="icon">￥</span>
              <span class="num">{result.amount}</span>
            </div>
          </div>
          <div class="left-bottom van-ellipsis">
            <span class="desc">{result.ruleDesc}</span>
          </div>
          <div class="right">
            <div class="msg">
              <div class="detail van-ellipsis">{result.name}</div>
              <div class="timer van-ellipsis">
                {`${formatTime(
                  result.startAt * 1000,
                  "YYYY.MM.DD"
                )} ~ ${formatTime(result.endAt * 1000, "YYYY.MM.DD")}`}
              </div>
            </div>
            <div class="btn_wrap">
              <div class="btn">领取</div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
