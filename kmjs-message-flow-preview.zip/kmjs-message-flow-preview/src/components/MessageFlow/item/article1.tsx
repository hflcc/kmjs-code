import { PropType, defineComponent } from "vue";
import { formatTime } from "../utils/format";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Article1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowArticleDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    return {
      result,
      itemStyle,
      image,
      callActionFn,
    };
  },
  render() {
    const { result, image, itemStyle, callActionFn } = this;
    if (result) {
      return (
        <div class="article1" style={itemStyle}>
          <div class="image">
            <img class="img" src={image} alt="article pic" />
          </div>
          <div class="detail">
            <div class="top">
              <div class="name van-multi-ellipsis--l2">
                {result.tags?.map((item) => {
                  return <div class="tag">{item}</div>;
                })}
                {result.title}
              </div>
              <div class="society_name">{result.societyName}</div>
            </div>
            <div class="bottom">
              <div class="left van-ellipsis">
                <i class="icon browse"/>
                <span class="text">
                  {formatTime(result.createdAt * 1000, "YYYY.MM.DD HH:mm")}
                </span>
              </div>
              <div class="right van-ellipsis">
                <i class="icon time"/>
                <span class="text">{result.browseCount}</span>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
