import { PropType, defineComponent } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "shop2",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowShopDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data.coverImages[0].ossId);
    }
    return {
      itemStyle,
      image,
      result,
    };
  },
  render() {
    const { itemStyle, image, result } = this;
    if (result) {
      return (
        <div class="shop2" style={itemStyle}>
          <div class="left">
            <img class="img" src={image} alt="shop2组件图片" />
          </div>
          <div class="right">
            <div class="basic">
              <div class="name van-ellipsis">{result.name}</div>
              {result.tags && result.tags.length > 0 ? (
                <div class="tags van-ellipsis">
                  {result.tags.map((item) => {
                    return <div class="tag">{item}</div>;
                  })}
                </div>
              ) : undefined}

              <div class="business van-ellipsis">
                {result.mainBiz?.content
                  ? `主营业务: ${result.mainBiz.content}`
                  : ""}
              </div>
            </div>
            <div class="join_shop">
              <div class="btn">进店看看</div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
