import { PropType, defineComponent } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "ImageText1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getItemStyle } = useGetMethods();
    let url = "";
    if (props.data.coverImages && props.data.coverImages[0]) {
      const { ossId } = props.data.coverImages[0];
      url = getImageUrl(ossId);
    }
    const itemStyle = getItemStyle(props.data);
    const title = props.data?.title as { name: string; color: string };
    return {
      url,
      itemStyle,
      title
    };
  },
  render() {
    const { url, itemStyle, title } = this;
    if (url) {
      return (
          <div class="imageText1" style={itemStyle}>
            <div class="image-box" style={{ height: title.name ? '' : '100%' }}>
              <img class="full_width" src={url}  alt="" />
            </div>
            {title?.name && <div class="text-box" style={{color: title.color}}>
              <span>{title.name}</span>
            </div>}
          </div>
      );
    }
    return undefined;
  },
});
