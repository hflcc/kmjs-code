import { PropType, defineComponent, computed, inject } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Banner",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, callActionFn, getItemStyle } = useGetMethods();
    const itemStyle = getItemStyle(props.data);
    const images = computed(() => {
      return (
        props.data?.data?.itemList?.map((item) => {
          return Object.assign(item, {
            image: getImageUrl(item.image),
          });
        }) || []
      );
    });
    return {
      images,
      callActionFn,
      itemStyle
    };
  },
  render() {
    const { images, callActionFn, itemStyle } = this;
    return (
      <van-swipe
        style={itemStyle}
        class="banner my-swipe"
        indicator-color="white"
        autoplay={1000 * 3}
      >
        {images.map((item, index) => {
          return (
            <van-swipe-item
              class="banner_swipe_item"
              onClick={() => {
                callActionFn(item.action);
              }}
            >
              <img class="full_width" style="height: 100%;" src={item.image} />
            </van-swipe-item>
          );
        })}
      </van-swipe>
    );
  },
});
