import { PropType, defineComponent } from "vue";

export default defineComponent({
  name: "Table",
  props: {
    data: {
      type: Object as PropType<MessageFlowContainer | MessageFlowItem>,
      required: true,
    },
    categoryProp: {
      type: Object as PropType<Record<'highlightColor' | 'defaultColor', string>>,
      default: () => ({})
    },
    tabIndex: {
      type: Number,
      default: 0
    },
    activeIndex: {
      type: Number,
      default: 0
    }
  },
  setup(props) {
    function renderFn() {
      const { title, descr, action } = props.data;
      const { highlightColor, defaultColor } = props.categoryProp
      const activeIndex = props.activeIndex
      const tabIndex = props.tabIndex
      const element = [];
      if (title && title.name) {
        element.push(
          <div
            class="title van-ellipsis"
            style={{ 'color': activeIndex === tabIndex ? highlightColor : defaultColor }}
          >
            {title.name}
          </div>
        );
      }
      if (descr && descr.name) {
        element.push(
          <div
            class="desc van-ellipsis"
            style={{ 'color': activeIndex === tabIndex ? highlightColor : defaultColor }}
          >
            {descr.name}
          </div>
        );
      }
      return element;
    }
    return {
      renderFn,
    };
  },
  render() {
    const { renderFn } = this;
    return (
      <div class="tab-table">
        {
          renderFn()
        }
      </div>
    );
  },
});
