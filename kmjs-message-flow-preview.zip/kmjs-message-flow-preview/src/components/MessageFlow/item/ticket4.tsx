import { PropType, defineComponent, ref } from "vue";
import { formatTime } from "../utils/format";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Ticket5",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowTicketDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    const showWan = ref(false);
    function formatterMoney(num: number) {
      if (num >= 10000) {
        showWan.value = true;
        if (num % 10000 === 0) {
          return num / 10000 + "";
        }
        return (num / 10000).toFixed(1);
      }
      return num;
    }
    return {
      result,
      itemStyle,
      formatterMoney,
      callActionFn,
      showWan,
    };
  },
  render() {
    const { result, itemStyle, formatterMoney, showWan, callActionFn } = this;
    const len = `${formatterMoney((result?.amount ?? 0) * 10000)}`.length
    if (result) {
      return (
        <div class="ticket4" style={itemStyle}>
          <div class="msg">
            <img class="ticket-img" src="https://resource.kmyun.cn/kmjs-infoflow-npm/coupons_bit-orange.png" alt=""/>
            <div class="price">
              <span class="icon">¥</span>
              <span class="num" style={{fontSize: len >= 4 ? '22px' : ''}}>
                {formatterMoney(result.amount * 10000)}
              </span>
            </div>
            <div class="desc van-ellipsis">{result.ruleDesc}</div>
          </div>
          <div class="btn">立即领取</div>
        </div>
      );
    }
    return undefined;
  },
});
