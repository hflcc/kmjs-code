import { PropType, defineComponent } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Goods1",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getData, getItemStyle, callActionFn } =
      useGetMethods();
    const result = getData<MessageFlowGoodsDetail | undefined>(
      props.data.biz?.value || ""
    );
    const itemStyle = getItemStyle(props.data);
    let image = "";
    if (props.data && props.data.coverImages && props.data.coverImages[0]) {
      image = getImageUrl(props.data?.coverImages[0].ossId);
    }
    return {
      result,
      itemStyle,
      image,
      callActionFn,
    };
  },
  render() {
    const { result, image, itemStyle, callActionFn, data } = this;
    if (result) {
      return (
        <div
          class="goods1"
          style={itemStyle}
          onClick={() => {
            callActionFn(data.action);
          }}
        >
          <div class="image">
            <img class="img" src={image} alt="goods pic" />
          </div>
          <div class="detail">
            <div class="top">
              <div class="name van-multi-ellipsis--l3">{result.title}</div>
              <div class="tags van-ellipsis ">
                <div class="tag ">{result.minNum}件起批</div>
              </div>
            </div>
            <div class="bottom">
              <div class="left">
                <div class="price van-ellipsis">
                  <span class="icon">￥</span>
                  <span class="real_price">{result.minPrice}</span>
                </div>
                <div class="join_car van-ellipsis">加入购物车</div>
              </div>
              <div class="shop">
                <i class="shop-icon"/>
                <span class="shop-text van-ellipsis">{result.shopName}</span>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return undefined;
  },
});
