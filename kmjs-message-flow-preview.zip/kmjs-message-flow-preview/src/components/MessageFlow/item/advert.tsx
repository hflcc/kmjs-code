import { PropType, defineComponent, computed } from "vue";
import { useGetMethods } from "../utils/mixins";

export default defineComponent({
  name: "Advert",
  props: {
    data: {
      type: Object as PropType<MessageFlowItem>,
      required: true,
    },
  },
  setup(props) {
    const { getImageUrl, getItemStyle } = useGetMethods();
    let url = "";
    if (props.data.coverImages && props.data.coverImages[0]) {
      const { ossId } = props.data.coverImages[0];
      url = getImageUrl(ossId);
    }
    const itemStyle = getItemStyle(props.data);
    return {
      url,
      itemStyle,
    };
  },
  render() {
    const { url, itemStyle } = this;
    if (url) {
      return (
        <div class="advert" style={itemStyle}>
          <img class="full_width" src={url} />
        </div>
      );
    }
    return undefined;
  },
});
