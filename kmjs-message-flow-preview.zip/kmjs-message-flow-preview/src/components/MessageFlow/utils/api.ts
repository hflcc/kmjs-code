import axios from "axios";
let baseUrl = '';
const mode = import.meta.env.MODE
const VITE_CUR_ENV = import.meta.env.VITE_CUR_ENV

if (mode === 'development') {
  baseUrl = '/dev'
} else if (VITE_CUR_ENV === 'test') {
  baseUrl = '/api-test' // build打包时通过nginx转发地址
} else if (VITE_CUR_ENV === 'prod') {
  baseUrl = '/api' // build打包时通过nginx转发地址
}

const instance = axios.create({
  baseURL: "/",
  timeout: 1000 * 60,
});

// 请求适配器
instance.interceptors.request.use(
  (config) => {
    return config;
  },
  () => {
    return false;
  }
);

// 响应适配器
instance.interceptors.response.use(
  (response) => {
    return response.data;
  },
  () => {
    return false;
  }
);

// 获取置顶类型的详情
function getTypeDetail<R = any>(type: string) {
  return (sns: string) => {
    return instance.get<null, R>(
      `${baseUrl}/info/common/flow/resource/map/${type}/${sns}`
    );
  };
}
// 获取商品详情
export const getGoodsDetail = getTypeDetail("goods");
// 获取店铺详情
export const getShopDetail = getTypeDetail("shop");
// 获取文章详情
export const getArticleDetail = getTypeDetail("article");
// 获取协会详情
export const getSocietyDetail = getTypeDetail("society");
// 获取活动详情
export const getActivityDetail = getTypeDetail("activity");
// 获取优惠券详情
export const getTicketDetail = getTypeDetail("ticket");

// 获取基本数据
export function getBaseData(sn: string) {
  if (sn) {
    return instance.get<null, MessageFlowResponse>(
      `${baseUrl}/info/common/flow/instance/detail/${sn}`,
      {
        params: {
          sn,
        },
      }
    );
  } else {
    return Promise.resolve({});
  }
  // return instance.get<null, MessageFlowResponse>("/mock/1.json", {
  //   params: {
  //     sn,
  //   },
  // });
}

// 批量获取图片
export function getImageUrl(seqs: string) {
  return instance.get<
    null,
    StringKeyOfGenericity<MessageFlowOssCommonListSeqsResponse>
  >(`${baseUrl}/oss/common/list/seqs`, {
    params: {
      seqs,
    },
  });
}
