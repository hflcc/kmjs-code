import {
  getActivityDetail,
  getArticleDetail,
  getBaseData,
  getGoodsDetail,
  getImageUrl,
  getShopDetail,
  getSocietyDetail,
  getTicketDetail,
} from "./api";
// 批量请求阈值
const thresholdValue = 30;
/**
 * @method 获取信息流数据
 * @desc getData
 * @param sn {String} 信息流sn
 * @return {Promise<AxiosResponse<MessageFlowResponse>>} 请求的响应
 */
export function getData(sn: string): Promise<MessageFlowResponse> {
  return getBaseData(sn);
}

/**
 * @method getMessageFlowDetail
 * @desc 获取信息流详情
 * @return {Promise<any>}
 * @param type
 * @param sns
 * @param saveData
 * @param images
 */
export function getMessageFlowDetail(
  type: string,
  sns: Array<string>,
  saveData: MessageFlowSnToItemData,
  images: MessageFlowWaitRequestImages
): Promise<boolean> {
  return new Promise((resolve) => {
    /**
     * 1.去重
     */
    sns = removeSameItem(sns);
    /**
     * 2.使用阈值分割请求
     *  1.获取sns的长度/阈值;向上取整;
     *  2.遍历这个数值,将接口批量发起请求;
     */
    const len = Math.ceil(sns.length / thresholdValue);
    const promises = [];
    for (let i = 0; i < len; i++) {
      if (type === "goods") {
        promises.push(
          getGoodsDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      } else if (type === "shop") {
        promises.push(
          getShopDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      } else if (type === "article") {
        promises.push(
          getArticleDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      } else if (type === "society") {
        promises.push(
          getSocietyDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      } else if (type === "activity") {
        promises.push(
          getActivityDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      } else if (type === "ticket") {
        promises.push(
          getTicketDetail(
            sns.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
          )
        );
      }
    }
    /**
     * 3.数据处理
     *  1.遍历响应数据,取出每一种类型的key-value;
     *  2.遍历对象,sn为(商品sn|店铺sn|协会sn|文章sn): 对应类型的数据;
     *  3.拿到的数据字符串进行强转,如果返回不是false,那么转换成功;
     *  4.对应的数据类型里面加入类型属性,以便区分;
     *  5.将对应类型里面图片暂存到images里面;
     */
    Promise.all(promises).then(
      (res: Array<StringKeyOfGenericity<MessageFlowTypeDetailResponse>>) => {
        // 遍历promise的response
        res.forEach((item) => {
          Object.keys(item).forEach((key) => {
            const data = item[key];
            let result = jsonStringToJson(data.data);
            if (result) {
              if (data.type === "goods") {
                const formatData = result as MessageFlowGoodsDetail;
                formatData.type = "goods";
                saveData[key] = formatData;
              } else if (data.type === "shop") {
                const formatData = result as MessageFlowShopDetail;
                formatData.type = "shop";
                saveData[key] = formatData;
              } else if (data.type === "article") {
                const formatData = result as MessageFlowArticleDetail;
                formatData.type = "article";
                saveData[key] = formatData;
              } else if (data.type === "activity") {
                const formatData = result as MessageFlowActivityDetail;
                formatData.type = "activity";
                saveData[key] = formatData;
                if (formatData.main && formatData.main.cover) {
                  images.push(formatData.main.cover);
                }
              } else if (data.type === "society") {
                const formatData = result as MessageFlowSocietyDetail;
                formatData.type = "society";
                saveData[key] = formatData;
              } else if (data.type === "ticket") {
                const formatData = result as MessageFlowTicketDetail;
                formatData.type = "ticket";
                saveData[key] = formatData;
              }
            }
          });
        });
        resolve(true);
      }
    );
  });
}

/**
 * @method getOssIdUrl
 * @desc ossId批量换取图片
 * @param {*}
 * @return {*}
 */
export function getOssIdUrl(
  lists: Array<string>,
  snToImageUrl: MessageFlowSnToImages
): Promise<boolean> {
  return new Promise((resolve, reject) => {
    /**
     * 1.去重
     */
    lists = removeSameItem(lists);
    /**
     * 2.使用阈值分割请求
     *  1.获取sns的长度/阈值;向上取整;
     *  2.遍历这个数值,将接口批量发起请求;
     */
    const len = Math.ceil(lists.length / thresholdValue);
    const promises = [];
    for (let i = 0; i < len; i++) {
      promises.push(
        getImageUrl(
          lists.slice(i * thresholdValue, (i + 1) * thresholdValue).join(",")
        )
      );
    }
    /**
     * 3.数据格式化
     */
    Promise.all(promises).then((res) => {
      res.forEach((item) => {
        Object.keys(item).forEach((key) => {
          snToImageUrl[key] = item[key]?.url?.split('?Expires=')[0];
        });
      });
      resolve(true);
    });
  });
}

/**
 * @method formatterMessageFlowData
 * @desc 格式化信息流数据
 * @param data {MessageFlowResponse}
 * @return result MessageFlowResponse
 */
export function formatterMessageFlowData(
  data: MessageFlowResponse
): Promise<FormatterMessageFlowDataInterface> {
  return new Promise(async (resolve) => {
    // 等待请求详情的sn
    const typeSnMap: MessageFlowWaitRequestSnsMap = {
      goods: [],
      shop: [],
      article: [],
      society: [],
      activity: [],
      ticket: [],
    };
    // 待请求的图片ossId
    const images: MessageFlowWaitRequestImages = [];
    // sn对应具体的数据
    const dataMap: MessageFlowSnToItemData = {};
    // sn对应具体的图片
    const imageMap: MessageFlowSnToImages = {};
    // 递归批量处理数据
    recursionData(data?.data?.main, data?.data, typeSnMap, images);
    // 遍历获取每种类型的详情
    const details = Object.keys(
      typeSnMap
    ) as Array<KeyOfMessageFlowWaitRequestSnsMap>;
    // promise列表
    const promises = details.map((item) => {
      if (typeSnMap[item].length > 0) {
        return getMessageFlowDetail(item, typeSnMap[item], dataMap, images);
      }
      return Promise.resolve(false);
    });
    // 遍历详情
    await Promise.all(promises);
    await getOssIdUrl(images, imageMap);
    setTimeout(() => {
      resolve({
        messageFlow: data?.data?.main || [],
        imageMap,
        dataMap,
      });
    }, 0);
  });
}

/**
 * @method jsonStringToJson
 * @desc json字符串转json
 * @param {string} jsonString
 * @return {any}
 */
function jsonStringToJson(jsonString: string): unknown {
  let result = false;
  try {
    result = JSON.parse(jsonString);
  } catch (error) {
    console.log(error, jsonString);
  }
  return result;
}

/**
 * @method removeSameItem<T>
 * @desc 去重基础类型
 * @return {Array<T>}
 * @param lists
 */
function removeSameItem<T = string>(lists: Array<T>): Array<T> {
  return [...new Set(lists)];
}

/**
 * @method recursionData
 * @desc 递归数据
 */
function recursionData(
  lists: Array<MessageFlowContainer | MessageFlowItem> | undefined = [],
  allData:
    | StringKeyOfGenericity<(MessageFlowContainer | MessageFlowItem)[]>
    | undefined = {},
  result: MessageFlowWaitRequestSnsMap,
  imageSnS: Array<string>
) {
  if (lists.length === 0) {
    return;
  }
  lists.forEach((item) => {
    // item时,存入数据;
    if (item.type === "item") {
      const { name, biz, coverImages, data } = item;
      // 存储图片ossId
      if (coverImages && coverImages[0] && coverImages[0].ossId) {
        imageSnS.push(coverImages[0].ossId);
      }
      switch (name) {
        case "advert": // 广告图
          break;
        case "image_text1": // 图文类型1
          break;
        case "banner": // 轮播图
          if (data && Array.isArray(data.itemList)) {
            data.itemList.forEach((item) => {
              imageSnS.push(item.image);
            });
          }
          break;
        case "table": // 分类组tab
          // 分类组 因为分类组的数据在外层全量数据中, 为了方便递归取值, 前端将其装入child字段里面
          if (item.sn && allData[item.sn]) {
            item.child = allData[item.sn];
            recursionData(allData[item.sn], allData, result, imageSnS);
          }
          break;
        case "goods1": // 商品类型1
        case "goods2": // 商品类型2
          if (biz?.value) {
            result.goods.push(biz.value);
          }
          break;
        case "shop1": // 店铺类型1
        case "shop2": // 店铺类型2
          if (biz?.value) {
            result.shop.push(biz.value);
          }
          break;
        case "article1": // 文章类型1
          if (biz?.value) {
            result.article.push(biz.value);
          }
          break;
        case "activity1": // 活动类型1
        case "activity2": // 活动类型2
          if (biz?.value) {
            result.activity.push(biz.value);
          }
          break;
        case "ticket4": // 优惠券类型4 店铺优惠券
        case "ticket5": // 优惠券类型5 商品优惠券
          if (biz?.value) {
            result.ticket.push(biz.value);
          }
          break;
        case "society1":
          if (biz?.value) {
            result.society.push(biz.value);
          }
          break;
      }
    }
    // 容器有子集,选择递归
    if (
      item.type === "container" &&
      Array.isArray(item.child) &&
      item.child.length > 0
    ) {
      if (item.background && item.background.image) {
        imageSnS.push(item.background.image);
      }
      recursionData(item.child, allData, result, imageSnS);
    }
  });
}

export function debounce(fn: Function, delay = 200): Function {
  let timer: number | undefined
  return function Foo (this: typeof Foo) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      clearTimeout(timer)
      timer = undefined
    }, delay)
  }
}
