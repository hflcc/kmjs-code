import { inject } from "vue";

// 获取图片函数签名
type GetImageUrlFn = (sn: string) => string;
// 获取数据函数签名
type GetDataFn = <T>(sn: string) => T;

// 计算后的container样式map
interface ComputedContainerStyleMap {
  // 包括标题之类样式
  gridStyle: string;
  // 只包含items列表的盒子
  containerStyle: string;
  // 不同grid的样式
  differentGridStyle: string;
}
// 获取通过container数据计算出来的样式字符串
type GetContainerStyleMapFn = (
  data: MessageFlowContainer
) => ComputedContainerStyleMap;

// 获取容器样式函数签名
type GetContainerItemWrapStyle = (
  data: MessageFlowContainer,
  isLast: boolean
) => string;

// 获取item样式函数签名
type getItemStyleFn = (data: MessageFlowItem) => string;
// 获取行为函数签名
type CallActionFn = (sn: MessageFlowAction | undefined) => void;

export function useGetMethods() {
  // 获取图片地址
  const getImageUrl = inject<GetImageUrlFn>("getImageUrl", (sn: string) => "");
  // 获取 sn 对应的数据
  const getData = inject<GetDataFn>(
    "getData",
    <T>(sn: string) => sn as unknown as T
  );
  // 获取 container 容器样式字符串
  const getContainerStyleMapFn = inject<GetContainerStyleMapFn>(
    "getContainerStyleMap",
    (data: MessageFlowContainer) => ({
      gridStyle: "",
      containerStyle: "",
      differentGridStyle: "",
    })
  );
  // 获取 container 容器样式字符串
  const getContainerItemWrapStyle = inject<GetContainerItemWrapStyle>(
    "getContainerItemWrapStyle",
    (data: MessageFlowContainer, isLast: boolean) => ""
  );
  // 获取 container 容器样式字符串
  const getItemStyle = inject<getItemStyleFn>(
    "getItemStyle",
    (data: MessageFlowItem) => ""
  );
  // 获取 action 函数
  const callActionFn = inject<CallActionFn>(
    "callActionFn",
    (data: MessageFlowAction | undefined) => void 0
  );

  return {
    getImageUrl,
    getData,
    getContainerStyleMapFn,
    getContainerItemWrapStyle,
    getItemStyle,
    callActionFn,
  };
}
