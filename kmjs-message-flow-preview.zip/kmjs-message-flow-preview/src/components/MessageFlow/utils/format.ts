import dayjs from "dayjs";
import updateLocale from "dayjs/plugin/updateLocale";

// const Activity = (option: undefined, dayjsClass: any, dayjsFactory: any) => {
//   const oldFormat = dayjsClass.prototype.format;
//   dayjsClass.prototype.format = function (args: any) {
//     console.log(this);
//     return oldFormat.bind(this)("yyyy");
//   };
// };

// dayjs.extend(Activity);
dayjs.extend(updateLocale);
dayjs.updateLocale("en", {
  weekdays: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
});
export function formatTime(time: number, format = "YYYY-MM-DD HH:mm:ss") {
  return dayjs(new Date(time)).format(format);
}
