import "./utils/index.less";
import { defineComponent, provide, reactive, ref } from "vue";
import { formatterMessageFlowData, getOssIdUrl } from "./utils";
import RenderCore from "./RenderCore";
import { getBaseData } from "./utils/api";
import { useRoute } from "vue-router";

export default defineComponent({
  name: "PreviewIndex",
  setup() {
    const route = useRoute()
    const sn = route.query.infoFlowSn as string
    const ua = navigator.userAgent?.toLocaleLowerCase();
    const flowLeftPadding = ref(0); // 信息流左侧默认有left内边距padding
    const isMobile = ua.includes('iphone') || ua.includes('android');
    const messageFlow = reactive<Array<MessageFlowContainer | MessageFlowItem>>(
      []
    );
    // 信息流外层样式
    let msgFlowWrapStyle = ref('')
    // 数据map
    const dataMap = reactive<MessageFlowSnToItemData>({});
    // 图片map
    const imageMap = reactive<MessageFlowSnToImages>({});
    getBaseData(sn).then((res: MessageFlowResponse) => {
      // 这里先处理外层信息流属性样式设置
      getInfoFlowWrapStyle(res.property).then()
      formatterMessageFlowData(res).then((result) => {
        messageFlow.push(...result.messageFlow);
        Object.assign(dataMap, result.dataMap);
        Object.assign(imageMap, result.imageMap);
      });
    });

    // 获取图片地址
    function getImageUrl(sn: string) {
      return imageMap[sn] || '';
    }

    // 获取sn数据
    function getData(sn: string) {
      return dataMap[sn] || "";
    }

    const clientWidth = document.body.clientWidth;

    // 获取信息流最外层样式设置
    async function getInfoFlowWrapStyle(data: MessageFlowResponse['property'] | StringKeyOfGenericity<unknown>) {
      msgFlowWrapStyle.value = ''
      if (data?.padding) {
        const { top = 0, left = 0, right = 0, bottom = 0 } = data.padding as Record<'top' | 'left' | 'right' | 'bottom', number>
        flowLeftPadding.value = left;
        msgFlowWrapStyle.value += `padding: ${top}px ${right}px ${bottom}px ${left}px;`
      }
      if (data?.background) {
        const { image, color } = data.background as Record<'image' | 'color', string>
        if (image) {
          const imgObj = {} as MessageFlowSnToImages
          await getOssIdUrl([image], imgObj)
          msgFlowWrapStyle.value += `background: url(${imgObj[image]}) no-repeat;background-size: 100% 100%;`
        } else if (color) {
          msgFlowWrapStyle.value += `background: ${color}`
        }
      }
    }
    // 获取item的样式 注意样式后面添加;分号
    function getItemStyle(data: MessageFlowItem) {
      const { borderRadius, height, width } = data;
      let style = "";
      // 设置圆角
      if (typeof borderRadius === "number") {
        style += `border-radius: ${borderRadius}px;overflow: hidden;`;
      }
      // 给全部item组件设置高度
      if (typeof height === 'number') {
        style += `height: ${height}px;`
      }
      // 设置默认宽度,针对全屏写入
      if (
        data.name === "goods1" ||
        data.name === "shop1" ||
        data.name === "shop2" ||
        data.name === "article1" ||
        data.name === "activity2" ||
        data.name === "society1" ||
        data.name === "ticket5" ||
        data.name === "advert" ||
        data.name === "table"
      ) {
        // 这里给个初始屏幕宽度, 最终宽度由max-width: 100%决定
        style += `width: ${clientWidth}px;`;
      } else if (data.name === 'banner') {
        style += `max-width: 100%;`
      } else if (data.name === "image_text1") {
        style += `width: ${width || 70}px;`;
      } else if (data.name === "goods2" || data.name === "activity1") {
        style += `width: ${clientWidth / 2}px;`;
      } else if (data.name === "ticket4") {
        style += `width: 100px;`;
      }
      return style;
    }
    // 获取通过container数据计算出来的样式字符串;
    function getContainerStyleMap(data: MessageFlowContainer) {
      const { borderRadius, background, padding, gridPadding, name, margin } = data;
      let gridStyle = "",
        containerStyle = "",
        differentGridStyle = "";

      //#region 计算 gridStyle
      // 设置背景色
      if (background) {
        if (background.image) {
          containerStyle += `background: url("${getImageUrl(
            background.image
          )}");background-size: 100% 100%;`;
        } else if (background.color) {
          containerStyle += `background: ${background.color};`;
        }
      }
      // 设置margin
      if (margin) {
        const { top, right, bottom, left } = margin;
        containerStyle += `margin: ${top || 0}px ${right || 0}px ${
          bottom || 0
        }px ${left || 0}px;`;
      }
      // 设置padding
      if (padding) {
        const { top, right, bottom, left } = padding;
        containerStyle += `padding: ${top || 0}px ${right || 0}px ${
          bottom || 0
        }px ${left || 0}px;`;
      }
      // 设置圆角
      if (typeof borderRadius === "number") {
        containerStyle += `border-radius: ${borderRadius}px;overflow: hidden;`;
      }
      //#endregion

      //#region 计算 containerStyle
      if (gridPadding) {
        // let { col = 0, row = 0 } = gridPadding;
        // 为了方便用户操作,col,row互相切换
        const [col, row] = [gridPadding.row || 0, gridPadding.col || 0];
        gridStyle += `grid-column-gap: ${col}px;`;
        gridStyle += `grid-row-gap: ${row}px;`;
        switch (name) {
          case "grid_1_2":
          case "grid_2_2":
          case "shape_y":
            gridStyle += `grid-template-columns: repeat(2, calc(50% - ${
              col / 2
            }px));`;
            break;
          case "grid_1_3":
          case "grid_2_3":
          case "grid_3_3":
            gridStyle += `grid-template-columns: repeat(3, calc(33.33% - ${
              (col * 2) / 3
            }px));`;
            break;
          case "grid_1_4":
          case "grid_2_4":
          case "shape_l":
            gridStyle += `grid-template-columns: repeat(4, calc(25% - ${
              (col * 3) / 4
            }px));`;
            break;
          case "grid_1_5":
          case "grid_2_5":
            gridStyle += `grid-template-columns: repeat(5, calc(20% - ${
              (col * 4) / 5
            }px));`;
            break;
          default:
            break;
        }
      }
      //#endregion

      //#region 计算l型和y型 上面和下面的间隙
      if ((name === "shape_l" || name === "shape_y") && gridPadding) {
        differentGridStyle += `margin-bottom: ${gridPadding.row}px;`;
      }
      //#endregion

      return {
        gridStyle,
        containerStyle,
        differentGridStyle,
      };
    }

    // 获取item外部的样式
    function getContainerItemWrapStyle(
      data: MessageFlowContainer,
      isLast: boolean
    ) {
      const { gridPadding, name } = data;
      let styleStr = "";
      if (gridPadding) {
        switch (name) {
          case "grid_1_n":
            // 这里针对1_n子项item设置一个宽度70px, 后面可以考虑做到容器设置里面去
            styleStr += `margin-right: ${isLast ? 0 : gridPadding.row}px;`;
            break;
        }
      }
      return styleStr;
    }

    // 点击item触发
    function callActionFn(action: MessageFlowAction | undefined) {
      console.log(action);
    }

    provide("getImageUrl", getImageUrl);
    provide("getData", getData);
    provide("getContainerStyleMap", getContainerStyleMap);
    provide("getContainerItemWrapStyle", getContainerItemWrapStyle);
    provide("getItemStyle", getItemStyle);
    provide("callActionFn", callActionFn);
    provide("isMobile", isMobile)

    return () => (
      <div style={msgFlowWrapStyle.value} class="message_flow-wrap" id="messageFlowWrapElem">
        <div class="message_flow" id="messageFlowScrollElem">
          {messageFlow.map((item, index) => {
            return <div style="position: relative;">
              {!isMobile && <div class="mark-label" style={{ left: `-${flowLeftPadding.value}px` }}>
                <p class="text">#{index + 1}</p>
              </div>}
              <RenderCore data={item} />
            </div>;
          })}
        </div>
      </div>
    )
  }
});
