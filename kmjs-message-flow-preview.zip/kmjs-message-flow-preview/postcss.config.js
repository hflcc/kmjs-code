module.exports = {
  plugins: {
    autoprefixer: {
      overrideBrowserslist: [
        "Android 4.1",
        "iOS 7.1",
        "Chrome > 31",
        "ff > 31",
        "ie >= 8",
        "last 10 versions", // 所有主流浏览器最近10版本用
      ],
      grid: true,
    },
    "postcss-pxtorem": {
      // 把px单位换算成rem单位
      rootValue: 37.5,
      // 最小精度，小数点位数
      unitPrecision: 5,
      //   // !不匹配属性（这里是字体相关属性不转换）
      //   propList: ["*", "!font*"],
      // 替换的最小像素值
      minPixelValue: 2,
      // 要忽略并保留为px的文件路径
      exclude: /node_module/,
    },
  },
};
