import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import vueJsx from "@vitejs/plugin-vue-jsx";

// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    open: '/',
    proxy: {
      "^/dev": {
        target: "https://api-dev.kmyun.cn",
        changeOrigin: true,
        rewrite: (path) => path.replace("/dev", ""),
      },
    },
  },
  plugins: [vue(), vueJsx({})],
});
