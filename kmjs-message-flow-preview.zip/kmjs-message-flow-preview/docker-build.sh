docker rm -f $(docker ps -a | grep -w kmjs-message-flow-preview:v2 | awk '{print $1}')
docker rmi --force $(docker images | grep -w 172.18.88.211:7080/library/kmjs-message-flow-preview:v2 | awk '{print $3}')
docker pull 172.18.88.211:7080/library/kmjs-message-flow-preview:v2
docker run --name=kmjs-message-flow-preview -d -p 16008:16008 -v /etc/hosts:/etc/hosts 172.18.88.211:7080/library/kmjs-message-flow-preview:v2
