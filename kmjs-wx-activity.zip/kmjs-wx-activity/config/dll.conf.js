const { resolve, resolveSrc } = require('../build/utils')
// const path = require('path')

module.exports = {
  path: resolve('dll'),
  context: resolveSrc(),
  groups: {
    cacheGroups: [
      // {
      //   entries: path.resolve(__dirname, '../node_modules/@vant/weapp'),
      //   name: 'vant',
      //   entryOnly: true,
      //   format: true
      // },
      // {
      //   entries: resolve('node_modules/vue'),
      //   name: 'vue',
      //   entryOnly: true,
      //   format: true
      // }
    ],
    webpackCfg: {
      mode: 'none'
    }
  }
}
