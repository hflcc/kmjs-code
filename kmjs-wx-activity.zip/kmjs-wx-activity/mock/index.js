import mock from '@mpxjs/mock'

mock([
  {
    url: '/api/test/test',
    rule: {
      code: 200,
      data: {
        'list|1': [
          {
            'number|+1': 1, // 随机生成1-10中的任意整数
            'string|6': /[0-9a-f]/, // 值支持正则表达式,随机生成6位的16进制值
            'boolean|1': true // 随机生成一个布尔值,值为 true 的概率是 1/2
          }
        ]
      },
      msg: ''
    }
  }
])
