module.exports = {
  ctx: 'kmjs-wx-activity', // 注意: 此值不能随意更改, 不同项目ctx上下文不能重复
  filename: 'img'
}
