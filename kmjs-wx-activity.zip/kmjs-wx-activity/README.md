# mpx-base-template

> 微信小程序mpx基础项目模板

[mpx官方文档](https://mpxjs.cn/)

### 基础目录说明
```
├─build                // mpx webpack配置
├─config               // mpx 自定义webpack配置
├─mock
├─src
│  ├─api               // 后台接口
│  ├─components        // 项目公共组件
│  ├─img               // 项目公共图片 (鉴于微信包大小限制, 建议只存tabbar相关icon, 其余存资源服务器上)
│  ├─packages          // 分包页面
│  │  ├─packageA
│  │  │  └─pages
│  │  │      └─webview
│  │  └─packageB
│  │      └─pages
│  │          └─demoPage2
│  ├─pages             // 主包
│  │  ├─index          // 首页
│  │  ├─login          // 登录
│  │  ├─my             // 我的
│  │  └─organ          // 机构选择页
│  │      ├─create
│  │      └─select
│  ├─store             // 类似 vuex store
│  │  └─modules
│  ├─styles            // 公共样式/变量
│  └─utils             // 公共方法
│      └─modules
└─static               // 微信静态配置 (project.config.json)
│    └─wx
├─ app.mpx             // 小程序主入口
```

### Dev

```
# install dep
npm i

# for dev
npm run dev

# for online
npm run build
```

### 代码规范

#### 注释

```javascript

/**
 * 函数干啥的
 * @param 参数名 这个参数干啥的
 * @return 返回的东西是啥
 * */

```

#### css

* 格式为 `name-name2` 不使用驼峰
