// 票券
import { fetch } from '@/utils/request'
// 当前登录用户活动报名票券状态分组统计数量
export const ticketTotal = data => fetch('/act/activity/ticket/user/total', data, 'GET')
// 查询用户全部的活动报名票券列表
export const queryTicketAll = data => fetch('/act/activity/ticket/user/page', data, 'GET')
// 根据票券状态查询用户活动报名票券列表
export const queryTicketForState = data => fetch('/act/activity/ticket/user/page/{states}', data, 'GET')
// 根据票券sn查询用户活动报名票券详情
export const queryTicketDetail = data => fetch('/act/activity/ticket/user/{ticketSn}', data, 'GET')
// 根据票号查询用户活动报名票券详情（扫描票券二维码）
export const getTicketInfoByScanAPI = data => fetch('/act/activity/ticket/main/scan/{ticketNo}', data, 'PUT')
// 主办方根据活动报名票券sn操作活动报名票券（审核/验票）
export const checkTicketWithSnAPI = data => fetch('/act/activity/ticket/main/operate/{ticketSn}/{operateType}', data, 'PUT')
// 根据票券sn重新提交报名资料
export const reSubmitFormAPI = data => fetch('/act/activity/ticket/user/{ticketSn}', data, 'PUT')
