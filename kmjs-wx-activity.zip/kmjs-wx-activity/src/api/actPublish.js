import { fetch } from '@/utils/request'
/* 活动发布API集合 */

// 新增活动, 获取活动实例
export const getActivityInsAPI = data => fetch('/act/activity/instance', data, 'POST')
// 根据分类定义类型查询一级分类列表
export const getActClassifyAPI = data => fetch('/act/common/activity/category/list/first/{categoryType}', data, 'GET')
// 根据活动sn查询活动标签列表
export const getActTagListAPI = data => fetch('/act/activity/instance/tag/{activitySn}', data, 'GET')
// 根据标签分类和标签适用范围分页查询标签列表
export const getUsualTagListAPI = data => fetch('/md/inst/tag/page/{category}/{scope}', data, 'GET')
// 根据活动sn新增活动标签
export const addActTagAPI = data => fetch('/act/activity/instance/tag/{activitySn}', data, 'POST')
// 新增活动标签
export const addListTagAPI = data => fetch('/md/inst/tag/{category}/{scope}', data, 'POST')
// 根据活动标签sn删除活动标签
export const delActTagAPI = data => fetch('/act/activity/instance/tag/{activityTagSn}', data, 'DELETE')
// 根据我的标签sn删除我的标签
export const delMyActTagAPI = data => fetch('/md/inst/tag/{tagSns}', data, 'DELETE')
// 根据活动sn查询活动图片列表
export const getActPhotoListAPI = data => fetch('/act/activity/instance/image/{activitySn}', data, 'GET')
// 根据活动sn新增活动图片
export const addActPhotoAPI = data => fetch('/act/activity/instance/image/{activitySn}', data, 'POST')
// 根据活动图片sn删除活动图片
export const delActPhotoAPI = data => fetch('/act/activity/instance/image/{activityImageSn}', data, 'DELETE')
// 根据活动sn查询表单详情
export const getActFormDetailAPI = data => fetch('/act/activity/instance/{activitySn}', data, 'GET')
// 根据活动sn查询活动详情内容
export const getActContentAPI = data => fetch('/act/activity/instance/content/{activitySn}', data, 'GET')
// 根据活动sn新增活动内容
export const addActContentAPI = data => fetch('/act/activity/instance/content/{activitySn}', data, 'POST')
// 根据活动sn新增活动内容
export const fixActContentAPI = data => fetch('/act/activity/instance/content/{activityContentSn}', data, 'PUT')
// 根据活动sn修改活动
export const fixActFormWithSnAPI = data => fetch('/act/activity/instance/{activitySn}', data, 'PUT')
// 根据活动sn新增活动站点
export const addActStationAPI = data => fetch('/act/activity/instance/site/{activitySn}', data, 'POST')
// 根据活动站点sn查询活动站点详情
export const getActStationInfoAPI = data => fetch('/act/activity/instance/site/{activitySiteSn}', data, 'GET')
// 根据活动sn查询活动站点列表
export const getActStationListAPI = data => fetch('/act/activity/instance/site/list/{activitySn}', data, 'GET')
// 根据活动站点sn修改活动站点
export const fixActStationAPI = data => fetch('/act/activity/instance/site/{activitySiteSn}', data, 'PUT')
// 根据活动站点sn删除活动站点
export const delActStationAPI = data => fetch('/act/activity/instance/site/{activitySiteSn}', data, 'DELETE')
// 根据活动站点sn查询活动票券列表
export const getActTicketListAPI = data => fetch('/act/activity/instance/ticket/list/site/{activitySiteSn}', data, 'GET')
// 根据活动票券sn删除活动票券
export const delActTicketAPI = data => fetch('/act/activity/instance/ticket/{activityTicketSn}', data, 'DELETE')
// 主办方根据活动sn操作活动（提审/下架）
export const submitActivityAPI = data => fetch('/act/activity/instance/operate/{activitySn}/{operateType}', data, 'PUT')
// 根据活动sn查询活动报名表单定义
export const getPublishFormAPI = data => fetch('/act/activity/instance/form/{activitySn}', data, 'GET')
// 根据活动sn新增活动报名表单定义
export const addPublishFormAPI = data => fetch('/act/activity/instance/form/{activitySn}', data, 'POST')
// 根据表单定义sn查询表单定义详情
export const getFormDefineInfoAPI = data => fetch('/md/form/def/{formDefSn}', data, 'GET')
// 新增表单定义
export const addFormDefineAPI = data => fetch('/md/form/def', data, 'POST')
// 根据表单定义步骤sn新增表单定义步骤子项
export const addFormDefineChildAPI = data => fetch('/md/form/def/step/item/{stepSn}', data, 'POST')
// 根据表单定义步骤子项sn删除
export const delFormDefineChildAPI = data => fetch('/md/form/def/step/item/{stepItemSn}', data, 'DELETE')
// 根据分类和适用范围分页查询表单步骤通用子项列表
export const getFormTempListAPI = data => fetch('/md/form/def/step/common/item/page/{category}/{scope}', data, 'GET')
// 根据表单定义步骤子项sn修改
export const fixFormDefineChildAPI = data => fetch('/md/form/def/step/item/{stepItemSn}', data, 'PUT')
