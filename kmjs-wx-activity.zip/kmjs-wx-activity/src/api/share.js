import { fetch } from '@/utils/request'
// 新增邀请码实例
// 邀请报名人： e72f1dc26db6467da1e069997081ef9c
// 活动分享：7946d2f92a384b0e89d99902a3865ad9
// export const addInvite = data => fetch('/mk/invite/code/{inviteDefSn}', data, 'POST')
// 生成邀请码--获取二维码的ossid
// export const inviteCode = data => fetch('/mk/invite/code/qr/data/{inviteCode}', data, 'POST')
// 根据订单明细sn查询报名分享信息
export const getShareInfo = data => fetch('/act/activity/order/share/info/{orderItemSn}', data, 'GET')
// 新增邀请实例
// export const addShareInsAPI = data => fetch('/mk/invite/code/generate/{inviteDefSn}', data, 'POST')
// 生成邀请实例
export const addShareInsAPI = data => fetch('/act/activity/order/share/{orderItemSn}/{inviteDefSn}', data, 'POST')
// 判断邀请实例是否可用
export const checkShare = data => fetch('/mk/invite/instance/check/{instanceSn}', data, 'GET')
