// 主页
import { fetch } from '@/utils/request'
// 信息流分类
export const infoFlowCategory = data => fetch('/md/common/info/flow/platform/list/category/{type}', data, 'GET')
// 信息流实例数据(分页)
export const infoFlowData = data => fetch('/md/common/info/flow/instance/page/def_category_sn/{sn}', data, 'GET')
// 根据类型搜索
export const searchForType = data => fetch('/si/common/search/{searchType}', data, 'GET')
// 搜索内容
export const searchContent = data => fetch('/si/common/search/', data, 'GET')
// 文章详情
export const getArticle = data => fetch('/md/common/article/{sn}', data, 'GET')
