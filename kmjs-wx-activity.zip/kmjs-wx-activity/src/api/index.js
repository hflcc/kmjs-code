import { fetch } from '@/utils/request'
import { INST_TYPE } from '@/utils/modules/constant'

// 登录获取token
export const loginToken = data => fetch('/oauth2/oauth/token', data, 'GET')

// 刷新token
export const refreshLoginToken = data => fetch(`/oauth2/oauth/token?grant_type=refresh_token&refresh_token=${data.refresh_token}`, data, 'POST')

// 完善用户信息
export const wxIntegrity = data => fetch('/sys/user/wx/integrity', data, 'PUT')
// 修改用户信息
export const updateUserInfo = data => fetch('/sys/user', data, 'PUT')
// 获取身份 society(协会) platform(平台) shop(商会) ml(美罗) activity(活动)
export const listOrgan = data => fetch('/md/inst/list/' + INST_TYPE, data, 'GET')
// 注册机构
export const registerOrgan = data => fetch('/md/inst/register', data)
// 取号 取号规则sn：INST_RANDOM_NO机构随机名称
export const incrementOrgan = data => fetch('/sys/increment/{sn}', data)

// 获取用户信息
export const getUserInfo = data => fetch('/sys/user/current/check/integrity', data, 'GET')

// 获取app相关信息
export const getAppInfo = data => fetch('/sys/common/app/info/list', data, 'GET')

// 获取协议详情
export const getAppInfoDetail = data => fetch('/sys/common/app/info/{sn}', data, 'GET')

// 查询用户关注的主办方分页列表
export const getFollowMain = data => fetch('/act/activity/user/page/follow/main', data, 'GET')

// 获取图片
export const getOssImg = data => fetch('/oss/common/list/oss/seqs', data, 'GET')

// 根据主办方sn查询活动分页列表
export const getMainPage = data => fetch('/act/common/activity/instance/page/main/{mainSn}', data, 'GET')

// 根据主办方sn查询主办方主页信息
export const getMainInfo = data => fetch('/act/common/activity/main/{mainSn}', data, 'GET')

// 根据当前登录机构查询主办方信息
export const getMyMain = data => fetch('/act/activity/main/', data, 'GET')

// 查询主办方粉丝列表
export const getFansList = data => fetch('/act/activity/main/page/fans', data, 'GET')

// 查询用户关注的主办方数量
export const getFollowMainNum = data => fetch('/act/activity/user/total/follow/main', data, 'GET')

// 根据当前登录机构创建主办方信息
export const createMain = data => fetch('/act/activity/main/', data, 'POST')
// 根据主办方sn修改当前登录机构主办方信息
export const updateMain = data => fetch('/act/activity/main/{mainSn}', data, 'PUT')
// 更新主办方的背景图片
export const updateMainBg = data => fetch('/act/activity/main/background/{mainSn}', data, 'PUT')
// 根据活动报名票券状态集合统计主办方活动报名票券数量
export const totalTicketStates = data => fetch('/act/activity/ticket/main/total/{ticketStates}', data, 'GET')
// 通过scene查询具体参数
export const getShareParamsAPI = data => fetch('/sys/common/params/{sn}', data, 'GET')
// 查询活动报名详情
export const getShareDetailAPI = data => fetch('/act/activity/ticket/user/join/{orderItemSn}', data, 'GET')
// 通过分享报名
export const addMemberByShareAPI = data => fetch('/act/activity/ticket/user/join/{orderItemSn}', data, 'POST')
// 查询搜索默认词
// export const getSearchHotWord = data => fetch('/md/common/search/hotword/page', data, 'GET')
export const getSearchHotWord = data => fetch('/si/common/search/hotword/page/{type}', data, 'GET')
// 平台根据活动sn集合批量操作活动（审核/下架）
export const auditActivity = data => fetch('/act/platform/activity/instance/operate/{activitySn}/{operateType}', data, 'PUT')
// 查询当前用户创建的活动总收入
export const getTotalIncome = data => fetch('/act/activity/instance/user/total/income', data, 'GET')
// 根据支付实例sn查询支付方式
export const payType = data => fetch('/pay/{payInstanceSn}/{payState}', data, 'GET')
// 根据支付实例sn查询支付方式
export const pay = data => fetch('/pay/unified/{payInstanceSn}/{payDefItemSn}', data, 'POST')
