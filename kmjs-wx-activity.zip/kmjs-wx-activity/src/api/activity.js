// 活动
import { fetch } from '@/utils/request'
import { INST_TYPE } from '@/utils'
import { userStore } from '@/store'

// 活动分类
export const activityType = data => fetch('/act/common/activity/category/list/first/' + INST_TYPE, data, 'GET')
// 查询全部活动分页列表
export const activityList = data => fetch('/act/common/activity/instance/page', data, 'GET')
// 根据分类sn查询活动分页列表
export const activityListForSn = data => fetch('/act/common/activity/instance/page/{categorySn}', data, 'GET')
// 根据活动sn新增活动浏览记录。未登录已登录接口分开的
export const addBrowse = data => fetch(!userStore.state.token ? '/act/common/activity/instance/browse/{activitySn}' : '/act/activity/instance/browse/{activitySn}', data, 'POST')
// 根据主体类型和主体sn新增机构用户收藏记录
export const addFollow = data => fetch('/md/inst/user/follow/{actionType}/{actionSn}', data, 'POST')
// 根据主体类型和主体sn取消机构用户收藏记录
export const cancelFollow = data => fetch('/md/inst/user/follow/cancel/{actionType}/{actionSn}', data, 'DELETE')
// 根据主体类型和主体sn校验机构用户是否收藏
export const validFollow = data => fetch('/md/inst/user/follow/valid/{actionType}/{actionSn}', data, 'GET')
// 查询用户收藏的活动分页列表
export const collectList = data => fetch('/act/activity/user/page/follow/activity', data, 'GET')
// 查询用户关注主办方发布的活动分页列表
export const followList = data => fetch('/act/activity/user/page/follow/main/activity', data, 'GET')
// 查询用户活动浏览记录
export const browseList = data => fetch('/act/activity/user/page/activity/browse', data, 'GET')
// 根据活动浏览记录sn删除活动浏览记录
export const deleteBrowseForSn = data => fetch('/act/activity/instance/browse/{browseSn}', data, 'DELETE')
// 删除当前登录用户所有活动浏览记录
export const deleteBrowseAll = data => fetch('/act/activity/instance/browse/current/all', data, 'DELETE')
// 待参加
export const waitJoin = data => fetch('/act/activity/ticket/user/wait', data, 'GET')
// 根据活动sn查询活动详情
export const activityDetail = data => fetch('/act/common/activity/instance/{activitySn}', data, 'GET')
// 根据活动sn预览活动
export const activityPreview = data => fetch('/act/activity/instance/preview/{activitySn}', data, 'GET')
// 根据活动站点sn查询活动票券列表
export const ticketList = data => fetch('/act/activity/instance/user/list/site/{activitySiteSn}', data, 'GET')
// 查询主办方全部活动分页列表
export const activityMainList = data => fetch('/act/activity/instance/page', data, 'GET')
// 根据活动展示状态查询主办方活动分页列表
export const activityMainListForState = data => fetch('/act/activity/instance/page/{activityShowState}', data, 'GET')
// 查询主办方所有待审核活动报名票券成员分页列表
export const waitAudit = data => fetch('/act/activity/ticket/main/page/waitAudit', data, 'GET')
// 根据活动sn查询活动站点列表
export const siteList = data => fetch('/act/activity/instance/site/list/{activitySn}', data, 'GET')
// 根据活动站点sn查询活动票券列表
export const ticketListForSite = data => fetch('/act/activity/instance/ticket/list/site/{activitySiteSn}', data, 'GET')
// 根据活动sn查询全部的活动报名票券分页列表
export const applyList = data => fetch('/act/activity/ticket/main/page/{activitySn}', data, 'GET')
// 根据活动sn、活动报名票券状态集合查询活动报名票券成员分页列表
export const applyListForStates = data => fetch('/act/activity/ticket/main/page/{activitySn}/{ticketStates}', data, 'GET')
// 主办方根据活动报名票券sn操作活动报名票券（审核/验票）
export const auditOrCheckTicket = data => fetch('/act/activity/ticket/main/operate/{ticketSn}/{operateType}', data, 'PUT')
// 根据活动sn查询主办方活动概览
export const summaryActivity = data => fetch('/act/activity/instance/summary/{activitySn}', data, 'GET')
// 主办方根据活动sn操作活动（提审/下架）
export const operateActivity = data => fetch('/act/activity/instance/operate/{activitySn}/{operateType}', data, 'PUT')
// 根据活动sn删除活动
export const deleteActFormWithSnAPI = data => fetch('/act/activity/instance/{activitySn}', data, 'DELETE')
// 根据活动sn查询活动票券列表（我的活动-票券管理）
export const ticketActivityList = data => fetch('/act/activity/instance/ticket/list/activity/{activitySn}', data, 'GET')
// 根据活动票券sn操作活动票券（暂停购票/开启购票）
export const operateTicket = data => fetch('/act/activity/instance/ticket/operate/{ticketSn}/{operateType}', data, 'PUT')
// 根据票券sn查询用户活动报名票券详情
export const ticketDetail = data => fetch('/act/activity/ticket/user/{ticketSn}', data, 'GET')
// 根据活动票券sn查询活动票券详情
export const ticketEditDetail = data => fetch('/act/activity/instance/ticket/{activityTicketSn}', data, 'GET')
// 根据活动站点sn新增活动票券
export const ticketAddDetail = data => fetch('/act/activity/instance/ticket/{activitySiteSn}', data, 'POST')
// 根据活动票券sn修改活动票券
export const ticketUpdateDetail = data => fetch('/act/activity/instance/ticket/{activityTicketSn}', data, 'PUT')
// 根据活动sn统计活动报名
export const summaryCount = data => fetch('/act/activity/ticket/main/summary/{activitySn}', data, 'GET')
// 根据活动站点sn查询活动站点详情
export const siteDetail = data => fetch('/act/activity/instance/site/{activitySiteSn}', data, 'GET')
// 根据区域sn返回区域数据
export const getAreaApi = data => fetch('/md/common/area/def/item/{areaSn}', data, 'GET')
// 根据省市区定位区域sn
export const createAreaSnAPI = data => fetch('/md/area/def/item/location', data, 'GET')

// 根据活动sn查询活动管理员分页列表
export const getManager = data => fetch('/act/activity/instance/manager/page/{activitySn}', data, 'GET')
// 查询当前机构用户分页列表
export const getCurrent = data => fetch('/md/inst/user/select/list/current', data, 'GET')
// 根据活动sn和机构用户sn集合查询
export const getManagerList = data => fetch('/act/activity/instance/manager/list/{activitySn}/{instUserSns}', data, 'GET')
// 根据活动sn新增活动管理员
export const addManagerList = data => fetch('/act/activity/instance/manager/{activitySn}', data, 'POST')
// 根据活动管理员sn删除活动管理员
export const deleteManager = data => fetch('/act/activity/instance/manager/{activityManagerSn}', data, 'DELETE')
