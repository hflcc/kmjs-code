// 订单
import { fetch } from '@/utils/request'
// 活动订单状态分组统计数量
export const orderTotal = data => fetch('/act/activity/order/total', data, 'GET')
// 查询用户全部的活动订单分页列表 act/activity/createOrder/page
export const queryOrderAll = data => fetch('/act/activity/order/page', data, 'GET')
// 根据订单展示状态查询用户活动订单分页列表 订单展示状态 wait待付款, ing进行中, complete已完成, cancel已取消
export const queryOrderForState = data => fetch('/act/activity/order/page/{showState}', data, 'GET')
// 根据订单sn查询用户活动订单详情
export const getOrderDetailAPI = data => fetch('/act/activity/order/{orderSn}', data, 'GET')
// 根据订单sn取消活动订单
export const cancelOrderAPI = data => fetch('/act/activity/order/cancel/{orderSn}', data, 'PUT')
// 根据订单明细sn统计活动报名票券成员
export const getMemberTotalAPI = data => fetch('/act/activity/ticket/order/summary/{orderItemSn}', data, 'GET')
// 根据订单明细sn查询活动报名票券成员分页列表
export const getAllMemberListAPI = data => fetch('/act/activity/ticket/order/page/{orderItemSn}', data, 'GET')
// 根据订单明细sn和活动报名票券状态集合查询活动报名票券成员分页列表
export const getPartMemberListAPI = data => fetch('/act/activity/ticket/order/page/{orderItemSn}/{ticketStates}', data, 'GET')
// 根据订单明细sn和活动报名票券sn集和取消活动报名名额
export const deleteMemberAPI = data => fetch('/act/activity/ticket/order/{orderItemSn}/{ticketSns}', data, 'DELETE')
// 根据表单实例sn获取表单与步骤实例
export const getFormDetailAPI = data => fetch('/md/form/instance/sn/{sn}', data, 'GET')
// 创建空表单实例和步骤（返回表单实例sn）
export const createFormInsAPI = data => fetch('/md/form/instance/add/{bizMdFormDefSn}', data, 'POST')
// 根据表单实例步骤sn提交表单
export const saveFormInsAPI = data => fetch('/md/form/instance/step/save/{stepOneSn}', data, 'POST')
// 根据订单明细sn手动添加报名人
export const addMemberWithInsAPI = data => fetch('/act/activity/ticket/order/{orderItemSn}', data, 'POST')
// 根据活动sn创建订单
export const createOrder = data => fetch('/act/activity/order/{activitySn}', data, 'POST')
// 根据订单sn确认订单
export const confirmOrder = data => fetch('/act/activity/order/confirm/{orderSn}', data, 'PUT')
// 根据订单sn提交订单
export const submitOrder = data => fetch('/act/activity/order/submit/{orderSn}/{payDefSn}', data, 'PUT')
// 根据订单sn查询活动订单支付结果
export const payResult = data => fetch('/act/activity/order/pay/result/{orderSn}', data, 'GET')
// 根据订单明细sn查询活动报名表单信息
export const getFormInfoAPI = data => fetch('/act/activity/ticket/order/form/info/{orderItemSn}', data, 'GET')
