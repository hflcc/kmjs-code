import { cancelOrderAPI, getFormInfoAPI, submitOrder } from '@/api/order'
import { PAY_DEF_SN } from '@/utils'
export default {
  methods: {
    /*
    * @info 添加报名人（跳转添加报名人页）
    * */
    async goAddMemberPage (formDefSn, ticketSn) {
      const res = await getFormInfoAPI({ orderItemSn: ticketSn })
      if (res.surplus > 0) {
        wx.navigateTo({
          url: `/packageA/pages/myOrder/pages/addMember?formDefSn=${formDefSn}&orderItemSn=${ticketSn}`
        })
      } else {
        wx._showToast('您购买的票券报名成员已满')
      }
    },
    /*
    * @info 取消订单
    * */
    cancelOrder (orderSn) {
      wx._showModal({
        content: '确认取消订单吗？',
        success: async (res) => {
          if (res.confirm) {
            const result = await cancelOrderAPI({ orderSn })
            if (result.success) {
              wx._showToast(result.message)
              this.cancelOrderSuccess()
            }
          }
        }
      })
    },
    /*
    * @info 跳转支付页面
    * */
    async goPay (orderSn) {
      // wx._showToast('支付页面未开发')
      // wx.navigateTo({
      //   url: ''
      // })
      // 去支付
      // 提交订单
      await wx.showLoading({
        title: '加载中',
        mask: true
      })
      // let res = await confirmOrder({ orderSn: sn })
      // if (res.success) {
      let res = await submitOrder({ orderSn, payDefSn: PAY_DEF_SN })
      if (res.success) {
        // 有paysn 跳支付中转页
        if (res.paySn) {
          await wx.navigateTo({
            url: `/packageB/pages/pay/index?paySn=${res.paySn}&sn=${res.sn}`
          })
        }
      }
      // }
      await wx.hideLoading()
    },
    /*
    * @info 跳转主办方主页
    * */
    goSponsorPage (mainSn) {
      wx.navigateTo({
        url: `/packageA/pages/sponsorHome/index/index?sn=${mainSn}`
      })
    }
  }
}
