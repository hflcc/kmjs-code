import { getContainerStyleMap } from '../utils/styleFormat'

export default {
  properties: {
    datas: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    contStyleMap () {
      return getContainerStyleMap(this.datas)
    }
  }
}
