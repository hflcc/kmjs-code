import ajax from '../utils/ajax'

export const getBaseDataAPI = sn => ajax.get(`/info/common/flow/instance/detail/${sn}`)
