import { getItemStyle } from '../utils/styleFormat'
import { getActualBizData, getActualImageUrl } from '../utils'

export default {
  properties: {
    datas: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    itemStyle () {
      return getItemStyle(this.datas)
    },
    imageUrl () {
      const ossId = (this.datas?.coverImages && this.datas.coverImages[0]?.ossId) || ''
      return getActualImageUrl(ossId)
    },
    result () {
      const bizId = this.datas?.biz?.value || ''
      return getActualBizData(bizId)?.data || {}
    }
  }
}
