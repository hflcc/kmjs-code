const ENV = wx.getAccountInfoSync().miniProgram.envVersion
let BASE_URL = ''
switch (ENV) {
  case 'develop':
    BASE_URL = 'https://api-dev.kmyun.cn'
    break
  case 'trial':
    BASE_URL = 'https://api-dev.kmyun.cn'
    break
  case 'release':
    BASE_URL = 'https://api.kmyun.cn'
    break
  default:
    break
}

const showToast = text => {
  return wx.showToast({
    title: text,
    icon: 'none',
    duration: 3000
  })
}

class Request {
  constructor (opts = {}) {
    this.$options = opts
  }
  send (url = '', req = {}) {
    return new Promise((resolve, reject) => {
      wx.request(Object.assign(
        this.$options,
        {
          url: `${BASE_URL}${url}`,
          data: req,
          success: (res) => {
            if (Object.prototype.toString.call(res) === '[object Object]') {
              const { statusCode, data } = res
              if (statusCode === 200) {
                resolve(data)
              } else {
                if (typeof data === 'object') {
                  showToast(data?.message || '服务器出错了').then()
                } else {
                  showToast('服务器出错了').then()
                }
                resolve({})
              }
            }
          },
          fail: (err) => {
            reject(err)
          }
        }
      ))
    })
  }
  get (url, req) {
    this.$options.method = 'GET'
    return this.send(url, req)
  }
  post (url, req) {
    this.$options.method = 'POST'
    return this.send(url, req)
  }
}

const options = {
  url: '',
  data: '',
  header: {},
  timeout: 5 * 1000,
  method: '',
  responseType: 'text',
  dataType: 'json'
}
module.exports = new Request(options)
