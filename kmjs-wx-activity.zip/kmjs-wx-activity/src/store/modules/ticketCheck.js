import { getTicketInfoByScanAPI } from '@/api/ticket'

export default {
  state: {
    ticketCodeByScan: '', // 通过扫码获取的票券码， 由scanTicket页面调用赋值
    ticketInfo: {}, // 票券详情
    ticketDetail: {} // 审核列表到详情传参 (注意此字段不是票券详情)
  },
  mutations: {
    setTicketInfo (state, data = {}) {
      state.ticketInfo = data
    },
    setTicketCodeByScan (state, code = '') {
      state.ticketCodeByScan = code
    },
    setTicketDetail (state, data = {}) {
      state.ticketDetail = data
    }
  },
  actions: {
    async getTicketInfo ({ commit }, num) {
      let reg = /^\d{12}$/
      if (!reg.test(num)) {
        wx._showToast('请扫码正确的票券二维码')
        return
      }
      wx.showLoading({
        title: '请求中',
        mask: true
      })
      const res = await getTicketInfoByScanAPI({ ticketNo: num })
      if (res) {
        wx.hideLoading()
        commit('setTicketInfo', res)
        wx.navigateTo({
          url: '/packageB/pages/ticketCheck/ticketDetail'
        })
      }
    }
  }
}
