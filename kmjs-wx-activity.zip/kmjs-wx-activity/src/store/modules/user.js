import { APP_INFO, REFRESHTOKEN, REFRESHTOKENTIME, TOKEN, USER_INFO } from '/src/utils/modules/constant'
import { getAppInfo, getAppInfoDetail, getSearchHotWord, refreshLoginToken, listOrgan } from '@/api'

const { setStorageSync, getStorageSync, removeStorageSync } = wx
const getDefaultState = () => {
  return {
    token: getStorageSync(TOKEN),
    userInfo: getStorageSync(USER_INFO) || {},
    appInfo: getStorageSync(APP_INFO),
    hotWord: '' // 搜索默认词
  }
}
const state = {
  ...getDefaultState()
}
const mutations = {
  setToken: (state, data) => {
    state.token = data.access_token
    setStorageSync(TOKEN, data.access_token)
    setStorageSync(REFRESHTOKEN, data.refresh_token)
    setStorageSync(REFRESHTOKENTIME, new Date().getTime() + 25 * 24 * 60 * 60 * 1000)
  },
  logout: state => {
    state.token = ''
    removeStorageSync(TOKEN)
    removeStorageSync(REFRESHTOKEN)
    removeStorageSync(REFRESHTOKENTIME)
    let instId = state.userInfo.instId
    removeStorageSync(USER_INFO)
    setStorageSync(USER_INFO, {
      instId
    })
    // removeStorageSync(INST_ID)
  },
  setUserInfo: (state, data) => {
    let userInfo = Object.assign(state.userInfo, data)
    state.userInfo = userInfo
    setStorageSync(USER_INFO, userInfo)
    // setStorageSync(INST_ID, userInfo.instId)
  },
  setAppInfo: (state, data) => {
    state.appInfo = data
    setStorageSync(APP_INFO, data)
  },
  setHotWord: (state, data) => {
    state.hotWord = data
  }
}
const actions = {
  getWxLogin ({ commit }) {
    return new Promise((resolve, reject) => {
      wx.login({
        success (res) {
          const { code } = res || {}
          if (code) {
            resolve(code)
          } else {
            resolve('登录失败！' + res.errMsg)
          }
        },
        fail (res) {
          reject(res)
        }
      })
    })
  },
  refreshToken ({ commit, dispatch }) {
    console.log(commit, 'commit')
    const refreshToken = getStorageSync(REFRESHTOKEN)
    const refreshTokenTime = getStorageSync(REFRESHTOKENTIME)

    if (refreshTokenTime && refreshToken) {
      if (new Date().getTime() > refreshTokenTime) {
        refreshLoginToken({
          'refresh_token': refreshToken
        }).then(res => {
          commit('setToken', res)
        })
      }
    }
  },
  getMiniAppInfo ({ commit }) {
    getAppInfo().then(res => {
      commit('setAppInfo', res)
    })
  },
  getMiniAppInfoDetail ({ state }, type) {
    const o = state.appInfo.find(item => item.detailType === type)
    if (o) {
      return new Promise((resolve, reject) => {
        getAppInfoDetail({ sn: o.sn }).then(res => {
          resolve(res)
        }).catch(err => {
          console.error(err)
        })
      })
    }
    return null
  },
  getOrganName ({ state, commit }) {
    listOrgan({}).then(res => {
      let idx = res.findIndex(item => item.id === state.userInfo.instId)
      if (idx !== -1) {
        let name = res[idx].name
        commit('setUserInfo', { organName: name })
      } else {
        let instId = res[0].id
        let name = res[0].name
        commit('setUserInfo', { instId: instId })
        commit('setUserInfo', { organName: name })
      }
    })
  },
  getHotWord ({ state, commit }) {
    return new Promise((resolve, reject) => {
      if (state.hotWord) {
        resolve(state.hotWord)
      } else {
        getSearchHotWord({ type: 'act' }).then(res => {
          if (res && res.content && res.content.length > 0) {
            const name = res.content[0].name
            commit('setHotWord', name)
            resolve(name)
          } else {
            resolve('请输入活动或主办方名称')
          }
        }).catch(_ => {
          resolve('请输入活动或主办方名称')
        })
      }
    })
  }
}

export default {
  state,
  mutations,
  actions
}
