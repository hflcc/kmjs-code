const state = {
  orderListRefresh: false // 订单列表是否需要刷新
}
const mutations = {
  setListRefresh (state, val = false) {
    state.orderListRefresh = val
  }
}
const actions = {
}

export default {
  state,
  actions,
  mutations
}
