import { getActivityInsAPI, fixActFormWithSnAPI } from '@/api/actPublish'

const state = {
  beforeEnterPubIndexUrl: '', // 记住是哪个页面跳转进来活动发布的, 在发布成功后手势左滑或者点击关闭跳转回原进来页面
  activitySn: '', // 根据活动标题/时间/活动分类生成的活动sn
  form: {
    photoList: [],
    title: '', // 活动标题
    time: {
      start: '', // 开始时间戳
      end: '' // 结束时间戳
    }, // 时间
    classify: {}, // 活动分类
    tag: [], // 活动标签
    hasDetail: false, // 活动详情
    isOpen: false, // 活动是否公开, 默认不公开
    formDefSn: '', // 报名人表单sn
    formList: '', // 报名人表单列表
    stationSn: '', // 活动站点
    siteNames: '' // 活动名称
  }
}
const mutations = {
  initState (state) {
    state.activitySn = ''
    state.beforeEnterPubIndexUrl = ''
    state.form = {
      photoList: [],
      title: '',
      time: {
        start: '',
        end: ''
      },
      classify: {},
      tag: [],
      hasDetail: false,
      isOpen: false,
      formDefSn: '',
      formList: '',
      stationSn: ''
    }
  },
  setEnterUrl (state, val = '') {
    state.beforeEnterPubIndexUrl = val
  },
  // 设置活动详情内容
  setActDetail (state, val = '') {
    state.form.hasDetail = !!val
  },
  // 设置报名人表单formDefSn
  setActFormDefSn (state, val = '') {
    state.form.formDefSn = val
  },
  // 设置报名人表单formList
  setActFormList (state, val = '') {
    state.form.formList = val
  },
  // 设置活动标题
  setFormTitle (state, val = '') {
    state.form.title = val
  },
  // 设置活动sn
  setActSn (state, val = '') {
    state.activitySn = val
  },
  // 设置活动时间
  setFormTime (state, { start, end }) {
    state.form.time = {
      start,
      end
    }
  },
  // 设置活动标签
  setFormTag (state, val = []) {
    state.form.tag = val
  },
  // 设置活动分类
  setFormClassify (state, val = {}) {
    state.form.classify = val
  },
  // 设置活动照片
  setFormPhotoList (state, val = []) {
    state.form.photoList = val
  },
  // 删除具体活动照片
  delFormPhotoItem (state, i) {
    state.form.photoList.splice(i, 1)
  },
  // 设置活动公开/私密
  setFormOpenStatus (state, val) {
    state.form.isOpen = val
  },
  // 活动站点
  setFormStationSn (state, val) {
    state.form.stationSn = val
  },
  // 活动站点
  setFormSiteNames (state, val) {
    state.form.siteNames = val
  }
}
const actions = {
  /*
  * @info 根据活动标题/时间/活动分类获取活动Sn
  * */
  async getActivityIns ({ commit, state }) {
    const { title, time, classify } = state.form
    const req = {
      title,
      startAt: parseInt(new Date(time.start).getTime() / 1000),
      endAt: parseInt(new Date(time.end).getTime() / 1000),
      categorySn: classify.sn
    }
    const { sn } = await getActivityInsAPI(req)
    commit('setActSn', sn)
  },
  /*
  * @info 根据活动sn修改活动必要信息 (标题/时间/活动分类)
  * */
  async modifyFormAct ({ state }) {
    const {
      title,
      time,
      classify,
      isOpen
    } = state.form
    const { sn } = classify
    const req = {
      activitySn: state.activitySn,
      title,
      startAt: parseInt(new Date(time.start).getTime() / 1000),
      endAt: parseInt(new Date(time.end).getTime() / 1000),
      isOpen, // 活动是否公开
      categorySn: sn // 活动分类sn
    }
    try {
      const { success, message } = await fixActFormWithSnAPI(req)
      if (success) {
        console.log('修改活动标题/时间/分类信息成功')
        return true
      } else {
        wx._showToast(message)
        return false
      }
    } catch (e) {
      return false
    }
  }
}

export default {
  state,
  mutations,
  actions
}
