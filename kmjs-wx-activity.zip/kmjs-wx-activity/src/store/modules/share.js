import { addShareInsAPI } from '@/api/share'

const state = {
  // 邀请定义sn
  shareDf: {
    invite: 'e72f1dc26db6467da1e069997081ef9c' // 邀请报名人
  }
}

const actions = {
  /*
  * @info 分享小程序时调用分享参数接口
  * @param payload {Object} { type: string, path: string }
  * @desc type 分享类型 invite邀请报名人 activity活动分享
  * @desc path 分享最终要跳转的路径
  * */
  async getShareParams ({ state }, payload = {}) {
    const { type, path, orderItemSn } = payload
    const inviteDefSn = state.shareDf[type]
    const res = await addShareInsAPI({
      inviteDefSn,
      orderItemSn,
      REQ_BODY: {
        pageParam: path,
        needCode: false
      }
    })
    return res || {}
  }
}

export default {
  state,
  actions
}
