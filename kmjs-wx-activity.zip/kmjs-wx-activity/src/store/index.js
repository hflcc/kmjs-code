import { createStore } from '@mpxjs/core'
import user from './modules/user'
import ticketCheck from './modules/ticketCheck'
import actPublish from './modules/actPublish'
import share from './modules/share'
import order from './modules/order'

// 采用多实例store
const userStore = createStore(user)
const tcStore = createStore(ticketCheck)
const actPublishStore = createStore(actPublish)
const shareStore = createStore(share)
const orderStore = createStore(order)

export {
  userStore,
  tcStore,
  actPublishStore,
  shareStore,
  orderStore
}
