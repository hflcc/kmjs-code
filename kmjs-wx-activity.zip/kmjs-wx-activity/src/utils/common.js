// /**
//  * @deprecated
//  * @param areaSn
//  * @returns {Promise<unknown>|Promise<{}>}
//  */
// export function getArea (areaSn) {
//   if (!areaSn || areaSn === '-') {
//     return Promise.resolve({})
//   }
//   return new Promise((resolve, reject) => {
//     getAreaApi({ areaSn }).then(res => {
//       let area = ''
//       if (res?.province?.name) {
//         area += res.province.name
//       }
//       if (res?.city?.name) {
//         area += res.city.name
//       }
//       if (res?.area?.name) {
//         area += res.area.name
//       }
//       res.provCityArea = area // 省市区组成
//       res.areaSn = areaSn
//       resolve(res)
//     }).catch(e => {
//       reject(e)
//     })
//   })
// }

/**
 * 表单转换
 * @param value 表单的值
 * @param type 表单类型
 * @param options 表单的选项列表
 * @returns {*}
 */
export function formTranslate (value, type, options) {
  if (!value) {
    return ''
  }
  let r = ''
  switch (type) {
    case 'single':
      let option = options.find(child => child.value === value)
      r = option?.title
      break
    case 'multiple':
      let arr = JSON.parse(value)
      let values = options.filter(child => arr.indexOf(child.value) !== -1).map(child => child.title)
      r = values.join(',')
      break
    default:
      r = value
  }
  return r
}

/***
 * 格式化省市区输出
 * @param province 省
 * @param city 市
 * @returns {string}
 */
export function getProvinceCity (province = '', city = '') {
  province = province || ''
  city = city || ''
  let p = province.replace(/[省|自治区|市|壮族自治区|回族自治区|维吾尔自治区|特别行政区]/g, '')
  let c = city.replace(/[市|特别行政区]/g, '')
  return p + ' ' + c
}
/**
 * 处理富文本里的图片宽度自适应
 * 1.去掉img标签里的style、width、height属性
 * 2.img标签添加style属性：max-width:100%;height:auto
 * 3.修改所有style里的width属性为max-width:100%
 * 4.去掉<br/>标签
 * @param richText 富文本内容
 * @returns {void|string|*}
 */
export function formatRichText (richText) {
  if (richText != null) {
    richText = richText.replace(/style=""/gi, '')
    let newRichText = richText.replace(/<img[^>]*>/gi, function (match, capture) {
      match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '')
      match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '')
      match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '')
      return match
    })
    newRichText = newRichText.replace(/style="[^"]+"/gi, function (match, capture) {
      match = match.replace(/width:[^;]+;/gi, 'width:100%;').replace(/width:[^;]+;/gi, 'width:100%;')
      return match
    })
    newRichText = newRichText.replace(/<br[^>]*\/>/gi, '')
    newRichText = newRichText.replace(/<img/gi, '<img style="width:100%;height:auto;display:block;margin:5px 0"')
    // console.info(newRichText)
    return newRichText
  } else {
    return null
  }
}
