const auth = require('./modules/auth')
const base64 = require('./modules/base64')
const constant = require('./modules/constant')
const formatter = require('./modules/formatter')
const utils = require('./modules/utils')
const uploadFile = require('./modules/uploadFile')

module.exports = {
  // token信息的读取
  ...auth,
  // 常量
  ...constant,
  // base64 编解码
  ...base64,
  // 格式化相关
  ...formatter,
  // 工具方法
  ...utils,
  // 上传图片方法
  ...uploadFile
}
