let asyncTask = 0 // 异步任务数，图片请求

/**
 * 绘制活动报名海报
 * @param that
 * @param activity 活动信息
 */
function createShareBill (that, activity) {
  const query = wx.createSelectorQuery()
  query.select('#mycanvas')
    .fields({ node: true, size: true })
    .exec((res) => {
      const canvas = res[0].node
      const ctx = canvas.getContext('2d')

      const dpr = wx.getSystemInfoSync().pixelRatio
      canvas.width = res[0].width * dpr
      canvas.height = res[0].height * dpr

      const width = canvas.width
      const height = canvas.height
      const left = 10 * dpr // 左侧边距
      const lineHeight = 18 * dpr // 字体高度
      // 把活动标题，地址，测量一下宽度，是一行还是多行，把banner高度变化
      ctx.font = `normal bold ${14 * dpr}px Arial,sans-serif`
      let textLine = 0
      if (ctx.measureText(activity.activityTitle).width > (width - left * 2 - left)) {
        // 2行
        textLine += 1
      }
      ctx.font = `normal bold ${12 * dpr}px Arial,sans-serif`
      if (ctx.measureText(activity.address).width > (width - 50 - left * 2.5)) {
        // 2行
        textLine += 1
      }
      // banner的高度
      const imgHeight = height * 0.5 - textLine * lineHeight
      roundRect(ctx, 0, 0, width, height, 10 * dpr)
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, imgHeight, width, height)

      let data = that.data
      asyncTask = 6
      let bannerImg = canvas.createImage()
      bannerImg.src = activity.banner.replace(/\?.*/, '')
      bannerImg.onload = () => {
        let w = bannerImg.width // 图片宽度
        let h = bannerImg.height // 图片高度

        let dw = width / bannerImg.width
        let dh = imgHeight / bannerImg.height
        // 裁剪图片中间部分
        if ((w > width && h > imgHeight) || (w < width && h < imgHeight)) {
          if (dw > dh) {
            ctx.drawImage(bannerImg, 0, (h - imgHeight / dw) / 2, w, imgHeight / dw, 0, 0, width, imgHeight)
          } else {
            ctx.drawImage(bannerImg, (w - width / dh) / 2, 0, width / dh, h, 0, 0, width, imgHeight)
          }
        } else {
          // 拉伸图片
          if (w < width) {
            ctx.drawImage(bannerImg, 0, (h - imgHeight / dw) / 2, w, imgHeight / dw, 0, 0, width, imgHeight)
          } else {
            ctx.drawImage(bannerImg, (w - width / dh) / 2, 0, width / dh, h, 0, 0, width, imgHeight)
          }
        }
        finishCanvas()
      }
      bannerImg.onerror = (e) => {
        console.info(e)
        finishCanvas()
      }

      const titleY = imgHeight + 25 * dpr
      // 绘制商品名字
      ctx.fillStyle = '#333333'
      ctx.textAlign = 'left'
      ctx.font = `normal bold ${14 * dpr}px Arial,sans-serif` // 字体加粗
      const lineTitle = canvasTextAutoLine(activity.activityTitle, width - left * 2, ctx, left, imgHeight + 25 * dpr, lineHeight)

      ctx.font = `normal 400  ${12 * dpr}px Arial,sans-serif `
      ctx.fillStyle = '#666666'
      // 地址
      let addressY = titleY + lineTitle * lineHeight + 10 * dpr
      const line = canvasTextAutoLine(activity.address, width - (50), ctx, left * 2.5, addressY, lineHeight)

      // 票券名称
      let ticketY = addressY + line * lineHeight + 10 * dpr
      ctx.fillText(activity.ticketName, left * 2.5, ticketY)

      // 时间
      let timeY = ticketY + lineHeight + 10 * dpr
      ctx.fillText(activity.time, left * 2.5, timeY)

      // 分割线
      const lineY = timeY + lineHeight / 2 + (height - 91 * dpr - (timeY + lineHeight)) / 2
      ctx.save()
      ctx.beginPath()
      ctx.strokeStyle = '#E6E6E6'
      ctx.lineWidth = dpr
      ctx.moveTo(left, lineY)
      ctx.lineTo(width - left, lineY)
      ctx.stroke()
      ctx.restore()

      // 用户名
      ctx.fillStyle = '#333333'
      ctx.font = `normal bold ${14 * dpr}px Arial,sans-serif` // 字体加粗
      ctx.fillText(activity.name, 60 * dpr, height - 76 * dpr)
      // 电话号码
      ctx.fillStyle = '#999999'
      ctx.font = `normal 400 ${14 * dpr}px Arial,sans-serif`
      ctx.fillText(activity.mobile, 60 * dpr, height - 58 * dpr)
      // 分享描述
      ctx.fillStyle = '#387BE8'
      ctx.font = `normal 400 ${12 * dpr}px Arial,sans-serif`
      ctx.fillText(activity.shareDesc, left, height - 27 * dpr)

      ctx.fillStyle = '#999999'
      ctx.font = `normal 400 ${10 * dpr}px Arial,sans-serif`
      const x = ctx.measureText('长按识别二维码').width + 13 * dpr
      ctx.fillText('长按识别二维码', width - x, height - 15 * dpr)

      // 结束画图
      function finishCanvas () {
        asyncTask--
        if (asyncTask === 0) {
          wx.canvasToTempFilePath({
            canvas: canvas,
            success: res => {
              that.setData({
                shareTempFilePath: res.tempFilePath
              })
              wx.hideLoading()
            }
          })
        }
      }

      // 位置的图标
      let addressImg = canvas.createImage()
      addressImg.src = data.img.location
      addressImg.onload = () => {
        ctx.drawImage(addressImg, left, addressY - 10 * dpr, 9 * dpr, 11 * dpr)
        finishCanvas()
      }
      // 票券的图标
      let ticketImg = canvas.createImage()
      ticketImg.src = data.img.ticket
      ticketImg.onload = () => {
        ctx.drawImage(ticketImg, left, ticketY - 9 * dpr, 11 * dpr, 10 * dpr)
        finishCanvas()
      }
      // 时间的图标
      let timeImg = canvas.createImage()
      timeImg.src = data.img.time
      timeImg.onload = () => {
        ctx.drawImage(timeImg, left, timeY - 9 * dpr, 10 * dpr, 10 * dpr)
        finishCanvas()
      }

      // 用户头像
      let headImg = canvas.createImage()
      headImg.src = activity.headImg.replace(/\?.*/, '')
      headImg.onload = () => {
        ctx.save()
        // 绘制头像
        ctx.beginPath() // 开始绘制
        let size = 40
        // 先画个圆，前两个参数确定了圆心 （x,y） 坐标  第三个参数是圆的半径  四参数是绘图方向  默认是false，即顺时针
        ctx.arc(left + size * dpr / 2, height - 91 * dpr + size * dpr / 2, size * dpr / 2, 0, Math.PI * 2, false)
        ctx.clip() // 画好了圆 剪切  原始画布中剪切任意形状和尺寸。
        // 一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内 这也是我们要save上下文的原因
        ctx.drawImage(headImg, left, height - 91 * dpr, size * dpr, size * dpr)
        ctx.restore() // 恢复之前保存的绘图上下文 恢复之前保存的绘图问下文即状态 还可以继续绘制
        finishCanvas()
      }
      headImg.onerror = (e) => {
        finishCanvas()
      }

      // 二维码图片
      let qrcodeImg = canvas.createImage()
      qrcodeImg.src = activity.qrcode.replace(/\?.*/, '')
      qrcodeImg.onload = () => {
        ctx.drawImage(qrcodeImg, width - 80 * dpr, height - 97 * dpr, 65 * dpr, 65 * dpr)
        finishCanvas()
      }
      qrcodeImg.onerror = () => { finishCanvas() }
    })
}

/**
 *
 * @param {CanvasContext} ctx canvas上下文
 * @param {number} x 圆角矩形选区的左上角 x坐标
 * @param {number} y 圆角矩形选区的左上角 y坐标
 * @param {number} w 圆角矩形选区的宽度
 * @param {number} h 圆角矩形选区的高度
 * @param {number} r 圆角的半径
 */
function roundRect (ctx, x, y, w, h, r) {
  // 开始绘制
  ctx.beginPath()
  // 因为边缘描边存在锯齿，最好指定使用 transparent 填充
  // 这里是使用 fill 还是 stroke都可以，二选一即可
  // ctx.setFillStyle('transparent')
  ctx.strokeStyle = 'transparent'
  // 左上角
  ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5)

  // border-top
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.lineTo(x + w, y + r)
  // 右上角
  ctx.arc(x + w - r, y + r, r, Math.PI * 1.5, Math.PI * 2)

  // border-right
  ctx.lineTo(x + w, y + h - r)
  ctx.lineTo(x + w - r, y + h)
  // 右下角
  ctx.arc(x + w - r, y + h - r, r, 0, Math.PI * 0.5)

  // border-bottom
  ctx.lineTo(x + r, y + h)
  ctx.lineTo(x, y + h - r)
  // 左下角
  ctx.arc(x + r, y + h - r, r, Math.PI * 0.5, Math.PI)

  // border-left
  ctx.lineTo(x, y + r)
  ctx.lineTo(x + r, y)

  // 这里是使用 fill 还是 stroke都可以，二选一即可，但是需要与上面对应
  ctx.fill()
  // ctx.stroke()
  ctx.closePath()
  // 剪切
  ctx.clip()
}

/*
str:要绘制的字符串
canvas:canvas对象
initX:绘制字符串起始x坐标
initY:绘制字符串起始y坐标
lineHeight:字行高，自己定义个值即可
*/
function canvasTextAutoLine (str, canvasWidth, ctx, initX, initY, lineHeight) {
  var lineWidth = 0
  var lastSubStrIndex = 0
  let line = 0
  for (let i = 0; i < str.length; i++) {
    lineWidth += ctx.measureText(str[i]).width
    if (lineWidth > canvasWidth - initX) { // 减去initX,防止边界出现的问题
      line++

      let txt = str.substring(lastSubStrIndex, i)
      if (line === 2) {
        txt = txt.substring(0, txt.length - 3) + '...'
      }
      ctx.fillText(txt, initX, initY)
      initY += lineHeight
      lineWidth = 0
      lastSubStrIndex = i
      if (line === 2) {
        return line
      }
    }
    if (i === str.length - 1) {
      line++
      ctx.fillText(str.substring(lastSubStrIndex, i + 1), initX, initY)
    }
    // context.stroke();
  }
  return line
}

function saveImage (path) {
  wx.showLoading({
    title: '保存中',
    mask: true
  })
  wx.saveImageToPhotosAlbum({
    filePath: path,
    success (res) {
      wx.hideLoading({
        complete: (res) => {
        }
      })
      wx.showToast({
        title: '保存成功',
        duration: 2000
      })
    },
    fail: function (res) {
      wx.hideLoading({
        complete: (res) => {
        }
      })
      // console.info(res)
      wx.showToast({
        title: '保存失败',
        icon: 'none',
        duration: 2000
      })
    }
  })
}

/**
 * 判断是否有保存到相册的权限
 * @param path
 */
function preSaveImage (path) {
  // 检测设置中是否允许保存到相册中去
  wx.getSetting({
    success (res) {
      // console.info(res)
      // 首次进来，没有提示过授权
      if (res.authSetting['scope.writePhotosAlbum'] === undefined) {
        saveImage(path)
      } else if (!res.authSetting['scope.writePhotosAlbum']) {
        // 提示过授权，但是被拒绝了
        wx._showModal({
          title: '提示',
          content: '没有保存到相册的权限，请到设置中打开权限',
          success (res) {
            if (res.confirm) {
              wx.openSetting({
                success (res) {
                }
              })
            }
          }
        })
      } else {
        // 正常授权后
        saveImage(path)
      }
    }
  })
}

module.exports = {
  createShareBill: createShareBill,
  saveImage: preSaveImage
}
