import mpx from '@mpxjs/core'
import { checkDataType } from '@/utils'
/**
 * 挂在一些mixin混入
 * wx上面挂载方法
 */
// toast
wx._showToast = function (text) {
  if (checkDataType(text) === 'string') {
    return wx.showToast({
      title: text,
      icon: 'none',
      duration: 3000
    })
  } else if (checkDataType(text) === 'object') {
    return wx.showToast(text)
  }
}
// modal
wx._showModal = function (obj = {}) {
  if (checkDataType(obj) !== 'object') {
    throw new Error(`${obj} is not an object`)
  }
  const baseOptions = {
    title: '提示',
    content: '',
    cancelText: '取消',
    cancelColor: '#323232',
    confirmText: '确定',
    confirmColor: '#387BE8'
  }
  Object.assign(baseOptions, obj)
  return wx.showModal(baseOptions)
}
// mixin会往page/component实例注入属性方法, 会在实例方法前执行
const xProps = {
  computed: {},
  onLoad () {},
  async onPullDownRefresh () {},
  methods: {}
}
mpx.mixin(xProps, ['page', 'component'])
