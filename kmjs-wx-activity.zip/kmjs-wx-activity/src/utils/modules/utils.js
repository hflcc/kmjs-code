/**
 * @method checkDataType
 * @desc 检查数据类型
 * @param payload {any} 需要检测的类型
 * @return {string} 类型字符串
 */
function checkDataType (payload) {
  const map = {
    '[object String]': 'string',
    '[object Object]': 'object',
    '[object Array]': 'array',
    '[object Number]': 'number',
    '[object Boolean]': 'boolean',
    '[object Null]': 'null',
    '[object Undefined]': 'undefined',
    '[object Function]': 'function',
    '[object Error]': 'error',
    '[object Symbol]': 'symbol',
    '[object RegExp]': 'regexp'
  }
  const t = Object.prototype.toString.call(payload)
  return map[t]
}

/**
 * @method debounce
 * @desc 事件防抖
 * @param fn {Function} 防抖函数
 * @param delay {number} 防抖时间
 */
function debounce (fn, delay = 500) {
  if (checkDataType(fn) !== 'function') {
    console.error(`${fn} is not a function`)
    return false
  }
  let timer = null
  return function () {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      timer = null
    }, delay)
  }
}

/**
 * @method throttle
 * @desc 事件节流
 * @param fn {Function} 节流函数
 * @param delay {number} 节流时间
 */
function throttle (fn, delay = 300) {
  if (checkDataType(fn) !== 'function') {
    console.error(`${fn} is not a function`)
    return false
  }
  let timer = null
  return function () {
    if (timer) return
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      timer = null
    }, delay)
  }
}

// 校验手机号码 正则校验
function numberReg (d) {
  const reg = /^1[3-9]\d{9}$/g
  return reg.test(d)
}

// 收货人 正则校验
function nameReg (d) {
  const reg = /^[\u4E00-\u9FA5A-Za-z0-9_]+$/
  return reg.test(d)
}

// 中文名字身份认证
function identityReg (value) {
  const reg = /^[\u4E00-\u9FA5A-Za-z]{2,30}$/
  return reg.test(value)
}

// 身份证号认证
function idCardReg (value) {
  const reg = /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}$)/
  return reg.test(value)
}

// 邮箱校验
function emailReg (val) {
  const reg = /^([a-zA-Z\d])(\w|-)+@[a-zA-Z\d]+\.[a-zA-Z]{2,4}$/
  return reg.test(val)
}

// 验证英文加数字
function numLetter (value) {
  const reg = /[a-zA-Z]&&[0-9]/
  return reg.test(value)
}

// 验证正整数
function numVerification (value) {
  const reg = /^[1-9]\d*$/
  return reg.test(value)
}

// 字符长度校验
/**
 * @param {String} data  传入的值
 * @param {Number} min 最小长度
 * @param {Number} max 最大长度
 */
function stringLength (data, min, max) {
  if (min && max) {
    if (data.length < min || data.length > max) {
      return false
    }
  } else if (min) {
    if (data.length < min) {
      return false
    }
  } else if (max) {
    if (data.length > max) {
      return false
    }
  }
  return true
}

/**
 * 滚动时，改变bar的颜色
 * @param scrollTop
 * @param offer 距离默认150
 * @param color 色值 默认白色
 */
function navigationBarAnim (scrollTop, color = '#ffffff', offer = 150) {
  const alpha = (scrollTop / offer).toFixed(2)
  wx.setNavigationBarColor({
    frontColor: alpha > 0.8 ? '#000000' : '#ffffff',
    backgroundColor: alpha > 0.8 ? '#000000' : '#ffffff'
  })
  return {
    background: hexToRgba(color, alpha),
    backArrowColor: alpha > 0.8 ? 'black' : 'white'
  }
}

/**
 *
 * @param hex 例如:"#23ff45"
 * @param opacity 透明度
 * @returns {string}
 */
function hexToRgba (hex, opacity) {
  return 'rgba(' + parseInt('0x' + hex.slice(1, 3)) + ',' + parseInt('0x' + hex.slice(3, 5)) + ',' + parseInt('0x' + hex.slice(5, 7)) + ',' + opacity + ')'
}

/*
* @info 给定开始, 结束的时间戳, 返回开始到结束时间的倒计时
* @param start {Number} 开始时间戳
* @param end {Number} 结束时间戳
* @param type {String} s秒  ms毫秒
* @return {Object} {day, hour, minute, second}
* */
function getCountDownTime (start, end, type = 's') {
  const diff = end - start
  const num = type === 's' ? 1 : 1000
  if (diff < 0) {
    return {
      day: 0,
      hour: '00',
      minute: '00',
      second: '00'
    }
  }
  const day = Math.floor(diff / num / 3600 / 24)
  const h = Math.floor(diff / num / 3600 % 24)
  const m = Math.floor(diff / num / 60 % 60)
  const s = Math.floor(diff / num % 60)
  const hour = h > 9 ? h : `0${h}`
  const minute = m > 9 ? m : `0${m}`
  const second = s > 9 ? s : `0${s}`
  return {
    day,
    hour,
    minute,
    second
  }
}

/**
 * 获取搜索历史
 * @returns {*[]}
 */
function getSearchHistory () {
  return wx.getStorageSync('history') || []
}

/**
 * 清理搜索历史
 */
function clearAllSearchHistory () {
  wx.removeStorageSync('history')
}

/**
 * 保存搜索历史
 * @param value 当前搜索的值
 */
function saveSearchHistory (value) {
  const labelList = wx.getStorageSync('history') || []
  // 存在删除
  if (labelList.includes(value)) {
    labelList.splice(labelList.indexOf(value), 1)
  }
  // 最新的放到最上面去
  labelList.unshift(value)
  // 最多保存十个
  if (labelList.length > 10) {
    labelList.length = 10
  }
  wx.setStorageSync('history', labelList)
}

/**
 * 获取摄像头权限
 */
function getCameraAuth (callback) {
  wx.getSetting({
    success: (res) => {
      if (!res.authSetting['scope.camera']) {
        wx.authorize({
          scope: 'scope.camera',
          success () {
            console.log('授权成功')
            callback()
          },
          fail () {
            wx._showModal({
              content: '没有相机权限, 请到设置中打开相机权限',
              success (res) {
                if (res.confirm) {
                  wx.openSetting()
                }
              }
            })
          }
        })
      } else {
        callback()
      }
    }
  })
}
/**
 * 获取位置权限
 */
function getLocationAuth (callback) {
  wx.getSetting({
    success: (res) => {
      if (!res.authSetting['scope.userLocation']) {
        wx.authorize({
          scope: 'scope.userLocation',
          success () {
            console.log('授权成功')
            callback()
          },
          fail () {
            wx._showModal({
              content: '没有位置权限, 请到设置中打开位置权限',
              success (res) {
                if (res.confirm) {
                  wx.openSetting()
                }
              }
            })
          }
        })
      } else {
        callback()
      }
    }
  })
}

/*
* @info 将API Promise化
* @param api {Function} 可以传入 如wx.getImageInfo
* */
function promixify (api) {
  if (checkDataType(api) !== 'function') return false
  return (options, ...params) => {
    return new Promise((resolve, reject) => {
      api(Object.assign({}, options, { success: resolve, fail: reject }), ...params)
    })
  }
}

export {
  checkDataType,
  debounce,
  throttle,
  numberReg,
  idCardReg,
  nameReg,
  emailReg,
  identityReg,
  numLetter,
  numVerification,
  stringLength,
  navigationBarAnim,
  getCountDownTime,
  getSearchHistory,
  clearAllSearchHistory,
  saveSearchHistory,
  getCameraAuth,
  getLocationAuth,
  promixify
}
