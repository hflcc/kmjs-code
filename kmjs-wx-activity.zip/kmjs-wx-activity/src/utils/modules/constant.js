const ENV = wx.getAccountInfoSync().miniProgram.envVersion
let BASE_URL = ''
let H5_URL = ''
if (ENV === 'develop') {
  BASE_URL = 'https://api-dev.kmyun.cn'
  H5_URL = 'https://h5-dev.kmyun.cn'
  // BASE_URL = 'http://172.16.31.22:18948' // 欧阳本地环境
} else if (ENV === 'trial') {
  BASE_URL = 'https://api-dev.kmyun.cn'
  H5_URL = 'https://h5-dev.kmyun.cn'
} else if (ENV === 'release') {
  BASE_URL = 'https://api.kmyun.cn'
  H5_URL = 'https://h5.kmyun.cn'
}

module.exports = {
  /**
   * develop: 开发环境
   * trial: 体验版
   * release: 生产
   */
  ENV,
  // 后台对应的 appid
  // CLIENT_ID: '99599E0DCED4_2',
  // // 后台对应的 APP秘钥
  // CLIENT_SECRET: 'C7F47C73863E40B18BC3F1616E4494',
  // 后台对应的 appid
  CLIENT_ID: 'F3124A4BD8DC_2',
  // 后台对应的 APP秘钥
  CLIENT_SECRET: '7551B56D17814ABD924A6E73655948',
  // token存储名称
  TOKEN: ENV + '_token',
  // 身份KEY值
  USER_INFO: ENV + '_userInfo',
  // app信息
  APP_INFO: 'appInfo',
  // 机构的类型 activity(活动)
  INST_TYPE: 'activity',
  // openId
  OPENID: 'openId',
  // 刷新token
  REFRESHTOKEN: 'refreshToken',
  // 刷新token的时间
  REFRESHTOKENTIME: 'refreshTokenTime',
  // 支付定义sn
  PAY_DEF_SN: '910ebb923b854f73b7f3045f251cc2c3',
  // 基本Url
  BASE_URL,
  // H5页面的URL
  H5_URL,
  // 使用在腾讯位置服务申请的key
  TX_POSITION_KEY: 'OJ5BZ-5NTW3-JNR3E-3QLLY-CZG2T-TUBG7',
  // 调用插件的app的名称
  TX_POSITION_REFERER: '喧圈',
  // 默认的其它用户头像
  DEFAULT_HEAD_IMG: 'https://resource.kmyun.cn/kmjs-wx-activity/head-img.png',
  // 默认的用户头像
  DEFAULT_USER_HEAD_IMG: 'https://resource.kmyun.cn/kmjs-wx-activity/my_default_avatar.png'
}
