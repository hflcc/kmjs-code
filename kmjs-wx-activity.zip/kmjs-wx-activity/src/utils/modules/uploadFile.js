import { userStore } from '@/store'
import { checkDataType } from './utils'
import { BASE_URL } from './constant'

function uploadFile (path) {
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: `${BASE_URL}/oss/upload/file`, // 此域名不适合配置项, 静态资源服务器生产上也是这个域名(api-dev.kmyun.cn), 跟业务接口不一样
      filePath: path,
      name: 'file',
      header: {
        Authorization: `Bearer ${userStore.state.token}`,
        'content-type': 'multipart/form-data'
      },
      formData: {
        dirName: 'kmjs-wx-activity'
      },
      success: (res) => {
        const { seq } = JSON.parse(res?.data || '{}')
        if (seq) {
          resolve(seq)
        } else {
          reject(new Error('获取seq失败'))
        }
      },
      fail: (err) => {
        reject(new Error(err))
      }
    })
  })
}
/*
* @info 图片上传公共方法
* @info form表单上传获取图片seq, 数组内图片都上传完后统一拿seq集合再去换取真实图片url
* @param payload {Array} [tempFilePaths]
* @return Promise then接收为数组  [] ==> [{ seq: '', url: '' }]
* */
function uploadImg (payload = []) {
  if (checkDataType(payload) !== 'array') {
    console.error('参数必须是个数组')
    return false
  }
  return new Promise((resolve, reject) => {
    Promise.allSettled(payload.map(item => uploadFile(item)))
      .then(async values => {
        const errList = []
        const arr = values.filter((item, index) => {
          if (item.status === 'fulfilled') {
            return true
          } else {
            errList.push(index + 1)
          }
        })
        if (errList.length) {
          wx._showToast(`第${errList.join(',')}个请求失败了，请重新上传`)
        }
        const list = await getApp().picSnGetUrl(arr.map(item => item.value), true)
        if (list?.length) {
          const l = list.map(({ seq, url }) => {
            return {
              seq,
              url: url.replace(/\?.*/, '')
            }
          })
          resolve(l)
        } else {
          resolve([])
        }
      }).catch(err => {
        reject(err)
      })
  })
}

export {
  uploadImg,
  uploadFile
}
