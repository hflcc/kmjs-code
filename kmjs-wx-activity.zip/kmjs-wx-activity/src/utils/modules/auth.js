import { TOKEN } from '@/utils'
const { setStorageSync, getStorageSync, removeStorageSync } = wx

/**
 * @method getStorageToken
 * @desc 获取token
 * @return {string} token 字符串
 */
function getStorageToken () {
  return getStorageSync(TOKEN) || ''
}

function setStorageToken (token) {
  setStorageSync(TOKEN, token)
}

function removeStorageToken () {
  removeStorageSync(TOKEN)
}
export { getStorageToken, setStorageToken, removeStorageToken }
