const datesAreOnSameDay = (first, second) =>
  first.getFullYear() === second.getFullYear() &&
  first.getMonth() === second.getMonth() &&
  first.getDate() === second.getDate()

let self = {
  /**
   * @method formatterMoney
   * @desc 格式化金钱
   * @param value {number|string} 目标字符串或者数字
   * @return {string} 格式化后的金钱
   */
  formatterMoney (value) {
    if (typeof value !== 'number') {
      value = parseInt(value)
    }
    if (isNaN(value)) {
      console.log('传入的类型不可转成数字')
      value = 0
    }
    return value.toFixed(2)
  },
  /**
   * @method formatterMobile
   * @desc 格式化手机号码
   * @param mobile {string} 源手机号码
   * @return {string} 格式化后手机号码
   */
  formatterMobile (mobile) {
    return mobile.substring(0, 3) + '****' + mobile.substring(7)
  },
  /**
   * @method formatterTime
   * @desc 时间戳格式化成时间字符串
   * @param time {string|number|date} 可以直接被new Date的属性
   * @param fmt {string} MD => MM-dd | HMM => hh:mm:ss
   * @return {string} 默认返回类型: yyyy-MM-dd hh:mm:ss
   */
  formatterTime (time, fmt = 'YYYY/mm/dd HH:MM:SS') {
    if (!time || time === 0 || time === '0') {
      return ''
    }
    if ((time + '').length === 10) {
      time *= 1000
    } else if ((time + '').length < 10) {
      return ''
    }
    const date = new Date(time)
    let ret
    const opt = {
      'Y+': date.getFullYear().toString(), // 年
      'm+': (date.getMonth() + 1).toString(), // 月
      'd+': date.getDate().toString(), // 日
      'H+': date.getHours().toString(), // 时
      'h+': date.getHours() > 12 ? ('下午 ' + (date.getHours() - 12)) : '上午 ' + date.getHours(), // 时
      'M+': date.getMinutes().toString(), // 分
      'S+': date.getSeconds().toString() // 秒
      // 有其他格式化字符需求可以继续添加，必须转化成字符串
    }
    for (let k in opt) {
      ret = new RegExp('(' + k + ')').exec(fmt)
      if (ret) {
        fmt = fmt.replace(ret[1], (ret[1].length === 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, '0')))
      }
    }
    return fmt
  },
  formatterTime2 (time) {
    if (!time) {
      return ''
    }
    if ((time + '').length === 10) {
      time *= 1000
    }
    const date = new Date(time)
    let currYear = new Date().getFullYear()

    const month = (date.getMonth() + 1).toString()
    const day = date.getDate().toString()
    const weeks = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
    const week = weeks[date.getDay()]
    // 如果不是现在的年份，需要显示年
    if (currYear !== date.getFullYear()) {
      return `${date.getFullYear()}年${month}月${day}日 ${week}`
    } else {
      return `${month}月${day}日 ${week}`
    }
  },
  // 活动时间  传秒 或者毫秒
  formatterActivityTime (startAt, endAt) {
    if (!startAt) {
      return ''
    }
    // 如果是数字，如果是秒，需要转成毫秒
    if (!isNaN(startAt)) {
      if ((startAt + '').length === 10) {
        startAt *= 1000
      }
      if (endAt && (endAt + '').length === 10) {
        endAt *= 1000
      }
    } else if ((startAt + '').indexOf('-') !== -1) {
      // 处理传进来的各种时间格式，-的形式IOS无法识别，需要转成/
      startAt = startAt.replace(/-/g, '/')
      if (endAt) {
        endAt = endAt.replace(/-/g, '/')
      }
    }
    let currYear = new Date().getFullYear()
    let startDate = new Date(startAt)
    if (!endAt) {
      if (currYear === startDate.getFullYear()) {
        return self.formatterTime(startAt, 'mm/dd HH:MM')
      } else {
        return self.formatterTime(startAt, 'YYYY/mm/dd HH:MM')
      }
    }
    let endDate = new Date(endAt)
    // ● 当开始时间不在本年度，结束时间未超过当天：展示年/月/日/时/分-时/分，如：2022/06/15 09:30 ～ 12:00
    if (startDate.getFullYear() > currYear && datesAreOnSameDay(startDate, endDate)) {
      return self.formatterTime(startAt, 'YYYY/mm/dd HH:MM') + ' ～ ' +
        self.formatterTime(endAt, 'HH:MM')
    }
    // ● 当开始时间在本年度，结束时间未超过当天：展示月/日/时/分-时/分，如：06/15 09:30 ～ 12:00；
    if (startDate.getFullYear() === currYear && datesAreOnSameDay(startDate, endDate)) {
      return self.formatterTime(startAt, 'mm/dd HH:MM') + ' ～ ' +
        self.formatterTime(endAt, 'HH:MM')
    }
    // ● 当开始和结束时间未超过本年度：显示月/日/时/分，如：06/17 09:30 ～ 06/20 12:00；
    if (startDate.getFullYear() === currYear && endDate.getFullYear() === currYear) {
      return self.formatterTime(startAt, 'mm/dd HH:MM') + ' ～ ' +
        self.formatterTime(endAt, 'mm/dd HH:MM')
    }
    // ● 当开始和结束时间有一个超过本年度：显示年/月/日/时/分，如：2021/06/17 09:30 ～ 2022/06/20 12:00；
    if (startDate.getFullYear() > currYear || endDate.getFullYear() > currYear) {
      if (startDate.getFullYear() === endDate.getFullYear()) {
        return self.formatterTime(startAt, 'YYYY/mm/dd HH:MM') + ' ～ ' +
          self.formatterTime(endAt, 'mm/dd HH:MM')
      } else {
        return self.formatterTime(startAt, 'YYYY/mm/dd HH:MM') + ' ～ ' +
          self.formatterTime(endAt, 'YYYY/mm/dd HH:MM')
      }
    }
    return self.formatterTime(startAt, 'mm/dd HH:MM') + ' ～ ' +
      self.formatterTime(endAt, 'mm/dd HH:MM')
  }

}
module.exports = self
