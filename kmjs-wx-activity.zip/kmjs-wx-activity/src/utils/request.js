import mpx from '@mpxjs/core'
import mpxFetch from '@mpxjs/fetch'
import { userStore } from '@/store'
import { CLIENT_ID, CLIENT_SECRET, BASE_URL } from './modules/constant'
import { encode } from './modules/base64'

const ENV = wx.getAccountInfoSync().miniProgram.envVersion
const LOGIN_URL = 'oauth2/oauth/token'
const WAIT_JOIN_URL = 'act/activity/ticket/user/wait' // 待参加
const SCAN_URL = 'act/activity/ticket/main/scan' // 扫码接口
mpx.use(mpxFetch)
const newFetch = mpx.xfetch
const cancelToken = new mpx.xfetch.CancelToken()
const reg = /{(.+?)}/g
newFetch.interceptors.request.use(function (config) {
  const { token } = userStore.state
  config.headers = {
    AppId: CLIENT_ID,
    Authorization: ''
  }
  if (config.url.indexOf(LOGIN_URL) !== -1) {
    config.headers.Authorization = `Basic ${encode(`${CLIENT_ID}:${CLIENT_SECRET}`)}`
  } else {
    config.headers.Authorization = 'Bearer ' + token
  }
  if (userStore.state.userInfo && userStore.state.userInfo.instId) {
    config.headers.InstId = userStore.state.userInfo.instId
  }

  // config.headers.Authorization = 'Bearer afcee1b4-f174-4a93-ab6f-e8448ec3e3c9'
  // config.headers.InstId = 554

  // 处理rest链接，替换花括号的内容
  const path = config.url.match(reg)
  if (path?.length && config.data) {
    const datas = JSON.parse(JSON.stringify(config.data))
    path.forEach(item => {
      const key = item.replace(/[{}]/g, '').trim()
      if (datas[key]) {
        config.url = config.url.replace(item, datas[key])
        delete datas[key]
      }
    })
    // 特殊处理请求中没有key的请求体，例如将整个数组放入请求体
    if (datas.REQ_BODY) {
      config.data = datas.REQ_BODY
    } else {
      config.data = datas
    }
  }
  if (ENV !== 'release' && wx.getSystemInfoSync().platform !== 'devtools') {
    console.info('请求地址：', config.url)
    console.info('请求参数：')
    console.info(JSON.stringify(config.data))
  }
  return config
})
let isToLogin = false
newFetch.interceptors.response.use(
  function (response) {
    const res = response.data || {}
    if (ENV !== 'release' && wx.getSystemInfoSync().platform !== 'devtools') {
      console.info('请求地址：', response.requestConfig.url)
      console.info('返回结果：')
      console.info(JSON.stringify(res))
    }
    if (response.statusCode === 200) {
      return res
    }
    if (response.statusCode === 401) {
      if (response.requestConfig.url.indexOf(LOGIN_URL) !== -1 ||
        response.requestConfig.url.indexOf(WAIT_JOIN_URL) !== -1) {
        userStore.commit('logout')
        return null
      }
      // 跳回登录页面
      wx._showToast('登录已过期')
      let pages = getCurrentPages()
      // 防止多个请求，同时跳转到登录页面
      if (pages[pages.length - 1].route !== '/pages/login/login' && !isToLogin) {
        wx.navigateTo({
          url: '/pages/login/login'
        })
        isToLogin = true
        setTimeout(() => {
          isToLogin = false
        }, 500)
      }
      userStore.commit('logout')
      return Promise.reject(res)
    }
    if (response.requestConfig.url.indexOf(SCAN_URL) !== -1 && res.status === 519) {
      wx.hideLoading()
      wx._showToast('二维码错误')
      return Promise.reject(res)
    }

    // 活动已下架
    if (res.status === 519 && (res.message === '活动不存在' || res.message === '活动已下架')) {
      return Promise.reject(res)
    }

    if (res.message) {
      wx.hideLoading()
      wx._showToast(res.message)
      return Promise.reject(res)
    }
  },
  err => {
    // 请求失败
    try {
      // 关闭loading
      wx.hideLoading()
      // 停止刷新
      wx.stopPullDownRefresh()
    } catch (e) {
      console.error(e)
    }
    if (err.errMsg.trim() === 'request:fail') {
      wx.hideLoading()
      wx._showToast('请求网络失败，请稍后重试')
    } else if (err.errMsg === 'request:fail timeout') {
      wx._showModal({
        title: '提示',
        content: '请求超时, 请重试',
        showCancel: false,
        success () {
        }
      })
    } else {
      wx._showToast('请求失败，请稍后重试')
    }
    return Promise.reject(err)
  }
)

/*
 * @info fetch请求
 * @param url {String} 请求api
 * @param data {Object} 请求参数
 * @param method {String} 请求方法
 * @param timeout {Number} 超时时间 单位:秒
 * @return {Promise<any>} 返回promise实例
 * */
export const fetch = function (url, data, method = 'POST', timeout = 10) {
  return newFetch.fetch({
    url: `${BASE_URL}${url}`,
    method,
    data,
    timeout: timeout * 1000,
    cancelToken: cancelToken.token
  })
}
