// pages/information-seach-detail/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 搜索内容
    searchValue: '',
    // 页数
    pages: 0,
    // 总条数
    total: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 设置搜索字段
    this.setData({ searchValue: options.v })
    // 获取tab数据
    this.getSearchList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  // 搜索
  onSearch(e) {
    let value = e.currentTarget.dataset.v || e.detail
    this.setData({
      searchValue: value
    })
    this.getSearchList()
  },
  // 获取搜索列表信息
  getSearchList() {
    const that = this;
    const searchValue = that.data.searchValue
    const page = that.data.pages
    app.get(`/mk/csc/client/message/search?searchKey=${searchValue}&page=${page}`).then((res)=>{
      if (res) {
        let list = res.content
        const total = res.totalElements
        app.formatMessageForService(list).then(val => {
            let searchInformationList = val
            // 加载上一页；聊天记录
            if (val.length === 0) {
              that.setData({
                loading: false,
                searchInformationList,
              })
              return
            }
            // 如果有下一页
            if (page!==0) {
              searchInformationList = this.data.searchInformationList.concat(val)
            }

            that.setData({
              searchInformationList,
              total
            })
        })
      }
    })
  },
  // 查看消息详情
  onGoToMessage(event) {
    if(event.detail) {
      const sn = event.detail.key.sn;
      const title = event.detail.key.name;
      const id = 'ID-' + event.detail.key.messageKey
      wx.navigateTo({
        url: `/packageB/pages/tim/tim?dialogSn=${sn}&title=${title}&toView=${id}`
      })
    }
  },
  // 今天上拉加载
  scrolltolower() {
    const list = this.data.searchInformationList
    const total = this.data.total

    if(list.length < total) {
      let pages = this.data.pages
      ++pages
      this.setData({
        pages
      })
      this.getSearchList()
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
