// pages/information-list/index.js
const app = getApp()
let timerName
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: `https://kmjs.oss-cn-shenzhen.aliyuncs.com/kmjs-wx-ec-static/purchase-list.png?timer=${new Date().getTime()}`,
    // 搜索
    searchVal: "搜索",
    // 未读消息
    unread: 0,
    // 消息列表
    informationList:[],
    // 防止多次点击
    clickBtn: false,
    // 胶囊距离顶部
    capsuletop: app.menuBoundingMsg["top"],
    // 胶囊高度
    capsuleheight: app.menuBoundingMsg["height"] - 1,
    // 登录态
    token: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  async onReady() {
    // hack
    setTimeout(() => {
      const result = app.getMenuBoundingMsg()
      this.setData({
        // 胶囊距离顶部
        capsuletop: result.top,
        // 胶囊高度
        capsuleheight: result.height - 1,
      })
    }, 1000)
  },
   /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      token: app.globalData.userInfo.token
    })
    if (app.globalData.userInfo.token) {
      this.getinformationList()
      this.messageFun()
      this.startReportHeart()
    }
  },
  // 刷新消息
  startReportHeart() {
    const that = this
    timerName = setTimeout(()=>{
      this.messageFun()
      this.startReportHeart()
    }, 10000)
    // 保存定时器name
    that.setData({
       timer: timerName
    })
  },
  // 获取消息列表
   getinformationList() {
    const that = this
    app.get('/mk/csc/client/list?includeTypes=dialog', {}, {}, false).then((res)=>{
      if (res) {
        const list = res
        app.formatMessageForService(list).then(val => {
          const informationList = val
          // 加载上一页；聊天记录
          if (val.length === 0) {
            that.setData({
              informationList
            })
            return
          }
          that.setData({
            informationList,
          })
        })
      }
    })
  },
  // 未读消息接口
  messageFun() {
    const that = this
    app.get('/mk/csc/client/message/count?includeTypes=dialog', {},{},false).then((res)=>{
      if(res) {
        let count = res.count > 99? '99+' : res.count
        if (res.count) {
          wx.setTabBarBadge({
            index: 3,
            text: `${count}`
          })
          this.getinformationList()
        } else {
          wx.removeTabBarBadge({
            index: 3
          })
        }
        that.setData({
          unread: count
        })
      }
    })
  },
  // 清除未读消息
  clearMwssageFun() {
    const that = this
    let clickBtn = that.data.clickBtn
    if (!clickBtn) {
      clickBtn = true
      setTimeout(() => {
        clickBtn = false
        that.setData({
          clickBtn
        })
      }, 3000)
      app.put('/mk/csc/client/message/clear').then((res)=>{
        if (res) {
          // 清除列表的未读消息
          const informationList = that.data.informationList
          informationList.forEach(item => {
            item.msgCount = 0
          })
          // 清除tabbar上的未读消息
          wx.removeTabBarBadge({
            index: 3
          })
          that.setData({
            unread: 0,
            informationList,
            clickBtn
          })
        }
      })
    } else {
      wx.showToast({
        title: '请勿重复点击',
        icon: 'none'
      })
    }
  },
  // 去客服聊天页面
  onGoToMessage(event) {
    if(event.detail) {
      const sn = event.detail.key.sn;
      const title = event.detail.key.name;
      this.messageFun()
      wx.navigateTo({
        url: `/packageB/pages/tim/tim?dialogSn=${sn}&title=${title}`
      })
    }
  },
   // 去登录
  login: function () {
    if (app.loginJump()) {
      return
    }
  },
  // 去搜索页面
  goSearch() {
    wx.navigateTo({
      url: `/pages/information-seach/index?v=${this.data.searchVal}`
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    clearTimeout(timerName)
  }
})
