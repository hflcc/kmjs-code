// pages/assist-list/index.js
import { MOBILE} from "../../utils/index"
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    time: null,
    assistList: [],
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
    // 优惠券弹出框
    show: false,
    //权益说明弹窗框
    explainShow: false,
    //banner图
    bannerImg: '',
    //信息流Sn
    dataSn: '',
    query: {
      page: 0,
      size: 30
    },
    goodsSn: '',
    ipone:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.scene) {
      this.setData({show:true})
      app.checkNewCoupon("mlbf")
    }
    this.setData({ipone:app.globalData.userInfo.phoneNum})
    this.getDataSn();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //下拉刷新
  pullUp() {
    this.setData({
      assistList: []
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getAssist()
      this.setData({
        refresherTriggered: false
      })
    })
  },
  //上拉加载
  pullDown() {
    if (this.data.hasData) {
      this.data.query.page += 1
      this.getAssist()
    }
  },
  //点击关闭
  onClickHide() {
    this.setData({
      show: false
    });
    wx.navigateTo({
      url: '/pages/mine-coupons/index',
    });
  },
  popExplain() {
    this.setData({
      explainShow: true
    })
  },
  close() {
    this.setData({
      explainShow: false
    })
  },
  //获取sn
  getDataSn() {
    app.get('/md/common/info/flow/platform/list/category/mlbf').then(res => {
      if (res) {
        let dataSn = res[0].sn;
        let bannerImg ;
        app.get('/md/common/info/flow/instance/page/def_category_sn/' + dataSn).then(async res => {
          if (res) {
            res.content.forEach(v => {
              v.items.forEach(a => {
                if (a.data.contentImageId) {
                  bannerImg = a.data.contentImageId[0];
                } else {
                  this.setData({
                    time: a.data.endAt
                  })
                }
              })
            })
            let time = (this.data.time - Math.round(new Date().getTime() / 1000)) * 1000;
            bannerImg = await app.picSnGetUrl(bannerImg);
            this.setData({
              bannerImg,
              time
            })
          }
        })
        app.get('/md/common/info/flow/platform/list/category/mlbf?parentSn=' + dataSn).then(res => {
          if (res) {
            let goodsSn = res[0].sn
            this.setData({
              goodsSn
            })
            this.getAssist()
          }
        })
      }
    })
  },
  //获取帮扶商品
  getAssist() {
    app.get('/md/common/info/flow/instance/page/def_category_sn/' + this.data.goodsSn, {
      page: this.data.query.page,
      size: this.data.query.size
    }).then(async res => {
     if (res) {
      let dataList = res.content.map(v => {
        return v.items[0];
      })
      this.setData({ hasData: !res.last })
      let assistList;
      if (this.data.query.page === 0) {
        assistList = []
      } else {
        assistList = this.data.assistList
      }
      this.setData({
        assistList: assistList.concat(...await app.formatterAssistGoods(dataList))
      })
     }
    })
  },
  //去商品详情
  goDetail(e) {
    let sn = e.detail;
    wx.navigateTo({
      url: '/pages/goods-detail/index?sn=' + sn,
    });
  }
})