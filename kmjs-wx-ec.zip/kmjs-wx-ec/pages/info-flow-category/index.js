const app = getApp()

Page({
  data: {
    // 信息流数据
    data: [],
    // 信息流sn
    sn: "",
    // 活动标题
    title: "",
    // 描述文案
    description: "",
    // 是否展示弹窗
    showDialog: false,
    // 是否刷新中
    refresherTriggered: false,
    // 分页数据
    paging: {
      page: 0,
      size: 10
    },
    // 是否请求中
    isRequestIng: false,
    // 是否有更多
    hasMore: false
  },
  onLoad: function (options) {
    this.setData({
      sn: options.sn
    })
    this.getActivityInfo()
    this.getData()
  },
  // 分享
  onShareAppMessage: function (e) {

  },
  onShareTimeline:function (e) {
    return {title:this.data.title}
  },
  // 获取活动的基本信息
  getActivityInfo() {
    app.get(`/md/common/info/flow/def/category/sn/${this.data.sn}`).then(res => {
      if (!res) {
        return
      }
      const { name: title, description } = res
      // 设置活动描述
      this.setData({
        title,
        description
      })
      wx.setNavigationBarTitle({
        title
      })
    })
  },
  // 获取信息流数据
  getData() {
    const { paging } = this.data
    app.get(`/md/common/info/flow/instance/page/def_category_sn/${this.data.sn}`, paging).then(async (res) => {
      const data = await app.formatterContent(res.content)
      this.setData({
        data,
        refresherTriggered: false
      })
      this.data.isRequestIng = false
      this.data.hasMore = !res.last
    })
  },
  // 刷新列表
  bindrefresh() {
    const { isRequestIng, paging } = this.data
    if (isRequestIng) {
      return
    }
    // 重置页数
    paging.page = 0
    // 重置数据
    this.setData({
      data: []
    })
    this.getData()
  },
  // 滚动到底部
  scrolltolower() {
    const { isRequestIng, paging, hasMore } = this.data
    if (isRequestIng || !hasMore) {
      return
    }
    paging.page += 1
    this.getData()
  },
  // 打开活动规则
  openShowDialog() {
    this.setData({
      showDialog: true
    })
  }
})
