// pages/my-spelling/index.js
const {
  formatterTime,
  formatterMoney,
  WXINFO,
  spellType
} = require("../../utils/index")
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 显示分享按钮
    showShare: false,
    // 显示分享海报
    showPoster: false,
    shareData: {},
    // 小程序码
    ewmImg: "",
    shareOptions: [{
        name: "分享给好友",
        type: "base",
        openType: "share",
        icon: "http://resource.kmyun.cn/haopinggo/wx.png"
      },
      {
        name: "生成分享海报",
        type: "poster",
        icon: "http://resource.kmyun.cn/haopinggo/poster.png"
      }
    ],
    //我的拼团列表
    spelling: [],
    query: {
      page: 0,
      size: 10
    },
    //二维码实例sn
    actorSn: '',
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.init()
    this.getMySpelling()
  },
  init(){
    this.data.query.page = 0
    this.setData({
      spelling: [],
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    let {
      title,
      imageUrl,
      scene
    } = this.data.shareData
    return {
      title,
      desc: title,
      imageUrl: imageUrl.replace("https", "http"),
      path: "/pages/spelling-detail/index?scene=" + scene
    }
  },
  //下拉刷新
  pullUp() {
    this.setData({
      spelling: []
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getMySpelling()
      this.setData({
        refresherTriggered: false
      })
    })
  },
  //上拉加载
  pullDown() {
    if (this.data.hasMore) {
      this.data.query.page += 1
      this.getMySpelling()
    }
  },
  getMySpelling() {
    this.setData({
      isLoading: true
    })
    app.get('/ec/compose/instance/actor', {
      page: this.data.query.page,
      size: this.data.query.size
    }).then(async res => {
      if (res.content) {
        let spellingList = [];
        for (let i = 0; i <= res.content.length - 1; i++) {
          res.content[i].statetxt = spellType[res.content[i].state];
          res.content[i].goodsAmount = formatterMoney(res.content[i].minMoney);
          res.content[i].payableAmount = formatterMoney(res.content[i].payableAmount);
          res.content[i].goodImg = await app.picSnGetUrl(res.content[i].ossId);
          res.content[i].time = ((res.content[i].state == 'none' ? res.content[i].orderExpireAt : res.content[i].expireAt) - Math.round(new Date().getTime() / 1000)) * 1000;
          res.content[i].deliverAmount = formatterMoney(res.content[i].deliverAmount);
          for(let j = 0;j<=res.content[i].actors.length-1;j++){
            res.content[i].actors[j].headImgUrl = await app.picSnGetUrl(res.content[i].actors[j].headImgUrl, {width: 800, height: 800})
            res.content[i].actors[j].headImgUrl = res.content[i].actors[j].headImgUrl.toString()
            console.log(res.content[i].actors[j].headImgUrl);
          }
          console.log(res.content[i].actors);
          if (res.content[i].state === "process") {
            res.content[i].shareData={
                "title": res.content[i].goodName,
                "minPrice": res.content[i].goodsAmount,
                "peopleNum": res.content[i].targetNum,
                "saleHeadImg": app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.headimgUrl ? wx.getStorageSync(WXINFO).headimgUrl : "https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/hpglogo-1624413363473.png",
                "saleHeadName": app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.nickName ? wx.getStorageSync(WXINFO).nickName : "耗品GO",
                "imageUrl": res.content[i].goodImg?res.content[i].goodImg[0]:'',
                "scene": res.content[i].bizEcComposeInstanceActorSn
              }
          }
          spellingList = res.content;
        }
        let spelling;
        if (this.data.query.page === 0) {
          spelling = []
        } else {
          spelling = this.data.spelling
        }
        this.setData({
          spelling: spelling.concat(spellingList),
          "hasMore": !res.last,
          isLoading: false
        })
      }
    })
  },
  // 关闭图片
  closePoster() {
    this.setData({
      showPoster: false
    })
  },
  // 保存图片
  savePoster() {
    const _self = this
    wx.getSetting({
      withSubscriptions: true,
      success(res) {
        if (res.authSetting["scope.writePhotosAlbum"] === false) {
          wx.openSetting({
            success(data) {
              console.log("成功", data)
            },
            fail(err) {
              console.log("失败", err)
            }
          })
        } else {
          _self.selectComponent("#canvas").saveImage()
        }
      }
    })
  },
  // 获取小程序码
  async ewm() {
    let img = await app.get(`/wx/common/applet/code?scene=${this.data.actorSn}&page=pages/spelling-detail/index`)
    this.setData({
      ewmImg: img.imgBase64
    })
  },
  // 分享面板
  changeShowShare() {
    this.setData({
      showShare: !this.data.showShare
    })
  },
  // 选择分享类型
  shareTypeSelect({
    detail
  }) {
    this.setData({
      showShare: false
    })
    if (detail.type == "base") {

    } else if (detail.type == "poster") {
      this.setData({
        "shareData.shareImg": this.data.ewmImg,
        showPoster: true
      })
    }
  },
  //拼团按钮
  setType({
    currentTarget
  }) {
    console.log(currentTarget);
    let sn = currentTarget.dataset.sn;
    let type = currentTarget.dataset.type;
    if (type === "fail") {
      wx.navigateTo({
        url: '/pages/goods-detail/index?sn=' + sn,
      });
    } else if (type === "none") {
      wx.navigateTo({
        url: '/pages/order-detail/index?sn=' + sn,
      });
    } else if (type === "success") {
      wx.navigateTo({
        url: '/pages/order-detail/index?sn=' + sn,
      });
    } else if (type === "process") {
      // 获取小程序码
      this.setData({
        showShare: !this.data.showShare,
        actorSn:currentTarget.dataset.item.bizEcComposeInstanceActorSn,
        shareData:currentTarget.dataset?.item?.shareData
      })
      this.ewm()
    } else if (type === "shops") {
      wx.navigateTo({
        url: '/packageA/pages/shop-home/index?sn=' + sn,
      });
    }
  }
})
