// pages/invite-friends/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    query: {},
    // 显示二维码
    showQR: false,
    // 方案sn
    projectSn: "",
    // 基础信息
    describe: {},
    //类型
    type: "",
    instId: "",
    userId: "",
    //环销sn
    scene: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: async function (options) {
    this.setData({
      query: options
    })
  },
  onShow: async function() {
    const {query: options} = this.data
    // 个人中心进来的
    if (options.projectSn) {
      this.setData({
        projectSn: options.projectSn,
        type: "self"
      })
      // 环销进来的
    } else if (options.scene) {
      let result = await app.get(`/sys/common/params/${options.scene}`)
      const data = {}
      if (!result) {
        return
      }
      result = result.value
      // 拆分字符串
      result.match(/(\w+)=(\w+)/g).forEach(item => {
        const res = item.split("=")
        data[res[0]] = res[1]
      })
      this.setData({
        projectSn: data.projectSn,
        type: data.type,
        instId: data.instId,
        userId: data.userId,
        scene: data.sn
      })
    }
    wx.nextTick(() => {
      // 获取基础信息
      this.getData()
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    const { title, imgShareUrl, pageRegUrl } = this.data.describe
    return {
      title: title,
      imageUrl: imgShareUrl,
      path: pageRegUrl
    }
  },
  // 面对面推荐
  qrCode() {
    this.setData({
      showQR: true
    })
  },
  // 隐藏面对面推荐
  onClickHide() {
    this.setData({
      showQR: false
    })
  },
  // 复制
  onCopy() {
    wx.setClipboardData({
      data: this.data.describe.inviteCode
    })
  },
  // 获取数据
  async getData() {
    // 查询环销方案分享列表
    const shareList = await app.get(`/mk/project/ring/event/list/${this.data.projectSn}`)
    if (!shareList) {
      return
    }
    let inviteDefSn
    shareList.forEach(item => {
      // 邀请定义sn
      if (item.name === "ec_order") {
        inviteDefSn = item.inviteDefSn
      }
    })
    // 新增邀请实例
    let inviteInstance
    // 通过邀请定义,获取邀请码
    let inviteCode
    if (this.data.type == "instance") {
      inviteInstance = await app.get(`/mk/invite/instance/${this.data.scene}`)
      inviteCode = await app.get(`/mk/invite/code/${inviteDefSn}?userId=${this.data.userId}&instId=${this.data.instId}`)
    } else if (this.data.type == "self") {
      inviteInstance = await app.post(`/mk/invite/instance/${inviteDefSn}`)
      inviteCode = await app.get(`/mk/invite/code/${inviteDefSn}`)
    }
    // 获取小程序码图片,获取邀请图片
    const picList = await app.picSnGetUrl([inviteCode.inviteCodeUrl, inviteInstance.transferImg, inviteInstance.img])
    // 设置标题
    wx.setNavigationBarTitle({
      title: inviteInstance.title
    })
    this.setData({
      describe: {
        ...inviteInstance,
        // 邀请码;邀请小程序码图片
        ...inviteCode,
        // 小程序码图片
        miniProgramPic: picList[0],
        // 项目的图片
        url: picList[1],
        // 分享的图片
        imgShareUrl: picList[2]
      }
    })
  }
})
