// pages/address/index.js
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 订单sn
    sn: "",
    type:"",
    data: {}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      sn: options.sn,
      type:options.type || ''
    })
    this.getData()
  },
  // 获取数据
  getData() {
    let url = ''
    if(this.data.type=='saled'){
      url = `/ec/saled/deliver/${this.data.sn}`
    }else{
      url = `/ec/deliver/search/${this.data.sn}`
    }
    app.get(url).then(res => {
      if (res) {
        this.setData({
          data: this.formatterData(res)
        })
      }
    })
  },
  // 格式化数据
  formatterData({ logo, expName, billSn, statusList }) {
    return {
      logo,
      expName,
      orderNo: billSn,
      list: statusList.map(({ time, status }) => {
        return {
          text: time,
          desc: status
        }
      })
    }
  },
  // 复制
  onCopy() {
    wx.setClipboardData({
      data: this.data.data.orderNo,
      success: function (res) {}
    })
  }
})
