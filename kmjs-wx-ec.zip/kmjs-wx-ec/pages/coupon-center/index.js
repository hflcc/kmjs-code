// pages/coupon-centre/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
    //轮播图列表
    dataImg: [],
    //tab下标
    active: 0,
    //tab列表
    tabList: [],
    //店铺
    shops: {},
    //商品优惠券
    goods: [],
    //店铺优惠券
    shopCoupon: [],
    //分页
    query:{
      page:0,
      size:10
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTab();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //下拉刷新
  pullUp() {
    this.setData({
      goods: [],
      shops:[]
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getCouponSn()
      this.setData({
        refresherTriggered: false
      })
    })
  },
  //上拉加载
  pullDown() {
    if (this.data.hasData) {
      this.data.query.page += 1
      this.getGoodCoupon()
    }
  },
  getTab() {
    //获取顶部tab
    app.get('/md/common/info/flow/platform/list/category/ticket_center').then(res => {
      if (res) {
        this.setData({
          tabList: res
        });
        this.getCouponSn();
      }
    })
    //获取顶部轮播sn
    app.get('/md/common/info/flow/platform/list/category/ticket_center_banner').then(res => {
      if (res) {
        let bannerSn = res[0].sn;
        this.getBanner(bannerSn)
      }
    })
  },
  //监听tab切换
  onChange(e) {
    let index = e.detail.index;
    this.setData({
      active: index,shops:[],goods:[]
    })
    this.getCouponSn();
  },
  //获取优惠券的sn
  getCouponSn() {
    app.get('/md/common/info/flow/instance/page/def_category_sn/' + this.data.tabList[this.data.active].sn).then(res => {
      if (res&&res.content.length) {
        let shops = {};
        res.content[0].items.forEach(v => {
          shops[v.data.sn] ={ sn : v.data.sn,name:v.data.name,coupon:[]};
          this.getShopCoupon(v.data.sn)
        })
        this.setData({
          shops
        })  
      }
    })
    app.get('/md/common/info/flow/platform/list/category/ticket_center?parentSn=' + this.data.tabList[this.data.active].sn).then(res => {
      if (res&&res.length) {
        this.setData({goodsSn:res[0].sn})
        this.getGoodCoupon()
      }
    })
  },
  //获取店铺优惠券
  getShopCoupon(sn) {
    if (app.globalData.userInfo.token) {
      app.get('/mk/ticket/shop/' + sn).then(res => {
        this.data.shops[sn].coupon = res;
        this.setData({
          shops: this.data.shops
        })
      })
    } else {
      app.get('/mk/common/ticket/shop/' + sn).then(res => {
        this.data.shops[sn].coupon = res;
        this.setData({
          shops: this.data.shops
        })
      })
    }
  },
  //获取商品优惠券
  getGoodCoupon() {
    app.get('/md/common/info/flow/instance/page/def_category_sn/' + this.data.goodsSn,{
      page:this.data.query.page,
      size:this.data.query.size
    }).then(async res => {
      if (res) {
        this.setData({ hasData: !res.last })
        let goodsList;
        goodsList = res.content.map(v => {
          return v.items.length ? v.items[0] : '';
        })
        for (var i = 0; i <= goodsList.length - 1; i++) {
          const [coupon,img] = await Promise.all([
            this.getReceive(goodsList[i].data.ticketSn),
            app.picSnGetUrl(goodsList[i].data.coverImages.length ? goodsList[i].data.coverImages[0].ossId : '')
          ])
          if (coupon&&img) {
            goodsList[i].data.coupon = coupon;
            goodsList[i].data.img = img;
          }
        }
        let goods;
        if (this.data.query.page === 0) {
          goods = []
        } else {
          goods = this.data.goods
        }
        this.setData({
          goods:goods.concat(goodsList)
        })
      }
    })
  },
  //获取商品优惠券是否领取
  getReceive(sn) {
    if (app.globalData.userInfo.token) {
      return new Promise(async (resolve, reject) => {
        const res = await app.get('/mk/ticket/' + sn).then(res => {
          res.num = res.takeNum / res.totalNum * 100;
          return res;
        })
        resolve(res)
      })
    } else {
      return new Promise(async (resolve, reject) => {
        const res = await app.get('/mk/common/ticket/' + sn).then(res => {
          res.num = res.takeNum / res.totalNum * 100;
          return res;
        })
        resolve(res)
      })
    }
  },
  //获取顶部轮播图
  getBanner(sn) {
    app.get('/md/common/info/flow/instance/page/def_category_sn/' + sn).then(async res => {
     if (res) {
      let banner = res.content.map(v => {
        return v.items.length ? v.items[0] : '';
      })
      for (var i = 0; i <= banner.length - 1; i++) {
        banner[i].newImg = await app.picSnGetUrl(banner[i].data.contentImageId.length ? banner[i].data.contentImageId[0] : '')
      }
      this.setData({
        dataImg: banner
      })
     }
    })
  },
   //领取优惠券
  getCP(e){
    let ticketSn = e.detail.sn;
    let received = e.detail.received;
    if (!received) {
      app.post('/mk/ticket/instance/' + ticketSn).then(res=>{
        if (res.success) {
          this.setData({
            goods: [],
            shops:[]
          })
          this.getCouponSn();
        }
      }) 
    }
  },
  goShop(e){
    let sn = e.currentTarget.dataset.sn;
    wx.navigateTo({
      url: '/packageA/pages/shop-home/index?sn='+sn,
    });
  },
  goGoods(e){
    let sn = e.detail;
    wx.navigateTo({
      url: '/pages/goods-detail/index?sn='+sn,
    });
  }
})
