const app = getApp()
const { privacyMobile } = require("../../utils/index")
Page({
  /**
   * 页面的初始数据
   */
  data: {
    addressList: [],
    // 是否含有更多
    hasMore: false,
    // 数据loading
    isLoading: true,
    query: {
      page: 0,
      size: 30
    },
    needBack: ""
  },
  /**
   * 生命周期函数--监听页面加载
   * options.t == 'needback' 需要返回到当前页
   */
  onLoad(options) {
    this.setData({
      needBack: options.t
    })
    this.getaddress()
  },
  // 导入微信地址
  wxAddress(){
    let _that = this
    wx.chooseAddress({
      success: async(res)=>{
        /* res
        {cityName:  "广州市"
        countyName: "海珠区"
        detailInfo: "新港中路397号"
        errMsg: "chooseAddress:ok"
        nationalCode: "510000"
        postalCode: "510000"
        provinceName: "广东省"
        telNumber: "020-81167888"
        userName: "张三" }
        */
        let area = [res.provinceName,res.cityName,res.countyName]
        let id = ''
        let bool = null
        await wx.request({
          method:'get',
          url:`https://apis.map.qq.com/ws/district/v1/search?keyword=${res.countyName}&key=7TXBZ-D43CF-V6XJ6-JMTZ5-3M2CQ-35FCO`,
          success:async (r)=>{
            if(r.statusCode==200){
              if(r.data?.result?.[0].length)
              id = r.data.result[0].find(item=>{
                bool = item.address.split(',').every((k,i)=>{
                  return area[i].indexOf(k) != -1
                })
                return bool && item
              })?.id
              if(id){
                let areaItem = await app.getAreaSn(id)
                let form = {
                  "areaSn": areaItem.sn,
                  "address": res.detailInfo,
                  "pitchOn": null,
                  "name": res.userName,
                  "mobile": res.telNumber
                }
                await app.post('/md/inst/user/address', form).then(res => {
                  if(res){
                    this.init()
                  }
                })
              }else{
                wx.showToast({
                  title: '微信地址导入失败',
                  icon: 'none',
                  duration: 2000
                })
                // wx.navigateTo({
                //   url: `/pages/address-edit/index?t=new`
                // })
              }
            }
          }
        })
      },
      fail: (err) => {
        console.log(err);
        if(err.errMsg != 'chooseAddress:fail cancel' && err.errMsg != 'chooseAddress:cancel'){
          wx.showToast({
            title: err.errMsg,
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
  },
  // 选择并返回上一页
  selectAdd(e) {
    if (this.data.needBack == "needback") {
      let pages = getCurrentPages()
      let beforePage = pages[pages.length - 2]
      // 调用上一页面方法 
      beforePage.changeAddressData(e.detail)
      wx.navigateBack()
    }
  },
  // 去编辑 | 新增
  goedit(e) {
    /**
     * e.detail 组件传值过来
     * e.currentTarget.dataset.v  页面传值过来
     * */
    wx.navigateTo({
      url: `/pages/address-edit/index?t=${e.currentTarget.dataset.v || e.detail.type} ${e.detail.item && e.detail.item.sn ? `&sn=${e.detail.item.sn}` : ""}`
    })
  },
  // 加载更多
  pullDown() {
    if (this.data.hasMore) {
      wx.nextTick(() => {
        this.getaddress()
      })
    }
  },
  //下拉刷新
  pullUp() {
    this.data.addressList = []
    this.data.query = {
      page: 0,
      size: 30
    }
    wx.nextTick(() => {
      this.getaddress()
    })
    this.setData({
      refresherTriggered: false
    })
  },
  // 初始化
  init() {
    this.data.query.page = 0
    this.setData({
      addressList: [],
      hasMore: false,
      isLoading: true
    })
    this.getaddress()
  },
  // 地址数据
  async getaddress() {
    this.setData({
      isLoading: true
    })
    let res = await app.getAddressList(this.data.query)
    if (res.content.length) {
      res.content = res.content.map(item => {
        item.privacyMobile = privacyMobile(item.mobile)
        // 去除多余的换行,只保留一个
        item.address = item.address.replace(/([↵\r\n])\1*/g, '\n');
        return item
      })
    }
    this.data.query.page++
    this.setData({
      hasMore: !res.last,
      addressList: this.data.addressList.concat(res.content),
      isLoading: false
    })
  }
})