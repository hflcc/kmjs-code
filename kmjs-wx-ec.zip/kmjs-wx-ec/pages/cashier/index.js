// pages/cashier/index.js
import { wxToast } from "../../utils/index"

const { formatterMoney } = require("../../utils/index")
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 支付值
    activePayMethods: "",
    // 订单sn （类型为recharge时，sn代表充值金额对应的交易规则sn）
    sn: "",
    // 支付sn
    paySn: "",
    // 收银台数据
    data: {},
    // 支付类型 订单组（group）还是订单(order)
    type: "",
    // 按钮是否可点击
    canSubmit: true,
    /* memberAccountSn、amount 充值状态才有值 */
    // 会员账户sn
    memberAccountSn:'',
    // 充值金额
    amount:'',
    // 订单来源
    source:'',
    //订单数量
    orderCount: '',
    //支付版本,v2、v3
    payVersion: ''
  },

  /**
   * 生命周期函数--监听页面加载
   * @param type {string} 支付类型。 订单组（group）还是订单(order) 充值（recharge）
   */
  onLoad: function ({ sn, paySn, type , memberAccountSn,  amount, source, orderCount, payVersion}) {
    this.setData({
      sn,
      paySn,
      type,
      memberAccountSn,
      amount,
      source,
      orderCount,
      payVersion
    })
    this.getData()
  },
  // 切换支付方式
  onChange({ detail }) {
    this.setData({
      activePayMethods: detail
    })
  },
  // 获取支付信息
  getData() {
    app.get(`/pay/${this.data.paySn}/none`).then(async res => {
      if (res && res.body) {
        res = res.body
        let bannerList = res.payDefitemList.map(({ logo }) => {
          return logo
        })
        bannerList = await app.picSnGetUrl(bannerList)
        this.setData({
          // 设置默认支付方式
          activePayMethods: res.payDefitemList[0].sn,
          // 数据
          data: {
            // 过期时间
            expireAt: res.expireAt * 1000 - new Date().getTime(),
            // 支付价格
            payAmount: formatterMoney(res.payAmount),
            // 支付方式
            payMethods: res.payDefitemList.map(({ name, logo, sn }, index) => {
              return {
                // 支付名称
                name,
                // 支付logo
                logo: bannerList[index],
                // 支付实例
                sn
              }
            })
          }
        })
      }
    })
  },
  // 支付
  async payNow() {
    if (!this.data.canSubmit) return
    this.setData({
      canSubmit: false
    })
    const { sn, type ,memberAccountSn,amount, source, orderCount, payVersion } = this.data
    let { openId } = app.globalData.userInfo
    // 预防openId没有的时候,需要触发;
    if (!openId) {
      const res = await app.get("/sys/user/current/check/integrity")
      if (res) {
        openId = res.wxInfo.openId
      }
    }
    app.post(`/pay/unified/${this.data.paySn}/${this.data.activePayMethods}`, {
      openId
    }).then(res => {
      if (res && res.data) {
        const data = JSON.parse(res.data)
        wx.requestPayment({
          nonceStr: data.nonceStr,
          package: data.pkg,
          paySign: data.sign,
          signType: data.signType,
          timeStamp: data.timeStamp.toString(),
          success(res) {
            if (source === 'payOrder') {//来源支付订单
              if (Number(orderCount) === 1) {//最后一个订单跳转订单列表
                wx.redirectTo({
                  url: `/pages/order-data/index?name=all`
                })
              } else {
                wx.showToast({
                  title: '支付成功',
                  duration: 2000,
                  success() {
                    setTimeout(() => {
                      wx.navigateBack()
                    }, 2000)
                  }
                })
              }
              return
            }
            wx.redirectTo({
              url: `/pages/pay-status-page/index?status=success&type=${type}`
            })
          },
          fail(res) {
            wx.redirectTo({
              url: `/pages/pay-status-page/index?status=fail&sn=${sn}&type=${type}&memberAccountSn=${memberAccountSn}&amount=${amount}&payVersion=${payVersion}`
            })
          }
        })
      } else if (res && res.message) {
        wxToast(res.message)
        this.setData({
          canSubmit: true
        })
      } else {
        this.setData({
          canSubmit: true
        })
      }
    })
  },
  /**
   * 倒计时结束时的回调事件，结束后跳转全部订单列表
   * */
  countDownFinished() {
    wx.reLaunch({
      url: "/pages/self/index?toAll=true"
    })
  }
})
