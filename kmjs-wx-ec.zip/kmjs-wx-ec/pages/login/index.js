import { client_id, client_secret, encode, getWxLoginCode, saveLoginStatus, wxToast } from "../../utils/index"
import { saveInstId } from "../../utils/utils"

const app = getApp()
let loginCode = ""
let timer
Page({
  data: {
    // 加时间戳,避免缓存
    src: "https://kmjs.oss-cn-shenzhen.aliyuncs.com/kmjs-wx-ec-static/logo.png?timer=" + new Date().getTime(),
    // 是否点击过
    isClick: false
  },
  async onLoad(query) {
    loginCode = await getWxLoginCode()
    // 4.5 分钟刷新一次 code;
    timer = setInterval(async () => {
      loginCode = await getWxLoginCode()
    }, 1000 * 60 * 4.5)
  },
  onUnload() {
    clearInterval(timer)
  },
  // 手机号码获取回调
  async phoneNumberCb({ detail }) {
    if (this.data.isClick) {
      return
    }
    this.data.isClick = true
    if (detail.errMsg === "getPhoneNumber:fail user deny") {
      wxToast("用户拒绝了", "error")
      this.data.isClick = false
      return
    }
    if (detail.errMsg !== "getPhoneNumber:ok") {
      this.data.isClick = false
      return
    }
    const { encryptedData, iv } = detail
    await this.login(loginCode, encryptedData, iv)
    this.data.isClick = false
  },
  // 调用登录
  login(code, encryptedData, iv) {
    return new Promise(async (resolve, reject) => {
      // 当前用户是否身份信息
      const result = await app.get("/oauth2/oauth/token", {
        grant_type: "wx_applet",
        scope: "all",
        code,
        encryptedData,
        iv
      }, {
        Authorization: "Basic " + encode(`${client_id}:${client_secret}`)
      })
      if (result) {
        app.globalData.loginData = result
        // 查询机构
        const hasIdentity = await app.get("/md/inst/list/shop", {}, {
          Authorization: result.access_token
        })
        // 如果有机构
        if (hasIdentity && hasIdentity.length > 0) {
          await saveLoginStatus(app, result)
          let hisInstld = hasIdentity.filter(item => item.id == wx.getStorageSync("instId-id"))
          await saveInstId(app, hisInstld.length > 0 ? hisInstld[0] : hasIdentity[0])
          wx.navigateBack()
        } else {
          // 没有机构,调用接口默认创建
          const result = await app.post("/md/inst/register", {
            "type": "shop"
          }, {
            Authorization: app.globalData.loginData.access_token
          })
          if (result) {
            saveLoginStatus(app, app.globalData.loginData)
            await saveInstId(app, result)
            wx.navigateBack({
              fail(e) {
                wx.switchTab({ url: "/pages/self/index" })
              }
            })
          }
        }
      } else {
        loginCode = await getWxLoginCode()
      }
      resolve()
    })
  },
  go(e) {
    /**
     * e.currentTarget.dataset.t==0 用户服务协议
     * e.currentTarget.dataset.t==1 隐私政策
     */
    let url = ""
    if (e.currentTarget.dataset.t == "1") {
      url = "/pages/privacy-policy/index"
    } else {
      url = "/pages/user-agreement/index"
    }
    wx.navigateTo({
      url
    })
  }
})
