// pages/mass-goods/mass-goods.js
const app = getApp()
let query = {
  page: 0,
  size: 20
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    massList: [],
    isLoading: true,
    // 是否含有更多
    lastData: true,
    // 显示规则
    regshow: false,
    sn:'',
    // 顶部图片
    headImg:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function ({sn}) {
    this.setData({sn})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    query = {
      page: 0,
      size: 20
    }
    this.getMassList()
    this.getHeadImg()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 获取顶部图片
  getHeadImg(){
    app.get(`/ec/common/info/flow/${this.data.sn}`).then(async res => {
      let headImg = await app.picSnGetUrl(res.images?.[0]?.ossId,{width: 375, height: 211})
      if(headImg.length){
        this.setData({headImg:headImg[0]})
      }
    })
  },
  // 去详情
  godetail({currentTarget}){
    wx.navigateTo({
      url: `/pages/goods-detail/index?sn=${currentTarget.dataset.sn}`,
    })
  },
  // 显示规则
  reg() {
    this.setData({
      regshow: true
    })
  },
  // 隐藏规则
  close() {
    this.setData({
      regshow: false
    })
  },
  // 加载更多
  pullDown() {
    if (this.data.lastData!=undefined && !this.data.lastData) {
      query.page++
      this.getMassList()
    }
  },
  //下拉刷新
  pullUp() {
    this.data.massList = []
    query = {
      page: 0,
      size: 20
    }
    this.getMassList()
    this.setData({
      refresherTriggered: false
    })
  },
  //获取拼单列表
  async getMassList() {
    this.setData({
      isLoading: true
    })
    app.get(`/ec/common/info/flow/item/page/${this.data.sn}`, query).then(async res => {
      let data = res.content.map(item=>{
        return item.data
      })
      data = await app.groupGoods(data, {width: 200, height: 200})
      this.setData({
        "massList": this.data.massList.concat(data),
        // res.last  false:没有到最后一页  true:是最后一页
        "lastData": res.last,
        "isLoading": false
      })
    })
  },
})