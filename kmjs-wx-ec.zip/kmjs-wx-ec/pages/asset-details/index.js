// pages/asset-details/index.js
const {
  formatterMultidigitMoney,formatterTime
} = require("../../utils/index")
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 胶囊距离顶部
    capsuletop: app.menuBoundingMsg["top"],
    active: 0,
    assignSn:'',
    query: {
      page: 0,
      size: 10
    },
    tabs: [{
        name: "使用记录"
      },
      {
        name: "冻结记录"
      }
    ],
    accountBalance: {},
    accountSn: '',
    records: [],
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
    //余额名称
    assetName:"",
    currencySn:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({assignSn:options.sn,assetName:options.name})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getAssignAccount()
  },

  //下拉刷新
  pullUp() {
    this.setData({
      records: [],
      active: 0
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getAssignAccount()
      this.setData({
        refresherTriggered: false
      })
    })
  },
  //上拉加载
  pullDown() {
    if (this.data.hasMore) {
      this.data.query.page += 1
      this.getRecord()
    }
  },
  getAssignAccount() {
    app.get('/mk/member/account/sn/' + this.data.assignSn).then(res => {
      res.balance = formatterMultidigitMoney(res.balance);
      res.flexibleAmount = formatterMultidigitMoney(res.flexibleAmount);
      res.frozenAmount = formatterMultidigitMoney(res.frozenAmount);
      this.setData({
        accountBalance: res,
        accountSn: res.sn,
        currencySn:res.currencySn
      });
      this.getRecord();
    });
  },
  setTabs({
    currentTarget
  }) {
    this.data.query.page = 0;
    let index = currentTarget.dataset.index;
    this.setData({
      active: index,
      records:[]
    });
    this.getRecord();
  },
  goDetail({
    currentTarget
  }) {
    let sn = currentTarget.dataset.sn;
    let index = currentTarget.dataset.index;
    wx.navigateTo({
      url: `/pages/use-details/index?sn=${sn}&index=${index}`
    });
  },
  getRecord() {
    this.setData({
      isLoading: true
    })
    if (this.data.active === 0) {
      app.get('/mk/member/account/item/flow/page/use/' + this.data.accountSn, {
        page: this.data.query.page,
        size: this.data.query.size
      }).then(res => {
        if (res.content) {
          res.content.forEach(v => {
            v.amount = formatterMultidigitMoney(v.amount)
            v.createdAt = formatterTime(v.createdAt*1000)
            v.currentAmount = formatterMultidigitMoney(v.currentAmount)
          })
          let records;
          if (this.data.query.page === 0) {
            records = []
          } else {
            records = this.data.records
          }
          this.setData({
            records: records.concat(res.content),
            "hasMore": !res.last,
            isLoading: false
          })
        }
      })
    } else if (this.data.active === 1) {
      app.get('/mk/member/account/item/flow/page/frozen/' + this.data.accountSn, {
        page: this.data.query.page,
        size: this.data.query.size
      }).then(res => {
        if (res.content) {
          res.content.forEach(v => {
            v.amount = formatterMultidigitMoney(v.amount)
            v.createdAt = formatterTime(v.createdAt*1000)
          })
          let records;
          if (this.data.query.page === 0) {
            records = []
          } else {
            records = this.data.records
          }
          this.setData({
            records: records.concat(res.content),
            "hasMore": !res.last,
            isLoading: false
          })
        }
      })
    }
  },
  goBack() {
    wx.navigateBack({
      delta: 1
    })
  },
  // 充值按钮
  rechargeBtn(){
    wx.navigateTo({url:`/pages/recharge/index?sn=${this.data.currencySn}&memberAccountSn=${this.data.assignSn}`})
  }
})