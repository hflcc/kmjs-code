import { formatterMoney, wxToast } from "../../utils/index"
import Dialog from "@vant/weapp/dialog/dialog"
import { goodsCoupon, goodsDetail, groupBuy } from "./goodsDetail"

const app = getApp()
let query = {
  page: 0,
  size: 30
}
// parentSn: [childrenSN]
const specMap = {}
let shopSn = ""
// let flag = true
Page({
  data: {
    // 轮播列表
    bannerList: [],
    // 商品详情
    goodDetail: "",
    // 展示的价格列表
    showPriceList: [],
    // 真实计算购买价格的数据
    prices: [],
    // 商品名称
    goodsName: "",
    // 商铺sn
    shopSn: "",
    // 商品sn
    goodsSn: "",
    // 商品的拼团sn
    bizEcComposeDefSn: "",
    // 商品类型
    // normal: 普通商品;
    // ticket: 美罗帮扶=》 mbh：美博会 mlbf:美萝帮扶
    // compose: 拼团;
    goodActiveType: "",
    // 拼团文字
    groupText: "",
    // 是否拼团商品
    isGroupBuys: false,
    // 是否展示商品规格的选择
    show: false,
    // 已选列表
    selectList: [],

    //优惠券列表
    couponList: [],
    // 新人优惠券
    newcoupon: false,
    // 新人优惠券列表
    newCouponList: [],
    // 活动优惠券类型，根据商品promotePrices.type判断
    // mbh: 美博会;
    // mlbf: 美罗帮扶;
    couponType: '',

    // 是否显示更多拼团
    showMoreGroupbuy: false,
    // 全部拼团
    allNowGroupbuyList: [],
    // 前五拼团
    fivenowGroupbuyList: [],
    // 拼团总数
    groupTotal:0,
    // 商品分享数据
    shareData: {},
    // 加入拼团的记录
    joingroup: {},

    // 商品类型  groupBuy:团购
    // goodstype: "",
    // addShopList:添加进货单， buyNow:立即购买,  backDetail：点击已选， originalPrice：原价购买，groupPrice：发起拼团
    showSpecType: "",
    // 默认地址sn
    defaultAreaSn: "",
    // 物流提示
    hintText: "",
    // 物流提示描述
    hintTextDesc: "",
    // 商品信息
    goodsList: {},
    // 店铺信息
    shops: [],
    // 传入商品规格的信息
    buyGoods: {},
    // 是否查看所有的sku
    checkedAllSku: true,
    // 广告
    ad: [],
    // 选择了的文本信息
    selectedTextList: [],
    // 用于买点的sn
    bizEcGoodsId: "",
    // 规格列表
    specList: [],
    // 子集的tab
    activeTabs: "",
    // 接受地址信息
    addressData: {},
    // 格式后地址
    address: "",
    //是否收藏
    collectShow: false,
    // 显示分享面板
    showShare: false,
    // 显示分享海报
    showPoster: false,
    // 小程序码
    ewmImg: "",
    // 分享选择器
    shareOptions: [
      {
        name: "分享给好友",
        type: "base",
        openType: "share",
        icon: "http://resource.kmyun.cn/haopinggo/wx.png"
      },
      {
        name: "生成分享海报",
        type: "poster",
        icon: "http://resource.kmyun.cn/haopinggo/poster.png"
      }
    ],
    //更多优惠券弹窗
    couponShow: false,
    //使用说明弹窗
    explainShow: false,
    // 是否刷新中
    refresherTriggered: false,
    // 数据loading
    isLoading: true,
    // 是不是最后一页
    lastpage: true,
    coverOssId: '',
    isShowService: false // 是否显示客服
  },
  // 显示更多拼团
  gogroupbuyMore() {
    this.setData({
      showMoreGroupbuy: true
    })
  },
  // 隐藏更多拼团
  onGroupbuyHide() {
    this.setData({
      showMoreGroupbuy: false
    })
  },
  // 关闭新人优惠券
  closecp() {
    this.setData({
      newcoupon: false
    })
  },
  // 关闭图片
  closePoster() {
    this.setData({
      showPoster: false
    })
  },
  // 保存图片
  savePoster() {
    const _self = this
    wx.getSetting({
      withSubscriptions: true,
      success(res) {
        if (res.authSetting["scope.writePhotosAlbum"] === false) {
          wx.openSetting({
            success(data) {
              console.log("成功", data)
            },
            fail(err) {
              console.log("失败", err)
            }
          })
        } else {
          _self.selectComponent("#canvas").saveImage()
        }
      }
    })
  },
  // 分享面板
  changeShowShare() {
    this.setData({
      showShare: !this.data.showShare
    })
  },
  // 选择分享类型
  shareTypeSelect({ detail }) {
    this.setData({
      showShare: false
    })
    if (detail.type == "base") {

    } else if (detail.type == "poster") {
      this.setData({
        "shareData.shareImg": this.data.ewmImg,
        showPoster: true
      })
    }
  },
  // 获取小程序码
  async ewm() {
      let img = await app.get(`/wx/common/applet/code?scene=${this.data.goodsSn}&page=pages/goods-detail/index`)
      this.setData({
        ewmImg: img.imgBase64
      })
    // console.log('data:image/png;base64,'+this.data.ewmImg);
  },
  // 页面分享
  onShareAppMessage() {
    const { title, desc, imageUrl, path } = this.data.shareData
    return { title, desc, imageUrl, path }
  },
  onShareTimeline:function (e) {
    const { title, imageUrl } = this.data.shareData
    return { title, imageUrl }
  },
  async onLoad(options) {
    const sceneSn = decodeURIComponent(options.scene)
    this.setData({
      goodsSn: options.sn || sceneSn,
      // goodsSn: '8c3a6bcfc03240d9990f9eceafe23b43', // 活动商品
      // goodsSn: '80b1032f70f44ae499867a3b3011ddad', // 拼团商品
      // goodsSn: '7f74aefdc1ae426db4c18141f55c3046', // 普通商品
    })
    Promise.all([
      // 获取商品基本信息
      goodsDetail(this.data.goodsSn, app),
      // 拼团信息
      // groupBuy(options.sn || scene.sn, app),
      // 增加浏览量
      this.addPv()
      // 查看拼团总数
      // this.getGroupTotal()
    ]).then(([[prices, baseInfo, bannerList, shops, activeType, coverOssId], groupBuy]) => {
      this.setData({
        // 基本信息
        bannerList,
        ...baseInfo,
        ...prices,
        shops,
        // 拼团
        ...groupBuy,
        coverOssId,
        // 活动优惠券类型
        couponType: activeType
      })
      // 获取优惠券列表
      goodsCoupon(this.data.sn, this.data.shopSn, app).then(coupons => {
        this.setData({
          // 优惠券
          ...coupons
        })
      })
      // 检查是否有配置客服
      this.checkService(this.data.shopSn)
    })
    // 删除地址的回调
    wx.WHENADDRESSDELETE = (sn) => {
      if (this.data.defaultAreaSn === sn) {
        this.setData({
          defaultAreaSn: "",
          addressData: {},
          address: ""
        })
      }
    }
  },
  // 检查是否有配置客服
  checkService(sn) {
    if (!sn) {
      return
    }
    app.post(`/mk/common/csc/client/check`, {
      "scopeType": "shop",
      "scopeValue": sn,
      "from": "minapp",
      "source": "耗品GO"
    }).then(res => {
      this.setData({isShowService: res.success})
    })
  },
  onShow() {
    this.init()
    this.ewm();
    // 是否收藏商品
    this.getCollect()
    // 地址初始化
    if (!this.data.address) {
      this.initAddress()
    }
    this.getDeliver(this.data.goodsSn, this.data?.addressData?.areaSn || "")
    this.groupBuyPromise()
    this.getGroupTotal()
  },
  // 拼团Primise
  groupBuyPromise(){
    this.setData({
      isLoading: true
    })
    //拼团
    Promise.all([
      // 拼团信息
     groupBuy(this.data.goodsSn, query, app)
      // 查看拼团总数
   ]).then(([{allNowGroupbuyList,...groupBuy}]) => {

     this.setData({
      allNowGroupbuyList:this.data.allNowGroupbuyList.concat(allNowGroupbuyList),
       // 拼团
       ...groupBuy
     })
   })
  },
  // 初始化地址
  initAddress() {
    if (!this.data.address) {
      let region = app.globalData.userAddress
      let address = ""
      if (region && region.area) {
        address = (app.area(region.area) ? app.area(region.area) : "") + (region.address ? region.address : "")
      }
      this.setData({
        defaultAreaSn: region && region.sn ? region.sn : "",
        addressData: region,
        address: address
      })
    }
  },
  // 必须提供此方法让地址页调用
  changeAddressData(res) {
    let areaSn = res.areaSn
    this.getDeliver(this.data.goodsSn, areaSn)
    this.setData({
      defaultAreaSn: res.sn,
      addressData: res,
      address: (app.area(res.area) ? app.area(res.area) : "") + (res.address ? res.address : "")
    })
  },
  // 获取物流信息
  async getDeliver(shopSn, areaSn) {
    areaSn = areaSn ? "/0/" + areaSn : ""
    app.get(`/ec/common/deliver/goods/${shopSn}${areaSn}`).then(res => {
      if (res) {
        res = res[0]
        let hintText = "", hintTextDesc = ""
        if (res.deliverAmount === 0) {
          hintText = "快递包邮"
          hintTextDesc = "快递包邮"
        } else {
          hintTextDesc += `运费计算:首费${res.defaultNum}件${formatterMoney(res.defaultAmount)}\n`
          hintTextDesc += `每增重${res.addNum}件,增加运费${formatterMoney(res.addAmount)}`
          hintText = `快递￥${formatterMoney(res.defaultAmount)}`
        }
        this.setData({
          hintText,
          hintTextDesc
        })
      }
    })
  },
  /*
  * addShopList: 添加进货单
  * buyNow: 立即购买
  * backDetail: 点击已选
  * originalPrice: 原价购买
  * openGroup: 发起拼团
  * joinGroup: 加入拼团
  * */
  buyNow(e) {
    const { type, joingroup, sn } = e.currentTarget.dataset
    switch (type) {
      case "addShopList":
      case "buyNow":
      case "backDetail":
      case "originalPrice":
      case "openGroup":
      case "joinGroup":
        if (app.loginJump()) {
          let setData = {}
          // 加入拼团的时候,需要记录加入谁的
          if (type === "joinGroup") {
            //点击加入拼团时候 判断该团是否有效
            app.get('/ec/common/compose/instance/check/'+sn).then(res=>{
              if (res.flag) {
                setData = {
                  joingroup:joingroup,
                  showSpecType:type,
                  show:true
                }
                this.setData(setData)
              } else {
                setData = {
                    show:false
                  }
                this.setData(setData)
                Dialog.alert({
                  message: res.failName
                }).then(() => {
                  this.groupBuyPromise()
                  this.getGroupTotal()
                });
              }
            })
          } else {
            setData = {
              showSpecType: type,
              show: true
            }
            this.setData(setData)
          }
        }
    }
  },
  // 确认订单
  submitOrder({ detail }) {
    const { type, result } = detail
    const { joingroup, goodsSn, bizEcComposeDefSn } = this.data
    console.log(type, 'goods-detail type')
    console.log(result, 'goods-detail result')
    switch (type) {
      case "buyNow":
        this.postOrder(result)
        break
      case "originalPrice":
        this.postOrder(result)
        break
      case "addShopList":
        this.addShopCard(result)
        break
      case "openGroup":
        if (bizEcComposeDefSn) {
          this.openGroupFn(bizEcComposeDefSn, {
            goodsSn,
            composeGoods: result.map(({ skuSn: bizEcGoodsSkuSn, quantity: num }) => ({
              bizEcGoodsSkuSn,
              num
            }))
          })
        }
        break
      case "joinGroup":
        if (joingroup.instanceSn) {
          this.joinGroupFn(joingroup.instanceSn, {
            goodsSn,
            composeGoods: result.map(({ skuSn: bizEcGoodsSkuSn, quantity: num }) => ({
              bizEcGoodsSkuSn,
              num
            }))
          })
        }
        break
    }
    this.close()
  },
  // 独立开团
  openGroupFn(composeDefSn, data) {
    app.post(`/ec/compose/instance/${composeDefSn}`, data).then(res => {
      if (res) {
        const sns = res.map(item => item.sn).join(',')
        wx.navigateTo({
          url: `/pages/submit-order/index?type=group&sn=${sns}`
        })
      }
    })
  },
  // 加入拼团
  joinGroupFn(instanceSn, data) {
    app.post(`/ec/compose/instance/join/${instanceSn}`, data).then(res => {
      if (res) {
        const sns = res.map(item => item.sn).join(',')
        wx.navigateTo({
          url: `/pages/submit-order/index?type=group&sn=${sns}`
        })
      }
    })
  },
  //效验该用户是否有权限
  buyPermissions(data) {
    return new Promise((resolve, reject) => {
      app.post(`/ec/cart/check/${this.data.goodsSn}`, data).then(res => {
        if (res.success) {
          resolve(data)
        } else {
          resolve(res.items)
        }
      })
    })
  },
  // 加入购物车
  async addShopCard(data) {
    data = await this.buyPermissions(data)
    app.post(`/ec/cart/${this.data.goodsSn}`, data).then(res => {
      if (res) {
        wxToast("加入成功")
        this.close()
      }
    })
  },
  // 立即购买
  async postOrder(data) {
    data = await this.buyPermissions(data)
    app.post(`/ec/order/${this.data.goodsSn}?addressSn=${this.data.defaultAreaSn}`, data).then(res => {
      if (res) {
        wx.navigateTo({
          url: `/pages/submit-order/index?type=group&sn=${res[0].sn}`
        })
      }
    })
  },
  // 关闭 sku弹窗时会触发
  close() {
    this.setData({
      show: false,
      selectList: this.selectComponent("#selectCount")?.getSelectList(),
      joingroup: {}
    })
  },
  // 物流提示
  hint() {
    Dialog.alert({
      title: "运费详情",
      message: this.data.hintTextDesc
    })
  },
  // 进店看看
  goShop() {
    const sn = this.data.shops[0].sn
    wx.navigateTo({
      url: "/packageA/pages/shop-home/index?sn=" + sn
    })
  },
  // 进货单
  goPurchaseList() {
    wx.switchTab({
      url: "/pages/purchase-list/index"
    })
  },
  // 收藏功能
  collect() {
    if (this.data.collectShow) {
      app.del("/md/inst/user/follow/cancel/goods/" + this.data.goodsSn).then(res => {
        if (res.success) {
          this.getCollect()
          wxToast("取消收藏成功")
        }
      })
    } else {
      app.post("/md/inst/user/follow/goods/"+this.data.goodsSn, { bodyTitle:this.data.goodsName, source: "home" }).then(res => {
        if (res.success) {
          this.getCollect()
          wxToast("收藏成功")
        }
      })
    }
  },
  // 是否收藏
  getCollect() {
    if (app.globalData.userInfo.token) {
      app.get("/md/inst/user/follow/valid/goods/" + this.data.goodsSn).then(res => {
        if (Array.isArray(res)) {
          this.setData({ collectShow: res.length>0 })
        }
      })
    }
  },
  // 跳转地址
  address() {
    if (app.loginJump()) {
      wx.navigateTo({
        url: "/pages/address/index?t=needback"
      })
    }
  },
  //增加浏览量
  addPv() {
    if (app.globalData.userInfo.token) {
      app.post(`/assist/inst/user/browse/goods/${this.data.goodsSn}`)
    } else {
      app.post(`/assist/common/inst/user/browse/goods/${this.data.goodsSn}`)
    }
  },
  // 打开更多优惠券
  goCoupon() {
    this.setData({ couponShow: true })
  },
  // 关闭更多优惠券
  onClose() {
    this.setData({ couponShow: false })
  },
  // 关闭说明
  closeExplain() {
    this.setData({ explainShow: false })
  },
  // 打开说明
  getRule() {
    this.setData({ explainShow: true })
  },
  //领取优惠券
  getCP(e) {
    let ticketSn = e.detail.sn
    let received = e.detail.received
    if (!received) {
      app.post("/mk/ticket/instance/" + ticketSn).then(res => {
        if (res.success) {
          goodsCoupon(this.data.sn, this.data.shopSn, app).then(coupons => {
            this.setData({
              // 优惠券
              ...coupons
            })
          })
          setTimeout(() => {
            wxToast("领取成功")
          }, 100)
        }
      })
    }
  },
   // 查看拼团总数
  getGroupTotal(){
    app.get(`/ec/common/compose/instance/total/${this.data.goodsSn}`).then(res=>{
      if(res){
        this.setData({
          groupTotal:res.num
        })
      }
    })
  },
  init(){
    this.setData({
      allNowGroupbuyList:[],
      fivenowGroupbuyList:[]
    })
    query = {
      page: 0,
      size: 30
    }
  },
  // 加载更多
  pullDown() {
    if (this.data.lastpage!=undefined && !this.data.lastpage) {
      query.page++
      this.groupBuyPromise()
    }
  },
   //下拉刷新
   pullUp() {
    this.init()
     //拼团
    this.groupBuyPromise()
    // this.groupBuy()
    // this.getGroupTotal()
    this.setData({
      refresherTriggered: false
    })
  },
  // 跳转到商家客服
  toService() {
    const {shopSn, shops, showPriceList, goodsName, goodsSn, coverOssId} = this.data
    const prices = showPriceList.map(item => item.minPrice)
    // 价格取最小的
    const price = ['￥' + Math.min.apply(null, prices)]

    const params = encodeURIComponent(JSON.stringify({
      sn: goodsSn,
      price: price,
      image: coverOssId,
      name: goodsName
    }))
    const title = shops[0]?.title || ''
    wx.navigateTo({
      url: `/packageB/pages/tim/tim?sn=${shopSn}&title=${title}&shopInfo=${params}`
    })
  }
})
