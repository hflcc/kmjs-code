// 获取商品基本信息
const { formatterMoney, formatterTime, scopeType, WXINFO, formatterToChinesNum } = require("../../utils/index")

// 格式化商品
export function goodsDetail(goodsSn, app) {
  return new Promise((resolve, reject) => {
    let query = [
      // 详情
      app.get(`/ec/common/inst/goods/shop_goods/${goodsSn}`),
      // 阶梯价
      app.get(`/md/common/inst/goods/${goodsSn}/step/price/summary`),
    ]
    Promise.all(query).then(([detail, ladderPrice]) => {
      // 活动优惠券类型，显示权益券的时候用，原优惠券字段ticketType不作为判断依据
      const activeType = detail.promotePrices && detail.promotePrices.activeType || ''
      if (!detail || !ladderPrice) {
        resolve([])
      }
      // 商品名称
      const goodsName = detail.name
      let coverOssId = ''
      if (detail.coverImages) {
        coverOssId = detail.coverImages[0]?.ossId
      }
      Promise.all([
        formatterPrice(detail, ladderPrice),
        formatterRichAndGoodBasic(detail),
        formatterBannerList(detail, app),
        formatterShop(detail, app)
      ]).then(([prices, baseInfo, bannerList, shops]) => {
        baseInfo.shareData = formatterShareData(prices, baseInfo, bannerList, goodsSn, app)
        resolve([prices, baseInfo, bannerList, shops, activeType, coverOssId])
      })
    })
  })
}

// 格式化分享数据
function formatterShareData(prices, baseInfo, bannerList, goodsSn, app) {
  const shareData = {
    title: baseInfo.goodsName,
    desc: baseInfo.goodsName,
    imageUrl: bannerList.length > 0 ? bannerList[0].newImg : "",
    path: "/pages/goods-detail/index?sn=" + goodsSn,
    maxPrice: 0,
    minPrice: 0,
    salePrice: 0,
    saleHeadImg: app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.headimgUrl?wx.getStorageSync(WXINFO).headimgUrl:"https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/hpglogo-1624413363473.png",
    saleHeadName: app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.nickName?wx.getStorageSync(WXINFO).nickName:"耗品GO",
    peopleNum: baseInfo.targetNum,
  }
  if (Array.isArray(prices.showPriceList) && prices.showPriceList.length > 0) {
    const first = prices.showPriceList[0]
    const last = prices.showPriceList[prices.showPriceList.length - 1]
    shareData.maxPrice = first.maxPrice
    shareData.minPrice = last.minPrice
    shareData.salePrice = ((shareData.maxPrice * 100 - shareData.minPrice * 100) / 100).toFixed(2)
  }
  return shareData
}

// 格式化价格
/**
 *
 * @param {object} detail  详情
 * @param {array} ladderPrice 阶梯价
 */
function formatterPrice(detail, ladderPrice) {
  return new Promise((resolve, reject) => {
    let { skus } = detail
    // 展示的列表价格数据
    const showPriceList = []
    if(ladderPrice.length){
      // 找到阶梯价中的最低价
      const lowPrice = ladderPrice.reduce((total, cur) => {
        if (total === 0 || cur.minPrice < total) {
          total = cur.minPrice
        }
        return total
      }, 0)
      ladderPrice.forEach(item => {
        const { min, max, minPrice, maxPrice } = item
        showPriceList.push({
          min,
          max,
          minPrice: formatterMoney(minPrice),
          maxPrice: formatterMoney(maxPrice),
          assistPrice: (detail?.promotePrices?.price && formatterMoney(detail.promotePrices.price)) || "",
          activeType: detail.discountType,
          originalPrice: formatterMoney(lowPrice)
        })
      })
    }else{
        let minPrice=0, maxPrice=0, min=0, max=0, originalPrice=0
        skus.forEach(item => {
            // 如果有团购价格取团购价
            let boo = !item.activePrice && item.activePrice !== 0
            let p = boo ? item.price : item.activePrice
            min = Math.min(min || item.minNum,item.minNum)
            max = Math.max(max || item.maxNum,item.maxNum)
            minPrice = Math.min(minPrice || p,p)
            maxPrice = Math.max(maxPrice || p,p)
            if(!boo){
              originalPrice = Math.min(originalPrice || item.price, item.price)
            }
        })
        showPriceList.push({
          min,
          max,
          minPrice:formatterMoney(minPrice),
          maxPrice:formatterMoney(minPrice),
          originalPrice:formatterMoney(originalPrice),
          // assistPrice: detail.promotePrices && detail.promotePrices[0] && detail.promotePrices[0].price && formatterMoney(detail.promotePrices[0].price) || ""
          assistPrice: (detail?.promotePrices?.price && formatterMoney(detail.promotePrices.price)) || ""
        })
    }
    resolve({ showPriceList })
  })
}

// 富文本商品详情|商品基础信息
function formatterRichAndGoodBasic(detail) {
  return new Promise((resolve, reject) => {
    const { name, details } = detail
    // 富文本
    let goodDetail = details && details.context ? details.context : ""
    if (goodDetail) {
      goodDetail = goodDetail.replace(/<img/g, "<img style='width: 100%;height: auto;display: block;margin:0px auto;'")
      goodDetail = goodDetail.replace(/style=""/g, "")
    }
    resolve({
      // 商品名称
      goodsName: name,
      // 商铺sn
      shopSn: detail.shop.sn,
      // 商品类型:如果是ticket类型，就要去 detail.promotePrices.activeType
      goodActiveType: detail.discountType === 'ticket' ? detail.promotePrices?.activeType : detail.discountType,
      // 商品的拼团sn
      bizEcComposeDefSn: detail.discountType === 'compose' ? detail?.composeDefSn : '',
      // 拼团文字
      // groupText: detail.goodActiveType === "compose" ? formatterToChinesNum(detail?.promotePrices?.targetNum) + "人团" : "",
      groupText: detail.discountType === 'compose' ? detail?.composeTypeValue + '人团' : '',
      targetNum: detail?.composeTypeValue,
      // 富文本信息
      goodDetail,
      sn: detail.sn
    })
  })
}

// 格式化轮播图
function formatterBannerList(detail, app) {
  return new Promise(async (resolve, reject) => {
    let bannerList = detail.banners.map(item => {
      return item.ossId
    })
    bannerList = await app.picSnGetUrl(bannerList, {width: 750, height: 550})
    bannerList = bannerList.map(item => {
      return {
        newImg: item
      }
    })
    resolve(bannerList)
  })
}

// 格式化商铺
function formatterShop(detail, app) {
  return new Promise(async (resolve, reject) => {
    let shops = [detail.shop]
    shops = await app.formatterShops(shops)
    resolve(shops)
  })
}

// 获取商品优惠券基本信息
export function goodsCoupon(goodsSn, shopSn, app) {
  return new Promise((resolve, reject) => {
    if (app.globalData.userInfo.token) {
      Promise.all([
        // 新人优惠券
        app.checkNewCoupon(),
        // 个人优惠券
        app.post(`/mk/ticket/goods/${goodsSn}`, {shopSns: [shopSn]})
      ]).then(([newCouponList, couponList]) => {
        let newCoupon = false
        if (Array.isArray(newCouponList) && newCouponList.length > 0) {
          newCouponList.forEach(item => {
            item.scopeNmae = scopeType[item.scopeType]
            item.endATString = formatterTime(item.endAt * 1000, "YMD", ".")
            item.startATString = formatterTime(item.startAt * 1000, "YMD", ".")
          })
          newCoupon = true
        } else {
          newCouponList = []
        }
        if (couponList) {
          couponList = couponList.map(item => {
            item.endATString = formatterTime(item.endAt * 1000, "YMD", ".")
            item.startATString = formatterTime(item.startAt * 1000, "YMD", ".")
            return item
          })
        }
        resolve({
          newCoupon,
          newCouponList,
          couponList
        })
      })
    } else {
      app.post(`/mk/common/ticket/goods/${goodsSn}`, {shopSns: [shopSn]}).then(res => {
        let couponList = res.map(item => {
          item.endATString = formatterTime(item.endAt * 1000, "YMD", ".")
          item.startATString = formatterTime(item.startAt * 1000, "YMD", ".")
          return item
        })
        resolve({
          newCoupon: false,
          newCouponList: [],
          couponList
        })
      })
    }
  })
}

// 获取拼团数据
export function groupBuy(goodsSn, query, app) {
  return new Promise((resolve, reject) => {
    Promise.all([
      app.get(`/ec/common/compose/instance/goods/${goodsSn}`,query)
    ]).then(async ([groupBuyList]) => {
      let lastpage = true
      if (groupBuyList) {
        // 是否最后一页
        lastpage = groupBuyList.last
        // 拼团列表
        groupBuyList = groupBuyList.content
        // 图片列表
        let imgList = groupBuyList.map(item => {
          return item.headImgUrl
        })
        // 批量拉取图片
        imgList = await app.picSnGetUrl(imgList,{ width: 50, height: 50 })
        groupBuyList.forEach(({ headImgUrl }, index) => {
          // 塞入图片
          groupBuyList[index].headImg = imgList[index]
          // 塞入时间
          groupBuyList[index].time = (groupBuyList[index].expireAt - Math.round(new Date().getTime() / 1000)) * 1000
        })
        return resolve({
          // 是否展示全量的拼团
          // showMoreGroupbuy: false,
          // 全部拼团列表
          allNowGroupbuyList: groupBuyList,
          // 前五条拼团
          fivenowGroupbuyList: groupBuyList.slice(0, 5),
          isLoading: false,
          lastpage
        })
      }
      return resolve({
        // 是否展示全量的拼团
        // showMoreGroupbuy: false,
        // 全部拼团列表
        allNowGroupbuyList: [],
        // 前五条拼团
        fivenowGroupbuyList: [],
        isLoading: false,
        lastpage
      })
    })
  })
}

// 商品详情数据
export function formatterDialogData(goodsSn, app) {
  return new Promise((resolve, reject) => {
    Promise.all([
      app.get(`/ec/common/inst/goods/shop_goods/${goodsSn}`),
      app.get(`/md/common/inst/goods/${goodsSn}/step/price/summary`),
      app.get(`/mk/ticket/instance/check/current/${'goods'}/${goodsSn}/${'qy'}`)
    ]).then(async ([detail, ladderPrice,couponType]) => {
      if (!detail || !ladderPrice) {
        resolve([])
      }
      const result = {
        data: {
          // 商品图片
          pic: "",
          // 商品名称
          name: detail.name,
          // 展示的价格
          priceList: [],
          // 是否阶梯价
          isTieredPricing: ladderPrice.length > 0,
          // sku列表
          skuList: []
        },
        // 是否展示全部数据
        checkedAllSku: false,
        // 规格列表
        specList: [],
        // 选中的分类
        activeTabs: "",
        // 商品类型
        goodActiveType: detail.discountType,
        // 活动优惠券类型，显示权益券的时候用，原优惠券字段ticketType不作为判断依据
        activeType : detail.promotePrices && detail.promotePrices.activeType || '',
        // 优惠价
        assistPrice: (detail?.promotePrices?.price && formatterMoney(detail.promotePrices.price)) || "",
        // 是否领取:takeFlag 是否使用:useFlag
        holdCouponType:couponType
      }
      //#region 商品图标
      if (detail.cover && detail.cover.ossId) {
        let pic = await app.picSnGetUrl(detail.cover.ossId)
        result.data.pic = pic[0]
      }
      //#endregion

      // 计算展示的价格
      if (detail.discountType === 'active') {
        const activePriceRes = await app.get(`/ec/common/inst/goods/promote/price/${goodsSn}`)
        if (activePriceRes) {

        }
      } else {
        if (!ladderPrice.length) {
          let minPrice, maxPrice, min, max
          detail.skus?.forEach(item => {
            if (!min) {
              min = item.minNum
            }
            if (!max) {
              max = item.maxNum
            }
            if (!minPrice && !maxPrice) {
              minPrice = formatterMoney(item.price)
              maxPrice = formatterMoney(item.price)
            } else if (minPrice > item.price) {
              minPrice = formatterMoney(item.price)
            } else if (maxPrice < item.price) {
              maxPrice = formatterMoney(item.price)
            }
          })
          result.data.priceList = [{
            min,
            max,
            minPrice,
            maxPrice
          }]
        } else {
          result.data.priceList = ladderPrice.map(({ min, max, minPrice, maxPrice }) => {
            return {
              min,
              max,
              minPrice: formatterMoney(minPrice),
              maxPrice: formatterMoney(maxPrice)
            }
          })
        }
      }

      let { specs, skus } = detail

      // 这里处理新sku接口的规格列表
      result.specsList = handleSpecsList(specs, skus)
      // 处理sku,添加前端自定义字段,方便后续取值
      handleSkus(skus, detail);
      result.data.skuList = skus;

      resolve({
        result,
        detail
      })
    })
  })
}

function handleSkus(skus = [], detail = {}) {
  skus?.forEach(item => {
    // 前端给sku加入自定义字段,方便模板字符串中取值, 用来绑定sku填写的数量
    item._writeCount = 0;
    item._disablePlus = false;
    // 如果有阶梯价,取阶梯价中的第一个价格,没有就取sku的价格和sn
    if (item.stepPrices?.length) {
      item._actualPrice = formatterMoney(item.stepPrices[0]?.price)
      item._actualPriceSn = item.stepPrices[0]?.sn
      item._actualPriceType = 'step'
    } else {
      item._actualPrice = formatterMoney(item.price)
      item._actualPriceSn = item.sn
      item._actualPriceType = 'sku'
    }
  })
}

/**
 * @info 处理规格展示列表(处理成树结构)
 * @param specs {Array} 后台返回的规格
 * @param skus {Array} 后台返回的sku数组
 * @return {Array} Array({ name: string; sn: string; twoList?: Array({}); threeList?: Array({}) })
 * */
function handleSpecsList(specs = [], skus = []) {
  if (!specs?.length || !skus?.length) {
    return []
  }
  const oneList = []
  specs[0].children.forEach(item => {
    oneList.push({ name: item.name, sn: item.sn })
  })
  // 寻找一级菜单下的子菜单
  oneList.forEach(elemOne => {
    const twoMenuSn = []
    // 从sku集合寻找关于一级菜单相关的sn, 除了它自己本身
    skus.forEach(sku => {
      if (sku.specSns && sku.specSns.includes(elemOne.sn)) {
        twoMenuSn.push(...sku.specSns.filter(sn => sn !== elemOne.sn))
      }
    })
    // 寻找二级菜单
    if (specs.length >= 2) {
      // 二级菜单遍历一级菜单结果
      const twoList = []
      specs[1]?.children?.forEach(elemTwo => {
        if (twoMenuSn.includes(elemTwo.sn)) {
          twoList.push({ name: elemTwo.name, sn: elemTwo.sn })
        }
      })
      elemOne.twoList = twoList;

      // 尝试寻找三级目录
      if (specs.length >= 3) {
        twoList.forEach(elemTwo => {
          const threeList = []
          specs[2]?.children?.forEach(elemThree => {
            const hasThree = skus.reduce((bool, cur) => {
              const temp = cur.specSns || []
              bool = temp.includes(elemTwo.sn) && temp.includes(elemOne.sn) && temp.includes(elemThree.sn)
              return bool
            }, false)
            if (hasThree) {
              threeList.push({ name: elemThree.name, sn: elemThree.sn })
            }
          })
          elemTwo.threeList = threeList
        })
      }
    }
  })
  return oneList
}
