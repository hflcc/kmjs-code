import { saveInstId } from "../../utils/utils"

const app = getApp()
Page({
  data: {
    // 身份列表
    lists: []
  },
  onLoad: function (options) {

  },
  onShow() {
    this.getList()
  },
  // 获取列表
  async getList() {
    const lists = await app.get("/md/inst/list/shop")
    this.setData({
      lists
    })
  },
  // 新增身份
  addId() {
    wx.navigateTo({
      url: "/pages/create-organization/index"
    })
  },
  // 选择了身份
  async selected(e) {
    const data = e.currentTarget.dataset.item
    await saveInstId(app, data)
    wx.navigateBack()
  }
})