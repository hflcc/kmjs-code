// pages/after-sale-list/index.js
const app = getApp()
import Dialog from "@vant/weapp/dialog/dialog"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    afterList: [],
    after: {},
    query: {
      page: 0,
      size: 10
    },
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.data.afterList = []
    this.data.query = {
      page: 0,
      size: 10
    }
    // hack
    const query = this.selectComponent("#pullLoading")
    query && query.resetScrollTop && query.resetScrollTop()
    this.getAfterList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //上拉加载
  pullDown() {
    if (this.data.hasMore) {
      this.getAfterList()
    }
  },
  //下拉刷新
  pullUp() {
    this.data.afterList = []
    this.data.query = {
      page: 0,
      size: 10
    }
    this.getAfterList()
    this.setData({
      refresherTriggered: false
    })
  },
  getAfterList() {
    const query = this.data.query
    this.setData({
      "isLoading": true
    })
    app.get("/ec/saled/page/", query).then(async res => {
      this.data.query.page++
      let data = res.content
      for (let i = 0; i <= data.length - 1; i++) {
        let arr = await app.formatterAfterGoods(data[i].items)
        data[i].items = arr
      }
      data.forEach(v => {
        if (v.state == "apply") {
          v.afterSaleState = "售后审核"
        } else if (v.state == "cancel") {
          v.afterSaleState = "售后关闭"
        } else if (v.state == "reject") {
          v.afterSaleState = "条件不符"
        } else if (v.state == "wait_send") {
          v.afterSaleState = "商品寄回"
        } else if (v.state == "process") {
          v.afterSaleState = "商家处理"
        } else if (v.state == "wait_back") {
          v.afterSaleState = "用户收货"
        } else if (v.state == "complete") {
          v.afterSaleState = "售后成功"
        }
        if (v.type == "exchange") {
          v.afterSaleType = "换货"
        } else if (v.type == "refund") {
          v.afterSaleType = "退款"
        } else if (v.type == "back_refund") {
          v.afterSaleType = "退货退款"
        }
      })
      this.setData({
        afterList: this.data.afterList.concat(data),
        "hasMore": !res.last,
        "isLoading": false
      })
    })
  },
  goAfterDetail(e) {
    //售后sn
    let sn = e.currentTarget.dataset.sn
    //判断页面
    let state = e.currentTarget.dataset.type
    //自传类型做修改、撤销按钮判断
    let status = e.currentTarget.dataset.status
    //商品寄回
    if (state == "wait_send") {
      wx.navigateTo({
        url: `/pages/good-back/index?sn=${sn}`
      })
    } else if (state == "process") {
      //物流详情
      wx.navigateTo({
        url: `/pages/logistics-info/index?sn=${sn}&type=saled`
      })
    } else if (state == "wait_back") {
      //确认收货
      Dialog.confirm({
        message: "确定已收到货？"
      })
        .then(async () => {
          let res = await app.put(`/ec/saled/complete/${sn}`)
          if (res.success) {
            this.setData({
              afterList: [],
              query: {
                page: 0,
                size: 10
              }
            })
            this.getAfterList()
          }
        })
        .catch(() => {
          // on cancel
        })
    } else if ((state == "reject" && status == "cancel") || state == "apply") {
      //撤销售后申请
      Dialog.confirm({
        message: "您确定撤销该售后申请?\n撤销后将不可再恢复。"
      })
        .then(async () => {
          let res = await app.put(`/ec/saled/cancel/${sn}`)
          if (res.success) {
            this.setData({
              afterList: [],
              query: {
                page: 0,
                size: 10
              }
            })
            this.getAfterList()
          }
        })
        .catch(() => {
          // on cancel
        })
    } else if (state == "reject" && status == "amend") {
      //修改售后申请
      wx.navigateTo({
        url: `/pages/apply-for-after-sales/index?sn=${sn}&apply=edit&orderSn=`
      })
    } else {
      //售后详情
      wx.navigateTo({
        url: `/pages/after-sale-detail/index?sn=${sn}`
      })
    }
  }
})
//