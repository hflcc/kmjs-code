// pages/address/index.js
import { wxToast } from "../../utils/index"
const { formatterMoney, ORDERSTATUS,WXINFO } = require("../../utils/index")
const app = getApp()
import Dialog from "@vant/weapp/dialog/dialog"

let orderSn = "", showToast = false, showType = "", showToastText = ""
Page({
  data: {
    // 当前选中
    active: "all",
    // tab列表
    tabList: [
      { label: "全部", active: "all" },
      { label: "待付款", active: "none,pay" },
      { label: "分享中", active: "compose" },
      { label: "待发货", active: "deliver" },
      { label: "发货中", active: "delivering" },
      { label: "待收货", active: "receiving" },
      { label: "已完成", active: "complete,comment" }
    ],
    // 分页信息
    query: {
      page: 0,
      size: 30
    },
    // 订单列表
    orderList: [],
    // 是否有更多订单
    hasMore: true,
    // 是否刷新完成
    refresherTriggered: false,
    // 下拉刷新时如果原来有数据，不展示空数据提示
    isRefresh: false,
    // 显示分享面包
    showShare:false,
    // 显示分享海报
    showPoster: false,
    // 分享数据
    shareData: {},
    // 分享二维码
    ewmImg:'',
    shareOptions: [{
        name: "分享给好友",
        type: "base",
        openType: "share",
        icon: "http://resource.kmyun.cn/haopinggo/wx.png"
      },
      {
        name: "生成分享海报",
        type: "poster",
        icon: "http://resource.kmyun.cn/haopinggo/poster.png"
      }
    ],
  },
  // 刷新订单
  pullUp() {
    this.setData({
      isRefresh: this.data.orderList.length > 0,
      orderList: [],
      "query.page": 0,
    })
    this.getData()
  },
  // 加载更多
  pullDown() {
    this.setData({
      "query.page": this.data.query.page + 1
    })
    this.getData()
  },
  onLoad(e) {
    // 2021-05-24 新需求 使用支付状态页替换提示
    // if (e.toastType === "success") {
    //   showToast = true
    //   showType = "success"
    //   showToastText = "支付成功"
    // } else if (e.toastType === "fail") {
    //   showToast = true
    //   showType = "fail"
    //   showToastText = "支付失败"
    // }
    this.onChange(e)
  },
  //tab栏切换
  onChange(e) {
    this.setData({
      active: e.name || e.detail?.name || 'all',
      orderList: [],
      "query.page": 0
    })
    this.getData()
  },
  onShow() {
    this.getData()
  },
    /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    let {
      title,
      imageUrl,
      scene
    } = this.data.shareData
    return {
      title,
      desc: title,
      imageUrl: imageUrl.replace("https", "http"),
      path: "/pages/spelling-detail/index?scene=" + scene
    }
  },
  // 获取订单数据
  getData() {
    const query = this.data.query
    const type = this.data.active === "all" ? "" : "/" + this.data.active
    app.get("/ec/order/page" + type, query).then(async res => {
      let resource
      if (query.page === 0) {
        resource = []
      } else {
        resource = this.data.orderList
      }
      this.setData({
        hasMore: !res.last,
        orderList: resource.concat(...await this.formatterOrder(res.content)),
        isRefresh: false
      })
      wx.nextTick(() => {
        setTimeout(() => {
          if (showToast) {
            showToast = false
            wxToast(showToastText, type)
          }
        }, 500)
        this.setData({
          refresherTriggered: false
        })
      })
    })
  },
  // 格式化订单
  formatterOrder(lists) {
    return new Promise(async (resolve, reject) => {
      if (!Array.isArray(lists)) {
        return resolve([])
      }
      // 图片oss地址
      let picList = []
      // 格式化后的数据
      // 遍历商铺
      let result = lists.map(item => {
        // 遍历商品
        item.goodsList = item.items.map(itemChild => {
          picList.push(itemChild.ossId)
          // 遍历sku
          let specsList = itemChild.itemDetailResponses.map(itemSon => {
            return {
              // 规格名称
              name: itemSon.bizEcGoodsSpecsName,
              // 单价
              price: formatterMoney(itemSon.price),
              // 数量
              count: itemSon.quantity,
              //售后状态
              saledState:itemSon.saledState,
              //订单sn
              sn:itemSon.sn,
              // 售后过期时间
              saledCloseAt:itemSon?.saledCloseAt,
              saledClose:itemSon?.saledCloseAt==0?false:(Date.now()/1000>itemSon?.saledCloseAt?true:false)
            }
          })
          return {
            // 图片地址
            newPic: "",
            // 商品名称
            goodsName: itemChild.bizEcGoodsName,
            // sku列表
            specsList
          }
        })
        return {
          // 拼团实例sn
          composesSn:item.composes?.sn,
          // 拼团实例sn
          composesGoodsAmount:item.composes?.goodsAmount,
          // 拼团实例sn
          composesTargetNum:item.composes?.targetNum,
          // 订单来源类型（暂时不适用）
          bizSource:item.bizSource,
          // address
          address: item.address,
          // 支付实例
          payInstanceSn: item.payInstanceSn,
          // 店铺sn
          shopSn: item.bizEcShopSn,
          // 订单sn
          sn: item.sn,
          // 商铺名称
          shopName: item.bizEcShopName,
          // 订单状态
          state: item.state,
          // 订单描述
          stateText: item.state=='compose'?ORDERSTATUS[item.bizSource]:ORDERSTATUS[item.state],
          // 是否展示删除订单的icon
          hasbin: item.state != "complete" && item.state === "cancel",
          // 规格列表
          goodsList: item.goodsList,
          // 几种商品
          specCount: item.species,
          // 几种规格
          skuCount: item.totalQuantity,
          // 运费金额
          freight: formatterMoney(item.deliverAmount),
          // 应付总金额
          price: formatterMoney(item.payableAmount),
          // 邀请好友
          compose:item.state==="compose",
          // 按钮展示状态,去支付按钮
          btnGoPay: item.state === "none" || item.state === "pay",
          // 按钮展示状态,取消订单
          btnCancelOrder: item.state === "none" || item.state === "pay",
          // 按钮展示状态,查看物流
          btnCheckLogistics: item.state === "receiving",
          // 按钮展示状态,确认收货
          btnSubmitReceiver: item.state === "receiving",
          // 按钮展示状态,再次采购
          btnReBuy: false, // item.state === "complete"
        }
      })
      // 图片oss地址,换图片
      picList = await app.picSnGetUrl(picList, {width: 800, height: 800})
      // 图片索引
      let picIndex = 0
      // 放入图片
      result.forEach(item => {
        item.goodsList.forEach(itemChild => {
          itemChild.newImg = picList[picIndex]
          picIndex += 1
        })
      })
      resolve(result)
    })
  },
  // 跳转订单详情页
  goDetail(e) {
    let orderInfo = e.orderData || e.target.dataset.orderinfo;
    wx.navigateTo({
      url: `/pages/order-detail/index?sn=${orderInfo.sn}`
    })
  },
  // 点击按钮
  tapBtn({ detail }) {
    if (detail.type === "submitReceiver") {
      this.submitReceiver(detail)
    } else if (detail.type === "reBuy") {
      this.reBuy(detail)
    } else if (detail.type === "checkLogistics") {
      this.checkLogistics(detail)
    } else if (detail.type === "goPay") {
      this.goDetail(detail)
    } else if (detail.type === "cancelOrder") {
      this.cancelOrder(detail)
    }else if (detail.type === "delete"){
      this.deleteOrder(detail)
    }else if (detail.type === "compose"){
      // 去分享
      this.goshare(detail.orderData)
    }
  },
  // 去分享
  goshare(detail){
    // 获取分享信息
    let data={}
    if(detail.goodsList.length){
      data = detail.goodsList[0]
    }else{
      return
    }
    this.setData({
      "shareData.title": data.goodsName,
      "shareData.minPrice": formatterMoney(detail.composesGoodsAmount),
      "shareData.peopleNum": detail.composesTargetNum,
      "shareData.saleHeadImg": app.globalData.userInfo.token && wx.getStorageSync(WXINFO).headimgUrl ? wx.getStorageSync(WXINFO).headimgUrl : "https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/hpglogo-1624413363473.png",
      "shareData.saleHeadName": app.globalData.userInfo.token && wx.getStorageSync(WXINFO).nickName ? wx.getStorageSync(WXINFO).nickName : "耗品GO",
      "shareData.imageUrl": data.newImg,
      "shareData.scene": detail.composesSn
    })
    // 获取小程序码
    this.ewm(detail.composesSn)
    this.setData({
      showShare: !this.data.showShare
    })
  },
  // 获取小程序码
  async ewm(sn) {
    let img = await app.get(`/wx/common/applet/code?scene=${sn}&page=pages/spelling-detail/index`)
    this.setData({
      ewmImg: img.imgBase64
    })
  },
  // 选择分享类型
  shareTypeSelect({
    detail
  }) {
    this.setData({
      showShare: false
    })
    if (detail.type == "base") {

    } else if (detail.type == "poster") {
      this.setData({
        "shareData.shareImg": this.data.ewmImg,
        showPoster: true
      })
    }
  },
  // 关闭分享面板
  changeShowShare() {
    this.setData({
      showShare: !this.data.showShare
    })
  },
  // 关闭图片
  closePoster() {
    this.setData({
      showPoster: false
    })
  },
  // 保存图片
  savePoster() {
    const _self = this
    wx.getSetting({
      withSubscriptions: true,
      success(res) {
        if (res.authSetting["scope.writePhotosAlbum"] === false) {
          wx.openSetting({
            success(data) {
              console.log("成功", data)
            },
            fail(err) {
              console.log("失败", err)
            }
          })
        } else {
          _self.selectComponent("#canvas").saveImage()
        }
      }
    })
  },
  // 去商品主页
  goShop(e) {
    wx.navigateTo({
      url: `/packageA/pages/shop-home/index?sn=${e.detail}`
    })
  },
  // 确认收货
  submitReceiver(detail) {
    Dialog.confirm({
      title: "提示",
      message: "确定已收到货？"
    }).then(() => {
      app.put(`/ec/order/received/${detail.orderData.sn}`).then(res => {
        if (res) {
          this.getData()
        }
      })
    }, () => {
    })
  },
  // 查看物流
  checkLogistics(detail) {
    wx.navigateTo({
      url: `/pages/logistics-info/index?sn=${detail.orderData.sn}`
    })
  },
  // 地址回调
  changeAddressData(e) {
    app.put(`/ec/order/address/${orderSn}/${e.sn}`).then(res => {
      if (res) {
        this.payNow(orderSn)
      }
    })
  },
  payNow(sn) {
    app.put(`/ec/order/submit/${sn}`).then((res) => {
      if (res) {
        wx.navigateTo({
          url: `/pages/cashier/index?paySn=${res.paySn}&sn=${sn}&type=order`
        })
      }
    })
  },
  // 去支付
  goPay(detail) {
    if (detail && detail.orderData && detail.orderData.address) {
      this.payNow(detail.orderData.sn)
    } else {
      Dialog.confirm({
        message: "当前订单还未选择收货地址\n请选择收货地址再进行订单支付"
      })
      .then(() => {
        orderSn = detail.orderData.sn
        wx.navigateTo({
          url: "/pages/address/index?t=needback"
        })
        return
      })
      .catch(() => {
        // on cancel
      })
    }
  },
  // 取消订单
  cancelOrder(detail) {
    Dialog.confirm({
      title: "提示",
      message: "您确定取消该订单？取消后将无法再恢复。"
    }).then(() => {
      app.put(`/ec/order/cancel/${detail.orderData.sn}`).then(res => {
        if (res) {
          this.getData()
        }
      })
    }, () => {
    })
  },
  //关闭订单
  deleteOrder(detail){
    Dialog.confirm({
      title: "提示",
      message: "您确定删除该订单？删除后将无法再恢复。"
    }).then(() => {
      app.del(`/ec/order/${detail.orderData.sn}`).then(res => {
        if (res) {
          this.getData()
        }
      })
    }, () => {
    })
  }
})
