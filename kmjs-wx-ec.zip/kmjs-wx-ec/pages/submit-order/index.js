// pages/cashier/index.js
import Dialog from "/@vant/weapp/dialog/dialog"

const {mobileFormat, formatterMoney, formatterTime, scopeType} = require("../../utils/index")
const app = getApp()
const oldTicketSn = {
  goods: "goodsTicket",
  shop: "shopTicket",
  app: "appTicket",
}
const newTicketSn = {
  goods: "newgoodsTicket",
  shop: "newshopTicket",
  app: "newappTicket",
}
const message = {
  goods: "goodsMessage",
  shop: "shopMessage",
  app: "appMessage",
}
Page({
  data: {
    // 商品单号
    sn: "",
    // 订单类型
    type: "group",
    // 地址信息
    address: {},
    // 商家列表
    shopList: [],
    // 汇总信息
    sumMsg: {},
    // 推荐码
    scancode: "",
    // 推荐人姓名
    referrerName: "",
    //当前角色
    role: "",
    // 优惠券类型选中值 '1':可使用 ’0‘：不可使用
    cp_nav_label: '1',
    // 显示优惠劵列表
    showCoupoList: false,
    // 使用规则
    showRule: false,
    // 选中优惠券的sn
    radio: '',
    //已选中优惠券
    mapCoupon: {},
    //已选优惠券类型
    couponType: '',
    //选择排他优惠券 默认使用数量
    couponNum: true,
    // 优惠券列表
    couponList: [],
    // 可使用的优惠券（商品 or 店铺 or 平台）
    usecp: '',
    // 显示优惠券对应的 （商品 or 店铺 or 平台）sn
    scopeValue: '',
    // 显示优惠券对应的 （商品 or 店铺 or 平台）总价
    scopeamount: 0,
    // 可使用数量
    validNum: 0,
    // 可使用优惠券
    validItems: [],
    // 不可使用数量
    inValidNum: 0,
    // 不可使用优惠券
    inValidItems: [],
    // 商品优惠券Sn
    goodsTicket: "",
    // 店铺优惠券Sn
    shopTicket: "",
    // 平台优惠券Sn
    appTicket: "",
    // 新商品优惠券Sn
    newgoodsTicket: "",
    // 新店铺优惠券Sn
    newshopTicket: "",
    // 新平台优惠券Sn
    newappTicket: "",
    // 商品信息
    goodsMessage: {},
    // 店铺券信息
    shopMessage: {},
    // 平台券信息
    appMessage: {},
    // 订单Sn
    orderSn: '',
    // 平台+店铺优惠金额
    appAndShopAmount: '',
    // 商品优惠金额
    goodTicketAmount: '',
    BizSns: [],
    // 是否显示底部推荐人组件
    showReferrerComp: true,
    shopSns: [],
    goodsSns: [],
    payVersion: ''
  },
  onLoad: function ({type, sn, payVersion}) {
    this.setData({type, sn, payVersion})
    this.inquireRole()
  },
  onShow(options) {
    this.getData()
  },
  // 选用采购金
  async useBiz({detail}) {
    this.setData({
      BizSns: detail
    })
    // 选中采购金接口
    let res = await app.put(`/ec/order/group/currency/${this.data.sn}`, this.data.BizSns)
    if (res) {
      // 重新获取数据
      this.getData()
    }
  },
  // 店铺or平台券
  stopORapp({currentTarget}) {
    //判断我选中的排他券的类型是否为空
    if (this.data.couponType == '') {
      this.setData({
        usecp: currentTarget.dataset.type,
        radio: this.data.radio == '' ? '' : this.data[newTicketSn[currentTarget.dataset.type]],
      })
    } else if (this.data.couponType && this.data.couponType != currentTarget.dataset.type) {//如果排他券的类型有的话 就把数据在切换tab的时候清空掉
      this.setData({
        usecp: currentTarget.dataset.type,
        radio: ''
      })
      if (currentTarget.dataset.type == 'shop') {
        this.setData({
          appMessage: {}
        })
      } else {
        this.setData({
          shopMessage: {}
        })
      }
    } else if (this.data.couponType == currentTarget.dataset.type) {
      this.setData({
        usecp: currentTarget.dataset.type,
        radio: this.data[newTicketSn[currentTarget.dataset.type]],
      })
    }
    this.getCouponList()
  },

  // 显示优惠券
  /**
   * amount 商品未优惠价格
   * ticketamount 优惠券价格
   * ticket 优惠券
   */
  showCP({detail}) {
    if (detail.sn != this.data.scopeValue) {
      this.setData({
        goodsMessage: {},
        shopMessage: {},
        appMessage: {},
        goodsTicket: "",
        shopTicket: "",
        appTicket: "",
        newgoodsTicket: "",
        newshopTicket: "",
        newappTicket: "",
      })
    }
    if (detail.type == "goods") {
      this.setData({
        usecp: 'goods',
        radio: detail.ticket?.instanceSn,
        goodsTicket: detail.ticket?.instanceSn,
        goodsMessage: detail.ticket,
        goodTicketAmount: detail.ticketamount
      })
    } else if (detail.type == "all") {
      this.setData({
        // usecp:'shop',
        appAndShopAmount: detail.ticketamount,
        radio: '',
      })
      detail.ticket?.forEach(item => {
        if (item.scopeType == "app") {
          this.setData({
            appTicket: item.instanceSn,
            newappTicket: item.instanceSn,
            appMessage: item
          })
        } else if (item.scopeType == "shop") {
          this.setData({
            shopTicket: item.instanceSn,
            newshopTicket: item.instanceSn,
            // radio:item.instanceSn,
            shopMessage: item
          })
        }
      })
      this.setData({
        usecp: this.data.shopTicket ? 'shop' : (this.data.appTicket ? 'app' : 'shop'),
        radio: this.data.shopTicket ? this.data.shopTicket : (this.data.appTicket ? this.data.appTicket : this.data.shopTicket),
      })
    }
    this.setData({
      scopeValue: detail.sn,
      scopeamount: detail.amount,
      showCoupoList: true,
      orderSn: detail.ordersn,
      shopSns: [detail.sn],
      goodsSns: detail.goodsSns
    })
    this.getCouponList(detail.type == "goods" ? detail.totalquantity : '')
  },
  //选择提取方式
  pickerChange({detail}) {
    app.put(`/ec/order/deliver/payment/${detail.sn}/${detail.paymentType}`).then(res => {
      if (res.success) {
        this.getData()
      }
    })
  },
  // 获取优惠券
  getCouponList(totalquantity) {
    let data = {
      scopeType: this.data.usecp,
      scopeValue: this.data.usecp == "app" ? 'ec_order' : this.data.scopeValue,
      amount: this.data.scopeamount,
      shopSns: this.data.shopSns?.length ? this.data.shopSns : [],
      goodsSns: this.data.goodsSns?.length ? this.data.goodsSns : [],
    }
    // 商品券要传sku总数量
    totalquantity ? data.num = totalquantity : ''
    app.post(`/mk/ticket/instance/list/current/scope/all`, data).then(res => {
      if (res) {
        if (res.validItems.length) {
          res.validItems.forEach(item => {
            item.scopeNmae = scopeType[item.scopeType]
            item.endATString = formatterTime(item.endAt * 1000, 'YMD', '.')
            item.startATString = formatterTime(item.startAt * 1000, 'YMD', '.')
          })
        }
        if (res.inValidItems.length) {
          res.inValidItems.forEach(item => {
            item.scopeNmae = scopeType[item.scopeType]
            item.endATString = formatterTime(item.endAt * 1000, 'YMD', '.')
            item.startATString = formatterTime(item.startAt * 1000, 'YMD', '.')
          })
        }
        this.setData({
          validNum: res.validNum || 0,
          validItems: res.validItems,
          inValidNum: res.inValidNum || 0,
          inValidItems: res.inValidItems,
          couponList: this.data.cp_nav_label == '0' ? res.inValidItems : res.validItems
        })
        //把默认历史券存起来
        if (this.data.radio && this.data.couponList.length > 0) {
          const mapCoupon = this.data.mapCoupon
          Object.assign(mapCoupon,
            {
              [this.data.radio]: this.data.couponList.find(item => {
                return item.instanceSn == this.data.radio ? item.beAdd : ''
              })
            })
          this.setData({
            mapCoupon
          })
        }
        this.setData({
          [message[this.data.usecp]]: this.data.validItems.find(item => {
            return item.instanceSn == this.data[oldTicketSn[this.data.usecp]]
          })
        })
      }
    })
  },
  // 选择优惠券
  couponChange({detail}) {
    // 当前选择的优惠券是否在优惠券列表中
    let coupon = this.data.couponList.find(item => {
      return item.instanceSn == detail
    })
    this.setData({
      [oldTicketSn[this.data.usecp]]: this.data.radio,
    })
    if (this.data.radio == detail) {
      this.setData({
        radio: '',
        [newTicketSn[this.data.usecp]]: '',
        [message[this.data.usecp]]: {},
        couponType: '',
        couponNum: true
      })
    } else {
      //把历史选中的radio赋值
      const mapCoupon = this.data.mapCoupon;
      //判断我点击这张不是排他券
      if (coupon.beAdd) {
        //判断历史选择中有没有排他券
        const isBeAff = Object.keys(mapCoupon).some(item => mapCoupon[item] === false);
        //存入历史选择中
        mapCoupon[detail] = true;
        //判断历史中有优惠券的话 有排他优惠券
        if (isBeAff) {
          this.setData({
            radio: detail,
            [newTicketSn[this.data.usecp]]: detail,
            [message[this.data.usecp]]:
              this.data.validItems.find(item => {
                return item.instanceSn == detail
              }),
            mapCoupon,
            //存入当前选择的这张券是什么类型的券
            couponType: coupon.scopeType,
            couponNum: false
          })
        } else {
          //历史中没有优惠券 就可以叠加使用
          this.setData({
            radio: detail,
            [newTicketSn[this.data.usecp]]: detail,
            [message[this.data.usecp]]:
              this.data.validItems.find(item => {
                return item.instanceSn == detail
              }),
            mapCoupon,
            couponType: '',
            couponNum: true
          })
        }
      } else {//当前点击的这张券是排他券
        //当前历史中有没有券
        let couponNum;
        if (coupon.scopeType == 'goods') {
          couponNum = true
        } else {
          couponNum = false
        }
        mapCoupon[detail] = false;
        this.setData({
          radio: detail,
          [newTicketSn[this.data.usecp]]: detail,
          [message[this.data.usecp]]:
            this.data.validItems.find(item => {
              return item.instanceSn == detail
            }),
          mapCoupon,
          couponType: coupon.scopeType,
          couponNum
        })
      }
    }
    let type = this.getSubmitCouponType(this.data[oldTicketSn[this.data.usecp]], this.data[newTicketSn[this.data.usecp]])
    let data = {
      "usedInstanceSn": type == "cancel" ? '' : this.data[oldTicketSn[this.data.usecp]],
      "scopeType": this.data.usecp,
      "scopeValue": this.data.usecp == "app" ? 'ec_order' : this.data.scopeValue,
      "instanceSn": type == "cancel" ? this.data[oldTicketSn[this.data.usecp]] : this.data[newTicketSn[this.data.usecp]],
      "groupSns": this.data.sn.split(',')
    }
    this.selectCoupon(type, data)
  },
  // 确定选择优惠券-调后台
  selectCoupon(type, data) {
    app.put(`/ec/order/ticket/${this.data.orderSn}/${type}`, data).then(async res => {
      if (res) {
        this.setData({
          appAndShopAmount: res.appAndShopAmount,
          goodTicketAmount: res.goodTicketAmount
        })
        if (type == "cancel") {
          let cancelCouponType = data.scopeType;
          console.log(cancelCouponType);
          this.setData({
            [oldTicketSn[this.data.usecp]]: ''
          })
        }
        await this.getData()
      } else {
        // 失败时恢复上一次状态
        this.setData({
          radio: this.data[oldTicketSn[this.data.usecp]],
          [newTicketSn[this.data.usecp]]: '',
          [message[this.data.usecp]]: {},
        })
      }
    })
  },
// 优惠券类型
  getSubmitCouponType(oldc, newc) {
    // use："新增优惠券",exchange："替换优惠券",cancel："取消优惠券"
    // 新增
    if (oldc && newc) {
      if (oldc != newc) {
        return 'exchange'
      }
    }
    // 旧的没有--新增
    else if (!oldc) {
      return 'use'
    }
    // 新的没有--删除
    else if (!newc) {
      return 'cancel'
    } else {
      return false
    }
  },
  // 使用规则
  ruleCallback() {
    this.setData({
      showRule: true
    })
  },
  // 关闭规则
  closeRule() {
    this.setData({
      showRule: false
    })
  },
  // 改变优惠券类型选中值
  changeCpNav({currentTarget}) {
    if (currentTarget.dataset.label != this.data.cp_nav_label) {
      this.setData({
        cp_nav_label: currentTarget.dataset.label
      })
      if (this.data.cp_nav_label == 1) {
        this.setData({
          couponList: this.data.validItems
        })
      } else {
        this.setData({
          couponList: this.data.inValidItems
        })
      }
    }
  },

  // 显示使用说明
  showUseDes({detail}) {
    Dialog.alert({
      title: '使用说明',
      message: detail,
    }).then(() => {
      // on close
    });
  },

  // 隐藏优惠券
  hiddenCP() {
    this.setData({
      showCoupoList: false,
      cp_nav_label: '1',
    })
  },
  // 获取推荐码
  getcodeValue({detail}) {
    this.setData({
      scancode: detail
    })
  },
  // 获取推荐码信息
  getValueMsg({detail}) {
    if (!detail) {
      this.setData({
        referrerName: ''
      })
      return
    }
    app.put(`/mk/invite/code/${detail}`).then(res => {
      if (res) {
        this.setData({
          referrerName: res.name
        })
      } else {
        this.setData({
          referrerName: ""
        })
      }
    })
  },
  // 选择推荐人
  selectReferrer() {
    wx.navigateTo({
      url: "/pages/referrer/index?form=ec_order&type=none&isNeedBack=true"
    })
  },
  //查询当前账号的角色
  inquireRole() {
    app.get('/mk/project/ring/actor/role/ec_order').then(res => {
      this.setData({role: res})
      if (res.flag) {
        this.getDefReferrer()
      }
    })
  },
  // 接受推荐人返回的数据
  getScancode({name, code}) {
    this.setData({
      scancode: code,
      referrerName: name
    })
  },
  // 初始化数据
  getData() {
    const data = this.data
    if (data.type === "group") {
      app.get(`/ec/order/group/sns/${data.sn}`).then(res => {
        if (res.items && res.items[0] && res.items[0].address) {
          this.formatterAddress(res.items[0].address)
        }
        if (res.items && Array.isArray(res.items)) {
          this.formatterShopsList(res.items)
          // this.getCouponCount(res.items)
        }
        if (res) {
          this.formatterSumMsg(res)
        }
      })
    } else if (data.type === "single") {
      app.get(`/ec/order/${this.data.sn}`)
    }
  },
  // 获取默认推荐人
  getDefReferrer() {
    app.get(`/mk/project/ring/user/find/commend/ec_order/${this.data.role.type}`).then(res => {
      if (res) {
        this.setData({
          referrerName: res.name,
          scancode: res.code
        })
      }
    })
  },
  // 地址格式化
  async formatterAddress(data) {
    let {name, mobile, areaSn, address, area, pitchOn} = data
    if (!area) {
      // 根据区域sn换取地址信息
      const result = await app.get(`/md/area/def/item/${areaSn}`)
      if (result) {
        area = result
      }
    }
    this.setData({
      address: {
        name,
        phone: mobileFormat(mobile),
        area: app.area(area),
        address,
        pitchOn
      }
    })
  },
  // 获取优惠券数量
  async getCouponCount(list) {
    // 商品列表
    const shopList = []
    list.forEach(item => {
      const shop = {
        scopeType: "shop",
        // 商铺SN
        scopeValue: item.bizEcShopSn,
        // 店铺列表
        items: [],
      }
      item.orderItems.forEach(itemChild => {
        const good = {
          scopeType: "goods",
          scopeValue: itemChild.bizEcGoodsSn,
        }
        shop.items.push(good)
      })
      shopList.push(shop)
    })
    app.post(`/mk/ticket/count`, shopList).then(res => {
      if (res) {
        let data = this.data.shopList.map((sItem, sIndex) => {
          item.totalNum = res[index].totalNum
          return item
        })
        this.setData({
          data
        })
      }
    })
  },
  // 格式化商家-商品-规格
  async formatterShopsList(list) {
    // 商品列表
    const shopList = []
    // 图片地址
    let goodsPic = []
    list.forEach(item => {
      const shop = {
        // 订单sn
        sn: item.sn,
        // 店铺sn
        shopSn: item.bizEcShopSn,
        // 店铺名称
        shopName: item.bizEcShopName,
        // 原价
        goodsAmount: item.goodsAmount,
        // 店铺列表
        goodsList: [],
        // 运费
        deliverAmount: formatterMoney(item.deliverAmount),
        // 节省
        preferentialAmount: item.preferentialAmount,
        // 店铺+平台 优惠券合计
        ticketAmount: item.appAndShopTicketAmount,
        // 订单优惠券集合(包含 平台券、店铺券)
        tickets: item.tickets,
        // 优惠券数量
        ticketNum: item.ticketNum,
        // 合计
        payableAmount: item.payableAmount,
        // 提取方式
        paymentType: item.paymentType,
        // 运费
        freeDiffAmount: item.freeDiffAmount,
        //是否可以选择提取方式
        paymentStatus: item.paymentStatus,
        //支付版本
        payVersion: item.payVersion
      }
      item.orderItems.forEach(itemChild => {
        goodsPic.push(itemChild.ossId)
        const good = {
          // 商品名称
          goodsName: itemChild.bizEcGoodsName,
          goodsSn: itemChild.bizEcGoodsSn,
          // 商品总价
          goodsAmount: itemChild.totalGoodsAmount,
          // 优惠券合计
          ticketAmount: itemChild.originalTicketAmount,
          // sku列表
          skuList: [],
          // 优惠券集合(商品券)
          ticket: itemChild.ticket,
          ticketNum: itemChild.ticketNum,
          // 单个商品购买总数
          totalQuantity: itemChild.totalQuantity
        }
        itemChild.itemDetailResponses.forEach(itemSon => {
          good.skuList.push({
            // 规格名称
            specName: itemSon.bizEcGoodsSpecsName,
            // 单价
            price: itemSon.price,
            // 数量
            count: itemSon.quantity
          })
        })
        shop.goodsList.push(good)
      })
      shopList.push(shop)
    })
    // 拉去图片
    goodsPic = await app.picSnGetUrl(goodsPic, {width: 180, height: 180})
    // 把图片放进去
    let picIndex = 0
    shopList.forEach(item => {
      item.goodsList.forEach(itemChild => {
        itemChild.newImg = goodsPic[picIndex]
        picIndex += 1
      })
    })
    this.setData({
      shopList
    })
  },
  // 格式化汇总信息
  formatterSumMsg({goodsAmount, payableAmount, deliverAmount, totalQuantity, preferentialAmount, ticketAmount, sn, currencies}) {
    this.setData({
      sumMsg: {
        sumPrice: formatterMoney(goodsAmount),
        realPrice: formatterMoney(payableAmount),
        freight: formatterMoney(deliverAmount),
        preferentialAmount: formatterMoney(preferentialAmount),
        ticketAmount: formatterMoney(ticketAmount),
        totalQuantity,
        sn,
        // 支付类型
        currencies
      }
    })
  },
  // 地址切换
  changeAddress() {
    wx.navigateTo({
      url: "/pages/address/index?t=needback"
    })
  },
  // 提供给地址页面调用
  changeAddressData(e) {
    app.put(`/ec/order/address/group/${this.data.sn}/${e.sn}`).then(res => {
      if (res) {
        this.getData()
      }
    })
  },
  // 订阅支付成功信息
  handleSubPay() {
    let _that = this
    let messageTemplatesSn = app.globalData?.appConfig?.notice_wx_message_template || ''
    app.get(`/sys/wx/applet/message/template/list/${JSON.parse(messageTemplatesSn).join(',')}`).then(tems => {
      let messageTemplates = tems.map(item => item.templateId)
      wx.requestSubscribeMessage({ //获取下发权限
        tmplIds: messageTemplates, //此处写在后台获取的模板ID，可以写多个模板ID，看自己的需求
        success: (res) => {
          let accept = []
          let unaccept = []
          tems.forEach(item => {
            if (res[item.templateId] == 'accept') {
              accept.push(item.sn)
            } else {
              unaccept.push(item.sn)
            }
          })
          if (!accept.length) {
            // 取消订阅接口
            app.post(`/sys/user/wx/message/template/batch/disubscribe/${unaccept.join(',')}`)
          } else if (!unaccept.length) {
            // 订阅接口
            app.post(`/sys/user/wx/message/template/batch/subscribe/${accept.join(',')}`)
          } else {
            app.post(`/sys/user/wx/message/template/batch/disubscribe/${unaccept.join(',')}`)
            app.post(`/sys/user/wx/message/template/batch/subscribe/${accept.join(',')}`)
          }
          // 成功
          /* tems.forEach(item=>{
            if (res[item.templateId] == 'accept') { //accept--用户同意 reject--用户拒绝 ban--微信后台封禁,可不管
              // 下发接口
              app.post(`/sys/user/wx/message/template/subscribe/${item.sn}`).then(res=>{
                if(res){
                  // 业务逻辑
                }
              })
            }
            else {
              // 取消下发接口
              app.post(`/sys/user/wx/message/template/disubscribe/${item.sn}`).then(res=>{
                if(res){
                  // 业务逻辑
                }
              })
            }
          }) */
        },
        fail: (err) => {
          console.log('订阅失败', err.errMsg);
        },
        complete: () => {
          _that.handeleGoCashier()
        }
      })
    })
  },
  goCashier() {
    this.handleSubPay()
  },
  async submitPay(sn, payVersion, isCustomAction) {
    return new Promise(async (resolve) => {
      const payDefSn = await this.getPayDefSn(payVersion)
      app.put(`/ec/order/group/submit/${sn}?payDefSn=${payDefSn}`).then(res => {
        if (res?.success) {
          if (isCustomAction) {
            resolve(res)
            return
          }
          if (res.paySn) {
            // 去收银台
            wx.redirectTo({
              url: `/pages/cashier/index?paySn=${res.paySn}&sn=${res.sn}&type=group&payVersion=${payVersion}`
            })
          } else {
            // 弹窗
            // 0元支付 去待发货页面
            wx.redirectTo({
              url: `/pages/order-data/index?name=all`
            })
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    })
  },
  // 立即支付
  async handeleGoCashier() {
    // 提交备注以及取货方式
    const remark = this.selectAllComponents(".shopItem").map(item => {
      return item.getRemarkAndPayType()
    })
    let scancode = encodeURIComponent(this.data.scancode)
    // 是产业用户不带请求链接 code
    const url = this.data.showReferrerComp ? `/ec/order/code/groupSns/${this.data.sn}?code=${scancode}` : `/ec/order/code/groupSns/${this.data.sn}`
    app.put(url, remark).then(res => {
      if (res.success) {
        const sns = this.data.sn.split(',')
        if (sns.length > 1) {
          wx.redirectTo({
            url: `/pages/pay-order/index?sns=${this.data.sn}`
          })
        } else {
          this.submitPay(this.data.sn, this.data.shopList[0].payVersion)
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
    // 确认下单
    // let scancode = encodeURIComponent(this.data.scancode)

    // 是产业用户不带请求链接 code
    // const url = this.data.showReferrerComp
    //   ? `/ec/order/code/${this.data.sn}?code=${scancode}`
    //   : `/ec/order/code/${this.data.sn}`
    // const result = await app.put(url, remark)
    // if (!result) {
    //   return
    // }

    // 添加推荐人
    // if(scancode){
    //   let data = {
    //     inviteInstanceCode: scancode,
    //     type: "code"
    //   }
    //   let addcode = await app.post(`/mk/project/ring/user`, data)
    //   if(!addcode)return;
    // }

    // 接口变更，买家备注统一到合并submit接口
    // await app.put(`/ec/order/group/message/${this.data.sn}`, remark)
    // 提交生成支付sn
  },
  getPayDefSn(version) {
    return new Promise((resolve, reject) => {
      app.get(`/pay/def?version=${version}`).then(res => {
        if (res) {
          resolve(res.data)
        }
      })
    })
  },
  showReferrer({detail}) {
    this.setData({showReferrerComp: detail})
  }
})
