// pages/add-referrer/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scancode: "",
    referrerName: ""
  },
  // 确定
  submit() {
    if (this.data.referrerName && this.data.scancode) {
      let data = {
        inviteInstanceCode: this.data.scancode,
        type: "code"
      }
      app.post(`/mk/project/ring/user`, data).then(res => {
        if (res) {
          wx.showToast({
            title: res.message,
            icon: 'none',
            duration: 2000
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 200); 
        }
      })
    } else if (this.data.scancode) {
      this.getValueMsg({ detail: this.data.scancode })
    } else {
      wx.showToast({
        title: "请输入推荐人",
        icon: "none",
        duration: 2000
      })
    }
  },
  // 获取推荐码
  getValue({ detail }) {
      this.setData({
        scancode: detail
      })
  },
  // 获取推荐码信息
  getValueMsg({ detail }) {
    if (!detail) {
      this.setData({
        referrerName: ''
      })
      return
    }
    app.put(`/mk/invite/code/${detail}`).then(res => {
      if (res) {
        this.setData({
          referrerName: res.name
        })
      } else {
        this.setData({
          referrerName: ""
        })
      }
    })
  },
  // 校验推荐码
  checkcode() {
    // return new Promise((resovle,reject)=>{

    // })
  }
})
