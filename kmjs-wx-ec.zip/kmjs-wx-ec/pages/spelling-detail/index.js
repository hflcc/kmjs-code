// pages/spelling-detail/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //权益说明弹窗框
    ruleShow: false,
    //拼图信息
    spellingData: {},
    //邀请商品sn
    sceneSn: "",
    //重新开团弹出框
    overlayShow:false,
    // 是否展示商品规格的选择
    skuShow: false,
    // addShopList:添加进货单， buyNow:立即购买,  backDetail：点击已选， originalPrice：原价购买，groupPrice：发起拼团
    showSpecType: "",
    // 加入拼团的记录
    joingroup: {},
    // 商品sn
    goodsSn: "",
    //拼团失败
    spellingShow:false,
    // 店铺商品sn
    shopGoodsSn: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    this.setData({
      // sceneSn: options.scene? options.scene : "f6d46d32aa3b423bbb89b504970427c9"
      sceneSn: options.scene
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getSpellingDetail(this.data.sceneSn);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  popRule() {
    this.setData({
      ruleShow: true
    })
  },
  close(){
    this.setData({
      ruleShow: false
    })
  },
  skuClose() {
    this.setData({
      skuShow: false
    })
  },
  getSpellingDetail(sn) {
    app.get('/ec/compose/instance/actor/' + sn).then(async res => {
      if (res) {
        res.ossId = await app.picSnGetUrl(res.ossId,{width: 800, height: 800});
        res.expireAt = (res.expireAt - Math.round(new Date().getTime() / 1000)) * 1000;
        res.name = res.name.length>8?res.name.slice(0,8)+'...':res.name;
        for (let a = 0; a <= res.actors.length - 1; a++) {
          res.actors[a].headImgUrl = await app.picSnGetUrl(res.actors[a].headImgUrl,{width: 800, height: 800});
        }
        this.setData({
          spellingData: res,
          shopGoodsSn: res.shopGoodsSn // 新增shopGoodsSn
        })
        this.ifSpelling();
      }
    })
  },
  ifSpelling() {
    app.get('/ec/common/compose/instance/check/' + this.data.spellingData.composeInstanceSn).then( res => {
      if (res&&!res.flag && res.failType=="compose_full_close") {
        this.setData({overlayShow:!this.data.overlayShow})
      }else if (!res.flag && res.failType=="compose_instance_expired_close") {
        this.setData({spellingShow:!this.data.spellingShow})
      }
    })
  },
  goParticipation({currentTarget}) {
    const { type, joingroup, goodsn, num,  } = currentTarget.dataset
    this.setData({goodsSn:goodsn});
    this.ifSpelling();
    if (num > 0 && type === "joinGroup") {
      if (app.loginJump()) {
        const setData = {
          showSpecType: type,
          skuShow: true
        }
        // 加入拼团的时候,需要记录加入谁的
        if (type === "joinGroup") {
          setData["joingroup"] = joingroup
        }
        this.setData(setData)
      }
    } else if (type === "spellingFail") {
      wx.switchTab({
        url: '/pages/index/index',
      });
    } else {
      wx.navigateTo({
        url: '/pages/goods-detail/index?sn=' + goodsn,
      });
    }
  },
  // 确认订单
  submitOrder({ detail }) {
    const { type, result } = detail
    const { joingroup, goodsSn } = this.data
    if (type === "joinGroup") {
      if (joingroup.composeInstanceSn) {
        this.joinGroupFn(joingroup.composeInstanceSn, {
          goodsSn,
          composeGoods: result.map(({ skuSn: bizEcGoodsSkuSn, quantity: num }) => ({
            bizEcGoodsSkuSn,
            num
          }))
        })
      }
    }
    this.skuClose()
  },
    // 加入拼团
  joinGroupFn(instanceSn, data) {
    app.post(`/ec/compose/instance/join/${instanceSn}`, data).then(res => {
      if (res) {
        wx.navigateTo({
          url: `/pages/submit-order/index?type=group&sn=${res.sn}`
        })
      }
    })
  },
})
