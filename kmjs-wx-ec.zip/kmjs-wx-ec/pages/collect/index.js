// pages/collect/index.js
import { wxToast } from "../../utils/index"

const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 是否 onShow 加载数据
    isOnShowLoadData: true,
    // 是否有更多数据
    hasData: false,
    //默认tab选中
    active: 0,
    // 加载状态
    loading: false,
    // 刷新状态
    triggered: false,
    //默认请求页数和条数
    query: {
      page: 0,
      size: 30
    },
    //收藏
    lists: [],
    //收藏类型
    collectTabList: [
      { label: "商品", active: 0 },
      { label: "店铺", active: 1 }
    ],
    //总条数
    collectNum:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ active: Number(options.index) })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.data.lists = []
    this.data.query = {
      page: 0,
      size: 30
    }
    this.resetScrollTop()
    this.getCollect().then(res => {
      this.setData({
        isOnShowLoadData: false
      })
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 重置滚动高度
  resetScrollTop() {
    const query = this.selectComponent("#pullLoading")
    query && query.resetScrollTop && query.resetScrollTop()
  },
  // 滚动+1
  addOne() {
    const query = this.selectComponent("#pullLoading")
    query && query.addOne && query.addOne()
  },
  // 到底加载更多
  pullLoading() {
    if (this.data.hasData) {
      this.data.query.page += 1
      this.getCollect() 
    }
  },
  // 刷新
  pullRefresh() {
    this.setData({
      lists: []
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getCollect()
      this.setData({
        triggered: false
      })
    })
  },
  //获取收藏数据
  getCollect() {
    return new Promise((resolve, reject) => {
      if (this.data.active == 0) {
        app.get(`/md/inst/user/follow/page/summary/goods/time/none`, {
          page: this.data.query.page,
          size: this.data.query.size
        }).then(async res => {
          if (res) {
            // fixbug822;图片过多时,会重复触发加载更多接口;所以需要先清除是否有更多数据
            this.setData({ hasData: !res.last })
            let goodsList
            if (this.data.query.page === 0) {
              goodsList = []
            } else {
              goodsList = this.data.lists
            }
            this.setData({ lists: goodsList.concat(...await app.formatterGoods(res.content)),collectNum:res.totalElements})
            resolve()
          }
        })
      } else {
        app.get(`/md/inst/user/follow/page/summary/shop/time/none`, {
          page: this.data.query.page,
          size: this.data.query.size
        }).then(async res => {
          if (res) {
            // fixbug822;图片过多时,会重复触发加载更多接口;所以需要先清除是否有更多数据
            this.setData({ hasData: !res.last })
            let shopList
            if (this.data.query.page === 0) {
              shopList = []
            } else {
              shopList = this.data.lists
            }
            this.setData({ lists: shopList.concat(...await app.formatterShops(res.content)),collectNum:res.totalElements})
            resolve()
          }
        })
      }
    })
  },
  onChange(e) {
    if (!this.data.isOnShowLoadData) {
      this.data.query.page = 0
      this.setData({
        active: e.detail.index,
        lists: [],
        hasData: true,
      })
      this.resetScrollTop()
      this.getCollect()
    }
  },
  goHome() {
    wx.switchTab({ url: "/pages/index/index" })
  },
  // 商品详情
  tapItem(e) {
    const sn = e.detail.sn
    if (e.detail.state !== "off") {
      wx.navigateTo({
        url: `/pages/goods-detail/index?sn=${sn}`
      })
    } else {
      wxToast("该商品已下架")
    }
  },
  // 去商铺详情
  goShopDetail(e) {
    wx.navigateTo({
      url: `/packageA/pages/shop-home/index?sn=${e.detail.sn}`
    })
  },
  // 删除收藏的店铺
  deleteCollectShop(e) {
    const index = e.currentTarget.dataset.index
    const data = e.currentTarget.dataset.item
    app.del("/md/inst/user/follow/cancel/shop/" + data.sn).then(res => {
      if (res) {
        wxToast("取消收藏成功")
        this.data.lists.splice(index, 1)
        this.addOne()
        this.setData({
          lists: this.data.lists
        })
        if(!this.data.lists.length){
          this.getCollect().then(res => {
            this.setData({
              isOnShowLoadData: false
            })
          })
        }
      }
    })
    
  },
  // 删除收藏的商品
  deleteCollectGoods(e) {
    const index = e.currentTarget.dataset.index
    const data = e.currentTarget.dataset.item
    app.del("/md/inst/user/follow/cancel/goods/" + data.sn).then(res => {
      if (res) {
        wxToast("取消收藏成功")
        this.addOne()
        this.data.lists.splice(index, 1)
        this.setData({
          lists: this.data.lists
        })
        if(!this.data.lists.length){
          this.getCollect().then(res => {
            this.setData({
              isOnShowLoadData: false
            })
          })
        }
      }
    })
  }
})
