import { saveInstId, saveLoginStatus } from "../../utils/utils"

const { nameReg, wxToast } = require("../../utils/index")
const app = getApp()
let isSuccess = false
Page({
  data: {
    value: ""
  },
  onShow: function () {
    wx.hideHomeButton({
      success: (e) => {},
      fail: (e) => {},
      complete: (e) => {}
    })
  },
  // 确定
  async submit({currentTarget}) {
    if(currentTarget.dataset.type=='ok'){
        const value = this.data.value
        if (!value) {
          return wxToast("请输入身份名称")
        } else if (!nameReg(value)) {
          return wxToast("请输入正确的身份名称")
        }
        const result = await app.post("/md/inst/register", {
          "type": "shop",
          "name": value
        }, {
          Authorization: app.globalData.loginData.access_token
        })
        if (result) {
          saveLoginStatus(app, app.globalData.loginData)
          await saveInstId(app, result)
          wx.navigateBack()
        }
        
    }else{
      // 跳默认角色接口
      const result = await app.post("/md/inst/register", {
        "type": "shop",
      }, {
        Authorization: app.globalData.loginData.access_token
      })
      if (result) {
        saveLoginStatus(app, app.globalData.loginData)
        await saveInstId(app, result)
        wx.navigateBack({
          fail(e){
            wx.switchTab({ url: "/pages/self/index" })
          }
        })
      }
    }
  }
})