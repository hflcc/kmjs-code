// 获取应用实例
const app = getApp()
const { wxToast } = require("../../utils/index")
Page({
  /**
   * 页面的初始数据
   */
  data: {
    shops: [],
    query: {
      page: 0,
      size: 10
    },
    sn: "",
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
    collectShow: [],
    snList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.sn = options.sn
    this.getShops(this.data.sn)
  },

  //上拉加载
  pullDown() {
    if (this.data.hasMore) {
      this.getShops(this.data.sn)
    }
  },
  //下拉刷新
  pullUp() {
    this.data.shops = []
    this.data.query = {
      page: 0,
      size: 10
    },
      this.getShops(this.data.sn)
    this.setData({
      refresherTriggered: false
    })
  },
  //跳转商铺主页
  goShop(e) {
    wx.navigateTo({
      url: `/packageA/pages/shop-home/index?sn=${e.detail.sn}`
    })
  },
  //获取商铺列表
  getShops(sn) {
    const query = this.data.query
    this.setData({
      "isLoading": true
    })
    app.get(`/ec/common/info/flow/item/page/${sn}`, query).then(async res => {
      this.data.query.page++
      let data = await app.formatterShops(res.content, {width: 140, height: 140})
      this.setData({
        "shops": this.data.shops.concat(data),
        // res.last  false:没有到最后一页  true:是最后一页
        "hasMore": !res.last,
        "isLoading": false
      })
    })
  },
  setCollect(e) {
    const { shopItem, index } = e.detail
    console.log(shopItem);
    if (shopItem.isCollect) {
      app.del("/md/inst/user/follow/cancel/shop/" + shopItem.sn).then(res => {
        if (res) {
          wxToast("取消收藏成功")
          const list = this.data.shops
          list[index].isCollect = false
          this.setData({
            "shops": list,
          })
        }
      })
    } else {
      app.post("/md/inst/user/follow/shop/"+shopItem.sn, {  bodyTitle:shopItem.title, source: "home" }).then(res => {
        if (res) {
          wxToast("收藏成功")
          const list = this.data.shops
          list[index].isCollect = true
          this.setData({
            "shops": list,
          })
        }
      })
    }
  },
})
