const { formatterTime, formatterMultidigitMoney} = require("../../utils/index")
const app = getApp()
const oldTicketSn = {
  goods: "goodsTicket",
  shop: "shopTicket",
  app: "appTicket",
}
const newTicketSn = {
  goods: "newgoodsTicket",
  shop: "newshopTicket",
  app: "newappTicket",
}
const message = {
  goods: "goodsMessage",
  shop: "shopMessage",
  app: "appMessage",
}
Page({
  data: {
    // 商品单号
    sn: "",
    // 订单类型
    type: "group",
    orderList: [],
    // 推荐码
    scancode: "",
    showContactService: true
  },
  onLoad: function ({type, sns}) {
    this.setData({ type, sn: sns })
    // this.inquireRole()
  },
  onShow(options) {
    this.getData()
  },
  // 检查是否有配置客服
  checkService(sn) {
    return new Promise(resolve => {
      if (!sn) {
        resolve(false)
        return
      }
      app.post(`/mk/common/csc/client/check`, {
        "scopeType": "shop",
        "scopeValue": sn,
        "from": "minapp",
        "source": "耗品GO"
      }).then(res => {
        resolve(res.success)
      }).catch(() => {
        resolve(false)
      })
    })
  },
  // 初始化数据
  getData() {
    app.get(`/ec/order/group/list/${this.data.sn}`).then(async res => {
      let goodsPic = []
      res.forEach(item => {
        item.items.forEach(async (shopItem) => {
          this.checkService(shopItem.bizEcShopSn).then(res => {
            shopItem.customerService = res
          })
          shopItem.orderItems.forEach(orderItem => {
            goodsPic.push(orderItem.ossId)
          })
        })
      })
      let picIndex = 0
      goodsPic = await app.picSnGetUrl(goodsPic, { width: 180, height: 180 })
      res.forEach(item => {
        item.items.forEach(async (shopItem) => {
          shopItem.orderItems.forEach(orderItem => {
            orderItem.newImg = goodsPic[picIndex]
            picIndex += 1
          })
        })
      })
      this.setData({
        orderList: res
      })
    })
  },
  getPayDefSn(version) {
    return new Promise((resolve, reject) => {
      app.get(`/pay/def?version=${version}`).then(res => {
        if (res) {
          resolve(res.data)
        }
      })
    })
  },
  async submitPay(e) {
    const { sn, payVersion } = e.target.dataset
    const payDefSn  = await this.getPayDefSn(payVersion)
    app.put(`/ec/order/group/submit/${sn}?payDefSn=${payDefSn}`).then(res => {
      if (res) {
        if (res.paySn) {
          const url =  `/pages/cashier/index?paySn=${res.paySn}&sn=${res.sn}&source=payOrder&orderCount=${this.data.orderList.length}&type=group&payVersion=${payVersion}`
          // 去收银台
          if (this.data.orderList.length === 1) {
            wx.redirectTo({
              url: url
            })
          } else{
            wx.navigateTo({
              url: url
            })
          }
        } else {
          wx.showToast({
            title: '支付成功',
            duration: 2000,
            success: () => {
              setTimeout(() => {
                if (this.data.orderList.length === 1) {
                  wx.redirectTo({
                    url: `/pages/order-data/index?name=all`
                  })
                  return
                }
                this.getData()
              }, 2000)
            }
          })
        }
      }
    })
  },
  // 获取默认推荐人
  getDefReferrer() {
    app.get(`/mk/project/ring/user/find/commend/ec_order/${this.data.role.type}`).then(res => {
      if (res) {
        this.setData({
          referrerName: res.name,
          scancode: res.code
        })
      }
    })
  },
  // 订阅支付成功信息
  handleSubPay() {
    let _that = this
    let messageTemplatesSn = app.globalData?.appConfig?.notice_wx_message_template || ''
    app.get(`/sys/wx/applet/message/template/list/${JSON.parse(messageTemplatesSn).join(',')}`).then(tems => {
      let messageTemplates = tems.map(item => item.templateId)
      wx.requestSubscribeMessage({ //获取下发权限
        tmplIds: messageTemplates, //此处写在后台获取的模板ID，可以写多个模板ID，看自己的需求
        success: (res) => {
          let accept = []
          let unaccept = []
          tems.forEach(item => {
            if (res[item.templateId] == 'accept') {
              accept.push(item.sn)
            } else {
              unaccept.push(item.sn)
            }
          })
          if (!accept.length) {
            // 取消订阅接口
            app.post(`/sys/user/wx/message/template/batch/disubscribe/${unaccept.join(',')}`)
          } else if (!unaccept.length) {
            // 订阅接口
            app.post(`/sys/user/wx/message/template/batch/subscribe/${accept.join(',')}`)
          } else {
            app.post(`/sys/user/wx/message/template/batch/disubscribe/${unaccept.join(',')}`)
            app.post(`/sys/user/wx/message/template/batch/subscribe/${accept.join(',')}`)
          }
          // 成功
          /* tems.forEach(item=>{
            if (res[item.templateId] == 'accept') { //accept--用户同意 reject--用户拒绝 ban--微信后台封禁,可不管
              // 下发接口
              app.post(`/sys/user/wx/message/template/subscribe/${item.sn}`).then(res=>{
                if(res){
                  // 业务逻辑
                }
              })
            }
            else {
              // 取消下发接口
              app.post(`/sys/user/wx/message/template/disubscribe/${item.sn}`).then(res=>{
                if(res){
                  // 业务逻辑
                }
              })
            }
          }) */
        },
        fail: (err) => {
          console.log('订阅失败', err.errMsg);
        },
        complete: () => {
          _that.handeleGoCashier()
        }
      })
    })
  },
  // 立即支付
  async handeleGoCashier() {
    // 确认下单
    let scancode = encodeURIComponent(this.data.scancode)

    // 提交备注以及取货方式
    const remark = this.selectAllComponents(".shopItem").map(item => {
      return item.getRemarkAndPayType()
    })

    // 是产业用户不带请求链接 code
    const url = this.data.showReferrerComp
      ? `/ec/order/code/${this.data.sn}?code=${scancode}`
      : `/ec/order/code/${this.data.sn}`
    const result = await app.put(url, remark)
    if (!result) {
      return
    }
    // 添加推荐人
    // if(scancode){
    //   let data = {
    //     inviteInstanceCode: scancode,
    //     type: "code"
    //   }
    //   let addcode = await app.post(`/mk/project/ring/user`, data)
    //   if(!addcode)return;
    // }

    // 接口变更，买家备注统一到合并submit接口
    // await app.put(`/ec/order/group/message/${this.data.sn}`, remark)

    // 提交生成支付sn
    app.put(`/ec/order/group/submit/${this.data.sn}`, []).then(res => {
      if (res?.success) {
        if (res.paySn) {
          // 去收银台
          wx.redirectTo({
            url: `/pages/cashier/index?paySn=${res.paySn}&sn=${res.sn}&type=group`
          })
        } else {
          // 弹窗
          // 0元支付 去待发货页面
          wx.redirectTo({
            url: `/pages/order-data/index?name=all`
          })
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  showReferrer({detail}) {
    this.setData({showReferrerComp: detail})
  },
  toService(e){
    const { shopsItem } = e.target.dataset
    const params = encodeURIComponent(JSON.stringify({
      sn: shopsItem.bizEcShopSn, // 店铺sn
      name: shopsItem.orderItems[0]?.bizEcGoodsName, // 商品名称
      image: shopsItem.orderItems[0]?.ossId, // 商品的图片
      orderPrice: formatterMultidigitMoney(shopsItem.payableAmount), // 总价格
      orderSn: shopsItem.sn, // 订单号
      orderDate: formatterTime(shopsItem.createAt * 1000), // 下单时间
      quantityGoods: shopsItem.totalQuantity, // 商品总数
    }))
    wx.navigateTo({
      url: `/packageB/pages/tim/tim?sn=${shopsItem.bizEcShopSn}&title=${shopsItem.bizEcShopName}&orderInfo=${params}`
    })
  },
  // 复制单号
  onCopy(e) {
    wx.setClipboardData({
      data: e.target.dataset.ordernum,
      success: function (res) {
      }
    })
  },
})
