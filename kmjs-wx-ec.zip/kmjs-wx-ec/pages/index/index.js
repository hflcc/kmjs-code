import {formatterTime ,scopeType} from "../../utils/index"
import { handleEvent } from '../../utils/infoFlowEvents'
const app = getApp()
// 层级一分页信息
const pagingLevel1 = {
  page: 0,
  size: 10
}
// 层级二分页信息
const pagingLevel2 = {
  page: 0,
  size: 10
}
// 表示一级每个sn是否带有子集
let firstTabHasNext = {}
Page({
  data: {
    upFlowStyle: '',
    decorateInfoFlowSn: '',
    isCategoryTabFixed: false,
    cutFlowBgParams: {
      upHeight: 260,
      downHeight: 1000
    },
    // 胶囊距离顶部
    capsuletop: app.menuBoundingMsg["top"],
    // 胶囊高度
    capsuleheight: app.menuBoundingMsg["height"] - 1,
    // 搜索
    searchVal: "请输入搜索关键词",

    // 首页 tabs 列表
    firstTabList: [],
    // 选中 tab 的 sn
    firstActiveTab: "",
    // 表示一级每个sn是否结束
    firstTabIsEnd: {},
    // 二级 tabs 列表
    secendTabList: [],
    // 选中 二级 tab 的 sn
    secendActiveTab: "",
    // 表示二级每个sn是否结束
    secendTabIsEnd: {},
    // 一级信息流
    firstMessageBuffer: [],
    // 二级信息流
    secondMessageBuffer: [],
    // 是否刷新中
    refresherTriggered: false,
    //tabSn
    tabSn:'',
    // 美博会优惠券
    mbhcoupon:false,
    // 新人优惠券
    newcoupon:false,
    // 美博会优惠券列表
    mbhCouponList:[],
    // 新人优惠券列表
    newCouponList:[],
    // 美博会礼包
    mbhCp_btn_txt:'',
    // 新人礼包
    newCp_btn_txt:'',
    // 美博会优惠券标题
    mbhTitle:'美博会礼包',
    // 新人优惠券标题
    newTitle:'新人礼包',

  },
  onLoad: function(options) {
    app.eventBus.on('setTab', this.setTab);
    // 由app启动onlacunch时调用接口请求
    if (!this.data.decorateInfoFlowSn) {
      app.eventBus.on('getIndexInfoFlowSn', (sn) => {
        this.setData({
          decorateInfoFlowSn: sn
        })
      })
    }
  },
  async onShow(){
    if (!this.data.decorateInfoFlowSn) {
      this.setData({
        decorateInfoFlowSn: app.globalData?.indexInfoFlowSn || ''
      })
    }
    let t = 4 * 60 * 60 * 1000
    // 美博会
    let ST = wx.getStorageSync(app.globalData.userInfo.InstId.id+'mbh_coupon_showtime')||0
    // 新人优惠券
    let newST = wx.getStorageSync(app.globalData.userInfo.InstId.id+'new_coupon_showtime')||0
    // 美博会券 9月4日-9月6日 未登录4小时弹一次
    if(new Date('2021/9/4').getTime() < Date.now() && Date.now() < new Date('2021/9/7').getTime() && (Date.now() - ST > t)){
      if(app.globalData.userInfo.token){
        // 登录
        this.getNewCoupon('mbh')
        this.setData({
          mbhCp_btn_txt:'查看我的优惠券'
        })
      }else{
        // 未登录优惠券礼包
        app.get(`/mk/ticket/instance/group/${'mbh'}`).then(res=>{
          if(res instanceof Array  && res.length){
            this.formattingNewCP(res)
          }else{
            this.setData({
              mbhcoupon:false
            })
          }
        })
        this.setData({
          mbhCp_btn_txt:'点击领取',
        })
      }
    }
    // 新人优惠券 未登录4小时弹一次
    if(Date.now() - newST > t){
      if(app.globalData.userInfo.token){
        // 登录
        this.getNewCoupon('register')
        this.setData({
          newCp_btn_txt:'查看我的优惠券'
        })
      }else{
        // 未登录优惠券礼包
        let res = await app.commonTicket('register')
        if(res instanceof Array && res.length){
          this.formattingNewCP(res,'register')
        }else{
          this.setData({
            newcoupon:false
          })
        }
        this.setData({
          newCp_btn_txt:'点击领取',
        })
      }
    }
  },
  /*
  * @info 统一收集处理信息流点击事件
  * */
  async handleFlowEmit(e) {
    const clickData = e.detail
    await handleEvent(clickData)
  },
  /*
  * @Info 获取信息流背景数据
  * */
  handleGetFlowBg (e) {
    const { upFlowBgUrl, flowBgColor } = e.detail
    if (upFlowBgUrl) {
      this.setData({
        upFlowStyle: `background: url(${upFlowBgUrl}) no-repeat;background-size: 100% 100%;`
      })
    } else if (flowBgColor) {
      this.setData({
        pageStyle: this.data.pageStyle += `background: ${flowBgColor};`
      })
    } else {
      this.setData({
        pageStyle: ''
      })
    }
  },
  /*
  * @info 获取信息流分类组吸顶与否
  * */
  handleFlowTabFixed (e) {
    const bool = e.detail
    this.setData({
      isCategoryTabFixed: bool
    })
    wx.setNavigationBarColor({
      backgroundColor: '#ffffff',
      frontColor: bool ? '#000000' : '#ffffff',
      animation: {
        duration: 400,
        timingFunc: 'easeInOut'
      }
    })
  },
  // 分享
  onShareAppMessage: function (e) {

  },
  onShareTimeline:function (e) {},
  //获取美博会优惠券列表
  async getNewCoupon(type){
    let res = await app.checkNewCoupon(type?.detail || type)
    if(res){
      this.formattingNewCP(res,type)
    }else{
      if(type=='mbh'){
        this.setData({
          mbhcoupon:false
        })
      }else{
        this.setData({
          newcoupon:false
        })
      }
    }
  },
  // 格式化美博会优惠券格式
  formattingNewCP(res,type){
    if(res instanceof Array){
      if(res.length){
        res.forEach(item=>{
          item.scopeNmae = scopeType[item.scopeType]
          item.endATString = formatterTime(item.endAt *1000,'YMD','.')
          item.startATString = formatterTime(item.startAt *1000,'YMD','.')
        })
      }
      if(type === 'mbh'){
        // 美博会
        this.setData({
          mbhCouponList:res,
          mbhcoupon:true
        })
        // 记录美博会礼包弹出时间
        wx.setStorage({
          key: app.globalData.userInfo.InstId.id+'mbh_coupon_showtime',
          data: Date.now(),
        });
      }else{
        // 新人礼包
        this.setData({
          newCouponList:res,
          newcoupon:true
        })
        // 记录美博会礼包弹出时间
        wx.setStorage({
          key: app.globalData.userInfo.InstId.id+'new_coupon_showtime',
          data: Date.now(),
        });
      }
    }
  },
  // 关闭美博会优惠券
  closembhcp(){
    this.setData({
      mbhcoupon:false
    })
  },
  // 关闭新人优惠券
  closenewcp(){
    this.setData({
      newcoupon:false
    })
  },
  //一级tab栏切换
  setTab(e){
    let tabSn = e;
    this.setData({tabSn});
    this.tabChange();
  },
  // 重置所有数据
  /*resetAllData() {
    return new Promise((resolve, reject) => {
      firstTabHasNext = {}
      pagingLevel1.page = 0
      pagingLevel2.page = 0
      this.setData({
        // 首页 tabs 列表
        firstTabList: [],
        // 选中 tab 的 sn
        firstActiveTab: "",
        // 表示一级每个sn是否结束
        firstTabIsEnd: {},
        // 二级 tabs 列表
        secendTabList: [],
        // 选中 二级 tab 的 sn
        secendActiveTab: "",
        // 表示二级每个sn是否结束
        secendTabIsEnd: {},
        // 一级信息流
        firstMessageBuffer: [],
        // 二级信息流
        secondMessageBuffer: []
      })
      wx.nextTick(() => {
        resolve()
      })
    })
  },*/
  async onReady() {
    // hack
    setTimeout(() => {
      const result = app.getMenuBoundingMsg()
      this.setData({
        // 胶囊距离顶部
        capsuletop: result.top,
        // 胶囊高度
        capsuleheight: result.height - 1,
      })
    }, 1000)
    // 初始化数据
    // await this.getFirstTabList()

    // ***************************
    const result = await this.getHometabs('', 'zqhd') // 中秋活动数据，原美博会参数 mdh
    // if (result) {
    //   wx.setStorage({ key: 'mbhSn', data: result?.[0]?.sn })
    // }
  },
  // 初始化一级菜单的信息
  /*async getFirstTabList() {
    const result = await this.getHometabs()
    if (Array.isArray(result) && result.length > 0) {
      const firstTabList = result.map(({ sn, name, hashNext }) => {
        firstTabHasNext[sn] = hashNext
        this.data.firstTabIsEnd[sn] = false
        return {
          sn,
          name
        }
      })
      this.setData({
        firstTabList,
        firstActiveTab: firstTabList[0].sn,
        firstTabIsEnd: this.data.firstTabIsEnd
      })
      this.getAndFormatterFirstMessageBuffer(firstTabList[0].sn, pagingLevel1)
      // https://vant-contrib.gitee.io/vant-weapp/#/tab#jie-jue-fang-fa
      // wx.nextTick(() => {
      //   this.selectComponent("#tabs").resize()
      // })
    }
  },
  // 获取二级tab的数据
  async getSecondTabList(sn) {
    const result = await this.getHometabs(sn)
    if (Array.isArray(result) && result.length > 0) {
      const secendTabList = result.map(({ sn, name, description }) => {
        this.data.secendTabIsEnd[sn] = false
        return {
          sn,
          name,
          description
        }
      })
      this.setData({
        secendActiveTab: result[0].sn,
        secendTabList,
        secendTabIsEnd: this.data.secendTabIsEnd
      })
      await this.getAndFormatterSecendMessageBuffer(result[0].sn, pagingLevel2)
    }
  },
  // 获取和格式化层级 1 的数据
  async getAndFormatterFirstMessageBuffer(sn, paging) {
    const res = await this.getHomeData(sn, paging)
    if (!res) {
      return
    }
    const bufferMsg = this.data.firstMessageBuffer
    bufferMsg.push(...await app.formatterContent(res.content))
    this.setData({
      firstMessageBuffer: bufferMsg
    })
    wx.nextTick(() => {
      // 如果当前的一级菜单已经加载完毕,并且当前一次菜单有二级的tab时;那么我们去加载第二级别的菜单
      if (res.last) {
        this.data.firstTabIsEnd[sn] = true
        if (firstTabHasNext[sn]) {
          this.getSecondTabList(sn)
        }
        this.setData({
          firstTabIsEnd: this.data.firstTabIsEnd
        })
      }
    })
  },
  // 获取和格式化层级 2 的数据
  async getAndFormatterSecendMessageBuffer(sn, paging) {
    const result = await this.getHomeData(sn, paging)
    if (!result) {
      return
    }
    // 二级信息流
    let secondMessageBuffer = this.data.secondMessageBuffer
    const data = await app.formatterContent(result.content)
    secondMessageBuffer.push(...data)
    this.setData({
      secondMessageBuffer
    })
    wx.nextTick(() => {
      // 决定当前的tab是否还能加载更多
      if (result.last) {
        this.data.secendTabIsEnd[sn] = true
        this.setData({
          secendTabIsEnd: this.data.secendTabIsEnd
        })
      }
    })
  },*/
  // 一级tab切换
  tabChange(e) {
    const data = this.data
    // 拿出旧的一级菜单高亮的tab
    const oldFirstActiveTab = data.firstActiveTab
    // 拿出一级菜单是否已经渲染结束, 取反
    this.data.firstTabIsEnd[oldFirstActiveTab] = false
    // 页数回滚
    pagingLevel1.page = 0
    pagingLevel2.page = 0
    // 清空数据
    this.setData({
      secendTabIsEnd: {},
      firstActiveTab: e?e.detail.name:this.data.tabSn,
      scrollViewTop: 0,
      firstMessageBuffer: [],
      secendTabList: [],
      secondMessageBuffer: []
    })
    // this.getAndFormatterFirstMessageBuffer(e ? e.detail.name : this.data.tabSn, pagingLevel1)
  },
  // 二级tab切换
  /*changeGoodstab(e) {
    const data = this.data
    const item = e.currentTarget.dataset.data
    const oldSecendActiveTab = data.secendActiveTab
    // 切换二级tab时,将旧的是否结束置为false
    this.data.secendTabIsEnd[oldSecendActiveTab] = false
    if (item.sn == this.data.secendActiveTab) {
      return
    }
    pagingLevel2.page = 0
    this.getAndFormatterSecendMessageBuffer(item.sn, pagingLevel2)
    this.setData({
      secendActiveTab: item.sn,
      secondMessageBuffer: [],
      secendTabIsEnd: this.data.secendTabIsEnd
    })
  },
  // 获取信息流
  getHomeData(sn = "", paging) {
    return app.get(`/md/common/info/flow/instance/page/def_category_sn/${sn}`, paging)
  },*/
  // 获取Tab信息，type: home 首页; mbh 美博会; zqhd 中秋活动;
  getHometabs(parentSn = "", type = "home") {
    return app.get(`/md/common/info/flow/platform/list/category/${type}`, parentSn ? {
      parentSn
    } : "")
  },
  // 搜索
  gosearch() {
    wx.navigateTo({
      url: `/pages/search/index?v=${this.data.searchVal}`
    })
  }
})
