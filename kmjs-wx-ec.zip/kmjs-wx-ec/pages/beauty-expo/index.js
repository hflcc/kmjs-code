// pages/beauty-expo/index.js
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    showRuleDialog: false, // 是否显示活动规则
    listQuery: {
      page: 0,
      size: 30
    },
    currentSn: '',
    ecTheme: [], // 耗材区
    nationalTheme: [], // 国庆主题
    tempList: [],
    isLoading: true, // 数据loading
    hasMore: false, // 是否有更多数据
    refresherTriggered: false // 是否刷新中
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: async function(options) {
    this.setData({
      currentSn: options.sn
    })
    this.getDataList()
    // await wx.getStorage({
    //   key: 'mbhSn', 
    //   success: (res) => {
    //     this.setData({
    //       currentSn: res.data
    //     })
    //     this.getDataList()
    //   }
    // })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onShareTimeline:function (e) {
    return {title:'热销礼品 心动专享'}
  },
  getDataList() {
    this.setData({
      isLoading: true
    })
    app.get(`/md/common/info/flow/instance/page/def_category_sn/${this.data.currentSn}`, {
      page: this.data.listQuery.page,
      size: this.data.listQuery.size
    }).then(async res => {
      if (!res) {
        return
      }
      res.content.forEach(item => {
        item.type === 'zqTheme' ? 
        this.setData({ ecTheme: item.items, isLoading: false, hasMore: !res.last }) 
        : this.setData({ tempList: item.items, isLoading: false, hasMore: !res.last }) 
      })

      // 耗材区
      let ecTheme = []
      // 正常商品区
      let nationalTheme = []
      if (this.data.listQuery.page === 0) {
        ecTheme = await this.formatterBeautyExpoGoods(this.data.ecTheme)
        nationalTheme = await this.formatterBeautyExpoGoods(this.data.tempList)
      } else { // 上拉加载数据流
        nationalTheme = this.data.nationalTheme.concat(...await this.formatterBeautyExpoGoods(this.data.tempList))
      }

      this.setData({
        ecTheme,
        nationalTheme
      })
    })
  },
  formatterBeautyExpoGoods(list) { // 格式化美博会数据
    return new Promise(async (resolve) => {
      let bannerList = list.map(item => {
        const data = item.data
        return (data.coverImages && data.coverImages[0] && data.coverImages[0].ossId) || ''
      })
      bannerList = await app.picSnGetUrl(bannerList, { width: 278, height: 278 })
      bannerList = list.map((item, index) => {
        const data = item.data
        return {
          actionType: item.actionType, // 行为
          sn: item.actionSn, // 唯一sn
          img: bannerList[index], // 图片地址
          price: data.minPrice, // 价格
          stepPrice: data.maxPrice, // 原价价格
          name: data.title, // 商品名称
          minNum: data.minNum, // 商品起批量
          status: 1 // 耗品区用，是否只能购买一次(暂时不做置灰，默认1)
        }
      })
      resolve(bannerList)
    })
  },
  pullDown() { // 上拉加载
    if (this.data.hasMore) {
      this.data.listQuery.page += 1
      this.getDataList()
    }
  },
  pullUp() { // 下拉刷新
    this.data.goodsList = []
    this.data.listQuery.page = 0
    wx.nextTick(() => {
      this.getDataList()
    })
    this.setData({
      refresherTriggered: false
    })
  },
  closeRule() { // 关闭说明
    this.setData({ showRuleDialog: false })
  },
  showRule() { // 打开说明
    this.setData({ showRuleDialog: true })
  },
  async buynow(event) {
    const { sn, once } = event.detail

    // if (once === 'true' && app.globalData.userInfo.token) {
      // if (once === 'true') {
      // 跳转之前先调接口领取优惠券，商品详情的接口返回的promotePrices字段才会有数据
      // await app.post(`/mk/ticket/instance/goods/${sn}`)
    // }

    // 跳转商品详情页
    wx.navigateTo({
      url: `/pages/goods-detail/index?sn=${sn}`
    })
  }
})