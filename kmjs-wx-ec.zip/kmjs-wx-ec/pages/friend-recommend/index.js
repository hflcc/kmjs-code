// pages/friend-recommend/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scene: "",
    friend: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      scene: options.scene
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData(this.data.scene)
  },
  // 获取缓存到后台的数据字符串
  getData(scene) {
    return new Promise(async (resolve, reject) => {
      const data = {}
      // 获取存在后台的缓存字符串
      let sourceData = await app.get(`/sys/common/params/${scene}`)
      if (!sourceData) {
        reject(new Error("scene有误"))
        return wx._showToast("scene有误")
      }
      sourceData = sourceData.value
      sourceData.match(/(\w+)=(\w+)/g).forEach(item => {
        const res = item.split("=")
        data[res[0]] = res[1]
      })
      // 绑定关系
      app.post(`/mk/project/ring/user`, {
        "inviteInstanceCode": data.sn,
        "type": data.type
      })
      // 获取邀请信息
      let pro
      if (data.type === "code") {
        pro = app.put("/mk/invite/code/" + data.sn)
      } else if (data.type === "instance") {
        pro = app.put("/mk/invite/instance/" + data.sn)
      }
      const friend = await pro
      if (!friend) {
        return
      }
      // 获取图片
      const picList = await app.picSnGetUrl([friend.finalImg])
      // 设置title
      wx.setNavigationBarTitle({
        title: friend.title
      })

      this.setData({
        friend: {
          ...friend,
          url: picList[0]
        }
      })
    })
  },
  goHome() {
    wx.reLaunch({
      url: "/pages/index/index"
    })
  }
})
