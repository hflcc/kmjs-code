// pages/my-asset/index.js
const {
  formatterMultidigitMoney
} = require("../../utils/index")
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    query: {
      page: 0,
      size: 10
    },
    accountPrice: [],
    // 是否有更多数据 还有最后一页
    hasMore: false,
    // 数据loading
    isLoading: true,
    // 是否刷新中
    refresherTriggered: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
   async onLoad(options) {
    // let currencySn = await this.sysConfig()
    // await this.accountInit(currencySn)
    // await this.getAccount();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  async onShow() {
    let currencySn = await this.sysConfig()
    await this.accountInit(currencySn)
    await this.getAccount();
  },
  //下拉刷新
  pullUp() {
    this.setData({
      accountPrice: []
    })
    wx.nextTick(() => {
      this.data.query.page = 0
      this.getAccount()
      this.setData({
        refresherTriggered: false
      })
    })
  },
  //上拉加载
  pullDown() {
    if (this.data.hasMore) {
      this.data.query.page += 1
      this.getAccount()
    }
  },
  getAccount() {
    this.setData({
      isLoading: true
    })
    app.get('/mk/member/account/page/current/type/inst', {
      page: this.data.query.page,
      size: this.data.query.size
    }).then(res => {
      if (res.content) {
        res.content.forEach(v => {
          v.balance = formatterMultidigitMoney(v.balance)
        })
        let accountPrice;
        if (this.data.query.page === 0) {
          accountPrice = []
        } else {
          accountPrice = this.data.accountPrice
        }
        this.setData({
          accountPrice: accountPrice.concat(res.content),
          "hasMore": !res.last,
          isLoading: false
        })
      }
    })
  },
  goDetails({
    currentTarget
  }) {
    let sn = currentTarget.dataset.sn;
    let name = currentTarget.dataset.name;
    wx.navigateTo({
      url: `/pages/asset-details/index?sn=${sn}&name=${name}`
    });
  },
  // 获取配置
  async sysConfig(){
    const key = 'member_currency'
    let res = await app.get(`/sys/config/property/key/${key}`)
    return res && res.value
  },
  // 初始化耗品卡账户
  async accountInit(currencySn){
    /* bizType会员类型 （先设置为inst，后续看产品要求)
     * inst 机构账户
     * user用户账户
     * inst_user机构用户
     */
    const bizType = 'inst'
    let res = await app.get(`/mk/member/account/init/${bizType}/${currencySn}`)
  }
})