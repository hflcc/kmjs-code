import { formatterMoney, formatterTime, removeLoginStatus, scopeType, wxToast } from "../../utils/index"
import Dialog from "@vant/weapp/dialog/dialog"
import { WXINFO } from "../../utils/constant"

const app = getApp()
Page({
  data: {
    // 登录态
    token: "",
    // 订单数量
    orderNumber: {},
    // 身份信息
    InstId: {},
    // 是否需要完善信息
    needFinishMsg: false,
    isFinishMsg: false,
    // 商品|店铺收藏;
    collect: 0,
    //我的足迹的数量
    footPrint: 0,
    //省钱总计
    money: "",
    //耗品GO方案
    projectList: [],
    //环销进来的机构名
    organization: "",
    // 未使用优惠券
    unUseCoupon: 0,
    // 新人优惠券
    newcoupon: false,
    // 新人优惠券列表
    newCouponList: [],
    showActions: false,
    actions: [{name: '在线客服', icon: 'https://resource.kmyun.cn/kmjs-wx-ec/online.png', type: 'online'},
      {name: '电话联系', icon: 'https://resource.kmyun.cn/kmjs-wx-ec/callphone.png', type: 'call'}]
  },
  async onLoad(option) {

    if (option.toAll) {
      wx.navigateTo({
        url: `/pages/order-data/index?name=all` // 2021-05-24 新需求 使用支付状态页替换提示 &toastType=${option.toastType}
      })
    }

  },
  onShow() {
    this.setData({
      InstId: app.globalData.userInfo.InstId || {}
    })
    this.loginChange()
  },
  // onShow时判断是否切换登录状态;
  loginChange() {
    this.setData({
      token: app.globalData.userInfo.token,
      orderNumber: {}
    })
    // 默认为空
    this.setData({ projectList: [] })
    if (app.globalData.userInfo.token) {
      // 获取用户是否完成信息认证
      this.checkedIsFinish()
      // 获取用户订单信息
      this.getOrderInfo()
      // 获取用户收藏数和足迹的数量
      this.getNum()
      this.getFoot()
      //获取用户省钱数据
      this.getMoney()
      //获取推荐列表
      this.getReferrer()
      //获取新人优惠券列表
      this.getNewCoupon()
    }
  },
  //获取新人优惠券列表
  async getNewCoupon() {
    let res = await app.checkNewCoupon()
    // 优惠券数量
    this.getCouponCount()
    if (res) {
      if (res instanceof Array) {
        if (res.length > 0) {
          res.forEach(item => {
            item.scopeNmae = scopeType[item.scopeType]
            item.endATString = formatterTime(item.endAt * 1000, "YMD", ".")
            item.startATString = formatterTime(item.startAt * 1000, "YMD", ".")
          })
        }
        this.setData({
          newCouponList: res,
          newcoupon: true
        })
      }
    } else {
      this.setData({
        newcoupon: false
      })
    }
  },
  // 关闭新人优惠券
  closecp() {
    this.setData({
      newcoupon: false
    })
  },
  // 查看我的优惠券
  goCoupon() {
    if (app.loginJump()) {
      wx.navigateTo({
        url: "/pages/mine-coupons/index"
      })
    }
  },
  // 优惠券数量
  getCouponCount() {
    app.get(`/mk/ticket/instance/count/current`).then(res => {
      if (res) {
        this.setData({
          unUseCoupon: res.none
        })
      }
    })
  },
  //#region 订单相关的
  // 获取用户订单
  getOrderInfo() {
    app.get("/ec/order/total").then((orderNumber) => {
      if (orderNumber) {
        let all = 0
        for (const orderNumberKey in orderNumber) {
          all += orderNumber[orderNumberKey] || 0
        }
        this.setData({
          orderNumber: {
            none: (orderNumber.none || 0) + (orderNumber.pay || 0),
            deliver: orderNumber.deliver,
            receiving: orderNumber.receiving,
            saled: orderNumber.saled,
            all
          }
        })
      }
    })
  },
  // 订单相关
  checkedOrder(e) {
    if (app.loginJump()) {
      const name = e.currentTarget.dataset.name
      if (name == "saled") {
        wx.navigateTo({
          // 详情页
          url: "/pages/after-sale-list/index"
        })
      } else {
        wx.navigateTo({
          // 详情页
          url: `/pages/order-data/index?name=${name}`
        })
      }
    }
  },
  //#endregion
  //#region 完善信息相关逻辑
  // 获取用户是否完成信息认证
  checkedIsFinish() {
    return app.get("/sys/user/current/check/integrity").then(res => {
      if (res.wx && res.wxInfo) {
        // 是否完善信息
        if (res.wxInfo.nickName) {
          const { headimgUrl, nickName } = res.wxInfo
          wx.setStorageSync(WXINFO, { headimgUrl, nickName })
          this.setData({
            isFinishMsg: false
          })
        } else {
          this.setData({
            isFinishMsg: true
          })
        }
      }
    })
  },
  // 完善信息
  finishMsg() {
    wx.getUserProfile({
      desc: "获取用户信息",
      success: ({ encryptedData, iv }) => {
        app.put("/sys/user/wx/integrity", {
          encryptedData,
          iv
        }).then(res => {
          if (res) {
            this.checkedIsFinish()
            wxToast("完善信息成功", "success")
          }
        })
      }
    })
  },
  //#endregion
  //#region 登录相关的
  // 点击登录
  login: function () {
    if (app.loginJump()) {
      return
    }
  },
  // 退出登录
  logout() {
    Dialog.confirm({
      title: "确定退出?",
      message: "退出登录后将无法查看订单\n重新登录即可查看"
    }).then(() => {
      removeLoginStatus(app)
      this.loginChange()
    }, () => {
    })
  },
  //#endregion
  // 点击 cell 模块
  clickCell(e) {
    const type = e.currentTarget.dataset.type
    const projectData = e.currentTarget.dataset.data
    if (type === "contact-service") {
      this.setData({
        showActions:true
      })
      return
    }
    if (app.loginJump()) {
      if (type === "address-manage") {
        wx.navigateTo({
          url: "/pages/address/index"
        })
      } else if (type === "referrer") {
        if (projectData) {
          wx.navigateTo({
            url: `/pages/referrer/index?form=self&projectSn=${projectData.sn}&type=${projectData.type}`
          })
        } else {
          wx.navigateTo({
            url: `/pages/add-referrer/index`
          })
        }
      } else if (type === "invite-friends") {
        wx.navigateTo({
          url: `/pages/invite-friends/index?projectSn=${projectData.sn}`
        })
      } else if (type === "my-group") {
        wx.navigateTo({
          url: `/pages/my-spelling/index`
        })
      } else if (type === "balance") {
        // 耗采购
        wx.navigateTo({
          url: `/pages/my-asset/index`
        })
      }
    }
  },
  // 获取收藏和足迹的数量
  getNum() {
    app.get("/md/inst/user/follow/count").then(res => {
      if (typeof res === "number") {
        this.setData({ collect: res })
      }
    })
  },
  getFoot() {
    app.get("/assist/inst/user/browse/count").then(res => {
      if (typeof res === "number") {
        this.setData({ footPrint: res })
      }
    })
  },
  // 编辑身份
  goSelectOrganization() {
    wx.navigateTo({
      url: "/pages/select-organization/index"
    })
  },
  // 商品收藏
  goCollect(e) {
    if (app.loginJump()) {
      let index = e.currentTarget.dataset.index
      wx.navigateTo({
        url: `/pages/collect/index?index=${index}`
      })
    }
  },
  // 跳转我的足迹
  goFootprint() {
    if (app.loginJump()) {
      wx.navigateTo({
        url: `/pages/footprint/index`
      })
    } else {

    }
  },
  //省钱详情
  goLook() {
    if (app.loginJump()) {
      wx.navigateTo({
        url: "/packageB/pages/statement/index"
      })
    }
  },
  //获取省钱额度
  getMoney() {
    app.get("/bi/inst/order/day/all").then(res => {
      if (res) {
        this.setData({ money: formatterMoney(res.preferentialAmount) })
      }
    })
  },
  //获取推荐人sn
  getReferrer() {
    app.get("/mk/project/ring/def/list").then(res => {
      if (res) {
        this.setData({ projectList: res })
      }
    })
  },
  onSelectActions(event) {
    const type = event.currentTarget.dataset.type
    if (type === 'call') {
      wx.makePhoneCall({
        phoneNumber: app.globalData.appConfig.customer_tel
      })
    } else if (type === 'online') {
      wx.navigateTo({url: '/packageB/pages/tim/tim'})
    }
    this.setData({ showActions: false });
  },
})
