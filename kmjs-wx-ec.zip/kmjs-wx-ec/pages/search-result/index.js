// pages/search-result/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 当前渲染的数据是 商品: goods; 店铺: shop
    active: "",
    // 分类信息列表; goods商品, shop店铺
    classify: [],
    // 搜索字段
    searchValue: "",
    // 数据集合
    lists: [],
    // 历史搜索
    old: [],
    // 是否含有更多
    hasMore: false,
    // 数据loading
    isLoading:true,
    // 分页数据
    query: {
      page: 0,
      size: 30
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 设置搜索字段
    this.setData({ searchValue: options.v })
    // 获取tab数据
    this.getTabs()
  },
  onShow: function () {
    const that = this
    wx.getStorage({
      key: "hisSearch",
      success(res) {
        that.setData({ old: res.data })
      }
    })
  },
  // 搜索
  onSearch(e){
    let value = e.detail
    this.data.old.unshift(value)
    wx.setStorage({
      key: "hisSearch",
      data:[...new Set(this.data.old)].slice(0,10)
    })
    wx.redirectTo({
      url: `/pages/search-result/index?v=${value}`
    })
  },
  productDetail(e) {
    let { sn } = e.detail
    wx.navigateTo({
      // 商品地址
      url: `/pages/goods-detail/index?sn=${sn}`
    })
  },
  storeDetail(e) {
    wx.navigateTo({
      // 店铺地址
      url: `/packageA/pages/shop-home/index?sn=${e.detail.sn}`
    })
  },
  // 改变tab
  changeClassify(e) {
    const query = this.data.query
    query.page = 0
    this.selectComponent("#pull").initTime()
    this.setData({
      active: e.target.dataset.value,
      query,
      lists: []
    })
    this.getSearchData()
  },
  // 获取tab
  getTabs() {
    app.get(`/si/common/search/group`).then(res => {
      this.setData({
        classify: res,
        active: res[0].type
      })
      this.getSearchData()
    })
  },
  // 加载更多
  pullDown() {
    if (this.data.hasMore) {
      const query = this.data.query
      query.page += 1
      this.setData({
        query
      })
      wx.nextTick(() => {
        this.getSearchData()
      })
    }
  },
  //下拉刷新
  pullUp(){
    this.data.lists = [];
    this.data.query={
      page:0,
      size:10
    },
    wx.nextTick(() => {
      this.getSearchData()
    })
    this.setData({
      refresherTriggered: false
    });
  },
  // 获取搜索的数据
  getSearchData() {
    this.setData({
      isLoading:true
    })
    let { page, size } = this.data.query
    let data = {
      page,
      size,
      title: `${this.data.searchValue},like`
    }
    app.get(`/si/common/search/${this.data.active}`, data).then(async (res) => {
      const oldList = this.data.lists
      let lists = res.content
      // let lists = res.content.map(item => {
      //   return item.actionSn
      // })
      // lists = await app.snToShopOrGoodAndPic(lists, this.data.active)
      if (this.data.active === "goods") {
        lists = await app.formatterGoods(lists)
      } else if (this.data.active === "shop") {
        lists = await app.formatterShops(lists)
      }
      this.setData({
        hasMore: !res.last,
        lists: oldList.concat(lists),
        isLoading:false
      })
    })
  }
})
