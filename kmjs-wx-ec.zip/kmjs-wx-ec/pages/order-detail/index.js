// pages/address/index.js
const {
  ORDERSTATUS,
  formatterTime,
  formatterMultidigitMoney
} = require("../../utils/index")
const app = getApp()
import Dialog from "@vant/weapp/dialog/dialog"

let orderData
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 胶囊距离顶部
    capsuletop: app.menuBoundingMsg["top"],
    // 胶囊高度
    capsuleheight: app.menuBoundingMsg["height"] - 1,
    // 订单唯一表示
    sn: "",
    // 订单信息
    orderInfo: {},
    goshow: true,
    isShowService: false
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function ({sn}) {
    this.setData({
      sn
    })
    // this.getData()
  },
  onShow: function () {
    if (this.data.goshow) {
      this.getData()
    } else {
      return
    }
  },
  // 检查是否有配置客服
  checkService(sn) {
    if (!sn) {
      return
    }
    app.post(`/mk/common/csc/client/check`, {
      "scopeType": "shop",
      "scopeValue": sn,
      "from": "minapp",
      "source": "耗品GO"
    }).then(res => {
      this.setData({isShowService: res.success})
    })
  },
  // 获取数据
  getData() {
    app.get(`/ec/order/${this.data.sn}`).then(res => {
      if (res) {
        this.formatterData(res)
      }
    })
  },
  // 格式是否可以申请按钮
  formatterBtnApplyForAfterSald({ saledCloseAt, saledState, beRefund }, { state }) {
    saledCloseAt = saledCloseAt * 1000
    // 01.订单状态为: deliver("待发货", 4), receiving("待收货", 5), comment("待评论", 6), complete("已完成", 7);
    if (state === "deliver" || state == "delivering" || state === "receiving" || state === "comment" || state === "complete") {
      // 02.订单关闭时间需要大于当前时间
      if (saledCloseAt > new Date().getTime() || saledCloseAt === 0) {
        // 03.没有退款并且没有在售后中
        if (!beRefund && saledState != "process") {
          return true
        }
      }
    }
    return false
  },
  // 格式化数据
  async formatterData(data) {
    orderData = data
    // 订单信息
    const orderInfo = {
      // 是否有快递信息
      isExpir: false,
      //按钮展示状态,申请售后
      btnAfterSale:data.state == "deliver",
      // 按钮展示状态,去支付按钮
      btnGoPay: data.state === "none" || data.state === "pay",
      // 按钮展示状态,取消订单
      btnCancelOrder: data.state === "none" || data.state === "pay",
      // 按钮展示状态,查看物流
      btnCheckLogistics: data.state === "receiving",
      // 按钮展示状态,确认收货
      btnSubmitReceiver: data.state === "receiving",
      // 按钮展示状态,再次采购
      btnReBuy: false, // data.state === "complete",
      // 按钮展示状态,申请售后
      btnApplyForAfterSald: false,
      // 卖家留言
      message: data.message || "",
      // 支付实例sn
      payInstanceSn: data.payInstanceSn,
      //支付版本
      payVersion: data.payVersion
    }
    // 订单信息
    const billSn = data.deliver && data.deliver.billSn
    // 订单信息
    let billMsg = {
      // 最后一条物流时间字符串
      timerStr: "",
      // 最后一条状态
      status: "",
      // 物流图标
      logo: ""
    }
    if (billSn) {
      const result = await app.get(`/ec/deliver/search/${this.data.sn}`)
      if (result) {
        const last = Array.isArray(result.statusList) && result.statusList[0] || {}
        billMsg.logo = result.logo
        billMsg.timerStr = last.time
        billMsg.status = last.status
      }
      orderInfo.isExpir = true
    }
    // 收货信息
    const areaSn = data.address && data.address.areaSn
    // 区域信息
    let area = ""
    if (areaSn) {
      // 根据区域sn换取地址信息
      const result = await app.get(`/md/area/def/item/${areaSn}`)
      area = app.area(result)
    }
    let payTransAt = 0
    if (Array.isArray(data.pays) && data.pays.length > 0) {
      payTransAt = data.pays[data.pays.length - 1].transAt
    }
    // 订单信息

    orderInfo.orderMsg = {
      // 订单状态
      status: data.state,
      // 订单状态文字
      statusText: data.state=='compose'?ORDERSTATUS[data.bizSource]:ORDERSTATUS[data.state],
      // 物流图标
      logisticsMsgLogo: billMsg.logo || "",
      // 最后一条物流时间, 需要查询物流
      timerString: billMsg.timerStr || "",
      // 最后一条物流信息, 需要查询物流
      lastLogisticsMsg: billMsg.status || "",
      // 订单信息
      orderNo: data.sn,
      // 下单时间
      submitTime: formatterTime(data.createAt * 1000),
      // 支付时间
      payTime: formatterTime(payTransAt * 1000),
      // 发货时间
      sendTime: formatterTime((data.deliver && data.deliver.deliveryAt) ? data.deliver && data.deliver.deliveryAt * 1000 : ""),
      // 收货时间 receivedAt
      getTime: formatterTime(data.receivedAt * 1000),
      // 关闭时间 closedAt
      closeTime: formatterTime(data.closedAt * 1000),
      // 推荐人推荐码
      inviteCode: data.inviteCode,
      // 推荐人名称
      recommendName: data.recommendName,
    }
    // 用户信息
    orderInfo.userInfo = {
      // 订单状态
      name: data.address && data.address.name || "",
      // 订单时间
      phone: data.address && data.address.mobile || "",
      // 下单地址,需要查询省市区出来.
      addressMsg: area + (data.address && data.address.address || "")
    }
    let goodsCount = 0,
      skuCount = 0,
      picList = []
    // 用于储存sku的状态
    let skuCanSaldList = []
    // 商品信息
    orderInfo.goodsMsg = {
      // 店铺名称
      shopName: data.bizEcShopName,
      // 店铺sn
      shopSn: data.bizEcShopSn,
      // 商品总数
      goodsCount: "",
      // sku总数
      skuCount: "",
      // 商品信息
      goodsList: data.orderItems.map(item => {
        goodsCount += 1
        picList.push(item.ossId)
        return {
          // 商品图片
          newImg: "",
          ossId: item.ossId,
          // 商品名称
          goodsName: item.bizEcGoodsName,
          // sku信息
          specsList: item.itemDetailResponses.map(itemChild => {
            skuCount += itemChild.quantity
            skuCanSaldList.push(this.formatterBtnApplyForAfterSald(itemChild, data))
            return {
              // sku名字
              name: itemChild.bizEcGoodsSpecsName,
              // sku数量
              count: itemChild.quantity,
              // sku价格
              price: itemChild.price
            }
          })
        }
      })
    }
    // 只要有一个sku可以被申请售后,那就true
    orderInfo.btnApplyForAfterSald = skuCanSaldList.includes(true)
    picList = await app.picSnGetUrl(picList, {width: 180, height: 180})
    // 塞入图片数据
    orderInfo.goodsMsg.goodsList = orderInfo.goodsMsg.goodsList.map((item, index) => {
      return {
        ...item,
        newImg: picList[index]
      }
    })
    data.currencies.forEach(item=>{
      item.flexibleAmount = formatterMultidigitMoney(item.flexibleAmount);
    })
    // sku总数
    orderInfo.goodsMsg.skuCount = skuCount
    // 商品总数
    orderInfo.goodsMsg.goodsCount = goodsCount
    // 价格信息
    orderInfo.priceMsg = {
      // 商品总额
      sumCount: formatterMultidigitMoney(data.goodsAmount),
      // 运费价格
      freightCount: formatterMultidigitMoney(data.deliverAmount),
      // 节省
      preferentialAmount: formatterMultidigitMoney(data.preferentialAmount),
      // 优惠
      ticketAmount: formatterMultidigitMoney(data.ticketAmount),
      // 真实价格
      realPrice: formatterMultidigitMoney(data.payableAmount),
      // 抵扣类型
      currencies: data.currencies
    }
    this.setData({
      orderInfo
    })
    this.checkService(this.data.orderInfo.goodsMsg.shopSn)
  },
  // 返回上一页
  goback() {
    wx.navigateBack({
      delta: 1
    })
  },
  // 复制单号
  onCopy(e) {
    wx.setClipboardData({
      data: e.target.dataset.ordernum,
      success: function (res) {
      }
    })
  },
  // 查看物流点击事件
  viewLogistics(e) {
    const sn = e.currentTarget.dataset.data.orderMsg.orderNo
    wx.navigateTo({
      url: `/pages/logistics-info/index?sn=${sn}`
    })
  },
  // 点击按钮
  tapBtn(e) {
    const type = e.currentTarget.dataset.type
    if (type === "submitReceiver") {
      this.submitReceiver()
    } else if (type === "reBuy") {
      this.reBuy()
    } else if (type === "checkLogistics") {
      this.checkLogistics()
    } else if (type === "goPay") {
      this.goPay()
    } else if (type === "cancelOrder") {
      this.cancelOrder()
    } else if (type === "applyForAfterSald") {
      wx.navigateTo({
        url: `/pages/apply-for-after-sales/index?sn=&apply=applyFor&orderSn=${this.data.sn}`
      })
    }
  },
  // 确认收货
  submitReceiver() {
    const sn = this.data.sn
    Dialog.confirm({
      title: "提示",
      message: "确定已收到货？"
    }).then(() => {
      app.put(`/ec/order/received/${sn}`).then(res => {
        if (res) {
          this.getData()
        }
      })
    }, () => {
    })
  },
  // 再次采购
  reBuy() {
    const sn = this.data.sn
  },
  // 查看物流
  checkLogistics() {
    const sn = this.data.sn
    wx.navigateTo({
      url: `/pages/logistics-info/index?sn=${sn}`
    })
  },
  // 去支付
  goPay() {
    // 若是自提，不需要选收货地址
    if (!orderData.address && orderData.paymentType !== 'zt') {
      Dialog.confirm({
        message: "当前订单还未选择收货地址\n请选择收货地址再进行订单支付"
      })
        .then(() => {
          wx.navigateTo({
            url: "/pages/address/index?t=needback"
          })
          return
        })
        .catch(() => {
          // on cancel
        })
    } else {
      this.payNow()
    }
  },
  // 地址回调
  changeAddressData(e) {
    this.setData({
      goshow: false
    })
    app.put(`/ec/order/address/${this.data.sn}/${e.sn}`).then(res => {
      if (res) {
        this.getData()
        this.setData({
          goshow: true
        })
      }
    })
  },
  getPayDefSn(version) {
    return new Promise((resolve, reject) => {
      app.get(`/pay/def?version=${version}`).then(res => {
        if (res) {
          resolve(res.data)
        }
      })
    })
  },
  // 立即支付
  async payNow() {
    const sn = this.data.sn
    const payVersion = this.data.orderInfo.payVersion
    const payDefSn  = await this.getPayDefSn(payVersion)
    app.put(`/ec/order/submit/${sn}?payDefSn=${payDefSn}`).then((res) => {
      if (res) {
        if(res.paySn){
          // 去收银台
          wx.navigateTo({
            url: `/pages/cashier/index?paySn=${res.paySn}&sn=${res.sn}&payVersion=${payVersion}`
          })
        }else{
          // 0元支付 去待发货页面
          wx.navigateTo({
            url: `/pages/order-data/index?name=deliver`
          })
        }
      }
    })
  },
  // 取消订单
  cancelOrder() {
    const sn = this.data.sn
    Dialog.confirm({
      title: "提示",
      message: "您确定取消该订单？取消后将无法再恢复。"
    }).then(() => {
      app.put(`/ec/order/cancel/${sn}`).then(res => {
        if (res) {
          this.getData()
        }
      })
    }, () => {
    })
  },
  // 去商铺首页
  goShop() {
    wx.navigateTo({
      url: `/packageA/pages/shop-home/index?sn=${this.data.orderInfo.goodsMsg.shopSn}`
    })
  },
  //去地址列表
  goAddress() {
    if (this.data.orderInfo.btnGoPay) {
      wx.navigateTo({
        url: "/pages/address/index?t=needback"
      })
    }
  },
  toService(){
    const {goodsMsg, orderMsg, priceMsg} = this.data.orderInfo

    const params = encodeURIComponent(JSON.stringify({
      sn: goodsMsg.shopSn, // 店铺sn
      name: goodsMsg.goodsList[0]?.goodsName, // 商品名称
      image: goodsMsg.goodsList[0]?.ossId, // 商品的图片
      orderPrice: priceMsg.realPrice, // 总价格
      orderSn: orderMsg.orderNo, // 订单号
      orderDate: orderMsg.submitTime, // 下单时间
      quantityGoods: goodsMsg.skuCount, // 商品总数
      typeOfMerchandize: goodsMsg.goodsCount // 商品种类
    }))
    const shopName = goodsMsg.shopName

    wx.navigateTo({
      url: `/packageB/pages/tim/tim?sn=${goodsMsg.shopSn}&title=${shopName}&orderInfo=${params}`
    })
  }
})
