// pages/address/index.js
const { ORDERSTATUS, formatterTime ,AFTERSALESTATE,AFTERSALETYPE} = require("../../utils/index")
const app = getApp()
import Dialog from "@vant/weapp/dialog/dialog"
let SN = ''
let status = {
  // 售后审核：撤销申请
  'apply':{
    p_title:'售后审核',
    p_label:''
  },
  // 售后成功
  'complete':{
    p_title:'售后成功',
    p_label:'审核时间'
  },
  // 售后关闭
  'cancel':{
    p_title:'售后关闭',
    p_label:'关闭时间'
  },
  // 商品寄回：商品寄回
  'wait_send':{
    p_title:'商品寄回',
    p_label:'处理剩余时间',
    p_des:'(超时未寄回将自动关闭售后申请）'
  },
  // 条件不符：修改申请、撤销申请
  'reject':{
    p_title:'条件不符',
    p_label:'处理时间',
  },
  // 商家处理：物流详情
  'process':{
    p_title:'商家处理',
    p_label:'寄回时间',
  },
  // 用户收货：确认收货
  'wait_back':{
    p_title:'用户收货',
    p_label:'寄出时间',
  },
}
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 胶囊距离顶部
    capsuletop: app.menuBoundingMsg["top"],
    // 胶囊高度
    capsuleheight: app.menuBoundingMsg["height"] - 1,
    allSteps:false,
    // 总数据
    list:{},
    steps:[],
    oncesteps:[],
    stepsList: [],
    lookImage:false,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad({sn}) {
    SN = sn
  },
  onShow(){
    if(!this.data.lookImage){
      this.getData()
      return;
    }
    this.setData({
      lookImage:false
    })
  },
  lookImageFn(){
    this.setData({
      lookImage:true
    })
  },
  // 返回上一页
    goback() {
      wx.navigateBack({
        delta: 1
      })
    },
  // 复制单号
  onCopy({currentTarget}) {
    let list = this.data.list
    let data = ''
    let type = currentTarget?.dataset?.type
    if(type=='shopAddress'){
      data = `收货人：${list.shopAddress.name}\n电话：${list.shopAddress.mobile}\n地址：${list.shopAddress.address}`
    }
    else if(type=='userAddress'){
      data = `收货人：${list.userAddress.name}\n电话：${list.userAddress.mobile}\n地址：${list.userAddress.area}${list.userAddress.address}`
    }
    else if(type=='orderSn'){
      data=list.orderSn
    }
    else if(type=='sn'){
      data=list.sn
    }
    
    wx.setClipboardData({
      data,
      success: function (res) {}
    })
  },
  // 收起展开步骤条
  putOn(){
    this.setData({
      allSteps:!this.data.allSteps
    })
    if(this.data.allSteps){
      this.setData({
        steps:this.data.stepsList
      })
      if(!this.selectComponent('#steps').data.allheight){
        this.selectComponent('#steps').getHeight('all')
      }
    }else{
      this.setData({
        steps:this.data.oncesteps
      })
    }
  },
  // 底部按钮
  tapBtn({currentTarget}){
    let {dataset} = currentTarget
    let type = dataset?.type
    // 撤销售后
    if(type=='backout'){
      Dialog.confirm({
        message: '您确定撤销该售后申请?\n撤销后将不可再恢复。',
      })
        .then(async () => {
          let res = await app.put(`/ec/saled/cancel/${SN}`)
          if(res.success){
            this.getData()
          }
        })
        .catch(() => {
          // on cancel
        });
    }
    // 确认收货
    else if(type=="submitReceiver"){
        Dialog.confirm({
          message: '确定已收到货？',
        })
          .then(async () => {
            let res = await app.put(`/ec/saled/complete/${SN}`)
            if(res.success){
                this.getData()}
            })
          .catch(() => {
            // on cancel
          });
    }
    // 查看物流
    else if(type=="checkLogistics"){
      wx.navigateTo({
        url: `/pages/logistics-info/index?sn=${this.data.list.deliverSn}&type=saled`
      })
    }
    // 商品寄回
    else if(type=="sendBack"){
      wx.navigateTo({
        url:`/pages/good-back/index?sn=${SN}`
      })
    }
    // 修改申请
    else if(type=='reject'){
      wx.navigateTo({
        url:`/pages/apply-for-after-sales/index?sn=${SN}&apply=edit`
      })
    }
  },
  changeShow(){
    this.setData({
      testShow: !this.data.testShow
    })
  },
  async getData(){
    this.selectComponent('#steps').initonceheight()
    let list = await app.get(`/ec/saled/${SN}`)
    // //用户地址
    if(list?.userAddress?.areaSn){
      let res = await app.getArea(list.userAddress.areaSn)
      list.userAddress.area = app.area(res)
    }
    // //创建时间
    if(list?.createdAt){
      list.createdAtString = formatterTime(list.createdAt*1000)
    }
    // 更新时间
    if(list?.updateAt){
      list.updateAtString = formatterTime(list.updateAt*1000)
    }
    if(list?.items?.length){
      list.goods = await app.formatterAfterGoods(list.items)
    }
    // 倒计时
    if(list.state=='wait_send'){
      list.countDown = list.updateAt*1000 + 60*60*24*3*1000 - Date.now()
    }
    if(list.logs?.length){
      for(let i=0;i<list.logs.length;i++){
        list.logs[i].createAtMD = formatterTime(list.logs[i].createAt*1000,'MD')
        list.logs[i].createAtHMM = formatterTime(list.logs[i].createAt*1000,'HMM')
        for(let k=0;k<list.logs[i].images.length;k++){
          let file = {}
          let img = await app.picSnGetUrl(list.logs[i].images[k].content)
          file.deletable=false
          file.url=img[0]
          list.logs[i].fileList||=[] 
          list.logs[i]?.fileList.push(file)
        }
      }
    }
    // 类型状态转文字
    list.typeString = AFTERSALETYPE[list.type]
    let newList = Object.assign(list,status[list.state])
    this.setData({
      stepsList:list.logs,
      oncesteps:list.logs?.slice(0,1),
      steps:list.logs?.slice(0,1),
      list:newList,
      allSteps:false
    })
  },
  goAddress(){
    if(this.data.list.state=='wait_send' || this.data.list.state=='apply'){
      wx.navigateTo({
        url: "/pages/address/index?t=needback"
      })
    }
  },
  changeAddressData(e){
    app.put(`/ec/saled/address/${SN}/${e.sn}`).then(res => {
      if (res) {
        this.getData()
      }
    })
  }
})