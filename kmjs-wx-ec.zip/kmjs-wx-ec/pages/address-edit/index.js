// pages/address-edit/index.js
const {
  stringLength,
  numberReg,
  nameReg
} = require("../../utils/utils")
import Dialog from "/@vant/weapp/dialog/dialog"

const app = getApp()
let areaList = []
Page({

  /**
   * 页面的初始数据
   */
  data: {
    regionData: {},

    multiIndex: [0, 0, 0],
    multiArray: [
      [],
      [],
      []
    ],
    // 表单
    form: {
      userName: "",
      phone: "",
      areaSn: "",
      region: "",
      pitchOn: null,
      desAddress: ""
    },
    // 输入姓名错误
    errorMessageName: "",
    // 输入电话号码错误
    errorMessageNnumber: "",
    // 输入地址错误
    errorMessageDesAddress: "",
    // 地址弹窗展示
    // show: false,
    // 文本框
    autosize: {
      maxHeight: 80
    },
    // 编辑id
    sn: ""
  },
  tapPicker() {
    wx.hideKeyboard()
  },
  // 初始化
  onLoad: function (options) {
    areaList = app.globalData.areaList
    this.formatmultiArray()
    if (options.t && options.t.trim() == "edit") {
      this.setData({
        sn: options.sn
      })
      // 获取地址
      this.snCheckAdd()
      wx.setNavigationBarTitle({
        title: "编辑地址"
      })
    } else {
      wx.setNavigationBarTitle({
        title: "新建收货地址"
      })
    }
  },
  // 导入微信地址
  wxAddress(){
    let _that = this
    wx.chooseAddress({
      success: async(res)=>{
        /* res
        {cityName:  "广州市"
        countyName: "海珠区"
        detailInfo: "新港中路397号"
        errMsg: "chooseAddress:ok"
        nationalCode: "510000"
        postalCode: "510000"
        provinceName: "广东省"
        telNumber: "020-81167888"
        userName: "张三" }
        */
        let area = [res.provinceName,res.cityName,res.countyName]
        let id = ''
        let bool = null
        await wx.request({
          method:'get',
          url:`https://apis.map.qq.com/ws/district/v1/search?keyword=${res.countyName}&key=7TXBZ-D43CF-V6XJ6-JMTZ5-3M2CQ-35FCO`,
          success:async (r)=>{
            if(r.statusCode==200){
              if(r.data?.result?.[0].length)
              id = r.data.result[0].find(item=>{
                bool = item.address.split(',').every((k,i)=>{
                  return area[i].indexOf(k) != -1
                })
                return bool && item
              }).id
              if(id){
                let areaItem = await app.getAreaSn(id)
                _that.setData({form:{
                  userName:res.userName,
                  phone:res.telNumber,
                  areaSn:areaItem.sn,
                  region:area.join(' '),
                  pitchOn: _that.data?.form?.pitchOn,
                  desAddress:res.detailInfo
                }})
              }else{
                wx.showToast({
                  title: '请手动选择地址',
                  icon: 'none',
                  duration: 2000
                })
              }
            }
          }
        })
      },
      fail: () => {
        wx.showToast({
          title: '微信地址授权失败',
          icon: 'none',
          duration: 2000
        })
      }
    })
  },
  // 格式化地址
  formatmultiArray(province = 0, city = 0, area = 0) {
    // multiArray
    this.setData({
      "multiArray[0]": areaList,
      "multiArray[1]": areaList[province].item,
      "multiArray[2]": areaList[province].item.length ? areaList[province].item[city].item : [],
      "multiIndex": [province, city, area]
    })
  },
  // 数据改变
  bindMultiPickerChange: function (e) {
    this.setData({
      multiIndex: e.detail.value
    })
    this.indexchange(e.detail.value)
  },
  // 地址滚动时触发
  bindMultiPickerColumnChange: function (e) {
    switch (e.detail.column) {
      case 0:
        this.formatmultiArray(e.detail.value, 0, 0)
        break
      case 1:
        this.formatmultiArray(this.data.multiIndex[0], e.detail.value, 0)
        break
      case 2:
        this.formatmultiArray(this.data.multiIndex[0], this.data.multiIndex[1], e.detail.value)
        break
    }
  },
  // 根据index设置值
  indexchange(data) {
    let snList = []
    let nameList = []
    for (let i in data) {
      if (this.data.multiArray[i].length) {
        nameList[i] = this.data.multiArray[i][data[i]].name
        snList[i] = this.data.multiArray[i][data[i]].sn
      }
    }
    this.setData({
      "form.region": nameList.join(" "),
      "form.areaSn": snList.pop()
    })
  },


  // 根据sn查询地址
  async snCheckAdd() {
    let res = await this.snCheckAddQuery()
    this.setData({
      "form.userName": res.name,
      "form.phone": res.mobile,
      "form.areaSn": res.areaSn,
      "form.pitchOn": res.pitchOn,
      "form.desAddress": res.address,
      "form.region": app.area(res.area, " ")
    })
  },
  snCheckAddQuery() {
    return app.get(`/md/inst/user/address/${this.data.sn}`)
  },
  // (新增|编辑)地址
  submit() {
    // for (const item of Object.keys(this.data.form)) {
    //   if (this.data.form[item] === "") {
    let msg = ""
    if (!this.data.form.userName) {
      msg = "请输入姓名"
    } else if (!this.nameInputBlurFn(this.data.form.userName)) {
      msg = "请输入正确的姓名"
    } else if (!this.data.form.phone) {
      msg = "请输入手机号"
    } else if (!this.numberInputBlurFn(this.data.form.phone)) {
      msg = "请输入正确的手机号"
    } else if (!this.data.form["areaSn"] || !this.data.form.region) {
      msg = "请选择所在省市区"
    } else if (!this.data.form.desAddress) {
      msg = "请输入详细地址"
    } else if (!this.desAddressInputBlurFn(this.data.form.desAddress)) {
      msg = "请输入正确的详细地址"
    }
    if (msg != "") {
      wx.showToast({
        title: msg,
        icon: "none",
        duration: 2000
      })
      return
    }
    // }
    // }
    // this.data.sn  当前id
    // 调接口 成功提示
    let url = "",
      queryType = ""
    if (this.data.sn) {
      // 编辑
      url = `/md/inst/user/address/${this.data.sn}`
      queryType = "put"
    } else {
      // 新增
      url = "/md/inst/user/address"
      queryType = "post"
    }
    let {
      form
    } = this.data
    form = {
      "areaSn": form.areaSn,
      "address": form.desAddress,
      "pitchOn": form.pitchOn,
      "name": form.userName,
      "mobile": form.phone
    }
    app[queryType](url, form).then(res => {
      wx.showToast({
        title: "保存成功",
        icon: "success",
        duration: 2000
      })
      this.goback()
    })
  },
  // 返回上一页并更新
  async goback() {
    let pages = getCurrentPages()
    let beforePage = pages[pages.length - 2]
    beforePage.init()

    wx.navigateBack()
  },
  // 删除地址
  del() {
    Dialog.confirm({
      title: "提示",
      message: "确定删除地址"
    })
      .then(() => {
        // 调接口 成功提示
        app.del(`/md/inst/user/address/${this.data.sn}`).then(res => {
          wx.showToast({
            title: res.message,
            icon: "none",
            duration: 2000
          })
          wx.WHENADDRESSDELETE && wx.WHENADDRESSDELETE(this.data.sn)
          this.goback()
        })
      })
      .catch(() => {
        // on cancel
      })
  },
  // 名称失焦
  nameInputBlur(e) {
    this.nameInputBlurFn(e.detail.value)
  },
  nameInputBlurFn(data) {
    if (!stringLength(data, 2, 10)) {
      this.setData({
        errorMessageName: "请输入2~10个字符的名称"
      })
      return
    } else {
      this.setData({
        errorMessageName: ""
      })
    }
    if (!nameReg(data)) {
      this.setData({
        errorMessageName: "请输入正确的名称"
      })
      return
    }
    return true
  },
  // 电话失焦
  numberInputBlur(e) {
    this.numberInputBlurFn(e.detail.value)
  },
  numberInputBlurFn(data) {
    if (!data) {
      this.setData({
        errorMessageNnumber: "请输入手机号"
      })
      return
    } else {
      this.setData({
        errorMessageNnumber: ""
      })
    }
    if (!numberReg(data)) {
      this.setData({
        errorMessageNnumber: "请输入正确的手机号"
      })
      return
    }
    return true
  },
  // 地址失焦
  desAddressInputBlur(e) {
    this.desAddressInputBlurFn(e.detail.value)
  },
  desAddressInputBlurFn(data) {
    if (!stringLength(data, 5, 50)) {
      this.setData({
        errorMessageDesAddress: "请输入5~50个字符的详细地址"
      })
      return
    } else {
      this.setData({
        errorMessageDesAddress: ""
      })
    }
    return true
  },
  // 修改值的时候触发
  onChange(e) {
    this.setData({
      [e.currentTarget.dataset.type]: e.detail
    })
  }
})
