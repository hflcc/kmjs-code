// pages/recharge/component/agreement/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    agreementSelectType:{
      type:Boolean,
      value:false
    },
    otherAmountshow:{
      type:Boolean
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    checked: null,
  },
  ready() {
    this.setData({
      checked:this.data.agreementSelectType
    })
  },
  observers:{
    agreementSelectType(v){
      this.setData({
        checked:v
      })
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    onChange(event) {
      this.setData({
        checked: event.detail,
      });
      this.triggerEvent("changeAgreementCU",event.detail)
    },
    // 去充值
    goRecharge(){
      this.triggerEvent("goRecharge")
    },
    // 取消
    goCancel(){
      this.triggerEvent("onClickHide")
    },
    // 协议
    popExplain(){
      wx.navigateTo({
        url:'/pages/recharge-policy/index'
      })
    }
  }
})
