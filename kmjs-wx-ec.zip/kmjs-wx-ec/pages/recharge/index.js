// pages/recharge/index.js
import Dialog from "/@vant/weapp/dialog/dialog"
import { formatterTime, scopeType } from "../../utils/index"
const app = getApp();
// 两位小数
// const reg = /^([1-9]\d{0,6}|0)\.\d{3,}$/  
const reg = /^([1-9]\d{0,}|0)\.\d{3,}$/
// 整数 或者 两位以内的小数
const succeedReg = /(^[1-9]\d{0,6}$)|(^([1-9]\d{0,6}|0)\.[0-9]{1,2}$)/
const page = {
  page: 0,
  size: 30
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    rechargeAmountList: [],
    // 选择的金额
    activeAmountSn: null,
    couponList: [],
    //充值协议说明弹窗框
    explainShow: false,
    // 其他金额弹窗
    otherAmountshow: false,
    // 充值金额
    rechargeAmount: null,
    // 协议选择状态
    agreementSelectType: false,
    // 输入框错误内容
    inputErrMsg: '',
    // sn
    sn: '',
    memberAccountSn: '',
    focus:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function ({ sn, memberAccountSn }) {
    this.setData({
      sn,
      memberAccountSn
    })
    this.getRechargeAmountList()
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  // 获取充值金额
  getRechargeAmountList() {
    app.get(`/mk/currency/exchange/list/${this.data.sn}`).then(res => {
      if (res) {
        this.setData({
          rechargeAmountList: res
        })
      }
    })
  },
  getCouponList() {
    app.get(`/mk/member/currency/exchange/discount/page/${this.data.activeAmountSn}`, page).then(async res => {
      if (res) {
        let cp = this.data.couponList
        for (let item of res.content) {
          cp = cp.concat(await this.handleCoupon(item.discountSn))
        }
        this.setData({
          couponList: cp
        })
        if (!res.last) {
          page.page++
          this.getCouponList()
        }
      }
    })
  },
  async handleCoupon(sn) {
    let res = await app.get(`/mk/common/ticket/group/sn/${sn}`)
    return res && this.formattingNewCP(res)
  },
  // 格式化美博会优惠券格式
  formattingNewCP(res) {
    if (res instanceof Array) {
      if (res.length > 0) {
        res.forEach(item => {
          item.scopeNmae = scopeType[item.scopeType]
          item.endATString = formatterTime(item.endAt * 1000, 'YMD', '.')
          item.startATString = formatterTime(item.startAt * 1000, 'YMD', '.')
        })
      }
    }
    return res
  },
  // 点击充值金额
  tapRechargeAmount({ currentTarget }) {
    let param = currentTarget.dataset?.param
    page.page = 0
    this.setData({
      activeAmountSn: param.sn,
      rechargeAmount: param.price,
      inputErrMsg: "",
      couponList: []
    })
    // custom ==1 弹出其他金额框  等于0不弹
    if (param.custom == '1') {
      this.setData({
        otherAmountshow: true,
        rechargeAmount: null
      });
      setTimeout(()=>{
        this.setData({
          focus:true
        })
      },300)
    } else if (param.discountType == 'ticket_group') {
      this.getCouponList()
    }
  },
  // 显示使用说明
  showUseDes({ detail }) {
    Dialog.alert({
      title: '使用说明',
      message: detail,
    }).then(() => {
      // on close
    });
  },
  // 去支付
  goRecharge() {
    this.fieldBlur({detail:{value:this.data.rechargeAmount}})
    if (!this.data.activeAmountSn) {
      wx.showToast({
        title: "请选择金额",
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (!this.data.rechargeAmount) {
      wx.showToast({
        title: "请输入金额",
        icon: 'none',
        duration: 2000
      })
      return
    }
    // if (this.data.rechargeAmount<=0) {
    //   wx.showToast({
    //     title: "充值金额必须大于0",
    //     icon: 'none',
    //     duration: 2000
    //   })
    //   return
    // }
    if (this.data.inputErrMsg) {
      return
    }
    if (!this.data.agreementSelectType) {
      wx.showToast({
        title: "请勾选《充值协议》",
        icon: 'none',
        duration: 2000
      })
      return
    }

    // console.log('去支付');
    this.handleGoRecharge()
  },
  async handleGoRecharge() {
    // 获取payDefSn
    const data = {
      "memberAccountSn": this.data.memberAccountSn,
      "amount": Number(this.data.rechargeAmount)
    }
    /* 
      *activeAmountSn 充值金额对应的交易规则sn
      *memberAccountSn 会员账户sn
     */
    const { activeAmountSn, memberAccountSn, rechargeAmount } = this.data
    if (!app.globalData.payDefSn) {
      await app.payDefSnData()
    }
    const paySnData = await app.post(`/mk/member/account/order/${activeAmountSn}/${app.globalData.payDefSn}`, data)
    if (paySnData.success) {
      wx.redirectTo({
        url: `/pages/cashier/index?paySn=${paySnData.sn}&type=recharge&sn=${activeAmountSn}&memberAccountSn=${memberAccountSn}&amount=${rechargeAmount}`
      })
    } else {
      wx.showToast({
        title: paySnData.message,
        icon: 'none'
      })
    }
  },
  // 隐藏其他金额弹窗
  onClickHide() {
    this.setData({
      rechargeAmount: null,
      otherAmountshow: false,
      activeAmountSn: null,
      inputErrMsg: ""
    });
  },
  // 改变协议勾选状态
  changeAgreementCU({ detail }) {
    this.setData({
      agreementSelectType: detail
    })
  },
  // 其他金额输入框失去焦点
  fieldBlur({ detail }) {
    if (Number(detail.value) <= 0) {
      this.setData({
        inputErrMsg: "充值金额必须大于0"
      })
    }
    else if (!Number(detail.value)) {
      this.setData({
        inputErrMsg: "请输入正确金额"
      })
    }
    else if (Number(detail.value) > 10000000) {
      this.setData({
        inputErrMsg: "最大输入金额为：9999999.99"
      })
    }
    else if(succeedReg.test(detail.value)){
      this.setData({
        inputErrMsg: "",
        rechargeAmount: detail.value
      })
      // const count = detail.value * 100
      // this.setData({
      //   inputErrMsg: "",
      //   rechargeAmount: Math.floor(count) / 100
      // })
    }else{
      this.setData({
        inputErrMsg: "请输入正确金额"
      })
    }
  },
  // 其他金额输入框数据改变
  fieldChagne({ detail }) {
    const count = detail * 100
    let p = detail && reg.test(detail) && Math.floor(count) / 100
    if (p || p === 0) {
      this.setData({
        rechargeAmount: p.toFixed(2)
      })
    }
  }
})