// pages/activity-coupons/index.js
import Dialog from "@vant/weapp/dialog/dialog"
import Toast from '@vant/weapp/toast/toast'
import { formatterTime, scopeType, getWxLoginCode, encode, client_id, client_secret, saveLoginStatus, saveInstId, wxToast} from "../../utils/index"
const app = getApp();
let loginCode = "";
let timer;
let gohomeTimer;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    couponList:[],
    sn:'',
    scene:'',
    token:'',
    // 是否点击过
    isClick: false,
    // 是否有数据
    hasList:true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad({scene}) {
    // console.log('登录返回');
    this.setData({scene})
    loginCode = await getWxLoginCode()
    // 4.5 分钟刷新一次 code;
    timer = setInterval(async () => {
      loginCode = await getWxLoginCode()
    }, 1000 * 60 * 4.5)
  },

  onUnload() {
    clearInterval(timer)
    clearInterval(gohomeTimer)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  async onShow() {
    // await this.checkToken()
    let sceneData = await app.getScene(this.data.scene)
    let {sn ,title='耗品GO',ossid } = JSON.parse(sceneData?.value)
    this.setData({
      sn,
      token:app.globalData.userInfo.token
    })
    wx.setNavigationBarTitle({
      title
    })
    this.checkCoupons()
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {

  // },
  // 显示使用说明
  showUseDes({ detail }) {
    Dialog.alert({
      title: '使用说明',
      message: detail,
    }).then(() => {
      // on close
    });
  },
  // 获取优惠券
  checkCoupons(){
    app.get(`/mk/common/ticket/group/sn/${this.data.sn}`).then(res=>{
      if(res){
        this.formattingNewCP(res)
      }
    })
  },
  // 校验token
  // async checkToken(){
  //   if(app.globalData.userInfo.token){
  //     const res = await app.post(`/oauth2/oauth/check_token?token=${app.globalData.userInfo.token}`,{}, {
  //       Authorization: "Basic " + encode(`${client_id}:${client_secret}`)
  //     })
  //     return res
  //   }
  // },
  // 领取优惠券
  async getCoupons(){
      // 已登录
      app.post(`/mk/ticket/instance/group/sn/${this.data.sn}`).then(res=>{
        if(res.success){
          Toast(` ${res.message || '领取成功' }`);
        }
        gohomeTimer = setTimeout(() => {
          wx.switchTab({
            url: '/pages/index/index',
          })
        }, 1000);
      })
  },
   // 格式化美博会优惠券格式
   formattingNewCP(res){
    if(res instanceof Array){
      if(res.length>0){
        res.forEach(item=>{
          item.scopeNmae = scopeType[item.scopeType]
          item.endATString = formatterTime(item.endAt *1000,'YMD','.')
          item.startATString = formatterTime(item.startAt *1000,'YMD','.')
        })
        this.setData({
          couponList:res,
          hasList:true
        })
      }else{
        this.setData({
          hasList:false
        })
      }
    }
  },

    // 手机号码获取回调
    async phoneNumberCb({ detail }) {
      if (this.data.isClick) {
        return
      }
      this.data.isClick = true
      if (detail.errMsg === "getPhoneNumber:fail user deny") {
        wxToast("用户拒绝了", "error")
        this.data.isClick = false
        return
      }
      if (detail.errMsg !== "getPhoneNumber:ok") {
        this.data.isClick = false
        return
      }
      const { encryptedData, iv } = detail
      await this.login(loginCode, encryptedData, iv)
      this.data.isClick = false
    },
    // 调用登录
    login(code, encryptedData, iv) {
      return new Promise(async (resolve, reject) => {
        // 当前用户是否身份信息
        const result = await app.get("/oauth2/oauth/token", {
          grant_type: "wx_applet",
          scope: "all",
          code,
          encryptedData,
          iv
        }, {
          Authorization: "Basic " + encode(`${client_id}:${client_secret}`)
        })
        if (result) {
          app.globalData.loginData = result
          // 查询机构
          const hasIdentity = await app.get("/md/inst/list/shop", {}, {
            Authorization: result.access_token
          })
          // 如果有机构
          if (hasIdentity && hasIdentity.length > 0) {
            await saveLoginStatus(app, result)
            let hisInstld = hasIdentity.filter(item => item.id == wx.getStorageSync("instId-id"))
            await saveInstId(app, hisInstld.length > 0 ? hisInstld[0] : hasIdentity[0])
            this.setData({
              token:app.globalData.userInfo.token
            })
          } else {
            // 没有机构,调用接口默认创建
            const result = await app.post("/md/inst/register", {
              "type": "shop"
            }, {
              Authorization: app.globalData.loginData.access_token
            })
            if (result) {
              saveLoginStatus(app, app.globalData.loginData)
              await saveInstId(app, result)
              this.setData({
                token:app.globalData.userInfo.token
              })
            }
          }
          this.getCoupons()
        } else {
          loginCode = await getWxLoginCode()
        }
        resolve()
      })
    },


})