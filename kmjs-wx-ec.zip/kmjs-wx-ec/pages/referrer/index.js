// pages/referrer/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 是否有更多数据
    // 是否刷新中
    refresherTriggered: false,
    // 推荐人列表
    referrer: [],
    // 项目sn
    projectSn: "",
    // 用户身份
    userIdentity: "",
    /*
    * 页面来源
    * self: 个人中心过来的
    * ecOrder: 确认订单过来
    * */
    form: "",
    // 是否需要返回
    isNeedBack: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function ({ form, projectSn, type, isNeedBack }) {
    // 初始化数据
    this.setData({
      form,
      projectSn,
      userIdentity: type,
      isNeedBack: isNeedBack === "true"
    })
  },
  onShow:function(){
    this.getData()
  },
  // 拉去列表数据
  async getData() {
    let referrer = ''
    if (this.data.form === "ec_order") {
      referrer = await app.get(`/mk/project/ring/user/list/commend/ec_order`)
    } else {
      referrer = await app.get(`/mk/project/ring/actor/commend/${this.data.projectSn}/${this.data.userIdentity}`)
    }
    if (!referrer) {
      return
    }
    this.setData({
      referrer
    })
  },
  // 加载更多
  pullDown() {
  },
  //下拉刷新
  async pullUp() {
    await this.getData()
    this.setData({
      refresherTriggered: false
    })
  },
  // 去添加我的推荐人
  goAddReferrer() {
    wx.navigateTo({
      url: "/pages/add-referrer/index"
    })
  },
  // 选择并返回上一页
  async selectAdd(e) {
    if (this.data.isNeedBack) {
      let pages = getCurrentPages()
      let beforePage = pages[pages.length - 2]
      // 推荐人item
      const data = e.currentTarget.dataset.item
      // 获取推荐人的邀请码
      const result = await app.get(`/mk/invite/code/obtain/${data.sn}/${this.data.form}`)
      if (result) {
        // 调用上一页面方法
        beforePage.getScancode({
          code: result.inviteCode,
          name: data.name
        })
        wx.navigateBack()
      }
    }
  }
})
