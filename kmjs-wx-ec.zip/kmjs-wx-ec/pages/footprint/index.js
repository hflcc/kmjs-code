const app = getApp()
import { wxToast } from "../../utils/index"

Page({
  data: {
    // 是否有更多数据
    hasData: false,
    // 数据条数
    size: 50,
    // 加载状态
    loading: false,
    // 刷新状态
    triggered: false,
    // 是否有数据
    objHasKey: false,
    // 渲染的key:value
    renderObj: {},
    // 分页信息
    page: {
      page: 0,
      size: 30
    },
    // 总条数
    numCount: null,
    // 最后条数id
    lastOfferId:'',
  },
  onShow: function (options) {
    this.data.renderObj = {}
    this.data.page = {
      page: 0,
      size: 30
    }
    // hack
    const query = this.selectComponent("#pullLoading")
    query && query.resetScrollTop && query.resetScrollTop()
    this.getBrowseList()
    this.setData({
      triggered: false
    })
  },
  // 拉去我的足迹
  getBrowseList() {
    wx.showLoading({
      title: '加载中',
      mask:true,
    })
    let params = this.data.page
    if(this.data.lastOfferId){
      params={...this.data.page,lastOfferId:this.data.lastOfferId}
    }
    return app.get("/assist/inst/user/browse/page/summary/goods/time/none", params).then(async (res) => {
      res.content.forEach(item=>{
        item.data.browseDate = item.browseDate;
        item.data.id = item.lastOfferId;
      })
      const data = await app.formatterGoods(res.content)
      const renderObj = this.data.renderObj
      for (let i = 0; i < data.length; i++) {
        const obj = data[i]
        if (!renderObj[obj.browseDate]) {
          renderObj[obj.browseDate] = []
        }
        renderObj[obj.browseDate].push(obj)
      }
      let objHasKey = Object.keys(renderObj).length > 0
      this.setData({
        renderObj,
        objHasKey,
        hasData: !res.last,
        numCount: res.totalElements,
        lastOfferId:res.content.length?res.content[res.content.length-1].lastOfferId:''
      })
      // wx.hideLoading()
    })
  },
  // 滚动+1
  addOne() {
    const query = this.selectComponent("#pullLoading")
    query && query.addOne && query.addOne()
  },
  // 隐藏页面的时候需要将所有swipe划出状态清空
  onHide: function () {
    const childs = this.selectAllComponents(".swipe")
    childs.forEach(child => {
      child.close()
    })
  },
  // 删除我的足迹
  deleteCollectGoods(e) {
    // 获取索引; item数据; 输入那一天的;
    const { index, item, key } = e.currentTarget.dataset
    app.del("/md/inst/user/browse?ids="+item.id).then(res => {
      if (res) {
        wxToast("删除成功")
        this.addOne()
        // 删除指定索引
        this.data.renderObj[key].splice(index, 1)
        // 判断当天日期是否已经没有足迹了
        if (this.data.renderObj[key].length === 0) {
          delete this.data.renderObj[key]
        }
        this.setData({
          renderObj: this.data.renderObj,
          numCount: this.data.numCount - 1
        })
        // this.getBrowseList()
      }
    })
  },
  // 到底加载更多
  pullLoading() {
    this.data.page.page += 1
    this.getBrowseList()
  },
  // 刷新
  pullRefresh() {
    this.setData({
      renderObj: {}
    })
    wx.nextTick(() => {
      this.data.page.page = 0
      this.getBrowseList().then(() => {
        this.setData({
          triggered: false
        })
      })
    })
  },
  // 回到首页
  goHome() {
    wx.switchTab({ url: "/pages/index/index" })
  },
  // 去收藏详情
  goDetail(e) {
    const data = e.currentTarget.dataset.item
    if (data.state !== "off") {
      wx.navigateTo({
        url: `/pages/goods-detail/index?sn=${data.sn}`
      })
    } else {
      wxToast("该商品已下架")
    }
  }
})
