const app = getApp();
Page({
  data: {
    // 当前支付订单的SN， 用来发起重新支付, 只在支付失败的时候才会有该值
    sn: '',
    // 支付状态 success fail
    status: '',
    // 订单组（group）还是订单(order) 充值（recharge）
    type: '',
    // 会员账户sn
    memberAccountSn:'',
    // 充值金额
    amount:''
  },
  /**
   * @param status {string} 支付状态 success fail
   * @param sn {string} 当前支付订单的SN。
   * @param type {string} 支付类型。
   * */
  onLoad: function ({ sn, status, type, memberAccountSn, amount, payVersion }) {
    this.setData({
      sn,
      status,
      type,
      memberAccountSn,
      amount,
      payVersion
    })
  },
  /**
   * 返回首页
   * */
  backHome() {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  /**
   * 查看订单
   * */
  backOrder() {
    let url = ''
    if(this.data.type=='recharge'){
        // url =  "/pages/my-asset/index"
        wx.navigateBack()
    }else{
        url =  "/pages/self/index?toAll=true&toastType=success"
        wx.reLaunch({
          url
        })
    }

  },
  /**
   * 重新支付
   * */
  async payment() {
    const {type, payVersion} = this.data;
    if(type=='recharge'){
      this.handleGoRecharge()
    }else{
      const payDefSn  = await this.getPayDefSn(payVersion)
      const url = type === 'group' ? '/ec/order/group/submit/' : '/ec/order/submit/'
      app.put(`${url}${this.data.sn}?payDefSn=${payDefSn}`).then(res => {
        if (res) {
          // 去收银台
          wx.redirectTo({
            url: `/pages/cashier/index?paySn=${res.paySn}&sn=${res.sn}&type=${type}&payVersion=${payVersion}`
          })
        }
      })
    }
  },
  getPayDefSn(version) {
    return new Promise((resolve, reject) => {
      app.get(`/pay/def?version=${version}`).then(res => {
        if (res) {
          resolve(res.data)
        }
      })
    })
  },
  // 充值
  async handleGoRecharge(){
    const {sn,memberAccountSn,amount} = this.data
    // 获取payDefSn
    const data = {
      "memberAccountSn": this.data.memberAccountSn,
      "amount": Number(this.data.amount)
  }
    const paySnData = await app.post(`/mk/member/account/order/${this.data.sn}/${app.globalData.payDefSn}`,data)
    if(paySnData.success){
      wx.redirectTo({
        url: `/pages/cashier/index?paySn=${paySnData.sn}&type=recharge&sn=${sn}&memberAccountSn=${memberAccountSn}&amount=${amount}`
      })
    }else{
        wx.showToast({
          title: paySnData.message,
          icon: 'none'
        })
    }
  }

});
