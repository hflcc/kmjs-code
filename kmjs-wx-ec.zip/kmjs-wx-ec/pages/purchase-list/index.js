const { formatterMoney,formatterTime ,scopeType} = require("../../utils/index.js")
const app = getApp()
import Dialog from "@vant/weapp/dialog/dialog"

let oldData = "", changeCountResult = {success:false}
Page({
  data: {
    src: `https://kmjs.oss-cn-shenzhen.aliyuncs.com/kmjs-wx-ec-static/purchase-list.png?timer=${new Date().getTime()}`,
    // 数据
    data: [],
    // 新的价格
    countPrice: formatterMoney(0),
    // 旧的价格
    discountPrice: formatterMoney(0),
    // 是否全选
    selectAll: false,
    // 登录态
    token: "",
    // 价格详情
    showPriceDes:false,
    // 新人优惠券
    newcoupon:false,
    // 新人优惠券列表
    newCouponList:[],

  },
    //获取新人优惠券列表
    async getNewCoupon(){
      let res = await app.checkNewCoupon()
      if(res instanceof Array){
        if(res.length>0){
          res.forEach(item=>{
            item.scopeNmae = scopeType[item.scopeType]
            item.endATString = formatterTime(item.endAt *1000,'YMD','.')
            item.startATString = formatterTime(item.startAt *1000,'YMD','.')
          })
        }
        this.setData({
          newCouponList:res,
          newcoupon:true
        })
      }
    },
  // 关闭新人优惠券
    closecp(){
      this.setData({
        newcoupon:false
      })
    },
  // 获取购物车商品
  getData() {
    app.get("/ec/cart/item").then(res => {
      if (res) {
        this.formatterData(res)

      } else {
        this.setData({
          data: []
        })
      }
    })
  },
  // 刷新列表
  onShow() {
    this.setData({
      token: app.globalData.userInfo.token,
      selectAll: false
    })
    if (app.globalData.userInfo.token) {
      this.getData()
      this.getNewCoupon()
    } else {
      this.setData({
        data: []
      })
    }
  },
  // 去登录
  login: function () {
    if (app.loginJump()) {
      return
    }
  },
  // 格式化数据
  async getCouponCount(list) {
    if (Array.isArray(list)) {
      // 构建数据
      const data = list.map((item, itemIndex) => {
        return {
          scopeType: "shop",
          // 商铺SN
          scopeValue: item.shopSn,
          items: item.items.map(itemChild => {
            return {
              scopeType: "goods",
              scopeValue: itemChild.shopGoodsSn,
            }
          })
        }
      })

      app.post(`/mk/ticket/count`,data).then(res=>{
        if(res){
          let data = this.data.data.map((item,index)=>{
            item.totalNum=res[index].totalNum
            return item
          })
          console.log(data);
          this.setData({
            data
          })
        }
      })

    }
  },
  // 格式化数据
  async formatterData(list) {
    if (Array.isArray(list)) {
      let picList = [], index = 0
      // 构建数据
      const data = list.map((item, itemIndex) => {
        return {
          // 商铺SN
          shopSn: item.shopSn,
          // 商铺的选中状态
          checked: false,
          // 商铺名字
          shopName: item.shopName,
          // 商品列表
          goodsList: item.items.map(itemChild => {
            if (itemChild.goodsImages && itemChild.goodsImages[0] && itemChild.goodsImages[0].ossId) {
              picList.push(itemChild.goodsImages[0].ossId)
            }
            return {
              // 店铺商品sn
              shopGoodsSn: itemChild.shopGoodsSn,
              // 商品的选中状态
              checked: false,
              // 图片
              pic: "",
              // 商品名称
              goodsName: itemChild.goodsName,
              // 商品规格数据
              specification: itemChild.skuItems.map(itemSon => {
                return {
                  // 规格SN
                  itemSn: itemSon.itemSn,
                  // 商品规格的选中状态
                  checked: false,
                  // 描述
                  desc: itemSon.specName,
                  // 新价格格式化
                  newPrice: formatterMoney(itemSon.price),
                  // 旧价格格式化
                  oldPrice: formatterMoney(itemSon.skuPrice),
                  // 数量
                  count: itemSon.quantity,
                  // 商品规格是否达到起批量
                  showHint: false,
                  // 状态: none 待下单,disabled已失效
                  state: itemSon.state,
                  // 最大数量 (最大值为0时代表不限制,通常情况不会为零,这里做个兼容写死999999999)
                  maxNum: itemSon.maxNum > 0 ? itemSon.maxNum : 999999999,
                  // 最小数量
                  minNum:itemSon.minNum
                }
              })
            }
          }),
          // 商铺的金额
          count: formatterMoney(0)
        }
      })
      // 批量查询图片
      picList = await app.picSnGetUrl(picList, {width: 144, height: 144})
      // 图片重新塞入数据中
      data.forEach(item => {
        item.goodsList.forEach(itemChild => {
          itemChild.pic = picList[index]
          index += 1
        })
      })
      this.callComputed(data,list)
    }
  },
  // 全选
  selectAll() {
    const result = !this.data.selectAll
    const data = this.data.data
    data.forEach(item => {
      item.checked = result
      item.goodsList.forEach(itemChild => {
        itemChild.checked = result
        itemChild.specification.forEach(itemSon => {
          if (itemSon.state === "none") {
            itemSon.checked = result
          }
        })
      })
    })
    this.setData({
      selectAll: result
    })
    this.callComputed(data)
  },
  // select切换时调用;
  selectChange({ detail }) {
    const data = this.data.data
    // 选中的店铺的索引
    const index1 = detail.index[0]
    // 选中的商品的索引
    const index2 = detail.index[1]
    // 选中的规格的索引
    const index3 = detail.index[2]
    // 切换店铺的处理
    if (detail.level === "1") {
      const result = !data[index1].checked
      data[index1].checked = result
      data[index1].goodsList.forEach(itemChild => {
        itemChild.checked = result
        itemChild.specification.forEach(itemSon => {
          if (itemSon.state === "none") {
            itemSon.checked = result
          }
        })
      })
      // 切换商品的处理
    } else if (detail.level === "2") {
      const result = !data[index1].goodsList[index2].checked
      data[index1].goodsList[index2].checked = result
      data[index1].goodsList[index2].specification.forEach(itemSon => {
        if (itemSon.state === "none") {
          itemSon.checked = result
        }
      })
      // 切换规格的处理
    } else if (detail.level === "3") {
      const result = !data[index1].goodsList[index2].specification[index3].checked
      if (data[index1].goodsList[index2].specification[index3].state === "none") {
        data[index1].goodsList[index2].specification[index3].checked = result
      }
    }
    // 子集处理完毕后,遍历树;操作父级节点
    let level1 = true
    data.forEach(item => {
      let level2 = true
      item.goodsList.forEach(itemChild => {
        let level3 = true
        itemChild.specification.forEach(itemSon => {
          if (!itemSon.checked) {
            level3 = false
          }
        })
        itemChild.checked = level3
        if (!level3) {
          level2 = false
        }
      })
      item.checked = level2
      if (!level2) {
        level1 = false
      }
    })
    this.setData({
      selectAll: level1
    })
    this.callComputed(data)
  },
  // 删除商品,并刷新列表
  deleteGoods(detail) {
    app.del(`/ec/cart/item/${detail.itemSn}`).then(res => {
      if (res) {
        const data = this.data.data
        data.forEach((item, itemIndex) => {
          item.goodsList.forEach((itemChild, itemChildIndex) => {
            itemChild.specification.forEach((itemSon, itemSonIndex) => {
              if (itemSon.itemSn === detail.itemSn) {
                itemChild.specification.splice(itemSonIndex, 1)
              }
            })
            if (itemChild.specification.length === 0) {
              item.goodsList.splice(itemChildIndex, 1)
            }
          })
          if (item.goodsList.length === 0) {
            data.splice(itemIndex, 1)
          }
        })
        this.callComputed(data)
      }
    })
  },
  // 删除购物车商品
  deleteShoppingCar({ detail }) {
    Dialog.confirm({
      message: "确定删除该商品？"
    })
      .then(() => {
        this.deleteGoods(detail)
      }, () => {
      })
  },
  // 修改 count 时触发
  async countChange({ detail }) {
    const data = this.data.data
    const { index1, index2, index3, value } = detail
    const itemSn = data[index1].goodsList[index2].specification[index3].itemSn
    changeCountResult = await app.put(`/ec/cart/item/${itemSn}`, {
      quantity: value
    })
    oldData = JSON.parse(JSON.stringify(data))
    //
    // this.selectAllComponents('.purchase-item')[2].updataInput()

    // 修改数据成功, 需要重新刷新数据
    data[index1].goodsList[index2].specification[index3].count = value
    if(changeCountResult?.price){
      data[index1].goodsList[index2].specification[index3].newPrice = changeCountResult.price
    }
    this.callComputed(data)
  },
  // 触发重新计算
  callComputed(data,res) {
    let newCount = 0
    let oldCount = 0
    data.forEach(item => {
      let shopCount = 0
      item.goodsList.forEach(itemChild => {
        itemChild.specification.forEach((itemSon) => {
          const { checked, count, newPrice, oldPrice, min } = itemSon
          itemSon.showHint = false
          if (checked) {
            newCount += count * newPrice
            oldCount += count * oldPrice
            shopCount += count * newPrice
            if (count < min) {
              itemSon.showHint = true
            }
          }
        })
      })
      item.count = formatterMoney(shopCount)
    })
    this.setData({
      data,
      countPrice: formatterMoney(newCount),
      discountPrice: formatterMoney(oldCount - newCount)
    })
    this.getCouponCount(res)
    // hack: 当修改数据失败之后,需要重新刷新试图一遍;
    wx.nextTick(() => {
      if (!changeCountResult?.success && oldData) {
        this.callComputed(oldData)
        oldData = ""
      }
    })
  },
  // 回到首页
  goHome() {
    wx.switchTab({
      url: "/pages/index/index"
    })
  },
  // 结算订单
  submit() {
    const data = this.data.data
    const bizEcCartItemSns = []
    data.forEach(item => {
      item.goodsList.forEach(itemChild => {
        itemChild.specification.forEach(itemSon => {
          if (itemSon.checked) {
            bizEcCartItemSns.push(itemSon.itemSn)
          }
        })
      })
    })
    // 有选中的商品
    if (bizEcCartItemSns.length > 0) {
      this.addOrder({ bizEcCartItemSns })
    }else{
      wx.showToast({
        title: '请先选择结算商品',
        icon: 'none',
        duration: 2000
      })
    }
  },
  // 新增订单
  addOrder(data) {
    app.post("/ec/order", data).then(res => {
      if (res) {
        const sns = res.map(item => item.sn).join(',')
        const payVersion = res.map(item => item.payVersion).join(',')
        wx.navigateTo({
          url: `/pages/submit-order/index?type=group&sn=${sns}&payVersion=${payVersion}`
        })
      }
    })
  },
  // 价格详情
  priceDes(){
    this.setData({
      showPriceDes:!this.data.showPriceDes
    })
  }
})
