// pages/good-back/index.js
const {numLetter} = require("../../utils/utils")
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    popShow: true,
    logisticsCompanyList: [],
    logisticsCompany:'请选择物流公司',
    trackingNumber :"",
    afterSaleSn:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({afterSaleSn:options.sn})
    this.getDeliver();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getDeliver(){
    app.get('/ec/common/deliver/type/list').then(res=>{
      this.setData({logisticsCompanyList:res})
    })
  },
  getInp(e){
    if (numLetter(e.detail.value)) {
      this.setData({trackingNumber:e.detail.value});
    }else{
      
    }
  },
  bindPickerChange: function (e) {
    this.setData({
      logisticsCompany: e.detail.value
    })
  },
  send(){
    // 上传凭证
    const child = this.selectComponent("#upload-imgs");
    let images = child.getFileList().map(item => {
      let imgs = {
        content: item.seq,
        contentType: item.type
      }
      return imgs
    })
    if (!this.data.logisticsCompanyList[this.data.logisticsCompany]) {
      wx.showToast({
        title: "请选择物流公司",
        icon: "none",
        duration: 2000
      })
    }else if (this.data.trackingNumber == "") {
      wx.showToast({
        title: "请输入正确的快递单号",
        icon: "none",
        duration: 2000
      })
    }else{
      const type = this.data.logisticsCompanyList[this.data.logisticsCompany].key;
      const billSn = this.data.trackingNumber;
      app.put(`/ec/saled/send/${this.data.afterSaleSn}`,{type,billSn,images}).then(res=>{
        if (res.success) {
          wx.navigateBack()
        }
      })
    }
  }
})