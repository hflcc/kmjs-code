// pages/main-coupons/index.js
import Dialog from "/@vant/weapp/dialog/dialog"
const { formatterTime ,scopeType} = require("../../utils/index")
let query = {
  page: 0,
  size: 30
}
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userType:{'none':{label:'未使用',value:0},'used':{label:'已使用',value:0},'expired':{label:'已过期',value:0}},
    // none  used expired
    navactive:'none',
    typeOption: [
      { text: '类型', value: '' },
      { text: '商品优惠券', value: 'goods' },
      { text: '店铺优惠券', value: 'shop' },
      { text: '平台优惠券', value: 'app' },
    ],
    saleOption: [
      { text: '优惠力度', value: '' },
      { text: '从高至低', value: 'discountAmount:desc' },
      { text: '从低至高', value: 'discountAmount:asc' },
    ],
    // 类型选中值
    typeActive: '',
    // 优惠力度选中值
    saleActive: '',
    // 数据loading
    isLoading: true,
    // 是不是最后一页
    lastpage: true,
    couponList:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getCouponCount()
    this.init()
    this.getcouponList()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 显示使用说明
  showUseDes({detail}){
    Dialog.alert({
      title: '使用说明',
      message: detail,
    }).then(() => {
      // on close
    });
  },
  // 优惠券按钮
  getCP({detail}){
    if (detail.actionUrl && detail.actionUrl !== '{}') {
      const action = JSON.parse(detail.actionUrl)
      let url = ''
      if (action.type === 'info_flow') {
        url = `/pages/info-flow-category/index?sn=${action.value}`
      } else if (action.type === 'shop') {
        url = `/packageA/pagesop-home/index?sn=${action.value}`
      } else if (action.type === 'goods') {
        url = `/pages/goods-detail/index?sn=${action.value}`
      }
      wx.navigateTo({
        url: url
      })
      return
    }
    if(detail.scopevalues.length){
      if(detail.scopetype=="shop"){
          wx.navigateTo({
            url: `/packageA/pages/shop-home/index?sn=${detail.scopevalues[0]}`
          })
      }
      // else if(detail.scopetype=="goods" && detail.ticketType=="qy"){
      //   wx.navigateTo({
      //     url: `/pages/assist-list/index?type=swiper`
      //   })
      // }
      else if(detail.scopetype=="goods"){
        wx.navigateTo({
          url: `/pages/goods-detail/index?sn=${detail.scopevalues[0]}`
        })
      }
      else if(detail.scopetype=="app"){
        // 去首页
        wx.switchTab({
          url: `/pages/index/index`
        })
      }
      // 权益券
  }
  },
  // 优惠券数量
  getCouponCount(){
    app.get(`/mk/ticket/instance/count/current`).then(res => {
      if (res) {
        for (let key in res) {
          this.setData({
            [`userType.${key}.value`]:res[key]
          })
        }
      }
    })
  },
  init(){
    this.setData({
      couponList:[]
    })
    query = {
      page: 0,
      size: 30
    }
  },
  // 导航变化
  navChange({detail}){
    this.setData({
      navactive:detail.name,
      typeActive: '',
      saleActive: '',
    })
    this.init()
    //调用数据
    this.getcouponList()
  },
  // 类型值发生改变
  onTypeActiveChange({ detail }){
    this.setData({typeActive:detail})
    this.init()
    this.getcouponList()
  },
   // 优惠力度发生改变
   onSaleActiveChange({ detail }){
    this.setData({saleActive:detail})
    this.init()
    this.getcouponList()
  },
  // 获取优惠券
  getcouponList(){
    this.setData({
      isLoading: true
    })
    let data = {
      scopeType:this.data.typeActive,
      orderBy:this.data.saleActive
    }
    Object.assign(data,query)
    app.get(`/mk/ticket/instance/page/current/${this.data.navactive}`,data).then(res=>{
      if(res){
        let content = res.content
        content.forEach(item=>{
          item.scopeNmae = scopeType[item.scopeType]
          item.endATString = formatterTime(item.endAt *1000,'YMD','.')
          item.startATString = formatterTime(item.startAt *1000,'YMD','.')
        })
        this.setData({
          couponList:this.data.couponList.concat(content),
        })
      }
      this.setData({
        isLoading: false,
        lastpage:res.last
      })
    })

  },
  // 加载更多
  pullDown() {
    if (this.data.lastpage!=undefined && !this.data.lastpage) {
      query.page++
      this.getcouponList()
    }
  },
   //下拉刷新
   pullUp() {
    // this.setData({
    //   typeActive: '',
    //   saleActive: '',
    // })
    this.init()
    this.getcouponList()
    this.getCouponCount()
    this.setData({
      refresherTriggered: false
    })
  },
})
