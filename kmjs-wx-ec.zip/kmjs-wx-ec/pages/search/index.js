// pages/search/index.js
const app = getApp()
import Dialog from "/@vant/weapp/dialog/dialog"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hot: [],
    old: [],
    storageOldList: [],
    placeholderVal: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getgoods()
    // this.setData({placeholderVal:options.v})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this
    wx.getStorage({
      key: "hisSearch",
      success(res) {
        that.data.storageOldList = res.data
        that.setData({ old: that.ellipsis(res.data) })
      }
    })
    // 清除搜索内容
    this.selectComponent("#search").clear()
  },

  // 省略
  ellipsis(data) {
    return data.map(item => {
      if (item instanceof Object) {
        if (item.value.length > 6) {
          item.ellivalue = item.value.slice(0, 6) + "..."
        }
      } else {
        if (item.length > 6) {
          item = { "value": item, "ellivalue": item.slice(0, 6) + "..." }
        } else {
          item = { "value": item }
        }
      }
      return item
    })
  },
  // 清除历史搜索
  clearHisData() {
    Dialog.confirm({
      title: "提示",
      message: "确定删除全部历史记录"
    })
      .then(() => {
        wx.clearStorage({ key: "hisSearch" })
        this.setData({ old: [] })
      })
      .catch(() => {
        // on cancel
      })

  },
  onSearch(e) {
    /**
     * e.detail 组件传值过来
     * e.currentTarget.dataset.v  页面传值过来
     * */
    let value = e.currentTarget.dataset.v || e.detail
    this.data.storageOldList.unshift(value)
    wx.setStorage({
      key: "hisSearch",
      data: [...new Set(this.data.storageOldList)].slice(0, 10)
      // data:this.data.storageOldList.slice(0,10)
    })
    wx.navigateTo({
      url: `/pages/search-result/index?v=${value}`
    })
  },

  // 商品列表
  getgoods() {
    // 拉去商品的函数
    const goodsPromise = app.get("/si/common/search/hotword/page/goods", {
      page: 0,
      size: 10
    })
    // 拉去店铺的函数
    const shopPromise = app.get("/si/common/search/hotword/page/shop", {
      page: 0,
      size: 10
    })
    Promise.all([goodsPromise, shopPromise]).then(results => {
      const result = []
      results.forEach(res => {
        if (!res) {
          return
        }
        result.push(...res.content.map((item, index) => {
          Object.assign(item, { value: item.name })
          return item
        }))
      })
      this.setData({
        hot: this.ellipsis(result)
      })
    })
  }
})