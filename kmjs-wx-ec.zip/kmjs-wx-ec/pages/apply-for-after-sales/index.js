// pages/apply-for-after-sales/index.js
const {
  formatterMoney
} = require("../../utils/index")
const {
  wxToast,
  AFTERSTATE
} = require("../../utils/index")
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 是否选中退款商品
    hasChecked: false,
    // 售后原因列表
    afterSaleReasonList: [],
    // 默认售后原因
    afterSaleReason: {
      name: "请选择售后原因",
      sn: null
    },
    // 售后方式列表
    afterSaleMethodList: [{
        name: "退款",
        type: "refund"
      },
      {
        name: "退款退货",
        type: "back_refund"
      },
      {
        name: "换货",
        type: "exchange"
      }
    ],
    // 默认售后方式
    afterSaleMethod: {
      name: "请选择售后方式",
      type: null
    },
    // 展示售后列表
    showAfterSaleList: false,
    // 订单sn
    orderSn: "",
    // sku商品列表
    skuList: [],
    // 弹窗商品列表
    dialogSkuList: [],
    // 已输入字数
    yesNum: "0",
    // 剩余可输入字数
    noNum: "200",
    // 退款说明
    section: "",
    // 总计
    amountTo: "0.00"
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 来源: applyFor: 申请;edit: 修改
    let apply = options.apply
    /*
    * 当 apply 为 applyFor 时: 为规格sn
    * 当 apply 为 edit 时: 为售后sn
    * */
    let sn = options.sn
    /*
    * 当 apply 为 applyFor 时: 为订单sn
    * 当 apply 为 edit 时: 为空
    * */
    let orderSn = options.orderSn
    // 保存订单 sn
    this.setData({
      orderSn
    })
    // 拉去选中的售后单信息
    if (apply === "edit") {
      this.getAfter(sn, apply)
    } else if (apply === "applyFor") {
      this.getAllCanAfterSaleSku()
    }
    // 获取售后原因
    this.getReasonList()
  },
  // 退款说明
  bindTextAreaBlur(e) {
    let value;
    if (e.detail.value.length < 200) {
      value = e.detail.value;
    } else {
      value = e.detail.value.substring(0, 200);
    }
    let number = 200 - value.length
    this.setData({
      section: value,
      noNum: number,
      yesNum: value.length
    })
  },
  // 售后原因
  changeAfterSaleReason(e) {
    this.setData({
      afterSaleReason: this.data.afterSaleReasonList[e.detail.value]
    })
  },
  // 售后方式
  changeAfterSaleMethod: function (e) {
    this.setData({
      afterSaleMethod: this.data.afterSaleMethodList[e.detail.value]
    })
  },
  // 添加商品售后
  setShow(e) {
    this.setData({
      showAfterSaleList: !this.data.showAfterSaleList
    })
  },
  // 获取全部可以进行售后的sku列表
  getAllCanAfterSaleSku(defaultSn) {
    app.get(`/ec/order/goods/${this.data.orderSn}`).then(async skuList => {
      if (skuList) {
        skuList = skuList.map(item => {
          return {
            checkedSku: item.sn === defaultSn,
            skuStatus: item.saledState == "process"? AFTERSTATE[item.saledState] : (item.beRefund && item.saledState == "complete"?AFTERSTATE[item.saledState]:'') ,
            ...item
          }
        })
        skuList = await app.formatterAfterGoods(skuList)
        let hasChecked = skuList.filter(item=>{
           return item.checkedSku
        }).length > 0
        this.setData({
          hasChecked,
          skuList,
          dialogSkuList: JSON.parse(JSON.stringify(skuList))
        })
      }
    })
  },
  // 获取售后原因
  getReasonList() {
    app.get("/ec/common/saled/reason/list").then(res => {
      if (res) {
        this.setData({
          // afterSaleReason: res[0],
          afterSaleReasonList: res
        })
      }
    })
  },
  // 获取选中的订单规格售后sku
  getAfter(sn,apply) {
    app.get(`/ec/saled/${sn}`).then(async res => {
      if (res && res.sn) {
        // 初始化申请售后商品的金额
        this.setData({
          amountTo: formatterMoney(res.goodsAmount)
        })
        if (apply === "edit") {
          this.setData({orderSn:res.orderSn})
          this.getAllCanAfterSaleSku(res.sn);
        }else{
          this.getAllCanAfterSaleSku(res.sn)
        }
      }
    })
  },
  // 选择售后单
  setChecked(e) {
    const orderSn = e.detail
    // 记录多少个选中项,以及最后一次选中项切换的索引
    let count = 0,
      changeIndex = -1
    const dialogSkuList = this.data.dialogSkuList.map((item, index) => {
      if (item.orderSn === orderSn) {
        item.checkedSku = !item.checkedSku
        // 记录下当前修改状态的索引
        changeIndex = index
      }
      // 记录多少个选中项
      if (item.checkedSku) {
        count += 1
      }
      return item
    })
    if (count === 0) {
      wxToast("至少选择一项申请售后")
      // 这次选择器点击索引的状态反转
      this.data.dialogSkuList[changeIndex].checkedSku = !this.data.dialogSkuList[changeIndex].checkedSku
      return
    }
    this.setData({
      dialogSkuList
    })
  },
  // 保存售后提交
  send() {
    // 上传凭证
    const child = this.selectComponent("#up-img")
    let images = child.getFileList().map(item => {
      let imgs = {
        content: item.seq,
        contentType: item.type
      }
      return imgs
    })
    // 售后原因
    const reasonSn = this.data.afterSaleReason.sn
    // 售后方式
    const type = this.data.afterSaleMethod.type
    // 退款说明
    const reason = this.data.section
    // item
    const itemsSn = []
    this.data.skuList.map(item => {
      if (item.checkedSku) {
        itemsSn.push(item.orderSn)
      }
    })
    if (itemsSn.length==0) {
      wxToast("请选择售后商品")
      return
    }
    if (!reasonSn) {
      wxToast("售后原因不能为空.")
      return
    }
    if (!type) {
      wxToast("售后方式不能为空.")
      return
    }
    if (itemsSn.length === 0) {
      wxToast("申请售后商品不能为空.")
      return
    }
    app.post(`/ec/saled/${this.data.orderSn}`, {
      itemsSn,
      reason,
      reasonSn,
      type,
      images
    }).then(res => {
      if (res) {
        wx.redirectTo({
          url: `/pages/after-sale-detail/index?sn=${res.sn}`
        })
      }
    })
  },
  /*
   * 打开弹出框
   * detail:
   * 1:确定;
   * 0:取消;
   * */
  changeShow({
    detail
  }) {
    // 取消的时候,按照外面列表为准
    if (detail === "0") {
      this.setData({
        dialogSkuList: JSON.parse(JSON.stringify(this.data.skuList)),
        showAfterSaleList: !this.data.showAfterSaleList
      })
      // 确认的时候,按照弹窗列表为准
    } else if (detail === "1") {
      const copySkuList = JSON.parse(JSON.stringify(this.data.dialogSkuList))
      let hasChecked = copySkuList.filter(item=>{
        return item.checkedSku
      }).length > 0
      this.setData({
        hasChecked,
        skuList: copySkuList,
        showAfterSaleList: !this.data.showAfterSaleList
      })
    }
    this.computedAmountTo()
  },
  // 设置选中的总价格
  computedAmountTo() {
    const list = this.data.skuList
    let amountTo = 0
    list.forEach(item => {
      if (item.checkedSku) {
        amountTo += item.skuSum
      }
    })
    // 初始化申请售后商品的金额
    this.setData({
      amountTo: formatterMoney(amountTo)
    })
  }
})
