const app = getApp()
Page({
  data: {
    // 左侧菜单数据
    treeSelectData: [],
    // 右侧菜单数据
    data: [],
    // 图片的高度
    picHeight: 0 + 'px',
    // 左侧选中项的索引
    mainActiveIndex: 0
  },
  async onLoad() {
    const itemData = await this.getItemsData()
  },
  // 获取左侧的数据并且处理
  getItemsData() {
    return new Promise((resolve) => {
      app.get("/ec/common/category/item/list").then(data => {
        if (data) {
          const treeSelectData = data.map(({ title, sn }) => {
            return {
              text: title,
              sn
            }
          })
          this.setData({
            mainActiveIndex: 0,
            treeSelectData
          })
          this.getContentData(treeSelectData[0].sn)
          wx.nextTick(() => {
            resolve(treeSelectData)
          })
        } else {
          resolve(false)
        }
      })
    })
  },
  // 获取右侧数据
  getContentData(sn) {
    return new Promise((resolve, reject) => {
      app.get(`/ec/common/category/item/${sn}`).then(async data => {
        for (let i = 0; i < data.length; i++) {
          const item = data[i]
          let picList = []
          // 拿出每个三级分类的icon的ossid
          for (let j = 0; j < item.children.length; j++) {
            const itemChild = item.children[j]
            picList.push(itemChild.icon)
          }
          // 批量调用获取图片
          picList = await app.picSnGetUrl(picList, {width: 186, height: 186})
          // 回写到原对象里面
          for (let j = 0; j < item.children.length; j++) {
            // item.children[j].pic = 'https://res.wx.qq.com/wxdoc/dist/assets/img/0.4cb08bb4.jpg'
            item.children[j].pic = picList[j]
          }
        }
        this.setData({
          data
        })
        wx.nextTick(() => {
          const query = this.createSelectorQuery()
          query.select("#item").boundingClientRect(({width}) => {
            this.setData({
              picHeight: width + 'px'
            })
          })
          query.exec()
        })
      })
    })
  },
  // 点击侧边栏
  onClickNav({ detail }) {
    const index = detail.index
    this.setData({
      mainActiveIndex: index || 0,
    });
    this.getContentData(this.data.treeSelectData[index].sn)
  },
  // 跳转详情
  goDetail(e) {
    const data = e.currentTarget.dataset.data
    wx.navigateTo({
      url: `/packageA/pages/manage/index?sn=${data.sn}&type=goodsClassity`
    })
  }
})
