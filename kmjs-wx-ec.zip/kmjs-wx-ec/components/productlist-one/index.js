// components/productlist-one/index.js
const { formatterMoney } = require("../../utils/index")
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    list: {
      type: Array
    },
    listType: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 组件的初始数据
   */
  data: {},
  observers: {
    list(data) {
      if (data && data.length) {
        let dataList = data.map(item => {
          item.discountPrice = item.discountPrice ? formatterMoney(item.discountPrice) : item.discountPrice
          item.price = item.price ? formatterMoney(item.price) : item.price
          return item
        })
        this.setData({ dataList })
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    productDetail(e) {
      let data = e.currentTarget.dataset.data
      this.triggerEvent("tapItem", data)
    },
    btnEvent() {

    }
  }
})
