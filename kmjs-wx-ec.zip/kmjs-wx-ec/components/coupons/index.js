// components/coupons/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    /**
     * type 类型
     * col 竖版
     * row 横版
     * maxrow 大横版
    */
    type:{
      type:String,
      value:'row'
    },
    // 权益券
    qytype:{
      type:Boolean,
      value:false
    },
    // 按钮文案
    btnText:{
      type:String,
      value:'领取'
    },
    // 数据
    cpData:{
      type:Object
    }
  },
  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    maxrowcallback({currentTarget}){
      let data = {
        scopetype:currentTarget.dataset.scopetype,
        scopevalues:currentTarget.dataset.scopevalues,
        ticketType:currentTarget.dataset.tickettype,
        actionUrl: currentTarget.dataset.actionurl
      }
      this.triggerEvent('getCP',data)
    },
    callback({currentTarget}){
      let sn = currentTarget.dataset.sn
      let received = currentTarget.dataset.received
      this.triggerEvent('getCP',{sn,received})
    },
    descallback({currentTarget}){
      this.triggerEvent('showUseDes',currentTarget.dataset.des)
    }
  }
})
