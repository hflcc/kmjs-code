const app = getApp()


Component({
    options: {
      addGlobalClass: true
    },
    /**
     * 组件的属性列表
     */
    properties: {
        shopSn: {
            type: String,
            value: ''
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        searchVal: '',
        tabList: [
            {
                title: '综合',
                value: ''
            },
            {
                title: '销量',
                value: 'browseCount' // 后台说没有销量,拿浏览量代替
            },
            {
                title: '价格',
                value: 'minPrice',
                sort: 'asc' // asc升序 desc降序
            }
        ],
        activeTabIndex: 0,
        showListType: 'grid', // list列表式 grid网格式
        goodsList: [],
        pageNo: 0,
        pageSize: 10,
        hasMore: true,
        loading: false
    },

    attached() {
        this.getData(true)
    },

    /**
     * 组件的方法列表
     */
    methods: {
        /*
        * @info 选择tab栏
        * */
        chooseTab(e) {
            const { index, item } = e.currentTarget?.dataset || {}
            const obj = {
                activeTabIndex: index,
                tabList: this.data.tabList
            }
            if (index === this.data.activeTabIndex && item.sort) {
                obj.tabList[index].sort = item.sort === 'asc' ? 'desc' : 'asc'
            }
            this.setData(obj)
            this.getData(true)
        },
        /*
        * @info 商品列表到底时触发加载更多
        * */
        handleLoadMore() {
            if (this.data.hasMore) {
                this.setData({
                    pageNo: this.data.pageNo++
                })
                this.getData()
            }
        },
        /*
        * @info 键盘按下确定搜索时触发
        * */
        handleSearch(e) {
            this.setData({
                searchVal: e.detail || ''
            })
            this.getData(true)
        },
        /*
        * @info 获取商品列表数据
        * */
        async getData(flag = false) {
            this.setData({
                loading: true
            })
            if (flag) {
                this.setData({
                    goodsList: [],
                    pageNo: 0,
                    hasMore: true
                })
            }
            const { shopSn, pageNo, pageSize, searchVal, tabList, activeTabIndex } = this.data
            const tabItem = tabList[activeTabIndex]
            let quertStr = `shopSn=${shopSn},=&page=${pageNo}&size=${pageSize}`

            if (searchVal.trim()) {
                quertStr += `&title=${searchVal},like`
            }

            if (tabItem) {
                const { value, sort } = tabItem
                switch (value) {
                  case 'browseCount': // 销量(用浏览量代替)
                    quertStr += `&sort=browseCount,desc`
                    break
                  case 'minPrice': // 价格
                    quertStr += `&sort=minPrice,${sort}`
                    break
                  default:
                    break
                }
            }
            const res = await app.get(`/si/common/search/goods?${quertStr}`)
            this.setData({
                loading: false
            })
            if (res) {
                const list = res.content || []
                const ossIds = list.map(item => item.data?.coverImages[0]?.ossId)
                const imgObj = await app.picSnGetUrl(ossIds, null, false, true)
                list.forEach(item => {
                    if (item.data) {
                        const id = item.data?.coverImages[0]?.ossId
                        item.data.minPrice = item.data?.minPrice?.toFixed(2)
                        item.data.coverImagesUrl = imgObj[id]?.url
                    }
                })
                this.setData({
                    goodsList: this.data.goodsList.concat(list),
                    hasMore: !res.last
                })
            }
        },
        /*
        * @info 跳转商品详情
        * */
        goGoodsDetail(e) {
            const item = e.currentTarget.dataset?.item || {}
            const goodsSn = item.data?.sn
            if (goodsSn) {
                wx.navigateTo({
                    url: `/pages/goods-detail/index?sn=${goodsSn}`
                })
            }
        },
        /*
        * @info 切换商品列表展示形式
        * */
        changeShowType() {
            this.setData({
                showListType: this.data.showListType === 'list' ? 'grid' : 'list'
            })
        }
    }
})
