// components/new-coupon/index.js
import { WXINFO } from "../../utils/index"
const app = getApp()
Component({
  // 使用全局样式
  options: {
    addGlobalClass: true
  },
  /**
   * 组件的属性列表
   */
  properties: {
    list:{
      type:Array
    },
    type:{
      type:String
    },
    title:{
      type:String,
      value:'新人礼包'
    },
    btntxt:{
      type:String,
      value:'查看我的优惠券'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
      phoneNum:app.globalData.userInfo.phoneNum,
  },
  /**
   * 组件的方法列表
   */
  methods: {
      // 关闭新人优惠券
    closecp(){
      this.triggerEvent('closecp')
    },
    goCoupon(){
      if(app.globalData.userInfo.token){
        wx.navigateTo({
          url: "/pages/mine-coupons/index"
        })
      }else{
        this.closecp()
        this.triggerEvent('getNewCoupon',this.data.type)
      }
    },
  }
})
