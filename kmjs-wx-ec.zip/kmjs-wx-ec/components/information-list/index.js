// components/instructions/index.js
const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    dataValue:{
      type: String,
      value: ""
    },
    data: {
      type: Array,
      value: []
    }
  },
  options: {
    
  },

  /**
   * 组件的初始数据
   */
  data: {
  },

  /**
   * 组件的方法列表
   */
  methods: {
    toSearchDetail() {
      this.triggerEvent('toSearchDetail')
    },
    goToMessage(event) {
      if(event.currentTarget) {
        const val = event.currentTarget.dataset
        this.triggerEvent('goToMessage', val)
      }
    }
  }
})
