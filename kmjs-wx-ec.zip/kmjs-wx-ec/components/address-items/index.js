// components/address-item/index.js
const computedBehavior = require("miniprogram-computed").behavior
const app =  getApp()
Component({
  /**
   * 组件的属性列表
   */
  behaviors: [computedBehavior],
  properties: {
    /**
     * list ObjectArray
     * {
     * address: "龙华区龙华地铁站"
      areaSn: "340000"
      lat: 50
      lng: null
      pitchOn: false
      sn: "3333"
      area:[]
    }
     */
    list:{
      type:Array
    }
  },
  observers:{
    // dataList(data){
    //   if(data.list.length){
    //     let result = data.list.map(item=>{
    //       item.areaAddress = item.area.province.name + item.area.city.name +item.area.area.name
    //       return item
    //     })
    //     return result
    //   }
    // }
    list(v){
      if(v.length){
        let result = v.map(item=>{
          item.areaAddress = app.area(item.area)
          return item
        })
        this.setData({
          dataList:result
        })
      }
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    dataList:[]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    edit(e){
      this.triggerEvent('goedit',{type:'edit',item:e.currentTarget.dataset.item})
    },
    selectAdd(e){
      this.triggerEvent('selectAdd',e.currentTarget.dataset.item)
    },
  }
})
