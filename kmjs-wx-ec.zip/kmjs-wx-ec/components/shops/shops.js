Component({
  properties: {
    shopsList: {
      type: Array
    },
    isCollect: {
      type: Boolean
    },
    showCollect: {
      type: Boolean,
      required: true
    }
  },
  observers: {
    shopsList(val) {
      this.setData({ list: val })
    }
  },
  options: {
    addGlobalClass: true
  },
  methods: {
    goShopDetail(e) {
      this.triggerEvent("tapItem", e.detail)
    },
    setCollect(e) {
      let shopItem = e.detail.shopItem
      let index = e.detail.shopIndex
      this.triggerEvent("setCollect", {
        shopItem,
        index
      })
    }
  },
  data: {
    list: []
  }
})
