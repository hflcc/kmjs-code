// components/search/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    placeholderVal:{
      type: String
    },
    searchValue:{
      type: String
    }
  },
  observers:{
    searchValue(v){
      if(v.length>0){
        this.setData({searchVal:v})
      }
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    searchVal:'',
    oList:[]
  },
  created(){
    // 获取历史搜索
    // wx.getStorage({
    //   key: 'hisSearch',
    //   success: (res)=> {
    //     this.data.oList=res.data
    //   }
    // })

  },
  /**
   * 组件的方法列表
   */
  methods: {
    clear(){
      this.setData({
        searchVal: '',
      });
    },
    // 搜索值
    onChange(e) {
      this.setData({
        searchVal: e.detail,
      });
    },
    // 搜索事件
    onSearch(){
      let value= this.data.searchVal||this.data.placeholderVal
      // this.data.oList.unshift(value)
      // wx.setStorage({
      //   key:"hisSearch",
      //   data:this.data.oList.slice(0,10)
      // })
      if(!value.trim()){
        wx.showToast({
          title: '请输入搜索词',
          icon: 'none',
          duration: 2000
        })
        return
      }
      this.triggerEvent('search',value)
    }
  }
})
