let timer = null
Component({
  properties: {
    type: {
      type: String,
      value: "index"
    },
    data: {
      type: Array,
      value: []
    },
    dataDesc: {
      type: Array,
      value: [],
      observer(newVal) {
        if (newVal.length > 0) {
          this.startAnimate()
        }
      }
    }
  },
  options: {
    addGlobalClass: true
  },
  data: {
    // 是否运动中
    isAnimated: false,
    // 当前块
    current: 0
  },
  detached() {
    if (timer) {
      clearTimeout(timer)
    }
  },
  observers: {
    type(value) {
      let result = {}
      if (value === "index") {
        result = {
          // 切换时间
          interval: 2600,
          // 动画时长
          duration: 500,
          // 提示点的颜色
          indicatorColor: "rgb(247, 247, 247)",
          // 高亮提示点颜色
          indicatorActiveColor: "var(--mainC)",
          // 模块轮播的class
          class: "index_swiper",
          // 是否有提示点
          indicatorDots: true,
          // 是否自动播放
          autoplay: true,
          // 显示第几页/共几条
          indicator: false,
          // 是否有 tips
          tips: true
        }
      } else if (value === "shopIndex") {
        result = {
          autoplay: true,
          interval: 2600,
          duration: 500,
          class: "shop_index"
        }
      } else if (value === "goodDetail") {
        result = {
          indicator: true,
          class: "goods_detail",
          share: true
        }
      }
      this.setData({
        swiperMsg: result
      })
    }
  },
  methods: {
    bindchange(e) {
      this.setData({
        current: e.detail.current
      })
    },
    tapSwiper(e) {
      this.triggerEvent("tapItem", e.currentTarget.dataset.data)
    },
    startAnimate() {
      if (timer) {
        clearTimeout(timer)
      }
      timer = setInterval(() => {
        if (this.data.dataDesc.length > 0) {
          this.setData({
            isAnimated: true
          })
          setTimeout(() => {
            const dataDesc = this.data.dataDesc.slice(1)
            dataDesc.push(this.data.dataDesc[0])
            this.setData({
              isAnimated: false,
              dataDesc
            })
          }, 500)
        }
      }, 2600)
    }
  }
})
