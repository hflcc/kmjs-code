// 父级的宽度
let parentWidth = 0
// 滚动总宽度
let scrollWidth = 0
// 最小滚动的宽度
let minScroll = 0
// 开始的 X 位置
let startX = 0
// 当前滚动的位置
let currentScroll = 0
// 最后的move的时间
let lastTime = 0
Component({
  properties: {
    showScrollBar: {
      type: Boolean,
      value: false
    }
  },
  data: {
    // 总滚动的宽度
    scrollWidth: 0,
    // 偏移量
    left: 0,
    // 是否加入动画
    activeScroll: false,
    // 滚动条宽度;需要动态计算来
    scrollBarWidth: 0,
    // 滚动条left值;
    scrollBarLeft: 0
  },
  methods: {
    /**
     * 初始化滚动的数据;
     * */
    computedScroll() {
      const query = this.createSelectorQuery()
      query.select(".hold_location").boundingClientRect()
      query.select(".scroll_view").boundingClientRect()
      query.exec((res) => {
        scrollWidth = res[0].left - res[1].left*2
        parentWidth = res[1].width
        minScroll = res[1].width - scrollWidth
        this.setData({
          scrollWidth,
          scrollBarWidth: parentWidth * 110 / scrollWidth + "px",
          scrollBarLeft: 0
        })
      })
    },
    touchstart({ touches }) {
      // 判断是否有的滚动
      if (minScroll >= 0) {
        return
      }
      // 记录开始的位置
      startX = touches[0].pageX
      // 记录开始的时间
      lastTime = new Date().getTime()
    },
    touchmove({ touches }) {
      // 判断是否有的滚动
      if (minScroll >= 0) {
        return
      }
      // 计算偏移量
      const transform = touches[0].pageX - startX
      // 加上当前的偏移距离,得到当前滚动位置
      const value = transform + currentScroll
      // 如果超过头,拉动变得缓慢
      if (value > 0) {
        this.setData({
          // 海盛大佬的逻辑
          // left: transform / 3 + currentScroll,
          // scrollBarLeft: this.computedScrollBarLeftValue(transform / 3 + currentScroll)
          left: transform + currentScroll,
          scrollBarLeft: this.computedScrollBarLeftValue(transform + currentScroll)
        })
      } else if (minScroll >= value) {
        // 如果超过尾部,拉动变得缓慢
        this.setData({
          // 海盛大佬的逻辑
          // left: transform / 3 + currentScroll,
          // scrollBarLeft: this.computedScrollBarLeftValue(transform / 3 + currentScroll),
          left: transform  + currentScroll,
          scrollBarLeft: this.computedScrollBarLeftValue(transform  + currentScroll),
        })
      } else {
        // 否则当前滚动位置是多少就是多少
        this.setData({
          left: value,
          scrollBarLeft: this.computedScrollBarLeftValue(value)
        })
      }
    },
    touchend({ changedTouches }) {
      // 判断是否有的滚动
      if (minScroll >= 0) {
        return
      }
      // 计算偏移量
      const transform = changedTouches[0].pageX - startX
      // 计算距离 touchStart 的时间
      const transformTime = new Date().getTime() - lastTime
      // 距离 / 时间 * 基数 = 运动该有的距离
      const distance = transform / transformTime * 300
      // 加上当前的scroll值,得到最后的运动距离
      let value = distance + currentScroll
      if (value > 0) {
        value = 0
      } else if (minScroll >= value) {
        value = minScroll
      }
      this.setData({
        activeScroll: true,
        left: value,
        scrollBarLeft: this.computedScrollBarLeftValue(value)
      })
      wx.nextTick(() => {
        currentScroll = value
      })
    },
    transitionend() {
      this.setData({
        activeScroll: false
      })
    },
    computedScrollBarLeftValue(value) {
      return value * -1 / scrollWidth * 110 + "px"
    }
  }
})
