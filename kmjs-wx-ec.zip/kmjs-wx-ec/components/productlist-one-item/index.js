Component({
  // 使用全局样式
  options: {
    addGlobalClass: true
  },
  properties: {
    listType: {
      type: Boolean,
      value: false
    },
    item: {
      type: Object,
      required: true
    }
  },
  data: {},

  methods: {
    productDetail(e) {
      this.triggerEvent("tapItem", this.data.item)
    }
  }
})
