// components/filter/filter.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    sortList: [
      {
        name: '综合排序',
        id: 1
      },
      {
        name: '销量',
        id: 2
      }, {
        name: '价格',
        id: 3
      }
    ],
    sortType: 'goup',
    activeType: 0,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getSort(e) {
      this.setData({ activeType: e.currentTarget.dataset.id });
      if (this.data.activeType === 1) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      } else if (this.data.activeType === 2) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      } else if (this.data.activeType === 3) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      }
    },
  }
})
