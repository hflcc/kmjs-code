Component({
  properties: {
    data: {
      type: Array,
      value: []
    }
  },
  options: {
    addGlobalClass: true
  },
  data: {},
  methods: {
    // 获取 更多的sn
    getMoreSn(type) {
      let d = this.data.data.find(item => item?.data?.typeName == type)
      return d.sn
    },
    // 点击item
    tapItem(e) {
      if (e.type === "more") {
        // 经营必备
        if (e.detail === "manage") {
          wx.navigateTo({
            url: `/packageA/pages/manage/index?sn=${this.getMoreSn("manage")}&type=indexStream`
          })
          // 甄选供应商
        } else if (e.detail === "provider") {
          wx.navigateTo({
            url: `/pages/supplier/index?sn=${this.getMoreSn("provider")}`
          })
          // 拼单goodsCompose 拼团peopleCompose
        } else if (e.detail === "peopleCompose") {
          wx.navigateTo({
            url: `/pages/mass-goods/index?sn=${this.getMoreSn("peopleCompose")}`
          })
        }
      } else if (e.type === "tapItem") {
        const { actionType, sn, goUrl, data } = e.detail
        if (actionType === "goods") {
          wx.navigateTo({
            url: `/pages/goods-detail/index?sn=${sn}`
          })
        } else if (actionType === "shop") {
          wx.navigateTo({
            url: `/packageA/pages/shop-home/index?sn=${sn}`
          })
        } else if (actionType === "link") {
          if (goUrl.startsWith("pages/beauty-expo/index")) {
            wx.navigateTo({
              url: `/${goUrl}`
            })
          } else {
            wx.navigateTo({
              url: `/${goUrl}?type=swiper`
            })
          }
        } else if (actionType === "infoFlowCategory") {
          wx.navigateTo({
            url: `/pages/info-flow-category/index?sn=${sn}`
          })
        } else if (actionType === "wechatApplet") {
          const { appId, path } = data
          wx.navigateToMiniProgram({
            appId,
            path
          })
        }
      } else if (e.type === "buynow") {
        const { sn } = e.detail
        wx.navigateTo({
          url: `/pages/goods-detail/index?sn=${sn}`
        })
      }
    }
  }
})
