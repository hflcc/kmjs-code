const { formatterMoney } = require("../../utils/index")

Component({
  properties: {
    // 价格对象
    showPriceList: {
      type: Array,
      value: []
    },
    // 商品名称
    goodsName: {
      type: String,
      value: ""
    },
    groupText: {
      type: String,
      value: ""
    },
    goodActiveType: {
      type: String,
      value: 'normal'
    }
  },
  options: {
    addGlobalClass: true
  },
  // observers: {
  //   goodsList(data) {
  //     let goodsArr = {}
  //     if (data && Array.isArray(data.prices)) {
  //       goodsArr = { ...data }
  //       goodsArr.prices = data.prices.map((item => {
  //         return Object.assign({}, item, {
  //           minPrice: item.minPrice,
  //           maxPrice: item.maxPrice,
  //           assistPrice: item.assistPrice
  //         })
  //       }))
  //     }
  //     this.setData({
  //       goodsArr
  //     })
  //   }
  // },
  methods: {
    forNumber() {
      return formatterMoney(value)
    },
    goCoupon() {
      this.triggerEvent("goCoupon")
    }
  }
})
