// components/shop-content/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    data: {
      type: Object,
      value: []
    }
  },
  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
      // 点击item
      tapItem(e) {
        if (e.type === "tapItem") {
            const { actionType, sn, goUrl } = e.detail
            if (actionType === "goods") {
              wx.navigateTo({
                url: `/pages/goods-detail/index?sn=${sn}`
              })
            } else if (actionType === "shop") {
              wx.navigateTo({
                url: `/packageA/pages/shop-home/index?sn=${sn}`
              })
            } else if (actionType === "link") {
              wx.navigateTo({
                url: `/${goUrl}?type=swiper`
              })
            }
      }
    }
  }
})
