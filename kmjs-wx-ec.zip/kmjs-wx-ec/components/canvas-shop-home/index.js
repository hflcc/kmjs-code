// components/canvas/index.js
Component({
  imagePath: '',
  history: [],
  future: [],
  /**
   * 组件的属性列表
   */
  properties: {
    shareData:{
      type:Object
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    paintPallette:{},
  },
  ready(){
    wx.showLoading({
      title: '正在生成图片',
    })
    const startLeft = 20;
    const startRight = 30;
    function _text(content, top, left, color, size,fontWeight="normal",arg) {
      return ({
        type: 'text',
        text: content,
        css: [{...{
          left: `${left}rpx`,
          top:`${top}rpx`,
          fontSize:`${size}rpx`,
          color,
          fontWeight,
          lineHeight:'70px',
        },...arg}],
      });
    }
    function _image(url, width,height,top, left, borderRadius,arg) {
      return ({
        type: "image",
        url,
        css: [{...{
          width: `${width}rpx`,
          height: `${height}rpx`,
          top: `${top}rpx`,
          left: `${left}rpx`,
          borderRadius: `${borderRadius}rpx`,
          mode: "scaleToFill"
        },...arg}]
      });
    }
    let {title,imageUrl,goods,saleHeadImg,saleHeadName,shareImg} = this.data.shareData
    let miantemplate = []
    if(goods.length==3){
      miantemplate = [
         // 图一
        _image(goods[0].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),654,480,105,0,0,{mode: "aspectFill"}),
        _text('   ',520,0,'#E61E1C','36','',{"height": "65rpx","width":"100%","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'65rpx'}),
        _text(`￥${goods[0].discountPrice} ~ ${goods[0].price}`,530,startLeft,'#E61E1C','36',''),
        // 图二
        _image(goods[1].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),316,297,600,0,0),
        _text('   ',849,0,'#E61E1C','12','',{"height": "48rpx","width":"316rpx","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'48rpx'}),
        _text(`￥${goods[1].discountPrice} ~ ${goods[1].price}`,857,startLeft,'#E61E1C','28',''),
        // 图三
        _image(goods[2].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),316,297,600,'0',0,{"right":"0rpx"}),
        _text('   ',849,338,'#E61E1C','36','',{"height": "48rpx","width":"316rpx","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'48rpx'}),
        _text(`￥${goods[2].discountPrice} ~ ${goods[2].price}`,857,358,'#E61E1C','28',''),
      ]
    } else if(goods.length==2){
         miantemplate = [
            // 图一
            _image(goods[0].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),654,390,105,0,0,{mode: "aspectFill"}),
            _text('   ',431,0,'#E61E1C','36','',{"height": "64rpx","width":"100%","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'64rpx'}),
            _text(`￥${goods[0].discountPrice} ~ ${goods[0].price}`,441,startLeft,'#E61E1C','36',''),
            // 图二
            _image(goods[1].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),654,388,510,0,0,{mode: "aspectFill"}),
            _text('   ',834,0,'#E61E1C','36','',{"height": "64rpx","width":"316rpx","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'64rpx'}),
            _text(`￥${goods[1].discountPrice} ~ ${goods[1].price}`,841,startLeft,'#E61E1C','36',''),
         ]
    }else if(goods.length==1){
      miantemplate = [
        // 图一
        _image(goods[0].newImg.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),654,792,105,0,0,{mode: "aspectFill"}),
        _text('   ',833,0,'#E61E1C','36','',{"height": "64rpx","width":"100%","background":"linear-gradient(-135deg,rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%)","lineHeight":'64rpx'}),
        _text(`￥${goods[0].discountPrice} ~ ${goods[0].price}`,844,startLeft,'#E61E1C','36',''), 
      ]
    }
   let views =  [
      // 用户logo
      _image(saleHeadImg.replace('http://thirdwx.qlogo.cn', 'https://thirdwx.qlogo.cn'),70,70,20,startLeft,70),
      // 用户名
      _text(saleHeadName,28,100,'#333333','24','bold'),
      _text('低价质优的耗品集采好货，别错过哦！',62,100,'#999999','20',''),
      // 主图 top 110 - 870

      
      // 店铺头像 + 名称
      // _image(imageUrl.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),80,80,910,startLeft,10),
      _text(title,930,120,'#333333','32',''),
      // 小程序码底部颜色
      {
        "type": "text",
        "text": "   ",
        "css": {
          "background": "linear-gradient(-135deg, #ffffff 0%, rgb(252,224,225) 100%)",
          "width": "650rpx",
          "height": "80rpx",
          "bottom": "80rpx",
          "lineHeight": "80rpx",
          "opacity": "0.15"
        }
      },
      // 小程序码
      {
        type: "image",
        url:`data:image/png;base64,${shareImg}`,
        css: {
          width:'110rpx',
          height:'110rpx',
          bottom: `94rpx`,
          right: `16rpx`,
          borderRadius:'110rpx',
          borderWidth: '2rpx',
          borderColor: 'rgb(226,163,166)',
          mode:'aspectFill'
        }
      },
      {
        "type": "text",
        "text": "长按识别或扫描采购",
        "css": {
          "bottom":"114rpx",
          "color": "#444444",
          "right":`145rpx`,
          "fontSize": "22rpx",
        }
      },
      // 底部颜色
      {
        "type": "text",
        "text": "   ",
        "css": {
          "background": "linear-gradient(-135deg, #F76932 0%, #E61E1C 100%)",
          "width": "654rpx",
          "height": "80rpx",
          "bottom": "0",
          "lineHeight": "80rpx",
        }
      },
      {
        "type": "text",
        "text": "超值低价 质优物美 售后无忧",
        "css": {
          "bottom":"32rpx",
          "color": "#fff",
          "right":`${startRight}rpx`,
          "fontSize": "24rpx",
        }
      },
      // 文字logo
      {
        type: "image",
        url:'https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/textlogo-1624413363476.png',
        css: {
          width: `129rpx`,
          height: `42rpx`,
          bottom:"20rpx",
          left: `${startLeft}rpx`,
          mode: "scaleToFill"
        }
      },
    ]
    if(imageUrl){
      views.push(
        _image(imageUrl.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),80,80,910,startLeft,10),
      )
    }
    views = views.concat(miantemplate)
    this.setData({
      paintPallette:{
        width: '654rpx',
        height: '1164rpx',
        background: '#ffffff',
        views
      }
    });
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 动态模版，绘制结束时触发
    // didShow(e){
    //   console.log('绘制结束时触发');
    // },
    // 图片生成成功，可以从 e.detail.path 获取生成的图片路径
    onImgOK(e) {
      this.imagePath = e.detail.path;
      this.setData({
        image: this.imagePath
      })
      wx.hideLoading()
    },
    // 图片生成失败
    onImgErr(e){
      wx.showToast({
        title: e.detail.error,
        icon: 'none',
        duration: 2000
      })
      console.log('生成海报失败');
      wx.hideLoading()
      this.triggerEvent('closePoster')
    },
    // 保存图片
    saveImage() {
      const _self = this
      if (this.imagePath && typeof this.imagePath === 'string') {
        wx.saveImageToPhotosAlbum({
          filePath: this.imagePath,
          success(data) {
            if(data.errMsg=="saveImageToPhotosAlbum:ok"){
              wx.showToast({
                title: '已保存至相册',
                icon: 'success',
                duration: 2000
              })
            }
            _self.triggerEvent('closePoster')
          },
          fail(err) {
            console.log('err',err);
          }
        });
      }
    },
  }
})
