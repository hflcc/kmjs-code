// components/img-tabs/img-tabs.js
const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabList:{
      type:Array
    }
  },
  ready(){
    const that = this
    wx.getStorage({key:'IMGINDEX',
    success (res) {
      that.setData({active:res.data});
    }});
  },

  /**
   * 组件的初始数据
   */
  data: {
    active:0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    setTab({currentTarget}){
      let index = currentTarget.dataset.index;
      let sn = currentTarget.dataset.sn;
      this.setData({active:index});
      wx.setStorage({key:'IMGINDEX',data:index})
      app.eventBus.emit('setTab',sn);
    }
  }
})
