
Component({
  properties: {
    data: {
      type: Object,
      value: []
    }
  },
  observers: {
    "data.paymentType"(v) {
      this.getPaymentTypeText(v)
    },
  },
  data: {
    popShow: false,
    value: "",
    remarkAndPickupTypeData: {},
    pickupType: [
      { name: '寄付', type: 'jf' },
      { name: '自提', type: 'zt' }
    ],
    index: 0, // 默认寄送
    paymentTypeText: '',
  },
  ready() {
    // 初始化备注信息
    this.setData({
      remarkAndPickupTypeData: {
        sn: this.data.data.sn,
        message: "",
        paymentType: this.data.data.paymentType || 'jf'
      }
    })
  },
  options: {
    addGlobalClass: true
  },
  methods: {
    showPopup() {
      this.setData({
        popShow: true
      })
    },
    // 备注
    onInput(e) {
      this.setData({
        "remarkAndPickupTypeData.message": e.detail.value
      })
    },
    // 获取备注的信息
    getRemarkAndPayType() {
      return this.data.remarkAndPickupTypeData
    },
    // 优惠券回调
    couponCallback({currentTarget}){
      let data = {
        type:currentTarget.dataset.type,
        sn:currentTarget.dataset.sn,
        amount:currentTarget.dataset.amount,
        ticket:currentTarget.dataset.ticket,
        ordersn:currentTarget.dataset.ordersn,
        ticketamount:currentTarget.dataset.ticketamount,
        totalquantity:currentTarget.dataset.totalquantity,
        goodsSns:this.data.data.goodsList.map(item=>item.goodsSn)
      }
      this.triggerEvent('showCP',data)
    },
    bindPickerChange(e) { // 改变取货方式
      const _value = e.detail.value
      this.setData({
        index: _value,
        'remarkAndPickupTypeData.paymentType': this.data.pickupType[_value].type
      })
      this.triggerEvent('bindPickerChange',this.data.remarkAndPickupTypeData)
    },
    // 根据商品的提取方式返回对应的文本
    getPaymentTypeText(type) {
      const textMap = new Map([
        ['jf', '寄付'],
        ['zt', '自提'],
        ['hh', '混合'] // (包含自提和寄付)
      ])
      this.setData({
        paymentTypeText: textMap.get(type)
      })
    }
  },
})