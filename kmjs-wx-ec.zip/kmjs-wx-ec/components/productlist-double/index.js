const { formatterMoney } = require("../../utils/index")
Component({
  options: {
    styleIsolation: "apply-shared"
  },
  properties: {
    list: {
      type: Array
    }
  },
  data: {
    computedList: []
  },
  observers: {
    list(lists) {
      this.setData({
        computedList:lists
      })
    }
  },
  methods: {
    goDetail(e) {
      this.triggerEvent("tapItem", e.currentTarget.dataset.data)
    }
  }
})
