// components/row-show-four/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    /**
     * typeName String
     * "manage" 经营必备-类型
     * "provider" 甄选供应商-类型
     *
     */
    typeName: {
      type: String
    },
    showData: {
      type: Object
    }
  },
  /**
   * 组件的初始数据
   */
  data: {},
  observers:{
    showData(data){
      if(data && data.items.length){
        let dataList = data.items.map(item=>{
          item.discountPrice = item.discountPrice
          item.price = item.price
          return item
        })
        this.setData({dataList})
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 更多
    gomore() {
      this.triggerEvent("more", this.data.typeName)
    },
    // 详情
    detail(e) {
      this.triggerEvent("tapItem", e.currentTarget.dataset.item)
    }
  }
})
