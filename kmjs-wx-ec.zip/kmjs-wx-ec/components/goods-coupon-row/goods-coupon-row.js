// components/goods-coupon-row/goods-coupon-row.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    goodsObj:{
      type:Object
    }
  },
  /**
   * 组件的初始数据
   */
  data: {

  },
  /**
   * 组件的方法列表
   */
  methods: {
    callback({currentTarget}){
      let sn = currentTarget.dataset.sn;
      let received = currentTarget.dataset.received;
      this.triggerEvent('getCP',{sn,received})
    },
    goGood(e){
      this.triggerEvent('goGood',e.currentTarget.dataset.sn)
    }
  }
})
