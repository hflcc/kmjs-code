// components/beauty-expo-item/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    type: { // 可选值：col、row
      type: String,
      value: 'row'
    },
    dataList: {
      type: Array,
      value: []
    }
  },
  options: {
    addGlobalClass: true
  },
  // lifetimes: {
  //   attached: function() {
  //   },
  // },
  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    goToBuy(event) {
      const { sn, once } = event.currentTarget.dataset
      this.triggerEvent('buynow', {
        sn,
        once
      })
    }
  }
})
