Component({
  options: {
    styleIsolation: "apply-shared"
  },
  properties: {
    data: {
      type: Object
    }
  },
  data: {},
  methods: {
    goDetail(e) {
      this.triggerEvent("tapItem", e.currentTarget.dataset.data)
    }
  }
})
