// components/submit-order-sum-up-item/index.js
const app = getApp()
const {
  formatterMultidigitMoney
} = require("../../utils/index")
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    data: {
      type: Object,
      value: {}
    },
    shopList: {
      type: Array,
      value: []
    }
  },
  observers: {
    "data.currencies"(v) {
      this.getbizTypeSn()
    },
    "data.realPrice"(v) {
      if (v == "0.00") {
        if (this.data.result.length) {
          let newList = this.data.list.map(item => {
            if (this.data.result.indexOf(item?.sn) == -1) {
              if (item) {
                item.disabled = true
              }
            }
            return item
          })
          this.setData({
            list: newList
          })
        }
      } else {
        let newList = this.data.list.map(item => {
          item.disabled = false
          return item
        })
        this.setData({
          list: newList
        })
      }
    }
  },
  data: {
    // 邮费弹窗详情
    popShow: false,
    list: [],
    result: [],
    currencySns: "",
    currencyKey: "",
    // 余额支付的方式
    payWay: {},
    current: '',
    // 是否刚进页面第一次调用
    flag: false
  },
  // created(){
  //   this.getbizTypeSn()
  // },
  methods: {
    // 查询采购金列表sn
    async getbizTypeSn() {
      const goodsSn = []
      this.data.shopList.forEach(item => {
        item.goodsList?.forEach(itemChild => {
          goodsSn.push(itemChild.goodsSn)
        })
      })
      let res = await app.get(`/ec/common/goods/pay/ways/${goodsSn.join(",")}`)
      const payWay = {}
      if (res) {
        // 支付方式Map
        for (const key in res) {
          payWay[key] = res[key].join(",")
          // 如果是存在这个key,那么就直接隐藏底部推荐人的输入框
          if (key === 'inst_user') {
            this.setData({ current: 'inst_user' })
            this.triggerEvent("showReferrer", false)
          }
        }
        this.setData({
          payWay
        })
        wx.nextTick(() => {
          this.getbizTypeMsg()
        })
        // res.value = JSON.parse(res.value)
        // for (key in res.value) {
        //   console.log(key)
        //   res.key = key
        // }
        // this.setData({
        //   currencySns: res.value.inst.join(","),
        //   currencyKey: res.key
        // })
        // this.getbizTypeMsg()
      }
    },
    // 通过sn查询对应信息
    async getbizTypeMsg() {
      const PromiseLists = []
      const { payWay } = this.data
      // 获取所有的支付方式
      for (const key in payWay) {
        PromiseLists.push(app.get(`/mk/member/account/batch/current/${key}/${payWay[key]}`))
      }
      const res = await Promise.all(PromiseLists)
      const result = []
      res.forEach(item => {
        if (item && item.data.length) {
          result.push(...item.data.map(item => {
            item ? item.disabled = false : ""
            item.Amount = formatterMultidigitMoney(item.flexibleAmount)
            return {
              ...item,
              disabled: item.balance === 0
            }
          }))

          // 获取产业金的数据
          const rect = result.filter((item) => item.currencyName === '产业金')
          // 如果是有产业金并且是第一次进入页面，默认勾选产业金
          if (!this.data.flag && rect.length && this.data.current === 'inst_user') {
            this.triggerEvent("useBiz", rect)

            this.setData({
              list: result,
              result: [rect[0].sn],
              flag: true
            })
          } else {
            this.setData({
              list: result,
              result: []
            })
          }

          // 选中类型回显
          if (this.data.data.currencies?.length > 0) {
            let arr = this.data.data.currencies.map(item => {
              return item.sn
            })
            this.setData({
              result: arr
            })
          }
        }
      })
      // let res = await app.get(`/mk/member/account/batch/current/${this.data.currencyKey}/${this.data.currencySns}`)
      // if (res && res.data.length) {
      //   res.data = res.data.map(item => {
      //     item ? item.disabled = false : ""
      //     item.Amount = formatterMultidigitMoney(item.flexibleAmount)
      //     return item
      //   })
      //   this.setData({
      //     list: res.data,
      //     result: []
      //     // result:this.data.data.realPrice !='0.00'?[res.data[0].sn]:[]
      //   })
      //   // 选中类型回显
      //   if (this.data.data.currencies?.length > 0) {
      //     let arr = this.data.data.currencies.map(item => {
      //       return item.sn
      //     })
      //     this.setData({
      //       result: arr
      //     })
      //   }
      //   // 处理数据
      //   // this.initBizData()
    },
    // 处理数据
    initBizData() {
      let params = this.data.result.map(item => {
        for (let val of this.data.list) {
          if (val.sn == item) {
            return val
          }
        }
      })
      // 调接口
      this.triggerEvent("useBiz", params)
    },
    showPopup() {
      this.setData({
        popShow: true
      })
    },
    onChange(event) {
      this.setData({
        result: event.detail
      })
      this.initBizData()
    },
    toggle(event) {
      const { index } = event.currentTarget.dataset
      const checkbox = this.selectComponent(`.checkboxes-${index}`)
      checkbox.toggle()
    }
  }
})
