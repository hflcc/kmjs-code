const app = getApp()
Component({
  properties: {},
  data: {
    fileList: []
  },
  methods: {
    // 点击删除
    bindDelete(e) {
      const fileList = this.data.fileList
      fileList.splice(e.detail.index, 1)
      this.setData({
        fileList
      })
    },
    // 获取图片地址
    getFileList() {
      return this.data.fileList
    },
    // 格式化图片数据
    formatterImagesData({ size, url }) {
      return new Promise(async (resolve, reject) => {
        const response = {
          "dirName": "kmjs",
          "suffixName": "",
          "data": ""
        }
        // 最大字节数,400KB
        const maxSize = 1024 * 400
        // 大于最大值,压缩图片
        if (size > maxSize) {
          const result = await this.compressImage(url, 0.5)
          url = result.tempFilePath
        }
        // 获取图片信息
        const imgInfo = await this.getImageInfo(url)
        response.suffixName = imgInfo.type
        // 转base64
        response.data = await this.urlToBase64(imgInfo.path)
        // 抛出去
        resolve(response)
      })
    },
    // 获取图片基本信息
    getImageInfo(src) {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src,
          success(res) {
            resolve(res)
          }
        })
      })
    },
    // 压缩图片
    compressImage(src, quality) {
      return new Promise((resolve, reject) => {
        wx.compressImage({
          src,
          quality,
          success(res) {
            resolve(res)
          }
        })
      })
    },
    // url转base64
    urlToBase64(url) {
      return new Promise((resolve, reject) => {
        wx.getFileSystemManager().readFile({
          filePath: url,
          encoding: "base64",
          success(res) {
            resolve(res.data)
          }
        })
      })
    },
    // 上传图片
    async bindAfterRead(e) {
      // url
      const url = e.detail.file.url
      // 获取上传图片信息
      const uploader = await this.formatterImagesData(e.detail.file)
      // 上传服务器
      const result = await app.post("/oss/upload", uploader)
      if (result) {
        const fileList = this.data.fileList
        fileList.splice(fileList.length, 0, {
          url,
          type: "image",
          seq: result.seq
        })
        this.setData({
          fileList
        })
      }
    }
  }
})
