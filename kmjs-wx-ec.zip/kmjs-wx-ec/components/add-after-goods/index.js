// components/add-after-goods/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    // 隐藏遮罩层 及逻辑操作
    callback() {
      this.triggerEvent("callback")
    },
    /**
     * dataset.type==='0' 取消
     * dataset.type==='1' 确定
     */
    operate({ currentTarget }) {
      let { dataset } = currentTarget
      this.triggerEvent("callback", dataset.type)
    }
  }
})
