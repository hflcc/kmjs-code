let scrollTop = 0
Component({
  options: {
    addGlobalClass: true
  },
  properties: {
    // 必传 是否还有更多数据
    hasData: {
      type: Boolean,
      value: false
    },
    // 必传 数据条数
    size: {
      type: Number
    },
    // 必传 加载状态
    loading: {
      type: Boolean
    },
    triggered: {
      type: Boolean,
      value: false
    }
  },
  data: {
    time: 0,
    // 滚动高度
    scrollTop: 0
  },
  methods: {
    // 触发加载更多
    bindDownLoad() {
      if (this.data.hasData) {
        this.setData({
          time: ++this.data.time
        })
        this.triggerEvent("pullLoading")
      }
    },
    // 滚动时触发
    bindscroll(e) {
      scrollTop = e.detail.scrollTop
    },
    //触发刷新页面
    refresh() {
      this.triggerEvent("pullRefresh")
    },
    // 重置滚动高度
    resetScrollTop() {
      this.setData({
        scrollTop: 0
      })
    },
    // 滚动加1
    addOne() {
      wx.nextTick(()=>{
        this.setData({
          scrollTop: scrollTop + 10
        })
      })
    },
    // 初始化time值  提供给父级调用
    initTime() {
      this.setData({
        time: 0
      })
    }
  }
})
