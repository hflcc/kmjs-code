// components/static-banner/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    productData: {
      type: Object
    },
    productState:{
      type:String
    }
  },
  options: {
    addGlobalClass: true
  },
  methods: {
    after(e) {
      console.log(e);
      let state = e.target.dataset.saledstate;
      let type = e.currentTarget.dataset.type;
      let sn = e.currentTarget.dataset.sn;
      let apply = e.currentTarget.dataset.apply;
      this.triggerEvent('after', {state, sn, apply,type})
    }
  }
})