Component({
  options: {
    addGlobalClass: true
  },
  properties: {
    data: {
      type: Object,
      value: {}
    }
  },
  data: {},
  methods: {
    changeAddress() {
      this.triggerEvent("changeAddress")
    }
  }
})
