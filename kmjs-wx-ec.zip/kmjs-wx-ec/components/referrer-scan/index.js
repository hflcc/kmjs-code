// components/referrer-scan/index.js
const {
  wxToast
} = require("../../utils/index")
const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    scancode:{
      type: String
    },
    referrerName:{
      type:String
    },
    roleData:{
      type:Object
    },
    fromPage:{
      type:String
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 扫描
    onscan(){
      if (this.data.fromPage=="referrer" || (this.data.fromPage=="order" && this.data.roleData.type == 'none')) {
        const _self = this
        wx.scanCode({
          success(res){
            if(res.errMsg=='scanCode:ok'){
              if (res.path) {
                const scene = res.path.split('scene=')[1]
                const decscene = decodeURIComponent(scene)
                app.get(`/sys/common/params/${decscene}`).then(res=>{
                  let parame={}
                  res.value.slice(1).split("&").map(item=>item.split('=')).forEach(item=>{
                    parame[item[0]] = item[1]
                  })
                  if(parame.type=='code'){
                    _self.triggerEvent('getValue',parame.sn)
                    _self.triggerEvent('getValueMsg',parame.sn)
                  }
                }) 
              }else{
                setTimeout(() => {
                  console.log(11);
                  wxToast("该推荐人不存在")
                }, 1000);
              }
            }
          }
        })
      }
    },
    //改变内容
    onchange({detail}){
      this.triggerEvent('getValue',detail)
    },
    onblur({detail}){
      this.triggerEvent('getValueMsg',detail.value)
    },
    onclear(){
      setTimeout(()=>{
        this.triggerEvent('getValue','')
        this.triggerEvent('getValueMsg','')
      },500)
    }

  }
})
