Component({
  properties: {
    shopItem: {
      type: Object
    },
    shopIndex: {
      type: Number
    },
    showCollect: {
      type: Boolean
    }
  },
  options: {
    addGlobalClass: true
  },
  data: {},
  methods: {
    setCollect() {
      this.triggerEvent("setCollect", {
        shopItem: this.data.shopItem,
        shopIndex: this.data.shopIndex
      })
    },
    goShopDetail() {
      this.triggerEvent("goShopDetail", this.data.shopItem)
    }
  }
})
