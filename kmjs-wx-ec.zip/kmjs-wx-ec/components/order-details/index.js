// components/static-banner/index.js
Component({
  properties: {
    orderData: {
      type: Object
    }
  },
  methods: {
    // 点击按钮
    tapBtn(e) {
      const type = e.currentTarget.dataset.type
      const orderData = this.data.orderData
      this.triggerEvent("tapBtn", {
        type,
        orderData
      })
    },
    goShop(e) {
      let shopSn = e.currentTarget.dataset.sn
      this.triggerEvent("goShop", shopSn)
    },
    after(e) {
      console.log(e);
      let orderSn = e.currentTarget.dataset.ordersn;
      let state = e.detail.state;
      let sn = e.detail.sn;
      let type = e.detail.type;
      let apply = e.detail.apply;
      if (state == "complete" && type == "refund") {
        wx.navigateTo({
          url: `/pages/after-sale-list/index?sn=${sn}`
        })
      } else if (state == "none" || (state == "complete" && type)) {
        wx.navigateTo({
          url: `/pages/apply-for-after-sales/index?sn=${sn}&apply=applyFor&orderSn=${orderSn}`,
        });
      } else {
        wx.navigateTo({
          url: `/pages/after-sale-list/index?sn=${sn}`
        })
      }
    }
  },
  data: {
    orderLength: 0
  },
})