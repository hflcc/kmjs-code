// 盒子宽度
let boxWidth = 0
// 滚动 bar 总宽度
let scrollBarContainer = 0
// 滚动 bar 的块高度
let scrollBarBox = 0
// 防抖
let timer = null
const { formatterMoney } = require("../../utils/index")
Component({
  properties: {
    props: {
      type: Object,
      value: {},
      observer() {
        this.initScroll()
      }
    }
  },
  options: {
    addGlobalClass: true
  },
  observers: {
    props(data) {
      let mainGood = {};
      if (data.items && data.items[0]) {
        mainGood = Object.assign({}, data.items[0], { composePrice: formatterMoney(data.items[0].composePrice) })
      }
      this.setData({mainGood})
      let goodList = [];
      if (data && data.items[1]) {
        goodList = data.items.slice(1)
      }
      this.setData({goodList})
    },
  },
  ready() {
    this.initScroll()
    this.setData({
      scrollLeft: 1
    })
  },
  methods: {
    formatter(value) {
      return formatterMoney(value)
    },
    initScroll() {
      wx.nextTick(() => {
        if (this.selectComponent("#kmjs-scroll-view")) {
          this.selectComponent("#kmjs-scroll-view").computedScroll()
        }
      })
    },
    goDetail(e) {
      const detail = e.currentTarget.dataset.detail
      this.triggerEvent("tapItem", detail)
    },
    tapMore() {
      this.triggerEvent("more", "peopleCompose")
    }
  }
})
