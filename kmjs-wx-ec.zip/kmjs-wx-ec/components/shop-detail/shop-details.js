Component({
  properties: {
    obj: {
      type: Object
    },
    tabList:{
      type: Array
    },
    shopShow: {
      type: Boolean
    },
    isShowService: {
      type: Boolean
    }
  },
  observers: {
    obj(val) {
      this.setData({ shop: val })
    },
    tabList(val){
      if(!val.length)return;
      this.setData({ tabId: val[0].sn })
    }

  },
  data: {
    sortList: [
      {
        name: '综合排序',
        id: 1
      },
      {
        name: '销量',
        id: 2
      }, {
        name: '价格',
        id: 3
      }
    ],
    // tabList: [
    //   {
    //     id: 1,
    //     name: '全部'
    //   },
    //   {
    //     id: 2,
    //     name: '美容耗材'
    //   }, {
    //     id: 3,
    //     name: '按摩耗材'
    //   }, {
    //     id: 4,
    //     name: '仪器耗材'
    //   }, {
    //     id: 5,
    //     name: '用品耗材'
    //   }
    // ],
    tabId: '',
    sortType: 'goup',
    activeType: 0,
    shop:{}
  },
  methods:{
    getSort(e) {
      this.setData({ activeType: e.currentTarget.dataset.id });
      if (this.data.activeType === 1) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      } else if (this.data.activeType === 2) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      } else if (this.data.activeType === 3) {
        if (this.data.sortType === "goup") {
          this.setData({ sortType: "desc" })
        } else {
          this.setData({ sortType: "goup" })
        }
      }
    },
    getTab(e) {
      if( e.currentTarget.dataset.id == this.data.tabId) return;
      this.setData({ tabId: e.currentTarget.dataset.id })
      this.triggerEvent('tapTab', e.currentTarget.dataset.item)
    },
    setCollect(e){
      let sn = e.currentTarget.dataset.sn
      this.triggerEvent("setCollect",sn)
    },
    // 跳转到客服
    toService() {
      const {sn, name} = this.data.shop
      wx.navigateTo({
        url: `/packageB/pages/tim/tim?sn=${sn}&title=${name}`
      })
    }
  }
})
