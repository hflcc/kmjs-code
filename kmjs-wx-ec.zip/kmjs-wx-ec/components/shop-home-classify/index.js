import { formatData } from './format'

const app = getApp()


Component({
    options: {
      addGlobalClass: true
    },
    /**
     * 组件的属性列表
     */
    properties: {
        classifySn: {
            type: String,
            value: ''
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        // 后台返回的原始数据
        originData: [],
        imgData: {},
        // 左侧菜单数据
        treeSelectData: [],
        // 左侧选中项的索引
        mainActiveIndex: 0,
        // 右侧菜单数据
        contentData: [],
        // 图片的高度
        picHeight: '0px',
    },

    attached() {
        this.getData(this.data.classifySn)
    },

    detached() {
    },

    /**
     * 组件的方法列表
     */
    methods: {
        async getData(sn) {
            const res = await app.get(`/md/common/shop/category/preview/${sn}`)
            if (res) {
                await this.formatClassify(res)
                // 设置左侧一级分类
                this.handleSetItemsData()
            }
        },
        async formatClassify(arr = []) {
            const { list, ossIds } = formatData(arr)
            const imgRes = await app.picSnGetUrl(ossIds, {width: 186, height: 186}, false, true)
            const imgObj = Object.keys(imgRes).reduce((obj, cur) => {
                obj[cur] = imgRes[cur]?.url || ''
                return obj
            }, {})
            this.setData({
                originData: list,
                imgData: imgObj
            })
        },
        /*
        * @info 设置左侧分类
        * */
        handleSetItemsData() {
            const list = this.data.originData
            this.setData({
                treeSelectData: list,
                mainActiveIndex: 0
            })
            this.handleSetContentData(this.data.mainActiveIndex)
        },
        /*
        * @info 设置右侧内容区域
        * */
        handleSetContentData(index) {
            this.setData({
                contentData: this.data.treeSelectData[index]?.items || []
            })
            wx.nextTick(() => {
                this.createSelectorQuery().select("#categoryItem").boundingClientRect(({width}) => {
                    this.setData({
                        picHeight: width + 'px'
                    })
                }).exec()
            })
        },
        goDetail(e) {
            const item = e.currentTarget?.dataset?.data || {}
            wx.navigateTo({
                url: `/packageA/pages/manage/index?sn=${item.sn}&type=goodsClassity`
            })
        },
        /*
        * @info 点击左侧一级分类
        * */
        onClickNav(e) {
            this.handleSetContentData(e.detail.index)
        },
    }
})
