export function formatData(list = []) {
  const ossIds = []
  const deep = (arr) => {
    arr.forEach(item => {
      item.text = item.name;
      item.ossId && ossIds.push(item.ossId);
      if (item.items?.length && Array.isArray(item.items)) {
        deep(item.items)
      }
    })
  }
  deep(list)
  return {
    list,
    ossIds
  }
}
