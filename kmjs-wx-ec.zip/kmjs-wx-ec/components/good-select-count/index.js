const { formatterMoney, wxToast } = require("../../utils/index")
const { formatterDialogData } = require("../../pages/goods-detail/goodsDetail")
const app = getApp()
Component({
  properties: {
    goodsSn: {
      type: String,
      value: ""
    },
    showSpecType: {
      type: String,
      value: ""
    },
    show: Boolean
  },
  options: {
    addGlobalClass: true
  },
  data: {
    // 详情接口返回的数据 用于组装数据给程鹏;
    detailApiResponse: {},
    // 数据
    data: {
      // 商品图片
      pic: "",
      // 商品名称
      name: "",
      // 展示的价格
      priceList: [],
      // 是否阶梯价
      isTieredPricing: false,
      // sku列表
      skuList: [],
      // 选中多少项
      sumCount: 0,
      // 总计
      sumPrice: 0,
      // 是否可以提交
      canSubmit: false
    },
    // 是否展示全部数据
    checkedAllSku: false,
    // 规格列表
    specList: [],
    // 选中的分类
    activeTabs: "",
    // 商品类型
    goodActiveType: "",
    // 价格的类型
    priceKey: "",
    // 展示的最小价格的key
    showMinPriceKey: "",
    // 展示的最大价格的key
    showMaxPriceKey: "",
    // 商品类型
    activeType: "",
    // 优惠价
    assistPrice: "",
    // 持有券状态  是否领取:takeFlag 是否使用:useFlag
    holdCouponType: {}
  },
  methods: {
    // 获取已选的文字
    getSelectList() {
      const { skuList } = this.data.data
      const result = []
      skuList.forEach(({ type01, type02, count }) => {
        if (count > 0) {
          result.push(`${type01},${type02} * ${count}`)
        }
      })
      return result
    },
    // 切换tab时触发
    onChangeTab(e) {
      this.setData({
        activeTabs: e.detail.name
      })
    },
    // 切换是否只显示有值的数据;
    changeChecked() {
      this.setData({
        checkedAllSku: !this.data.checkedAllSku
      })
    },
    // 切换数值
    onChange(e) {
      // 索引
      const index = e.target.dataset.index
      // 值
      let value = parseInt(e.detail)
      // 取出非阶梯价的价格规则
      const { showSpecType, data, priceKey } = this.data
      const { skuList } = data
      // 操作哪一行的sku
      const skuItem = skuList[index]
      // 默认价格数据
      const defaultPrice = skuItem.ladderPrice[0]
      // 真实价格
      let realPrice = defaultPrice[priceKey]
      // 价格类型
      let priceType = defaultPrice.priceType
      // 价格sn
      let priceSn = defaultPrice.priceSn
      // 修改数量
      if (value > skuItem.maxNum) {
        value = skuItem.maxNum
      }
      skuItem.count = value
      this.selectAllComponents(".stepper").forEach(item => {
        item.observeValue()
      })
      // 获取真实价格
      skuItem.ladderPrice.forEach(item => {
        if (value >= item.min && item.max >= value) {
          realPrice = item[priceKey]
          priceType = item.priceType
          priceSn = item.priceSn
        }
      })
      // 修改价格
      skuItem.realPrice = formatterMoney(realPrice)
      skuItem.priceType = priceType
      skuItem.priceSn = priceSn
      this.setData({
        "data.skuList": skuList
      })
      // 计算价格
      this.computedChange()
    },
    // 数量切换,触发重新计算价格;
    computedChange() {
      let { data, specList } = this.data
      // 是否可以确定下单
      data.canSubmit = false
      // 已选的件数;已选的总价
      let sumCount = 0, sumPrice = 0
      // parentSn: 数量
      const specMap = {}
      // 遍历sku的数组
      data.skuList.forEach(({ count, realPrice, parentSn, minNum, maxNum }) => {
        // 数量在起批量之间时,可以点击提交
        if (count >= minNum && count <= maxNum) {
          data.canSubmit = true
        }
        sumCount += count
        sumPrice += count * realPrice
        // 每个大分类的数量
        if (typeof specMap[parentSn] === "number") {
          specMap[parentSn] += count
        } else {
          specMap[parentSn] = count
        }
      })
      data.sumCount = sumCount
      data.sumPrice = formatterMoney(sumPrice)
      specList.forEach((item) => {
        item.count = specMap[item.sn]
      })
      this.setData({
        data,
        specList
      })
      wx.nextTick(() => {
        this.selectComponent("#tabs")?.resize()
      })
    },
    // 关闭弹窗;
    close() {
      this.triggerEvent("close", false)
    },
    // 计算是否可以提交
    computedCanSubmit() {
      let { skuList } = this.data.data
      let result = true
      for (let i = 0; i < skuList.length; i++) {
        const { minNum, maxNum, count, type01 } = skuList[i]
        // 0件可以被过滤
        if (count !== 0 && (minNum > count || count > maxNum)) {
          if (count > maxNum) {
            wxToast(`${type01}规格最大起批${maxNum}件`)
          } else {
            wxToast(`${type01}规格最少起批${minNum}件`)
          }
          result = false
          break
        }
      }
      return result
    },
    // 格式化提交的代码
    formatterCommitData() {
      let { skuList } = this.data.data
      const result = []
      skuList.forEach(({ skuSn, priceType, priceSn, realPrice: price, count: quantity }) => {
        if (quantity > 0) {
          result.push({
            skuSn,
            priceType,
            priceSn,
            price: parseFloat(price),
            quantity
          })
        }
      })
      if (result.length === 0) {
        wxToast("请添加商品数量")
        return
      }
      return result
    },
    // 提交验证
    submitOrder(e) {
      if (this.computedCanSubmit()) {
        const result = this.formatterCommitData()
        if (result && Array.isArray(result)) {
          let { type } = e.target.dataset
          const { showSpecType } = this.data
          type = type === "submit" ? showSpecType : type
          //#region 程鹏让改的;
          const { detailApiResponse } = this.data
          const goodActiveType = detailApiResponse.goodActiveType
          /*
          * 当 goodActiveType 为 ticket("权益券"),active("活动") 时
          * 1. 找到对应的 skus 中的 activePrice 赋值给 price;
          * 2. priceType赋值为"active"
          * 3. 加入新字段 activeType 在detail.promotePrices.activeType 中取
          * 4. priceSn 改成 skuSn
          * */
          if (goodActiveType === "active") {
            result.forEach(item => {
              // 第一步
              detailApiResponse.skus.forEach(priceItem => {
                if (item.skuSn === priceItem.sn) {
                  item.price = priceItem.activePrice
                }
              })
              // 第二步
              item.priceType = "active"
              // 第三步
              item.activeType = detailApiResponse?.promotePrices?.activeType || null
              // 第四步
              item.priceSn = item.skuSn
            })
          }
          //#endregion
          this.triggerEvent("submitOrder", {
            type,
            result
          })
        }
      }
    }
  },
  observers: {
    /**
     * 组建展示时获取到可选择数量的最大值
     * */
    "show"(show) {
      if (show && this.data.goodsSn) {
        formatterDialogData(this.data.goodsSn, app).then(({ result, detail }) => {
          const data = result
          // 格式化拼团价格
          data.data.skuList = data.data.skuList.map(item => {
            return {
              ...item,
              realPrice: item[this.data.priceKey]
            }
          })
          this.setData({
            detailApiResponse: detail,
            ...data
          })
          wx.nextTick(() => {
            this.computedChange()
          })
        })
      }
    },
    "showSpecType"(showSpecType) {
      this.setData({
        priceKey: showSpecType === "openGroup" || showSpecType === "joinGroup" ? "composePrice" : "price",
        showMinPriceKey: showSpecType === "openGroup" || showSpecType === "joinGroup" ? "composeMinPrice" : "minPrice",
        showMaxPriceKey: showSpecType === "openGroup" || showSpecType === "joinGroup" ? "composeMaxPrice" : "maxPrice"
      })
    }
  }
})
