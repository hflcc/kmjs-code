Component({
    options: {
        styleIsolation: 'isolated',
        multipleSlots: true
    },
    /**
     * 组件的属性列表
     */
    properties: {
        imgWidth: {
            type: Number,
            value: 480
        },
        imgHeight: {
            type: Number,
            value: 350
        },
        imgSrc: {
            type: String,
            value: ''
        },
        nullText: {
            type: String,
            value: '暂无数据'
        }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {

    }
})
