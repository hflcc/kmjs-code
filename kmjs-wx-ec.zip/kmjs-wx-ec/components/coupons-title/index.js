// components/coupons/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    /** 
     * type
     * col 竖版
     * row 横版
     * maxrow 大横版
    */
    title:{
      type:String,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 更多-回调
    callback(){
      this.triggerEvent('more')
    }
  }
})
