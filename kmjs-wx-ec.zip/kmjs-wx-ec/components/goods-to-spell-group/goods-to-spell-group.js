// components/goods-to-spell-group/goods-to-spell-group.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    data:{
      type:Object
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    time: 30 * 60 * 60 * 1000,
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
