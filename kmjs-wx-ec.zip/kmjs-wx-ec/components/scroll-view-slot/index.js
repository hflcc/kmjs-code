// components/scroll-view-slot/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    hidloading: {
      type: Boolean,
      value: true
    },
    hiddivider: {
      type: Boolean,
      value: true
    },
    scrollViewTop: {
      type: Number,
      value: 0
    },
    stopScroll: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    bindscrolltolower() {
      if (this.data.stopScroll) return
      this.triggerEvent("scrolltolower")
    }
  }
})
