const { formatterMoney, wxToast } = require("../../utils/index")
import { formatterDialogData } from '../../pages/goods-detail/goodsDetail'
const app = getApp()

Component({
    options: {
        addGlobalClass: true
    },

    properties: {
        show: {
            type: Boolean,
            value: false
        },
        goodsSn: {
            type: String,
            value: ''
        },
        // 调用sku弹窗的点击按钮类型
        showSpecType: {
            type: String,
            value: '' // 已选backDetail 加入进货单addShopList 立即采购buyNow
        },
    },

    data: {
        showTwoBtn: false,
        showConfirmBtn: true,
        // 商品详情
        goodsDetail: {},
        state: {
            // 商品图片
            pic: "",
            // 商品名称
            name: "",
            // 展示的价格
            priceList: [],
            // 是否阶梯价
            isTieredPricing: false,
            // sku列表
            skuList: []
        },
        // 是否可以提交
        canSubmit: false,
        // 规格菜单
        specsList: [],
        // 筛选后展示出来的sku列表
        showSkuList: [],
        firstSpecIndex: 0,
        firstSpecList: [],
        secondSpecIndex: '',
        secondSpecList: [],
        thirdSpecIndex: '',
        thirdSpecList: [],
        // normal普通, compose拼团, active活动
        discountType: '',
        // 选择的sku总件数
        selectedTotalSkuNum: 0,
        // 点击已选*件切换显示/隐藏
        showAllSelectedSku: false,
        // 商品总计价格
        totalPrice: formatterMoney(0)
    },

    methods: {
        /*
        * @info 关闭sku弹窗
        * */
        handleClose() {
            this.triggerEvent("close", false)
        },
        /*
        * @info 供父组件调用获取选中的skuList数据
        * */
        getSelectList() {
            return this.data.state.skuList.filter(item => item._writeCount > 0).map(item => `${item.name} * ${item._writeCount}`)
        },
        /*
        * @info 初始化规格菜单列表
        * */
        initSpecsList() {
            const list = this.data.specsList
            const i = this.data.firstSpecIndex
            this.setData({
                firstSpecList: list,
                secondSpecList: list[i]?.twoList || [],
                thirdSpecList: []
            })
        },
        init() {
            this.setData({
                canSubmit: false,
                showTwoBtn: this.data.showSpecType === 'backDetail',
                showConfirmBtn: ['buyNow', 'addShopList', 'joinGroup', 'originalPrice', 'openGroup'].includes(this.data.showSpecType),
                firstSpecIndex: 0,
                firstSpecList: [],
                secondSpecIndex: '',
                secondSpecList: [],
                thirdSpecIndex: '',
                thirdSpecList: [],
                selectedTotalSkuNum: 0,
                showAllSelectedSku: false,
                allSelectedSkuList: [],
                totalPrice: formatterMoney(0)
            })
        },
        /*
        * @info 初始化sku列表
        * */
        initSkuList() {
            const { specsList, firstSpecIndex } = this.data
            const { skuList } = this.data.state
            const firstSpecSn = specsList[firstSpecIndex]?.sn
            this.setData({
                showSkuList: skuList?.filter(item => item.specSns.includes(firstSpecSn))
            })
        },
        handleSkuStepChange(e) {
            const { discountType, showSkuList, state } = this.data
            let val = e.detail
            const targetIndex = e.currentTarget.dataset.index
            const targetSn = showSkuList[targetIndex]?.sn
            const sourceIndex = state.skuList.findIndex(item => item.sn === targetSn)
            const stepPriceList = showSkuList[targetIndex]?.stepPrices || []
            let cachePrice,cacheSn,cachePriceType,disablePlus;
            // 如果当前商品是普通商品 normal
            if (discountType === 'normal') {
                // 根据当前输入的数量, 找到商品符合的阶梯价格
                const elem = this.getStepPriceObj(stepPriceList, val)
                cachePrice = elem?.price
                cacheSn = elem?.sn
                cachePriceType = elem.priceType
                val = elem.canBuyCount
                disablePlus = elem.disablePlus
            // 如果当前商品是拼团商品 compose
            } else if (discountType === 'compose') {
                const compose = showSkuList[targetIndex]?.compose || {}
                cachePrice = compose.composePrice
                // 取sku的sn
                cacheSn = targetSn
                cachePriceType = 'sku'
            // 如果当前商品是活动商品 active
            } else if (discountType === 'active') {
                // 活动商品不限制购买件数，以最大库存数为准 (20220330腾讯会议纪要)
                const promote = showSkuList[targetIndex]?.promote
                if (promote) {
                    cachePrice = promote.price || 0
                    cacheSn = promote.sn
                    cachePriceType = 'active'
                } else {
                    console.log('此sku没有配置活动promote')
                }
            }
            // 将变化后的值赋值给原来state.skuList中,用来记住值(修改showSkuList数据的同时也在修改state.skuList中的数据)
            this.setData({
                [`showSkuList[${targetIndex}]._actualPrice`]: formatterMoney(cachePrice),
                [`showSkuList[${targetIndex}]._actualPriceSn`]: cacheSn,
                [`showSkuList[${targetIndex}]._actualPriceType`]: cachePriceType,
                [`showSkuList[${targetIndex}]._writeCount`]: val,
                [`state.skuList[${sourceIndex}]._writeCount`]: val,
                [`showSkuList[${targetIndex}]._disablePlus`]: !!disablePlus
            })
            this.handleComputedSelectedSku()
        },
        /*
        * @info van-stepper失去焦点时触发
        * */
        handleSkuStepBlur (e) {
            const { index } = e.currentTarget.dataset
            // 这里为了解决失去焦点时van-stepper不更新值的bug,强行触发重新渲染
            this.setData({
                [`showSkuList[${index}]._hide`]: true,
            })
            wx.nextTick(() => {
                this.setData({
                    [`showSkuList[${index}]._hide`]: false
                })
            })
        },
        /**
         * @info 统一封装获取阶梯价逻辑
         * @param list {Array} 当前正在操作的sku的阶梯价数组
         * @param val {Number} 当前输入的sku购买数量
         * @return {Object}
         * */
        getStepPriceObj(list = [], val) {
            if (!list.length) return {}
            let obj = list.find(elem => val >= elem.min && (val <= elem.max || elem.max === 0))
            const lastItem = list[list.length - 1]
            if (!obj) {
                obj = lastItem
            }
            return {
                price: obj.price,
                sn: obj.sn,
                priceType: 'step',
                // 根据阶梯价范围判断, 确定用户最大可以购买的数量, max为0时代表无上限
                canBuyCount: val > obj.max && obj.max !== 0 ? obj.max : val,
                // 是否禁用当前van-stepper的增加按钮
                disablePlus: val >= lastItem.max && lastItem.max !== 0
            }
        },
        /*
        * @info 处理第一级的规格选择
        * */
        handleSelectFirstSpec(e) {
            const index = e.currentTarget.dataset.index
            this.setData({
                showSkuList: [],
                firstSpecIndex: index,
                secondSpecIndex: '',
                thirdSpecIndex: ''
            })
            this.initSpecsList()
            this.initSkuList()
        },
        /*
        * @info 如果有第二级规格,就处理第二级的规格选择
        * */
        handleSelectSecondSpec(e) {
            const index = e.currentTarget.dataset.index
            const { secondSpecList, firstSpecList, firstSpecIndex, state } = this.data
            this.setData({
                showSkuList: [],
                secondSpecIndex: index,
                thirdSpecList: secondSpecList[index]?.threeList || [],
                thirdSpecIndex: ''
            })
            wx.nextTick(() => {
                const firstSpecSn = firstSpecList[firstSpecIndex]?.sn
                const secondSpecSn = secondSpecList[index]?.sn
                // 此时展示的showSkuList要同时含有一级规格sn和二级规格sn的列表
                const list = state.skuList.filter(item => item.specSns.includes(firstSpecSn) && item.specSns.includes(secondSpecSn))
                this.setData({
                    showSkuList: list
                })
            })
        },
        /*
        * @info 如果有第三级规格,就处理第三级的规格选择
        * */
        handleSelectThirdSpec(e) {
            const index = e.currentTarget.dataset.index
            this.setData({
                showSkuList: [],
                thirdSpecIndex: index
            })
            wx.nextTick(() => {
                const { firstSpecList, firstSpecIndex, secondSpecList, secondSpecIndex, thirdSpecList, state } = this.data
                const firstSpecSn = firstSpecList[firstSpecIndex]?.sn
                const secondSpecSn = secondSpecList[secondSpecIndex]?.sn
                const thirdSpecSn = thirdSpecList[index]?.sn
                // 此时展示的showSkuList要同时含有一级规格sn和二级规格sn以及三级规格的列表
                const list = state.skuList.filter(item => item.specSns.includes(firstSpecSn) && item.specSns.includes(secondSpecSn) && item.specSns.includes(thirdSpecSn))
                this.setData({
                    showSkuList: list
                })
            })
        },
        /*
        * @info 此方法主要计算已选的sku件数, sku的加减都会触发此方法
        * */
        handleComputedSelectedSku () {
            const list = []
            let price = 0
            let succ = false
            const totalNum = this.data.state.skuList.reduce((total, cur) => {
                if (cur._writeCount > 0) {
                    total += cur._writeCount
                    price += cur._writeCount * cur._actualPrice
                    list.push(cur)
                    if (cur._writeCount >= cur.stepPrices[0]?.min) {
                        succ = true
                    }
                }
                return total
            }, 0)
            this.setData({
                selectedTotalSkuNum: parseInt(totalNum), // 选择的总件数
                allSelectedSkuList: list, // 已经操作选择过的sku列表
                totalPrice: formatterMoney(price), // 商品总计价格
                canSubmit: succ
            })
        },
        /*
        * @info 点击已选/继续选购切换展示skulist列表
        * */
        changeShowAllSelected () {
            if (this.data.showAllSelectedSku) {
                this.setData({
                    showAllSelectedSku: false,
                    showSkuList: this.data.skuListCache
                })
            } else {
                // 将切换前的showSkuList缓存起来,等切换回去的时候直接取值展示
                this.data.skuListCache = this.data.showSkuList
                this.setData({
                    showAllSelectedSku: true,
                    showSkuList: this.data.allSelectedSkuList
                })
            }
        },
        /*
        * @info 点击确认按钮触发提交
        * */
        handleSubmitOrder(e) {
            if (!this.data.canSubmit) return
            let { type } = e.currentTarget.dataset
            type = type === 'submit' ? this.data.showSpecType : type
            const result = this.formatterCommitData()
            if (result) {
                this.triggerEvent("submitOrder", {
                    type,
                    result
                })
            }
        },
        // 格式化提交的代码
        formatterCommitData() {
            const { state } = this.data
            const result = state.skuList.reduce((list, cur) => {
                if (cur._writeCount > 0) {
                    list.push({
                        skuSn: cur.sn,
                        priceType: cur._actualPriceType,
                        priceSn: cur._actualPriceSn,
                        price: parseFloat(cur._actualPrice),
                        quantity: cur._writeCount
                    })
                }
                return list
            }, [])
            if (!result.length) {
                wxToast("请添加商品数量")
                return false
            }
            return result
        }
    },
    observers: {
        'show'(show) {
            if (show && this.data.goodsSn) {
                console.log(this.data.showSpecType)
                formatterDialogData(this.data.goodsSn, app).then(({ detail, result }) => {
                    this.setData({
                        state: {},
                        specsList: [],
                        showSkuList: []
                    })
                    wx.nextTick(() => {
                        this.setData({
                            goodsDetail: detail || {},
                            discountType: detail?.discountType || 'normal', // 没有传入就默认普通商品
                            state: result?.data || {},
                            specsList: result?.specsList || []
                        })
                        this.init()
                        this.initSpecsList()
                        this.initSkuList()
                    })
                })
            }
        },
        "showSpecType"(showSpecType) {
        }
    }
})
