const compBehavior = require("miniprogram-computed").behavior


Component({
    behaviors: [compBehavior],
    /**
     * 组件的属性列表
     */
    properties: {
        shopDetails: {
            type: Object,
            value: {}
        }
    },

    computed: {
      baseInfoRichText(data) {
          return data.shopDetails?.baseInfo?.replace(/\<img/gi, '<img style="max-width:100%;height:auto" ')
      }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {
        /*
  * @info 店铺信息点击拨打电话
  * */
        handleCall() {
            wx.makePhoneCall({
                phoneNumber: this.data.shopDetails.phoneNum
            })
        },
    }
})
