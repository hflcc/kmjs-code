// components/canvas/index.js
Component({
  imagePath: '',
  history: [],
  future: [],
  /**
   * 组件的属性列表
   */
  properties: {
    shareData:{
      type:Object
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    paintPallette:{},
  },
  ready(){
    wx.showLoading({
      title: '正在生成图片',
    })
    const startLeft = 20;
    const startRight = 30;
    function _text(content, top, left, color, size,fontWeight="normal",arg) {
      return ({
        type: 'text',
        text: content,
        css: [{...{
          left: `${left}rpx`,
          top:`${top}rpx`,
          fontSize:`${size}rpx`,
          color,
          fontWeight,
        },...arg}],
      });
    }
    function _image(url, width,height,top, left, borderRadius) {
      return ({
        type: "image",
        url,
        css: {
          width: `${width}rpx`,
          height: `${height}rpx`,
          top: `${top}rpx`,
          left: `${left}rpx`,
          borderRadius: `${borderRadius}rpx`,
          mode: "scaleToFill"
        }
      });
    }
    let {title,imageUrl,minPrice,maxPrice,salePrice,saleHeadImg,saleHeadName,shareImg} = this.data.shareData
    title = title.length>36?title.slice(0,40)+'...':title
    // 阶梯价
    let p = minPrice==maxPrice?`￥${minPrice}`:`￥${minPrice}~${maxPrice}`
   let views =  [
      // logo
      _image(saleHeadImg.replace('http://thirdwx.qlogo.cn', 'https://thirdwx.qlogo.cn'),70,70,20,startLeft,70),
      // 主图
      _image(imageUrl.replace('https://resource.kmyun.cn','https://kmjs.oss-cn-shenzhen.aliyuncs.com'),650,550,110,0,0),
      // name
      _text(saleHeadName,28,100,'#333333','24','bold'),
      _text('低价质优的耗品集采好货，别错过哦！',62,100,'#999999','20',''),
      _text(p,690,startLeft,'#E61E1C','40',''),
      _text(title,802,startLeft,'#999999','24','',{"width": "397rpx","lineHeight": "32rpx"}),
      
      {
        "type": "text",
        "text": "   ",
        "css": {
          "background": "linear-gradient(-135deg, #F76932 0%, #E61E1C 100%)",
          "width": "650rpx",
          "height": "80rpx",
          "bottom": "0",
          "lineHeight": "80rpx",
        }
      },
      {
        "type": "text",
        "text": "超值低价 质优物美 售后无忧",
        "css": {
          "bottom":"32rpx",
          "color": "#fff",
          "right":`${startRight}rpx`,
          "fontSize": "24rpx",
        }
      },
      // 文字logo
      {
        type: "image",
        url:'https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/textlogo-1624413363476.png',
        css: {
          width: `129rpx`,
          height: `42rpx`,
          bottom:"20rpx",
          left: `${startLeft}rpx`,
          mode: "scaleToFill"
        }
      },
      // 小程序码
      _image(`data:image/png;base64,${shareImg}`,140,140,690,482,0),
      _text(`长按识别或扫 描采购`,840,482,'#999999','20','',{width:'130rpx',"lineHeight": "30rpx"}),
    ]
    if(salePrice!=0.00 || salePrice!=0){
      views.push(_text(`每件最高可省${salePrice}元`,747,startLeft,'#333333','26','bold'))
    }
    this.setData({
      paintPallette:{
        width: '650rpx',
        height: '990rpx',
        background: '#ffffff',
        views
      }
    });
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 动态模版，绘制结束时触发
    // didShow(e){
    //   console.log('绘制结束时触发');
    // },
    // 图片生成成功，可以从 e.detail.path 获取生成的图片路径
    onImgOK(e) {
      this.imagePath = e.detail.path;
      this.setData({
        image: this.imagePath
      })
      wx.hideLoading()
    },
    // 图片生成失败
    onImgErr(e){
      wx.showToast({
        title: e.detail.error,
        icon: 'none',
        duration: 2000
      })
      console.log('生成海报失败');
      wx.hideLoading()
      this.triggerEvent('closePoster')
    },
    // 保存图片
    saveImage() {
      const _self = this
      if (this.imagePath && typeof this.imagePath === 'string') {
        wx.saveImageToPhotosAlbum({
          filePath: this.imagePath,
          success(data) {
            if(data.errMsg=="saveImageToPhotosAlbum:ok"){
              wx.showToast({
                title: '已保存至相册',
                icon: 'success',
                duration: 2000
              })
            }
            _self.triggerEvent('closePoster')
          },
          fail(err) {
            console.log('err',err);
          }
        });
      }
    },
  }
})
