Component({
  properties: {
    type: {
      type: String
    },
    data: {
      type: Object
    }
  },
  options: {
    addGlobalClass: true
  },
  data: {
    // // type: "addGoods",
    // // type: "proposerAfterSale",
    // type: "afterSaleDetail",
    // data: {
    //   // 当前sku的orderSn
    //   orderSn: "",
    //   // 是否选中当前sku
    //   checkedSku: false,
    //   // 商品名称
    //   goodsName: "马丁男士古龙香薰亚光质感造型发 蜡80g(男士头发护理 持久定型)马丁男士古龙香薰亚光质感造型发 蜡80g(男士头发护理 持久定型)",
    //   // 商品图片
    //   goodsImage: "https://img.yzcdn.cn/vant/cat.jpeg",
    //   // 规格名称
    //   skuName: "自然色",
    //   // 当前sku状态
    //   skuStatus: "售后中",
    //   // 当前sku购买的数量
    //   skuCount: "10",
    //   // 当前sku购买的单价
    //   skuPrice: "20",
    //   // 当前sku购买的总价
    //   skuSum: "200"
    // }
  },
  methods: {
    checkedIcon() {
      if (!this.data.data.skuStatus) {
        this.triggerEvent("checkedIcon", this.data.data.orderSn)
      }
    }
  }
})
