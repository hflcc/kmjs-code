// components/steps/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    params:{
      type:Array
    },
    stepsList:{
      type:Array
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    toggleAnimationData: {}, // 动画
    onceheight:'',
    allheight:''

  },

  observers:{
    params(val){
      if (val.length>1) {
        this.animation = wx.createAnimation({
          duration:200,
          timingFunction:'ease-out'
        })
        // 如果是展开的，就让它收缩
        let maxheight = parseInt(this.data.allheight)>600?'600rpx':this.data.allheight
        this.animation.height(maxheight).step()
      } else {
        if(!this.data.onceheight || parseInt(this.data.onceheight)<0){
          this.getHeight('once')
        }
        this.animation = wx.createAnimation({
          delay:-200,
          timingFunction:'ease-out'
        })
        this.animation.height(this.data.onceheight).step()
      }
      this.setData({
        toggleAnimationData: this.animation.export()
      });

    }
  },
  
  /**
   * 组件的方法列表
   */
  ready(){
  },
  methods: {
    afterRead(){
      this.triggerEvent("lookImage")
    },
    initonceheight(){
      this.setData({
        onceheight:'',
        allheight:'',
      })
    },
    /**
     * 
     * @param {*} type 
     * all
     * once
     */
    getHeight(type){
      const query = wx.createSelectorQuery()
      query.select('.steps').boundingClientRect()
      query.selectViewport()
      query.exec((res)=>{
        if(!res[0])return;
        let {height,width} = res[0]
        let ratio  = 750/width
        if(type=='all'){
          ratio = (height-35)*ratio+'rpx'
          this.animation.height(ratio).step()
          this.setData({
            allheight:ratio
          })
        }else{
          ratio = this.data.stepsList?.length==1?(height)*ratio+'rpx':(height-35)*ratio+'rpx'
          this.animation.height(ratio).step()
          this.setData({
            onceheight:ratio
          })
        }
        this.setData({
          toggleAnimationData: this.animation.export()
        })
      })
    }
  }
})
