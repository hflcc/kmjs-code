Component({
  options: {
    addGlobalClass: true
  },
  pageLifetimes: {
    hide: function () {
      const childs = this.selectAllComponents(".swipe")
      childs.forEach(child => {
        child.close()
      })
    }
  },
  properties: {
    data: {
      type: Object,
      value: {}
    },
    index: {
      type: Number
    }
  },
  data: {},
  methods: {
    // 商铺首页
    goShopHome(e) {
      const item = e.currentTarget.dataset.item
      wx.navigateTo({
        url: `/packageA/pages/shop-home/index?sn=${item.shopSn}`
      })
    },
    // 商品首页
    goGoodsHome(e) {
      const item = e.currentTarget.dataset.item
      wx.navigateTo({
        url: `/pages/goods-detail/index?sn=${item.shopGoodsSn}`
      })
    },
    // 删除商品
    deleteGoods(e) {
      const item = e.currentTarget.dataset.item
      this.triggerEvent("deleteShoppingCar", item)
    },
    // 选择了谁
    tapSelect(e) {
      this.triggerEvent("selectChange", {
        level: e.currentTarget.dataset.level,
        index: [this.data.index, e.currentTarget.dataset.index2, e.currentTarget.dataset.index3]
      })
    },
    // 变化了谁
    countChange(e) {
      let type = e.type
      let v=''
      switch(type){
        case "plus":
          setTimeout(()=>{
            v = e.currentTarget.dataset.value
            v++;
            this.handleCountChange(e,v)
          },500)
          break;
        case "minus":
          setTimeout(()=>{
            v = e.currentTarget.dataset.value
            v--;
            this.handleCountChange(e,v)
          },500)
          break;
        case "blur":
          v=e.detail.value;
          this.handleCountChange(e,v)
          break;
      }


    },
    updataInput(){
      let vts = this.selectAllComponents(".van-stepper")
      vts.forEach(vt=>{
        vt.observeValue()
      })
    },
    //
    handleCountChange(e,v){
      let value = parseInt(v)
      let index2 = e.currentTarget.dataset.index2
      if (value > this.data.data.goodsList[index2].maxNum) {
        value = this.data.data.goodsList[index2].maxNum
        this.updataInput()
      }
      if(value < this.data.data.goodsList[index2].minNum ){
        value = this.data.data.goodsList[index2].minNum
        this.updataInput()
      }
      this.triggerEvent("countChange", {
        value,
        index1: this.data.index,
        index2: index2,
        index3: e.currentTarget.dataset.index3
      })
    }
  }
})
