import { EventBus, formatterTime, formatterMoney,formatterTimeTim, INSTID, OPENID, refreshToken, TOKEN, PHONENUM} from "./utils/index"

import TIM from 'tim-wx-sdk';
const axios = require("./utils/axios")
let timerName
App({
  //发布订阅
  eventBus: new EventBus(),
  onLaunch() {
    // 初始化设备信息
    this.initDeviceMsg()
    // 初始化工具方法
    this.initUtils()
    // 刷新token, 方法内部判定是否需要刷新token
    refreshToken(this)
    // 获取省市区方法
    // this.getAreaList()
    // 获取地址
    if (this.globalData && this.globalData.userInfo && this.globalData.userInfo.token) {
      this.getAddressList()
      this.getAreaList()
    }
    this.propertyInfo()
    // 获取耗品go首页动态tab数组,注意:当前并没有支持动态改变tab,只是用在首页信息流获取sn用
    this.getDynamicTab()
    // this.payDefSnData()
  },
  onShow() {
    const envs = wx.getAccountInfoSync().miniProgram.envVersion;
    let tim = TIM.create({
      SDKAppID: envs==='release'?1400614852:1400530567 // 接入时需要将0替换为您的即时通信 IM 应用的 SDKAppID
    }); // SDK 实例通常用 tim 表示

    tim.setLogLevel(1);

    // 注册腾讯云即时通信 IM 上传插件
    // tim.registerPlugin({
    //   'tim-upload-plugin': TIMUploadPlugin
    // });
    this.globalData.tim = tim
    // 获取设备机型
    wx.getSystemInfo({
      success: (res) => {
        console.log('手机信息res' + res.model)
        let model = res.model;
        if (/iphone/i.test(model)) {
          this.isGlobalIphone.isIphone = true;
        } else {
          this.isGlobalIphone.isIphone = false;
        }
      }
    })
    this.startReportHeart()
  },
  startReportHeart() {
    timerName = setInterval(() => {
      let pages = this.pagesRoute()
      if (pages) {
        this.messageFun()
      }
    }, 1000 * 10)
  },
  // 是否为tabbar页面
  pagesRoute() {
    let page = getCurrentPages().length===1&&getCurrentPages()[0].route
    const tabpages = ['pages/index/index','pages/classify/index','pages/purchase-list/index','pages/self/index']
    return tabpages.includes(page)
  },
  onHide() {
    clearInterval(timerName)
    wx.setStorageSync(this.globalData.userInfo.InstId.id + 'mbh_coupon_showtime', "")
    wx.setStorageSync(this.globalData.userInfo.InstId.id + 'new_coupon_showtime', "")
  },
  globalData: {
    // 用户信息
    userInfo: {
      token: wx.getStorageSync(TOKEN),
      InstId: wx.getStorageSync(INSTID),
      openId: wx.getStorageSync(OPENID),
      phoneNum: wx.getStorageSync(PHONENUM)
    },
    loginData: {},
    // 默认地址
    userAddress: {},
    // 省市区集合
    areaList: [],
    // 系统配置
    propertyList:{},
    appConfig: {},
    // 耗品go首页动态tab,暂时未支持动态tab
    indexDynamicTab: [],
    // 耗品go首页信息流sn
    indexInfoFlowSn: '',
    tim: null,
    // 耗品go的支付定义sn
    payDefSn:''
  },
  // 设备信息
  deviceMsg: {},
  // 页面找不到的时候
  onPageNotFound() {
    wx.redirectTo({
      url: "/pages/index/index"
    })
  },
  // 初始化设备信息
  initDeviceMsg() {
    // 设置设备信息
    this.deviceMsg = wx.getSystemInfoSync()
    // 胶囊按钮的位置信息
    this.getMenuBoundingMsg()
    // 设置环境变量
    this.ENV = wx.getAccountInfoSync().miniProgram.envVersion
  },
  // 胶囊按钮的位置信息
  getMenuBoundingMsg() {
    let result = wx.getMenuButtonBoundingClientRect()
    if (result.top === 0 || result.height === 0) {
      const storageResult = wx.getStorageSync({
        key: "menuButtonBoundingClientRect"
      })
      if (storageResult) {
        result = JSON.parse(storageResult)
      }
    } else {
      wx.setStorage({
        key: "menuButtonBoundingClientRect",
        data: JSON.stringify(result)
      })
    }
    this.menuBoundingMsg = result
    return result
  },
  // 初始化工具
  initUtils() {
    // 初始化axios
    const _axios = axios(this)
    this.axios = _axios
    this.get = _axios.get.bind(_axios)
    this.post = _axios.post.bind(_axios)
    this.put = _axios.put.bind(_axios)
    this.del = _axios.del.bind(_axios)
  },
  // 登录态校验跳转
  loginJump() {
    if (this.globalData.userInfo.token) {
      this.startReportHeart()
      return true
    }

    wx.navigateTo({
      url: "/pages/login/index"
    })
  },
  getDynamicTab() {
    this.get(`/sys/common/app/page/list`).then(async res => {
      if (res) {
        this.globalData.indexDynamicTab = res
        const sn = res[0]?.sn
        const flowRes = await this.get(`/info/common/flow/release?relationType=platform&bizSn=${sn}`)
        if (flowRes) {
          this.globalData.indexInfoFlowSn = flowRes.sn
          wx.nextTick(() => {
            this.eventBus.emit('getIndexInfoFlowSn', flowRes.sn)
          })
        }
      }
    })
  },
  // 通过appId获取当前系统配置（无需登录）
  propertyInfo(){
    this.get('/sys/common/config/property/info').then(res=>{
      if(res){
        this.globalData.appConfig = res
      }
    })
  },
  // 取耗品go的支付定义sn
  async payDefSnData(){
    const res = await this.get('/pay/def')
    this.globalData.payDefSn =  res?.data
  },
  // 未登录优惠券礼包
  commonTicket(type){
    return this.get(`/mk/common/ticket/group/${type}`)
  },
  // 检查是否领取新人优惠券
  async checkNewCoupon(type = "register") {
    const res = await this.post(`/mk/ticket/instance/check/${type}`)
    if (res.exists && res.received != undefined && !res.received) {
      return this.getNewCoupon(type)
    }
    return false
  },
  // 领取新人优惠券
  async getNewCoupon(type) {
    const res = await this.post(`/mk/ticket/instance/group/${type}`)
    if (res && res.success) {
      return this.getNewCouponList(type)
    }
    return false
  },
  // 查询新人优惠券列表
  async getNewCouponList(type) {
    const res = await this.get(`/mk/ticket/instance/group/${type}`)
    return res
  },
  // 通过图片sn拉去图片地址
  picSnGetUrl(sn, ossStyle, isOss = false, needOrigin = false) {
    return new Promise(async (resolve, reject) => {
      if (!Array.isArray(sn)) {
        sn = [sn]
      }
      if (!sn.length) {
        resolve([])
        return
      }
      const api = isOss ? '/oss/common/list/oss/seqs' : '/oss/common/list/seqs'
      const res = await this.get(api, {
        seqs: sn.join(","),
        style: ossStyle ? `image/resize,m_fixed,w_${ossStyle.width},h_${ossStyle.height}` : undefined
      })
      let result;
      if (needOrigin) {
        result = res
      } else {
        result = sn.map(item => {
          return res[item] && res[item].url ? res[item].url : ""
        })
      }
      resolve(result)
    })
  },
  // 通过商铺sn拉取是否收藏
  shopSnGetCollect(sn) {
    if (this.globalData.userInfo.token) {
      return new Promise(async (resolve, reject) => {
        if (!Array.isArray(sn)) {
          sn = [sn]
        }
        const res = await this.get(`/md/inst/user/follow/valid/shop/${sn.join(",")}`)
        if (res) {
          const resMap = {}
          res.forEach(item => {
            resMap[item] = true
          })
          const result = sn.map(item => {
            return resMap[item] === true
          })
          resolve(result)
        }
        return resolve([])
      })
    }
  },
  // sn转(商品|店铺)详情+图片;
  // type: goods | shop
  snToShopOrGoodAndPic(sn, type = "goods") {
    return new Promise(async (resolve, reject) => {
      if (!Array.isArray(sn)) {
        sn = [sn]
      }
      if (sn.length === 0) {
        return resolve([])
      }
      let result
      if (type === "goods") {
        result = await this.get("/ec/common/goods/summary", {
          goodsSns: sn.join(",")
        })
      } else if (type === "shop") {
        result = await this.get("/ec/common/shop/summaries", {
          shopSns: sn.join(",")
        })
      }
      result = sn.map(item => {
        return result[item]
      })
      if (result && Array.isArray(result) && result.length > 0) {
        return resolve(result)
      } else {
        return resolve([])
      }
    })
  },
  // 格式化商品数据
  formatterGoods(list, ossStyle) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        const data = item.data || item
        return (data.coverImages && data.coverImages[0] && data.coverImages[0].ossId) || ""
      })
      //为了解决图片超过一百个 而请求失败
      if (bannerList.length > 100) {
        var imgList = []
        for (let a = 0;a <= bannerList.length-1; a++){
          if (a % 100 == 0) {
            var arr = [];
            imgList.push(arr);
          }
          arr.push(bannerList[a]);
        }
        let imgArr = []
        for(let i = 0; i <= imgList.length-1;i++){
          let lists = await this.picSnGetUrl(imgList[i], ossStyle)
          imgArr = imgArr.concat(lists)
        }
        bannerList = imgArr;
      } else {
        bannerList = await this.picSnGetUrl(bannerList, ossStyle)
      }
      bannerList = list.map((item, index) => {
        const data = item.data || item
        return {
          data,
          //
          id: data.id,
          // 行为
          actionType: "goods",
          // 唯一sn
          sn: data.sn,
          // 图片地址
          newImg: bannerList[index],
          // 优惠价
          discountPrice: formatterMoney(data.minPrice),
          // 原价
          price: formatterMoney(data.maxPrice),
          // 商品名称
          title: data.title,
          // 起批量
          min: data.minNum,
          // 浏览量
          count: data.browseCount,
          // 最后浏览时间Str
          browseDate: data.browseDate,
          // 最后浏览时间
          browseAt: data.browseAt,
          /*
           * 商品状态
           * draft: 草稿
           * audit: 待审核
           * rejected: 驳回
           * release: 已上架
           * off: 已下架
           * */
          state: data.state,
          shopName: data.shopName
        }
      })
      resolve(bannerList)
    })
  },
  // 拼团商品数据格式化
  groupGoods(list, ossStyle) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(data => {
        if (!data) {
          return []
        }
        return (data.coverImages && data.coverImages[0] && data.coverImages[0].ossId) || ""
      })
      let actorsList = []
      list.forEach(item => {
        actorsList.push(
          item?.actors?.map(p => {
            return p.headImgUrl
          })
        )
      })
      let allactorsList = []
      for (let i = 0; i < actorsList.length; i++) {
        let res = this.picSnGetUrl(actorsList[i] || [], ossStyle)
        allactorsList.push(res)
      }
      Promise.all(allactorsList).then(async res => {
        allactorsList = res
        bannerList = await this.picSnGetUrl(bannerList, ossStyle)
        bannerList = list.map((item, index) => {
          return {
            data: item?.data,
            // 图片
            newImg: bannerList[index],
            // 商品sn
            sn: item?.goodSn,
            // 商品名称
            goodName: item?.goodName,
            // 拼团定义sn
            composeDefSn: item?.composeDefSn,
            // 拼团价
            composePrice: item?.composePrice,
            // 拼团原价
            originalPrice: item?.originalPrice,
            // 成团目标数量
            targetNum: item?.targetNum,
            // 已拼件数
            composeNum: item?.composeNum,
            // 头像
            actors: allactorsList[index],
            // 行为
            actionType: "goods"
          }
        })
        resolve(bannerList)
      })
    })
  },
  // 格式化帮扶商品数据
  formatterAssistGoods(list) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        const data = item.data || item
        return (data.coverImages && data.coverImages[0] && data.coverImages[0].ossId) || ""
      })
      bannerList = await this.picSnGetUrl(bannerList)
      bannerList = list.map((item, index) => {
        const data = item.data || item
        return {
          //
          id: data.id,
          // 行为
          actionType: data.type,
          // 唯一sn
          sn: data.sn,
          // 图片地址
          newImg: bannerList[index],
          // 现在价
          discountPrice: data.price,
          // 原价
          price: data.skuPrice,
          //帮扶价格
          diffPrice: data.diffPrice,
          // 商品名称
          title: data.title
        }
      })
      resolve(bannerList)
    })
  },
  // 格式化商家
  formatterShops(list, ossStyle) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        const data = item.data || item.shop || item
        return data.coverImages && data.coverImages[0] && data.coverImages[0].ossId || ""
      })
      bannerList = await this.picSnGetUrl(bannerList, ossStyle)
      bannerList = list.map((item, index) => {
        const data = item.data || item
        return {
          data,
          // 图片地址
          newImg: bannerList[index],
          // 行为
          actionType: "shop",
          // 唯一sn
          sn: data.sn,
          // 商家名称
          title: data.name,
          // tab标签数组
          tabList: data.tags,
          // 主营业务
          business: data && data.mainBiz && data.mainBiz.content || "",
          state: data.state
        }
      })
      //
      if (this.globalData.userInfo.token && bannerList.length) {
        let collectList = bannerList.map(item => {
          return item.sn
        })
        collectList = await this.shopSnGetCollect(collectList)
        bannerList = bannerList.map((item, index) => {
          return {
            ...item,
            isCollect: collectList[index]
          }
        })
      }
      resolve(bannerList)
    })
  },
  // 格式化tabs
  formatterTabs(list, ossStyle) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        const data = item.data || item
        return (data.contentImageId && data.contentImageId[0]) || ""
      })
      bannerList = await this.picSnGetUrl(bannerList, ossStyle)
      bannerList = list.map((item, index) => {
        const data = item.data || item
        return {
          data,
          // 唯一sn
          sn: data.actionSn,
          // 图片地址
          newImg: bannerList[index],
          // tab名称
          title: data.title
        }
      })
      resolve(bannerList)
    })
  },
  // 格式化信息流第一层
  formatterContent(list) {
    return new Promise(async (resolve, reject) => {
      const result = []
      const PromiseList = []
      for (let i = 0; i < list.length; i++) {
        const item = list[i]
        // 处理轮播图
        if (item.type === "banner" && Array.isArray(item.items) && item.items.length > 0) {
          const p = this.formatterBanner(item.items, {
            width: 692,
            height: 306
          })
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              data: {
                type: "index",
                data,
                dataDesc: []
              }
            }
          })
        } else if (item.type === "goodsGroup" && Array.isArray(item.items) && item.items.length > 0) {
          // 经营必备
          const data = item.items.slice(0, 6)
          const p = this.formatterGoods(data, {
            width: 206,
            height: 192
          })
          PromiseList.push(p)
          p.then(items => {
            result[i] = {
              type: item.type,
              sn: item.sn,
              data: {
                typeName: "manage",
                showData: {
                  name: item.name,
                  description: item.description,
                  items
                }
              }
            }
          })
          // 采集拼单 goodsCompose
          // 采集拼团 peopleCompose
        } else if (item.type === "peopleCompose" && Array.isArray(item.items) && item.items.length > 0) {
          let list = item.items.map(p => {
            return p.actionSn
          })
          list = await this.get(`/ec/common/compose/instance/info?goodSns=${list.join()}`)
          if (list) {
            const p = this.groupGoods(list, {
              width: 194,
              height: 194
            })
            PromiseList.push(p)
            p.then(items => {
              result[i] = {
                type: item.type,
                sn: item.sn,
                data: {
                  typeName: "peopleCompose",
                  name: item.name,
                  description: item.description,
                  items
                }
              }
            })
          }
          // 广告
        } else if (item.type === "advert" && Array.isArray(item.items) && item.items.length > 0) {
          let p = this.formatterBanner(item.items)
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              data: data[0]
            }
          })
        } else if (item.type === "shopGroup" && Array.isArray(item.items) && item.items.length > 0) {
          // 甄选供应商
          const data = item.items.slice(0, 10)
          let p = this.formatterShops(data, {
            width: 140,
            height: 140
          })
          PromiseList.push(p)
          p.then(items => {
            result[i] = {
              type: item.type,
              sn: item.sn,
              data: {
                typeName: "provider",
                showData: {
                  name: item.name,
                  description: item.description,
                  items
                }
              }
            }
          })
        } else if (item.type === "shopHot" && Array.isArray(item.items) && item.items.length > 0) {
          // 热门商家
          const p = this.formatterShops(item.items, {
            width: 140,
            height: 140
          })
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              name: item.name,
              data
            }
          })
        } else if (item.type === "goodsHot" && Array.isArray(item.items) && item.items.length > 0) {
          // 热门商品
          const p = this.formatterGoods(item.items, {
            width: 344,
            height: 344
          })
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              name: item.name,
              data
            }
          })
        } else if (item.type === "goodsRecommend" && Array.isArray(item.items) && item.items.length > 0) {
          const p = this.formatterGoods(item.items, {
            width: 344,
            height: 344
          })
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              name: item.name,
              data
            }
          })
        } else if (item.type === "categoryGroup" && Array.isArray(item.items) && item.items.length > 0) {
          const p = this.formatterTabs(item.items, {
            width: 160,
            height: 160
          })
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              name: item.name,
              data
            }
          })
        } else if (item.type === "zqTheme" && Array.isArray(item.items) && item.items.length > 0) {
          const p = this.formatterZqTheme(item.items)
          PromiseList.push(p)
          p.then(data => {
            result[i] = {
              type: item.type,
              name: item.name,
              data
            }
          })
        }
      }
      Promise.all(PromiseList).then(data => {
        resolve(result)
      })
    })
  },
  // 格式化活动
  formatterZqTheme(list) {
    return new Promise(async (resolve) => {
      // 获取图片sn列表
      let bannerList = list.map(item => {
        const data = item.data
        return (data.coverImages && data.coverImages[0] && data.coverImages[0].ossId) || ""
      })
      // 批量换取图片
      bannerList = await this.picSnGetUrl(bannerList, {
        width: 278,
        height: 278
      })
      bannerList = list.map((item, index) => {
        const data = item.data
        return {
          // 行为
          actionType: item.actionType,
          // 唯一sn
          sn: item.actionSn,
          // 图片地址
          img: bannerList[index],
          // 价格
          price: data.minPrice,
          // 原价价格
          stepPrice: data.maxPrice,
          // 商品名称
          name: data.title,
          // 商品起批量
          minNum: data.minNum,
          // 耗品区用，是否只能购买一次(暂时不做置灰，默认1)
          status: 1
        }
      })
      resolve(bannerList)
    })
  },
  // 格式化售后商品
  formatterAfterGoods(list) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        return item.ossId
      })
      bannerList = await this.picSnGetUrl(bannerList)
      bannerList = list.map((item, index) => {
        const data = item.data || item
        let states = ""
        if (data.state == "complete" || data.state == "cancel") {
          states = `售后时间:  ${formatterTime(data.saledAt * 1000)}`
          // (? `售后时间:  ${formatterTime(data.saledAt*1000)}` : '') : (?  `售后时间:  ${formatterTime(data.saledAt*1000)}` : "")
        } else if (data.saledState == "complete") {
          states = `售后时间:  ${formatterTime(data.saledAt * 1000)}`
        }
        return {
          // skuid
          // goodsSkuId:data.goodsSkuId,
          // 是否选中当前sku
          checkedSku: data.checkedSku,
          // 图片地址
          goodsImage: bannerList[index],
          // 商品名称
          goodsName: data.goodsName,
          // 规格名称
          skuName: data.goodsSpecName || data.goodsSpecsName,
          // 当前sku状态
          skuStatus: data.skuStatus,
          // 当前sku购买的数量
          skuCount: data.quantity,
          // 当前sku购买的单价
          skuPrice: data.price,
          // 当前sku购买的总价
          skuSum: data.goodsAmount,
          // 退款时间
          times: states,
          //sn
          orderSn: data.sn
        }
      })
      resolve(bannerList)
    })
  },
  // 格式化轮播
  formatterBanner(list, ossStyle) {
    return new Promise(async (resolve, reject) => {
      let bannerList = list.map(item => {
        return item.data.contentImageId
      })
      bannerList = await this.picSnGetUrl(bannerList, ossStyle)
      bannerList = list.map((item, index) => {
        return {
          // 轮播图的数据
          data: item.data,
          // 图片地址
          newImg: bannerList[index],
          // 行为
          actionType: item.actionType,
          // 唯一sn
          sn: item.actionSn,
          // 跳转地址，后端数据结构变更，统一取 actionSn
          goUrl: item.actionSn // item.data.pageUrl
        }
      })
      resolve(bannerList)
    })
  },
  // 获取地址
  /**
   * @param {Object} query
   * {page:0,size:10}
   */
  getAddressList(query) {
    return new Promise((resolve, reject) => {
      this.get("/md/inst/user/address/list/current", query ? query : "").then(res => {
        // 设置默认地址
        if (res && res.content[0] && res.content[0].pitchOn) {
          this.globalData.userAddress = res.content[0]
        } else {
          this.globalData.userAddress = {}
        }
        resolve(res)
      })
    })
  },
  // 获取省市区
  getAreaList(defSn = "CHINA_001", index = "3") {
    this.get(`/md/area/def/item/tree/${defSn}/${index}`).then(res => {
      // 设置默认地址
      this.globalData.areaList = res
    })
  },
  // 根据areaSn获取省市区
  getArea(areaSn) {
    return this.get(`/md/area/def/item/${areaSn}`)
  },
  // 根据wx地址id获取areaSn
  getAreaSn(regionSn,index='3'){
    return this.get(`/md/area/def/item/location/${index}/${regionSn}`)
  },
  // 格式化省市区
  area(area, symbol = "") {
    let result = ""
    if (area?.province?.name) {
      result += area.province.name + symbol
    }
    if (area?.city?.name) {
      result += area.city.name + symbol
    }
    if (area?.area?.name) {
      result += area.area.name
    }
    return result
  },
  // 存scene参数
  saveScene(sceneData) {
    let value = JSON.stringify(sceneData).replace(/\"/g, "\\\"")
    return this.post(`/sys/params`, {
      value
    })
  },
  // 取scene参数
  getScene(sceneSn) {
    return this.get(`/sys/common/params/${sceneSn}`)
  },
  // 格式化消息列表消息
  formatMessageForService(list) {
    const result = list.filter(item => item.message).map(item => {
      const basic = {
        // 消息sn
        sn: item.dialogSn,
        // 名称
        name: item.groupName,
        // 群组sn
        groupSn: item.groupSn,
        // 消息类型
        messageType: item.message.messageType,
        // 消息体
        messageBody: {},
        // 消息状态
        status: item.status,
        // 是否有未读
        msgCount: item.msgCount,
        // 是否指定
        top: item.top,
        // 当前消息key
        messageKey: item.messageKey,
        // 发送时间格式化
        time: formatterTimeTim(item.lastMsgAt * 1000),
        // 搜索消息时间
        createdAt: formatterTimeTim(item.createdAt * 1000),
        // 头像avatar
        avatar: item.avatar,
        // 头像
        imgs: ''
      }

      switch (basic.messageType) {
        case 'TIMTextElem':
          // 文本消息
          return {
            ...basic,
            // 消息体
            messageBody: {
              text: item.message.messageBody.Text
            }
          }
          case 'TIMCustomElem':
            // 文本消息
            return {
              ...basic,
              // 消息体
              messageBody: {
                text: '[商品信息]'
              }
            }
            case 'TIMImageElem': {
              return {
                ...basic,
                // 消息体
                messageBody: {
                  text: '[图片]'
                }
              };
            }
            // 解析文件类型
            case 'TIMFileElem': {
              return {
                ...basic,
                // 消息体
                messageBody: {
                  text: '[文件]'
                }
              };
            }
            // 解析视频类型
            case 'TIMVideoFileElem': {
              return {
                ...basic,
                // 消息体
                messageBody: {
                  text: '[视频]'
                }
              };
            }
            default:
              return {};
      }
    })
    return new Promise(async (resolve) => {
      for (let i = 0; i < result.length; i++) {
        const item = result[i]
        let imgs = []

        // 批量调用获取图片
        imgs = await this.picSnGetUrl(item.avatar, {
          width: 186,
          height: 186
        })
        // 无头像的处理
        if(item.avatar == '') {
          imgs = 'https://resource.kmyun.cn/kmjs-wx-ec/Default_default_avatar.png'
        }
        item.imgs = imgs
      }
      resolve(result);
    })
  },

  // 未读消息接口
  messageFun() {
    if (this.globalData.userInfo.token) {
      this.get('/mk/csc/client/message/count?includeTypes=dialog', {},{},false).then((res) => {
        if(res) {
          let count = res.count > 99? '99+' : res.count
          if (res.count) {
            wx.setTabBarBadge({
              index: 3,
              text: `${count}`
            })
          } else {
            wx.removeTabBarBadge({
              index: 3
            })
          }
        }
      })
    }
  },
  isGlobalIphone: {
    isIphone: false, //判断机型
  }
})
