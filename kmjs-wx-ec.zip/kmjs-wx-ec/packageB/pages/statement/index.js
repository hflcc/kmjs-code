// pages/statement/index.js

import uCharts from '../../packUtils/u-charts'
const app = getApp()
let _self;
let canvaColumn = null;
let Column;
Page({
  /**
   * 页面的初始数据
   */
  data: {
     // 胶囊距离顶部
     capsuletop: app.menuBoundingMsg["top"],
     // 胶囊高度
     capsuleheight: app.menuBoundingMsg["height"] - 1,
     activeTab:'onMouth',
     state:{},
     chartType:[
      {
        label:'柱状图',
        value:'column'
      },
      {
        label:'折线图',
        value:'line'
      },
     ],
    //  图表类型
     activechartType:"column",
     timeTabs:[
       {
         label:'近一月',
         value:'onMouth'
       },
       {
        label:'近三月',
        value:'onThreeMouths'
      },
      {
        label:'近一年',
        value:'onAllOneYear'
      }
     ],
    cWidth: '',
    cHeight: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    setTimeout(() => {
      const result = app.getMenuBoundingMsg()
      this.setData({
        // 胶囊距离顶部
        capsuletop: result.top,
        // 胶囊高度
        capsuleheight: result.height - 1,
      })
    }, 1000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(app.loginJump()){
      _self=this;
      this.cWidth = wx.getSystemInfoSync().windowWidth;
      this.cHeight = 500 / 750 * wx.getSystemInfoSync().windowWidth;
      this.getData()
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  changetab({currentTarget}){
    let type = currentTarget.dataset.type
    this.setData({
      activeTab:type
    })
    this.getData()
  },
  async getData(){
    let res = await app.get(`/bi/inst/order/day/start/${this.data.activeTab}`)
    if(res?.summary?.overRatio){
      res.summary.overRatio = (res.summary.overRatio*100).toFixed(2)
    }
    this.setData({
      state:res
    })
    this.getServerData()
  },
  changeChartType({currentTarget}){
    let type = currentTarget.dataset.type
    this.setData({
      activechartType:type
    })
    this.getServerData()
  },
  back(){
    wx.navigateBack()
  },
  getServerData(){
    wx.showLoading({
      title: '加载中',
      mask:true,
    })
    setTimeout(()=>{
      wx.hideLoading()
    },1000)
    let detail = this.data.state.detail
    let categories=[];
    let series = [
      {
          "name": "采购金额",
          "data": [],
          "color":"#1890FF",
      },
        {
            "name": "省钱金额",
            "data": [],
            "color":"#91CB74"

        },
      {
        "name": "采购数量",
        "index":1,
        "data": [],
        "color":"#FAC858"
    },
  ]
    detail.forEach(item=>{
      categories.push(item.orderAt)
      series[0].data.push(item.payableAmount)
      series[1].data.push(item.preferentialAmount)
      series[2].data.push(item.goodsNum)
    })
    let Column = {
      categories,
      series
  }
    _self.showColumn("canvasColumn", Column);
  },
  showColumn(canvasId, chartData) {
    let ctx = wx.createCanvasContext(canvasId, this);
    canvaColumn = new uCharts({
      $this: _self,
      context: ctx,
      canvasId: canvasId,
      type: _self.data.activechartType,
      legend: true,
      fontSize: 11,
      background: '#FFFFFF',
      pixelRatio: 1,
      animation: true,
      categories: chartData.categories,
      series: chartData.series,
      dataLabel: false,
      padding: [20,15,20,15],
      xAxis: {
        disableGrid: true,
        axisLine:false,
      },
      yAxis: {
        "gridColor":"#eeeeee",
        "data": [
          {
              "position": "left",
              "title": "(元)",
              "textAlign": "left",
              "tofix": 2,
              "min":0,
              "axisLineColor":"transparent"
          },
          {
            "position": "right",
            "title": "(件)",
            "min":0,
            "axisLineColor":"transparent"
        },
      ]
      },
      width: _self.cWidth ,
      height: _self.cHeight ,
      extra: {
        column: {
          type: 'group',
          width: _self.cWidth * 0.2 / chartData.categories.length
        },
        tooltip: {
        }
      }
    });

  },
  touchColumn(e) {
    canvaColumn.showToolTip(e, {
      formatter: function (item) {
          if(item.name==="采购数量"){
            return item.name + ':' + item.data + "件"
          }
          return item.name + ':' + item.data + "元"
      }
    });
  },
})
