const app = getApp()
import TIM from 'tim-wx-sdk';
const { formatterTimeTim } = require('../../packUtils/formatter')
// const tim=getApp().globalData.tim
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sn: '', // 传过来的sn
    isReady: false, // 是否准备好
    tim: null,
    inputValue: '', // 输入框的内容
    dialogSn: '', // 对话框sn
    chatingList: [], // 聊天记录
    memberMap: {}, // 成员信息
    accountSn: '', // 当前用户sn
    isLastChat: false, // 是否还有聊天记录
    scrollTop: 0,
    toView: '',
    isToView: '',
    loading: false,
    emojiShow: false, // 表情弹窗
    fileShow: false, // 文件弹窗
    goodShow: false, // 商品信息
    videoShow: false, // 视频弹窗
    emoji: '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 😘 😗 😙 😚 😋 😛 😝 😜 🤓 😎 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 😢 😭 😤 😠 😡 😳 😱 😨 🤗 🤔 😶 😑 😬 🙄 😯 😴 😷 🤑 😈 🤡 💩 👻 💀 👀 👣 👐 🙌 👏 🤝 👍 👎 👊 ✊ 🤛 🤜 🤞 ✌️ 🤘 👌 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤙 💪 🖕 ✍️ 🙏'.split(/\s/),
    shopInfo: null, // 商品信息
    orderInfo: null, // 订单信息
    inputCursor: 0, // 输入框光标位置
    messageHeight: 'height:calc(100vh - 105rpx)', // 消息面板高度
    autoplay: false, // 是否自动播放视频
    videos: {
      url: '',
      myVideo: ''
    },
    keyboardHeight: 0,
    groupSn: '', // 腾讯那边的群组sn
    isIphone: false, // 是否为iphone
    iskeyboard: true, // 点击页面的时候不收起键盘
    isFocus: false // 失去焦点
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.shopInfo) {
      this.setData({
        shopInfo: JSON.parse(decodeURIComponent(options.shopInfo)),
        goodShow: true
      })
      this.initImage(this.data.shopInfo.image)
    } else if (options.orderInfo) {
      this.setData({
        orderInfo: JSON.parse(decodeURIComponent(options.orderInfo)),
        goodShow: true
      })
      this.initImage(this.data.orderInfo.image)
    }
    if (options.title) {
      wx.setNavigationBarTitle({
        title: options.title
      })
    }

    if (options.dialogSn) {
      this.setData({
        dialogSn: options.dialogSn,
        isReady: true
      })
      this.initSdk()
      // 获取成员列表
      this.getMemberList()
    }
    if (options.toView) {
      this.setData({
        isToView: options.toView
      })
    }
    this.setData({
      sn: options.sn || '',
      isIphone: app.isGlobalIphone.isIphone
    })
  },
  onReady() {
    setTimeout(() => {
      this.updateMessageHeight(false)
    }, 300)
  },
  onShow() {
    // sn 参数对应店铺的sn，没有sn则是平台客服
    if (!this.data.dialogSn) {
      this.getDialog()
    } else {
      // 获取平台名字
      this.getNavTitle(this.data.dialogSn)
    }
    this.setData({
      keyboardHeight: 0,
      emojiShow: false,
      fileShow: false
    })
    if (this.data.chatingList.length > 0) {
      this.updateMessageHeight(true)
    }
  },

  // 订单商品的图片
  initImage(seq) {
    app.picSnGetUrl(seq, {
      width: 80,
      height: 80
    }).then(res => {
      if (this.data.shopInfo) {
        this.setData({
          'shopInfo.tempImg': res[0]
        })
      } else if (this.data.orderInfo) {
        this.setData({
          'orderInfo.tempImg': res[0]
        })
      }
    })
  },
  // 初始化TIM的信息
  initSdk() {
    const tim = getApp().globalData.tim
    app.get(`/im/account/current`,{},{},false).then(res => {
      tim.login({
        userID: res.accountSn,
        userSig: res.accountSign
      })
      this.setData({
        accountSn: res.accountSn
      })
    })
    // 消息撤回回调
    tim.on(TIM.EVENT.MESSAGE_REVOKED, this.onMessageRevoked)
    // 消息接收回调
    tim.on(TIM.EVENT.MESSAGE_RECEIVED, this.onMessageReceived);

    tim.on(TIM.EVENT.KICKED_OUT, this.onMessageOut)
    this.setData({
      tim
    })
  },
  onUnload() {
    const tim = getApp().globalData.tim
    tim.off(TIM.EVENT.MESSAGE_REVOKED, this.onMessageRevoked)
    tim.off(TIM.EVENT.MESSAGE_RECEIVED, this.onMessageReceived)
    tim.off(TIM.EVENT.KICKED_OUT, this.onMessageOut)
    tim.logout().then()
  },
  // 消息撤回
  onMessageRevoked(event) {
    const that = this
    if (event.data[0].to !== this.data.groupSn) {
      return
    }
    // console.info(event,'撤回消息')
    const msgKey = event.data.map(item =>
      item.sequence + ''
    )
    const chatingList = that.data.chatingList
    chatingList.forEach(item => {
      if (msgKey.includes(item.messageKey)) {
        item.isRevoked = true
      }
    })
    that.setData({
      chatingList
    })
  },
  // 消息删除
  onMessageDelete(event) {
    const that = this
    const chatingList = that.data.chatingList
    chatingList.forEach(item => {
      if (event.includes(item.messageKey)) {
        item.isDelete = true
      }
    })
    that.setData({
      chatingList
    })
  },
  // 被踢下线了
  onMessageOut(event) {
    wx.showToast({
      title: '被踢下线了，请重新进入',
      icon: 'none'
    })
    this.setData({
      isReady: false
    })
  },
  // 接收消息
  async onMessageReceived(event) {
    const that = this
    // 收到推送的单聊、群聊、群提示、群系统通知的新消息，可通过遍历 event.data 获取消息列表数据并渲染到页面
    // event.name - TIM.EVENT.MESSAGE_RECEIVED
    // event.data - 存储 Message 对象的数组 - [Message]
    // 如果是自定义类型
    console.log('收到的消息', event.data)
    if (event.data.length === 0) {
      return
    }
    const item = event.data[0]
    if (item.to !== this.data.groupSn) {
      return
    }
    if (item.conversationType === TIM.TYPES.CONV_GROUP &&
      item.type === TIM.TYPES.MSG_GRP_TIP) {
      // 群提示消息
      return
    }

    if (item.type === TIM.TYPES.MSG_CUSTOM) {
      // 未知类型
      if (!event.data[0].payload.description) {
        return
      }
      const body = event.data[0].payload
      // 已读消息
      if (body.description === 'READ') {
        const d = JSON.parse(body.data)
        if (d.type === 'attendor') {
          const chatingList = that.data.chatingList
          // 所有消息设置为已读
          chatingList.forEach(item => {
            // 消息设置为已读
            item.isPeerRead = true
          })
          that.setData({
            chatingList
          })
        }
        return
      }
      // 切换客服
      if (body.description === 'SWITCH') {
        console.info('切换客服了')
        if (that.data.dialogSn) {
          // 如果有新的客服进来，需要重新调用成员列表
          await that.getMemberList(false)
        }
        // return;
      }
      // 会话结束
      if (body.description === 'FINISH') {
        console.info('会话结束了')
        return;
      }
    }
    // 收到的消息，直接通知后台，消息已读
    if (item.flow === 'in') {
      that.setMessageRead()
    }
    that.formatMessageForTim(event.data).then(res => {
      // console.info( '哈哈哈')
      const chatingList = that.data.chatingList
      chatingList.push(...res)
      that.setData({
        chatingList,
        toView: 'ID-' + chatingList[chatingList.length - 1].messageKey
      })
    })
  },
  // 获取聊天的信息
  getDialog() {
    const sn = this.data.sn
    // 有sn时  指代商家sn。没有则是平台客服
    const data = sn ? {
      "scopeType": "shop",
      "scopeValue": sn,
      "from": "minapp",
      "source": "耗品GO"
    } : {
      "scopeType": "app",
      "scopeValue": '99599E0DCED4_2',
      "from": "minapp",
      "source": "耗品GO"
    }
    app.post('/mk/csc/client', data).then(res => {
      if (res) {
        this.setData({
          dialogSn: res.sn
        })
        // if (!sn) {
        // 获取平台名字
        this.getNavTitle(res.sn, !sn)
        // }
        this.initSdk()
        // 获取成员列表
        this.getMemberList()

        this.setData({
          isReady: true
        })
      }
    })
  },
  // 获取平台客服名称
  getNavTitle(dialogSn, isApp) {
    app.get(`/mk/csc/client/info/${dialogSn}`, {}, {}, false).then(r => {
      if (isApp) {
        wx.setNavigationBarTitle({
          title: r.groupName
        })
      }
      this.setData({
        groupSn: r.groupSn
      })
    })
  },
  // 获取之前的聊天记录
  getChatingList(lastMessageSn = '') {
    this.setData({
      loading: true
    })
    const dialogSn = this.data.dialogSn
    app.get(`/mk/csc/instance/dialog/message/${dialogSn}?page=0&size=30&lastMessageSn=${lastMessageSn}`, {}, {}, false).then(res => {
      let list = res.content
        .filter(item => {
          if (item.messageType !== 'TIMCustomElem') {
            return true;
          }
          // eslint-disable-next-line no-undef
          const body = item.messageBody;
          return body.Desc === 'ORDER' || body.Desc === 'SHOP' || body.Desc === 'SWITCH';
        })
        .reverse()

      // 第一页，且最新一条消息，是未读 且不是自己发的
      if (!lastMessageSn && list.length > 0 &&
        list[list.length - 1].from !== this.data.accountSn) {
        // 清理一下未读消息
        this.setMessageRead()
      }

      this.setData({
        isLastChat: res.last
      })
      this.formatMessageForService(list).then(res => {
        if (res) {
          let chatingList = res
          // 加载上一页；聊天记录
          if (res.length === 0) {
            this.setData({
              isLastChat: true,
              loading: false
            })
            return
          }
          let toViewId = ''
          if (this.data.isToView) {
            toViewId = this.data.isToView
          } else {
            toViewId = 'ID-' + res[res.length - 1].messageKey
          }
          if (lastMessageSn) {
            toViewId = 'ID-' + this.data.chatingList[0].messageKey
            chatingList = res.concat(this.data.chatingList)
          }

          this.setData({
            chatingList,
            loading: false
          })
          // 有视频的情况下，加载慢一些，会导致 不到最底部
          //
          this.setData({
            toView: toViewId
          })
          console.info('跳转底部')
          if (!lastMessageSn) {
            setTimeout(() => {
              this.updateMessageHeight(false)
              console.info('跳转底部2')
            }, 200)
          }
        }
      })
    }).catch(e => {
      this.setData({
        loading: false
      })
    })
  },
  // 获取群成员列表
  async getMemberList(init = true) {
    const dialogSn = this.data.dialogSn
    const memberRes = await app.get(`/mk/csc/instance/dialog/member/${dialogSn}`,{},{},false)
    if (memberRes) {
      const memberMap = {}
      const seqs = []
      memberRes.forEach(item => {
        seqs.push(item.avatar)
      })
      const imgs = await app.picSnGetUrl(seqs, {
        width: 50,
        height: 50
      })
      memberRes.forEach((item, index) => {
        item.avatar = imgs[index].replace(/Expires=[^&]*&?/g, '')
        memberMap[item.accountSn] = item;
        console.info('成员：', item.nickname)
      })

      this.setData({
        memberMap
      })
      if (init) {
        // 获取聊天记录
        this.getChatingList()
      }
    }
  },
  // 发送消息
  bindKeyInput(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  bindBlurInput(e) {
    console.log(e,'失去了焦点')
    this.setData({
      inputCursor: e.detail.cursor,
      keyboardHeight: 0
    })
    this.updateMessageHeight()
  },
  onKeyInput() {
    this.setData({
      emojiShow: false
    })
    this.sendTextMessage()
  },
  send(data) {
    if (!this.data.isReady) {
      return
    }
    const dialogSn = this.data.dialogSn
    app.post(`/mk/csc/instance/dialog/send/${dialogSn}`, data).then()
  },

  // 发送文本消息
  sendTextMessage() {
    const text = this.data.inputValue
    this.setData({
      inputValue: '',
      inputCursor: 0
    })
    this.send({
      messageType: 'TIMTextElem',
      messageBody: {
        Text: text.trim()
      }
    })
  },
  // 拍照
  sendCameraMessage() {
    const that = this;
    this.updateMessageHeight(true);
    wx.chooseImage({
      count: 1,
      sizeType: 'compressed',
      sourceType: ['camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths[0];
        that.uploadFile(tempFilePaths).then(res => {
          that.send(that.createImageMessage(res))
        }).catch(e => {
          wx.showToast({
            title: e,
            icon: 'none'
          })
        })
      }
    })
  },
  // 发送图片
  sendImageMessage() {
    const that = this;
    this.updateMessageHeight(true);
    wx.chooseImage({
      count: 1,
      sizeType: 'compressed',
      sourceType: ['album'],
      success(res) {
        const tempFilePaths = res.tempFilePaths[0];
        that.uploadFile(tempFilePaths).then(res => {
          that.send(that.createImageMessage(res))
        }).catch(e => {
          wx.showToast({
            title: e,
            icon: 'none'
          })
        })
      }
    })
  },
  // 图片消息
  createImageMessage(seq) {
    return {
      messageType: 'TIMImageElem',
      messageBody: {
        UUID: new Date().getTime() + '',
        ImageFormat: 255,
        ImageInfoArray: [{
          Type: 1,
          Size: 0,
          Width: 0,
          Height: 0,
          URL: seq
        }]
      }
    }
  },
  // 发送文件
  sendFileMessage() {
    const that = this;
    this.updateMessageHeight(true);
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFiles[0]
        that.uploadFile(tempFilePaths.path).then(res => {
          that.send(that.createFileMessage({
            seq: res,
            size: tempFilePaths.size,
            name: tempFilePaths.name
          }))
        }).catch(e => {
          wx.showToast({
            title: e,
            icon: 'none'
          })
        })
      },
      fail(res) {
        console.info(res)
      }
    })
  },
  // 文件消息
  createFileMessage(file) {
    return {
      messageType: 'TIMFileElem',
      messageBody: {
        Url: file.seq,
        FileSize: file.size,
        FileName: file.name
      }
    }
  },
  // 发送视频
  sendVideoMessage() {
    const that = this
    // 小程序端发送视频消息示例：
    // 1. 调用小程序接口选择视频，接口详情请查阅 https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseVideo.html
    wx.chooseMedia({
      mediaType: ['video'],
      count: 1,
      sourceType: ['album', 'camera'], // 来源相册或者拍摄
      maxDuration: 20, // 设置最长时间60s
      camera: 'back', // 后置摄像头
      success(res) {
        const temp = res.tempFiles[0]
        let p = [that.uploadFile(temp.tempFilePath), that.uploadFile(temp.thumbTempFilePath)]
        Promise.all(p).then(r => {
          console.log(r)
          that.send(that.createVideoMessage({
            ...res,
            url: r[0],
            thumbUrl: r[1]
          }))
        }).catch(e => {
          console.info(e)
          // wx.showToast({
          //   title: e,
          //   icon: 'none'
          // })
        })
      }
    })
  },
  createVideoMessage(source) {
    return {
      "messageType": "TIMVideoFileElem",
      "messageBody": {
        "VideoUrl": source.url,
        "VideoUUID": new Date().getTime() + '',
        "VideoSize": source.size,
        "VideoSecond": source.duration,
        "VideoFormat": "mp4",
        "VideoDownloadFlag": 2,
        "ThumbUrl": source.thumbUrl,
        "ThumbUUID": new Date().getTime() + '1',
        "ThumbSize": 0,
        "ThumbWidth": 0,
        "ThumbHeight": 0,
        "ThumbFormat": "",
        "ThumbDownloadFlag": ''
      }
    }
  },
  playVideos(event) {
    console.log(event, 'event');
    const url = event.currentTarget.dataset.key
    const videos = this.data.videos
    videos.url = url
    this.setData({
      videos,
      videoShow: true,
      autoplay: true,
    });
  },
  // 监听视频播放
  bindplay(e) {
    console.log(e, );
  },
  // 关闭视频播放弹窗
  closePopup() {
    const videos = this.data.videos
    // videos.pause()
    this.setData({
      videoShow: false,
      videos
    });
  },
  // 发送商品信息
  sendShopMessage() {
    // const data = {
    //   sn: '12341564564564',
    //   // 商品名称
    //   name: '商品名称',
    //   // 图片
    //   image: "1d7dde3c52454437926ffc403c7f7949",
    //   // 单价,范围价格
    //   price: ['￥0.01','￥0.01','￥0.01','￥0.01']
    // }
    this.setData({
      goodShow: false
    })
    const data = this.data.shopInfo
    this.send(this.createCustomMessage('SHOP', data))
  },
  // 发送订单信息
  sendOrderMessage() {
    this.setData({
      goodShow: false
    })
    // const data = {
    //   "sn": "831efbd1e70848039abcb02cac607e51",
    //   "name": "欧蝶兰香奈丝宝香水洗衣液2KG*2瓶+2KG*2袋",
    //   "image": "8b75cc37ce8949c0b37afdbdc1d9af3d",
    //   "price": "0.05",
    //   "orderSn": "HD20211025142024175030",
    //   "orderDate": "2021-10-25 14:20:24",
    //   "quantityGoods": 5,
    //   "typeOfMerchandize": 2
    // }
    const data = this.data.orderInfo
    this.send(this.createCustomMessage('ORDER', data))
  },
  // 自定义消息
  createCustomMessage(type, data) {
    return {
      messageType: 'TIMCustomElem',
      messageBody: {
        Data: JSON.stringify(data),
        Desc: type
      }
    }
  },
  // 格式化消息--腾讯推送过来的
  async formatMessageForTim(list) {
    const member = this.data.memberMap

    const seqList = []
    const result = list.map(item => {
      const basic = {
        // 消息sn
        sn: item.ID,
        // 消息的流向;in 为收到的消息,out 为发出的消息
        flow: item.flow,
        // 消息类型
        messageType: item.type,
        // 消息体
        messageBody: {},
        // 消息发送者
        from: member[item.from],
        // 消息状态
        status: item.status,
        // 是否撤回
        isRevoked: item.isRevoked,
        // 是否删除
        isDelete: item.isDelete,
        // 是否已读
        isPeerRead: item.isPeerRead,
        // 发送时间
        time: item.time * 1000,
        timeStr: formatterTimeTim(item.time * 1000),
        messageKey: item.sequence + ''
      };
      // 格式化后消息的基础配置
      // 处理消息
      switch (item.type) {
        // 解析文本消息
        case TIM.TYPES.MSG_TEXT: {
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 发送的文字
              text: item.payload.text || '',
              // @的人员
              atUserList: item.atUserList
            }
          }
        }
        // 解析自定义类型
        case TIM.TYPES.MSG_CUSTOM: {
          // 切换消息
          if (item.payload.description === 'SWITCH') {
            // console.info(member)
            // console.info(this.data.memberMap)
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 自定义消息内容
                data: member[item.payload.data],
                // 自定义消息类型
                desc: item.payload.description
              }
            }
          } else if (item.payload.description === 'ORDER' || item.payload.description === 'SHOP') {
            const data = JSON.parse(item.payload.data)
            if (data.image) {
              seqList.push(data.image);
            }
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 自定义消息内容
                data,
                // 自定义消息类型
                desc: item.payload.description
              }
            }
          }
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 自定义消息内容
              data: item.payload.data,
              // 自定义消息类型
              desc: item.payload.description
            }
          }
        }
        // 解析图片类型
        case TIM.TYPES.MSG_IMAGE: {
          const seq = item.payload.imageInfoArray[0].url || '';
          // 批量处理图片
          if (seq) {
            seqList.push(seq);
          }
          // 解析自定义类型
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 图片地址
              url: seq
            }
          }
        }
        // 解析文件类型
        case TIM.TYPES.MSG_FILE: {
          const seq = item.payload || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.fileUrl);
          }
          let index = seq.fileName.indexOf('.') + 1;
          let format = seq.fileName.substring(index);
          // 解析自定义类型
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 文件地址
              fileName: seq.fileName,
              // 文件地址
              fileUrl: seq.fileUrl,
              // 文件大小
              fileSize: this.renderSize(seq.fileSize),
              fileFormat: format
            }
          }
        }
        // 解析文件类型
        case TIM.TYPES.MSG_VIDEO: {
          const seq = item.payload || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.videoUrl);
            seqList.push(seq.thumbUrl);
          }
          // 解析自定义类型
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 视频长度
              videoSecond: seq.videoSecond,
              // 视频大小
              videoSize: seq.videoSize,
              // 视频路径
              videoUrl: seq.videoUrl,
              thumbUrl: seq.thumbUrl
            }
          }
        }
        default:
          console.log('无法处理数据');
      }
    })
    return new Promise((resolve) => {
      // 批量获取文件|图片
      if (seqList.length === 0) {
        // console.info(result)
        return resolve(result);
      }
      app.picSnGetUrl(seqList, null, true).then(imgs => {
        result.forEach(item => {
          if (item.messageType === TIM.TYPES.MSG_IMAGE) {
            item.messageBody.url = this.formatUrl(imgs[seqList.indexOf(item.messageBody.url)]);
          } else if (item.messageType === TIM.TYPES.MSG_VIDEO) {
            item.messageBody.videoUrl = this.formatUrl(imgs[seqList.indexOf(item.messageBody.videoUrl)]);
            item.messageBody.thumbUrl = this.formatUrl(imgs[seqList.indexOf(item.messageBody.thumbUrl)]);
          } else if (item.messageType === TIM.TYPES.MSG_FILE) {
            item.messageBody.fileUrl = this.formatUrl(imgs[seqList.indexOf(item.messageBody.fileUrl)]);
          } else if (item.messageType === TIM.TYPES.MSG_CUSTOM && (item.messageBody.desc === 'ORDER' || item.messageBody.desc === 'SHOP')) {
            item.messageBody.data.tempImg = this.formatUrl(imgs[seqList.indexOf(item.messageBody.data.image)]);
          }
        })
        resolve(result);
      })
    })
  },
  // 格式化消息--后台聊天记录
  async formatMessageForService(list) {
    const member = this.data.memberMap
    const seqList = []
    const result = list.map(item => {
      const basic = {
        // 消息sn
        sn: item.sn,
        // 消息的流向;in 为收到的消息,out 为发出的消息
        flow: item.from === this.data.accountSn ? 'out' : 'in',
        // 消息类型
        messageType: item.messageType,
        // 消息体
        messageBody: {},
        // 消息发送者
        from: member[item.from],
        // 消息状态
        status: item.status,
        // 是否撤回
        isRevoked: item.revoked,
        // 是否删除
        isDelete: item.isDelete,
        // 是否已读
        isPeerRead: item.peerRead,
        // 发送时间
        time: item.createdAt * 1000,
        // 发送时间格式化
        timeStr: formatterTimeTim(item.createdAt * 1000),
        // 消息key，用于撤回
        messageKey: item.messageKey
      }
      switch (item.messageType) {
        case TIM.TYPES.MSG_TEXT:
          // 文本消息
          return {
            ...basic,
            // 消息体
            messageBody: {
              text: item.messageBody.Text
            }
          };
        case TIM.TYPES.MSG_CUSTOM:
          // 解析自定义类型
          // 切换消息
          if (item.messageBody.Desc === 'SWITCH') {
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 自定义消息内容
                data: member[item.messageBody.Data],
                // 自定义消息类型
                desc: item.messageBody.Desc
              }
            }
          } else if (item.messageBody.Desc === 'ORDER' || item.messageBody.Desc === 'SHOP') {
            const data = JSON.parse(item.messageBody.Data)
            if (data.image) {
              seqList.push(data.image);
            }
            // 订单
            return {
              // 基础信息
              ...basic,
              messageBody: {
                // 自定义消息内容
                data,
                // 自定义消息类型
                desc: item.messageBody.Desc
              }
            }
          }
          return {
            ...basic,
            // 消息体
            messageBody: {
              // 自定义消息内容
              data: item.messageBody.Data,
              // 自定义消息类型
              desc: item.messageBody.Desc
            }
          };
        case TIM.TYPES.MSG_IMAGE: {
          // 解析图片类型
          const seq = item.messageBody.ImageInfoArray[0]?.URL || '';
          // 批量处理图片
          if (seq) {
            seqList.push(seq);
          }
          return {
            ...basic,
            // 消息体
            messageBody: {
              // 图片地址
              url: seq
            }
          };
        }
        // 解析文件类型
        case TIM.TYPES.MSG_FILE: {
          const seq = item?.messageBody || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.Url);
          }
          let index = seq.FileName.indexOf('.') + 1;
          let format = seq.FileName.substring(index);
          // 解析自定义类型
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 文件地址
              fileName: seq.FileName,
              // 文件地址
              fileUrl: seq.Url,
              // 文件大小
              fileSize: this.renderSize(seq.FileSize),
              // 文件格式
              fileFormat: format
            }
          };
        }
        // 解析视频类型
        case TIM.TYPES.MSG_VIDEO: {
          const seq = item?.messageBody || {};
          // 批量处理文件
          if (seq) {
            seqList.push(seq.VideoUrl);
            seqList.push(seq.ThumbUrl);
          }
          // 解析自定义类型
          return {
            // 基础信息
            ...basic,
            messageBody: {
              // 视频长度
              videoSecond: seq.VideoSecond,
              // 视频大小
              videoSize: seq.VideoSize,
              // 视频路径
              videoUrl: seq.VideoUrl,
              thumbUrl: seq.ThumbUrl,
            }
          };
        }
        default:
          return {};
      }
    })
    return new Promise((resolve) => {
      // 批量获取文件|图片
      if (seqList.length === 0) {
        // console.info(result)
        return resolve(result);
      }
      app.picSnGetUrl(seqList, null, true).then(imgs => {
        result.forEach(item => {
          // if (item.messageType === TIM.TYPES.MSG_IMAGE || item.messageType === TIM.TYPES.MSG_FILE) {
          if (item.messageType === TIM.TYPES.MSG_IMAGE) {
            item.messageBody.url = imgs[seqList.indexOf(item.messageBody.url)];
          } else if (item.messageType === TIM.TYPES.MSG_VIDEO) {
            item.messageBody.videoUrl = this.formatUrl(imgs[seqList.indexOf(item.messageBody.videoUrl)]);
            item.messageBody.thumbUrl = imgs[seqList.indexOf(item.messageBody.thumbUrl)];
          } else if (item.messageType === TIM.TYPES.MSG_FILE) {
            item.messageBody.fileUrl = this.formatUrl(imgs[seqList.indexOf(item.messageBody.fileUrl)]);
          } else if (item.messageType === TIM.TYPES.MSG_CUSTOM && (item.messageBody.desc === 'ORDER' || item.messageBody.desc === 'SHOP')) {
            item.messageBody.data.tempImg = this.formatUrl(imgs[seqList.indexOf(item.messageBody.data.image)]);
          }
          // }
        })
        resolve(result);
      })
    })
  },
  formatUrl(url) {
    if (url.indexOf('?') !== -1) {
      return url.replace(/([?#])[^'"]*/, '');
    }
    return url
  },
  getBaseUrl() {
    const env = wx.getAccountInfoSync().miniProgram.envVersion
    if (env === "develop") {
      // return "http://172.16.31.68:18888"
      return "https://api-dev.kmyun.cn"
    } else if (env === "trial") {
      return "https://api-dev.kmyun.cn"
    }
    return "https://api.kmyun.cn"
  },
  // 上传图片
  uploadFile(tempFilePaths) {
    const that = this
    return new Promise((resolve, reject) => {
      //上传图片
      wx.uploadFile({
        url: that.getBaseUrl() + '/oss/upload/file',
        filePath: tempFilePaths,
        name: 'file',
        header: {
          Authorization: `Bearer ${app.globalData.userInfo.token}`,
          'content-type': 'multipart/form-data'
        },
        //额外的参数formData
        formData: {
          'dirName': 'kmjs'
        },
        success: function (res) {
          //上传成功
          const {
            seq
          } = JSON.parse(res.data || '{}')
          if (seq) {
            resolve(seq)
          } else {
            reject(new Error('获取seq失败'))
          }
        },
        fail: function (err) {
          reject(new Error(err))
        },
      })
    })
  },
  // 设置消息已读
  setMessageRead() {
    const dialogSn = this.data.dialogSn
    if (!dialogSn) {
      return
    }
    // 设置消息已读，通知后台
    app.put(`/mk/csc/instance/dialog/clear/${dialogSn}`, {}, {}, false).then()
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onMoreMsg() {
    if (this.data.loading) {
      return
    }
    const chatingList = this.data.chatingList
    if (chatingList.length > 0 && !this.data.isLastChat) {
      this.getChatingList(chatingList[0].sn)
    }
  },

  /**
   * 表情弹出框
   */
  onExpression() {
    if (!this.data.isReady) {
      return
    }
    this.setData({
      emojiShow: !this.data.emojiShow,
      fileShow: false,
      keyboardHeight: 0
    })
    this.updateMessageHeight(true)
  },
  // 选择表情
  onEmo(e) {
    console.info('表情', this.data.inputCursor)
    const {
      key
    } = e.currentTarget.dataset;
    const {
      inputValue
    } = this.data;
    const cursor = this.data.inputCursor
    const result = inputValue.slice(0, cursor) + key + inputValue.slice(cursor)
    // 表情是两个字符长度
    this.setData({
      inputValue: result,
      inputCursor: cursor + 2
    })
  },
  // 文件
  onFile() {
    if (!this.data.isReady) {
      return
    }
    this.setData({
      fileShow: !this.data.fileShow,
      emojiShow: false
    })
    this.updateMessageHeight(true)
  },
  // 关闭弹窗
  onClose() {
    if (this.data.emojiShow || this.data.fileShow) {
      this.setData({
        emojiShow: false,
        fileShow: false
      })
      this.updateMessageHeight(false)
    } else if (this.data.keyboardHeight){
      this.setData({
        keyboardHeight: 0,
        isFocus: false,
        inputCursor: 0
      })
      wx:hideKeyboard()
      this.updateMessageHeight(true)
    }
  },
  // 关闭商品信息
  closePoster() {
    this.setData({
      shopInfo: null,
      orderInfo: null,
      goodShow: false
    })
  },
  // 消息撤回、删除
  MessageDispose(e) {
    console.log(e);
    const item = e.currentTarget.dataset.msgKey
    const that = this
    const menu = ['删除']
    if (item.flow === 'out') {
      menu.unshift('撤回')
    }
    if (item.messageType === TIM.TYPES.MSG_TEXT) {
      menu.unshift('复制')
    }

    wx.showActionSheet({
      itemList: menu,
      success(res) {
        const msgKey = item.messageKey
        const dialogSn = that.data.dialogSn
        switch (menu[res.tapIndex]) {
          case '删除':
            app.post(`/mk/csc/instance/dialog/message/delete/${dialogSn}/${msgKey}`).then(res => {
              that.onMessageDelete(msgKey)
              wx.showToast({
                title: '删除成功',
                icon: 'none',
                duration: 2000
              })
            })
            break
          case '撤回':
            const time = item.time
            if (new Date().getTime() - time > 3 * 60 * 1000) {
              wx.showToast({
                title: '消息已超过三分钟，不能撤回',
                icon: 'none'
              })
              return
            }
            app.post(`/mk/csc/instance/dialog/message/recall/${dialogSn}/${msgKey}`).then(res => {
              if (res.success) {
                const chatingList = that.data.chatingList
                chatingList.forEach(item => {
                  if (msgKey === item.messageKey) {
                    item.isRevoked = true
                  }
                })
                that.setData({
                  chatingList
                })
              }
            })
            break
          case '复制':
            wx.setClipboardData({
              data: item.messageBody.text,
              success: function (res) {
                wx.getClipboardData({
                  success: function (res) {
                    wx.showToast({
                      title: '复制成功'
                    })
                  }
                })
              }
            })
            break
          default:
            break
        }
      }
    })

  },
  // 更新面板高度
  updateMessageHeight(isToBottom) {
    //创建节点选择器
    var query = wx.createSelectorQuery();
    //选择id
    query.select('#footer').boundingClientRect()
    query.exec((res) => {
      //res就是 所有标签为mjltest的元素的信息 的数组
      //取高度
      let height = `height:calc(100vh - ${res[0].height}px)`
      if (this.data.keyboardHeight > 0) {
        height = `height:calc(100vh - ${res[0].height}px - ${this.data.keyboardHeight}px)`
      }
      this.setData({
        messageHeight: height
      })
      
      if (isToBottom) {
        wx.nextTick(() => {
          this.setData({
            toView: this.data.toView
          })
        })
      }
    })
  },
  // 文件格式转换
  renderSize(value) {
    if (null == value) {
      return '0 Bytes';
    }
    let unitArr = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    let srcSize = value;
    let index = Math.floor(Math.log(srcSize) / Math.log(1024));
    let size = srcSize / Math.pow(1024, index);
    return size.toFixed(2) + unitArr[index];
  },
  // 下载文件
  downFile(e) {
    const {
      index
    } = e.currentTarget.dataset
    const that = this
    const item = this.data.chatingList[index]
    if (item.messageBody.filePath) {
      that.openDocument(item.messageBody.filePath)
      return
    }
    wx.showLoading({
      title: '下载中',
    })
    const url = item.messageBody.fileUrl
    const fileName = item.messageBody.fileName

    wx.downloadFile({
      url: url,
      filePath: wx.env.USER_DATA_PATH + '/' + fileName,
      success(res) {
        // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
        if (res.statusCode === 200) {
          const filePath = res.filePath
          wx.hideLoading()
          wx.showToast({
            title: '下载完成',
            icon: 'success',
            duration: 2000
          })
          item.messageBody.filePath = filePath
          var idx = "chatingList[" + index + "]"
          that.setData({
            [idx]: item
          })
          that.openDocument(filePath)
        }
      },
      fail(e) {
        wx.hideLoading()
        wx.showToast({
          title: '下载异常',
          icon: "none"
        })
      }
    })
  },
  openDocument(path) {
    if (/.(doc|docx|xls|xlsx|ppt|pptx|pdf)$/i.test(path)) {
      wx.openDocument({
        filePath: path,
      })
    } else {
      wx.showToast({
        title: '不支持打开的格式',
        icon: "none"
      })
    }
  },
  // 去商品详情
  goToGoods(event) {
    const data = event.currentTarget.dataset.key.messageBody.data
    const desc = event.currentTarget.dataset.key.messageBody.desc
    const sn = data.sn
    const orderSn = data.orderSn

    if (sn || orderSn) {
      if (desc === 'ORDER') {
        wx.navigateTo({
          url: `/pages/order-detail/index?sn=${orderSn}`
        })
      } else {
        wx.navigateTo({
          url: `/pages/goods-detail/index?sn=${sn}`
        })
      }
    }
  },
  bindFocusInput(e) {
    console.info(e,'获取焦点')
    // keyboardHeight: app.isGlobalIphone.isIphone? e.detail.height : 28,
    this.setData({
      keyboardHeight: e.detail.height,
      emojiShow: false,
      fileShow: false,
      isFocus: true
    })
    this.updateMessageHeight(true)
  },
  // 预览图片
  previewImage(e) {
    const url = e.currentTarget.dataset.key
    console.log(url);
    wx.previewImage({
      urls: [url],
      showmenu: false,
      success: (res) => {
        console.log(res)
      },
      fail: (e) => {
        console.log(e)
      }
    })
  }
  // onPageScroll(e){
  //   console.log(e.scrollTop);
  // }
})
