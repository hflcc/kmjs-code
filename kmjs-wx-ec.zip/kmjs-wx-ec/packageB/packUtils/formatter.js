const util = {
  // 时间戳格式化成时间字符串
  formatterTimeTim(time, type = "", F = "-") {
    if (!time) {
      return ""
    }
    //  今天0点时间
    const dateNow = new Date(new Date(new Date().toLocaleDateString()).getTime());
    const date = new Date(time)
    const year = date.getFullYear() > 9 ? date.getFullYear() : "0" + date.getFullYear()
    const month = (date.getMonth() + 1) > 9 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1)
    const dateDay = date.getDate() > 9 ? date.getDate() : "0" + date.getDate()
    const hours = date.getHours() > 9 ? date.getHours() : "0" + date.getHours()
    const minute = date.getMinutes() > 9 ? date.getMinutes() : "0" + date.getMinutes()
    const second = date.getSeconds() > 9 ? date.getSeconds() : "0" + date.getSeconds()
    if (type == "MD") {
      return `${month}${F}${dateDay}`
    } else if (type == "HMM") {
      return `${hours}:${minute}:${second}`
    } else if (type == "YMD") {
      return `${year}${F}${month}${F}${dateDay}`
    }
    // 今天
    if(date > dateNow){
      return `今天  ${hours}:${minute}`
    } else if(date >= dateNow-(24 * 60 * 60 * 1000)) {
      return `昨天  ${hours}:${minute}`
    } else if(date >= dateNow-(2 * 24 * 60 * 60 * 1000)) {
      return `前天  ${hours}:${minute}`
    }
    return `${year}${F}${month}${F}${dateDay} ${hours}:${minute}:${second}`
  }
}

module.exports = util
