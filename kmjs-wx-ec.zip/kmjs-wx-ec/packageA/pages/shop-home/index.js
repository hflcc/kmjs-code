const {
  wxToast,
  formatterTime,
  scopeType,
  WXINFO
} = require("../../../utils/index")
const { handleEvent } = require('../../../utils/infoFlowEvents')
const app = getApp()


Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 当前高亮的底部tab栏索引
    activeTabIndex: 0,
    // tab类型 info_flow首页信息流 goods_category分类 goods商品 shop_info店铺信息 csc客服
    activeTabType: '',
    tabBarList: [],
    // 当前选中tab栏的sn
    currentTabSn: '',
    // 店铺sn
    shopSn: "",
    shopDetails: {},
    collectShow: false,
    // 新人优惠券
    newcoupon: false,
    // 新人优惠券列表
    newCouponList: [],
    // 分享数据
    shareData:{},
    // 显示分享面板
    showShare: false,
    // 分享选择器
    shareOptions: [{
        name: "分享给好友",
        type: "base",
        openType: "share",
        icon: "http://resource.kmyun.cn/haopinggo/wx.png"
      },
      {
        name: "生成分享海报",
        type: "poster",
        icon: "http://resource.kmyun.cn/haopinggo/poster.png"
      }
    ],
    // 显示分享海报
    showPoster: false,
    // 小程序码
    ewmImg: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    this.setData({
      shopSn: options.sn
    })
    await this.shopDetails(this.data.shopSn)
    await this.getShopTabList()
    if (app.globalData.userInfo.token) {
      this.getCollect();
    }
    this.ewm();
  },
  onShow() {
    if (app.globalData.userInfo.token) {
      this.getNewCoupon()
    }
  },
  /*
  * @info vantabbar切换时触发
  * */
  onTabChange(e) {
    const index = e.detail
    this.setTabShow(index)
  },
  /*
  * @info 设置对应的tab应展示的内容
  * */
  setTabShow(index) {
    const tabbarList = this.data.tabBarList
    const obj = {
      activeTabIndex: index,
      activeTabType: tabbarList[index]?.type?.toLowerCase(),
      currentTabSn: tabbarList[index]?.value
    }
    // CSC客服
    if (obj.activeTabType === 'csc') {
      this.jumpToCustomerChat()
    }
    this.setData(obj)
    wx.setNavigationBarTitle({
      title: tabbarList[index]?.title || '主页'
    })
  },
  /*
  * @info 跳转客服聊天
  * */
  jumpToCustomerChat() {
    const {sn, name} = this.data.shopDetails
    wx.nextTick(() => {
      wx.navigateTo({
        url: `/packageB/pages/tim/tim?sn=${sn}&title=${name}`
      })
    })
  },
  /*
  * @info 获取店铺下面的动态tab栏
  * */
  async getShopTabList() {
    const res = await app.get(`/md/common/shop/page/home/${this.data.shopSn}`)
    if (res) {
      const ossIds = res.map(item => [item.activeIcon, item.defaultIcon]).flat()
      const imgRes = await app.picSnGetUrl(ossIds, null, false, true)
      res.forEach(item => {
        item.activeIconUrl = imgRes[item.activeIcon]?.url
        item.defaultIconUrl = imgRes[item.defaultIcon]?.url
      })
      this.setData({
        tabBarList: res
      })
      this.setTabShow(this.data.activeTabIndex)
    }
  },
  /*
  * @info 统一收集处理信息流点击事件
  * */
  async handleFlowEmit(e) {
    const clickData = e.detail
    await handleEvent(clickData)
  },
  // 分享
  onShareAppMessage: function (e) {
    return {
      title: `我发现一间好店@${this.data.shopDetails.name}，推荐给你`
    }
  },
  onShareTimeline:function (e) {
    return {
      title: `我发现一间好店@${this.data.shopDetails.name}，推荐给你`
    }
  },
  // 保存图片
  savePoster() {
    const _self = this
    wx.getSetting({
      withSubscriptions: true,
      success(res) {
        if (!res.authSetting["scope.writePhotosAlbum"]) {
          wx.openSetting({
            success(data) {
              console.log("成功", data)
            },
            fail(err) {
              console.log("失败", err)
            }
          })
        } else {
          _self.selectComponent("#canvas").saveImage()
        }
      }
    })
  },
  // 分享面板
  changeShowShare() {
    this.setData({
      showShare: !this.data.showShare
    })
  },
  // 选择分享类型
  shareTypeSelect({ detail }) {
    this.setData({
      showShare: false
    })
    if (detail.type === "base") {

    } else if (detail.type === "poster") {
      this.setData({
        "shareData.shareImg": this.data.ewmImg,
        showPoster: true
      })
    }
  },
  // 关闭图片
  closePoster() {
    this.setData({
      showPoster: false
    })
  },
  // 获取小程序码
  async ewm() {
    let img = await app.get(`/wx/common/applet/code?scene=${this.data.shopSn}&page=pages/shop-home/index`)
    this.setData({
      ewmImg: img.imgBase64
    })
  },
  // 生成分享数据
  createShareData(){
    this.setData({
      shareData:{
        saleHeadImg: app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.headimgUrl?wx.getStorageSync(WXINFO).headimgUrl:"https://kmjs.oss-cn-shenzhen.aliyuncs.com/haopinggo/hpglogo-1624413363473.png",
        saleHeadName: app.globalData.userInfo.token && wx.getStorageSync(WXINFO)?.nickName?wx.getStorageSync(WXINFO).nickName:"耗品GO",
        // 店铺名称
        title: this.data.shopDetails.name,
        // 店铺logo
        imageUrl: this.data.shopDetails.headerImg,
        goods: [],
      }
    })
  },
  //获取新人优惠券列表
  async getNewCoupon() {
    let res = await app.checkNewCoupon()
    if (res instanceof Array) {
      if (res.length > 0) {
        res.forEach(item => {
          item.scopeNmae = scopeType[item.scopeType]
          item.endATString = formatterTime(item.endAt * 1000, 'YMD', '.')
          item.startATString = formatterTime(item.startAt * 1000, 'YMD', '.')
        })
      }
      this.setData({
        newCouponList: res,
        newcoupon: true
      })
    }
  },
  // 关闭新人优惠券
  closecp() {
    this.setData({
      newcoupon: false
    })
  },
  //获取店铺主页信息
  shopDetails(sn) {
    app.get(`/md/common/shop/detail/${sn}`).then(async res => {
      let data = [],
        imgList = []
      res.backgroundImages.forEach(item => {
        data.push(item)
        imgList.push(item.ossId)
      })
      imgList = await app.picSnGetUrl(imgList, {
        width: 344,
        height: 344
      })
      let headerImg = await app.picSnGetUrl(res?.coverImages?.[0]?.ossId, {
        width: 100,
        height: 100
      })
      data.forEach((v, i) => {
        v.newImg = imgList[i]
      })
      res.backgroundImages = data
      res.headerImg = headerImg && headerImg[0]

      this.setData({
        shopDetails: res
      })
    })
  },
  setCollect() {
    if (this.data.collectShow) {
      app.del("/md/inst/user/follow/cancel/shop/" + this.data.shopSn).then(res => {
        if (res) {
          wxToast("取消收藏成功")
          this.getCollect()
        }
      })
    } else {
      app.post("/md/inst/user/follow/shop/" + this.data.shopSn, {
        bodyTitle: this.data.shopDetails.name,
        source: "home"
      }).then(res => {
        if (res) {
          wxToast("收藏成功")
          this.getCollect()
        }
      })
    }
  },
  getCollect() {
    app.get("/md/inst/user/follow/valid/shop/" + this.data.shopSn).then(res => {
      if (Array.isArray(res)) {
        this.setData({
          collectShow: res.length > 0
        })
      }
    })
  }
})
