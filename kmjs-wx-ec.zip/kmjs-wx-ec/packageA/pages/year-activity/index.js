import {requestAnimationFrame as next, debounce, getImageUrl, formatRecordList, getRecordListOssId } from './tools'
import { formatterTime } from '../../../utils/formatter'
import { createCanvasFire, clearCanvasTimer } from './canvas'
import Toast from '@vant/weapp/toast/toast'

const app = getApp()
let timerArr = []
let mechineBgTimer = null


Page({
    data: {
        bgSizeType: '100% 100%',
        audioSrc: 'https://resource.kmyun.cn/kmjs-year-act/scroll0-audio-2.mp3', // 滚动音频
        prizeSrc: 'https://resource.kmyun.cn/kmjs-year-act/reward-audio.mp3', // 中奖时音频
        pageBgUrl: '',
        showScrollMask: true,
        // 奖品列表
        prizeList: [],
        opts: null,
        startedAt: null,
        scrolling: false,
        scrollBoxTransY: 0,
        scrollerItemHeight: 0,
        // 活动说明弹窗
        showRewardRule: false,
        // 中奖记录弹窗
        showRewardRecord: false,
        // 抽中奖品后的弹窗
        showPrizeResult: false,
        // 中奖后的奖品弹窗数据
        prizeDialogResult: null,
        // 抽奖次数
        lotteryNum: 0,
        // 抽奖配置
        instanceSn: '',
        canJoinAct: false,
        // 抽奖活动实例信息
        actInfo: {},
        actStartTime: '',
        actEndTime: '',
        // 所有用户中奖记录列表
        otherRecordList: [],
        otherPageSize: 20,
        otherPageNo: 0,
        otherLoadMore: true,
        // 当前自己的中奖记录列表
        myRecordList: [],
        changeMechineBg: false,
    },

    onReady() {
        // this.audioCtx = wx.createAudioContext('yearActAudio')
        this.audioPrizeCtx = wx.createAudioContext('yearPrizeAudio')
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        timerArr = []
        // 是否在滚动抽奖中
        this.setData({
            bgSizeType: wx.getSystemInfoSync().windowHeight >= 700 ? '100% 100%' : '100% auto',
            scrolling: false,
            instanceSn: options.sn
        })
        this.getActivityInsInfo()
        // 使用animation切换背景,在ios切换到后台时背景会消失,因此改用定时器切换
        mechineBgTimer = setInterval(() => {
            this.setData({
                changeMechineBg: !this.data.changeMechineBg
            })
        }, 300)
    },

    onUnload() {
        this.clearPageTimeOut()
        clearCanvasTimer()
        clearInterval(mechineBgTimer)
    },

    onHide() {
        clearCanvasTimer()
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        wx.nextTick(() => {
            createCanvasFire.call(this)
        })
        if (!wx.getStorageSync('refreshToken')) {
            wx.showToast({
                title: '你还未登录, 请先登录',
                icon: 'none',
                complete() {
                    setTimeout(() => {
                        wx.navigateTo({
                            url: '/pages/login/index'
                        })
                    }, 1500)
                }
            })
        } else {
            this.handleJoinActivity()
        }
    },

    /*
    * @info 参与抽奖活动
    * */
    async handleJoinActivity() {
        const res = await app.post(`/mk/lottery/instance/user/${this.data.instanceSn}`)
        if (res && res.success) {
            this.setData({
                canJoinAct: true
            })
            this.getSelfLotteryInfo()
        }
    },

    /*
    * @info 查询自己的抽奖信息(包含可抽奖次数, 已使用抽奖次数)
    * */
    async getSelfLotteryInfo() {
        const res = await app.get(`/mk/lottery/instance/user/current/${this.data.instanceSn}`)
        if (res) {
            this.setData({
                lotteryNum: res.surplusNum || 0
            })
        }
    },

    /*
    * @info 查询抽奖实例信息
    * */
    async getActivityInsInfo() {
        const res = await app.get(`/mk/common/lottery/instance/${this.data.instanceSn}`)
        if (res) {
            const {rewards = [], background = ''} = res
            const ossIds = [background, ...rewards.map(item => item.icon)]
            const imgRes = await getImageUrl(ossIds)
            rewards.forEach(item => item.iconUrl = imgRes[item.icon]?.url)
            this.setData({
                prizeList: rewards,
                pageBgUrl: imgRes[background]?.url,
                actInfo: res,
                actStartTime: formatterTime(res.startAt * 1000, 'YMD', '.'),
                actEndTime: formatterTime(res.endAt * 1000, 'YMD', '.'),
            })
            wx.setNavigationBarTitle({title: res.name})
            if (rewards?.length) {
                wx.createSelectorQuery().selectAll('.scroller-box .scroller-box--item').boundingClientRect(rects => {
                    this.setData({
                        scrollBoxTransY: -rects[0]?.height || 0, // 初始化滚轮位置
                        scrollerItemHeight: rects[0]?.height || 0
                    })
                }).exec()
            }
        }
    },

    /*
    * @info 获取活动是否已经开始
    * */
    getActivityIsStart() {
        return new Promise(async (resolve, reject) => {
            const res = await app.put(`/mk/common/lottery/instance/check/${this.data.instanceSn}`)
            if (res && res.success) {
                resolve(true)
            } else {
                wx.showModal({
                    confirmText: '知道了',
                    content: res.message,
                    showCancel: false,
                    title: '提示'
                })
                resolve(false)
            }
        })
    },

    /*
    * @info 开始抽奖
    * */
    handleStart: debounce(async function () {
        if (this.data.canJoinAct && !this.data.scrolling) {
            const isStart = await this.getActivityIsStart()
            if (!isStart) return
        }
        if (!this.data.canJoinAct) return
        if (this.data.scrolling) return
        if (!this.data.prizeList?.length) return
        if (this.data.lotteryNum <= 0) {
            Toast('抽奖次数已用完')
            return
        }
        // 回到音效开头并开始播放
        // this.audioCtx.seek(0)
        // this.audioCtx.play()
        this.setData({
            scrolling: true,
            showScrollMask: false,
            prizeDialogResult: null,
            lotteryNum: this.data.lotteryNum - 1,
            opts: {
                finalPos: 0, // 最终停留的位置
                startOffset: 20000, // 影响转的圈数
                height: this.data.prizeList.length * this.data.scrollerItemHeight,
                duration: 60000, // milliseconds
                isFinished: false,
            }
        })
        // 这里为了不等接口回来才开始转动, 先设定了60秒的转动展示给用户, 等接口回来把之前的定时器都清除再重新开始计算
        timerArr.push(next(this.animateFn))
        const res = await this.getLotteryResult()
        // 先清除掉之前模拟的滚动
        this.setData({
            opts: null,
            startedAt: null,
        })
        this.clearPageTimeOut()
        // 如果接口返回了正确的奖品sn就真正开始滚动
        if (res) {
            const choice = this.data.prizeList.findIndex(item => item.sn === res.rewardSn);
            const obj = {
                opts: {
                    finalPos: choice * this.data.scrollerItemHeight, // 最终停留的位置
                    startOffset: 3000, // 影响转的圈数
                    height: this.data.prizeList.length * this.data.scrollerItemHeight,
                    duration: 8000, // milliseconds
                    isFinished: false,
                }
            }
            if (res.beLottery) {
                obj.prizeDialogResult = this.data.prizeList.find(item => item.sn === res.rewardSn) || null
            }
            this.setData(obj)
            timerArr.push(next(this.animateFn))
        } else {
            // this.audioCtx.pause()
            this.setData({
                showScrollMask: true,
                scrolling: false,
                lotteryNum: this.data.lotteryNum + 1, // 如果接口报错, 将减掉的抽奖次数加回1,
                scrollBoxTransY: -this.data.scrollerItemHeight || 0 // 初始化滚轮位置
            })
            this.getSelfLotteryInfo()
        }
    }),

    /*
    * @info 获取抽奖结果
    * */
    getLotteryResult () {
        return new Promise(async (resolve, reject) => {
            const res = await app.post(`/mk/lottery/instance/play/personal/${this.data.instanceSn}`)
            if (res) {
                resolve(res)
            } else {
                resolve(false)
            }
        })
    },

    /*
    * @info 抽奖机滚动函数
    * */
    animateFn(timestamp) {
        if (!this.data.opts) return
        if (!this.data.startedAt) {
            this.setData({
                startedAt: timestamp
            })
        }
        const timeDiff = timestamp - this.data.startedAt; // 动画持续的时间
        const opt = this.data.opts
        const damping = opt.duration
        if (!opt.isFinished) {
            // 设置动画随着执行次数增多,增大执行时间, 即越到后面滚动速度越慢
            // 总的持续时间 - 动画持续时间 = 剩下的时间,0表示结束
            const timeRemaining = Math.max(damping - timeDiff, 0);
            const power = 3
            // Math.pow(timeRemaining, power)表示: timeRemaining 的3 次幂;
            const offset = (Math.pow(timeRemaining, power) / Math.pow(damping, power)) * opt.startOffset;
            const pos = -1 * Math.floor((offset + opt.finalPos) % opt.height)
            this.setData({
                scrollBoxTransY: pos - this.data.scrollerItemHeight
            })
            // 如果执行时间大于设定的执行事件, 说明抽奖滚轮已经停止结束了
            if (timeDiff > damping) {
                // 解决防止用户快速点击导致剩余次数计算问题, 这里滚动结束后延迟一秒才打开scrolling开关
                setTimeout(() => {
                    this.setData({
                        scrolling: false
                    })
                }, 100)
                const obj = {
                    opts: null,
                    startedAt: null
                }
                // 如果有值说明抽中了奖品, 为null时说明没抽中奖
                if (this.data.prizeDialogResult) {
                    obj.showPrizeResult = true
                    // 播放中奖音频
                    this.audioPrizeCtx.seek(0)
                    this.audioPrizeCtx.play()
                }
                this.setData(obj)
                this.clearPageTimeOut()
                // this.audioCtx.pause()
                // 再获取一次抽奖次数, 确保与服务器保持一致
                this.getSelfLotteryInfo()
            } else {
                timerArr.push(next(this.animateFn))
            }
        }
    },

    /*
    * @info 打开活动规则弹窗
    * */
    handleShowRule() {
        if (!this.data.canJoinAct) return
        this.setData({
            showRewardRule: true
        })
    },

    /*
    * @info 打开中奖记录弹窗
    * */
    async handleShowRecord() {
        if (!this.data.canJoinAct) return
        this.setData({
            showRewardRecord: true
        })
        this.getOtherRecordList(true)
        this.getMyRecordList()
    },

    /*
    * @info 获取所有人的中奖记录
    * */
    async getOtherRecordList(flag) {
        if (flag) {
            this.setData({
                otherRecordList: [],
                otherPageNo: 0,
                otherLoadMore: true
            })
        }
        this.otherRecordLoading = true
        const { otherRecordList, otherPageSize, otherPageNo, instanceSn } = this.data
        const res = await app.get(`/mk/lottery/instance/user/reward/page/${instanceSn}?page=${otherPageNo}&size=${otherPageSize}`)
        this.otherRecordLoading = false
        if (res) {
            const ossIds = getRecordListOssId(res.content)
            const imgRes = await (ossIds.length && getImageUrl(ossIds) || [])
            formatRecordList(res.content, imgRes)
            this.setData({
                otherRecordList: otherRecordList.concat(res.content || []),
                otherLoadMore: !!res.content?.length
            })
        }
    },

    /*
    * @info 加载更多中奖记录
    * */
    handleGetMoreOtherRecord() {
        const { otherPageNo, otherLoadMore } = this.data
        if (otherLoadMore && !this.otherRecordLoading) {
            this.setData({
                otherPageNo: otherPageNo + 1
            })
            this.getOtherRecordList()
        }
    },

    /*
    * @info 获取本人中奖记录
    * */
    async getMyRecordList() {
        const myList = await app.get(`/mk/lottery/instance/user/reward/list/group/current/${this.data.instanceSn}`)
        if (!myList) return
        const ossIds = getRecordListOssId(myList)
        const imgRes = await (ossIds.length && getImageUrl(ossIds) || [])
        formatRecordList(myList, imgRes)
        this.setData({
            myRecordList: myList
        })
    },

    // 关闭活动说明弹窗触发
    onRuleClose() {
        this.setData({
            showRewardRule: false
        })
    },

    // 关闭中奖记录弹窗触发
    onRecordClose() {
        this.setData({
            showRewardRecord: false
        })
    },

    // 关闭中奖后的弹窗触发
    onPriseResultClose() {
        this.setData({
            prizeDialogResult: null,
            showPrizeResult: false
        })
    },

    // 中奖后跳转填写收货地址
    onPriseAddress () {
        this.onPriseResultClose()
        wx.navigateTo({
            url: '/pages/address/index?t=needback'
        })
    },

    // 供收货地址页面调用(防止报错)
    changeAddressData(res) {
        console.log(res)
    },

    /*
    * @Info 清除页面定时器
    * */
    clearPageTimeOut() {
        timerArr.forEach(t => clearTimeout(t))
        timerArr = []
    },
    emptyFn() {}
})
