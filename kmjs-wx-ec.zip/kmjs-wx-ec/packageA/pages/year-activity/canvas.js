let canvasTimer = null

export const clearCanvasTimer = () => {
  clearInterval(canvasTimer)
  canvasTimer = null
}

const openFire = function() {
  fire.call(this, Math.random() * 500, Math.random() * 500)
  canvasTimer = setInterval(() => {
    fire.call(this, Math.random() * 500, Math.random() * 500)
  }, 2000)
}

export const createCanvasFire = function () {
  if (this.canvas && this.context) {
    openFire.call(this)
    return
  }
  const query = wx.createSelectorQuery()
  query.select('#yearCanvas')
  .fields({ node: true, size: true })
  .exec((res) => {
    this.canvas = res[0].node
    this.context = this.canvas.getContext('2d')
    const dpr = wx.getSystemInfoSync().pixelRatio
    this.canvas.width = res[0].width * dpr
    this.canvas.height = res[0].height * dpr
    openFire.call(this)
  })
}

function clearCanvas() {
  this.context.fillStyle = "transparent";
  this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
}

let rid = null;
let particles = [];

function fire(x, y) {
  particles = []
  createFireworks(x, y);
  const self = this;
  function tick() {
    self.context.globalCompositeOperation = "destination-out";
    self.context.fillStyle = "rgba(0,0,0," + 10 / 100 + ")";
    self.context.fillRect(0, 0, self.canvas.width, self.canvas.height);
    self.context.globalCompositeOperation = "lighter";
    drawFireworks.call(self);
    rid = self.canvas.requestAnimationFrame(tick);
  }
  self.canvas.requestAnimationFrame(tick)
  self.canvas.cancelAnimationFrame(rid);
  rid = null
}

function createFireworks(sx, sy) {
  // let hue = Math.floor(Math.random() * 51) + 150;
  // let hueVariance = 30;
  let count = 100;
  for (let i = 0; i < count; i++) {
    let p = {};
    let angle = Math.floor(Math.random() * 360);
    p.radians = (angle * Math.PI) / 180;
    p.x = sx;
    p.y = sy;
    p.speed = Math.random() * 5 + 0.4;
    p.radius = p.speed;
    p.size = Math.floor(Math.random() * 3) + 1;
    /*p.hue =
        Math.floor(
            Math.random() * (hue + hueVariance - (hue - hueVariance))
        ) +
        (hue - hueVariance);
    p.brightness = Math.floor(Math.random() * 31) + 50;*/
    p.alpha = (Math.floor(Math.random() * 61) + 40) / 100;
    particles.push(p);
  }
}

function drawFireworks() {
  clearCanvas.call(this);
  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    let vx = Math.cos(p.radians) * p.radius;
    let vy = Math.sin(p.radians) * p.radius + 0.4;
    p.x += vx;
    p.y += vy;
    p.radius *= 1 - p.speed / 100;
    p.alpha -= 0.005;
    this.context.beginPath();
    this.context.arc(p.x, p.y, p.size, 0, Math.PI * 2, false);
    this.context.closePath();
    this.context.fillStyle = randomRgba(p.alpha);
    this.context.fill();
  }
}

function randomRgba(a) {
  const o = Math.round, r = Math.random, s = 255;
  return `rgba(${o(r()*s)}, ${o(r()*s)}, ${o(r()*s)}, ${a})`
}

