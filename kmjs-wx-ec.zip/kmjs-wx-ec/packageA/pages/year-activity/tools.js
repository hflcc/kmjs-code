import { formatterTime } from '../../../utils/formatter'

const app = getApp()

// requestAnimationFrame polyfill
export const requestAnimationFrame = function(callback, lastTime) {
  if (typeof lastTime === 'undefined') {
    lastTime = 0
  }
  let currTime = new Date().getTime();
  let timeToCall = Math.max(0, 16.67 - (currTime - lastTime));
  lastTime = currTime + timeToCall;
  return setTimeout(function () {
        callback(currTime + timeToCall, lastTime);
      }, timeToCall);
};

export const getImageUrl = function (ossIds = [], style = {}) {
  return new Promise(async (resolve, reject) => {
    const imgRes = await app.get(`/oss/common/list/seqs`, { seqs: ossIds.join(',') })
    if (imgRes) {
      resolve (imgRes)
    } else {
      resolve({})
    }
  })
}

export const formatRecordList = function (arr = [], imgRes = {}) {
  arr.forEach(item => {
    item._createdAt = `${formatterTime(item.createdAt * 1000, 'MD', '-')} ${formatterTime(item.createdAt * 1000, 'HMM')}`
    item.iconUrl = imgRes[item.icon]?.url || ''
    item.userIconUrl = imgRes[item.userIcon]?.url || ''
  })
}

export const getRecordListOssId = function (arr = []) {
  return arr.reduce((total, cur) => {
    const { userIcon, icon } = cur || {}
    if (userIcon) total.push(userIcon)
    if (icon) total.push(icon)
    return total
  }, [])
}

export const debounce = function (fn, delay = 100) {
  let timer = null
  return function () {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      clearTimeout(timer)
      timer = null
    }, delay)
  }
}
