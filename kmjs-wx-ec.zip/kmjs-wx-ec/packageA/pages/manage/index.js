// pages/manage/manage.js
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 是否有更多数据
    hasMore: false,
    // 是否加载中
    isLoading: true,
    // 商品列表
    productList: [],
    // 分页信息
    query: {
      page: 0,
      size: 10
    },
    // 商品sn
    sn: "",
    /*
    * goodsClassity: 分类列表过来的
    * indexStream: 首页信息流出来的
    * */
    type: "",
    // 不同类型不同表现
    typeMsg: {
      // 分类列表
      goodsClassity: {
        // 接口
        api: "/ec/common/category/resource/",
        // 标题名称
        title: "分类列表"
      },
      // 首页信息流
      indexStream: {
        // 接口
        api: "/ec/common/info/flow/item/page/",
        // 标题名称
        title: "经营必备"
      }
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 分类列表sn
    this.data.sn = options.sn
    // 当前类型
    this.data.type = options.type
    // 匹配到的信息
    const msg = this.data.typeMsg[options.type]
    // 有分类匹配,调用接口
    if (msg) {
      wx.setNavigationBarTitle({
        title: msg.title
      })
      // 拉取商品列表
      this.getgoods(this.data.sn)
    }
  },
  // 底部加载更多
  pullDown() {
    if (this.data.hasMore) {
      this.getgoods(this.data.sn)
    }
  },
  // 下拉刷新
  pullUp() {
    this.data.productList = []
    this.data.query = {
      page: 0,
      size: 10
    }
    this.getgoods(this.data.sn)
    this.setData({
      refresherTriggered: false
    })
  },
  //获取商品列表
  getgoods(sn) {
    this.setData({
      "isLoading": true
    })
    // 分页数据
    const query = this.data.query
    app.get(`${this.data.typeMsg[this.data.type].api}${sn}`, query).then(async res => {
      if (!res) {
        return
      }
      this.data.query.page++
      let data = await app.formatterGoods(res.content, {width: 344, height: 344})
      this.setData({
        "productList": this.data.productList.concat(data),
        "hasMore": !res.last,
        "isLoading": false
      })
    })
  },
  tapItem(e) {
    wx.navigateTo({
      url: `/pages/goods-detail/index?sn=${e.detail.sn}`
    })
  }
})