const base64 = require('./base64')
const constant = require('./constant')
const formatter = require('./formatter')
const wx = require('./wx')
const utils = require('./utils')
const EventBus = require('./event-bus')

module.exports = {
  // 常量
  ...constant,
  // base64 编解码
  ...base64,
  // 格式化相关
  ...formatter,
  // 微信相关的方法
  ...wx,
  // 工具方法
  ...utils,
  //缓存页面对象
  EventBus
};