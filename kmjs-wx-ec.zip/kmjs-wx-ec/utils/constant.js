const ENV = wx.getAccountInfoSync().miniProgram.envVersion
module.exports = {
  // 后台对应的 appid
  client_id: "99599E0DCED4_2",
  // 后台对应的 APP秘钥
  client_secret: "C7F47C73863E40B18BC3F1616E4494",
  // token存储名称
  TOKEN: ENV + "token",
  // 手机号存储名称
  MOBILE: "mobile",
  // 身份KEY值
  INSTID: ENV + "InstId",
  // openId
  OPENID: "openId",
  WXINFO:"wxInfo",
  // 刷新token
  REFRESHTOKEN: "refreshToken",
  // 刷新token的时间
  REFRESHTOKENTIME: "refreshTokenTime",
  PHONENUM:"phoneNum",
  /**
   * 页面的初始数据
   * none("待支付", 1),
   * pay("支付中", 2),
   * deliver("待发货", 3),
   * receiving("待收货", 4),
   * comment("待评论", 5),
   * complete("已完成", 6),
   * refund("已退款", 7),
   * cancel("取消", 0);
   */
  // 优惠券类型
  scopeType:{
    goods:'商品优惠券',
    shop:'店铺优惠券',
    app:'平台优惠券',
  },
  // 订单枚举
  ORDERSTATUS: {
    none: "待支付", // 去支付, 取消订单
    pay: "待支付", // 去支付, 取消订单
    deliver: "待发货", // 无
    delivering: "发货中", // 供应商填写物流单号点击发货后，再未获取到物流信息前
    receiving: "待收货", // 查看物流, 确认收货
    comment: "已完成", // 无
    complete: "已完成", // 再次采购
    refund: "已退款", // 无
    cancel: "交易关闭", // 无
    goodsCompose:"拼单中",
    peopleCompose:"拼团中",
  },
  // 售后类型
  AFTERSALETYPE:{
    exchange:"换货",
    refund:"退款",
    back_refund:"退货退款"
  },
  // 售后状态
  AFTERSALESTATE:{
    none:"none",
    apply:"售后审核",
    cancel:"售后关闭",
    reject:"条件不符",
    wait_send:"商品寄回",
    process:"商家处理",
    wait_back:"用户收货",
    complete:"售后成功"
  },
  // 快递
  EXPRESSAGE: {
    "def": "快递",
    "ems": "EMS",
    "py": "平邮",
    "sf": "顺丰",
    "zt": "中通"
  },
  // 快递算值汇总
  EXPRESSAGESUM: {
    "piece": "按件数",
    "weight": "按重量",
    "volume": "按体积"
  },
  //售后状态
  AFTERSTATE:{
    "process":"售后中",
    "complete":"已售后"
  },
  //拼团状态
  spellType:{
    "none":"待支付",
    "process":"拼团中",
    "success":"拼团成功",
    "fail":"拼团失败"
  }
}