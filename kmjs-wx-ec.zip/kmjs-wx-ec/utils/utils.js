import {
  INSTID,
  TOKEN,
  OPENID,
  REFRESHTOKEN,
  REFRESHTOKENTIME,
  WXINFO,
  MOBILE,
  PHONENUM,
  client_id,
  client_secret
} from "./constant"
import { encode } from "./base64"

const utils = {
  // 登录态储存
  async saveLoginStatus(app, data) {
    app.globalData.userInfo.token = data.access_token
    wx.setStorageSync(TOKEN, data.access_token)
    wx.setStorageSync(REFRESHTOKEN, data.refresh_token)
    wx.setStorageSync(REFRESHTOKENTIME, new Date().getTime() + 25 * 24 * 60 * 60 * 1000)
    app.get("/sys/user/current/check/integrity").then(res => {
      if (res) {
        app.globalData.userInfo.phoneNum = res.phoneNum
        utils.saveOpenId(app, res.wxInfo)
        const {headimgUrl,nickName} =  res.wxInfo
        wx.setStorageSync(WXINFO, {headimgUrl,nickName})
        wx.setStorageSync(PHONENUM, res.phoneNum)
      }
    })
  },
  // 登录态销毁
  removeLoginStatus(app) {
    app.globalData.userInfo.token = ""
    app.globalData.userAddress = {}
    wx.setStorageSync(TOKEN, "")
    wx.setStorageSync(REFRESHTOKEN, "")
    wx.setStorageSync(REFRESHTOKENTIME, "")
    wx.setStorageSync(WXINFO, "")
    wx.setStorageSync(MOBILE, "")
    wx.setStorageSync(PHONENUM, "")
    utils.removeInstId(app)
    utils.removeOpenId(app)
  },
  // openID储存
  saveOpenId(app, data) {
    app.globalData.userInfo.openId = data.openId
    wx.setStorageSync(OPENID, data.openId)
  },
  // openID销毁
  removeOpenId(app) {
    app.globalData.userInfo.openId = ""
    wx.setStorageSync(OPENID, "")
  },
  // 
  // 历史搜索销毁
  removeHisSearch() {
    wx.removeStorage({ key: "hisSearch" })
  },
  // 身份储存
  async saveInstId(app, { name, id }) {
    const data = {
      name,
      id
    }
    app.globalData.userInfo.InstId = data
    wx.setStorageSync(INSTID, data)
    wx.setStorageSync('instId-id', id)
    await app.getAddressList()
    app.getAreaList()
  },
  // 身份销毁
  removeInstId(app) {
    app.globalData.userInfo.InstId = {}
    wx.setStorageSync(INSTID, {})
  },
  // 校验手机号码 正则校验
  numberReg(d) {
    const reg = /^1[3-9]\d{9}$/g
    return reg.test(d)
  },
  //收货人 正则校验
  nameReg(d) {
    const reg = /^[\u4E00-\u9FA5A-Za-z0-9]+$/
    return reg.test(d)
  },
  // 身份信息输入框认真
  identityReg(value) {
    const reg = /^[\u4E00-\u9FA5A-Za-z]{2,30}$/
    return reg.test(value)
  },
  //验证英文加数字
  numLetter(value){
    const reg = /^[A-Za-z0-9]+$/
    return reg.test(value)
  },
  //字符长度校验
  /**
   * @param {String} data  传入的值
   * @param {Number} min 最小长度
   * @param {Number} max 最大长度
   */
  stringLength(data, min, max) {
    if (min && max) {
      if (data.length < min || data.length > max) {
        return false
      }
    } else if (min) {
      if (data.length < min) {
        return false
      }
    } else if (max) {
      if (data.length > max) {
        return false
      }
    }
    return true
  },
  // 号码中间4位隐藏
  privacyMobile(num) {
    var pattern = /(\d{3})(\d{4})(\d{4})/
    return num.replace(pattern, "$1****$3")
  },
  // 刷新token
  async refreshToken(app) {
    const refreshToken = wx.getStorageSync(REFRESHTOKEN)
    const refreshTokenTime = wx.getStorageSync(REFRESHTOKENTIME)
    if (refreshTokenTime && refreshToken) {
      if (new Date().getTime() > refreshTokenTime) {
        const result = await app.post("/oauth2/oauth/token?grant_type=refresh_token&refresh_token=" + refreshToken, {}, {
          Authorization: "Basic " + encode(`${client_id}:${client_secret}`)
        })
        if (result) {
          utils.saveLoginStatus(app, result)
        }
      }
    }
  }
}

module.exports = utils
