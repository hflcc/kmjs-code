import {client_id, closeLoading, openLoading, wxToast} from "./index"
import {removeLoginStatus} from "./utils"

class Axios {
  constructor(app) {
    this.app = app
    this.baseUrl = this.getBaseUrl()
  }

  // 如果是有登陆失效的报错，后续所有的请求都已失效处理
  // 记录请求地址的数组, 相同的地址不重复发起请求
  requestUrlList = []
  // 不限制请求数量的接口
  throughList = ['/oss/common/list/seqs']
  // 记录登陆失败的标记位，如果有这个标记（值为true），在所有请求完成后跳转到登陆页
  logoutFlag = false
  // 请求数量
  loadingCount = 0

  // 错误信息数组
  errMsg = []

  // 白名单
  whiteLists = [
    // 首页信息流
    "/md/common/info/flow/instance/page/def_category_sn/",
    // 首页信息流的tab
    "/md/common/info/flow/platform/list/category/home",
    // 查询图片
    "/oss/common/list/seqs"
  ]

  // 定时器
  timer = 0

  // 接口是否在白名单中
  isWhiteListsUrl(url) {
    for (let i = 0; i < this.whiteLists.length; i++) {
      if (this.whiteLists.indexOf(url) > 0) {
        return true
      }
    }
    return false
  }

  // 获取token
  getToken() {
    if (this.app.globalData.userInfo && this.app.globalData.userInfo.token) {
      return "Bearer " + this.app.globalData.userInfo.token
    }
    return ""
  }

  // 获取身份ID
  getInstId() {
    const instId = this.app.globalData.userInfo.InstId
    return instId.id || ""
  }

  getBaseUrl(url) {
    if(url && url.startsWith("/ec")){
      return "http://172.16.31.126:18888"
    }
    const env = this.app.ENV
    if (env === "develop") {
      // return "http://172.16.31.126:18888"
      return "https://api-dev.kmyun.cn"
    } else if (env === "trial") {
      return "https://api-dev.kmyun.cn"
    }
    return "https://api.kmyun.cn"
  }

  get(url, data, header) {
    return this.request(url, data, header, "GET")
  }

  post(url, data, header) {
    return this.request(url, data, header, "POST")
  }

  put(url, data, header) {
    return this.request(url, data, header, "PUT")
  }

  del(url, data, header) {
    return this.request(url, data, header, "DELETE")
  }

  request(url, data = {}, header = {}, method) {
    if ((this.throughList.indexOf(url) < -1 && this.requestUrlList.indexOf(url) > -1) || this.status === 'abort') {
      return
    }
    this.requestUrlList.push(url)
    if (this.loadingCount === 0 && !this.isWhiteListsUrl(url)) {
      openLoading()
    }
    if (!this.isWhiteListsUrl(url)) {
      this.loadingCount += 1
    }
    return new Promise((resolve, reject) => {
      wx.request({
        method,
        data,
        url: this.getBaseUrl(url) + url,
        header: {
          AppId: client_id,
          "content-type": "application/json",
          Authorization: header.Authorization || this.getToken(),
          InstId: this.getInstId(),
          ...header
        },
        success: ({statusCode, data, header, cookies}) => {
          if (statusCode === 200) {
            return resolve(data)
          } else if (statusCode === 401) {
            this.logoutFlag = true
            // console.log('登陆失效')
            // 如果登陆失效，跳转登陆页, 并且取消所有的请求
            // wxToast("登录失效")
            // removeLoginStatus(this.app)
            // wx.navigateTo({
            //   url: "/pages/login/index"
            // }).then(() => {
            //   // console.log('重制状态')
            //   this.status = 'through'
            // })
          } else if (data.message) {
            this.errMsg.push(data.message)
          }
          resolve(false)
        },
        fail: (err) => {
          if (this.status === 'abort') {
            // console.log('无效请求')
            return resolve(false)
          }
          console.log(err)
          this.errMsg.push("系统异常,请稍后重试;")
          resolve(false)
        },
        complete: () => {
          // 清除已完成的请求
          const index = this.requestUrlList.indexOf(url);
          if (index > -1) {
            // console.log('请求完成')
            this.requestUrlList.splice(index, 1)
          }
          if (!this.isWhiteListsUrl(url)) {
            this.loadingCount -= 1
          }
          if (this.loadingCount === 0) {
            clearTimeout(this.timer)
            this.timer = setTimeout(() => {
              closeLoading()
              if (!this.logoutFlag && this.errMsg.length > 0) {
                wxToast(...new Set(this.errMsg))
                this.errMsg = []
              }
              const pages = getCurrentPages()
              const page = pages[pages.length - 1].route
              if (this.logoutFlag && page !== 'pages/login/index') {
                wxToast("登录失效")
                removeLoginStatus(this.app)
                wx.navigateTo({
                  url: "/pages/login/index"
                }).then(() => {
                  // console.log('重制状态')
                  this.logoutFlag = false
                })
              }
            }, 200)
          }
        }
      })
    })
  }
}

module.exports = function (app) {
  return new Axios(app)
}
