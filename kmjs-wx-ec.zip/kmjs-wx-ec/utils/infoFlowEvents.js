/**
 * Created by hing on 2021-12-13 13:55
 * 统一处理信息流点击事件
 */
const navigate = (url) => {
  return wx.navigateTo({
    url,
    fail: function () {
      wx.switchTab({
        url,
        fail: function () {}
      })
    }
  })
}

const handleNavigateUrl = async (data = {}) => {
  const { action = {} } = data
  console.log(action, 'beforeNavigate')
  return new Promise((resolve, reject) => {
    if (action.type === 'shop') {
      resolve(`/packageA/pages/shop-home/index?sn=${action.value}`)
    } else if (action.type === 'goods') {
      resolve(`/pages/goods-detail/index?sn=${action.value}`)
    } else if (action.type === 'info_flow') {
      // 跳转类型为信息流时还需判断信息流类型
      switch (action.other?.flowType) {
        case 'shop_home':
          resolve(`/packageA/pages/shop-home/index?sn=${action.value}`)
          break
        case 'platform_home':
          break
        case 'activity_home':
          resolve(`/packageA/pages/activity-home/index?sn=${action.value}`)
          break
        default:
          break
      }
    }
  })
}

export const handleEvent = async (eventData = {}) => {
  console.log(eventData, 'eventData')
  // funcName调用方法名 target点击的业务数据 source信息流构建数据源
  const {funcName = '', target = {}, source = {}} = eventData
  let jumpUrl = ''
  if (source.name === 'banner') {
    jumpUrl = await handleNavigateUrl(target)
    navigate(jumpUrl)
    return
  }
  jumpUrl = await handleNavigateUrl(source)
  navigate(jumpUrl)
}
