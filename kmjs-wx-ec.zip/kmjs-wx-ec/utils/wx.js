// 微信相关的工具方法
module.exports = {
  // 获取登录 code
  getWxLoginCode() {
    return new Promise((resolve, reject) => {
      wx.login({
        success: ({ code }) => {
          if (code) {
            resolve(code);
          } else {
            wxToast("登录失败,请重试;");
          }
        },
        fail: () => {
          wxToast("登录失败,请重试;");
        }
      });
    });
  },
  // Toast
  wxToast(title, icon = "none") {
    wx.showToast({
      title,
      icon,
      duration: 2000,
      mask: true
    });
  },
  // 打开 loading
  openLoading() {
    wx.showLoading({
      title: "加载中",
      mask: true
    });
  },
  // 关闭 loading
  closeLoading() {
    wx.hideLoading();
  }
}