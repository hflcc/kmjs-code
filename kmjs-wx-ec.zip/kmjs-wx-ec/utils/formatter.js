module.exports = {
  formatterToChinesNum(num) {
    let changeNum = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"] //changeNum[0] = "零"
    let unit = ["", "十", "百", "千", "万"]
    num = parseInt(num)
    let getWan = (temp) => {
      let strArr = temp.toString().split("").reverse()
      let newNum = ""
      for (var i = 0; i < strArr.length; i++) {
        newNum = (i == 0 && strArr[i] == 0 ? "" : (i > 0 && strArr[i] == 0 && strArr[i - 1] == 0 ? "" : changeNum[strArr[i]] + (strArr[i] == 0 ? unit[0] : unit[i]))) + newNum
      }
      return newNum
    }
    let overWan = Math.floor(num / 10000)
    let noWan = num % 10000
    if (noWan.toString().length < 4) noWan = "0" + noWan
    return overWan ? getWan(overWan) + "万" + getWan(noWan) : getWan(num)
  },
  formatterMultidigitMoney(value) {
    if (typeof value !== "number") {
      value = parseInt(value)
    }
    if (isNaN(value)) {
      console.log("传入的类型不可转成数字")
      value = 0
    }
    return parseFloat(value)
    .toFixed(2)
    .toString()
    .split('')
    .reverse()
    .join('')
    .replace(/(\d{3})/g,'$1,')
    .replace(/\,$/, '')
    .split('')
    .reverse()
    .join('')
  },
  formatterMoney(value) {
    if (typeof value !== "number") {
      value = parseInt(value)
    }
    if (isNaN(value)) {
      console.log("传入的类型不可转成数字")
      value = 0
    }
    return value.toFixed(2)
  },
  mobileFormat(mobile) {
    return mobile.substring(0, 3) + "****" + mobile.substring(7)
  },
  // 时间戳格式化成时间字符串
  formatterTime(time, type = "", F = "-") {
    if (!time) {
      return ""
    }
    const date = new Date(time)
    const year = date.getFullYear() > 9 ? date.getFullYear() : "0" + date.getFullYear()
    const month = (date.getMonth() + 1) > 9 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1)
    const dateDay = date.getDate() > 9 ? date.getDate() : "0" + date.getDate()
    const hours = date.getHours() > 9 ? date.getHours() : "0" + date.getHours()
    const minute = date.getMinutes() > 9 ? date.getMinutes() : "0" + date.getMinutes()
    const second = date.getSeconds() > 9 ? date.getSeconds() : "0" + date.getSeconds()
    if (type == "MD") {
      return `${month}${F}${dateDay}`
    } else if (type == "HMM") {
      return `${hours}:${minute}:${second}`
    } else if (type == "YMD") {
      return `${year}${F}${month}${F}${dateDay}`
    }
    return `${year}${F}${month}${F}${dateDay} ${hours}:${minute}:${second}`
  },
  // 时间戳格式化成时间字符串
  formatterTimeTim(time, type = "", F = "-") {
    if (!time) {
      return ""
    }
    //  今天0点时间
    const dateNow = new Date(new Date(new Date().toLocaleDateString()).getTime());
    const date = new Date(time)
    const year = date.getFullYear() > 9 ? date.getFullYear() : "0" + date.getFullYear()
    const month = (date.getMonth() + 1) > 9 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1)
    const dateDay = date.getDate() > 9 ? date.getDate() : "0" + date.getDate()
    const hours = date.getHours() > 9 ? date.getHours() : "0" + date.getHours()
    const minute = date.getMinutes() > 9 ? date.getMinutes() : "0" + date.getMinutes()
    const second = date.getSeconds() > 9 ? date.getSeconds() : "0" + date.getSeconds()
    if (type == "MD") {
      return `${month}${F}${dateDay}`
    } else if (type == "HMM") {
      return `${hours}:${minute}:${second}`
    } else if (type == "YMD") {
      return `${year}${F}${month}${F}${dateDay}`
    }
    // 今天
    if(date > dateNow){
      return `今天  ${hours}:${minute}`
    } else if(date >= dateNow-(24 * 60 * 60 * 1000)) {
      return `昨天  ${hours}:${minute}`
    } else if(date >= dateNow-(2 * 24 * 60 * 60 * 1000)) {
      return `前天  ${hours}:${minute}`
    }
    return `${year}${F}${month}${F}${dateDay} ${hours}:${minute}:${second}`
  }
}
