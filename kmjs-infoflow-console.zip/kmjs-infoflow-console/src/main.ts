import { createApp } from 'vue';
import App from './App.vue';
import Collapse from '@/views/infoFlow/components/editModules/collapse/collapse.vue';
import router from './router';
import store from './store';

// 初始化样式
import 'normalize.css';
import '@/style/init.less';
import '@/style/global.less';
import '@/style/element.less';
// element-ui-plus
import 'element-plus/lib/theme-chalk/index.css';
import '@/style/elementTheme/index.css';
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import ElementPlus from 'element-plus';
import '@/style/element.less';

window.alert = function () {
  return false;
};

const app = createApp(App);

// 全局注册自定义Collapse组件
app.component('Collapse', Collapse);

// 配置全局color-picker属性颜色选项
app.config.globalProperties.$predefineColors = [
  '#ff3721',
  '#ffffff',
  '#ff8c00',
  '#ffd700',
  '#90ee90',
  '#00ced1',
  '#333333',
  '#666666',
  '#999999',
  'rgba(255, 69, 0, 0.68)',
  'rgb(255, 120, 0)',
  'hsv(51, 100, 98)',
  'hsva(120, 40, 94, 0.5)',
  'hsl(181, 100%, 37%)',
  '#f8f8f8',
  'hsla(209, 100%, 56%, 0.73)'
];

app.use(ElementPlus, { locale: zhCn });

app.use(store).use(router).mount('#app');
