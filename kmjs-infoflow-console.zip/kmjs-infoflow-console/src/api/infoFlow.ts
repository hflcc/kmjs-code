import ajax from '@/utils/axios';

export interface ActionListItem<T> {
  sn: string;
  type: string;
  remoteCallDefMappingSn: T;
  name: string;
  [i: string]: unknown;
}

type FormItemName =
  | 'title' // 表单--标题
  | 'descr' // 表单--标题描述
  | 'action' // 表单--跳转类型
  | 'bottomTitle' // 表单--底部标题
  | 'bottomDescr' // 表单--底部标题描述
  | 'background' // 表单--背景(背景图/背景颜色)
  | 'borderRadius' // 表单--圆角
  | 'margin' // 表单--外边距
  | 'padding' // 表单--内边距
  | 'gridPadding' // 表单--格内边距(grid布局中的row/col)
  | 'height' // 表单--高
  | 'width' // 表单--宽
  | 'categoryProp'; // 表单--分类组属性(仅在分类组容器中展示)

export interface InfoFlowItem {
  sn: string;
  type: string;
  name: string;
  descr?: string | null;
  icon?: string | null;
  maxNum?: number; // 容器有此值,代表容器最大可添加子集数
  contextType: 'container' | 'item'; // container容器  item具体项(组件)
  actionList: ActionListItem<string | null>[];
  // 容器或item的默认属性配置
  property?: {
    padding?: Record<'top' | 'right' | 'bottom' | 'left', number>; // 容器属性
    gridPadding?: Record<'row' | 'col', number>; // 容器属性
    height?: number; // item属性
    borderRadius?: number; // 容器或item属性
    [i: string]: unknown;
  };
  form?: FormItemName[]; // 容器/item组件根据form数组判断展示哪些表单项
  moduleList?: {
    sn: string;
    type: string;
    contextType: 'item';
    name: string;
    remoteCallDefMappingSn: string;
    actionList: ActionListItem<string>[];
    [i: string]: unknown;
  }[];
  componentList?: InfoFlowItem[];
  [i: string]: unknown;
}

/*
 * 根据跳转类型和跳转内容获取信息流跳转信息
 * */
export interface ActionValObj {
  [key: string]: {
    title: string;
    image: string;
    _sn?: string; // 自定义属性sn
    otherBizOptions: string[] | null; // 目前优惠券此字段才有值返回
  };
}
export const getActionValShowAPI = (type: string, values: string): Promise<ActionValObj> => {
  return ajax.get(`/api/info/common/flow/action/data/summary/${type}/${values}`);
};

/*
 * 获取信息流/商品/文章等表格数据
 * */
export interface RemoteMapContentItem {
  image: string;
  sn: string;
  price: number;
  title: string;
  flowTypeName?: string; // 信息流平台中文名
  flowType?: string; // actionType为信息流时会有此值返回
  otherBizOptions: string[]; // 目前优惠券选择会有此字段返回
  _checked?: boolean; // 动态添加的属性
  _imageUrl?: string; // 动态添加的属性
}

interface RemoteMapContent {
  content: RemoteMapContentItem[];
  totalPages: number;
  totalElements: number;
  size: number;
  number: number;
}
export interface RemoteDataReq {
  page: number;
  size: number;
  [i: string]: unknown;
}
export const getRemoteMappingAPI = (
  remoteCallDefMappingSn: string,
  data: RemoteDataReq
): Promise<RemoteMapContent> => {
  return ajax.post(
    `/api/sys/remote/call/${remoteCallDefMappingSn}/kmjs-infoflow-console/origin`,
    data
  );
};

/*
 * 新增信息流实例
 * */
export const addInfoFlowInsAPI = (
  flowSn: string,
  data: { [i: string]: unknown }
): Promise<{ success: boolean; message: string; sn: string }> => {
  return ajax.post(`/api/info/flow/instance/${flowSn}`, data);
};

/*
 * 更新信息流实例
 * */
export const updateInfoFlowInsAPI = (
  flowSn: string,
  data: { [i: string]: unknown }
): Promise<{ success: boolean; message: string; sn: string }> => {
  return ajax.put(`/api/info/flow/instance/${flowSn}`, data);
};

/*
 * 删除信息流实例
 * */
export const deleteInfoFlowInsAPI = (
  flowSn: string
): Promise<{ success: boolean; message: string; sn: null }> => {
  return ajax.delete(`/api/info/flow/instance/${flowSn}`);
};

/*
 * 获取信息流实例(集合)
 * */
interface InfoFlowInsListItem {
  originSn: string;
  rootSn: string;
  sn: string;
  type: string;
  name: string;
  child?: InfoFlowInsListItem[];
  [i: string]: unknown;
}
export const getInfoFlowInsListAPI = (
  flowSn: string,
  parentSn: string
): Promise<InfoFlowInsListItem[]> => {
  return ajax.get(`/api/info/flow/instance/list/${flowSn}/${parentSn}`);
};

type InfoFlowType = 'platform_home' | 'society_home' | 'shop_home';
export const getInfoFlowCompListAPI = (
  type: InfoFlowType
): Promise<{ name: string; data: InfoFlowItem[]; remote: Record<string, unknown> }> => {
  return ajax.get(`/api/info/common/flow/def/detail/${type}`);
};

/*
 * @info 获取信息流详情数据
 * */
export interface InfoFlowDetail {
  relationType: 'platform' | 'society' | 'shop'; // shop店铺 society协会 platform平台
  relationValue: string;
  sn: string;
  name: string;
  state: 'draft'; // draft草稿
  rejectReason: string | null;
  property?: {
    background: Record<'image' | 'color', string>;
    padding: Record<'top' | 'right' | 'bottom' | 'left', number>;
  };
}
export const getInfoFlowDetailAPI = (sn: string): Promise<InfoFlowDetail> => {
  return ajax.get(`/api/info/flow/${sn}`);
};

/*
 * @info 信息流排序接口
 * */
type FlowSortData = { type: 'swap' | 'insert'; sourceSn: string; targetSn: string };
export const setInfoFlowSortAPI = (
  flowSn: string,
  data: FlowSortData
): Promise<{ success: boolean; message: string; sn: string }> => {
  return ajax.put(`/api/info/flow/instance/reorder/${flowSn}`, data);
};

/*
 * @info 信息流整体属性接口
 * */
export interface InfoFlowProperty {
  // 信息流名称
  name?: string;
  // 信息流描述
  descr?: string;
  // 信息流属性 背景 内边距...
  property?: {
    background: Record<'image' | 'color', string>;
    padding: Record<'top' | 'right' | 'bottom' | 'left', number>;
  };
}
export const setInfoFlowPropAPI = (
  flowSn: string,
  data: InfoFlowProperty
): Promise<{ success: boolean; message: string; sn: string }> => {
  return ajax.put(`/api/info/flow/${flowSn}`, data);
};

/*
 * @info 获取信息流背景可选列表
 * */
export interface InfoFlowBgListItem {
  sn: string;
  name: string;
  descr: string;
  ossId: string;
  createBy: number;
  _imageUrl: string;
}
export const getInfoFlowBgListAPI = (appId: string): Promise<InfoFlowBgListItem[]> => {
  return ajax.get(`/api/sys/common/config/theme/list/${appId}`);
};

/*
 * @info 获取平台名称
 * */
interface PlatformInfo {
  name: string;
  clientId: string;
  [i: string]: unknown;
}
export const getPlatformNameAPI = (appId: string): Promise<PlatformInfo> => {
  return ajax.get(`/api/sys/oauth/client/details/${appId}`);
};
