import ajax from '@/utils/axios';

/*
 * @info 获取跳转授权token
 * */
interface GetToken {
  access_token: string;
  token_type: string;
  refresh_token: string;
  expires_in: string;
  scope: string;
}
export const getTokenByTemporaryTokenAPI = (token: string): Promise<GetToken> => {
  return ajax.get(`/api/oauth2/oauth/token?grant_type=jump_token&scope=all&token=${token}`);
};

/*
 * @info 查询临时token信息.
 * */
export interface OtherSysInfoInterface {
  path: string; // 需要跳转的路径
  decorateSn: string; // 需要装修的sn 如店铺sn
  decorateInfoFlowSn: string; // 需要装修的信息流sn
  decorateType: 'platform_home' | 'society_home' | 'shop_home'; // 平台主页/协会主页/店铺主页
  instId: number; // 机构ID
  relationType: 'platform' | 'society' | 'shop';
  relationValue: string;
  appId: string; // appId
  [i: string]: unknown;
}
interface TempTokenInfo {
  data: string; // json字符串  OtherSysInfoInterface
  [i: string]: unknown;
}
export const getInfoByTempTokenAPI = (token: string): Promise<TempTokenInfo> => {
  return ajax.get(`/api/sys/auth/app/jump/instance/${token}`);
};
