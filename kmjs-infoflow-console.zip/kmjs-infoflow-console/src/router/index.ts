import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "Login" */ '../views/login/login')
  },
  {
    path: '/infoflow/index',
    name: 'InfoFlowIndex',
    component: () => import(/* webpackChunkName: "InfoFlowIndex" */ '../views/infoFlow/index.vue')
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

export default router;
