import { Module } from 'vuex';
import { InfoFlowItem } from '@/api/infoFlow';

interface DecorateState {
  infoFlowList: InfoFlowItem[];
  decorateSn: string;
  decorateInfoFlowSn: string;
  remoteReqMap: {
    [i: string]: UnknownObj<unknown>;
  };
}

const decorateModule: Module<DecorateState, RootState> = {
  namespaced: true,
  state: {
    // 店铺装修可以选择的信息流数组
    infoFlowList: [],
    // 正在装修的店铺/平台/协会sn...
    decorateSn: '',
    // 正在装修的信息流sn
    decorateInfoFlowSn: '',
    // 请求商品/店铺/文章等参数集合
    remoteReqMap: {}
  },
  mutations: {
    /*
     * @info 设置店铺装修信息流可选容器类型
     * */
    setInfoFlowList(state, list: InfoFlowItem[]) {
      state.infoFlowList = list;
    },
    setDecorateSn(state, sn: string) {
      state.decorateSn = sn;
    },
    setDecorateInfoFlowSn(state, sn: string) {
      state.decorateInfoFlowSn = sn;
    },
    setRemoteReqMap(state, obj: DecorateState['remoteReqMap']) {
      state.remoteReqMap = obj;
    }
  },
  getters: {
    // 信息流装修可选的容器组件
    decorateComponentObj(state) {
      return state.infoFlowList.reduce((obj: { [i: string]: unknown }, cur: InfoFlowItem) => {
        obj[cur.type as string] = cur.componentList || [];
        return obj;
      }, {});
    },
    // 店铺装饰可选的模块item组件
    decorateModuleObj(state) {
      return state.infoFlowList.reduce((obj: { [i: string]: unknown }, cur: InfoFlowItem) => {
        obj[cur.type as string] = cur.moduleList || [];
        return obj;
      }, {});
    },
    // 获取所有容器或项目对应的中文名称 如image对应图片 image_text对应图文
    containerOrItemName(state) {
      const obj = {} as { [i: string]: string };
      const getName = (arr: InfoFlowItem[]) => {
        arr.forEach((item) => {
          obj[item.type as string] = item.name;
          if (item.moduleList?.length) {
            getName(item.moduleList);
          }
        });
      };
      getName(state.infoFlowList);
      return obj;
    },
    // 将后台返回的信息actionList拍平成对象key value形式, 方便后面取值
    actionListMap(state) {
      const obj = {} as { [sn: string]: InfoFlowItem };
      const getList = (arr: InfoFlowItem[]) => {
        arr.forEach((item) => {
          if (item.actionList) {
            obj[item.sn as string] = item;
          }
          if (item.moduleList?.length) {
            getList(item.moduleList);
          }
          if (item.componentList?.length) {
            getList(item.componentList);
          }
        });
      };
      getList(state.infoFlowList);
      return obj;
    },
    // 容器最大可添加子集数
    containerMaxChildNum(state) {
      const obj = {} as { [i: string]: number };
      const getNum = (arr: InfoFlowItem[]) => {
        arr.forEach((item) => {
          if (item.contextType === 'container') {
            obj[item.sn] = item.maxNum as number;
          }
          if (item.componentList?.length) {
            getNum(item.componentList);
          }
        });
      };
      getNum(state.infoFlowList);
      return obj;
    }
  },
  actions: {}
};

export default decorateModule;
