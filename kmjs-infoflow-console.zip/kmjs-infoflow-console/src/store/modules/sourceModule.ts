import { ActionContext, Module } from 'vuex';
import { getFileUrlBySeq } from '@/utils/commApi';
import { keys } from 'lodash-es';

const sourceModule: Module<SourceStore, RootState> = {
  namespaced: true,
  state: {
    ossUrl: {}
  },
  mutations: {
    SET_OSS_URL_DATA(state, data) {
      state.ossUrl = Object.assign(state.ossUrl, data);
    }
  },
  actions: {
    async getOssUrl({ state, commit }: ActionContext<SourceStore, RootState>, seqs: string[]) {
      seqs = [...new Set(seqs)];
      const obj: Record<string, { url: string; seq: string }> = {};
      for (let i = 0; i < seqs.length; i++) {
        const s = seqs[i];
        if (state.ossUrl[s]) {
          obj[s] = {
            url: state.ossUrl[s]?.url,
            seq: s
          };
          seqs.splice(i--, 1);
        }
      }
      if (seqs.length) {
        const res = await getFileUrlBySeq(seqs.join(','));
        if (!res) {
          return obj;
        }
        seqs.forEach((seq) => {
          // 这里将url截掉过期时间
          res[seq] && (res[seq].url = res[seq]?.url?.split('?')[0]);
        });
        for (let i = 0; i < seqs.length; i++) {
          const s = seqs[i];
          if (res[s]) {
            obj[s] = {
              url: res[s]?.url,
              seq: s
            };
            seqs.splice(i--, 1);
          }
        }
        commit('SET_OSS_URL_DATA', res);
      }
      return obj;
    }
  }
};

export default sourceModule;
