import { createStore } from 'vuex';
import createPersistedState from 'vuex-persistedstate';
import sourceModule from './modules/sourceModule';
import decorateModule from './modules/decorateModule';
import { OtherSysInfoInterface } from '@/api/login';

export default createStore({
  state: {
    ACCESS_TOKEN: '',
    // 存储从其他系统平台带过来的参数信息
    OTHER_SYS_INFO: {} as OtherSysInfoInterface,
    // 装修类型中文名称  如: 店铺装修/平台装修...
    DEC_TYPE_NAME: ''
  },
  mutations: {
    SET_DEC_TYPE_NAME(state, name: string) {
      state.DEC_TYPE_NAME = name;
    },
    SET_OTHER_SYS_INFO(state, params: OtherSysInfoInterface) {
      state.OTHER_SYS_INFO = params;
    },
    SET_ACCESS_TOKEN(state, token: string) {
      state.ACCESS_TOKEN = token;
    }
  },
  actions: {},
  modules: {
    sourceModule,
    decorateModule
  },
  plugins: [
    createPersistedState({
      key: 'decorateVuex',
      storage: window.sessionStorage
    })
  ]
});
