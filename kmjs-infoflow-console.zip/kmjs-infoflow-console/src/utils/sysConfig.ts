const env = process.env.VUE_APP_ENV;

let previewUrl = '';
switch (env) {
  case 'development': // 本地开发
    previewUrl = 'http://192.168.31.42:3000';
    break;
  case 'test': // 测试环境
    previewUrl = 'https://info-flow-dev.kmyun.cn';
    break;
  case 'production': // 生产环境
    previewUrl = 'https://info-flow.kmyun.cn';
    break;
  default:
    break;
}

export default {
  // 平台ID
  clientId: 'BF4ACB5F26D8_2',
  // clientSecret
  clientSecret: 'C3BB2385D8464650B99CDA5DCB8132',
  // 信息流预览url
  previewUrl
};
