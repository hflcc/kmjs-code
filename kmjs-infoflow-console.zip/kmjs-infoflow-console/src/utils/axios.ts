import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import store from '@/store';
import { ElNotification, ElLoading, ElMessageBox } from 'element-plus';
import { ILoadingInstance } from 'element-plus/es/el-loading/src/loading.type';
import sysConfig from '@/utils/sysConfig';

// const VUE_APP_ENV = process.env.VUE_APP_ENV;
let loading: ILoadingInstance | null;
let loadNum = 0;
/**
 * 关闭loading
 * */
const loadClose = () => {
  loadNum--;
  if (loadNum <= 0) {
    setTimeout(() => {
      loading?.close();
      loading = null;
    }, 200);
  }
};
/**
 * 显示loading
 * */
const showLoad = () => {
  loadNum++;
  if (loading) return;
  loading = ElLoading.service({
    lock: true,
    text: 'Loading',
    spinner: 'el-icon-loading',
    background: 'rgba(0, 0, 0, 0.5)'
  });
};

export interface Res<T> {
  code: number;
  msg: string;
  data: T;
}

// 创建axios实例
const serveice = axios.create({
  withCredentials: true,
  timeout: 60000
});
// 请求文件的实例
const fileServeice = axios.create({
  withCredentials: true,
  timeout: 60000
});

const basicBase64Id = window.btoa(`${sysConfig.clientId}:${sysConfig.clientSecret}`);

const beforeRequest = () => {
  return (config: AxiosRequestConfig) => {
    const accessToken = store.state.ACCESS_TOKEN;
    const instId = store.state.OTHER_SYS_INFO.instId;
    // 获取token api请求头中需要加入base64编码
    if (config.url?.includes('/oauth2/oauth/token')) {
      config.headers.Authorization = `Basic ${basicBase64Id}`;
    } else {
      config.headers.Authorization = `Bearer ${accessToken}`;
      config.headers.InstId = instId || '';
    }
    // 判断请求头中是否设置了不显示loading
    if (config.headers.$noLoading) {
      Reflect.deleteProperty(config.headers, '$noLoading');
    } else {
      showLoad();
    }
    return config;
  };
};

const beforeResponse = (backAll = false) => {
  return (response: AxiosResponse) => {
    loadClose();
    if (backAll) {
      return response;
    }
    return response.data || {};
  };
};

const isLoginInvalid = (code: number) => {
  if (code === 401) {
    ElMessageBox.alert('登录信息已失效', '提示', {
      confirmButtonText: 'OK',
      callback: (action: string) => {
        console.log(action);
      }
    });
    return true;
  }
  return false;
};

interface ErrorResponse {
  response: {
    status: number;
    data: {
      message?: string;
    };
  };
}
const beforeResponseError = (error: ErrorResponse) => {
  loadClose();
  console.log(error.response, 'axios error');
  if (isLoginInvalid(error.response?.status)) return Promise.resolve(false);
  ElNotification({
    type: 'error',
    title: '请求错误',
    message: error.response?.data?.message || '请求错误， 请稍后再试',
    duration: 4000
  });
  return Promise.resolve(false);
};

// 请求拦截
serveice.interceptors.request.use(beforeRequest(), (err) => {
  console.log(err);
});

// 响应拦截
serveice.interceptors.response.use(beforeResponse(), beforeResponseError);

// 请求拦截
fileServeice.interceptors.request.use(beforeRequest(), (err) => {
  console.log(err);
});

// 响应拦截
fileServeice.interceptors.response.use(beforeResponse(true), beforeResponseError);

export const file = (url: string, config?: AxiosRequestConfig): Promise<File> => {
  return fileServeice.get(url, config);
};
export default serveice;
