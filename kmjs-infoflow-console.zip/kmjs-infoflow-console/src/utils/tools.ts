import { useStore } from 'vuex';
import { uploadFile } from '@/utils/commApi';
import { ElMessage } from 'element-plus';

// 创建唯一uuid
export const createUuid = function (): string {
  return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0,
      v = c == 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

// 从store缓存中取出已经加载好的图片url
export const getStoreImgByKey = function (key: string): string {
  const store = useStore();
  return store.state?.sourceModule?.ossUrl[key]?.url ?? '';
};

export const checkDataType = function (payload: unknown): string {
  const map: Record<string, string> = {
    '[object String]': 'string',
    '[object Object]': 'object',
    '[object Array]': 'array',
    '[object Number]': 'number',
    '[object Boolean]': 'boolean',
    '[object Null]': 'null',
    '[object Undefined]': 'undefined',
    '[object Function]': 'function',
    '[object Error]': 'error',
    '[object Symbol]': 'symbol',
    '[object RegExp]': 'regexp',
    '[object Promise]': 'promise'
  };
  const t = Object.prototype.toString.call(payload);
  return map[t] || '';
};

/*
 * @info 上传图片方法 基于vuex source做图片数据缓存
 * */
export const useImageInput = function (
  limitSize: number
): () => Promise<Record<'seq' | 'imgUrl', string> | null> {
  const store = useStore();
  return function () {
    return new Promise((resolve, reject) => {
      let inputElem = document.getElementById('_fileInputElem') as HTMLInputElement;
      if (!inputElem) {
        inputElem = document.createElement('input') as HTMLInputElement;
        inputElem.setAttribute('id', '_fileInputElem');
        inputElem.setAttribute('type', 'file');
        inputElem.setAttribute('accept', 'image/png,image/jpeg,image/jpg,image/gif');
        inputElem.style.display = 'none';
        document.body.appendChild(inputElem);
      }
      if (inputElem) {
        inputElem.value = '';
        inputElem.click();
      }
      const listener = async (e: Event) => {
        const target = e.target as HTMLInputElement;
        const file: File = (target?.files as FileList)[0];
        if (file.size / 1024 / 1024 <= limitSize) {
          const res = await uploadFile(file);
          if (res) {
            const imgInfo = await store.dispatch('sourceModule/getOssUrl', [res.seq]);
            const imgUrl = imgInfo[res.seq]?.url ?? '';
            resolve({ seq: res.seq, imgUrl });
          } else {
            reject(null);
          }
        } else {
          ElMessage.error(`图片超出${limitSize}M限制大小`);
          reject(null);
        }
        inputElem?.removeEventListener('change', listener);
      };
      inputElem?.addEventListener('change', listener);
    });
  };
};

/*
 * @info 根据某个节点sn, 找到树节点sn链(数组), 数组第0位即是树根节点sn
 * */
type Node = { sn: string; child?: Node[]; [i: string]: unknown };
export const findNodeChain = (arr: Node[], sn: string): string[] => {
  const stock: string[] = [];
  let going = true;
  const worker = function (arr: Node[], sn: string) {
    for (let i = 0, len = arr.length; i < len; i++) {
      const item = arr[i];
      if (!going) return;
      stock.push(item.sn);
      if (item.sn == sn) {
        going = false;
      } else if (item.child?.length) {
        worker(item.child, sn);
      } else {
        stock.pop();
      }
    }
    if (going) stock.pop();
  };
  worker(arr, sn);
  return stock;
};
