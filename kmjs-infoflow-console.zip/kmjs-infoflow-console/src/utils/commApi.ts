import ajax from '@/utils/axios';

/**
 * 上传主图
 * @param file 文件
 * @param path {String}
 * */
export const uploadFile = (file: File, path = 'kmjs'): Promise<{ seq: string }> => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('dirName', path);
  return ajax.post<FormData, { seq: string }>('/api/oss/upload/file', formData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });
};
/**
 * 根据seq换取文件的地址
 * */
export const getFileUrlBySeq = (seqs: string): Promise<CommonOssCommonListSeqs> => {
  return ajax.get('/api/oss/common/list/seqs', {
    params: {
      seqs,
      $noLoad: true
    }
  });
};
