import { defineComponent, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import {
  getInfoByTempTokenAPI,
  getTokenByTemporaryTokenAPI,
  OtherSysInfoInterface
} from '@/api/login';
import { useStore } from 'vuex';
import { ElMessage } from 'element-plus';

export default defineComponent({
  setup() {
    const store = useStore();
    const route = useRoute();
    const router = useRouter();
    const tempToken = route.query.token as string;

    /*
     * @info 根据临时token获取从其他系统带过来的参数信息
     * */
    const getTempTokenParams = async () => {
      const res = await getInfoByTempTokenAPI(tempToken);
      if (res) {
        try {
          const data = JSON.parse(res.data || '{}') as OtherSysInfoInterface;
          // 保存从其他系统带过来的参数信息
          store.commit('SET_OTHER_SYS_INFO', data);
          // 保存需要装修的信息流sn
          store.commit('decorateModule/setDecorateInfoFlowSn', data.decorateInfoFlowSn);
          // 保存需要装修的店铺/平台/协会等sn
          store.commit('decorateModule/setDecorateSn', data.decorateSn);
          // 成功后跳转到参数中配置的路径
          router
            .replace({
              path: data.path
            })
            .catch((err) => {
              ElMessage.error(`跳转失败, ${err}`);
            });
        } catch (err) {
          console.log(err);
        }
      }
    };

    /*
     * @info 根据临时token获取正式token
     * */
    const getToken = async () => {
      const res = await getTokenByTemporaryTokenAPI(tempToken);
      if (res.access_token) {
        store.commit('SET_ACCESS_TOKEN', res.access_token);
        getTempTokenParams().then();
      }
    };

    // todo start 以下代码是临时的, 先给运营看效果调试用
    // const test = () => {
    //   const data = {
    //     path: `/infoflow/index`,
    //     appId: '99599E0DCED4_2',
    //     decorateSn: '8b4cfc7a8bc840799f05601732a6edf3',
    //     decorateInfoFlowSn: route.query.testSn, // activity_home 439deee3789c4c70bf7c1d66c285ef7c
    //     decorateType: 'platform_home',
    //     relationType: 'shop',
    //     relationValue: '8b4cfc7a8bc840799f05601732a6edf3',
    //     instId: 6
    //   };
    //   store.commit('SET_ACCESS_TOKEN', '4770546f-ab43-4763-97df-ec1b47809061');
    //   // 保存从其他系统带过来的参数信息
    //   store.commit('SET_OTHER_SYS_INFO', data);
    //   // 保存需要装修的信息流sn
    //   store.commit('decorateModule/setDecorateInfoFlowSn', data.decorateInfoFlowSn);
    //   // 保存需要装修的店铺/平台/协会等sn
    //   store.commit('decorateModule/setDecorateSn', data.decorateSn);
    //   // 成功后跳转到参数中配置的路径
    //   router
    //     .replace({
    //       path: data.path,
    //       query: {
    //         testSn: route.query.testSn
    //       }
    //     })
    //     .catch((err) => {
    //       ElMessage.error(`跳转失败, ${err}`);
    //     });
    // };
    // todo end 以下代码是临时的, 先给运营看效果调试用

    onMounted(() => {
      if (tempToken && !store.state.ACCESS_TOKEN) {
        getToken().then();
      } else {
        getTempTokenParams().then();
      }
    });
  }
});
