// 树节点类型
type InfoTreeNodeType = 'container' | 'item';
// 容器类型名称
type ContainerName =
  | 'category'
  | 'grid_1_1'
  | 'grid_1_2'
  | 'grid_1_3'
  | 'grid_1_n'
  | 'grid_2_2'
  | 'grid_3_3'
  | 'shape_l'
  | 'shape_y'
  | 'grid_1_4'
  | 'grid_1_5'
  | 'grid_2_3'
  | 'grid_2_4'
  | 'grid_2_5';
// item组件类型
type ItemName =
  | 'table'
  | 'image_text1'
  | 'goods1'
  | 'goods2'
  | 'shop1'
  | 'shop2'
  | 'article1'
  | 'society1'
  | 'banner'
  | 'advert'
  | 'activity1'
  | 'activity2'
  | 'ticket4'
  | 'ticket5';
