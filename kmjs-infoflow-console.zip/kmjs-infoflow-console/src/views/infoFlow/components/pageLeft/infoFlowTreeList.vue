<template>
  <div class="comp-list">
    <div class="comp-desc">
      <el-button class="ml-10px" @click="handleAddComp" size="small" icon="el-icon-plus"
        >添加容器</el-button
      >
    </div>
    <div class="tree-list">
      <draggable
        v-bind="dragOptions"
        v-model="containerList"
        tag="transition-group"
        :component-data="{
          tag: 'ul',
          type: 'transition-group',
          name: !dragging ? 'flip-list' : null
        }"
        @start="dragging = true"
        @end="dragging = false"
        item-key="sn"
        @change="handleDragChange"
      >
        <template #item="{ element, index }">
          <li
            class="tree-list--item"
            :style="{ cursor: dragOptions.disabled ? 'no-drop' : 'move' }"
          >
            <comp-tree :datas="element" :index="index"></comp-tree>
          </li>
        </template>
      </draggable>
      <!--存放分类组数据-->
      <ul v-if="categoryList.length">
        <li
          class="tree-list--item"
          style="cursor: no-drop"
          v-for="item in categoryList"
          :key="item.sn"
        >
          <comp-tree :datas="item" :index="containerList.length"></comp-tree>
        </li>
      </ul>
    </div>
  </div>

  <!--选择一级容器弹窗-->
  <add-container-dialog
    v-model="containerDialogState.showDialog"
    :infoFlowList="infoFlowList"
    @on-confirm="getContainerDialogVal"
  ></add-container-dialog>

  <!--选择子容器弹窗-->
  <add-child-dialog
    v-model="childDialogState.showDialog"
    :edit-datas="childDialogState.editDatas"
    @on-confirm="getChildDialogVal"
  ></add-child-dialog>

  <!--动态的编辑组件-->
  <component
    v-if="editState.show"
    v-model="editState.show"
    :is="editState.dynamicComp"
    :editItem="editState.editItem"
    @on-confirm="handleEditConfirm"
  ></component>
</template>

<script lang="ts">
  import {
    defineComponent,
    reactive,
    toRefs,
    provide,
    computed,
    defineAsyncComponent,
    nextTick,
    markRaw,
    onMounted,
    inject
  } from 'vue';
  import type { Component } from 'vue';
  import compTree from './compTree.vue';
  import {
    InfoFlowItem,
    getInfoFlowInsListAPI,
    deleteInfoFlowInsAPI,
    setInfoFlowSortAPI
  } from '@/api/infoFlow';
  import addChildDialog from './addChildDialog.vue';
  import { cloneDeep, merge } from 'lodash-es';
  import { useStore } from 'vuex';
  import addContainerDialog from './addContainerDialog.vue';
  import { ElMessage } from 'element-plus';
  import {
    deleteTreeNode,
    InfoFlowTreeNode,
    getDynamicEditComponent,
    CompTreeState,
    useChildDialogState,
    useContainerDialogState,
    useIsCategory
  } from './pageLeftHooks';
  import draggable from 'vuedraggable';
  import { checkDataType } from '@/utils/tools';

  const useEditState = function () {
    interface EditState {
      show: boolean;
      editItem: InfoFlowTreeNode;
      dynamicComp: Component | null;
    }
    const editState = reactive<EditState>({
      show: false,
      editItem: {} as InfoFlowTreeNode,
      dynamicComp: null
    });
    return {
      editState
    };
  };

  export default defineComponent({
    name: 'InfoFlowTreeList',
    components: {
      compTree,
      draggable,
      addChildDialog,
      addContainerDialog
    },
    props: {
      // 是否是 子信息流, 即分类组点击跳转到另一个信息流
      isChildInfoFlow: {
        type: Boolean,
        default: false
      },
      // 如果当前是子信息流, 必须传入categoryParentSn
      categoryParentSn: {
        type: String,
        default: ''
      },
      // 信息流sn
      infoFlowSn: {
        type: String,
        default: ''
      }
    },
    setup(props) {
      const store = useStore();
      const onPageViewRefresh = inject('onPageViewRefresh') as () => void;
      const state = reactive<CompTreeState>({
        containerList: [], // 除分类组外的信息流数据
        categoryList: [] // 分类组数据
      });
      /*
       * @info 获取信息流实例列表集合
       * */
      const getInfoFlowInsList = async () => {
        const res = await getInfoFlowInsListAPI(
          props.infoFlowSn,
          props.isChildInfoFlow ? props.categoryParentSn : 'main'
        );
        if (Array.isArray(res)) {
          // 这里区分过滤分类组数组和普通容器数组
          state.categoryList = res.filter(
            (item) => useIsCategory(item.name, state).isCategory
          ) as InfoFlowTreeNode[];
          state.containerList = res.filter(
            (item) => !useIsCategory(item.name, state).isCategory
          ) as InfoFlowTreeNode[];
        }
      };
      // 容器选择弹窗hooks
      const { containerDialogState, getContainerDialogVal } = useContainerDialogState(state, props);
      // 子容器选择弹窗hooks
      const { childDialogState, getChildDialogVal, handleUpdateInfoFlow } =
        useChildDialogState(state);
      // 可供选择的信息流信息数组
      const infoFlowList = computed(() => {
        const arr = store.state.decorateModule.infoFlowList;
        // 如果当前是子信息流时过滤掉分类组category, 即子信息流不能再嵌套分类组, 信息流最多嵌一重分类组
        if (props.isChildInfoFlow) {
          return arr.filter((item: InfoFlowItem) => !useIsCategory(item.type, state).isCategory);
        }
        return arr;
      });
      // 定义点击编辑树节点的编辑状态
      const { editState } = useEditState();

      /*
       * @info 根据sn查找树形结构中的数据进行删除,为多重嵌套子组件调用
       * */
      provide(
        'delContainerOrChildBySn',
        async (delSn: string, level: number, rootSn: string, source: InfoFlowTreeNode) => {
          const { operateList } = useIsCategory(source.name, state);
          // 如果容器层级是0,即最外层容器,删除此节点需要调后台接口删除,其它调用更新信息流实例接口即可
          if (level === 0) {
            const res = await deleteInfoFlowInsAPI(delSn);
            // 刷新iframe信息流预览窗口
            onPageViewRefresh();
            if (!res.success) return;
            deleteTreeNode(operateList, delSn);
            return;
          }
          deleteTreeNode(operateList, delSn);
          const res = await handleUpdateInfoFlow(rootSn, source);
          if (!res.success) {
            await getInfoFlowInsList();
          }
        }
      );

      /*
       * @info 编辑模块, 为子/孙组件调用
       * */
      provide('handleShowEdit', (editItem: InfoFlowTreeNode) => {
        editState.show = false;
        // 缓存当前编辑的是哪个树节点
        editState.editItem = editItem;
        editState.dynamicComp = null;
        // 动态获取编辑组件
        const dynamicComp = getDynamicEditComponent(editItem.type, editItem.name);
        if (checkDataType(dynamicComp) === 'promise') {
          editState.dynamicComp = markRaw(
            defineAsyncComponent(
              () => dynamicComp as Promise<{ default: { [i: string]: unknown } }>
            )
          );
        }
        nextTick(() => (editState.show = true));
      });

      /*
       * @info 点击添加一级容器组件
       * */
      const handleAddComp = () => {
        containerDialogState.showDialog = true;
      };

      /*
       * @info 由动态编辑弹窗组件触发确定按钮
       * */
      const handleEditConfirm = async (formData: {
        action?: { type: string | null; value: string };
        [i: string]: unknown;
      }) => {
        // 后台action.type使用的是枚举类型, 直接传空会导致报错, 修改传值为null
        if (formData.action && formData.action.type === '') {
          formData.action.type = null;
        }
        // 将编辑弹窗中的表单数据合并到原先缓存好的编辑组件中
        // *** 注意: 如果formData对象中含有数组属性, 请先在各编辑组件中先清空数组(参考bannerEdit组件), lodash合并数组是递归合并,而不是覆盖 ***
        merge(editState.editItem, formData);
        // 更新信息流实例
        const res = await handleUpdateInfoFlow(editState.editItem?.rootSn, editState.editItem);
        if (res.success) {
          ElMessage.success('编辑保存成功');
        } else {
          await getInfoFlowInsList();
        }
      };

      /*
       * @info 信息流树拖动改变时触发
       * @tips 注意: 分类组不在此拖动列表中, 即分类组永远在信息流最下面,不支持拖动
       * */
      const handleDragChange = async (evt: { [i: string]: unknown }) => {
        const { element, newIndex, oldIndex } = evt.moved as {
          element: InfoFlowTreeNode;
          newIndex: number;
          oldIndex: number;
          [i: string]: unknown;
        };
        // 根据新旧下标判断元素是上移还是下移
        if (newIndex === oldIndex) return;
        // 下移就是被拖动对象上面那一个sn 上移就是被拖动对象下面那一个sn
        const targetSn =
          newIndex - oldIndex > 0
            ? state.containerList[newIndex - 1]?.sn
            : state.containerList[newIndex + 1]?.sn;
        const res = await setInfoFlowSortAPI(props.infoFlowSn, {
          type: 'insert',
          sourceSn: element.sn,
          targetSn
        });
        // 刷新iframe信息流预览窗口
        onPageViewRefresh();
        if (!res) {
          ElMessage.error('信息流移动失败');
          await getInfoFlowInsList();
        }
      };

      onMounted(() => {
        getInfoFlowInsList();
      });

      return {
        ...toRefs(state),
        childDialogState,
        containerDialogState,
        getContainerDialogVal,
        getChildDialogVal,
        infoFlowList,
        handleAddComp,
        editState,
        handleEditConfirm,
        handleDragChange,
        onPageViewRefresh,
        dragging: false,
        dragOptions: {
          animation: 200,
          disabled: false
        }
      };
    }
  });
</script>

<style lang="less" scoped>
  .ml-10px {
    margin-left: 10px;
  }
  .flip-list-move {
    transition: transform 0.5s;
  }
  .comp-list {
    display: flex;
    flex-direction: column;
    background: #fff;
    flex: 1;
    overflow-y: hidden;
    .comp-desc {
      padding: 15px;
      border-bottom: 1px solid #eee;
      background: #fff;
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
    .tree-list {
      flex: 1;
      overflow-y: auto;
      &--item {
        padding: 10px;
        background: #f8f8f8;
        margin-bottom: 10px;
      }
    }
  }
</style>
