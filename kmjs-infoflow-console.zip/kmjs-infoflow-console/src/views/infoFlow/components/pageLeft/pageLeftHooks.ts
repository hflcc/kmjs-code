// 信息流树节点接口描述
import { useStore } from 'vuex';
import { provide, reactive, inject } from 'vue';
import { addInfoFlowInsAPI, updateInfoFlowInsAPI } from '@/api/infoFlow';
import { ElMessage } from 'element-plus';

// 信息流树节点接口描述
export interface InfoFlowTreeNode {
  // 节点类型
  readonly type: 'container' | 'item';
  // 标记后台返回时原始的sn
  readonly originSn: string;
  // 节点名称
  readonly name: ContainerName | ItemName;
  // 当前节点sn
  readonly sn: string;
  // 节点树根节点sn
  readonly rootSn: string;
  // 容器或item组件圆角
  borderRadius?: number;
  // 容器、组件标题
  title?: Record<'name' | 'color', string>;
  // 容器特有属性 容器底部标题
  bottomTitle?: Record<'name' | 'color', string>;
  // 容器特有属性 容器背景
  background?: Record<'image' | 'color', string>;
  // 容器特有属性 容器外边距
  margin?: Record<'top' | 'left' | 'right' | 'bottom', number>;
  // 容器特有属性 容器内边距
  padding?: Record<'top' | 'left' | 'right' | 'bottom', number>;
  // 容器特有属性 容器格内边距
  gridPadding?: Record<'row' | 'col', number>;
  // 容器、组件描述
  descr?: Record<'name' | 'color', string>;
  // 容器特有属性 容器底部描述
  bottomDescr?: Record<'name' | 'color', string>;
  // 特殊字段 如轮播图会有此字段
  data?: {
    itemList?: { [i: string]: unknown }[];
    [i: string]: unknown;
  };
  // 组件内容
  biz?: {
    value: string;
  };
  // 组件封面图
  coverImages?: Array<{ ossId: string }>;
  // 容器、组件跳转类型
  action?: Record<'type' | 'value', string>;
  child?: InfoFlowTreeNode[]; // 容器container才有child属性
  categoryProp?: Record<'highlightColor' | 'defaultColor', string>; //分类组容器才有的属性
  [i: string]: unknown;
}

export interface CompTreeState {
  containerList: InfoFlowTreeNode[];
  categoryList: InfoFlowTreeNode[];
}

interface ChildDialogReturn {
  childDialogState: {
    editDatas: InfoFlowTreeNode;
    showDialog: boolean;
  };
  getChildDialogVal: (obj: InfoFlowTreeNode) => Promise<void>;
  handleUpdateInfoFlow: (rootSn: string, source: InfoFlowTreeNode) => Promise<{ success: boolean }>;
}

interface ContainerDialogReturn {
  containerDialogState: {
    showDialog: boolean;
  };
  getContainerDialogVal: (item: InfoFlowTreeNode) => Promise<void>;
}

// 判断是否操作的是分类组, 分类组跟其他容器放的变量有所不同, 这里统一判断
export const useIsCategory = (
  name: string,
  state: CompTreeState
): {
  isCategory: boolean;
  operateList: InfoFlowTreeNode[];
} => {
  const bool = ['category', 'table'].includes(name);
  return {
    isCategory: bool,
    operateList: bool ? state?.categoryList : state?.containerList
  };
};

/*
 * @info 根据sn标识,删除某个树节点
 * */
export const deleteTreeNode = (arr: InfoFlowTreeNode[], delSn: string): void => {
  const delFn = (arr: InfoFlowTreeNode[], sn: string) => {
    for (let i = 0, len = arr?.length; i < len; i++) {
      const item = arr[i];
      if (item.sn === sn) {
        arr.splice(i, 1);
        return;
      } else if (item.child?.length) {
        delFn(item.child, sn);
      }
    }
  };
  delFn(arr, delSn);
};

/*
 * @info 获取信息流动态的编辑组件
 * */
export const getDynamicEditComponent = (
  type: string,
  name: ContainerName | ItemName
): Promise<{ default: { [i: string]: unknown } }> | void => {
  // 如果是容器编辑, 所有类型的容器共用同一个编辑组件
  if (type === 'container') {
    return import(/* webpackChunkName: "containerEdit" */ '../editModules/containerEdit.vue');
    // 如果是组件item编辑, 需要区分具体类型编辑
  } else if (type === 'item') {
    switch (name) {
      case 'banner': // 轮播图
        return import(/* webpackChunkName: "bannerEdit" */ '../editModules/bannerEdit.vue');
      case 'advert': // 广告
        return import(/* webpackChunkName: "advertEdit" */ '../editModules/advertEdit.vue');
      case 'table': // 表格
        return import(/* webpackChunkName: "tabEdit" */ '../editModules/tabEdit.vue');
      case 'goods1': // 商品 类型1
      case 'goods2': // 商品 类型2
        return import(/* webpackChunkName: "goodsEdit" */ '../editModules/goodsEdit.vue');
      case 'shop1': // 店铺 类型1
      case 'shop2': // 店铺 类型2
        return import(/* webpackChunkName: "shopEdit" */ '../editModules/shopEdit.vue');
      case 'article1': // 文章 类型1
        return import(/* webpackChunkName: "articleEdit" */ '../editModules/articleEdit.vue');
      case 'society1': // 协会 类型1
        return import(/* webpackChunkName: "societyEdit" */ '../editModules/societyEdit.vue');
      // case 'ticket1': // 商品优惠券
      // case 'ticket2': // 店铺优惠券
      // case 'ticket3': // 优惠券
      case 'ticket4': // 店铺优惠券
      case 'ticket5': // 商品优惠券
        return import(/* webpackChunkName: "TicketEdit" */ '../editModules/ticketEdit.vue');
      case 'activity1': // 活动 类型1
      case 'activity2': // 活动 类型2
        return import(/* webpackChunkName: "activityEdit" */ '../editModules/activityEdit.vue');
      case 'image_text1': // 图文 类型1
        return import(/* webpackChunkName: "imageTextEdit" */ '../editModules/imageTextEdit.vue');
      default:
        console.log('找不到对应的编辑组件,什么也不返回');
        break;
    }
  }
};

/*
 * @info 选择子容器container/组件item弹窗
 * */
export const useChildDialogState = function (state: CompTreeState): ChildDialogReturn {
  const store = useStore();
  const onPageViewRefresh = inject('onPageViewRefresh') as () => void;
  const childDialogState = reactive({
    editDatas: {} as InfoFlowTreeNode,
    showDialog: false
  });
  /*
   * @info 更新信息流实例
   * */
  const handleUpdateInfoFlow = async (
    rootSn: string,
    source: InfoFlowTreeNode
  ): Promise<{ success: boolean }> => {
    if (!rootSn) {
      console.error('未找到树根节点sn');
      return Promise.resolve({ success: false });
    }
    const { operateList } = useIsCategory(source.name, state);
    const rootNode = operateList.find((item) => item.sn === rootSn) as InfoFlowTreeNode;
    // 更新信息流实例 注意: **更新节点时,始终是要拿树中的根节点sn请求接口,即当前树第一层节点
    const res = await updateInfoFlowInsAPI(rootSn, rootNode);
    // 刷新iframe信息流预览窗口
    onPageViewRefresh();
    return res;
  };
  // 提供给子/孙组件调用更新信息流实例方法
  provide('handleUpdateInfoFlow', handleUpdateInfoFlow);
  /*
   * @info 由子组件选择子容器/组件触发，获取弹窗中选中的子节点数据, 添加到节点树中
   * */
  const getChildDialogVal = async (obj: InfoFlowTreeNode) => {
    const { operateList } = useIsCategory(obj.name, state);
    childDialogState.editDatas?.child?.push({
      ...obj,
      parentSn: childDialogState.editDatas.sn
    });
    const res = await handleUpdateInfoFlow(obj.rootSn, obj);
    if (!res.success) {
      ElMessage.error('新增节点失败, 请重试');
      deleteTreeNode(operateList, obj.sn);
    }
  };
  // 为子节点调用, 点击添加的时候缓存当前添加的是哪个节点
  provide('callParentSelect', (caller: InfoFlowTreeNode) => {
    // 如果当前节点是容器节点, 判断当前节点是否已经达到后台接口限制添加的数量
    if (caller.type === 'container') {
      const { child, originSn } = caller;
      const maxChildNumObj = store.getters['decorateModule/containerMaxChildNum'];
      const maxNum = maxChildNumObj[originSn];
      if (child && maxNum !== 0 && child.length >= maxNum) {
        ElMessage.error(`已达容器最大添加数: ${maxNum}`);
        return;
      }
    }
    childDialogState.editDatas = caller;
    childDialogState.showDialog = true;
  });
  return { childDialogState, getChildDialogVal, handleUpdateInfoFlow };
};

/*
 * @info 选择一级容器弹窗
 * */
export const useContainerDialogState = function (
  state: CompTreeState,
  props: UnknownObj<unknown>
): ContainerDialogReturn {
  const containerDialogState = reactive({
    showDialog: false
  });
  // 获取容器中选择的值
  const getContainerDialogVal = async (item: InfoFlowTreeNode) => {
    if (props.isChildInfoFlow) {
      item.parentSn = props.categoryParentSn;
    }
    // 新增信息流实例
    const res = await addInfoFlowInsAPI(props.infoFlowSn as string, item);
    if (res.success) {
      const { operateList } = useIsCategory(item.name, state);
      operateList.push(item);
    }
  };
  return {
    containerDialogState,
    getContainerDialogVal
  };
};
