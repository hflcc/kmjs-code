<script lang="tsx">
  import { computed, defineComponent } from 'vue';
  import type { PropType } from 'vue';
  import compTreeNode from './compTreeNode.vue';
  import { InfoFlowItem } from '@/api/infoFlow';
  import { useStore } from 'vuex';
  import { getStoreImgByKey } from '@/utils/tools';

  export default defineComponent({
    name: 'CompTree',
    props: {
      datas: {
        type: Object as PropType<InfoFlowItem>,
        default: () => ({})
      },
      index: {
        type: Number,
        default: 0
      }
    },
    components: {
      compTreeNode
    },
    setup(props) {
      const store = useStore();
      // 第一层容器的缩略图
      const contImgUrl = computed(() => {
        const list = store.state.decorateModule.infoFlowList;
        const item = list.find((item: InfoFlowItem) => item.type === props.datas.name);
        return getStoreImgByKey(item?.icon);
      });

      return () => (
        <div class="comp-tree">
          <div class="comp-tree-img">
            <div>
              <div class="sort-num">#{props.index + 1}</div>
              <el-image src={contImgUrl.value} fit="fill" />
            </div>
          </div>
          <comp-tree-node datas={props.datas} />
        </div>
      );
    }
  });
</script>

<style lang="less" scoped>
  .comp-tree {
    position: relative;
    &-img {
      position: absolute;
      left: 0;
      height: 100%;
      width: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      .sort-num {
        width: 100%;
        color: #888;
        text-align: center;
      }
    }
  }
</style>
