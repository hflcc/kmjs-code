<template>
  <el-dialog title="请选择容器或组件" top="5vh" v-model="showDialog" :close-on-click-modal="false">
    <div class="dialog-content">
      <el-form>
        <el-form-item label="类型:">
          <el-select v-model="selectedCtxVal" @change="handleCtxChange">
            <el-option
              v-for="item in ctxList"
              :value="item.value"
              :label="item.label"
              :key="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="内容:">
          <div class="dialog-content">
            <ul class="dialog-content--list">
              <li
                @click.stop="selectedContentIndex = index"
                :class="['list-item']"
                v-for="(item, index) in contentList"
                :key="item.sn"
              >
                <div :class="['list-item--div', { 'high-light': selectedContentIndex === index }]">
                  <el-image
                    fit="fill"
                    style="height: 108px"
                    :src="getStoreImgByKey(item.icon)"
                  ></el-image>
                </div>
                <p style="margin-left: 10px; line-height: 1">{{ item.name }}</p>
              </li>
            </ul>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showDialog = false">取 消</el-button>
        <el-button type="primary" @click="handleDialogConfirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, ref, computed, watch } from 'vue';
  import type { PropType } from 'vue';
  import { InfoFlowItem } from '@/api/infoFlow';
  import { createUuid, getStoreImgByKey } from '@/utils/tools';
  import { ElMessage } from 'element-plus';
  import { useStore } from 'vuex';
  import { InfoFlowTreeNode } from './pageLeftHooks';

  export default defineComponent({
    name: 'AddChildDialog',
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editDatas: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const store = useStore();
      // 选中的类型
      const selectedCtxVal = ref('');
      // 当前可选的内容list
      const contentList = ref([] as InfoFlowItem[]);
      // 选中的内容类型下标
      let selectedContentIndex = ref<number | null>(null);
      // 控制弹窗显示/隐藏
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val: boolean) {
          emit('update:modelValue', val);
        }
      });
      const createGetter = (getter: string) => {
        const obj = store?.getters[getter] ?? {};
        return obj[props.editDatas.name] || [];
      };
      // 当前弹窗中可选的容器组件
      const componentList = computed(() => createGetter('decorateModule/decorateComponentObj'));
      // 当前弹窗中可选的module模块item组件
      const moduleList = computed(() => createGetter('decorateModule/decorateModuleObj'));
      // 当前可选的类型
      const ctxList = ref<{ label: string; value: string }[]>([]);

      /*
       * @info 初始化当前组件内变量
       * */
      const init = () => {
        selectedContentIndex.value = null;
        contentList.value = [];
      };

      /*
       * @info 初始化当前可选类型
       * */
      const initCtxList = () => {
        const arr = [
          { label: '组件', value: 'item' },
          { label: '容器', value: 'container' }
        ];
        const initCtxVal = () => {
          // 默认选中第一个类型渲染内容
          selectedCtxVal.value = ctxList.value[0]?.value;
          handleCtxChange();
        };
        // 如果是分类组, 只能显示组件
        if (props.editDatas.name === 'category') {
          ctxList.value = arr.slice(0, 1);
          initCtxVal();
          return;
        }
        // 如果当前容器中componentList数组有长度, 说明可以选容器/组件
        if (componentList.value.length) {
          ctxList.value = arr;
          initCtxVal();
          return;
        }
        // 其余情况容器都是只能选组件
        ctxList.value = arr.slice(0, 1);
        initCtxVal();
      };

      /*
       * @info 类型选项改变时触发
       * */
      const handleCtxChange = () => {
        init();
        switch (selectedCtxVal.value) {
          case 'container':
            contentList.value = (componentList.value as InfoFlowItem[]) ?? [];
            break;
          case 'item':
            contentList.value = (moduleList.value as InfoFlowItem[]) ?? [];
            break;
          default:
            break;
        }
      };

      /*
       * @info 点击弹窗中的确认
       * */
      const handleDialogConfirm = () => {
        if (selectedContentIndex.value === null) {
          ElMessage.error('请选择内容类型');
          return;
        }
        // 调用父组件选中方法传值, 并生成唯一sn
        const item = contentList.value[selectedContentIndex.value];
        const obj: InfoFlowTreeNode = {
          originSn: item.sn, // 标记后台返回数据时原始的sn
          type: item.contextType,
          name: item.type as InfoFlowTreeNode['name'],
          sn: createUuid(),
          rootSn: props.editDatas?.rootSn, // 树根节点sn
          ...(item.property || {}) // 给item组件添加默认样式, 目前有height borderRadius
        };
        // 如果选择的是容器, 需要构建一个child属性为空数组
        if (item.contextType === 'container') {
          obj.child = [];
        }
        emit('on-confirm', obj);
        showDialog.value = false;
      };

      watch(
        () => showDialog.value,
        (newVal) => {
          if (!newVal) {
            init();
            selectedCtxVal.value = '';
          } else {
            initCtxList();
          }
        }
      );
      return {
        ctxList,
        contentList,
        selectedCtxVal,
        selectedContentIndex,
        showDialog,
        handleDialogConfirm,
        handleCtxChange,
        getStoreImgByKey
      };
    }
  });
</script>

<style lang="less" scoped>
  .dialog-content {
    margin-top: 15px;
    &--list {
      display: grid;
      grid-row-gap: 20px;
      grid-column-gap: 10px;
      grid-template-columns: repeat(auto-fit, minmax(220px, 268px));
      grid-template-rows: repeat(auto, 122px);
      overflow-y: auto;
      max-height: 400px;
      min-height: 100px;
      .list-item {
        &--div {
          display: flex;
          align-items: center;
          justify-content: center;
          border: 1px solid #eee;
          border-radius: 5px;
          &.high-light {
            border-color: #0063c8;
          }
        }
        & > p {
          text-align: center;
          margin-top: 8px;
        }
      }
    }
  }
</style>
