<template>
  <div class="page-left">
    <div class="title-box">
      <!--信息流名称-->
      <div class="title">{{ flowDetail?.name }}</div>
      <!--信息流属性编辑-->
      <el-button
        style="min-height: 20px; padding: 8px; margin-left: 20px"
        class="el-icon-setting"
        size="small"
        @click.stop="showFlowPropDialog = true"
      ></el-button>
    </div>
    <info-flow-tree-list :infoFlowSn="infoFlowSn"></info-flow-tree-list>

    <!--分类组信息流-->
    <div class="category-box" v-if="categoryState.show">
      <div class="title-box">
        <el-button
          class="back-btn"
          size="mini"
          icon="el-icon-arrow-left"
          @click.stop="backUpInfoFlow"
          >返回</el-button
        >
        <div class="title">
          <span>分类组</span>
          (<span class="category-name text-hidden">{{ categoryState.editItem?.title?.name }}</span
          >)
          <span>信息流</span>
        </div>
      </div>
      <info-flow-tree-list
        v-if="categoryState.editItem"
        isChildInfoFlow
        :infoFlowSn="infoFlowSn"
        :categoryParentSn="categoryState.editItem.sn"
      ></info-flow-tree-list>
    </div>

    <!--信息流整体属性弹窗-->
    <flow-prop-edit
      v-if="showFlowPropDialog"
      v-model="showFlowPropDialog"
      :editDatas="flowDetail"
      @change="getInfoFlowDetail"
    ></flow-prop-edit>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, provide, reactive, computed, ref } from 'vue';
  import {
    getInfoFlowCompListAPI,
    getInfoFlowDetailAPI,
    InfoFlowDetail,
    InfoFlowItem
  } from '@/api/infoFlow';
  import flowPropEdit from '../editModules/flowPropEdit.vue';
  import infoFlowTreeList from './infoFlowTreeList.vue';
  import { useStore } from 'vuex';
  import { InfoFlowTreeNode } from './pageLeftHooks';

  /*
   * @info 分类组表格信息流
   * */
  const useCategoryState = function () {
    const categoryState = reactive<{ show: boolean; editItem: InfoFlowTreeNode | null }>({
      show: false,
      editItem: null
    });
    provide('handleShowCategoryInfoFlow', (editItem: InfoFlowTreeNode) => {
      categoryState.editItem = editItem;
      categoryState.show = true;
    });
    return {
      categoryState
    };
  };

  export default defineComponent({
    name: 'PageLeft',
    components: {
      infoFlowTreeList,
      flowPropEdit
    },
    setup() {
      const store = useStore();
      const flowDetail = ref<InfoFlowDetail | null>(null);
      const infoFlowSn = computed(() => store.state.decorateModule.decorateInfoFlowSn);
      const { categoryState } = useCategoryState();
      const showFlowPropDialog = ref(false);

      /*
       * @info 收集容器/item的缩略图ossId
       * */
      const collectImg = (data: InfoFlowItem[]): string[] => {
        return data.reduce((total: string[], cur) => {
          cur.icon && total.push(cur.icon as string);
          if (cur.componentList?.length) {
            cur.componentList.forEach((obj) => {
              obj.icon && total.push(obj.icon as string);
            });
          }
          if (cur.moduleList?.length) {
            cur.moduleList.forEach((obj) => {
              obj.icon && total.push(obj.icon as string);
            });
          }
          return total;
        }, []);
      };
      /*
       * @info 获取容器选项数据
       * */
      const getInfoFlowList = async () => {
        const { data, name, remote } = await getInfoFlowCompListAPI(
          store.state.OTHER_SYS_INFO.decorateType
        );
        // 保存装修类型名称
        store.commit('SET_DEC_TYPE_NAME', name);
        // 保存请求获取商品/文章...等参数集合, 即前端枚举好对象, 后台定义请求参数字段和格式
        store.commit('decorateModule/setRemoteReqMap', remote);
        if (Array.isArray(data)) {
          // 取出res数组中的图片ossId, 和可选容器componentList的图片id 以及 可选组件modulelist的图片ossid
          const ossIdList = collectImg(data);
          // 统一收集ossId, 在这里换取图片真实url路径
          if (ossIdList.length) {
            await store.dispatch('sourceModule/getOssUrl', ossIdList);
          }
          // 将处理过数据保存
          store.commit('decorateModule/setInfoFlowList', data);
        }
      };

      /*
       * @info 获取信息流详情
       * */
      const getInfoFlowDetail = async () => {
        const res = await getInfoFlowDetailAPI(infoFlowSn.value);
        if (res) {
          flowDetail.value = res;
        }
      };

      /*
       * @info 点击返回上级主信息流
       * */
      const backUpInfoFlow = () => {
        categoryState.show = false;
      };

      onMounted(() => {
        getInfoFlowList();
        getInfoFlowDetail();
      });

      return {
        infoFlowSn,
        categoryState,
        backUpInfoFlow,
        flowDetail,
        getInfoFlowDetail,
        showFlowPropDialog
      };
    }
  });
</script>

<style lang="less" scoped>
  .text-hidden {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .page-left {
    display: flex;
    flex-direction: column;
    position: relative;
    height: 100%;
    border: 1px solid #eee;
    .title-box {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 50px;
      padding-left: 10px;
      font-size: 16px;
      font-weight: bold;
      .back-btn {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
      }
    }
    .category-box {
      display: flex;
      flex-direction: column;
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      z-index: 2;
      background: #fff;
      .title {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        justify-content: center;
        align-items: center;
        white-space: nowrap;
        .category-name {
          display: inline-block;
          width: 40%;
        }
      }
    }
  }
</style>
