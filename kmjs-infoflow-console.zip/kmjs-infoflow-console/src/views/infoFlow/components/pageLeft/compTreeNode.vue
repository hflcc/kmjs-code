<template>
  <div
    class="comp-tree-node"
    :style="{
      paddingLeft: `${(curLevel + 1) * 25}px`,
      marginLeft: '40px',
      marginTop: `${curLevel !== 0 ? 10 : 0}px`
    }"
  >
    <div class="node-name">
      {{ nodeName }}
      <span style="color: #999; font-size: 12px">层级:{{ curLevel + 1 }}</span>
      <span style="color: #f56c6c" class="ml-20px" v-if="!isEdited">未编辑</span>
    </div>
    <el-button-group>
      <!--添加子集按钮 只有容器才能添加子集-->
      <el-button
        v-if="datas.type === 'container'"
        icon="el-icon-plus"
        @click.stop="handleAddChild"
        size="mini"
      ></el-button>
      <el-button
        v-if="datas.type === 'item' && datas.name === 'table'"
        @click.stop="handleDecorate"
        icon="el-icon-setting"
        size="mini"
      ></el-button>
      <!--编辑当前项-->
      <el-button icon="el-icon-edit" @click.stop="handleEdit" size="mini"></el-button>
      <!--删除当前项-->
      <el-button icon="el-icon-delete" @click.stop="handleDel" size="mini"></el-button>
    </el-button-group>
  </div>
  <template v-if="compTreeChild.length">
    <draggable
      v-bind="dragOptions"
      v-model="compTreeChild"
      tag="transition-group"
      :component-data="{
        tag: 'ul',
        type: 'transition-group',
        name: !dragging ? 'flip-list' : null
      }"
      @start="dragging = true"
      @end="dragging = false"
      item-key="sn"
    >
      <template #item="{ element }">
        <li>
          <comp-tree-node :datas="element" :curLevel="curLevel + 1"></comp-tree-node>
        </li>
      </template>
    </draggable>
    <!--<div v-for="item in datas.child" :key="item.sn">-->
    <!--  <comp-tree-node :datas="item" :curLevel="curLevel + 1"></comp-tree-node>-->
    <!--</div>-->
  </template>
</template>

<script lang="ts">
  import { defineComponent, inject, computed } from 'vue';
  import type { PropType } from 'vue';
  import { ElMessageBox } from 'element-plus';
  import { useStore } from 'vuex';
  import { InfoFlowTreeNode } from './pageLeftHooks';
  import draggable from 'vuedraggable';

  export default defineComponent({
    name: 'CompTreeNode',
    components: {
      draggable
    },
    props: {
      datas: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      },
      // curLevel不需父组件传入, 仅供组件compTreeNode递归自身时传入
      curLevel: {
        type: Number,
        default: 0
      }
    },
    emits: ['update:modelValue'],
    setup(props) {
      const store = useStore();
      // 判断当前节点是否已编辑
      const isEdited = computed(() => {
        const { type, child, name, data, coverImages, biz } = props.datas as InfoFlowTreeNode;
        if (type === 'container') {
          return !!child?.length;
        } else if (type === 'item') {
          switch (name) {
            case 'banner':
              return !!data?.itemList?.length;
            case 'advert':
              return !!coverImages?.length;
            case 'image_text1':
              return !!coverImages?.length;
            case 'table': // 分类组比较特殊, 没有字段可以判断有无添加子信息流, 默认返回true
              return true;
            default:
              return !!biz?.value;
          }
        }
        return true;
      });
      // 注入更新节点函数
      const handleUpdateInfoFlow = inject('handleUpdateInfoFlow') as (
        rootSn: string,
        source: InfoFlowTreeNode
      ) => Promise<{ success: boolean }>;
      // 当前节点的子节点, 可能为空, 此变量暴露给draggable组件
      const compTreeChild = computed({
        get() {
          return (props.datas?.child as InfoFlowTreeNode[]) ?? [];
        },
        set(list: InfoFlowTreeNode[]) {
          Object.assign(props.datas, {
            child: list
          });
          // 组件拖动后触发更新整棵树函数方法
          handleUpdateInfoFlow(props.datas?.rootSn, props.datas);
        }
      });
      // 当前节点中文名称
      const nodeName = computed(() => {
        const obj = store.getters['decorateModule/containerOrItemName'];
        const name = props.datas.name;
        return obj[name];
      });

      // 调用祖父方法调起选择容器弹窗
      const callParentSelect = inject('callParentSelect') as (t: InfoFlowTreeNode) => void;
      // 调用祖父方法删除当前节点以及全部下级节点
      const delContainerOrChildBySn = inject('delContainerOrChildBySn') as (
        delSn: string,
        level: number,
        rootSn: string,
        source: InfoFlowTreeNode
      ) => void;
      // 调用祖父调起编辑模块
      const handleShowEdit = inject('handleShowEdit') as (t: InfoFlowTreeNode) => void;
      // 调用祖父组件打开子信息流 (另一个信息流)
      const handleShowCategoryInfoFlow = inject('handleShowCategoryInfoFlow') as (
        t: InfoFlowTreeNode
      ) => void;
      /*
       * @info 点击+号添加子容器container或者子组件item
       * */
      const handleAddChild = () => {
        callParentSelect(props.datas);
      };

      /*
       * @info 编辑当前项
       * */
      const handleEdit = () => {
        handleShowEdit(props.datas);
      };

      /*
       * @info 分类组下的表格才有装修按钮, 点击进入子信息流
       * */
      const handleDecorate = () => {
        handleShowCategoryInfoFlow(props.datas);
      };

      /*
       * @info 删除当前项
       * */
      const handleDel = () => {
        ElMessageBox.confirm('是否删除当前项及子集', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            const { sn, rootSn } = props.datas;
            delContainerOrChildBySn(sn, props.curLevel, rootSn, props.datas);
          })
          .catch(() => {
            console.log('cancel');
          });
      };

      return {
        isEdited,
        nodeName,
        handleEdit,
        handleDel,
        handleAddChild,
        handleDecorate,
        compTreeChild,
        dragging: false,
        dragOptions: {
          animation: 200,
          disabled: false
        }
      };
    }
  });
</script>

<style lang="less" scoped>
  .flip-list-move {
    transition: transform 0.5s;
  }
  .comp-tree-node {
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    cursor: move;
    .thumb-img {
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }
</style>
