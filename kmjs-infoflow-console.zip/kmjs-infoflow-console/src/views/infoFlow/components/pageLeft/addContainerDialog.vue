<template>
  <el-dialog
    top="5vh"
    title="请选择容器类型"
    v-model="showDialog"
    destroy-on-close
    :close-on-click-modal="false"
  >
    <div>
      <el-input
        v-model="searchVal"
        placeholder="输入容器名称搜索"
        clearable
        style="width: 300px"
      ></el-input>
    </div>
    <div class="dialog-content">
      <ul class="dialog-content--list">
        <li
          @click.stop="selectedIndex = index"
          :class="['list-item', { 'high-light': selectedIndex === index }]"
          v-for="(item, index) in dataList"
          :key="item.sn"
        >
          <el-image
            fit="fill"
            style="width: 80px; height: 50px"
            :src="getStoreImgByKey(item.icon)"
          ></el-image>
          <p style="margin-left: 10px; line-height: 1">{{ item.name }}</p>
        </li>
      </ul>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showDialog = false">取 消</el-button>
        <el-button type="primary" @click="handleDialogConfirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, ref, computed, watch } from 'vue';
  import type { PropType } from 'vue';
  import { InfoFlowItem } from '@/api/infoFlow';
  import { debounce } from 'lodash-es';
  import { createUuid, getStoreImgByKey } from '@/utils/tools';

  export default defineComponent({
    name: 'AddContainerDialog',
    props: {
      infoFlowList: {
        type: Array as PropType<InfoFlowItem[]>,
        default: () => []
      },
      modelValue: {
        type: Boolean,
        default: false
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const selectedIndex = ref<number | null>(null);
      const dataList = ref([] as InfoFlowItem[]);
      const searchVal = ref('');
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const handleDialogConfirm = () => {
        if (selectedIndex.value === null) return;
        const item = dataList.value[selectedIndex.value];
        const uuid = createUuid();
        emit('on-confirm', {
          originSn: item.sn, // 标记后台返回时原始的sn
          type: item.contextType,
          name: item.type,
          child: [],
          sn: uuid, // 前端自己生成sn
          rootSn: uuid, // 一级容器的根节点就是自己, 加入根节点sn, 方便树查找
          ...(item.property || {}) // 给容器添加默认样式,目前有padding 和 gridPadding, margin
        });
        showDialog.value = false;
      };

      /*
       * @info 前端离线模糊搜索容器组件
       * */
      const handleSearch = () => {
        selectedIndex.value = null;
        if (searchVal.value) {
          dataList.value = props.infoFlowList.filter((item) =>
            item.name?.includes(searchVal.value)
          );
        } else {
          dataList.value = props.infoFlowList;
        }
      };

      // 监听搜索输入框值变化, 并使用节流调用搜索函数
      watch(() => searchVal.value, debounce(handleSearch, 500));

      watch(
        () => showDialog.value,
        (newVal) => {
          if (!newVal) {
            selectedIndex.value = null;
            searchVal.value = '';
          } else {
            dataList.value = props.infoFlowList;
          }
        }
      );

      return {
        showDialog,
        selectedIndex,
        handleDialogConfirm,
        searchVal,
        dataList,
        getStoreImgByKey
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/pageLeftAddDialog';
</style>
