<template>
  <div class="img-wrap">
    <el-image :style="style" :fit="fit" :src="imageUrl" :class="[{ 'el-image-border': border }]">
      <template #error>
        <div class="image-slot">
          <i class="el-icon-picture-outline"></i>
        </div>
      </template>
    </el-image>
  </div>
</template>

<script lang="ts">
  import { defineComponent, ref, onMounted, watch } from 'vue';
  import { useStore } from 'vuex';

  export default defineComponent({
    name: 'ImageShow',
    props: {
      ossId: {
        type: String,
        default: ''
      },
      border: {
        type: Boolean,
        default: false
      },
      fit: {
        type: String,
        default: 'fill'
      },
      style: {
        type: Object,
        default: () => ({
          height: '150px'
        })
      }
    },
    setup(props) {
      const store = useStore();
      const imageUrl = ref('');
      const getImageUrl = async () => {
        if (!props.ossId) return;
        const res = await store.dispatch('sourceModule/getOssUrl', [props.ossId]);
        if (res) {
          imageUrl.value = res[props.ossId]?.url ?? '';
        }
      };

      onMounted(() => {
        getImageUrl();
      });

      watch(
        () => props.ossId,
        () => {
          getImageUrl();
        }
      );
      return {
        imageUrl
      };
    }
  });
</script>

<style lang="less" scoped>
  .img-wrap {
    position: relative;
    display: inline-flex;
  }
  .el-image-border {
    border: 1px solid #eee;
  }
</style>
