/**
 * Created by hing on 2021-11-04 11:18
 */
import { useStore } from 'vuex';
import { computed, getCurrentInstance } from 'vue';
import type { ComputedRef } from 'vue';
import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
import { ActionListItem } from '@/api/infoFlow';

interface CompRef<T> {
  (item?: InfoFlowTreeNode): ComputedRef<T>;
}
interface ReturnT<T> {
  (item: InfoFlowTreeNode): T;
}

/*
 * @info 获取当前编辑模块的action跳转类型数组
 * */
export const useGetActionTypeList: CompRef<ActionListItem<string>[]> = (editItem) => {
  const store = useStore();
  return computed(() => {
    const obj = store.getters['decorateModule/actionListMap'];
    return obj[editItem?.originSn as string]?.actionList ?? [];
  });
};

/*
 * @info 获取当前编辑弹窗中的表单项 (只控制显示隐藏)
 * */
export const useGetFormItemList = (editItem: InfoFlowTreeNode): ((type: string) => boolean) => {
  const store = useStore();
  const obj = store.getters['decorateModule/actionListMap'];
  const arr = obj[editItem?.originSn as string]?.form ?? [];
  return function (type) {
    return arr.includes(type);
  };
};

/*
 * @info 获取当前编辑模块的店铺/平台等装修sn
 * */
export const useGetDecorateSn: CompRef<string> = () => {
  const store = useStore();
  return computed(() => store.state.decorateModule.decorateSn);
};

/*
 * @info 获取当前编辑模块的模块名
 * */
export const useGetModuleName = (editItem: InfoFlowTreeNode): string => {
  const store = useStore();
  const obj = store.getters['decorateModule/containerOrItemName'] || {};
  return obj[editItem?.name as string];
};

/*
 * @info 获取item组件默认的高度
 * */
const getDefItemHeight: ReturnT<number> = (editItem) => {
  const map = new Map([
    ['activity1', 280], // 活动类型1
    ['activity2', 125], // 活动类型2
    ['advert', 90], // 广告图
    ['goods1', 143], // 商品类型1
    ['goods2', 285], // 商品类型2
    ['shop1', 104], // 店铺类型1
    ['shop2', 96], // 店铺类型2
    ['article1', 118], // 文章类型1
    ['banner', 178], // 轮播图
    ['society1', 125], // 协会类型1
    ['ticket4', 160], // 店铺优惠券
    ['ticket5', 90], // 商品优惠券
    ['image_text1', 95] // 图文类型1
  ]);
  return map.get(editItem.name) || 120;
};

/*
 * @info 获取组件默认圆角
 * */
const getDefItemRadius: ReturnT<number> = (editItem) => {
  const map = new Map([
    ['ticket4', 0], // 店铺优惠券
    ['ticket5', 0] // 商品优惠券
  ]);
  const val = map.get(editItem.name);
  return typeof val === 'number' ? val : 6;
};

/*
 * @info 获取item默认属性配置, 包括组件高度等, 可以在此扩展默认配置
 * */
export const useDefaultItemConfig: ReturnT<{ height: number; borderRadius: number }> = (
  editItem
) => {
  return {
    height: getDefItemHeight(editItem),
    borderRadius: getDefItemRadius(editItem) // 默认item圆角
  };
};

/*
 * @info 获取全局配置属性, 如colorPicker颜色选择器样式
 * */
export const getGlobalProperties = (globalName: string): unknown => {
  const prop = getCurrentInstance()?.appContext?.config?.globalProperties;
  return prop && prop[globalName];
};

/*
 * @info 针对个别的编辑弹窗(如商品/文章/活动/店铺/协会), 在提交校验数据之前,先处理一次action的值
 * */
export const useHandleActiveValue = (
  state: {
    biz: { value: string };
    action: Record<'type' | 'value', string>;
  },
  type: 'goods' | 'activity' | 'article' | 'shop' | 'society'
): void => {
  if (state.biz.value) {
    if (state.action.type === type) {
      state.action.value = state.biz.value;
    }
  }
};
