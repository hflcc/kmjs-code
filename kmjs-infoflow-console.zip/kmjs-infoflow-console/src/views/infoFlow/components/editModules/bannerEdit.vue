<!--轮播图编辑-->
<template>
  <el-dialog
    :title="'组件编辑: ' + moduleName"
    v-model="showDialog"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    top="3vh"
    lock-scroll
  >
    <div class="edit-module-wrap" v-if="showDialog">
      <div class="edit-form">
        <div class="edit-form--content">
          <el-form ref="formElem" label-width="120px" label-position="left">
            <collapse>
              <template v-slot:base>
                <div class="banner-item" v-for="(item, index) in bannerList" :key="index">
                  <div class="operate-tool">
                    <el-button-group>
                      <el-button
                        :disabled="index === 0"
                        type="text"
                        style="padding: 0 5px"
                        size="mini"
                        icon="el-icon-caret-top"
                        @click="handleToUp(index)"
                      ></el-button>
                      <el-button
                        :disabled="index === bannerList.length - 1"
                        type="text"
                        style="padding: 0 5px"
                        size="mini"
                        icon="el-icon-caret-bottom"
                        @click="handleToDown(index)"
                      ></el-button>
                      <el-button
                        :disabled="bannerList.length === 1"
                        type="text"
                        style="padding: 0 5px"
                        size="mini"
                        icon="el-icon-delete"
                        @click="handleDeleteItem(index)"
                      ></el-button>
                    </el-button-group>
                  </div>
                  <el-form-item label="轮播图片">
                    <upload-image v-model="item.image"></upload-image>
                  </el-form-item>
                  <!--跳转类型/跳转值-->
                  <action-handle :editItem="editItem" v-model:action="item.action"></action-handle>
                </div>
                <el-button
                  class="add-btn"
                  :disabled="bannerList.length === 10"
                  style="width: 70%; display: block; margin-bottom: 30px"
                  icon="el-icon-plus"
                  size="small"
                  @click.stop="handleAddBanner"
                  >添加轮播
                </el-button>
              </template>
              <template v-slot:senior>
                <el-form-item label="组件圆角">
                  <el-input-number
                    size="small"
                    v-model="itemStyle.borderRadius"
                    :min="0"
                    :max="100"
                  ></el-input-number>
                </el-form-item>
                <el-form-item label="组件高度">
                  <el-input-number
                    size="small"
                    v-model="itemStyle.height"
                    :min="50"
                    :max="1000"
                  ></el-input-number>
                </el-form-item>
              </template>
            </collapse>
          </el-form>
        </div>
        <!--编辑保存区域-->
        <div class="edit-form--save">
          <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
          <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts">
  import { computed, defineComponent, onMounted, reactive, ref } from 'vue';
  import type { PropType } from 'vue';
  import { checkDataType } from '@/utils/tools';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import { cloneDeep } from 'lodash-es';
  import { ElMessage } from 'element-plus';
  import uploadImage from './uploadImage/uploadImage.vue';
  import actionHandle from './actionHandle/actionHandle.vue';
  import { useGetDecorateSn, useGetModuleName, useDefaultItemConfig } from './editModuleHooks';

  interface BannerItem {
    image: string;
    action: {
      type: string;
      value: string;
      other?: Record<string, unknown>;
    };
  }

  const createBannerItem = () => {
    const bannerItem = {
      image: '',
      action: {
        type: '',
        value: ''
      }
    };
    return cloneDeep(bannerItem);
  };

  export default defineComponent({
    name: 'BannerEdit',
    components: {
      uploadImage,
      actionHandle
    },
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const decorateSn = useGetDecorateSn();
      const moduleName = useGetModuleName(props.editItem);
      const defConfig = useDefaultItemConfig(props.editItem);
      const bannerList = ref<BannerItem[]>([]);
      const itemStyle = reactive({
        borderRadius: defConfig.borderRadius,
        height: defConfig.height
      });
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      /*
       * @info 点击取消关闭弹窗
       * */
      const handleCloseDialog = () => {
        showDialog.value = false;
      };

      const handleToUp = (index: number) => {
        const cur = bannerList.value[index];
        const pre = bannerList.value[index - 1];
        bannerList.value[index] = pre;
        bannerList.value[index - 1] = cur;
      };
      const handleToDown = (index: number) => {
        const cur = bannerList.value[index];
        const next = bannerList.value[index + 1];
        bannerList.value[index + 1] = cur;
        bannerList.value[index] = next;
      };
      const handleDeleteItem = (index: number) => {
        bannerList.value.splice(index, 1);
      };

      /*
       * @info 点击添加轮播
       * */
      const handleAddBanner = () => {
        bannerList.value.push(createBannerItem());
      };

      /*
       * @info 校验数据的合法性
       * */
      const checkBannerList = () => {
        for (let i = 0, len = bannerList.value.length; i < len; i++) {
          const item = bannerList.value[i];
          if (!item.image) {
            ElMessage.error('请上传轮播图片');
            return false;
          }
          if (item.action.type) {
            if (!item.action.value) {
              ElMessage.error('跳转类型值不能为空');
              return false;
            }
          }
        }
        return true;
      };

      /*
       * @info 点击确定校验数据并传值父组件
       * */
      const handleSave = () => {
        const isValid = checkBannerList();
        if (!isValid) return;
        // 这里解决外层lodash工具库merge数组时, 会进行递归合并, 而不是覆盖, 导致删掉某个数组item时, 外层数据依然合并为未删除之前的数组
        // 所以先清空外层的数据
        Object.assign(props.editItem?.data ?? {}, {
          itemList: []
        });
        const obj = {
          borderRadius: itemStyle.borderRadius,
          height: itemStyle.height,
          data: {
            itemList: bannerList.value
          }
        };
        emit('on-confirm', obj);
        showDialog.value = false;
      };

      /*
       * @info 初始化弹窗数据
       * */
      const initModuleEdit = () => {
        const { borderRadius, height, data } = props.editItem;
        typeof borderRadius === 'number' && (itemStyle.borderRadius = borderRadius);
        typeof height === 'number' && (itemStyle.height = height);
        const datas = (data || {}) as {
          itemList?: BannerItem[];
          [i: string]: unknown;
        };
        if (checkDataType(data) === 'object') {
          bannerList.value = cloneDeep(datas.itemList || []);
        } else {
          bannerList.value.push(createBannerItem());
        }
      };

      onMounted(() => {
        initModuleEdit();
      });

      return {
        itemStyle,
        handleToUp,
        handleToDown,
        handleDeleteItem,
        showDialog,
        moduleName,
        bannerList,
        decorateSn,
        handleAddBanner,
        handleCloseDialog,
        handleSave
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle.less';

  .edit-form--content {
    padding-right: 10px;
  }

  .add-btn {
    width: 70%;
    margin: 10px auto 0;
    display: block;
  }

  .banner-item {
    border: 1px solid #eee;
    padding: 10px;
    margin-bottom: 15px;

    &.active-edit {
      border-color: #0063c8;
    }

    .operate-tool {
      display: flex;
      padding: 0 10px;
      align-items: center;
      justify-content: flex-end;
    }
  }
</style>
