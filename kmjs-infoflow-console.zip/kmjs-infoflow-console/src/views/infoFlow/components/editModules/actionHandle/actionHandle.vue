<template>
  <div class="action-handle">
    <el-form-item label="跳转类型">
      <el-select placeholder="请选择" v-model="actionType" @change="actionValue = ''" clearable>
        <el-option
          v-for="item in actionTypeList"
          :key="item.sn"
          :label="item.name"
          :value="item.type"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="跳转值" v-show="showActionValItem">
      <action-val-show
        :actionList="actionTypeList"
        :actionType="actionType"
        v-model="actionValue"
        @getOtherParams="handleGetOtherParams"
      ></action-val-show>
    </el-form-item>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent, PropType, ref } from 'vue';
  import { useGetActionTypeList } from '../editModuleHooks';
  import { InfoFlowTreeNode } from '../../pageLeft/pageLeftHooks';
  import actionValShow from '../actionValShow/actionValShow.vue';

  interface ActionObj {
    type: string;
    value: string;
    other?: Record<string, unknown>;
  }

  export default defineComponent({
    name: 'ActionHandle',
    components: {
      actionValShow
    },
    props: {
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      },
      action: {
        type: Object as PropType<ActionObj>,
        default: () => ({})
      }
    },
    setup(props) {
      const actionTypeList = useGetActionTypeList(props.editItem);

      // 判断是否需要展示跳转值一项, 注意: 此判断仅为前端展示与否, 实际保存时依然会有数据到后台
      const showActionValItem = computed<boolean>(() => {
        const editItem = props.editItem;
        if (editItem.type === 'item') {
          if (!actionType.value) return false;
          return !!(actionType.value && !editItem.name?.includes(actionType.value));
        }
        return true;
      });

      const actionType = computed<string>({
        get() {
          return props.action.type;
        },
        set(val) {
          Object.assign(props.action, {
            type: val
          });
        }
      });

      const actionValue = computed<string>({
        get() {
          return props.action.value;
        },
        set(val) {
          Object.assign(props.action, {
            value: val
          });
        }
      });

      // 将其他参数other融合到action中返回
      const handleGetOtherParams = (obj: Record<string, unknown>) => {
        Object.assign(props.action, {
          other: {
            flowType: obj.flowType || null
          }
        });
      };

      return {
        showActionValItem,
        actionTypeList,
        actionType,
        actionValue,
        handleGetOtherParams
      };
    }
  });
</script>

<style lang="less"></style>
