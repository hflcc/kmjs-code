<!--店铺编辑-->
<template>
  <el-dialog
    :title="'组件编辑: ' + moduleName"
    v-model="showDialog"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    top="3vh"
    lock-scroll
  >
    <div class="edit-module-wrap" v-if="showDialog">
      <div class="edit-form">
        <div class="edit-form--content">
          <el-form ref="formElem" label-width="120px" label-position="left">
            <collapse>
              <template v-slot:base>
                <el-form-item label="店铺选择">
                  <action-val-show
                    placeholder="点击选择店铺"
                    :actionList="actionTypeList"
                    :actionType="moduleType"
                    v-model="formState.biz.value"
                    @get-action-val="getActionShopVal"
                  ></action-val-show>
                </el-form-item>
                <el-form-item label="店铺封面">
                  <upload-image v-model="formState.coverImages[0].ossId"></upload-image>
                </el-form-item>
                <!--跳转类型/跳转值-->
                <action-handle
                  :editItem="editItem"
                  v-model:action="formState.action"
                ></action-handle>
              </template>
              <template v-slot:senior>
                <el-form-item label="组件高度">
                  <el-input-number
                    size="small"
                    v-model="formState.height"
                    :min="0"
                    :max="1000"
                  ></el-input-number>
                </el-form-item>
                <el-form-item label="组件圆角">
                  <el-input-number
                    size="small"
                    v-model="formState.borderRadius"
                    :min="0"
                    :max="100"
                  ></el-input-number>
                </el-form-item>
              </template>
            </collapse>
          </el-form>
        </div>
        <!--编辑保存区域-->
        <div class="edit-form--save">
          <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
          <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, computed, onMounted, reactive } from 'vue';
  import type { PropType } from 'vue';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import { cloneDeep } from 'lodash-es';
  import { ElMessage } from 'element-plus';
  import uploadImage from './uploadImage/uploadImage.vue';
  import actionValShow from './actionValShow/actionValShow.vue';
  import actionHandle from './actionHandle/actionHandle.vue';
  import {
    useDefaultItemConfig,
    useGetActionTypeList,
    useGetDecorateSn,
    useGetModuleName,
    useHandleActiveValue
  } from './editModuleHooks';

  interface FormState {
    height: number;
    borderRadius: number;
    coverImages: { ossId: string }[];
    biz: {
      value: string;
    };
    action: {
      type: string;
      value: string;
      other?: Record<string, unknown>;
    };
  }

  export default defineComponent({
    name: 'ShopEdit',
    components: {
      uploadImage,
      actionValShow,
      actionHandle
    },
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      // 当前编辑模块 店铺编辑
      const moduleType = 'shop';
      const actionTypeList = useGetActionTypeList(props.editItem);
      const decorateSn = useGetDecorateSn();
      const moduleName = useGetModuleName(props.editItem);
      const defConfig = useDefaultItemConfig(props.editItem);
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const formState = reactive<FormState>({
        height: defConfig.height,
        borderRadius: defConfig.borderRadius,
        coverImages: [],
        biz: {
          value: ''
        },
        action: {
          type: '',
          value: ''
        }
      });

      /*
       * @info 点击取消关闭弹窗
       * */
      const handleCloseDialog = () => {
        showDialog.value = false;
      };

      /*
       * @info 校验数据的合法性
       * */
      const checkFormState = () => {
        if (!formState.biz.value) {
          ElMessage.error('请选择店铺');
          return false;
        }
        if (formState.action.type) {
          if (!formState.action.value) {
            ElMessage.error('跳转类型值不能为空');
            return false;
          }
        }
        return true;
      };

      /*
       * @info 点击确定校验数据并传值父组件
       * */
      const handleSave = () => {
        useHandleActiveValue(formState, moduleType);
        const isValid = checkFormState();
        if (!isValid) return;
        emit('on-confirm', formState);
        showDialog.value = false;
      };

      /*
       * @info 选择店铺内容时，默认将店铺图片设置为店铺封面, 默认将跳转类型设置为店铺, 并将店铺内容设置为跳转内容
       * */
      const getActionShopVal = (val: { image: string; title: string }) => {
        formState.coverImages = [{ ossId: val.image }];
        formState.action.type = moduleType;
        formState.action.value = formState.biz.value;
      };

      /*
       * @info 初始化弹窗数据
       * */
      const initModuleEdit = () => {
        const { coverImages, action, biz, height, borderRadius } = cloneDeep(props.editItem);
        coverImages?.length
          ? (formState.coverImages = coverImages)
          : (formState.coverImages = [{ ossId: '' }]);
        typeof height === 'number' && (formState.height = height);
        typeof borderRadius === 'number' && (formState.borderRadius = borderRadius);
        biz && (formState.biz = biz);
        action && (formState.action = action);
      };

      onMounted(() => {
        initModuleEdit();
      });

      return {
        moduleType,
        showDialog,
        moduleName,
        getActionShopVal,
        formState,
        actionTypeList,
        decorateSn,
        handleCloseDialog,
        handleSave
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle.less';
</style>
