<template>
  <el-dialog
    :title="selectorName + '选择'"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    lock-scroll
    v-model="showSelector"
    top="5vh"
  >
    <div class="dialog-content" v-if="showSelector">
      <el-input
        v-model.trim="searchVal"
        size="small"
        placeholder="输入名称搜索"
        style="width: 50%"
        clearable
      ></el-input>
      <el-button @click.stop="handleSearch" size="small" style="margin-left: 10px">搜索</el-button>
      <el-table
        align="center"
        :data="pageData.tableData"
        style="width: 100%; margin-top: 20px"
        height="50vh"
      >
        <el-table-column label="单选" width="55">
          <template v-slot="{ row }">
            <el-checkbox v-model="row._checked" @change="changeCheckbox(row)"></el-checkbox>
          </template>
        </el-table-column>
        <el-table-column
          v-if="pageData.tableData.find((item) => item.image !== undefined)"
          property="image"
          label="图片"
        >
          <template v-slot="{ row }">
            <el-image
              :src="row._imageUrl"
              style="display: flex; width: 50px; height: 50px"
              fit="fill"
            ></el-image>
          </template>
        </el-table-column>
        <el-table-column property="title" label="名称"></el-table-column>
        <el-table-column
          v-if="pageData.tableData[0] && pageData.tableData[0].price !== undefined"
          property="price"
          label="价格"
        >
        </el-table-column>
      </el-table>
      <el-pagination
        layout="prev, pager, next"
        v-model:current-page="pageData.pageNo"
        :page-size="pageData.pageSize"
        :total="pageData.total"
        @current-change="handlePageChange"
      ></el-pagination>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button size="small" @click="showSelector = false">取 消</el-button>
        <el-button size="small" type="primary" @click="handleConfirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, reactive, computed, onMounted, ref } from 'vue';
  import type { PropType } from 'vue';
  import { getActionValShowAPI } from '@/api/infoFlow';
  import { getFileUrlBySeq } from '@/utils/commApi';
  import { ElMessage } from 'element-plus';
  import { checkDataType } from '@/utils/tools';
  import { cloneDeep } from 'lodash-es';

  interface TableDataItem {
    title: string;
    image: string;
    _sn?: string; //
    _imageUrl?: string;
    _checked?: boolean;
  }

  export default defineComponent({
    name: 'TicketSelector',
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      reqType: {
        type: String,
        default: ''
      },
      reqValues: {
        type: Array as PropType<string[]>,
        default: () => []
      },
      selectorName: String
    },
    setup(props, { emit }) {
      const showSelector = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });
      // 搜索值
      const searchVal = ref('');
      // 后台请求回来的全量数据
      let allData = [] as TableDataItem[];
      // 搜索后的全量数据
      let searchData = [] as TableDataItem[];
      // 是否在搜索中
      const isSearching = ref(false);

      const pageData = reactive({
        total: 0,
        pageNo: 1,
        pageSize: 10,
        tableData: [] as TableDataItem[]
      });

      /*
       * 获取信息流列表
       * */
      const getDataList = async () => {
        const res = await getActionValShowAPI(props.reqType, props.reqValues.join(','));
        // res数据格式为 { sn1: {}, sn2: {} }, 遍历对象, 将key注入到对象value对象中
        for (const element of Object.keys(res)) {
          if (checkDataType(res[element]) === 'object') {
            res[element]._sn = element;
          }
        }
        const content = Object.values(res);
        const ossIdList = content.map((item) => item.image);
        const imgObj = await getFileUrlBySeq(ossIdList.join(','));
        content.forEach((item: TableDataItem) => {
          item._imageUrl = imgObj[item.image]?.url ?? '';
          item._checked = false;
        });
        allData = content;
        renderTable(true);
      };

      const sliceFn = () => {
        const sv = (pageData.pageNo - 1) * pageData.pageSize;
        const start = sv === 0 ? sv : sv + 1;
        const end = pageData.pageNo * pageData.pageSize + 1;
        return {
          start,
          end
        };
      };

      const renderTable = (flag?: boolean) => {
        if (flag) {
          pageData.pageNo = 1;
          pageData.tableData = [];
          pageData.total = 0;
        }
        const { start, end } = sliceFn();
        if (isSearching.value) {
          pageData.total = searchData.length;
          pageData.tableData = cloneDeep(searchData.slice(start, end));
        } else {
          pageData.total = allData.length;
          pageData.tableData = cloneDeep(allData.slice(start, end));
        }
      };

      const handleSearch = () => {
        if (!searchVal.value.trim()) {
          isSearching.value = false;
        } else {
          isSearching.value = true;
          searchData = allData.filter((item) => item.title.includes(searchVal.value));
        }
        renderTable(true);
      };

      const handlePageChange = (curPage: number) => {
        pageData.pageNo = curPage;
        renderTable();
      };

      /*
       * @info 点击确定,调用父组件提交选中的值
       * */
      const handleConfirm = () => {
        const select = pageData.tableData.find((item) => item._checked);
        if (select) {
          emit('on-confirm', {
            sn: select._sn
          });
          showSelector.value = false;
        } else {
          ElMessage.error('请先选择');
        }
      };

      /*
       * @info 表格单选时改变时触发
       * */
      const changeCheckbox = (row: TableDataItem) => {
        pageData.tableData.forEach((item) => {
          item._checked = false;
        });
        row._checked = true;
      };

      onMounted(() => {
        getDataList();
      });

      return {
        searchVal,
        handleConfirm,
        showSelector,
        changeCheckbox,
        pageData,
        handleSearch,
        handlePageChange
      };
    }
  });
</script>

<style lang="less" scoped></style>
