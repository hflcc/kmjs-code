<template>
  <el-dialog
    :title="moduleSelectorName + '选择'"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    lock-scroll
    v-model="showSelector"
    top="5vh"
  >
    <div class="dialog-content" v-if="showSelector">
      <el-input
        v-model="realReq.title"
        size="small"
        placeholder="输入名称搜索"
        style="width: 50%"
        clearable
      ></el-input>
      <el-button @click.stop="handleSearch" size="small" style="margin-left: 10px">搜索</el-button>
      <el-table
        align="center"
        :data="pageData.tableData"
        style="width: 100%; margin-top: 20px"
        height="50vh"
        @row-click="changeCheckbox"
      >
        <el-table-column label="单选" width="55">
          <template v-slot="{ row }">
            <el-checkbox v-model="row._checked" @change="changeCheckbox(row)"></el-checkbox>
          </template>
        </el-table-column>
        <el-table-column
          v-if="pageData.tableData.find((item) => item.image !== undefined)"
          property="image"
          label="图片"
        >
          <template v-slot="{ row }">
            <el-image :src="row._imageUrl" style="width: 50px; height: 50px" fit="fill"></el-image>
          </template>
        </el-table-column>
        <el-table-column property="title" label="名称"></el-table-column>
        <el-table-column
          v-if="pageData.tableData.find((item) => item.flowTypeName !== undefined)"
          property="flowTypeName"
          label="信息流类型"
        ></el-table-column>
        <el-table-column
          v-if="pageData.tableData[0] && pageData.tableData[0].price !== undefined"
          property="price"
          label="价格"
        >
        </el-table-column>
      </el-table>
      <el-pagination
        layout="prev, pager, next"
        :page-size="realReq.size"
        :total="pageData.totalElements"
        @current-change="handlePageChange"
      ></el-pagination>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button size="small" @click="showSelector = false">取 消</el-button>
        <el-button size="small" type="primary" @click="handleConfirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, reactive, computed, onMounted } from 'vue';
  import type { PropType } from 'vue';
  import {
    getRemoteMappingAPI,
    RemoteMapContentItem,
    RemoteDataReq,
    ActionListItem
  } from '@/api/infoFlow';
  import { getFileUrlBySeq } from '@/utils/commApi';
  import { ElMessage } from 'element-plus';
  import { useStore } from 'vuex';
  import { cloneDeep } from 'lodash-es';
  import { checkDataType } from '@/utils/tools';

  interface Obj {
    [i: string]: unknown;
  }

  export default defineComponent({
    name: 'ModuleSelector',
    props: {
      actionList: {
        type: Array as PropType<ActionListItem<string | null>[]>,
        default: () => []
      },
      modelValue: {
        type: Boolean,
        default: false
      },
      actionType: {
        type: String,
        default: ''
      },
      remoteSn: {
        type: String,
        default: ''
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const store = useStore();
      // 店铺装修 店铺sn
      const remoteReqMap = computed(() => store.state.decorateModule.remoteReqMap);
      // 后台定义的请求参数集合
      const decorateSn = computed(() => store.state.decorateModule.decorateSn);
      const decorateInfoFlowSn = computed(() => store.state.decorateModule.decorateInfoFlowSn);
      // 装修类型 如: shop店铺 platform平台...
      const relationType = computed(() => store.state.OTHER_SYS_INFO.relationType);
      const relationValue = computed(() => store.state.OTHER_SYS_INFO.relationValue);
      // 当前模块选择器名称
      const moduleSelectorName = computed(() => {
        const item = props.actionList?.find((item) => item.type === props.actionType);
        return item?.name ?? '';
      });
      // 如果props中remoteSn有值,就取props中的, 否则再去actionList中去找
      const remoteSn = computed(() => {
        if (props.remoteSn) {
          return props.remoteSn;
        }
        const item = props.actionList?.find((item) => item.type === props.actionType);
        return item?.remoteCallDefMappingSn ?? '';
      });
      // 商品搜索方法
      const handleSearch = () => {
        getDataList(true);
      };
      const showSelector = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      /*
       * @info 点击确定,调用父组件提交选中的值
       * */
      const handleConfirm = () => {
        const select = pageData.tableData.find((item) => item._checked);
        if (select) {
          const obj: { sn: string; flowType: string | null; otherBizOptions?: string[] } = {
            sn: select.sn,
            flowType: select.flowType || null // actiontype为信息流时会有此flowType值返回
          };
          // 目前优惠券选择会有此字段返回
          select.otherBizOptions && (obj.otherBizOptions = select.otherBizOptions);
          emit('on-confirm', obj);
          showSelector.value = false;
        } else {
          ElMessage.error('请先选择');
        }
      };

      /*
       * @info 表格单选时改变时触发
       * */
      const changeCheckbox = (row: RemoteMapContentItem) => {
        pageData.tableData.forEach((item) => {
          item._checked = false;
        });
        row._checked = true;
      };

      const pageData = reactive({
        totalElements: 0,
        tableData: [] as RemoteMapContentItem[]
      });

      // 备用请求参数
      const backupParams: Obj = {
        title: '', // 输入的搜索值
        size: 10,
        page: 0,
        shopSn: decorateSn.value,
        relationType: relationType.value,
        state: 'normal',
        relationValue: relationValue.value,
        sn: decorateInfoFlowSn.value
      };

      // 根据remoteSn获取后台接口中定义的请求参数模型
      const remoteReq = cloneDeep(remoteReqMap.value[remoteSn.value]);
      // 根据匹配到的请求参数模型,递归对象从备用请求参数中找到属性并赋值
      const createReq = (item: Obj) => {
        Object.keys(item).forEach((k) => {
          const type = checkDataType(item[k]);
          if (type === 'object') {
            createReq(item[k] as Obj);
          } else if (['null', 'number', 'string'].includes(type)) {
            item[k] = backupParams[k];
          }
        });
        return item;
      };
      // 获取到真实请求后台接口参数
      const realReq = reactive(createReq(remoteReq));
      /*
       * 获取信息流列表
       * */
      const getDataList = async (flag?: boolean) => {
        if (flag) {
          realReq.page = 0;
          pageData.tableData = [];
          pageData.totalElements = 0;
        }

        const { totalElements, content } = await getRemoteMappingAPI(
          remoteSn.value,
          realReq as RemoteDataReq
        );
        if (!content) return;
        pageData.totalElements = totalElements;
        const ossIdList = content.filter((item) => !!item.image).map((item) => item.image);
        const imgObj = await ((ossIdList.length && getFileUrlBySeq(ossIdList.join(','))) || {});
        content.forEach((item: RemoteMapContentItem) => {
          item._imageUrl = imgObj[item.image]?.url ?? '';
          item._checked = false;
        });
        pageData.tableData = content;
      };

      const handlePageChange = (curPage: number) => {
        // 后台接口第一页是0
        realReq.page = curPage - 1;
        getDataList();
      };

      onMounted(() => {
        getDataList(true);
      });

      return {
        realReq,
        moduleSelectorName,
        handleConfirm,
        showSelector,
        changeCheckbox,
        handleSearch,
        pageData,
        handlePageChange
      };
    }
  });
</script>

<style lang="less" scoped></style>
