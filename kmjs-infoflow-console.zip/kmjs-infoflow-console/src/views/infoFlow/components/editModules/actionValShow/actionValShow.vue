<!--此组件用来展示action选中的值-->
<template>
  <div class="action-show-box">
    <!--信息流 类型展示模式-->
    <div
      class="action-val-img"
      v-if="showActionImage && actionType"
      @click.stop="handleShowSelector"
    >
      <template v-if="modelValue">
        <image-show
          v-if="state.imgOssId"
          style="width: 50px; height: 50px"
          :ossId="state.imgOssId"
          fit="fill"
          :clearable="false"
        ></image-show>
        <p class="action-val-name">{{ state.name }}</p>
      </template>
      <div class="action-val-name" v-else>{{ placeholder }}</div>
    </div>
    <!--链接 类型展示模式-->
    <div class="action-val" v-if="showActionInput">
      <el-input v-model="actionValue" placeholder="请输入"></el-input>
    </div>
  </div>

  <module-selector
    v-if="showSelector"
    v-model="showSelector"
    :remoteSn="remoteSn"
    :actionType="actionType"
    :actionList="actionList"
    @on-confirm="handleSelectorConfirm"
  ></module-selector>
</template>

<script lang="ts">
  import { defineComponent, reactive, onMounted, computed, watch, ref } from 'vue';
  import type { PropType } from 'vue';
  import imageShow from '../../imageShow/imageShow.vue';
  import { getActionValShowAPI, ActionListItem } from '@/api/infoFlow';
  import moduleSelector from '../selectors/moduleSelector.vue';

  interface ActState {
    imgOssId: string;
    name: string;
  }

  export default defineComponent({
    name: 'ActionValShow',
    props: {
      placeholder: {
        type: String,
        default: '点击添加跳转内容'
      },
      actionList: {
        type: Array as PropType<ActionListItem<string | null>[]>,
        default: () => []
      },
      actionType: {
        type: String,
        default: ''
      },
      modelValue: {
        type: String,
        default: ''
      },
      remoteSn: {
        type: String,
        default: ''
      },
      flowType: {
        type: String,
        default: ''
      }
    },
    components: {
      imageShow,
      moduleSelector
    },
    emits: ['update:modelValue', 'getOtherParams', 'get-other-biz-opts', 'get-action-val'],
    setup(props, { emit }) {
      const showSelector = ref(false);
      /*
       * @info 展示选择器弹窗
       * */
      const handleShowSelector = () => {
        showSelector.value = true;
      };
      /*
       * @info 获取模块选中器中选中的值
       * */
      const handleSelectorConfirm = (val: {
        sn: string;
        flowType: string | null;
        otherBizOptions?: string[];
      }) => {
        actionValue.value = val.sn;
        emit('getOtherParams', {
          flowType: val.flowType
        });
      };
      const state = reactive<ActState>({
        imgOssId: '',
        name: ''
      });

      const actionValue = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      // 展示链接等输入框
      const showActionInput = computed(() => {
        return ['link'].includes(props.actionType);
      });

      // 展示需要展示图片和文字的action值, 例如商品/活动/文章...
      const showActionImage = computed(() => {
        const arr = ['info_flow', 'goods', 'activity', 'shop', 'article', 'society', 'ticket'];
        return arr.includes(props.actionType);
      });

      /*
       * @info 后台接口获取action选中的值做回显
       * @param flag {Boolean} 是否需要通知父组件, 获取回显的值
       * @tips 组件初始化时不用通知父组件, watch监听主动修改才需要通知父组件
       * */
      const getActValData = async (flag?: boolean) => {
        if (!props.actionType || !props.modelValue || props.actionType === 'link') return;
        const res = await getActionValShowAPI(props.actionType, props.modelValue);
        if (res) {
          const obj = res[props.modelValue] || {};
          state.imgOssId = obj.image;
          state.name = obj.title;
          // otherBizOptions字段值目前在优惠券编辑中会有返回,否则返回null
          if (obj.otherBizOptions) {
            emit('get-other-biz-opts', obj.otherBizOptions);
          }
          flag && emit('get-action-val', obj);
        }
      };

      watch(
        () => props.modelValue,
        (newVal) => {
          if (newVal) {
            getActValData(true);
          }
        }
      );

      onMounted(() => {
        // 有图文信息的action值需要调接口做数据回显
        if (showActionImage.value) {
          getActValData();
        }
      });

      return {
        state,
        actionValue,
        showActionInput,
        showActionImage,
        showSelector,
        handleShowSelector,
        handleSelectorConfirm
      };
    }
  });
</script>

<style lang="less" scoped>
  .dialog-content {
    height: 65vh;
  }
  .action-val-img {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    border: 1px solid #eee;
    padding: 5px;
    border-radius: 5px;
    width: 90%;

    .action-val-name {
      margin-left: 10px;
    }
  }
</style>
