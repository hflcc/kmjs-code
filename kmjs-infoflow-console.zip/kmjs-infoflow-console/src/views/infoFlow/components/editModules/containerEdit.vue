<!--容器编辑-->
<template>
  <div>
    <el-dialog
      v-model="dialogVisible"
      :closeOnClickModal="false"
      :title="'容器编辑: ' + moduleEditName"
      width="70%"
      destroy-on-close
      top="3vh"
      lock-scroll
    >
      <div class="edit-module-wrap" v-if="dialogVisible">
        <!--编辑表单区域-->
        <div class="edit-form">
          <header class="edit-form--content">
            <el-form ref="formElem" :model="formState" label-width="120px" label-position="left">
              <collapse>
                <template v-slot:base>
                  <div v-if="handleShowFormItem('title')">
                    <el-form-item label="标题">
                      <el-input placeholder="请输入" v-model="formState.title.name"></el-input>
                    </el-form-item>
                    <el-form-item label="标题颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.title.color"
                      />
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('descr')">
                    <el-form-item label="描述">
                      <el-input placeholder="请输入" v-model="formState.descr.name"></el-input>
                    </el-form-item>
                    <el-form-item label="描述颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.descr.color"
                      />
                    </el-form-item>
                  </div>
                  <!--跳转类型/跳转值-->
                  <action-handle
                    v-if="handleShowFormItem('action')"
                    :editItem="editItem"
                    v-model:action="formState.action"
                  ></action-handle>
                  <div v-if="handleShowFormItem('bottomTitle')">
                    <el-form-item label="底部标题">
                      <el-input
                        placeholder="请输入"
                        v-model="formState.bottomTitle.name"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="底部标题颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.bottomTitle.color"
                      />
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('bottomDescr')">
                    <el-form-item label="底部描述">
                      <el-input
                        placeholder="请输入"
                        v-model="formState.bottomDescr.name"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="底部描述颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.bottomDescr.color"
                      />
                    </el-form-item>
                  </div>
                  <!--分类组容器时才展示-->
                  <div v-if="handleShowFormItem('categoryProp') && isCategory">
                    <el-form-item label="分类组高亮颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.categoryProp.highlightColor"
                      />
                    </el-form-item>
                    <el-form-item label="分类组默认颜色">
                      <el-color-picker
                        :predefine="predefineColors"
                        v-model="formState.categoryProp.defaultColor"
                      />
                    </el-form-item>
                  </div>
                </template>
                <template v-slot:senior v-if="!isCategory">
                  <div v-if="handleShowFormItem('background')">
                    <el-form-item label="容器背景图">
                      <upload-image v-model="formState.background.image"></upload-image>
                    </el-form-item>
                    <el-form-item label="容器背景色">
                      <el-color-picker
                        v-model="formState.background.color"
                        :predefine="predefineColors"
                      />
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('borderRadius')">
                    <el-form-item label="容器圆角">
                      <el-input-number
                        v-model="formState.borderRadius"
                        :min="0"
                        size="mini"
                      ></el-input-number>
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('margin')">
                    <el-form-item label="容器外边距">
                      <div>
                        <span class="mr-10px">上边距:</span>
                        <el-input-number
                          v-model="formState.margin.top"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('padding')">
                    <el-form-item label="容器内边距">
                      <div>
                        <span class="mr-10px">上边距:</span>
                        <el-input-number
                          v-model="formState.padding.top"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                      <div>
                        <span class="mr-10px">下边距:</span>
                        <el-input-number
                          v-model="formState.padding.bottom"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                      <div>
                        <span class="mr-10px">左边距:</span>
                        <el-input-number
                          v-model="formState.padding.left"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                      <div>
                        <span class="mr-10px">右边距:</span>
                        <el-input-number
                          v-model="formState.padding.right"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                    </el-form-item>
                  </div>
                  <div v-if="handleShowFormItem('gridPadding')">
                    <el-form-item label="格内边距">
                      <div>
                        <span class="mr-10px">横向边距:</span>
                        <el-input-number
                          v-model="formState.gridPadding.row"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                      <div>
                        <span class="mr-10px">纵向边距:</span>
                        <el-input-number
                          v-model="formState.gridPadding.col"
                          :min="0"
                          size="mini"
                        ></el-input-number>
                      </div>
                    </el-form-item>
                  </div>
                </template>
              </collapse>
            </el-form>
          </header>
          <!--编辑保存区域-->
          <footer class="edit-form--save">
            <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
            <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
          </footer>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, computed, reactive } from 'vue';
  import type { PropType } from 'vue';
  import { ElMessage } from 'element-plus';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import uploadImage from './uploadImage/uploadImage.vue';
  import actionHandle from './actionHandle/actionHandle.vue';
  import { getGlobalProperties, useGetModuleName, useGetFormItemList } from './editModuleHooks';
  import { cloneDeep } from 'lodash-es';

  type NameColor = Record<'name' | 'color', string>;
  type EdgeDistance = Record<'top' | 'left' | 'right' | 'bottom', number>;
  interface FormState {
    borderRadius: number;
    background: Record<'image' | 'color', string>;
    margin: EdgeDistance;
    padding: EdgeDistance;
    // 格内边距
    gridPadding: Record<'row' | 'col', number>;
    title: NameColor;
    descr: NameColor;
    bottomTitle: NameColor;
    bottomDescr: NameColor;
    action: {
      type: string;
      value: string;
      other?: Record<string, unknown>;
    };
    // 分类组容器才有的属性
    categoryProp?: Record<'highlightColor' | 'defaultColor', string>;
  }

  export default defineComponent({
    name: 'ContainerEdit',
    components: {
      uploadImage,
      actionHandle
    },
    props: {
      modelValue: Boolean,
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const handleShowFormItem = useGetFormItemList(props.editItem);
      const moduleEditName = useGetModuleName(props.editItem);
      // 判断当前编辑的容器是否分类组
      const isCategory = computed(() => props.editItem?.name === 'category');
      // 控制弹窗显示/隐藏
      const dialogVisible = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });
      const formState = reactive<FormState>({
        // 容器圆角
        borderRadius: 5,
        background: {
          // 容器背景图片ossID
          image: '',
          // 容器背景色
          color: ''
        },
        margin: {
          top: 10,
          right: 0,
          bottom: 0,
          left: 0
        },
        padding: {
          top: 0,
          right: 0,
          bottom: 0,
          left: 0
        },
        gridPadding: {
          row: 5,
          col: 5
        },
        // 容器标题
        title: {
          name: '',
          color: '#333333'
        },
        // 容器描述
        descr: {
          name: '',
          color: ''
        },
        // 底部容器标题
        bottomTitle: {
          name: '',
          color: ''
        },
        // 底部容器描述
        bottomDescr: {
          name: '',
          color: ''
        },
        action: {
          // 容器点击类型
          type: '',
          // 容器点击类型值
          value: '',
          // 点击类型为信息流时,other才有属性
          other: {}
        }
      });

      if (isCategory.value) {
        formState.categoryProp = {
          highlightColor: '#ff3721',
          defaultColor: '#666666'
        };
      }

      /*
       * @info 关闭弹窗
       * */
      const handleCloseDialog = () => {
        dialogVisible.value = false;
      };

      /*
       * @info 校验当前表单
       * */
      const checkForm = () => {
        if (formState.action.type) {
          if (!formState.action.value) {
            ElMessage.error('选择跳转类型后, 跳转值为必填');
            return false;
          }
        }
        return true;
      };

      /*
       * @info 点击保存弹窗中的数据
       * */
      const handleSave = () => {
        if (!checkForm()) return;
        emit('on-confirm', formState);
        dialogVisible.value = false;
      };

      /*
       * @info edit弹窗出来之前先将数据进行回显
       * */
      const initEdit = () => {
        const {
          background,
          title,
          descr,
          bottomTitle,
          bottomDescr,
          action,
          borderRadius,
          padding,
          gridPadding,
          margin,
          categoryProp
        } = cloneDeep(props.editItem);
        if (borderRadius !== undefined) {
          formState.borderRadius = borderRadius;
        }
        background && (formState.background = background);
        margin && (formState.margin = margin);
        padding && (formState.padding = padding);
        gridPadding && (formState.gridPadding = gridPadding);
        title && (formState.title = title);
        descr && (formState.descr = descr);
        bottomTitle && (formState.bottomTitle = bottomTitle);
        bottomDescr && (formState.bottomDescr = bottomDescr);
        action && (formState.action = action);
        isCategory.value && categoryProp && (formState.categoryProp = categoryProp);
      };

      onMounted(() => {
        initEdit();
      });

      return {
        moduleEditName,
        formState,
        dialogVisible,
        handleCloseDialog,
        handleSave,
        isCategory,
        handleShowFormItem,
        predefineColors: getGlobalProperties('$predefineColors')
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle';
</style>
