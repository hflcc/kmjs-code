<!--优惠券编辑-->
<template>
  <el-dialog
    :title="'组件编辑: ' + moduleName"
    v-model="showDialog"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    top="3vh"
    lock-scroll
  >
    <div class="edit-module-wrap" v-if="showDialog">
      <div class="edit-form">
        <div class="edit-form--content">
          <el-form ref="formElem" label-width="120px" label-position="left">
            <collapse>
              <template v-slot:base>
                <el-form-item label="优惠券选择">
                  <action-val-show
                    placeholder="点击选择优惠券"
                    :remoteSn="remoteSn"
                    :actionType="moduleType"
                    v-model="formState.biz.value"
                    @get-other-biz-opts="getOtherBizOpts"
                  ></action-val-show>
                </el-form-item>
                <el-form-item v-if="showRelates" :label="selectorName + '选择'">
                  <div class="goods-show" @click.stop="handleShowSelector">
                    <image-show
                      style="width: 50px; height: 50px"
                      v-if="relates.imageOssId"
                      v-model:ossId="relates.imageOssId"
                    ></image-show>
                    <div class="goods-show--name ml-10px">
                      {{ relates.title || `点击选择关联${selectorName}` }}
                    </div>
                  </div>
                </el-form-item>
                <!--跳转类型/跳转值-->
                <action-handle
                  :editItem="editItem"
                  v-model:action="formState.action"
                ></action-handle>
              </template>
              <template v-slot:senior>
                <el-form-item label="组件高度">
                  <el-input-number
                    size="small"
                    v-model="formState.height"
                    :min="0"
                    :max="1000"
                  ></el-input-number>
                </el-form-item>
                <el-form-item label="组件圆角">
                  <el-input-number
                    size="small"
                    v-model="formState.borderRadius"
                    :min="0"
                    :max="100"
                  ></el-input-number>
                </el-form-item>
              </template>
            </collapse>
          </el-form>
        </div>
        <!--编辑保存区域-->
        <div class="edit-form--save">
          <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
          <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
        </div>
      </div>
    </div>
  </el-dialog>

  <ticket-selector
    v-if="showTicketSelector"
    v-model="showTicketSelector"
    :req-type="ticketSelectType"
    :selectorName="selectorName"
    :req-values="ticketBizOpts"
    @on-confirm="getTicketSelectorVal"
  ></ticket-selector>
</template>

<script lang="ts">
  import { defineComponent, ref, computed, onMounted, reactive, watch } from 'vue';
  import type { PropType } from 'vue';
  import { useStore } from 'vuex';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import { cloneDeep } from 'lodash-es';
  import actionValShow from './actionValShow/actionValShow.vue';
  import actionHandle from './actionHandle/actionHandle.vue';
  import imageShow from '../imageShow/imageShow.vue';
  import { ElMessage } from 'element-plus';
  import { useGetModuleName, useDefaultItemConfig } from './editModuleHooks';
  import ticketSelector from './selectors/ticketSelector.vue';
  import { getActionValShowAPI } from '@/api/infoFlow';

  interface FormState {
    height: number;
    borderRadius: number;
    biz: {
      value: string;
    };
    action: {
      type: string;
      value: string;
      other?: Record<string, unknown>;
    };
    otherBizList: { type: string; value: string }[];
  }

  export default defineComponent({
    name: 'goodsTicketEdit',
    components: {
      actionValShow,
      imageShow,
      actionHandle,
      ticketSelector
    },
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const defConfig = useDefaultItemConfig(props.editItem);
      const moduleName = useGetModuleName(props.editItem);
      // 是否展示关联商品/店铺表单项
      const showRelates = computed(() => {
        return ['ticket1', 'ticket2', 'ticket3'].includes(props.editItem?.name);
      });
      // 当前编辑模块 票券编辑
      const moduleType = 'ticket';
      // 优惠券选择类型
      const ticketSelectType = computed(() => {
        const obj: { [i: string]: string } = {
          ticket1: 'goods', // 商品优惠券
          ticket2: 'shop', // 店铺优惠券
          ticket3: 'platform', // 平台优惠券
          ticket4: 'shop', // 店铺优惠券
          ticket5: 'goods' // 商品优惠券
        };
        return obj[props.editItem.name];
      });
      // 选择器名称
      const selectorName = computed(() => {
        const obj: { [i: string]: string } = {
          ticket1: '商品',
          ticket2: '店铺',
          ticket3: '平台',
          ticket4: '店铺',
          ticket5: '商品'
        };
        return obj[props.editItem.name];
      });
      const store = useStore();
      let ticketBizOpts = ref<string[]>([]);
      // 选中后需要展示的商品
      const relates = reactive({
        imageOssId: '',
        title: '',
        sn: ''
      });
      const remoteSn = computed(() => {
        const obj = store.getters['decorateModule/actionListMap'];
        return obj[props.editItem?.originSn as string]?.remoteCallDefMappingSn ?? [];
      });
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const showTicketSelector = ref(false);

      /*
       * @info 获取弹窗中选中的关联商品/店铺
       * */
      const getTicketSelectorVal = (val: { sn: string }) => {
        formState.otherBizList = [{ value: val.sn, type: 'goods' }];
        getRelateShow(val.sn);
      };

      /*
       * @info 将关联商品/店铺进行数据回显
       * */
      const getRelateShow = async (sn: string) => {
        const res = await getActionValShowAPI(ticketSelectType.value, sn);
        if (res) {
          const obj = res[sn];
          relates.imageOssId = obj.image;
          relates.title = obj.title;
        }
      };

      const formState = reactive<FormState>({
        height: defConfig.height,
        borderRadius: defConfig.borderRadius,
        biz: {
          value: ''
        },
        action: {
          type: '',
          value: ''
        },
        otherBizList: []
      });

      /*
       * @info 点击取消关闭弹窗
       * */
      const handleCloseDialog = () => {
        showDialog.value = false;
      };

      /*
       * @info 校验数据的合法性
       * */
      const checkFormState = () => {
        if (!formState.biz.value) {
          ElMessage.error('请选择优惠券');
          return false;
        }
        if (showRelates.value && !formState.otherBizList[0]?.value) {
          ElMessage.error('请选择关联商品');
          return false;
        }
        return true;
      };

      /*
       * @info 点击确定校验数据并传值父组件
       * */
      const handleSave = () => {
        const isValid = checkFormState();
        if (!isValid) return;
        emit('on-confirm', formState);
        showDialog.value = false;
      };
      /*
       * @info 获取商品biz选项参数
       * */
      const getOtherBizOpts = (val: string[]) => {
        ticketBizOpts.value = val;
      };

      /*
       * @info 根据ticketBizOpts中的商品sn数组, 获取商品列表供用户选择
       * */
      const handleShowSelector = () => {
        if (!ticketBizOpts.value.length) {
          ElMessage.error('请先选择优惠券');
          return;
        }
        showTicketSelector.value = true;
      };

      watch(
        () => formState.biz.value,
        () => {
          formState.otherBizList = [];
          relates.title = '';
          relates.imageOssId = '';
          relates.sn = '';
        }
      );

      /*
       * @info 初始化弹窗数据
       * */
      const initModuleEdit = () => {
        const { biz, otherBizList, action, height, borderRadius } = cloneDeep(props.editItem);
        typeof height === 'number' && (formState.height = height);
        typeof borderRadius === 'number' && (formState.borderRadius = borderRadius);
        biz && (formState.biz = biz);
        action && (formState.action = action);
        if (showRelates.value && otherBizList) {
          formState.otherBizList = otherBizList as FormState['otherBizList'];
          const sn = (otherBizList as FormState['otherBizList'])[0].value;
          getRelateShow(sn);
        }
      };

      onMounted(() => {
        initModuleEdit();
      });

      return {
        relates,
        showRelates,
        moduleType,
        showDialog,
        moduleName,
        selectorName,
        getOtherBizOpts,
        formState,
        remoteSn,
        handleCloseDialog,
        handleSave,
        handleShowSelector,
        showTicketSelector,
        ticketBizOpts,
        ticketSelectType,
        getTicketSelectorVal
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle.less';
  .goods-show {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    border: 1px solid #eee;
    padding: 5px;
    border-radius: 5px;
    width: 90%;
  }
</style>
