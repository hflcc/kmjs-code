<template>
  <el-dialog title="信息流属性设置" top="5vh" v-model="showDialog" :close-on-click-modal="false">
    <div class="dialog-content">
      <el-form>
        <el-form-item label="背景图" style="width: 100%">
          <ul class="bg-list">
            <li
              :class="['bg-list-item', { selected: formState.background.image === item.ossId }]"
              v-for="item in flowBgList"
              :key="item.ossId"
              @click="chooseBgItem(item)"
            >
              <el-image
                style="display: block; font-size: 0"
                :src="item._imageUrl"
                fit="fill"
              ></el-image>
            </li>
          </ul>
        </el-form-item>
        <el-form-item label="内边距">
          <!--          <div>
            <span class="mr-10px">上边距:</span>
            <el-input-number v-model="formState.padding.top" :min="0" size="mini"></el-input-number>
          </div>
          <div>
            <span class="mr-10px">下边距:</span>
            <el-input-number
              v-model="formState.padding.bottom"
              :min="0"
              size="mini"
            ></el-input-number>
          </div>-->
          <div>
            <span class="mr-10px">左边距:</span>
            <el-input-number
              v-model="formState.padding.left"
              :min="0"
              size="mini"
            ></el-input-number>
          </div>
          <div>
            <span class="mr-10px">右边距:</span>
            <el-input-number
              v-model="formState.padding.right"
              :min="0"
              size="mini"
            ></el-input-number>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showDialog = false">取 消</el-button>
        <el-button type="primary" @click="handleDialogConfirm">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, ref, computed, reactive, onMounted, inject } from 'vue';
  import type { PropType } from 'vue';
  import { useStore } from 'vuex';
  import {
    InfoFlowDetail,
    setInfoFlowPropAPI,
    getInfoFlowBgListAPI,
    InfoFlowBgListItem
  } from '@/api/infoFlow';
  import { cloneDeep } from 'lodash-es';
  import { getGlobalProperties } from './editModuleHooks';

  interface FormState {
    background: Record<'image' | 'color', string>;
    padding: Record<'top' | 'right' | 'bottom' | 'left', number>;
  }

  export default defineComponent({
    name: 'InfoFlowPropEdit',
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editDatas: {
        type: Object as PropType<InfoFlowDetail>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'change'],
    setup(props, { emit }) {
      const store = useStore();
      const flowSn = computed(() => store.state.decorateModule.decorateInfoFlowSn);
      const appId = computed(() => store.state.OTHER_SYS_INFO.appId);
      const onPageViewRefresh = inject('onPageViewRefresh') as () => void;
      const flowBgList = ref<InfoFlowBgListItem[]>([]);
      // 控制弹窗显示/隐藏
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val: boolean) {
          emit('update:modelValue', val);
        }
      });

      const formState = reactive<FormState>({
        background: {
          image: '',
          color: ''
        },
        padding: {
          top: 0,
          bottom: 0,
          right: 10,
          left: 10
        }
      });

      /*
       * @info 点击弹窗中的确认
       * */
      const handleDialogConfirm = async () => {
        const res = await setInfoFlowPropAPI(flowSn.value, {
          property: {
            background: formState.background,
            padding: formState.padding
          }
        });
        if (res) {
          // 刷新预览界面
          onPageViewRefresh();
          showDialog.value = false;
          emit('change', formState);
        }
      };

      const initPropEdit = () => {
        const { property } = cloneDeep(props.editDatas);
        if (property) {
          property.background && (formState.background = property.background);
          property.padding && (formState.padding = property.padding);
        }
      };

      /*
       * @Info 获取信息流背景图列表
       * */
      const getBgList = async () => {
        const res = await getInfoFlowBgListAPI(appId.value);
        if (res) {
          const ossIds = res.map((item) => item.ossId);
          const datas = await store.dispatch('sourceModule/getOssUrl', ossIds);
          res.forEach((item) => (item._imageUrl = datas[item.ossId]?.url ?? ''));
          flowBgList.value = res;
        }
      };

      const chooseBgItem = (item: InfoFlowBgListItem) => {
        if (formState.background.image === item.ossId) {
          formState.background.image = '';
        } else {
          formState.background.image = item.ossId;
        }
      };

      onMounted(() => {
        initPropEdit();
        getBgList();
      });

      return {
        showDialog,
        formState,
        handleDialogConfirm,
        flowBgList,
        chooseBgItem,
        predefineColors: getGlobalProperties('$predefineColors')
      };
    }
  });
</script>

<style lang="less" scoped>
  .bg-list {
    display: grid;
    grid-gap: 15px;
    grid-template-columns: repeat(auto-fill, 100px);
    grid-template-rows: auto;
    max-height: 300px;
    overflow-y: auto;
    padding: 10px;
    &-item {
      &.selected {
        border: 1px solid #0063c8;
        box-shadow: 0 0 6px 1px #0063c8;
        transform: scale(1.06);
        transform-origin: 50% 50%;
      }
    }
  }
</style>
