<!--广告图编辑-->
<template>
  <el-dialog
    :title="'组件编辑: ' + moduleName"
    v-model="showDialog"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    top="3vh"
    lock-scroll
  >
    <div class="edit-module-wrap" v-if="showDialog">
      <div class="edit-form">
        <div class="edit-form--content">
          <el-form ref="formElem" label-width="120px" label-position="left">
            <collapse>
              <template v-slot:base>
                <el-form-item label="展示图片">
                  <upload-image v-model="formState.coverImages[0].ossId"></upload-image>
                </el-form-item>
                <el-form-item label="文案标题">
                  <el-input
                    clearable
                    v-model="formState.title.name"
                    placeholder="请输入展示文案"
                  ></el-input>
                </el-form-item>
                <el-form-item label="文案颜色">
                  <el-color-picker :predefine="predefineColors" v-model="formState.title.color" />
                </el-form-item>
                <!--跳转类型/跳转值-->
                <action-handle
                  :editItem="editItem"
                  v-model:action="formState.action"
                ></action-handle>
              </template>
              <template v-slot:senior>
                <el-form-item label="组件圆角">
                  <el-input-number
                    size="small"
                    v-model="formState.borderRadius"
                    :min="0"
                    :max="100"
                  ></el-input-number>
                </el-form-item>
                <el-form-item label="组件高度">
                  <el-input-number
                    size="small"
                    v-model="formState.height"
                    :min="0"
                    :max="1000"
                  ></el-input-number>
                </el-form-item>
                <el-form-item label="组件宽度">
                  <el-input-number
                    size="small"
                    v-model="formState.width"
                    :min="0"
                    :max="1000"
                  ></el-input-number>
                </el-form-item>
              </template>
            </collapse>
          </el-form>
        </div>
        <!--编辑保存区域-->
        <div class="edit-form--save">
          <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
          <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, computed, onMounted, reactive } from 'vue';
  import type { PropType } from 'vue';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import { cloneDeep } from 'lodash-es';
  import { ElMessage } from 'element-plus';
  import uploadImage from './uploadImage/uploadImage.vue';
  import actionHandle from './actionHandle/actionHandle.vue';
  import { useGetModuleName, useDefaultItemConfig, getGlobalProperties } from './editModuleHooks';

  interface FormState {
    borderRadius: number;
    height: number;
    width: number;
    title: {
      name: string;
      color: string;
    };
    coverImages: { ossId: string }[];
    action: {
      type: string | null;
      value: string;
      other?: Record<string, unknown>;
    };
  }

  export default defineComponent({
    name: 'ImageTextEdit',
    components: {
      uploadImage,
      actionHandle
    },
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const moduleName = useGetModuleName(props.editItem);
      const defConfig = useDefaultItemConfig(props.editItem);
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const formState = reactive<FormState>({
        borderRadius: defConfig.borderRadius,
        width: 70,
        height: defConfig.height,
        title: {
          name: '',
          color: '#333333'
        },
        coverImages: [],
        action: {
          type: null,
          value: ''
        }
      });

      /*
       * @info 点击取消关闭弹窗
       * */
      const handleCloseDialog = () => {
        showDialog.value = false;
      };

      /*
       * @info 获取动态组件中选中的值
       * */
      const getEditSelectChoose = (val: { sn: string }) => {
        // action.value存储的是字符串, 代表最终的sn值或者其他如链接这样的字符串
        formState.action.value = val.sn;
      };

      /*
       * @info 校验数据的合法性
       * */
      const checkFormState = () => {
        if (!formState.coverImages[0]?.ossId) {
          ElMessage.error('请上传图片');
          return false;
        }
        if (formState.action.type) {
          if (!formState.action.value) {
            ElMessage.error('跳转类型值不能为空');
            return false;
          }
        }
        return true;
      };

      /*
       * @info 点击确定校验数据并传值父组件
       * */
      const handleSave = () => {
        const isValid = checkFormState();
        if (!isValid) return;
        emit('on-confirm', formState);
        showDialog.value = false;
      };

      /*
       * @info 初始化弹窗数据
       * */
      const initModuleEdit = () => {
        const { coverImages, action, borderRadius, height, title, width } = cloneDeep(
          props.editItem
        );
        title && (formState.title = title);
        coverImages?.length
          ? (formState.coverImages = coverImages)
          : (formState.coverImages = [{ ossId: '' }]);
        formState.action = action || formState.action;
        typeof height === 'number' && (formState.height = height);
        typeof borderRadius === 'number' && (formState.borderRadius = borderRadius);
        typeof width === 'number' && (formState.width = width);
      };

      onMounted(() => {
        initModuleEdit();
      });

      return {
        showDialog,
        moduleName,
        formState,
        handleCloseDialog,
        getEditSelectChoose,
        handleSave,
        predefineColors: getGlobalProperties('$predefineColors')
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle.less';
</style>
