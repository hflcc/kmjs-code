<template>
  <div class="image-box" @click.stop="handleUpload">
    <image-show
      border
      v-if="imageOssId"
      style="height: 150px"
      v-model:ossId="imageOssId"
      fit="fill"
    ></image-show>
    <div class="clear-img" @click.stop="handleClearImg" v-if="imageOssId">
      <i class="el-icon-delete"></i>
    </div>
    <div v-else class="empty-text">+ 添加图片</div>
  </div>
</template>

<script lang="ts">
  import { computed, defineComponent } from 'vue';
  import imageShow from '../../imageShow/imageShow.vue';
  import { useImageInput } from '@/utils/tools';

  export default defineComponent({
    name: 'UploadImage',
    props: {
      modelValue: {
        type: String,
        default: ''
      }
    },
    components: {
      imageShow
    },
    emits: ['update:modelValue'],
    setup(props, { emit }) {
      // 限制图片上传大小为1M
      const uploadImgUtils = useImageInput(1);

      const imageOssId = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const handleUpload = async () => {
        const res = await uploadImgUtils();
        if (res) {
          imageOssId.value = res.seq;
        }
      };

      // 清除图片
      const handleClearImg = () => {
        imageOssId.value = '';
      };

      return {
        handleUpload,
        imageOssId,
        handleClearImg
      };
    }
  });
</script>

<style lang="less" scoped>
  .image-box {
    position: relative;
    display: inline-block;
    padding-right: 30px;
    .clear-img {
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
    }
  }
</style>
