<!--分类组tab编辑-->
<template>
  <el-dialog
    :title="'组件编辑: ' + moduleName"
    v-model="showDialog"
    destroy-on-close
    width="70%"
    :close-on-click-modal="false"
    top="3vh"
    lock-scroll
  >
    <div class="edit-module-wrap" v-if="showDialog">
      <div class="edit-form">
        <div class="edit-form--content">
          <el-form ref="formElem" label-width="120px" label-position="left">
            <collapse>
              <template v-slot:base>
                <el-form-item label="标题">
                  <el-input
                    style="max-width: 60%"
                    v-model="formState.title.name"
                    placeholder="请输入"
                    clearable
                    maxlength="10"
                  ></el-input>
                </el-form-item>
                <el-form-item label="描述">
                  <el-input
                    style="max-width: 60%"
                    placeholder="请输入"
                    v-model="formState.descr.name"
                    clearable
                    maxlength="10"
                  ></el-input>
                </el-form-item>
              </template>
            </collapse>
          </el-form>
        </div>
        <!--编辑保存区域-->
        <div class="edit-form--save">
          <el-button size="small" @click.stop="handleCloseDialog">取消</el-button>
          <el-button type="primary" size="small" @click.stop="handleSave">保存</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts">
  import { defineComponent, computed, onMounted, reactive } from 'vue';
  import type { PropType } from 'vue';
  import { InfoFlowTreeNode } from '../pageLeft/pageLeftHooks';
  import { cloneDeep } from 'lodash-es';
  import { ElMessage } from 'element-plus';
  import { useGetModuleName } from './editModuleHooks';

  interface FormState {
    title: {
      name: string;
    };
    descr: {
      name: string;
    };
  }

  export default defineComponent({
    name: 'TabEdit',
    props: {
      modelValue: {
        type: Boolean,
        default: false
      },
      editItem: {
        type: Object as PropType<InfoFlowTreeNode>,
        default: () => ({})
      }
    },
    emits: ['update:modelValue', 'on-confirm'],
    setup(props, { emit }) {
      const moduleName = useGetModuleName(props.editItem);
      // dialog展示
      const showDialog = computed({
        get() {
          return props.modelValue;
        },
        set(val) {
          emit('update:modelValue', val);
        }
      });

      const formState = reactive<FormState>({
        title: {
          name: ''
        },
        descr: {
          name: ''
        }
      });

      /*
       * @info 点击取消关闭弹窗
       * */
      const handleCloseDialog = () => {
        showDialog.value = false;
      };

      /*
       * @info 校验数据的合法性
       * */
      const checkFormState = () => {
        if (!formState.title.name) {
          ElMessage.error('标题不能为空');
          return false;
        }
        return true;
      };

      /*
       * @info 点击确定校验数据并传值父组件
       * */
      const handleSave = () => {
        const isValid = checkFormState();
        if (!isValid) return;
        emit('on-confirm', formState);
        showDialog.value = false;
      };

      /*
       * @info 初始化弹窗数据
       * */
      const initModuleEdit = () => {
        const { title, descr } = cloneDeep(props.editItem);
        title && (formState.title = title);
        descr && (formState.descr = descr);
      };

      onMounted(() => {
        initModuleEdit();
      });

      return {
        showDialog,
        moduleName,
        formState,
        handleCloseDialog,
        handleSave
      };
    }
  });
</script>

<style lang="less" scoped>
  @import '../style/editModuleStyle.less';
</style>
