<script lang="tsx">
  import { defineComponent, ref } from 'vue';

  export default defineComponent({
    name: 'Collapse',
    setup(props, { slots }) {
      const activeCollapseName = ref('base');

      return () => {
        return (
          <>
            <el-collapse accordion v-model={activeCollapseName.value}>
              {slots.base && (
                <el-collapse-item name="base" title="基础设置">
                  <div style="margin-top: 20px">{slots.base()}</div>
                </el-collapse-item>
              )}
              {slots.senior && (
                <el-collapse-item name="senior" title="高级设置">
                  <div style="margin-top: 20px">{slots.senior()}</div>
                </el-collapse-item>
              )}
            </el-collapse>
          </>
        );
      };
    }
  });
</script>

<style lang="less"></style>
