<script lang="tsx">
  import { computed, defineComponent, ref } from 'vue';
  import { useStore } from 'vuex';
  import sysConfig from '@/utils/sysConfig';

  export default defineComponent({
    name: 'DecorateView',
    setup() {
      const store = useStore();
      const iframeElem = ref<HTMLIFrameElement | null>(null);
      const iframeWindow = computed(() => iframeElem.value?.contentWindow);

      const decorateInfoFlowSn = computed(() => {
        return store.state.decorateModule.decorateInfoFlowSn;
      });
      // 传递消息给iframe
      const postMsgToIframe = (msg?: string) => {
        iframeWindow.value?.postMessage(msg || 'onRefresh', sysConfig.previewUrl);
      };

      return {
        decorateInfoFlowSn,
        postMsgToIframe,
        iframeElem
      };
    },
    render() {
      const { decorateInfoFlowSn } = this;
      return (
        <>
          <div class="render-comp">
            <div class="simulator">
              <iframe
                ref="iframeElem"
                src={`${sysConfig.previewUrl}?infoFlowSn=${decorateInfoFlowSn}`}
                allowfullscreen
                style="width: 100%; height: 100%;"
              />
            </div>
          </div>
        </>
      );
    }
  });
</script>

<style lang="less">
  .render-comp {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    width: 100%;
    .simulator {
      width: 377px;
      height: 90%;
      overflow-y: auto;
      background: #fff;
      box-shadow: 0 0 10px 1px #b1aeae;
      &::-webkit-scrollbar {
        display: none;
      }
    }
    @media screen and (min-height: 900px) {
      .simulator {
        height: 669px;
      }
    }
    @media screen and (min-height: 1200px) {
      .simulator {
        height: 812px;
      }
    }
  }
</style>
