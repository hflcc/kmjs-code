<script lang="tsx">
  import { defineComponent, computed, ref, provide, onMounted } from 'vue';
  import type { Ref, Component } from 'vue';
  import pageLeft from './components/pageLeft/pageLeft.vue';
  import pageView from './components/pageView/pageView.vue';
  import qrCode from 'qrcode-vue3';
  import { useStore } from 'vuex';
  import sysConfig from '@/utils/sysConfig';
  import { getPlatformNameAPI } from '@/api/infoFlow';

  export default defineComponent({
    name: 'InfoFlowIndex',
    components: {
      pageLeft,
      pageView,
      qrCode
    },
    setup() {
      const store = useStore();

      const decorateTypeName = computed(() => store.state.DEC_TYPE_NAME);

      const platformName = ref('');

      const decorateInfoFlowSn = computed(() => {
        return store.state.decorateModule.decorateInfoFlowSn;
      });

      const pageViewElem = ref<Component | null>(null) as Ref<{
        postMsgToIframe: (msg?: string) => void;
        [i: string]: unknown;
      }>;
      // 给子/孙组件调用, 信息流更新时调用刷新预览
      provide('onPageViewRefresh', () => {
        pageViewElem.value?.postMsgToIframe();
      });

      const getPlatformInfo = async () => {
        const res = await getPlatformNameAPI(store.state.OTHER_SYS_INFO.appId);
        platformName.value = res.name;
      };

      onMounted(() => {
        getPlatformInfo();
      });

      return () => (
        <div class="decorate-wrap">
          <header class="header-box">
            <nav class="header-box--t">
              {decorateTypeName.value}({platformName.value})
            </nav>
            <div class="header-box--h">
              <el-popover
                placement="bottom"
                width={120}
                trigger="click"
                v-slots={{
                  reference: () => <el-button size="medium">真机预览</el-button>
                }}
              >
                <div style="display: flex; justify-content: center; align-items: center;flex-direction: column;">
                  <qr-code
                    width={120}
                    height={120}
                    value={`${sysConfig.previewUrl}?infoFlowSn=${decorateInfoFlowSn.value}`}
                    qrOptions={{ typeNumber: 5, mode: 'Byte', errorCorrectionLevel: 'L' }}
                    dotsOptions={{ type: 'dots', color: '#000000' }}
                    backgroundOptions={{ color: '#ffffff' }}
                    cornersSquareOptions={{ type: 'square', color: '#000000' }}
                    cornersDotOptions={{ type: 'square', color: '#000000' }}
                  />
                  <p>手机扫码预览</p>
                </div>
              </el-popover>
            </div>
          </header>
          <div class="decorate-page">
            <div class="comp-wrap">
              <page-left />
            </div>
            <div class="con-wrap">
              <page-view ref={pageViewElem} />
            </div>
          </div>
        </div>
      );
    }
  });
</script>

<style lang="less">
  .decorate-wrap {
    padding: 20px;
    height: 100%;
    .header-box {
      position: relative;
      height: 50px;
      .center() {
        position: absolute;
        top: 50%;
      }
      .header-box--t {
        .center();
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 16px;
      }
      .header-box--h {
        .center();
        right: 0;
        transform: translate(0, -50%);
      }
    }
    .decorate-page {
      display: flex;
      width: 100%;
      height: calc(100% - 50px);
      .comp-wrap {
        flex: 1;
        flex-shrink: 0;
        height: 100%;
      }
      .con-wrap {
        flex: 1;
        height: 100%;
        background: #f8f8f8;
      }
    }
  }
</style>
