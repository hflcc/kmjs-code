interface UnknownObj<T> {
  [i: string]: T | unknown;
}
