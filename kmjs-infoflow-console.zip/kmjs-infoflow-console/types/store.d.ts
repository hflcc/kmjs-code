interface SourceStore {
  ossUrl: CommonOssCommonListSeqs;
}

interface CommonOssCommonListSeqs {
  [s: string]: {
    bucketName: string;
    id: number;
    seq: string;
    url: string;
    name: string;
    objectName: string;
    remark: string;
    storeType: string;
  };
}

interface RootState {
  ACCESS_TOKEN: string;
}
