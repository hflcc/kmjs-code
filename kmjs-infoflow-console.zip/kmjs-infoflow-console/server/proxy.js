const fs = require('fs');
const express = require('express');
const router = express.Router();
const { createProxyMiddleware } = require('http-proxy-middleware');
// 目前仅仅有一个环境的配置，有别的需要注意这个顺序
let env = process.argv.slice(2)[0];
console.log(env);
if (env && env.includes('action')) {
  env = env.split('=')[1];
}

let stderr = fs.createWriteStream('./nodeLog.log', {
  flags: 'w', //
  encoding: 'utf8' // utf8编码
});

// 创建logger
let logger = new console.Console(stderr);

fs.writeFile('./nodeLog.log', '', function (err) {
  if (err) {
    console.log(err);
  }
});

function log(req, res, next) {
  next();
}
module.exports = () => {
  router.use(
    '/',
    log,
    createProxyMiddleware({
      // target: env === 'test' ? 'http://172.18.88.221:18808' : 'http://172.18.88.224:18808',
      target: env === 'test' ? 'http://api-dev.kmyun.cn' : 'http://api.kmyun.cn',
      changeOrigin: true,
      pathRewrite: { '^/api/': '/' },
      onProxyReq(proxyReq, req, res) {
        console.log(res);
        // logger.log(res);
      }
    })
  );
  return router;
};
