const path = require('path');
const express = require('express');
const proxy = require('./proxy');
const app = express();

app.use('/api', proxy());
app.use(
  express.static(path.resolve(__dirname, './dist/'), {
    cacheControl: false,
    etag: false,
    lastModified: false
  })
);

app.listen(16009, () => {
  console.log('success listen at port:16009......');
});
