#!/bin/sh
docker rm -f `docker ps -a | grep -w kmjs-infoflow-console | awk '{print $1}'`;
docker rmi --force `docker images | grep -w 172.18.88.211:7080/library/kmjs-infoflow-console:v1 | awk '{print $3}'`;
docker pull 172.18.88.211:7080/library/kmjs-infoflow-console:v1
docker run --name=kmjs-infoflow-console -d -e "action=test" -v /etc/hosts:/etc/hosts -p 16009:16009 172.18.88.211:7080/library/kmjs-infoflow-console:v1
