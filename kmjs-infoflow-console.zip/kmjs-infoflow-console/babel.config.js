module.exports = {
  plugins: [
    '@babel/plugin-proposal-nullish-coalescing-operator', // 让babel编译识别js可选链
    '@babel/plugin-proposal-optional-chaining' // 让babel编译识别js双问号
  ],
  presets: ['@vue/cli-plugin-babel/preset']
};
