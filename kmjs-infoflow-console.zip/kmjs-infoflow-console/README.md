# infoflow

发布生产: 
* 设置git web hooks
* 设置生产jenkins
* 在master分支 打tag 如: git tag v1.0
* 推送master分支触发git钩子部署jenkins ```git push origin v1.0``` 

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
