#!/bin/sh
docker rm -f -p kmjs-infoflow-console;
docker rmi --force kmjs-infoflow-console;
docker build -t kmjs-infoflow-console:local .
docker run -e "action=test" -p 16009:16009 kmjs-infoflow-console:local
