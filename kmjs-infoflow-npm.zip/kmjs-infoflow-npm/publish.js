/**
 * Created by HING on 2021-12-11 21:23
 * 该脚本用于npm自动登录以及自动发布
 */
const shell = require('shelljs')
const path = require('path')
const fs = require('fs')
const args = process.argv

const registry = 'http://npm.kmjs.com'
const versionType = args.find(item => item.includes('--npmversion'))?.split('--npmversion=')[1]
const username = 'kmjs'
const password = 'kmjs'
const email = 'kmjs@163.com'
const inputArray = [
  username + '\n',
  password + '\n',
  email + '\n'
]

// 判断文件符不符合npm发包结构
const fileExist = () => {
  return new Promise((resolve, reject) => {
    // 如果有app.json说明在dev开发中,不能发布npm包
    fs.access(path.join(__dirname, 'dist', 'app.json'), fs.constants.F_OK, (err) => {
      if (!err) {
        return resolve('fail')
      }
      return resolve('success')
    })
  })
}

const promisifyExec = (cmd = '') => {
  return new Promise((resolve, reject) => {
    const child = shell.exec(cmd, { async: true })
    child.stdout.on('data', (res) => {
      resolve(res)
    })
  })
}

/*
* @info 执行发布逻辑
* */
fileExist().then((res) => {
  if (res === 'success') {
    npmlogin().then(async () => {
      // 修改npm发布版本
      await promisifyExec(`npm version ${versionType}`)
      // 推送npm包到仓库
      await promisifyExec(`npm publish --registry ${registry}`)
      // 推送本地修改后的package.json文件到git仓库
      await promisifyExec(`git push`)
    })
  } else {
    console.log('Error: 请先执行 npm run build:infoflow 构建包')
  }
})

/*
* @info 登录npm仓库
* */
function npmlogin () {
  return new Promise((resolve, reject) => {
    const child = shell.exec(`npm login --registry ${registry}`, { async: true })

    child.stdout.on('data', (chunk) => {
      const cmd = inputArray.shift()
      if (cmd) {
        shell.echo(cmd)
        child.stdin.write(cmd)
      } else {
        child.stdin.end()
        resolve()
      }
    })
  })
}
