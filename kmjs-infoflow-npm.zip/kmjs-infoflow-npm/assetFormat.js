const fs = require('fs')
const path = require('path')

const resolve = (p = '') => path.resolve(__dirname, `dist/components/${p}`)

/*
* 将打包后的dist文件加上相对路径,避免在使用npm包时使用绝对路径,导致找不到包报错
* */
const names = fs.readdirSync(resolve())
names.forEach(name => {
  const files = fs.readdirSync(resolve(name))
  files.forEach(p => {
    if (p.includes('.json')) {
      const operateFile = resolve(`${name}/${p}`)
      const f = fs.readFileSync(operateFile, { encoding: 'utf8' })
      const obj = JSON.parse(f)
      if (obj.component && Object.keys(obj.usingComponents).length > 0) {
        Object.keys(obj.usingComponents).forEach(key => {
          obj.usingComponents[key] = `../..${obj.usingComponents[key]}`
        })
        const str = JSON.stringify(obj, '', '\t')
        fs.writeFileSync(operateFile, str)
      }
    }
  })
})
