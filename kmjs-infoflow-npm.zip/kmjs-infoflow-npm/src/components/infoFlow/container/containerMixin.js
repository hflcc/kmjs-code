import { getContainerStyleMap } from '../utils/styleFormat'

export default {
  properties: {
    datas: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    contStyleMap () {
      return getContainerStyleMap(this.datas)
    },
    // 容器原始属性样式
    contOriginStyle () {
      return getContainerStyleMap(this.datas).originStyle
    }
  }
}
