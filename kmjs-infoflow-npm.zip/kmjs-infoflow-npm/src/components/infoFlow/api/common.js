import ajax from '../utils/ajax'

// 通过图片seq获取图片url路径
export const getImageUrlAPI = (seqs, style = '') => ajax.get(`/oss/common/list/seqs?seqs=${seqs}${style ? `&style=${style}` : ''}`)

// 通用获取业务数据详情接口, 如商品goods/活动activity/店铺shop...
export const getBizDataAPI = (type = '') => {
  return (sns = []) => {
    return ajax.get(`/info/common/flow/resource/map/${type}/${sns.join(',')}`)
  }
}

// 获取商品数据
export const getGoodsAPI = getBizDataAPI('goods')
// 获取店铺数据
export const getShopAPI = getBizDataAPI('shop')
// 获取文章数据
export const getArticleAPI = getBizDataAPI('article')
// 获取协会数据
export const getSocietyAPI = getBizDataAPI('society')
// 获取活动数据
export const getActivityAPI = getBizDataAPI('activity')
// 获取优惠券数据
export const getTicketAPI = getBizDataAPI('ticket')
