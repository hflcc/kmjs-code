import { getActualImageUrl } from './index'

const clientWidth = wx.getSystemInfoSync().screenWidth

// 获取item的样式 注意样式后面添加;分号
export const getItemStyle = (data = {}) => {
  const { borderRadius, height, width } = data
  let style = ''
  // 设置圆角
  if (typeof borderRadius === 'number') {
    style += `border-radius: ${borderRadius}px;overflow: hidden;`
  }
  // 给全部item组件设置高度
  if (typeof height === 'number') {
    style += `height: ${height}px;`
  }
  // 设置默认宽度,针对全屏写入
  if (
    data.name === 'goods1' ||
    data.name === 'shop1' ||
    data.name === 'shop2' ||
    data.name === 'article1' ||
    data.name === 'activity2' ||
    data.name === 'society1' ||
    data.name === 'ticket5' ||
    data.name === 'advert' ||
    data.name === 'table'
  ) {
    style += `width: ${clientWidth}px;`
  } else if (data.name === 'banner') {
    style += `max-width: 100%;`
  } else if (data.name === 'image_text1') {
    style += `width: ${width || 70}px;`
  } else if (data.name === 'goods2' || data.name === 'activity1') {
    style += `width: ${clientWidth / 2}px;`
  } else if (data.name === 'ticket4') {
    style += `width: 100px;`
  }
  return style
}

// 获取通过container数据计算出来的样式字符串; 注意样式后面添加;分号
export const getContainerStyleMap = (data = {}) => {
  const { borderRadius, background, padding, gridPadding, name, margin } = data
  let gridStyle = ''
  let containerStyle = ''
  let differentGridStyle = ''

  // 这里针对小程序样式圆角可能不生效问题, 根据微信社区提示,加上以下样式
  containerStyle += 'transform: translateY(0);'

  // #region 计算 gridStyle
  // 设置背景色
  if (background) {
    if (background.image) {
      containerStyle += `background: url("${getActualImageUrl(
        background.image
      )}");background-size: 100% 100%;`
    } else if (background.color) {
      containerStyle += `background: ${background.color};`
    }
  }
  // 设置margin
  if (margin) {
    const { top = 0, right = 0, bottom = 0, left = 0 } = margin
    containerStyle += `margin: ${top}px ${right}px ${bottom}px ${left}px;`
  }
  // 设置padding
  if (padding) {
    const { top = 0, right = 0, bottom = 0, left = 0 } = padding
    containerStyle += `padding: ${top}px ${right}px ${bottom}px ${left}px;`
  }
  // 设置圆角
  if (typeof borderRadius === 'number') {
    containerStyle += `border-radius: ${borderRadius}px;overflow: ${name === 'category' ? 'visible' : 'hidden'}`
  }
  // #endregion

  // #region 计算 containerStyle
  if (gridPadding) {
    // let { col = 0, row = 0 } = gridPadding;
    // 为了方便用户操作,col,row互相切换
    const [col, row] = [gridPadding.row || 0, gridPadding.col || 0]
    gridStyle += `grid-column-gap: ${col}px;`
    gridStyle += `grid-row-gap: ${row}px;`
    switch (name) {
      case 'grid_1_2':
      case 'grid_2_2':
      case 'shape_y':
        gridStyle += `grid-template-columns: repeat(2, calc(50% - ${
          col / 2
        }px));`
        break
      case 'grid_1_3':
      case 'grid_2_3':
      case 'grid_3_3':
        gridStyle += `grid-template-columns: repeat(3, calc(33.33% - ${
          (col * 2) / 3
        }px));`
        break
      case 'grid_1_4':
      case 'grid_2_4':
      case 'shape_l':
        gridStyle += `grid-template-columns: repeat(4, calc(25% - ${
          (col * 3) / 4
        }px));`
        break
      case 'grid_1_5':
      case 'grid_2_5':
        gridStyle += `grid-template-columns: repeat(5, calc(20% - ${
          (col * 4) / 5
        }px));`
        break
      default:
        break
    }
  }
  // #endregion

  // #region 计算l型和y型 上面和下面的间隙
  if ((name === 'shape_l' || name === 'shape_y') && gridPadding) {
    differentGridStyle += `margin-bottom: ${gridPadding.row}px;`
  }
  // #endregion

  return {
    gridStyle,
    containerStyle,
    differentGridStyle,
    originStyle: {
      padding,
      margin
    }
  }
}
