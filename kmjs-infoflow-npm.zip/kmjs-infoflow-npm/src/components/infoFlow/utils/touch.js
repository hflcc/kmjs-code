/**
 * Created by hing on 2021-12-19 21:42
 */
const MIN_DISTANCE = 10

export function getDirection (x, y) {
  if (x > y && x > MIN_DISTANCE) {
    return 'horizontal'
  }
  if (y > x && y > MIN_DISTANCE) {
    return 'vertical'
  }
  return ''
}
