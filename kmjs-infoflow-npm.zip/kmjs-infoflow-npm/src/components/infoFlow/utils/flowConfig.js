export default {
  // 后台返回的信息流原始数据, 存储storage中
  originDataKey: 'infoFlowOriginData_',
  // 存储信息流所有图片的key, 存储storage中
  imageKey: 'infoFlowImageData_',
  // 存储信息流业务数据的key, 存储storage中
  dataKey: 'infoFlowBizData_'
}
