import { getImageUrlBySeq, saveDataToStorage } from './index'
import flowConfig from './flowConfig'

import {
  getGoodsAPI,
  getActivityAPI,
  getArticleAPI,
  getShopAPI,
  getSocietyAPI,
  getTicketAPI } from '../api/common'

// 接口请求阀值限制
const reqLimit = 30

export const buildFn = async (data = {}, infoFlowSn = '') => {
  const imageArr = []
  const dataSnArr = {
    goods: [],
    shop: [],
    article: [],
    society: [],
    activity: [],
    ticket: []
  }
  // 递归构建数据
  const loopBuild = (list = []) => {
    list.forEach(item => {
      // 这里将信息流sn注入到每个容器/item组件中,方便后续访问
      item.infoFlowSn = infoFlowSn
      // 判断是否是容器
      if (item.type === 'container') {
        if (item.background?.image) {
          imageArr.push(item.background.image)
        }
        // 处理特殊容器分类组
        if (item.name === 'category') {
          if (item.child?.length) {
            item.child.forEach(obj => {
              // 因为分类组的数据比较特殊, 这里为了前端渲染, 将分类组的数据用child字段装起来放到分类组tab中, 并再递归处理
              obj.child = data[obj.sn] || []
              if (obj.child.length) {
                loopBuild(obj.child)
              }
            })
          }
        }
        // 普通容器如果有子集的情况直接递归遍历
        if (item.child?.length) {
          loopBuild(item.child)
        }
        // 处理是item的情况
      } else if (item.type === 'item') {
        // banner轮播图特殊处理
        if (item.name === 'banner') {
          item.data && item.data.itemList && item.data.itemList.forEach(obj => {
            if (obj.image) {
              imageArr.push(obj.image)
            }
          })
        } else {
          item.coverImages && item.coverImages.forEach(obj => {
            if (obj.ossId) {
              imageArr.push(obj.ossId)
            }
          })
          if (item.biz?.value) {
            dataSnArr[item.biz.type].push(item.biz.value)
          }
        }
      }
    })
  }

  loopBuild(data.main)

  // 图片请求
  const imgReqs = splitRequest(imageArr).map(arr => getImageUrlBySeq(arr))
  // 商品请求
  const goodsReqs = splitRequest(dataSnArr.goods).map(arr => getGoodsAPI(arr))
  // 店铺请求
  const shopReqs = splitRequest(dataSnArr.shop).map(arr => getShopAPI(arr))
  // 文章请求
  const articleReqs = splitRequest(dataSnArr.article).map(arr => getArticleAPI(arr))
  // 协会请求
  const societyReqs = splitRequest(dataSnArr.society).map(arr => getSocietyAPI(arr))
  // 活动请求
  const activityReqs = splitRequest(dataSnArr.activity).map(arr => getActivityAPI(arr))
  // 优惠券请求
  const ticketReqs = splitRequest(dataSnArr.ticket).map(arr => getTicketAPI(arr))

  const bizReqList = [goodsReqs, shopReqs, articleReqs, societyReqs, activityReqs, ticketReqs].flat()
  // 业务数据请求
  const bizResult = await Promise.allSettled(bizReqList)
  const bizObj = mergePromiseArr(bizResult)
  const bizImages = []
  /* handleBizData 处理请求回来的业务数据 做以下两件事
      1.将业务数据data的值 json字符串转换为json对象
      2.将业务数据中含有的图片ossId也一并取出
    */
  handleBizData(bizObj, bizImages)
  // 将处理好的业务数据对象保存到storage中, { [key: string]: Object }
  saveDataToStorage(bizObj, flowConfig.dataKey + infoFlowSn)
  // 切割图片请求
  const bizImgReqs = splitRequest(bizImages).map(arr => getImageUrlBySeq(arr))
  // 图片数据请求
  const imgResult = await Promise.allSettled([...imgReqs, ...bizImgReqs])
  const imgObj = mergePromiseArr(imgResult)
  // 将图片对象保存到storage中, { [key: string]: string }
  saveDataToStorage(imgObj, flowConfig.imageKey + infoFlowSn)
}

const handleBizData = (bizObj = {}, imgArr = []) => {
  Object.keys(bizObj).forEach(key => {
    try {
      const biz = JSON.parse(bizObj[key]?.data || '{}')
      bizObj[key].data = biz
      if (biz.coverImages) {
        biz.coverImages.forEach(row => imgArr.push(row.ossId))
      }
      if (biz.main && biz.main.cover) {
        imgArr.push(biz.main?.cover)
      }
    } catch (err) {
      console.log(err)
    }
  })
}

// 切割sn请求数, 防止一次性请求sn过多
const splitRequest = (arr = []) => {
  const sns = [...new Set(arr)] // 去重处理
  const reqs = []
  while (sns.length > 0) {
    reqs.push(sns.splice(0, reqLimit))
  }
  return reqs
}

// 将promise.allSettled返回数组中的对象合并为一个对象输出 [{},{}] ==> {}
const mergePromiseArr = (res = []) => {
  return res.reduce((total, cur) => {
    if (cur.status === 'fulfilled') {
      Object.assign(total, cur.value || {})
    }
    return total
  }, {})
  // return res.reduce((total, cur) => {
  //   Object.assign(total, cur)
  //   return total
  // }, {})
}
