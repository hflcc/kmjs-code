import { getImageUrlAPI } from '../api/common'
import flowConfig from './flowConfig'

export const formatTime = (time, fmt = 'YYYY/mm/dd HH:MM:SS') => {
  if (!time || time === 0 || time === '0') {
    return ''
  }
  if ((time + '').length === 10) {
    time *= 1000
  } else if ((time + '').length < 10) {
    return ''
  }
  const weekZH = {
    '0': '日',
    '1': '一',
    '2': '二',
    '3': '三',
    '4': '四',
    '5': '五',
    '6': '六'
  }
  const date = new Date(time)
  let ret
  const opt = {
    'Y+': date.getFullYear().toString(), // 年
    'm+': (date.getMonth() + 1).toString(), // 月
    'd+': date.getDate().toString(), // 日
    'H+': date.getHours().toString(), // 时
    'h+': date.getHours() > 12 ? ('下午 ' + (date.getHours() - 12)) : '上午 ' + date.getHours(), // 时
    'M+': date.getMinutes().toString(), // 分
    'S+': date.getSeconds().toString(), // 秒
    'dddd': date.getDay().toString(), // 星期几 0表示星期天
    'W': weekZH[date.getDay().toString()] // 中文 周几
    // 有其他格式化字符需求可以继续添加，必须转化成字符串
  }
  for (let k in opt) {
    ret = new RegExp('(' + k + ')').exec(fmt)
    if (ret) {
      fmt = fmt.replace(ret[1], (ret[1].length === 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, '0')))
    }
  }
  return fmt
}

export const formatterMoney = (num) => {
  if (num >= 10000) {
    if (num % 10000 === 0) {
      return num / 10000 + ''
    }
    return (num / 10000).toFixed(1)
  }
  return num
}

// 去掉expires, OSSAccessKeyId, Signature字段以及值
const formatImgUrl = (url = '') => {
  return url.replace(/Expires=\d+&/g, '').replace(/OSSAccessKeyId=\w+&/g, '').replace(/Signature=.*?&/g, '')
}

/*
* @Info 通过图片ossid/seq获取图片真实url路径
* */
export const getImageUrlBySeq = async (seqs = [], style = '') => {
  const list = Array.from(new Set(seqs))
  const res = await getImageUrlAPI(list.join(','), style)
  if (res) {
    return Object.keys(res).reduce((total, key) => {
      total[key] = formatImgUrl(res[key]?.url)
      return total
    }, {})
  }
}

/*
* @info 从缓存中取出信息流数据缓存
* */
export const getDataFromStorage = (storageKey = '') => {
  const value = wx.getStorageSync(storageKey)
  if (typeof value === 'object') {
    return value
  }
  return {}
}

/*
* @info 保存信息流数据缓存
* */
export const saveDataToStorage = (data = {}, storageKey = '') => {
  const storage = Object.assign({}, getDataFromStorage(storageKey), data)
  wx.setStorageSync(storageKey, storage)
}

/*
* @info 清除信息流数据缓存
* */
export const clearFlowStorage = (storageKey = '') => {
  wx.removeStorageSync(storageKey)
}

/*
* @info 获取storage缓存中的提起请求好的图片url路径
* */
export const getActualImageUrl = (ossId = '', infoFlowSn = '') => {
  const storageObj = getDataFromStorage(flowConfig.imageKey + infoFlowSn)
  return storageObj[ossId] || ''
}

/*
* @info 获取storage缓存中的提起请求好的业务数据
* */
export const getActualBizData = (bizId = '', infoFlowSn = '') => {
  const storageObj = getDataFromStorage(flowConfig.dataKey + infoFlowSn)
  return storageObj[bizId] || {}
}

export function debounce (fn = () => {}, delay = 300) {
  let timer = null
  return function () {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, arguments)
      timer = null
    }, delay)
  }
}
