/*
* @info 利用阿里云oss裁切图片
* @param payload {Object} { upHeight: number, downHeight: number }
* upHeight上部高度 downHeight下部高度
* @param type {String} 切割类型 up down
* */
export function cutFlowBgFn (payload = {}) {
  const { upHeight, downHeight } = payload
  return function setStyle (type = '') {
    let style = ''
    switch (type) {
      case 'up':
        style += `image/crop,h_${upHeight},x_0,y_0`
        break
      case 'down':
        style += `image/crop,h_${downHeight},x_0,y_${upHeight}`
        break
      default:
        style = ''
        break
    }
    return style
  }
}
