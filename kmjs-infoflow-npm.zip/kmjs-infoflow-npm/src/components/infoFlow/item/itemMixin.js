import { getItemStyle } from '../utils/styleFormat'
import { getActualBizData, getActualImageUrl } from '../utils'

export default {
  properties: {
    datas: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    itemStyle () {
      return getItemStyle(this.datas)
    },
    imageUrl () {
      const ossId = (this.datas?.coverImages && this.datas.coverImages[0]?.ossId) || ''
      // 注意: infoFlowSn由buildCore构建时动态添加
      return getActualImageUrl(ossId, this.datas.infoFlowSn)
    },
    result () {
      const bizId = this.datas?.biz?.value || ''
      // 注意: infoFlowSn由buildCore构建时动态添加
      return getActualBizData(bizId, this.datas.infoFlowSn)?.data || {}
    },
    busEmitKey () {
      // 注意: infoFlowSn由buildCore构建时动态添加
      return `INFO_FLOW_${this.datas.infoFlowSn}`
    }
  }
}
