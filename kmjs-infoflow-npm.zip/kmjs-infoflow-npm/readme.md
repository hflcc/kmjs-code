## kmjs-infoflow-npm

仓库地址: [http://npm.kmjs.com](http://npm.kmjs.com/)
> 访问仓库地址需添加 172.18.88.222  npm.kmjs.com 到hosts文件中
-----------------------------------------
1. 每次修改完需要发布时, 需要先执行 npm run build:infoflow 生成dist包
2. 执行 npm run publish:[major | minor | patch] 即可发包 例如 ```npm run publish:patch```

* major 大版本
* minor 小版本
* patch 补丁版本
-----------------------------------------

### 使用方式
* 引用
```
原生小程序:
{
  "usingComponents": {
    "info-flow": "kmjs-infoflow-npm/components/infoFlow/infoFlow"
  }
}
mpx小程序:
{
  "usingComponents": {
    "info-flow": "kmjs-infoflow-npm"
  }
}
```
* 调用
```
  <info-flow
    diyFlowBg
    refresherEnabled
    tabSticky
    decorateInfoFlowSn="{{ decorateInfoFlowSn }}"
    bindonFlowEmit="handleFlowEmit"
    bindonFlowError="handleFlowError"
    bindonGetFlowBg="handleFlowBg"
    bindonFlowRefreshed="handleFlowRefreshed"
    bindonFlowScroll="handleFlowScroll"
    bindonFlowReachBottom="handleFlowBottom"
  ></info-flow>
```

#### info-flow: Props
* diyFlowBg {Boolean} 默认: false (自定义信息流背景属性)
* refresherEnabled {Boolean} 默认: false (信息流是否需要刷新功能)
* tabSticky {Boolean} 默认: true (分类组tab是否需要吸顶效果)
* decorateInfoFlowSn {String} 默认: '' (信息流sn)
* cutFlowBgParams {Object} Record<'upHeight' | 'downHeight', number> (需要裁切的背景参数, 同时需要配置属性diyFlowBg为true, 通过onGetFlowBg事件获取裁切后的图片)

#### info-flow: Events
* onFlowEmit {Function} event: Event (信息流绑定的点击事件)
* onFlowError {Funtion} event: Event (信息流加载失败时触发 如信息流未发布)
* onGetFlowBg {Funtion} event: Event (获取信息流中设置的背景样式 **注意: diyFlowBg属性为true时会执行**)
* onFlowRefreshed {Funtion} event: Event (信息流刷新完时触发)
* onFlowScroll {Funtion} event: Event (信息流滚动时触发)
* onFlowReachBottom {Funtion} event: Event (信息流到底时触发)
* onTabIsFixed {Function} event: Event (分类组tab吸顶时触发)
